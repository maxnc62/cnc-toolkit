import adsk.core
import adsk.fusion
import traceback
import os
import sys
import json
import math
import time

# Apercu fluide partage (cnc_apercu_fluide.py a la racine de ToolkitCNC) : pastilles glissees par la souris.
try:
    _RACINE_TK = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if _RACINE_TK not in sys.path:
        sys.path.insert(0, _RACINE_TK)
    import cnc_apercu_fluide as _caf
except Exception:
    _caf = None

# ---------------------------------------------------------------------------
# Traverse sur corps CNC (2026-11-10, demande de Maxence)
#
# Une traverse (plaque d'epaisseur CPxx) posee sur un corps : on clique l'arete exterieure du corps, la traverse
# apparait en apercu, affleurante a la face exterieure, posee sur l'autre face de l'arete.
#   - longueur : detectee le long de l'arete (bout de l'arete ou corps en face) ;
#   - hauteur : detectee jusqu'au corps du dessus (ou du dessous) ; aucun corps : 100 mm « PAR DEFAUT » a saisir ;
#   - extremites : droite, arc 3 points (tangent dessous ou dessus) ou angle, retrait reglable ; si le corps du
#     dessus est en retrait, l'arc tangent est calcule pour se coller contre lui ;
#   - tenons dessus / dessous / cotes (moteur de Tenons CNC) ;
#   - mesures en mm ou en parametres utilisateur (CP18, LONG1*2...) dans la boite.
# Fenetres en bas a gauche (modele ReseauTrajectoireCNC / TraversesDossierCNC) : LONGUEUR, HAUTEUR, DEBUT, FIN ;
# clic sur une ligne ou sur une poignee = ligne active (bleue) : taper une mesure au clavier puis Entree.
# Poignees glissees par la souris hors du cycle de commande (cnc_apercu_fluide) : aperçu fluide.
# Creation : esquisse ENTIEREMENT contrainte sur la face exterieure du corps (arete projetee, enveloppe, arcs
# tangents, cotes avec les expressions saisies), extrusion de l'epaisseur, groupe replie « Traverse corps CNC »,
# reglages memorises pour l'historique (Modifier).
# ---------------------------------------------------------------------------

_app = None
_ui = None
_handlers = []

CMD_ID = 'TraverseCorpsCNCCmd'
COMMAND_NAME = 'Traverse CNC'                  # ex « Traverse sur corps CNC » (Maxence 2026-11-16)
COMMAND_DESC = 'Traverse posee sur un corps : clic sur l\'arete exterieure, longueur et hauteur detectees, bouts droits, en arc ou en angle'
PANEL_ID = 'SolidCreatePanel'
GROUPE_NOM = 'Traverse corps CNC'
ATTR_G, ATTR_N = 'TraverseCorpsCNC', 'edit'

_ADDIN_DIR = os.path.dirname(os.path.abspath(__file__))
PREFS_FILE = os.path.join(_ADDIN_DIR, 'traverse_corps_prefs.json')
TENON_PREFS = os.path.join(os.path.dirname(_ADDIN_DIR), 'TenonCNC', 'tenon_prefs.json')

ORANGE = (255, 90, 0, 255)
ROUGE = (220, 30, 30, 255)
H_DEFAUT = 10.0                       # cm : hauteur quand aucun corps n'est trouve
L_DEFAUT = 10.0                       # cm : longueur quand rien n'est detecte (courbe d'esquisse seule)

TYPES = ('auto', 'droite', 'arc', 'angle', 'conge', 'miroir')
TYPES_NOMS = ('Automatique (aretes droites sur les bords des corps du dessus et du dessous)', 'Droite (bout droit)', 'Arc 3 points', 'Angle (ligne droite)',
              'Conge asymetrique (largeur et hauteur)', 'Miroir du debut (meme bout que le debut)')
# ordre du bouton de forme dans les fenetres (Maxence 2026-11-13) : le debut (cote clique) part en conge, la fin en
# droite ; MIROIR (fin seulement) = la fin suit le debut en temps reel ; modifier la fin la rend independante
ORDRE_TYPES = {0: ('auto', 'arc', 'angle', 'droite', 'conge'),            # 1er clic = arc, conge en dernier
               1: ('auto', 'arc', 'angle', 'droite', 'miroir', 'conge')}  # (Maxence 2026-11-14)
# conge asymetrique (Maxence 2026-11-13) : quart d'ellipse tangent au cote et au dessus (ou au dessous), largeur =
# retrait du bout, hauteur reglable a part (b['hexpr']) ; esquisse : courbe conique (rho = racine(2) - 1) dont le
# sommet est le coin, donc tangente aux deux lignes
RHO_CONGE = math.sqrt(2.0) - 1.0
H_CONGE = '30 mm'


class _Bout(tuple):
    """(type, tangent, retrait, detecte) ; .h = hauteur du conge (cm) ou None."""
    h = None


def _b_hexpr(b):
    return (b.get('hexpr') or H_CONGE) if isinstance(b, dict) else H_CONGE


def _b_eff(i, bl):
    """Reglages effectifs du bout i : la fin en MIROIR prend ceux du debut (seul endroit ou le miroir est resolu)."""
    b = bl[i]
    if b.get('type') != 'miroir':
        return b
    if i == 0:
        return dict(b, type='droite')
    return dict(_b_eff(0, bl))


def _detacher_fin(bl):
    """La fin en MIROIR devient independante (copie du debut) avant d'etre modifiee a la main."""
    if bl[1].get('type') == 'miroir':
        n = dict(_b_eff(0, bl))
        bl[1].clear()
        bl[1].update(n)
        return True
    return False
TANS = ('dessous', 'dessus')
TANS_NOMS = ('Tangent dessous (dessus en retrait)', 'Tangent dessus (base en retrait)')

DEFAULT_PREFS = {'epaisseur_mm': 18.0,
                 'b0_type': 'auto', 'b0_tan': 'dessous', 'b1_type': 'auto', 'b1_tan': 'dessous',
                 'tn_dessus': False, 'tn_dessous': False, 'tn_cotes': False}
# reglages memorises (blob) : expressions des mesures en texte
CLES = ('L_auto', 'L_expr', 'L_saisie', 'H_auto', 'H_expr', 'H_saisie', 'b', 'inv', 'sens', 'pos', 'pos_expr',
        'tn_dessus', 'tn_dessous', 'tn_cotes', 'tn_nb', 'tn_len', 'tn_h', 'tn_h_auto', 'tn_bord', 'tn_place', 'mortaise_auto',
        'marge_auto', 'piece', 'axe', 'axes', 'para', 'sym', 'sym2', 'sym_nb', 'sym_e', 'L_delta', 'aretes',
        'dist_on', 'dist_expr', 'dist_cote', 'dist_param')

_s = {}                    # reglages
_ctx = {'ok': False}       # contexte de l'arete choisie (repere, detections)
_cur = {'calc': None, 'ep': 1.8, 'ep_nom': None}
_en_cours = {'v': False}
_drag = {'k': None}
_souris = {'pos': None, 'vp': None, 't': 0.0}
_bloc = {'t': 0.0, 'sel': None}
_edition = {'v': None}
_pastilles = {}
_saisie = {'row': None, 'txt': ''}      # saisie clavier en cours dans la fenetre active
_actif = {'row': 0}
_cmd = {'c': None}
ID_APERCU = 'TraverseCorpsCNC_apercu'
ID_PASTILLE = 'TraverseCorpsCNC_pastille%d'
ACTION_ID = 'TraverseCorpsCNC_action'
REDRAW_ID = 'TraverseCorpsCNC_redraw'
GROUPAGE_ID = 'TraverseCorpsCNC_groupage'
_action = {'evt': None, 'h': None}
_redraw = {'evt': None, 'h': None, 'on': False}
_groupage = {'evt': None, 'h': None}
_groupage_apres = {}
_apercu = {'g': [], 'sig': None}
_png_cache = {}
_dpr_cache = {}


def _tt(s):
    """Texte dans la langue choisie (cnc_i18n est charge par ToolkitCNC)."""
    try:
        m = sys.modules.get('cnc_i18n')
        return m.t(s) if m is not None else s
    except Exception:
        return s


def _log(msg):
    try:
        with open(os.path.join(_ADDIN_DIR, 'traverse_corps_journal.txt'), 'a', encoding='utf-8') as f:
            f.write(time.strftime('%H:%M:%S ') + msg + '\n')
    except Exception:
        pass


def _lire_json(p, defaut):
    d = dict(defaut)
    try:
        with open(p, 'r', encoding='utf-8') as f:
            d.update(json.load(f))
    except Exception:
        pass
    return d


def load_prefs():
    return _lire_json(PREFS_FILE, DEFAULT_PREFS)


def save_prefs(p):
    try:
        with open(PREFS_FILE, 'w', encoding='utf-8') as f:
            json.dump(p, f)
    except Exception:
        pass


def _tenon_prefs():
    return _lire_json(TENON_PREFS, {'edge_dist_mm': 50.0, 'tenon_count': 2, 'tenon_len_mm': 30.0, 'tenon_h_mm': 15.0,
                                    'centrer': False, 'repartition_mode': 'uniforme', 'repartition_cotes_pct': 33.3,
                                    'mortaise_auto': False, 'marge_auto': False})


def _nouveau(p=None):
    p = p or load_prefs()
    tp = _tenon_prefs()
    # nouvelle traverse : bouts AUTO (Maxence 2026-11-14, revient sur le conge par defaut du 13) : chaque bout suit le
    # corps du dessus (droit, aligne sur son bord ; arc seulement si le dessus est en retrait) ; conge, arc, angle,
    # miroir se choisissent ensuite (boutons ou clic sur le bout). Les types memorises dans les prefs sont ignores.
    bouts = [{'type': 'auto', 'tan': 'dessous', 'auto': True, 'expr': '30 mm', 'hexpr': H_CONGE},
             {'type': 'auto', 'tan': 'dessous', 'auto': True, 'expr': '30 mm', 'hexpr': H_CONGE}]
    return {'L_auto': True, 'L_expr': '', 'L_saisie': False, 'H_auto': True, 'H_expr': '', 'H_saisie': False,
            'b': bouts, 'pos': None, 'pos_expr': '',
            'inv': False, 'sens': False,
            'tn_dessus': bool(p.get('tn_dessus')), 'tn_dessous': bool(p.get('tn_dessous')),
            'tn_cotes': bool(p.get('tn_cotes')), 'tn_nb': int(p.get('tn_nb', 1)),
            'tn_len': float(tp.get('tenon_len_mm', 30.0)), 'tn_h': float(tp.get('tenon_h_mm', 15.0)), 'tn_h_auto': True,
            'tn_bord': float(tp.get('edge_dist_mm', 50.0)), 'tn_place': p.get('tn_place', 'centre'),
            'mortaise_auto': bool(tp.get('mortaise_auto', False)),
            'marge_auto': bool(tp.get('marge_auto', False)),
            'axe': '', 'axes': bool(p.get('axes', False)), 'aretes': [],
            'para': True, 'sym': False, 'sym2': False, 'sym_nb': int(p.get('sym_nb', 2)), 'sym_e': float(p.get('sym_e_cm', 20.0)),
            'dist_on': False, 'dist_expr': '170 mm', 'dist_cote': 0,     # distance a l'extremite de la base
            'enreg': False, 'enreg_nom': '',        # bouton « enregistrer comme piece » (jamais memorise)
            'L_delta': 0.0}     # + / - au clavier : 1 mm de plus ou de moins sur la longueur de toutes les pieces


def _design():
    return adsk.fusion.Design.cast(_app.activeProduct)


# --- Vecteurs ------------------------------------------------------------------------------------------------

def _v_sub(a, b): return (a[0] - b[0], a[1] - b[1], a[2] - b[2])
def _v_add(a, b): return (a[0] + b[0], a[1] + b[1], a[2] + b[2])
def _v_mul(a, k): return (a[0] * k, a[1] * k, a[2] * k)
def _v_dot(a, b): return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
def _v_cross(a, b): return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])
def _d3(a, b): return math.sqrt(_v_dot(_v_sub(a, b), _v_sub(a, b)))


def _v_norm(a):
    n = math.sqrt(_v_dot(a, a))
    return (a[0] / n, a[1] / n, a[2] / n) if n > 1e-12 else (0.0, 0.0, 0.0)


def _vers_haut():
    try:
        o = _app.preferences.generalPreferences.defaultModelingOrientation
        if o == adsk.core.DefaultModelingOrientations.YUpModelingOrientation:
            return (0.0, 1.0, 0.0)
    except Exception:
        pass
    return (0.0, 0.0, 1.0)


def _monde_pt(ent, p):
    q = p.copy()
    ctx = getattr(ent, 'assemblyContext', None)
    if ctx is not None:
        q.transformBy(ctx.transform2)
    return (q.x, q.y, q.z)


def _normale_face(face, p):
    """Normale exterieure (monde) de la face au point p (monde)."""
    try:
        ok, nv = face.evaluator.getNormalAtPoint(adsk.core.Point3D.create(*p))
        if ok:
            return _v_norm((nv.x, nv.y, nv.z))
    except Exception:
        pass
    try:
        g = face.geometry
        nv = g.normal
        return _v_norm((nv.x, nv.y, nv.z))
    except Exception:
        return None


# --- Rayons ------------------------------------------------------------------------------------------------

def _rayon(design, o, dv, ignorer=None):
    """[(face, distance)] tries des faces touchees par le rayon parti de o (tuple) dans la direction dv."""
    hp = adsk.core.ObjectCollection.create()
    try:
        faces = design.rootComponent.findBRepUsingRay(adsk.core.Point3D.create(*o),
                                                      adsk.core.Vector3D.create(*dv),
                                                      adsk.fusion.BRepEntityTypes.BRepFaceEntityType, -1.0, True, hp)
    except Exception:
        return []
    if faces is None:
        return []
    out = []
    for i in range(faces.count):
        f = faces.item(i)
        try:
            if ignorer and f.body.entityToken in ignorer:
                continue
        except Exception:
            pass
        if i < hp.count:
            h = hp.item(i)
            t = (h.x - o[0]) * dv[0] + (h.y - o[1]) * dv[1] + (h.z - o[2]) * dv[2]
            if t > 1e-5:
                out.append((f, t))
    out.sort(key=lambda x: x[1])
    return out


def _premier(design, o, dv, tmax=1000.0, ignorer=None):
    for f, t in _rayon(design, o, dv, ignorer):
        if t <= tmax:
            return f, t
    return None, None


def _dedans(body, p):
    try:
        return body.pointContainment(adsk.core.Point3D.create(*p)) == \
            adsk.fusion.PointContainment.PointInsidePointContainment
    except Exception:
        return False


# --- Contexte de l'arete : repere et detections -----------------------------------------------------------
# La traverse est PERPENDICULAIRE a l'arete (ou a la courbe) au point choisi, comme les copies de Reseau sur la
# trajectoire : son plan est normal a la tangente. Repere : S (point sur l'arete), u (longueur, en travers),
# n (hauteur, normale de la face d'appui), w = tangente (epaisseur, centree sur le point).

def _courbe(ent):
    """(evaluateur monde, p0, p1, longueur, type) d'une arete de corps ou d'une courbe d'esquisse ; None sinon."""
    e = adsk.fusion.BRepEdge.cast(ent)
    if e is not None:
        ev, kind = e.evaluator, 'brep'
    else:
        sc = adsk.fusion.SketchCurve.cast(ent)
        if sc is None:
            return None
        ev, kind = sc.worldGeometry.evaluator, 'esq'
    ok, p0, p1 = ev.getParameterExtents()
    if not ok:
        return None
    ok, lg = ev.getLengthAtParameter(p0, p1)
    if not ok or lg < 0.05:
        return None
    return ev, p0, p1, lg, kind


def _point_s(c, s):
    """(point, tangente unitaire) a l'abscisse curviligne s (cm depuis le debut de la courbe)."""
    ev, p0 = c['ev'], c['p0']
    s = max(0.0, min(c['Ltot'], s))
    ok, prm = ev.getParameterAtLength(p0, s)
    if not ok:
        prm = p0 + (c['p1'] - p0) * s / max(c['Ltot'], 1e-9)
    _ok, p = ev.getPointAtParameter(prm)
    _ok, d = ev.getFirstDerivative(prm)
    return (p.x, p.y, p.z), _v_norm((d.x, d.y, d.z))


def _s_du_point(c, q):
    try:
        ok, prm = c['ev'].getParameterAtPoint(adsk.core.Point3D.create(*q))
        if ok:
            ok, s = c['ev'].getLengthAtParameter(c['p0'], prm)
            if ok:
                return max(0.0, min(c['Ltot'], s))
    except Exception:
        pass
    return c['Ltot'] / 2.0


def _perp(v, t):
    """v rendu perpendiculaire a t, unitaire."""
    return _v_norm(_v_sub(v, _v_mul(t, _v_dot(v, t))))


def _uv_brep(c, P, t, k):
    """(n, u) de la face d'appui k : n = normale de la face dans le plan de la traverse, u = vers l'interieur
    du corps, le long de la face d'appui."""
    fs = c['faces']
    nk = _normale_face(fs[k], P)
    if nk is None:
        return None, None
    n = _perp(nk, t)
    u = None
    if len(fs) == 2:
        na = _normale_face(fs[1 - k], P)
        if na is not None:
            u0 = _v_mul(_perp(na, t), -1.0)
            u0 = _v_sub(u0, _v_mul(n, _v_dot(u0, n)))
            if math.sqrt(_v_dot(u0, u0)) > 0.05:
                u = _v_norm(u0)
    if u is None:
        u = _v_norm(_v_cross(t, n))
        if not _dedans(c['corps'], _v_add(_v_add(P, _v_mul(u, 0.1)), _v_mul(n, -0.1))):
            u = _v_mul(u, -1.0)
    return n, u


# --- Axes virtuels de la forme (2026-11-11, demande de Maxence) ------------------------------------------------
# Axes LONGUEUR et LARGEUR de la face d'appui (plane) : directions principales de son contour, par son centre.
# Une traverse « parallele a un axe » garde la direction de cet axe ou qu'on la glisse sur l'arete : des traverses
# paralleles entre elles le long d'une forme ovoide, au lieu de perpendiculaires a l'arete.

AXES_NOMS = ('', 'long', 'larg')


def _axes_forme(c):
    """{'o', 'n', 'long': (dir, tmin, tmax), 'larg': (...)} de la face d'appui plane ; None sinon (memorise)."""
    if 'axes' in c:
        return c['axes']
    c['axes'] = None
    try:
        f = c.get('f_app')
        if f is None or not isinstance(f.geometry, adsk.core.Plane):
            return None
        g = f.geometry.normal
        nrm = _v_norm((g.x, g.y, g.z))
        pts = []
        lp = f.loops.item(0)
        for i in range(f.loops.count):
            if f.loops.item(i).isOuter:
                lp = f.loops.item(i)
        for i in range(lp.edges.count):
            ev = lp.edges.item(i).evaluator
            ok, p0, p1 = ev.getParameterExtents()
            ok2, lg = ev.getLengthAtParameter(p0, p1)
            nb = max(4, min(120, int((lg if ok2 else 10.0) / 0.5)))
            prms = []
            for k in range(nb):
                okk, pk = ev.getParameterAtLength(p0, lg * k / nb) if ok2 else (False, 0.0)
                prms.append(pk if okk else p0 + (p1 - p0) * k / nb)
            ok, ps = ev.getPointsAtParameters(prms)
            if ok:
                pts += [(q.x, q.y, q.z) for q in ps]
        if len(pts) < 6:
            return None
        o = tuple(sum(q[i] for q in pts) / len(pts) for i in range(3))
        e1 = _perp((1.0, 0.0, 0.0), nrm) if abs(nrm[0]) < 0.9 else _perp((0.0, 1.0, 0.0), nrm)
        e2 = _v_cross(nrm, e1)
        xy = [(_v_dot(_v_sub(q, o), e1), _v_dot(_v_sub(q, o), e2)) for q in pts]
        sxx = sum(x * x for x, y in xy)
        syy = sum(y * y for x, y in xy)
        sxy = sum(x * y for x, y in xy)
        ang = 0.5 * math.atan2(2.0 * sxy, sxx - syy)              # direction principale (plus grande dispersion)
        d1 = _v_norm(_v_add(_v_mul(e1, math.cos(ang)), _v_mul(e2, math.sin(ang))))
        d2 = _v_norm(_v_cross(nrm, d1))
        res = {'o': o, 'n': nrm}
        ext = []
        for d in (d1, d2):
            pr = [_v_dot(_v_sub(q, o), d) for q in pts]
            ext.append((d, min(pr), max(pr)))
        ext.sort(key=lambda e: -(e[2] - e[1]))
        res['long'], res['larg'] = ext[0], ext[1]
        c['axes'] = res
    except Exception:
        _log('axes forme : ' + traceback.format_exc()[-300:])
    return c['axes']


def _repere(c, s):
    """Place le repere de la traverse a l'abscisse s (sans relancer les detections)."""
    P, t = _point_s(c, s)
    if c['kind'] == 'brep':
        n, u = _uv_brep(c, P, t, c['k'])
        if n is None:
            return False
    else:
        n = _perp(c['nz'], t)
        if math.sqrt(_v_dot(n, n)) < 0.5:
            return False
        u = _v_mul(_v_norm(_v_cross(t, n)), c['su'])
    w = t
    ax = _axes_forme(c) if (c['kind'] == 'brep' and _s.get('axe') in ('long', 'larg')) else None
    c['axe'] = None
    c['para'] = False
    if ax is not None and not _s.get('para', True):
        c['axe'] = _s['axe']            # axe de symetrie seulement : la traverse reste perpendiculaire au chemin
    elif ax is not None:
        # parallele a l'axe choisi : u = direction de l'axe (vers l'interieur), w = normale du plan
        a = _perp(ax[_s['axe']][0], n)
        if math.sqrt(_v_dot(a, a)) > 0.5:
            if _v_dot(a, u) < 0:
                a = _v_mul(a, -1.0)
            u = a
            w = _v_norm(_v_cross(n, u))
            if _v_dot(w, t) < 0:
                w = _v_mul(w, -1.0)
            c['axe'] = _s['axe']
            c['para'] = True
    if c.get('sens'):
        u = _v_mul(u, -1.0)
    c.update(s=max(0.0, min(c['Ltot'], s)), S=P, t=t, u=u, n=n, w=w, ub_cache={})
    return True


# --- Symetrie par rapport a l'axe (2026-11-11, demande de Maxence) -------------------------------------------
# Traverses paralleles a l'axe choisi, reparties symetriquement de part et d'autre : nb pieces a l'entraxe e
# (impair : celle du milieu sur l'axe). La traverse tiree a la poignee est la plus a l'exterieur de son cote :
# la glisser change l'entraxe, les autres suivent. Chaque piece a ses propres detections (longueur, hauteur,
# arcs) a sa position, et devient une traverse independante a la creation.

_sym = {'sig': None, 'pos': [], 'pieces': [], 'manque': 0, 'hors': False}


# --- Distance a l'extremite de la base (2026-11-13, demande de Maxence : dossier de canape a 170 mm de mousse) ----
# Mode DISTANCE : la traverse (toujours perpendiculaire a l'arete) glisse le long de l'arete jusqu'a ce que sa face
# du cote choisi soit a la distance D du point le plus loin du contour de la base, mesure selon l'epaisseur de la
# traverse (la normale de son plan). D, le cote et le mode sont memorises (historique : Modifier rouvre et recalcule).

def _dist_face(c):
    """Face de la base : la face d'appui (arete de corps) ; courbe d'esquisse : la face plane trouvee juste sous la
    traverse (memorisee)."""
    if c.get('f_app') is not None:
        return c['f_app']
    if 'dist_face' in c:
        return c['dist_face']
    f = None
    try:
        S, n, u = c['S'], c['n'], c['u']
        for x in (0.5, 2.0, 5.0):
            o = _v_add(_v_add(S, _v_mul(n, 0.05)), _v_mul(u, x))
            ff, _t = _premier(_design(), o, _v_mul(n, -1.0), 5.0, _ignores())
            if ff is not None and isinstance(ff.geometry, adsk.core.Plane):
                f = ff
                break
    except Exception:
        _log('distance face : ' + traceback.format_exc()[-200:])
    c['dist_face'] = f
    return f


def _dist_pts(c):
    """Points du contour exterieur de la face d'appui (monde), tous les ~2 mm (memorises)."""
    if 'dist_pts' in c:
        return c['dist_pts']
    pts, idx, segs = [], [], []
    try:
        f = _dist_face(c)
        if f is None:
            c['dist_pts'] = []
            return []
        lp = None
        for i in range(f.loops.count):
            if f.loops.item(i).isOuter:
                lp = f.loops.item(i)
        lp = lp or f.loops.item(0)
        for i in range(lp.edges.count):
            # arete par arete : une arete refusee par Fusion (parametres hors bornes) ne vide plus tout le contour
            # (« SANS BASE » sur le dossier de Maxence, 2026-11-13)
            try:
                ev = lp.edges.item(i).evaluator
                ok, p0, p1 = ev.getParameterExtents()
                lo, hi = min(p0, p1), max(p0, p1)
                ok2, lg = ev.getLengthAtParameter(p0, p1)
                nb = max(8, min(1500, int((lg if ok2 else 10.0) / 0.2)))
                prms = []
                for k in range(nb + 1):
                    okk, pk = ev.getParameterAtLength(p0, lg * k / nb) if ok2 else (False, 0.0)
                    pk = pk if okk else p0 + (p1 - p0) * k / nb
                    prms.append(min(hi, max(lo, pk)))
                try:
                    ok, ps = ev.getPointsAtParameters(prms)
                except Exception:
                    ok, ps = False, None
                if ok:
                    pts += [(q.x, q.y, q.z) for q in ps]
                else:
                    for pk in prms:
                        try:
                            okk, q = ev.getPointAtParameter(pk)
                            if okk:
                                pts.append((q.x, q.y, q.z))
                        except Exception:
                            pass
            except Exception:
                _log('distance contour (arete %d) : %s' % (i, traceback.format_exc()[-200:]))
            idx += [i] * (len(pts) - len(idx))
            segs.append(len(pts))                  # fin des points de l'arete i (les segments ne sautent pas d'arete)
    except Exception:
        _log('distance contour : ' + traceback.format_exc()[-300:])
    c['dist_pts'] = pts
    c['dist_idx'] = idx
    c['dist_fins'] = set(segs)
    return pts


def _dist_lie_longueur(c):
    """Longueur accrochee au contour de la base : mode DISTANCE, traverse parallele a l'axe, longueur AUTO, sans
    corps qui l'arrete."""
    return bool(_s.get('dist_on')) and c.get('ok') and c.get('para') and _s.get('L_auto') and \
        not _s.get('L_delta') and _dist_dispo(c)


def _dist_coupes(c, k):
    """Points ou le contour de la base coupe le plan w.p = k : [(abscisse le long de u depuis S, point, arete)]."""
    pts, idx, fins = _dist_pts(c), c.get('dist_idx') or [], c.get('dist_fins') or set()
    S, u, w = c['S'], c['u'], _dist_w(c)
    out = []
    for j in range(len(pts) - 1):
        if (j + 1) in fins or (idx and idx[j] != idx[j + 1]):
            continue
        a, b = pts[j], pts[j + 1]
        fa = a[0] * w[0] + a[1] * w[1] + a[2] * w[2] - k
        fb = b[0] * w[0] + b[1] * w[1] + b[2] * w[2] - k
        if fa == fb or fa * fb > 0:
            continue
        t = fa / (fa - fb)
        p = (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t)
        out.append((_v_dot(_v_sub(p, S), u), p, idx[j] if idx else 0))
    return out


def _dist_face_coupes(c, sgn, L_ref=None):
    """Debut et fin de la face sgn (+1 / -1 selon _dist_w) de la traverse sur le contour : ((t, p, arete), ...)."""
    S, w = c['S'], _dist_w(c)
    ks = S[0] * w[0] + S[1] * w[1] + S[2] * w[2]
    cp = _dist_coupes(c, ks + sgn * _cur['ep'] / 2.0)
    if len(cp) < 2:
        return None
    d0 = min(cp, key=lambda x: abs(x[0]))                             # cote de l'arete cliquee
    loin = [x for x in cp if x[0] > d0[0] + 0.5]
    if not loin:
        return None
    d1 = min(loin, key=lambda x: abs(x[0] - L_ref)) if L_ref is not None else min(loin, key=lambda x: x[0])
    return d0, d1


def _dist_bornes(c, L_ref=None):
    """Mode DISTANCE : debut et fin de la traverse sur la base, la face la plus a l'interieur a chaque bout (aucun
    coin dehors, les coins du cote serre touchent la base) : (a0, a1, [(face, point, arete) debut, ... fin]) ; None."""
    deb, fin = [], []
    for sgn in (1.0, -1.0):
        r = _dist_face_coupes(c, sgn, L_ref)
        if r is None:
            return None
        deb.append((sgn, r[0]))
        fin.append((sgn, r[1]))
    b0 = max(deb, key=lambda x: x[1][0])                              # le plus a l'interieur
    b1 = min(fin, key=lambda x: x[1][0])
    return b0[1][0], b1[1][0], (b0, b1)


def _dist_dispo(c=None):
    c = _ctx if c is None else c
    if not c.get('ok'):
        return False
    ok = bool(_dist_pts(c))
    if not ok and not c.get('dist_log'):
        c['dist_log'] = True                      # raison precise, une fois par contexte
        _log('distance : pas de base (%s, face %s, points %d)' % (
            c.get('kind'), 'oui' if _dist_face(c) is not None else 'non', len(c.get('dist_pts') or [])))
    return ok


def _dist_w(c):
    """Direction de l'epaisseur pour le mode DISTANCE : parallele a un axe, l'autre axe de la forme (fixe : w change
    de signe le long d'une arete fermee) ; sinon w."""
    if c.get('para') and c.get('axe') in ('long', 'larg'):
        ax = _axes_forme(c)
        if ax is not None:
            return ax['larg' if c['axe'] == 'long' else 'long'][0]
    return c['w']


def _dist_ecart(c, cote):
    """(ecart entre la face de la traverse du cote choisi et le plan d'extremite de la base, point extreme)."""
    S, w = c['S'], _dist_w(c)
    # point extreme selon w (memorise par direction : parallele a l'axe, w ne change pas d'une position a l'autre)
    cache = c.setdefault('dist_ext', {})
    cle = (cote, round(w[0], 6), round(w[1], 6), round(w[2], 6))
    if cle not in cache:
        best = None
        for p in _dist_pts(c):
            v = cote * (p[0] * w[0] + p[1] * w[1] + p[2] * w[2])
            if best is None or v > best[0]:
                best = (v, p)
        if len(cache) > 400:
            cache.clear()
        cache[cle] = best
    best = cache[cle]
    if best is None:
        return None, None
    v = best[0] - cote * (S[0] * w[0] + S[1] * w[1] + S[2] * w[2])
    return v - _cur['ep'] / 2.0, best[1]


def _dist_cote_auto(c):
    """Cote par defaut : l'extremite la plus proche de la traverse."""
    a, _p = _dist_ecart(c, 1.0)
    b, _q = _dist_ecart(c, -1.0)
    if a is None or b is None:
        return 1
    return 1 if a <= b else -1


def _dist_resoudre(c, D, cote):
    """Abscisse s de l'arete ou l'ecart vaut D (la plus proche de la position actuelle) ; None si impossible."""
    Ltot = c['Ltot']

    def f(s):
        cc = dict(c)
        if not _repere(cc, s):
            return None
        g, _p = _dist_ecart(cc, cote)
        return None if g is None else g - D
    nb = 80
    ss = [Ltot * k / nb for k in range(nb + 1)]
    vs = [f(s) for s in ss]
    racines = []
    for k in range(nb):
        a, b = vs[k], vs[k + 1]
        if a is None or b is None:
            continue
        if a == 0.0:
            racines.append(ss[k])
        elif a * b < 0:
            s0, s1, f0 = ss[k], ss[k + 1], a
            for _it in range(40):
                sm = 0.5 * (s0 + s1)
                fm = f(sm)
                if fm is None:
                    break
                if (fm < 0) == (f0 < 0):
                    s0, f0 = sm, fm
                else:
                    s1 = sm
                if s1 - s0 < 1e-5:
                    break
            racines.append(0.5 * (s0 + s1))
    if not racines:
        return None
    return min(racines, key=lambda s: abs(s - c['s']))


def _dist_appliquer():
    """Mode DISTANCE actif : la traverse principale est amenee (ou laissee) a la distance voulue."""
    c = _ctx
    c['dist_hors'] = False
    if not _s.get('dist_on') or not _dist_dispo(c):
        return
    c['dist_ref'] = True                          # piece principale : esquisse « Distance mousse » a la creation
    D = _eval_expr(_s.get('dist_expr'))
    if D is None:
        c['dist_hors'] = True
        return
    if not _s.get('dist_cote'):
        _s['dist_cote'] = _dist_cote_auto(c)
    cote = float(_s['dist_cote'])
    g, _p = _dist_ecart(c, cote)
    if g is not None and abs(g - D) < 1e-4:
        return
    if c.get('para'):
        # parallele a l'axe : le pied de la traverse est le point du contour de la base (toutes ses aretes) ou le
        # plan median est a la bonne distance, du cote du debut ; la traverse passe sur cette arete si besoin
        # (l'arete cliquee peut etre trop courte : FS210, 2026-11-13)
        try:
            if _dist_placer_contour(c, D, cote):
                return
        except Exception:
            _log('distance contour : ' + traceback.format_exc()[-300:])
    s = _dist_resoudre(c, D, cote)
    if s is None:
        c['dist_hors'] = True
        _log('distance : %.1f mm introuvable sur l\'arete' % (D * 10.0))
        return
    _s['pos_expr'] = ''
    _deplacer(s)


def _dist_orienter():
    """Mode DISTANCE active : une traverse alignee sur un axe de la forme (centree sur l'axe) passe « parallele a
    l'axe » : elle se deplace sans tourner (perpendiculaire a une arete courbe, elle pivotait de ~25 degres a 70 mm
    du centre d'un ovale et ne pouvait pas approcher l'extremite a moins de ~177 mm) ; la distance devient alors
    un parametre de Fusion (DIST_DOSSIER)."""
    c = _ctx
    if not _dist_dispo(c) or c.get('para'):
        return
    ax = _axes_forme(c)
    if ax is None:
        return
    k = max(('long', 'larg'), key=lambda a: abs(_v_dot(ax[a][0], c['u'])))
    if abs(_v_dot(ax[k][0], c['u'])) < 0.98:
        return                                   # traverse en biais : elle reste perpendiculaire a l'arete
    _s['axe'] = k
    _s['para'] = True
    _repere(c, c['s'])
    _detecter(_design(), c, _ignores())
    c.pop('dist_pts', None)
    _s['dist_cote'] = 0                          # cote recalcule dans le nouveau repere
    _log('distance : traverse parallele a l\'axe %s' % k)


def _dist_placer_contour(c, D, cote):
    """Parallele a l'axe : pied de la traverse = coupe du contour de la base par le plan median voulu, la plus
    proche du pied actuel. Vrai si la traverse est placee."""
    _g, Pe = _dist_ecart(c, cote)
    if Pe is None:
        return False
    w = _dist_w(c)
    k = (Pe[0] * w[0] + Pe[1] * w[1] + Pe[2] * w[2]) - cote * (D + _cur['ep'] / 2.0)
    cp = _dist_coupes(c, k)
    if not cp:
        return False
    S = c['S']
    t, P, iar = min(cp, key=lambda x: _d3(x[1], S))
    f = _dist_face(c)
    lp = None
    for i in range(f.loops.count):
        if f.loops.item(i).isOuter:
            lp = f.loops.item(i)
    lp = lp or f.loops.item(0)
    e = lp.edges.item(iar)
    ev = e.evaluator
    ok, p0, p1 = ev.getParameterExtents()
    okp, prm = ev.getParameterAtPoint(adsk.core.Point3D.create(*P))
    ok2, sl = ev.getLengthAtParameter(p0, prm) if okp else (False, 0.0)
    if not ok2:
        return False
    if e.entityToken == c['ent'].entityToken:
        _s['pos_expr'] = ''
        _deplacer(sl)
        return True
    # autre arete du contour : la traverse y passe (meme mecanisme que la selection en chaine)
    if _chaine_passer(e, sl):
        _detecter(_design(), _ctx, _ignores())
        _ctx['dist_ref'] = True
        _log('distance : traverse passee sur l\'arete %d du contour' % iar)
        return True
    return False


def _dist_bloque():
    """OK grise : mode DISTANCE actif mais la distance n'est pas atteignable sur l'arete."""
    return bool(_s.get('dist_on')) and _ctx.get('ok') and (_ctx.get('dist_hors') or not _dist_dispo())


def _dist_depuis_position():
    """Position glissee a la main en mode DISTANCE : D suit (la distance affichee est celle de la position)."""
    c = _ctx
    if not _s.get('dist_on') or not _dist_dispo(c) or not _s.get('dist_cote'):
        return
    g, _p = _dist_ecart(c, float(_s['dist_cote']))
    if g is not None and g > 0:
        _s['dist_expr'] = _mm_txt(round(g * 100.0) / 100.0)


def _dist_lignes(c, calc):
    """Apercu du mode DISTANCE : repere sur le point extreme, ligne d'appui parallele a la traverse, cote jusqu'a la
    face de la traverse (segments a plat)."""
    if not _s.get('dist_on') or not _dist_dispo(c) or not _s.get('dist_cote') or not calc.get('L'):
        return []
    cote = float(_s['dist_cote'])
    g, P = _dist_ecart(c, cote)
    if P is None:
        return []
    S, u, w, n = c['S'], c['u'], _dist_w(c), c['n']
    L = calc['L']
    lev = _v_mul(n, 0.08)                         # juste au-dessus de la face d'appui
    dw = cote * (_v_dot(_v_sub(P, S), w))         # du plan median de la traverse au plan d'extremite
    du = _v_dot(_v_sub(P, S), u)
    a0, a1 = min(0.0, du) - 2.0, max(L, du) + 2.0
    R0 = _v_add(_v_add(S, _v_mul(w, cote * dw)), _v_mul(u, a0))
    R1 = _v_add(_v_add(S, _v_mul(w, cote * dw)), _v_mul(u, a1))
    out = []

    def seg(p, q):
        p, q = _v_add(p, lev), _v_add(q, lev)
        out.extend(p)
        out.extend(q)
    seg(R0, R1)
    um = L / 2.0
    F = _v_add(_v_add(S, _v_mul(w, cote * _cur['ep'] / 2.0)), _v_mul(u, um))      # face de la traverse
    Q = _v_add(_v_add(S, _v_mul(w, cote * dw)), _v_mul(u, um))
    seg(F, Q)
    for X in (F, Q):                              # petits traits aux bouts de la cote
        seg(_v_add(X, _v_mul(u, -1.0)), _v_add(X, _v_mul(u, 1.0)))
    k = 1.2                                       # losange sur le point extreme
    for d1, d2 in ((u, w), (w, _v_mul(u, -1.0)), (_v_mul(u, -1.0), _v_mul(w, -1.0)), (_v_mul(w, -1.0), u)):
        seg(_v_add(P, _v_mul(d1, k)), _v_add(P, _v_mul(d2, k)))
    return out


def _sym_actif(c=None):
    c = _ctx if c is None else c
    return bool(_s.get('sym') or _s.get('sym2')) and bool(c.get('ok')) and c.get('kind') == 'brep' and \
        c.get('axe') in ('long', 'larg') and _axes_forme(c) is not None


def _sym_cibles(c, nb, e, x0, g0):
    """[(ecart, cote)] des autres pieces : celles du meme bout (sans la principale), puis, avec les deux axes
    (Ctrl + clic sur le 2e axe), la copie de toutes de l'autre cote de l'autre axe (cote -g0)."""
    if nb > 1:
        ip = nb - 1 if x0 >= 0 else 0
        meme = [x for k, x in enumerate(_sym_ecarts(nb, e)) if k != ip]
    else:
        meme = []
    out = [(x, g0) for x in meme]
    if _s.get('sym2'):
        out += [(x, -g0) for x in [x0] + meme]
    return out


def _sym_coord(c, P):
    """(ecart a l'axe choisi, position le long de cet axe) du point P."""
    ax = _axes_forme(c)
    a = ax[c['axe']][0]
    b = ax['larg' if c['axe'] == 'long' else 'long'][0]
    q = _v_sub(P, ax['o'])
    return _v_dot(q, b), _v_dot(q, a)


def _sym_ecarts(nb, e):
    return [(k - (nb - 1) / 2.0) * e for k in range(nb)]


def _sym_aretes(c):
    """Aretes du contour de la face d'appui qui contient l'arete cliquee (celle-ci d'abord)."""
    ent = c['ent']
    out = [ent]
    try:
        tok = ent.entityToken
        f = c['f_app']
        for i in range(f.loops.count):
            lp = f.loops.item(i)
            es = [lp.edges.item(j) for j in range(lp.edges.count)]
            if any(e.entityToken == tok for e in es):
                out += [e for e in es if e.entityToken != tok]
                break
    except Exception:
        _log('sym aretes : ' + traceback.format_exc()[-200:])
    return out


def _sym_ech(c, e):
    """[(s, point)] echantillons de l'arete e tous les 2 mm environ (memorises)."""
    cache = c.setdefault('sym_ech', {})
    k = e.entityToken
    if k not in cache:
        ev = e.evaluator
        ok, p0, p1 = ev.getParameterExtents()
        ok2, lg = ev.getLengthAtParameter(p0, p1)
        if not ok2:
            lg = 0.0
        nb = max(16, min(600, int(lg / 0.2)))
        out = []
        for i in range(nb + 1):
            sl = lg * i / nb
            okk, pk = ev.getParameterAtLength(p0, sl)
            if not okk:
                pk = p0 + (p1 - p0) * i / nb
            _o, q = ev.getPointAtParameter(pk)
            out.append((sl, (q.x, q.y, q.z)))
        cache[k] = (ev, p0, out)
    return cache[k]


def _sym_trouver(c, x, g_ref, aretes):
    """(arete, s) du point du contour a l'ecart x de l'axe, du meme bout que g_ref (le plus proche) ; None."""
    best = None
    for e in aretes:
        try:
            ev, p0, ech = _sym_ech(c, e)
        except Exception:
            continue
        prev = None
        for sl, P in ech:
            xx, gg = _sym_coord(c, P)
            if prev is not None:
                s0, x0, g0 = prev
                if (x0 - x) * (xx - x) <= 0 and abs(xx - x0) > 1e-9:
                    t = (x - x0) / (xx - x0)
                    sg, g = s0 + (sl - s0) * t, g0 + (gg - g0) * t
                    score = (0 if g * g_ref > 0 else 1, abs(g - g_ref))
                    if best is None or score < best[0]:
                        best = (score, e, sg, s0, sl, ev, p0)
            prev = (sl, xx, gg)
    if best is None:
        return None
    _sc, e, sg, sa, sb, ev, p0 = best
    for _it in range(4):                          # affinage (secante) sur la vraie courbe
        def ecart(sv):
            ok, pr = ev.getParameterAtLength(p0, sv)
            _o, q = ev.getPointAtParameter(pr)
            return _sym_coord(c, (q.x, q.y, q.z))[0] - x
        fa, fg = ecart(sa), ecart(sg)
        if abs(fg) < 1e-4 or abs(fg - fa) < 1e-12:
            break
        sa, sg = sg, sg - fg * (sg - sa) / (fg - fa)
    return e, sg


def _sym_placer(x):
    """Traverse principale amenee a l'ecart x de l'axe (sur l'arete cliquee, du meme bout)."""
    c = _ctx
    _x0, g0 = _sym_coord(c, c['S'])
    r = _sym_trouver(c, x, g0, [c['ent']])
    _sym['hors'] = r is None
    if r is None:
        _log('symetrie : ecart %.2f cm hors de l\'arete cliquee' % x)
        return False
    _s['pos_expr'] = ''
    _deplacer(r[1])
    return True


def _sym_cible():
    x0, _g = _sym_coord(_ctx, _ctx['S'])
    nb = max(1, int(_s.get('sym_nb') or 1))
    cote = 1.0 if x0 >= 0 else -1.0
    return cote * (nb - 1) / 2.0 * float(_s.get('sym_e') or 0.0)


def _sym_nb():
    return max(1, int(_s.get('sym_nb') or 1)) if _s.get('sym') else 1


def _nb_traverses(nb, ins=None):
    """Bouton - / + des fenetres : nombre de traverses en symetrie sur l'axe. Sans axe choisi, on prend celui
    qui suit le mieux la traverse actuelle (elle bouge le moins)."""
    nb = max(1, min(30, int(nb)))
    c = _ctx
    if not c.get('ok'):
        return
    if nb > 1 and c.get('axe') not in ('long', 'larg'):
        ax = _axes_forme(c) if c.get('kind') == 'brep' else None
        if ax is None:
            _log('symetrie : pas d\'axe (face d\'appui non plane)')
            return
        _s['sym2'] = False
        _s['axe'] = max(('long', 'larg'), key=lambda k: abs(_v_dot(ax[k][0], c['u'])))
        _s['axes'] = True
        _s['para'] = False
        _repere(c, c['s'])
        _detecter(_design(), c, _ignores())
    x0, _g = _sym_coord(c, c['S']) if _sym_actif_axe() else (0.0, 0.0)
    if nb > 1:
        # l'ecart de la traverse tenue reste le meme : les autres se placent entre elle et sa symetrique
        e = 2.0 * abs(x0) / (nb - 1)
        if e >= 1.0:
            _s['sym_e'] = round(e * 100.0) / 100.0
    _s['sym_nb'] = nb
    _s['sym'] = nb > 1
    if nb > 1:
        _sym_recaler()
    elif _sym_actif_axe():
        _sym_placer(0.0)                        # une seule : sur l'axe
    if ins is not None:
        _cur['ep'] = _ep_cm(ins)


def _sym_actif_axe():
    c = _ctx
    return bool(c.get('ok')) and c.get('kind') == 'brep' and c.get('axe') in ('long', 'larg') and \
        _axes_forme(c) is not None


def _sym_recaler():
    """Nombre, entraxe ou axe changes : la traverse principale va a sa place (la plus a l'exterieur)."""
    if _sym_actif() and _sym_nb() > 1:
        _sym_placer(_sym_cible())


def _sym_apres_glisser():
    """Poignee lachee : l'entraxe suit la traverse principale (une seule piece : elle revient sur l'axe)."""
    if not _sym_actif():
        return
    nb = _sym_nb()
    if nb == 1:
        return
    x0, _g = _sym_coord(_ctx, _ctx['S'])
    _s['sym_e'] = max(0.1, round(2.0 * abs(x0) / (nb - 1) * 100.0) / 100.0)
    _sym_placer(_sym_cible())


def _sym_positions():
    """[(ecart, jeton arete, s)] des autres pieces (la principale exclue), memorisees ; manque = introuvables."""
    c = _ctx
    nb = max(1, int(_s.get('sym_nb') or 1))
    e = float(_s.get('sym_e') or 0.0)
    nb = _sym_nb()
    sig = (c['ent'].entityToken, round(c['s'], 4), nb, round(e, 4), c.get('axe'), c.get('para'), bool(_s.get('sym2')),
           bool(_s.get('sens')),
           bool(_s.get('inv')))
    if sig == _sym['sig']:
        return _sym['pos'], _sym['manque']
    x0, g0 = _sym_coord(c, c['S'])
    aretes = _sym_aretes(c)
    pos, manque = [], 0
    for x, gr in _sym_cibles(c, nb, e, x0, g0):
        r = _sym_trouver(c, x, gr, aretes)
        if r is None:
            manque += 1
            continue
        pos.append((x, r[0].entityToken, r[1]))
    _sym.update(sig=sig, pos=pos, manque=manque)
    return pos, manque


def _sym_contexte(design, tok, sl, ignorer=None, fa=None):
    """Contexte d'une piece en symetrie : meme face d'appui que la principale (jeton fa)."""
    r = design.findEntityByToken(tok)
    if not r:
        return None
    inv = bool(_s.get('inv'))
    ck = _contexte(design, r[0], None, sl, bool(_s.get('sens')), inv, ignorer)
    try:
        fa = fa or _ctx['f_app'].entityToken
        if ck.get('ok') and ck['f_app'].entityToken != fa and len(ck.get('faces') or []) == 2:
            ck = _contexte(design, r[0], None, sl, bool(_s.get('sens')), not inv, ignorer)
    except Exception:
        pass
    return ck


_sym_bov = {}          # reglages des bouts propres a une piece en symetrie : {rang: [bout debut, bout fin]}
_corps = {'i': 0}      # corps personnalise par les fenetres : 0 = principal, i = i-eme piece en symetrie


def _corps_n():
    return 1 + (len(_sym['pieces']) if _sym_actif() else 0)


def _corps_i():
    i = _corps.get('i') or 0
    return i if 0 <= i < _corps_n() else 0


def _b_liste_sym(j, creer=False):
    """Bouts de la piece j en symetrie : ses reglages propres (crees au besoin, bouts effectifs figes)."""
    bs = _sym_bov.get(j)
    if bs is None:
        if not creer or j >= len(_sym['pieces']):
            return _s['b']
        cc = _sym['pieces'][j][1]
        bs = _sym_bov[j] = [dict(b) for b in _s['b']]
        for i2, eff in enumerate(cc.get('bouts') or []):
            if bs[i2]['type'] == 'auto':
                bs[i2]['type'], bs[i2]['tan'] = eff[0], eff[1]
    return bs


def _b_liste_sel(creer=False):
    i = _corps_i()
    return _s['b'] if i == 0 else _b_liste_sym(i - 1, creer)


def _calc_sel():
    i = _corps_i()
    if i == 0 or i - 1 >= len(_sym['pieces']):
        return _cur['calc'] or {}
    return _sym['pieces'][i - 1][1]


def _calc_pour(ck, j=None):
    """_calc() d'une autre piece (le contexte global est echange le temps du calcul) ; j : rang de la piece
    en symetrie, dont les bouts (courbes) peuvent avoir leurs propres reglages."""
    global _ctx
    old = _ctx
    ob = _s['b']
    _ctx = ck
    if j is not None and j in _sym_bov:
        _s['b'] = _sym_bov[j]
    try:
        return _calc()
    finally:
        _ctx = old
        _s['b'] = ob


def _sym_maj():
    """Pieces en symetrie (contexte, calc) pour l'apercu et la validation."""
    if not _sym_actif():
        _sym.update(pieces=[], manque=0, sig=None, hors=False, ctxs=[])
        _sym_bov.clear(); _corps['i'] = 0
        return
    try:
        pos, _m = _sym_positions()
        cle = tuple((tok, round(sl, 4)) for _x, tok, sl in pos)
        anciens = {k: ck for k, ck in _sym.get('ctxs', [])}
        ctxs = []
        design = _design()
        for (x, tok, sl), k in zip(pos, cle):
            ck = anciens.get(k)
            if ck is None:
                ck = _sym_contexte(design, tok, sl, _ignores())
            if ck is not None:
                ctxs.append((k, ck))
        _sym['ctxs'] = ctxs
        _sym['pieces'] = [(ck, _calc_pour(ck, j)) for j, ck in enumerate(ck for _k, ck in ctxs if ck.get('ok'))]
    except Exception:
        _log('symetrie : ' + traceback.format_exc()[-400:])
        _sym['pieces'] = []


def _sym_glisser():
    """Pendant le glisser de la poignee : les autres pieces suivent tout de suite (repere seul, sans detection ;
    leur profil d'avant est garde, les mesures sont refaites au lacher). Maxence 2026-11-11."""
    _sym['vue'] = None
    if not _sym_actif() or not _sym['pieces']:
        return
    try:
        c = _ctx
        nb = _sym_nb()
        x0, g0 = _sym_coord(c, c['S'])
        e = 2.0 * abs(x0) / (nb - 1) if nb > 1 else 0.0
        cibles = _sym_cibles(c, nb, e, x0, g0)
        if len(cibles) != len(_sym['pieces']):
            return
        aretes = _sym_aretes(c)
        vue = []
        for (x, gr), (ck, cc) in zip(cibles, _sym['pieces']):
            r = _sym_trouver(c, x, gr, aretes)
            if r is None or r[0].entityToken != ck['ent'].entityToken:
                vue.append((ck, cc))
                continue
            cm = dict(ck)
            if _repere(cm, r[1]):
                vue.append((cm, cc))
            else:
                vue.append((ck, cc))
        _sym['vue'] = vue
    except Exception:
        _log('symetrie glisser : ' + traceback.format_exc()[-300:])


def _sym_ok():
    if not _sym_actif():
        return True
    return not _sym.get('hors') and _sym.get('manque', 0) == 0 and all(cc.get('ok') for _ck, cc in _sym['pieces']) and \
        len(_sym['pieces']) == (_sym_nb() - 1) * (2 if _s.get('sym2') else 1) + (1 if _s.get('sym2') else 0)


def _contexte(design, ent, clic=None, s=None, sens=False, inv=False, ignorer=None):
    """Repere de la traverse sur l'arete (ou la courbe d'esquisse) au point clique, puis detections."""
    c = {'ok': False, 'raison': None}
    try:
        cv = _courbe(ent)
        if cv is None:
            c['raison'] = 'ARETE'
            return c
        ev, p0, p1, lg, kind = cv
        c.update(ent=ent, ev=ev, p0=p0, p1=p1, Ltot=lg, kind=kind, sens=bool(sens))
        if s is None:
            s = _s_du_point(c, clic) if clic is not None else lg / 2.0
        s = max(0.0, min(lg, s))
        P, t = _point_s(c, s)
        haut = _vers_haut()
        if kind == 'brep':
            fs = [ent.faces.item(i) for i in range(ent.faces.count)]
            if not fs:
                c['raison'] = 'ARETE'
                return c
            c['faces'] = fs
            c['corps'] = ent.body
            # face d'appui : la face LARGE (dessus ou dessous du corps, jamais le champ : Maxence 2026-11-12), puis celle
            # au-dessus de laquelle on voit un corps, sinon la plus horizontale
            try:
                aires = [f.area for f in fs]
            except Exception:
                aires = [1.0] * len(fs)
            amax = max(aires) if aires else 1.0
            score = []
            for k in range(len(fs)):
                large = 0 if aires[k] >= 0.95 * amax else 1
                n, u = _uv_brep(c, P, t, k)
                if n is None:
                    score.append((2, 1, 1, 0.0, 1e9))
                    continue
                tt = None
                for x in (0.5, 2.0, 5.0, 10.0, 25.0):        # le corps du dessus peut etre en retrait
                    o = _v_add(_v_add(P, _v_mul(n, 0.02)), _v_mul(u, x))
                    _f, tt = _premier(design, o, n, 500.0, ignorer)
                    if tt is not None:
                        break
                plane = 0 if isinstance(fs[k].geometry, adsk.core.Plane) else 1     # une face plane d'abord
                score.append((large, 0 if tt is not None else 1, plane, -_v_dot(n, haut), tt if tt is not None else 1e9))
            k = min(range(len(fs)), key=lambda i: score[i])
            if inv and len(fs) == 2 and aires[0] > 0.0 and abs(aires[0] - aires[1]) < 0.05 * amax:
                k = 1 - k               # l'inversion n'a de sens qu'entre deux faces larges (pas vers le champ)
            c['k'] = k
            c['f_app'] = fs[k]
        else:
            sk = adsk.fusion.SketchCurve.cast(ent).parentSketch
            o = sk.sketchToModelSpace(adsk.core.Point3D.create(0, 0, 0))
            z = sk.sketchToModelSpace(adsk.core.Point3D.create(0, 0, 1))
            nz = _v_norm((z.x - o.x, z.y - o.y, z.z - o.z))
            if _v_dot(nz, haut) < -1e-6:
                nz = _v_mul(nz, -1.0)
            if inv:
                nz = _v_mul(nz, -1.0)
            c['nz'] = nz
            c['sketch'] = sk
            c['corps'] = None
            # cote de la longueur : celui ou un corps est trouve (le plus proche)
            n = _perp(nz, t)
            u = _v_norm(_v_cross(t, n))
            o = _v_add(P, _v_mul(n, 0.1))
            _f, ta = _premier(design, o, u, 500.0, ignorer)
            _f, tb = _premier(design, o, _v_mul(u, -1.0), 500.0, ignorer)
            c['su'] = -1.0 if (tb is not None and (ta is None or tb < ta)) else 1.0
        if not _repere(c, s):
            c['raison'] = 'ARETE'
            return c
        c['ok'] = True
        _detecter(design, c, ignorer)
        return c
    except Exception:
        _log('contexte erreur ' + traceback.format_exc()[-500:])
        c['ok'] = False
        c['raison'] = 'ERREUR'
        return c


def _pt(c, x, y, z=0.0):
    """Point local (x en travers, y en hauteur, z dans l'epaisseur, centree) -> monde."""
    return _v_add(_v_add(_v_add(c['S'], _v_mul(c['u'], x)), _v_mul(c['n'], y)), _v_mul(c['w'], z))


def _detecter(design, c, ignorer=None):
    u, n = c['u'], c['n']
    # longueur : corps en face (1 mm au-dessus de l'appui) ou bout de la face d'appui (sortie du corps)
    # mesuree au milieu ET aux deux faces de la traverse (les deux bouts du chant, a +-ep/2) : la plus courte
    # gagne, pour qu'aucun coin ne depasse sur une forme courbe (demande de Maxence le 2026-11-11)
    L, fL = None, None
    ep = 0.0
    try:
        ep = max(0.0, float(_cur.get('ep') or 0.0))
    except Exception:
        pass
    zs = [0.0]
    if ep > 0.02:
        zs += [ep / 2.0 - 0.0002, -(ep / 2.0 - 0.0002)]
    Lz = []
    for z in zs:
        Lk, fk = None, None
        _f, t = _premier(design, _pt(c, 0.0, 0.1, z), u, 500.0, ignorer)
        if t is not None and t > 0.5:
            Lk, fk = t, _f
        if c.get('corps') is not None:
            tok = c['corps'].entityToken
            # sur une arete courbe, le coin du depart peut etre hors du corps d'appui : on part un peu plus loin
            x0 = 0.05
            if z != 0.0:
                x0 = None
                for xe in (0.05, 0.3, 1.0, 3.0):
                    if _dedans(c['corps'], _pt(c, xe, -0.05, z)):
                        x0 = xe
                        break
            if x0 is not None:
                for f, t in _rayon(design, _pt(c, x0, -0.05, z), u, ignorer):
                    try:
                        if f.body.entityToken == tok:
                            if t + x0 > 0.5 and (Lk is None or t + x0 < Lk):
                                Lk, fk = t + x0, f
                            break
                    except Exception:
                        pass
        if Lk is None and c.get('corps') is None:
            # courbe d'esquisse posee sur / dans un corps : rien au-dessus, on cherche la sortie du corps
            # juste sous l'esquisse (longueur AUTO au lieu de 100 mm ; Maxence 2026-11-13)
            for yy in (-0.05, -0.2, -0.5):
                _f, t = _premier(design, _pt(c, 0.0, yy, z), u, 500.0, ignorer)
                if t is not None and t > 0.5:
                    Lk, fk = t, _f
                    break
        Lz.append(Lk)
        if Lk is not None and (L is None or Lk < L - 1e-5):
            L, fL = Lk, fk
    if L is None and c.get('corps') is not None:
        # rien trouve par les rayons : etendue du corps d'appui dans le sens de la traverse (reste en AUTO,
        # au lieu des 100 mm par defaut ; Maxence 2026-11-13)
        try:
            bb = c['corps'].boundingBox
            S, uu = c['S'], c['u']
            pr = []
            for X in (bb.minPoint.x, bb.maxPoint.x):
                for Y in (bb.minPoint.y, bb.maxPoint.y):
                    for Z in (bb.minPoint.z, bb.maxPoint.z):
                        pr.append((X - S[0]) * uu[0] + (Y - S[1]) * uu[1] + (Z - S[2]) * uu[2])
            if pr and max(pr) > 0.5:
                L = max(pr)
                _log('longueur : rayons sans resultat, etendue du corps %.1f mm' % (L * 10.0))
        except Exception:
            _log('longueur etendue : ' + traceback.format_exc()[-200:])
    c['L_centre'] = Lz[0]
    if len(Lz) > 1 and L is not None and Lz[0] is not None and Lz[0] - L > 0.001:
        _log('longueur aux coins : centre %.2f mm, coins %s mm' % (
            Lz[0] * 10.0, ', '.join('-' if v is None else '%.2f' % (v * 10.0) for v in Lz[1:])))
    c['L_det'] = L
    c['f_L'] = fL                    # face qui arrete la longueur : le bout de l'esquisse y est accroche
    Lm = L if L is not None else L_DEFAUT
    c['Lmax'] = Lm
    # hauteur : corps du dessus (rayon au milieu, puis vers les bouts)
    H, haut, fH = None, None, None
    for fx in (0.5, 0.25, 0.75, 0.1, 0.9):
        f, t = _premier(design, _pt(c, Lm * fx, 0.02), n, 300.0, ignorer)
        if t is not None and t > 0.3:
            H, haut, fH = t + 0.02, f.body, f
            break
    c['H_det'] = H
    c['f_H'] = fH                    # face du dessous du corps du dessus : le haut de l'esquisse y est accroche
    c['haut'] = haut
    # etendue du corps du dessus en travers (pour les arcs automatiques)
    c['ua'] = c['ub'] = None
    if haut is not None:
        y = H + 0.05
        tok = haut.entityToken
        try:
            # rayons partis un peu avant chaque bout (un depart pile sur une face du corps ne compte pas)
            m0 = 0.5
            if _dedans(haut, _pt(c, -m0, y)):
                ua = 0.0
            else:
                ua = None
                for f, t in _rayon(design, _pt(c, -m0, y), u, ignorer):
                    if f.body.entityToken == tok:
                        ua = max(0.0, t - m0)
                        break
            fin = _pt(c, Lm + m0, y)
            if _dedans(haut, fin):
                ub = Lm
            else:
                ub = None
                for f, t in _rayon(design, fin, _v_mul(u, -1.0), ignorer):
                    if f.body.entityToken == tok:
                        ub = min(Lm, Lm + m0 - t)
                        break
            c['ua'], c['ub'] = ua, ub
        except Exception:
            _log('etendue erreur ' + traceback.format_exc()[-300:])


# --- Mesures ------------------------------------------------------------------------------------------------

def _eval_expr(expr, defaut=None):
    """Valeur (cm) d'une expression ('800 mm', 'CP18*2', 'LONG1') ; None si invalide."""
    if not expr:
        return defaut
    try:
        um = _design().unitsManager
        if um.isValidExpression(expr, 'mm'):
            return um.evaluateExpression(expr, 'mm')
    except Exception:
        pass
    return defaut


def _mm_txt(cm):
    v = round(cm * 10.0, 2)
    s = ('%.2f' % v).rstrip('0').rstrip('.')
    return s + ' mm'


def _est_param(expr):
    """Expression qui utilise un parametre (pas un simple nombre en mm)."""
    if not expr:
        return False
    e = expr.replace('mm', '').replace(' ', '').replace(',', '.')
    try:
        float(e)
        return False
    except Exception:
        return True


def _longueur():
    """(L en cm, par_defaut) ; le reglage + / - du clavier (L_delta) s'ajoute a la mesure."""
    L, defaut = _longueur_base()
    d = _s.get('L_delta') or 0.0
    if L is not None and d:
        L = max(0.1, L + d)
    return L, defaut


def _longueur_base():
    if not _ctx.get('ok'):
        return None, False
    if _s['L_auto'] or not _s['L_expr']:
        if _ctx.get('L_det') is not None:
            return _ctx['L_det'], False
        return L_DEFAUT, not _s.get('L_saisie')
    return _eval_expr(_s['L_expr'], L_DEFAUT), False


def _delta_txt():
    d = _s.get('L_delta') or 0.0
    if abs(d) < 1e-6:
        return ''
    return ('+' if d > 0 else '-') + _mm_txt(abs(d)).upper()


def _hauteur():
    """(H en cm, par_defaut)"""
    if not _ctx.get('ok'):
        return None, False
    if _s['H_auto'] or not _s['H_expr']:
        if _ctx.get('H_det') is not None:
            return _ctx['H_det'], False
        return H_DEFAUT, not _s.get('H_saisie')
    return _eval_expr(_s['H_expr'], H_DEFAUT), False


def _etendue_fin(c, L):
    """Fin (cm, en travers) du corps du dessus vue depuis le bout L de la traverse (rayon parti de L + 5 mm
    vers le debut) ; memorisee par longueur."""
    cache = c.setdefault('ub_cache', {})
    cle = round(L, 3)
    if cle in cache:
        return cache[cle]
    ub = None
    haut, H = c.get('haut'), c.get('H_det')
    if haut is not None and H is not None:
        try:
            y, m0 = H + 0.05, 0.5
            fin = _pt(c, L + m0, y)
            if _dedans(haut, fin):
                ub = L
            else:
                tok = haut.entityToken
                for f, t in _rayon(_design(), fin, _v_mul(c['u'], -1.0), _ignores()):
                    if f.body.entityToken == tok:
                        ub = min(L, L + m0 - t)
                        break
        except Exception:
            _log('etendue fin : ' + traceback.format_exc()[-300:])
    cache[cle] = ub
    return ub


def _retrait_auto(i, L):
    """Retrait du corps du dessus au bout i (cm) ou None."""
    if _ctx.get('haut') is None:
        return None
    if i == 0:
        ua = _ctx.get('ua')
        return ua if ua is not None and ua > 0.1 else None
    ub = _ctx.get('ub') if abs(L - (_ctx.get('Lmax') or 0.0)) < 1e-4 else _etendue_fin(_ctx, L)
    if ub is None:
        return None
    d = L - ub
    return d if d > 0.1 else None


def _depasse(i, L):
    """Debord (cm) du corps du dessus au-dela du bout i de la traverse (le dessus plus long que la base), ou None.
    Mesure juste sous le corps du dessus : rayon parti 0,5 mm apres le bout, vers l'exterieur, jusqu'a sa sortie."""
    c = _ctx
    haut, H = c.get('haut'), c.get('H_det')
    if haut is None or H is None:
        return None
    cache = c.setdefault('dep_cache', {})
    cle = (i, round(L, 3))
    if cle in cache:
        return cache[cle]
    res = None
    try:
        y, m0 = H + 0.05, 0.05
        x = -m0 if i == 0 else L + m0
        dv = _v_mul(c['u'], -1.0) if i == 0 else c['u']
        p = _pt(c, x, y)
        if _dedans(haut, p):
            tok = haut.entityToken
            for f, t in _rayon(_design(), p, dv, _ignores()):
                if f.body.entityToken == tok:
                    res = t + m0
                    break
        if res is not None and res < 0.1:
            res = None
    except Exception:
        _log('debord : ' + traceback.format_exc()[-200:])
    cache[cle] = res
    return res


def _bouts(L, H):
    """[(typ, tan, d, auto_detecte)] effectifs des deux bouts."""
    res = []
    dep = _ctx.get('depasse') or (None, None)
    for i in (0, 1):
        b = _b_eff(i, _s['b'])
        typ, tan = b['type'], b['tan']
        if i == 1 and typ == 'auto' and _s['b'][1].get('type') == 'auto':
            # FIN (bout oppose a l'arete cliquee) en AUTO : bout droit vertical, quel que soit le corps du dessus
            # (Maxence 2026-11-14) ; en MIROIR elle suit le debut
            res.append(_Bout(('droite', tan, 0.0, False)))
            continue
        if dep[i] and typ == 'conge' and not b.get('auto'):
            # conge regle a la main sous un dessus qui deborde : le cote reste sur le bord du corps du dessus, la
            # largeur deplace le debut de la courbe sur le dessous, prolonge en ligne droite (colineaire) au-dela
            # du bord de la base (Maxence 2026-11-17)
            bt = _Bout(('conge', 'dessus', _eval_expr(b['expr'], dep[i]) or dep[i], False))
            bt.h = _eval_expr(_b_hexpr(b), 3.0) or 0.0
            res.append(bt)
            continue
        if dep[i] and (typ == 'auto' or (typ != 'droite' and b.get('auto'))):
            # dessus plus long que la base a ce bout : le haut reste sur le bord du corps du dessus, la courbe
            # descend jusqu'au bord de la base (AUTO = angle droit ; arc / conge choisis : vers le bas, Maxence
            # 2026-11-14)
            t = 'angle' if typ == 'auto' else typ
            bt = _Bout((t, 'dessus', dep[i], True))
            if t == 'conge':
                bt.h = _eval_expr(_b_hexpr(b), 3.0) or 0.0
            res.append(bt)
            continue
        da = _retrait_auto(i, L)
        if typ == 'auto':
            # AUTO : aretes droites (Maxence 2026-11-14) ; dessus en retrait -> angle droit du bord de la base au
            # bord du corps du dessus ; arcs et conges seulement si on les choisit
            if da is not None:
                typ, tan = 'angle', 'dessous'
            else:
                typ = 'droite'
        d = 0.0
        det = False
        if typ != 'droite':
            if b['auto'] and da is not None and tan == 'dessous':
                d, det = da, True
            else:
                d = _eval_expr(b['expr'], 3.0) or 0.0
        t = _Bout((typ, tan, d, det))
        if typ == 'conge':
            t.h = _eval_expr(_b_hexpr(b), 3.0) or 0.0
        res.append(t)
    return res


# --- Profil 2D ----------------------------------------------------------------------------------------------

def _bout_geo(typ, tan, d, H, h=None):
    """Bout de DEBUT, repere local (x le long, y en hauteur) : (x bas, x haut, courbe du bas vers le haut, arc)."""
    if typ == 'droite' or d <= 1e-6:
        return 0.0, 0.0, [(0.0, 0.0), (0.0, H)], None
    if typ == 'conge':
        h = min(H, max(0.0, h or 0.0))
        nn = 24
        if tan == 'dessous':
            # coin du haut arrondi : du cote (0, H - h) au dessus (d, H), centre (d, H - h)
            el = [(d - d * math.cos(math.pi / 2 * k / nn), H - h + h * math.sin(math.pi / 2 * k / nn))
                  for k in range(nn + 1)]
            pts = ([(0.0, 0.0)] if h < H - 1e-6 else []) + el
            return 0.0, d, pts, None
        # coin du bas arrondi : du dessous (d, 0) au cote (0, h), centre (d, h)
        el = [(d - d * math.sin(math.pi / 2 * k / nn), h - h * math.cos(math.pi / 2 * k / nn)) for k in range(nn + 1)]
        pts = el + ([(0.0, H)] if h < H - 1e-6 else [])
        return d, 0.0, pts, None
    if tan == 'dessous':
        A, B, xb, xh = (0.0, 0.0), (d, H), 0.0, d
    else:
        A, B, xb, xh = (d, 0.0), (0.0, H), d, 0.0
    if typ == 'angle':
        return xb, xh, [A, B], None
    r = (d * d + H * H) / (2.0 * d)
    C = (r, 0.0) if tan == 'dessous' else (r, H)
    a0 = math.atan2(A[1] - C[1], A[0] - C[0])
    a1 = math.atan2(B[1] - C[1], B[0] - C[0])
    da = a1 - a0
    while da > math.pi:
        da -= 2 * math.pi
    while da < -math.pi:
        da += 2 * math.pi
    nn = 24
    pts = [(C[0] + r * math.cos(a0 + da * k / nn), C[1] + r * math.sin(a0 + da * k / nn)) for k in range(nn + 1)]
    return xb, xh, pts, (A, B, C, r)


def _profil(L, H, bouts):
    """(contour ferme [(x, y)], ok, raison, info)."""
    if L is None or H is None or L <= 0.05 or H <= 0.05:
        return None, False, 'DIM', None
    g = []
    for bt in bouts:
        typ, tan, d, _det = bt
        hc = getattr(bt, 'h', None)
        if typ != 'droite' and d <= 1e-6:
            typ = 'droite'
        if typ == 'arc' and d > H + 1e-6:
            return None, False, 'ARC', None
        if typ == 'conge' and (hc is None or hc <= 1e-6 or hc > H + 1e-6):
            return None, False, 'CONGE', None
        g.append(_bout_geo(typ, tan, d, H, hc))
    xb0, xh0, c0, _a = g[0]
    xb1, xh1, c1, _a = g[1]
    if xb0 + xb1 >= L - 0.05 or xh0 + xh1 >= L - 0.05:
        return None, False, 'RETRAIT', None
    fin = [(L - x, y) for (x, y) in c1]
    contour = list(c0[::-1]) + fin + [c0[-1]]
    return contour, True, None, {'haut': (xh0, L - xh1), 'bas': (xb0, L - xb1)}


def _centrer(s):
    """Placement des tenons : 'centre' = repartis avec des ecarts egaux, centres sur le chant ;
    'bord' = depuis la distance du bord (premier et dernier tenon a cette distance des bouts)."""
    return s.get('tn_place', 'centre') != 'bord'


def _tenons_1d(lg, s):
    """Segments [(debut, largeur)] (cm) des tenons sur un chant de longueur lg : moteur de Tenons CNC.
    None si ils ne tiennent pas (ou se chevauchent)."""
    tm = _module('TenonCNC')
    try:
        if tm is not None and hasattr(tm, 'compute_tenon_layout_1d'):
            r = tm.compute_tenon_layout_1d(lg, 'tenon', int(s['tn_nb']), s['tn_len'] / 10.0, s['tn_h'] / 10.0,
                                           0.0, 0.0, s['tn_bord'] / 10.0, _centrer(s), 'uniforme', 33.3)
            if not r.get('ok'):
                return None
            seg = [(sg['start'], sg['width']) for sg in r['segments']]
            for k in range(len(seg) - 1):
                if seg[k][0] + seg[k][1] > seg[k + 1][0] + 1e-6:
                    return None          # depuis le bord, chant trop court : les tenons se chevaucheraient
            return seg
    except Exception:
        _log('tenons 1d ' + traceback.format_exc()[-300:])
    # repli : repartition uniforme depuis la distance du bord
    n, tl, e = int(s['tn_nb']), s['tn_len'] / 10.0, s['tn_bord'] / 10.0
    if lg <= 2 * e + tl:
        return None
    a, b = e + tl / 2.0, lg - e - tl / 2.0
    cs = [a + (b - a) * k / (n - 1) for k in range(n)] if n > 1 else [lg / 2.0]
    return [(x - tl / 2.0, tl) for x in cs]


def _epaisseur_voisin(c, cote, x):
    """Epaisseur (cm) du corps du dessus (cote 'dessus') ou du corps d'appui ('dessous') a l'abscisse x de la
    traverse, mesuree le long de la normale ; None si rien. Memorisee dans le contexte."""
    cache = c.setdefault('ep_voisins', {})
    cle = (cote, round(x, 2), round(c.get('H_det') or 0.0, 3), round(c.get('s') or 0.0, 4))
    if cle in cache:
        return cache[cle]
    res = None
    try:
        if cote == 'dessus':
            body, H = c.get('haut'), c.get('H_det')
            o, dv = (_pt(c, x, H - 0.05) if (body is not None and H) else None), c['n']
        else:
            body = c.get('corps')
            o, dv = _pt(c, x, 0.05), _v_mul(c['n'], -1.0)
        if body is not None and o is not None:
            tok = body.entityToken
            ts = [t for f, t in _rayon(_design(), o, dv, _ignores()) if f.body.entityToken == tok]
            if len(ts) >= 2 and ts[1] - ts[0] > 0.05:
                res = ts[1] - ts[0]
    except Exception:
        _log('epaisseur voisin : ' + traceback.format_exc()[-200:])
    cache[cle] = res
    return res


def _tn_hauteur(cote, x=None):
    """Hauteur des tenons d'un cote : l'epaisseur du corps du dessus / du dessous (traversant, Maxence
    2026-11-11), sinon la hauteur saisie."""
    if _s.get('tn_h_auto', True) and cote in ('dessus', 'dessous') and _ctx.get('ok') and x is not None:
        e = _epaisseur_voisin(_ctx, cote, x)
        if e is not None:
            return round(e * 1000.0) / 1000.0
    return _s['tn_h'] / 10.0


def _calc():
    """Etat calcule de la traverse : dimensions, profil, tenons, validite."""
    c = {'ok': False, 'msg': ''}
    if not _ctx.get('ok'):
        c['msg'] = _tt('Cliquez l\'arete exterieure d\'un corps.') if _ctx.get('raison') is None else \
            _tt('Arete non prise en charge : choisissez une arete de corps ou une courbe d\'esquisse.')
        return c
    e = _piece()
    if e is not None:
        return _calc_piece(e)
    L, dL = _longueur()
    H, dH = _hauteur()
    a0 = 0.0
    if _dist_lie_longueur(_ctx):
        # mode DISTANCE : debut et fin sur le contour de la base, la face la plus a l'interieur a chaque bout
        # (comme la piece creee : aucun coin dehors)
        try:
            bo = _dist_bornes(_ctx, L)
            if bo is not None and bo[1] - bo[0] > 0.5:
                # un autre corps arrete la traverse avant le bord de la base : la fin reste sur ce corps
                fin_base = L is None or L >= bo[1] - 0.05
                fin = bo[1] if fin_base else L
                a0, L, dL = bo[0], fin - bo[0], False
                c['dist_fin_base'] = fin_base
        except Exception:
            _log('bornes distance : ' + traceback.format_exc()[-200:])
    _ctx['depasse'] = None
    if not a0 and L and _s.get('L_auto') and not _s.get('piece'):
        # bouts AUTO : le corps du dessus deborde de la base -> la traverse s'allonge jusqu'a son bord (angle)
        try:
            o = [None, None]
            for i in (0, 1):
                be = _b_eff(i, _s['b'])
                if i == 1 and _s['b'][1].get('type') == 'auto':
                    continue                     # FIN en AUTO : bout droit (pas de debord)
                if be.get('type') in ('auto', 'conge') or (be.get('type') != 'droite' and be.get('auto')):
                    # conge : la traverse reste allongee jusqu'au corps du dessus meme quand sa largeur est
                    # reglee (poignee du bas ou mesure tapee ; Maxence 2026-11-17)
                    o[i] = _depasse(i, L)
            if o[0] or o[1]:
                _ctx['depasse'] = tuple(o)
                a0 = -(o[0] or 0.0)
                L = L + (o[0] or 0.0) + (o[1] or 0.0)
        except Exception:
            _log('debord auto : ' + traceback.format_exc()[-200:])
    c['a0'] = a0
    defaut = dL or dH
    bouts = _bouts(L or 0.0, H or 0.0)
    prof, ok, raison, info = _profil(L, H, bouts)
    if not ok and L and H and L > 0.05 and H > 0.05:
        prof = [(0.0, 0.0), (L, 0.0), (L, H), (0.0, H), (0.0, 0.0)]          # enveloppe en rouge
    c.update(L=L, H=H, defaut=defaut, defaut_L=dL, defaut_H=dH, bouts=bouts, prof=prof, info=info, raison=raison)
    tns = []
    if ok:
        hi, bi = info['haut'], info['bas']
        manque = []
        c['tn_hauteurs'] = {}

        def poser(nom, lg, x0):
            th = _tn_hauteur(nom, x0 + lg / 2.0)
            c['tn_hauteurs'][nom] = th
            seg = _tenons_1d(lg, _s)
            if seg is None:
                manque.append(nom)
            for a, wd in (seg or []):
                tns.append((nom, x0 + a, wd, th))
        if _s['tn_dessus']:
            poser('dessus', hi[1] - hi[0], hi[0])
        if _s['tn_dessous']:
            poser('dessous', bi[1] - bi[0], bi[0])
        if _s['tn_cotes']:
            for i in (0, 1):
                if bouts[i][0] == 'droite' or bouts[i][2] <= 1e-6:
                    poser('cote%d' % i, H, 0.0)
        c['tn_manque'] = manque
    c['tenons'] = tns
    c['ok'] = ok and not defaut
    if not ok:
        c['msg'] = {'ARC': _tt('Arc impossible : le retrait depasse la hauteur.'),
                    'CONGE': _tt('Conge impossible : sa hauteur doit etre entre 0 et la hauteur de la traverse.'),
                    'RETRAIT': _tt('Retraits trop grands pour la longueur.'),
                    'DIM': _tt('Longueur ou hauteur nulle.')}.get(raison, '')
    else:
        txt = _tt('Longueur {0} - hauteur {1}').replace('{0}', _mm_txt(L)).replace('{1}', _mm_txt(H))
        if dH:
            txt += ' ' + _tt('(aucun corps au-dessus : hauteur par defaut, saisissez une mesure)')
        if dL:
            txt += ' ' + _tt('(rien detecte en travers : longueur par defaut, saisissez une mesure)')
        if c.get('tn_manque'):
            txt += ' ' + _tt('(tenons qui ne tiennent pas : moins de tenons, plus courts ou distance du bord plus petite)')
        c['msg'] = txt
    return c


# --- Apercu (CustomGraphics orange, rouge si invalide) --------------------------------------------------------

def _lignes(c, calc):
    """Coordonnees a plat de segments (paires de points) : profil sur les deux faces + aretes de liaison + tenons."""
    pts = []
    prof = calc.get('prof')
    if not prof:
        return pts
    ep = _cur['ep']
    z0, z1 = (0.0, ep) if c.get('kind') == 'nc' else (-ep / 2.0, ep / 2.0)
    if calc.get('piece') and c.get('kind') != 'nc':
        # piece de la bibliotheque : face avant sur le point clique, epaisseur du cote ou _poser_piece la pose
        sg = calc.get('w_h', 1.0) * (1.0 if _v_dot(c['w'], _v_cross(c['u'], c['n'])) >= 0.0 else -1.0)
        z0, z1 = (0.0, ep) if sg > 0 else (-ep, 0.0)
    a0 = calc.get('a0') or 0.0                    # mode DISTANCE : debut decale sur le contour de la base

    def _pt_(cc, x, y, z):
        return _pt(cc, x + a0, y, z)
    for z in (z0, z1):
        for k in range(len(prof) - 1):
            pts.extend(_pt_(c, prof[k][0], prof[k][1], z))
            pts.extend(_pt_(c, prof[k + 1][0], prof[k + 1][1], z))
    # liaisons aux coins (points ou la direction change franchement)
    for k in range(len(prof) - 1):
        a = prof[k - 1] if k > 0 else prof[-2]
        b, cc = prof[k], prof[k + 1]
        v1 = (b[0] - a[0], b[1] - a[1])
        v2 = (cc[0] - b[0], cc[1] - b[1])
        n1, n2 = math.hypot(*v1), math.hypot(*v2)
        if n1 < 1e-9 or n2 < 1e-9:
            continue
        if (v1[0] * v2[0] + v1[1] * v2[1]) / (n1 * n2) < 0.985:
            pts.extend(_pt_(c, b[0], b[1], z0))
            pts.extend(_pt_(c, b[0], b[1], z1))
    H = calc['H']
    L = calc['L']
    for cote, a, wd, th in calc.get('tenons', []):
        if cote == 'dessus':
            r = [(a, H), (a, H + th), (a + wd, H + th), (a + wd, H)]
        elif cote == 'dessous':
            r = [(a, 0.0), (a, -th), (a + wd, -th), (a + wd, 0.0)]
        elif cote == 'cote0':
            r = [(0.0, a), (-th, a), (-th, a + wd), (0.0, a + wd)]
        else:
            r = [(L, a), (L + th, a), (L + th, a + wd), (L, a + wd)]
        for z in (z0, z1):
            for k in range(3):
                pts.extend(_pt_(c, r[k][0], r[k][1], z))
                pts.extend(_pt_(c, r[k + 1][0], r[k + 1][1], z))
        for k in (1, 2):
            pts.extend(_pt_(c, r[k][0], r[k][1], z0))
            pts.extend(_pt_(c, r[k][0], r[k][1], z1))
    return pts


def _balayer(ident):
    try:
        design = _design()
        # tous les composants : le composant actif a pu changer (Modifier recule la chronologie, Maxence 2026-11-11)
        for comp in design.allComponents:
            gs = comp.customGraphicsGroups
            for i in range(gs.count - 1, -1, -1):
                try:
                    g = gs.item(i)
                    if g.id == ident:
                        g.deleteMe()
                except Exception:
                    pass
    except Exception:
        pass


ID_AXES = 'TraverseCorpsCNC_axes'
_axes_g = {'g': None, 'sig': None}


def _axes_segments():
    """[(nom, A, B)] des axes a montrer (case « Axes de la forme » ou axe choisi), sinon []."""
    c = _ctx
    if not c.get('ok') or c.get('kind') != 'brep' or not (_s.get('axes') or _s.get('axe')):
        return []
    ax = _axes_forme(c)
    if ax is None:
        return []
    out = []
    for nom in ('long', 'larg'):
        d, t0, t1 = ax[nom]
        m = 0.08 * (t1 - t0) + 0.5
        # un peu au-dessus de la face (sinon cache par elle)
        o = _v_add(ax['o'], _v_mul(c['n'] if _v_dot(c['n'], ax['n']) > 0 else ax['n'], 0.05))
        out.append((nom, _v_add(o, _v_mul(d, t0 - m)), _v_add(o, _v_mul(d, t1 + m))))
    return out


def _axes_effacer():
    g = _axes_g['g']
    _axes_g['g'] = None
    _axes_g['sig'] = None
    try:
        if g is not None and g.isValid:
            g.deleteMe()
    except Exception:
        pass
    _balayer(ID_AXES)


def _axes_maj():
    try:
        segs = _axes_segments()
        sig = (tuple((n, tuple(round(v, 4) for v in a + b)) for n, a, b in segs), _s.get('axe'), _s.get('sym2'),
               _design().activeComponent.entityToken)
        if sig == _axes_g['sig'] and _axes_g['g'] is not None and _axes_g['g'].isValid:
            return
        _axes_effacer()
        if not segs:
            return
        comp, conv = _hote_cg()
        g = comp.customGraphicsGroups.add()
        g.id = ID_AXES
        for nom, a, b in segs:
            choisi = _s.get('axe') == nom or bool(_s.get('axe') and _s.get('sym2'))
            ln = g.addLines(adsk.fusion.CustomGraphicsCoordinates.create(conv(list(a) + list(b))), [], False)
            ln.weight = 3 if choisi else 1.5
            ln.isLineStrip = False
            try:
                ln.lineStylePattern = adsk.fusion.LineStylePatterns.centerLineStylePattern
                ln.lineStyleScale = 2.0
            except Exception:
                pass
            col = (255, 140, 0, 255) if choisi else ((40, 120, 215, 255) if nom == 'long' else (30, 160, 90, 255))
            ln.color = adsk.fusion.CustomGraphicsSolidColorEffect.create(adsk.core.Color.create(*col))
            ln.isSelectable = False
            try:
                ln.depthPriority = 1
            except Exception:
                pass
        _axes_g['g'] = g
        _axes_g['sig'] = sig
    except Exception:
        _log('axes dessin : ' + traceback.format_exc()[-300:])


def _axe_touche(vp, pos):
    """Nom de l'axe sous la souris (8 px), sinon None."""
    P = adsk.core.Point3D.create
    best = None
    for nom, a, b in _axes_segments():
        A, B = vp.modelToViewSpace(P(*a)), vp.modelToViewSpace(P(*b))
        ex, ey = B.x - A.x, B.y - A.y
        e2 = ex * ex + ey * ey
        tt = 0.0 if e2 < 1e-9 else max(0.0, min(1.0, ((pos.x - A.x) * ex + (pos.y - A.y) * ey) / e2))
        dd = math.hypot(A.x + ex * tt - pos.x, A.y + ey * tt - pos.y)
        if dd <= 8.0 * _dpr() and (best is None or dd < best[0]):
            best = (dd, nom)
    return best[1] if best else None


def _hote_cg():
    """(composant actif, fonction monde -> composant) : les graphismes poses dans un autre composant que le
    composant actif sont estompes par Fusion (couleurs ternes signalees par Maxence le 2026-11-11)."""
    des = _design()
    occ = des.activeOccurrence
    if occ is None:
        return des.rootComponent, (lambda pts: list(pts))
    inv = occ.transform2.copy()
    inv.invert()

    def conv(pts):
        out = []
        for i in range(0, len(pts), 3):
            q = adsk.core.Point3D.create(pts[i], pts[i + 1], pts[i + 2])
            q.transformBy(inv)
            out += [q.x, q.y, q.z]
        return out
    return des.activeComponent, conv


def _apercu_effacer():
    for g in _apercu['g']:
        try:
            if g.isValid:
                g.deleteMe()
        except Exception:
            pass
    _apercu['g'] = []
    _apercu['sig'] = None
    _balayer(ID_APERCU)
    _axes_effacer()


def _apercu_maj(force=False):
    """Groupe recree quand la forme change ; le nouveau avant la suppression de l'ancien (jamais d'image vide)."""
    _axes_maj()
    try:
        calc = _cur['calc']
        if calc is None or not _ctx.get('ok') or not calc.get('prof'):
            _apercu_effacer()
            return
        pts = _lignes(_ctx, calc)
        col = ORANGE if (calc.get('raison') is None and not calc.get('defaut')) else ROUGE
        hi = []
        if _sym_actif():
            vue = _sym['pieces'] if _drag.get('k') is None else (_sym.get('vue') or _sym['pieces'])
            isel = _corps_i()
            parts = [pts]
            for ck, cc in vue:
                parts.append(_lignes(ck, cc) if cc.get('prof') else [])
            if not _sym_ok():
                col = ROUGE
            if len(parts) > 1 and col == ORANGE and isel < len(parts):
                hi = parts[isel]                  # corps choisi : surbrillance
                pts = [v for q, pp in enumerate(parts) if q != isel for v in pp]
            else:
                pts = [v for pp in parts for v in pp]
        try:
            dl = _dist_lignes(_ctx, calc)
        except Exception:
            dl = []
            _log('apercu distance : ' + traceback.format_exc()[-200:])
        try:
            sv = _survol_lignes() if _drag.get('k') is None else []
        except Exception:
            sv = []
        sig = (tuple(round(v, 4) for v in pts), col, tuple(round(v, 4) for v in hi),
               _design().activeComponent.entityToken, tuple(round(v, 4) for v in dl), tuple(round(v, 4) for v in sv))
        ok = _apercu['sig'] == sig and not force
        if ok:
            try:
                ok = all(g.isValid for g in _apercu['g'])
            except Exception:
                ok = False
        if ok:
            return
        nouveaux = []
        if pts:
            comp, conv = _hote_cg()
            g = comp.customGraphicsGroups.add()
            g.id = ID_APERCU
            ln = g.addLines(adsk.fusion.CustomGraphicsCoordinates.create(conv(pts)), [], False)
            ln.weight = 2
            ln.color = adsk.fusion.CustomGraphicsSolidColorEffect.create(adsk.core.Color.create(*col))
            ln.isSelectable = False
            if hi:
                l2 = g.addLines(adsk.fusion.CustomGraphicsCoordinates.create(conv(hi)), [], False)
                l2.weight = 4
                l2.color = adsk.fusion.CustomGraphicsSolidColorEffect.create(adsk.core.Color.create(255, 215, 40, 255))
                l2.isSelectable = False
            if sv:                                # bout survole : jaune, plus epais (clic = forme suivante)
                l4 = g.addLines(adsk.fusion.CustomGraphicsCoordinates.create(conv(sv)), [], False)
                l4.weight = 5
                l4.color = adsk.fusion.CustomGraphicsSolidColorEffect.create(adsk.core.Color.create(*JAUNE_SURVOL))
                l4.isSelectable = False
            if dl:                                # mode DISTANCE : appui, cote et point extreme
                l3 = g.addLines(adsk.fusion.CustomGraphicsCoordinates.create(conv(dl)), [], False)
                l3.weight = 4
                cd = ROUGE if _ctx.get('dist_hors') else ORANGE
                l3.color = adsk.fusion.CustomGraphicsSolidColorEffect.create(adsk.core.Color.create(*cd))
                l3.isSelectable = False
            nouveaux.append(g)
        anciens = _apercu['g']
        _apercu['g'] = nouveaux
        _apercu['sig'] = sig
        for g in anciens:
            try:
                if g.isValid:
                    g.deleteMe()
            except Exception:
                pass
    except Exception:
        _log('apercu erreur ' + traceback.format_exc()[-400:])


def _rafraichir_vue():
    try:
        _app.activeViewport.refresh()
    except Exception:
        pass


# --- Fenetres en bas a gauche ----------------------------------------------------------------------------------

_GLYPHES = {
    'C': '111100100100111', 'H': '101101111101101', 'E': '111100111100111', 'M': '101111111101101',
    'T': '111010010010010', 'O': '111101101101111', 'U': '101101101101111',
    'S': '111100111001111', 'I': '111010010010111', 'N': '111101101101101', ' ': '000000000000000',
    '0': '111101101101111', '1': '010110010010111', '2': '111001111100111', '3': '111001111001111',
    '4': '101101111001001', '5': '111100111001111', '6': '111100111101111', '7': '111001001001001',
    '8': '111101111101111', '9': '111101111001111',
    'A': '010101111101101', 'B': '110101110101110', 'D': '110101101101110', 'F': '111100110100100',
    'G': '011100101101011', 'J': '001001001101010', 'K': '101101110101101', 'L': '100100100100111',
    'P': '110101110100100', 'Q': '010101101111011', 'R': '110101110101101', 'V': '101101101101010',
    'W': '101101111111101', 'X': '101101010101101', 'Y': '101101010010010', 'Z': '111001010100111',
    "'": '010010000000000', '.': '000000000000010', ',': '000000000010100', '-': '000000111000000',
    ':': '000010000010000', '%': '101001010100101', '/': '001001010100100', '_': '000000000000111',
    '*': '000101010101000', '+': '000010111010000', '(': '010100100100010', ')': '010001001001010',
    '=': '000111000111000', '<': '001010100010001', '>': '100010001010100'}

OV_W, OV_H = 524, 28
OV_GAP = 6
OV_X, OV_Y = 16, 60
OV_T0, OV_T1 = 96, 176          # bouton type (DEBUT / FIN)
OV_G0, OV_G1 = 182, 262         # bouton tangent
OV_V0 = 274                     # valeur
OV_S0 = 392                     # etat (AUTO, PAR DEFAUT...)
ROWS = ('NM', 'N', 'L', 'H', 'D0', 'D1', 'T', 'M')     # POSITION retiree, TENONS ajoutee (Maxence 2026-11-11),
                                                # DISTANCE a l'extremite de la base (M, 2026-11-13), NOM de la piece
                                                # tout en haut (NM, 2026-11-14 : pour « Enregistrer comme piece »)
# ligne TENONS : interrupteurs dessus / dessous / cotes, nombre - n +, placement centre / bord
TN_ZONES = (('tn_dessus', 96, 160, 'DESSUS'), ('tn_dessous', 166, 238, 'DESSOUS'), ('tn_cotes', 244, 300, 'COTES'),
            ('tn_moins', 310, 334, '-'), ('tn_plus', 366, 390, '+'), ('tn_place', 400, 516, None))
NOMS_ROWS = {'T': 'TENONS', 'N': 'TRAVERSES', 'P': 'POSITION', 'L': 'LONGUEUR', 'H': 'HAUTEUR', 'D0': 'DEBUT', 'D1': 'FIN',
             'M': 'DISTANCE', 'NM': 'NOM'}
OV_M0, OV_M1 = 96, 128          # bouton - (ligne TRAVERSES)
OV_N0 = 134                     # nombre
OV_P0, OV_P1 = 166, 198         # bouton +
OV_O0, OV_O1 = 206, 270         # bouton parallele a l'axe / perpendiculaire au chemin
ROW_P = 2                       # fenetre active par defaut (LONGUEUR)
NOMS_TYPES = {'auto': 'AUTO', 'droite': 'DROITE', 'arc': 'ARC', 'angle': 'ANGLE', 'conge': 'CONGE', 'miroir': 'MIROIR'}
_ov = {'g': None, 'sig': None, 'row': 0}
_tip = {'g': None, 'cle': None}


def _ecrire_png(cle, px, w, h):
    import zlib, struct, tempfile
    raw = bytearray()
    for y in range(h):
        raw.append(0)
        for x in range(w):
            raw += bytes(px[y][x])

    def chunk(tt, dd):
        c = struct.pack('>I', len(dd)) + tt + dd
        return c + struct.pack('>I', zlib.crc32(tt + dd) & 0xffffffff)

    png = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 6, 0, 0, 0)) + \
        chunk(b'IDAT', zlib.compress(bytes(raw))) + chunk(b'IEND', b'')
    chemin = os.path.join(tempfile.gettempdir(), 'traverse_corps_cnc_%s.png' % cle)
    with open(chemin, 'wb') as f:
        f.write(png)
    _png_cache[cle] = chemin
    return chemin


def _dpr():
    if 'k' not in _dpr_cache:
        k = 1.0
        try:
            import ctypes
            k = max(1.0, ctypes.windll.user32.GetDpiForSystem() / 96.0)
        except Exception:
            pass
        _dpr_cache['k'] = k
    return _dpr_cache['k']


def _sans_accent(txt):
    import unicodedata
    return ''.join(ch for ch in unicodedata.normalize('NFD', txt) if unicodedata.category(ch) != 'Mn').upper()


def _texte_px(px, txt, x0, y0, couleur, xmax=None):
    """Capitales sans accent, police 3x5 agrandie x2, pas de 8 px."""
    txt = _sans_accent(txt)
    for n, ch in enumerate(txt):
        if xmax is not None and x0 + n * 8 + 6 > xmax:
            break
        g = _GLYPHES.get(ch, _GLYPHES[' '])
        for gy in range(5):
            for gx in range(3):
                if g[gy * 3 + gx] == '1':
                    for dy in range(2):
                        for dx in range(2):
                            xx, yy = x0 + n * 8 + gx * 2 + dx, y0 + gy * 2 + dy
                            if 0 <= yy < len(px) and 0 <= xx < len(px[0]):
                                px[yy][xx] = couleur


def _nom_piece_defaut(calc):
    try:
        return 'Traverse %sx%sx%s' % (_mm_txt(calc['L'])[:-3], _mm_txt(calc['H'])[:-3], _mm_txt(_cur['ep'])[:-3])
    except Exception:
        return 'Traverse'


def _etat_rows():
    """Contenu de chaque fenetre : (cle, nom, bouton type, bouton tangent, valeur, couleur valeur, etat, couleur etat)."""
    calc = _cur['calc'] or {}
    rows = []
    JAUNE, GRIS, BLANC = (255, 200, 60, 255), (150, 150, 150, 255), (235, 235, 235, 255)
    for r in ROWS:
        nom = _tt(NOMS_ROWS[r])
        typ = tan = None
        val, cval, et, cet = '', JAUNE, '', GRIS
        if r == 'T':
            typ = tuple(bool(_s.get(k)) for k in ('tn_dessus', 'tn_dessous', 'tn_cotes'))
            tan = str(int(_s.get('tn_nb') or 1))
            et = _tt('CENTRES') if _s.get('tn_place', 'centre') != 'bord' else \
                _tt('BORD') + ' ' + _mm_txt((_s.get('tn_bord') or 0.0) / 10.0)
            if (_cur['calc'] or {}).get('tn_manque'):
                et, cet = _tt('NE TIENNENT PAS'), ROUGE
            rows.append((r, nom, typ, tan, '', cval, et, cet))
            continue
        if r == 'N':
            nb = _sym_nb()
            typ, tan = '-', str(nb)
            # 3e element : bouton d'orientation (seulement avec un axe choisi)
            nom = (nom, ('// ' + _tt('AXE')) if (_s.get('axe') and _s.get('para', True)) else
                   (_tt('PERP') if _s.get('axe') else None))
            if nb > 1:
                val = _mm_txt(float(_s.get('sym_e') or 0.0))
                et = _tt('ENTRAXE')
            elif _s.get('axe'):
                val = _tt('CENTRER')            # une seule traverse : clic = sur l'axe (Maxence 2026-11-11)
            else:
                val = '-'
            if _s.get('sym2') and _s.get('axe'):
                et = (et + ' ' if et else '') + 'X2'
            if (nb > 1 or _s.get('sym2')) and not _sym_ok():
                et, cet = _tt('NE TIENT PAS'), ROUGE
        elif r == 'NM':
            # nom de la piece (bouton « Enregistrer comme piece ») : par defaut « Traverse LxHxE », en gris
            nmv = (_s.get('enreg_nom') or '').strip()
            if nmv:
                val = nmv[:34]
            else:
                val, cval = _nom_piece_defaut(calc)[:34], GRIS
            et = ''
        elif r == 'M':
            # distance a l'extremite de la base : bouton COTE (extremite utilisee), bouton ON / OFF
            on = bool(_s.get('dist_on'))
            typ = _tt('COTE') + (' ' + ('+' if (_s.get('dist_cote') or 1) > 0 else '-') if on else '')
            tan = _tt('ON') if on else _tt('OFF')
            if not on:
                val, cval = '-', GRIS
                et = _tt('CLIC : ACTIVER')
            else:
                ex = _s.get('dist_expr') or ''
                val = ex[:12] if _est_param(ex) else _mm_txt(_eval_expr(ex) or 0.0)
                if not _dist_dispo():
                    et, cet = _tt('SANS BASE'), ROUGE
                elif _ctx.get('dist_hors'):
                    et, cet = _tt('HORS DE L\'ARETE'), ROUGE
                else:
                    et = _tt('DE L\'EXTREMITE')
        elif r == 'P':
            val = _mm_txt(_ctx.get('s') or 0.0)
            if _est_param(_s.get('pos_expr')):
                et = ':' + _s['pos_expr'][:14]
        elif r == 'L':
            L = calc.get('L')
            val = _mm_txt(L) if L else '-'
            if calc.get('defaut_L'):
                et, cet = _tt('PAR DEFAUT : A SAISIR'), ROUGE
            elif _s.get('L_auto'):
                et = ''                         # automatique : rien a signaler (Maxence 2026-11-16)
            elif _est_param(_s.get('L_expr')):
                et = ':' + _s['L_expr'][:14]
            else:
                et = ''
            if _delta_txt() and not calc.get('defaut_L'):
                et = (et + ' ' + _delta_txt()).strip()
        elif r == 'H':
            H = calc.get('H')
            val = _mm_txt(H) if H else '-'
            if calc.get('defaut_H'):
                et, cet = _tt('PAR DEFAUT : A SAISIR'), ROUGE
            elif _s.get('H_auto') and _ctx.get('H_det') is not None:
                et = ''
            elif _est_param(_s.get('H_expr')):
                et = ':' + _s['H_expr'][:14]
            else:
                et = ''
        else:
            i = int(r[1])
            bl = _b_liste_sel() if _s.get('b') else None
            b = _b_eff(i, bl) if bl else {'type': 'auto', 'tan': 'dessous'}       # reglages effectifs (miroir)
            eff = (_calc_sel().get('bouts') or [None, None])[i]
            typ = _tt(NOMS_TYPES.get(b['type'], 'AUTO'))
            if bl and bl[i].get('type') == 'miroir':
                typ = _tt('MIROIR')                 # la fin suit le debut
            elif b['type'] == 'auto' and eff is not None:
                typ = _tt(NOMS_TYPES.get(eff[0], ''))
            tan = _tt('DESSOUS' if (eff[1] if eff else b['tan']) == 'dessous' else 'DESSUS')
            if eff is None or eff[0] == 'droite':
                val, tan = '-', '-'
                et = ''
            else:
                val = _mm_txt(eff[2])
                if eff[3]:
                    et = ''
                elif _est_param(b.get('expr')):
                    et = ':' + b['expr'][:14]
                else:
                    et = _tt('SAISIE')
                if eff[0] == 'conge':
                    # conge : largeur dans la valeur, hauteur a droite (clic dessus pour la taper)
                    he = _b_hexpr(b)
                    et = _tt('HAUTEUR') + ' ' + (he[:12] if _est_param(he) else _mm_txt(getattr(eff, 'h', None) or 0.0))
                    if _saisie['row'] == r + 'h':
                        et, cet = _tt('HAUTEUR') + ' ' + _saisie['txt'] + '_', BLANC
                    elif calc.get('raison') == 'CONGE' or _calc_sel().get('raison') == 'CONGE':
                        cet = ROUGE
        if _saisie['row'] == r:
            val, cval = _saisie['txt'] + '_', BLANC
            et, cet = _tt('ENTREE : VALIDER'), JAUNE
        rows.append((r, nom, typ, tan, val, cval, et, cet))
    return rows


def _png_ligne(row, actif):
    r, nom, typ, tan, val, cval, et, cet = row
    orient = None
    if isinstance(nom, tuple):
        nom, orient = nom
    cle = 'tc_%s' % abs(hash((row, actif)))
    if cle in _png_cache and os.path.isfile(_png_cache[cle]):
        return _png_cache[cle]
    w, h = OV_W, OV_H
    BLEU = (20, 130, 215, 255)
    cadre = BLEU if actif else (110, 110, 110, 255)
    px = [[(40, 40, 40, 255)] * w for _ in range(h)]
    for x in range(w):
        for y in (0, 1, h - 1, h - 2):
            px[y][x] = cadre
    for y in range(h):
        for x in (0, 1, w - 1, w - 2):
            px[y][x] = cadre
    yc = h // 2
    y0 = (h - 10) // 2
    _texte_px(px, nom, 8, y0, (235, 235, 235, 255) if actif else (140, 140, 140, 255), OV_T0 - 4)

    def bouton(x0, x1, txt, allume=False):
        fond = (20, 110, 190, 255) if allume else (62, 62, 62, 255)
        for x in range(x0, x1):
            for y in range(yc - 11, yc + 11):
                px[y][x] = (125, 125, 125, 255) if (x in (x0, x1 - 1) or y in (yc - 11, yc + 10)) else fond
        lg = len(_sans_accent(txt)) * 8 - 2
        _texte_px(px, txt, x0 + max(4, (x1 - x0 - lg) // 2), y0,
                  (255, 255, 255, 255) if allume else (190, 190, 190, 255), x1 - 2)

    if r == 'T':
        for (k, x0, x1, txt), on in zip(TN_ZONES[:3], typ):
            bouton(x0, x1, _tt(txt), on)
        _, m0, m1, _t = TN_ZONES[3]
        _, p0, p1, _t = TN_ZONES[4]
        bouton(m0, m1, '-')
        _texte_px(px, tan, m1 + (p0 - m1 - (len(tan) * 8 - 2)) // 2, y0, (235, 235, 235, 255))
        bouton(p0, p1, '+')
        _, x0, x1, _t = TN_ZONES[5]
        bouton(x0, x1, et)
        if cet == ROUGE:
            _texte_px(px, et, x0 + 4, y0, ROUGE, x1 - 2)
        return _ecrire_png(cle, px, w, h)
    if r in ('N', 'C'):
        bouton(OV_M0, OV_M1, '<' if r == 'C' else '-')
        _texte_px(px, tan, OV_N0 + (OV_P0 - 6 - OV_N0 - (len(tan) * 8 - 2)) // 2, y0, (235, 235, 235, 255))
        bouton(OV_P0, OV_P1, '>' if r == 'C' else '+')
        if orient:
            bouton(OV_O0, OV_O1, orient)
        xv = OV_V0
    elif typ is not None:
        bouton(OV_T0, OV_T1, typ)
        bouton(OV_G0, OV_G1, tan)
        xv = OV_V0
    else:
        xv = OV_T0 + 8
    _texte_px(px, val, xv, y0, cval if actif else (140, 140, 140, 255), OV_S0 - 6)
    if et:
        _texte_px(px, et, OV_S0, y0, cet if (actif or cet == ROUGE) else (140, 140, 140, 255), w - 6)
    return _ecrire_png(cle, px, w, h)


def _png_info(txt):
    cle = 'tip_%s' % abs(hash(txt))
    w = len(_sans_accent(txt)) * 8 + 12
    h = 24
    if cle in _png_cache and os.path.isfile(_png_cache[cle]):
        return _png_cache[cle], w, h
    px = [[(246, 246, 246, 255)] * w for _ in range(h)]
    for x in range(w):
        for y in (0, h - 1):
            px[y][x] = (110, 110, 110, 255)
    for y in range(h):
        for x in (0, w - 1):
            px[y][x] = (110, 110, 110, 255)
    _texte_px(px, txt, 6, 7, (20, 20, 20, 255))
    return _ecrire_png(cle, px, w, h), w, h


def _vp_larg():
    try:
        v = _app.activeViewport
        return (int(v.width), int(v.height))
    except Exception:
        return None


# Affichage (Maxence 2026-11-16) : les bouts se choisissent sur l'apercu -> fenetres DEBUT / FIN cachees (elles ne
# reviennent que le temps de taper une valeur de bout depuis sa poignee) ; LONGUEUR et HAUTEUR sur une seule ligne.
# ROWS reste la liste logique (saisie, poignees) ; _aff() donne les lignes affichees, chacune = rangs de ROWS.
OV_LH = 262                     # ligne LONGUEUR + HAUTEUR : debut de la moitie HAUTEUR


def _aff():
    sr = str(_saisie.get('row') or '')
    out = []
    for i, r in enumerate(ROWS):
        if r == 'H':
            continue
        if r == 'L':
            out.append((i, ROWS.index('H')))
        elif r in ('D0', 'D1'):
            if sr[:2] == r:
                out.append((i,))
        else:
            out.append((i,))
    return out


def _aff_index(r):
    """Rang affiche de la fenetre logique r (bulles d'aide) ; ligne LONGUEUR / HAUTEUR si elle est cachee."""
    a = _aff()
    for j, rs in enumerate(a):
        if r in rs:
            return j
    for j, rs in enumerate(a):
        if ROWS.index('L') in rs:
            return j
    return 0


def _ov_y(r):
    """Bas de la fenetre affichee de rang r (rang 0 en haut)."""
    nb = len(_aff())
    return OV_Y + (nb - 1 - r) * (OV_H * _dpr() + OV_GAP)


def _png_ligne_lh(rl, rh, actif, act_h):
    """Ligne LONGUEUR + HAUTEUR : deux moities (nom, valeur, etat court)."""
    cle = 'tclh_%s' % abs(hash((rl, rh, actif, act_h)))
    if cle in _png_cache and os.path.isfile(_png_cache[cle]):
        return _png_cache[cle]
    w, h = OV_W, OV_H
    cadre = (20, 130, 215, 255) if actif else (110, 110, 110, 255)
    px = [[(40, 40, 40, 255)] * w for _ in range(h)]
    for x in range(w):
        for y in (0, 1, h - 1, h - 2):
            px[y][x] = cadre
    for y in range(h):
        for x in (0, 1, w - 1, w - 2):
            px[y][x] = cadre
    for y in range(6, h - 6):                   # separation des deux moities
        px[y][OV_LH - 6] = (90, 90, 90, 255)
    y0 = (h - 10) // 2
    GRIS = (140, 140, 140, 255)
    for row, x0, x1, moi in ((rl, 8, OV_LH - 10, not act_h), (rh, OV_LH, w - 6, act_h)):
        _r, nom, _t, _g, val, cval, et, cet = row
        _texte_px(px, nom, x0, y0, (235, 235, 235, 255) if (actif and moi) else GRIS, x1)
        xv = x0 + len(_sans_accent(nom)) * 8 + 8
        if cet == ROUGE and not val.endswith('_'):
            cval = ROUGE                         # valeur par defaut a saisir : la valeur en rouge
        _texte_px(px, val, xv, y0, cval if (actif or cval == ROUGE) else GRIS, x1)
        if et and cet != ROUGE:
            xe = xv + len(_sans_accent(val)) * 8 + 8
            _texte_px(px, et, xe, y0, cet if actif else GRIS, x1)
    return _ecrire_png(cle, px, w, h)


ID_OV = 'TraverseCorpsCNC_fenetres'
ID_TIP = 'TraverseCorpsCNC_aide'


def _ov_effacer(balayer=False):
    g = _ov['g']
    _ov['g'] = None
    _ov['sig'] = None
    _tip_effacer()
    try:
        if g is not None and g.isValid:
            g.deleteMe()
    except Exception:
        pass
    if balayer:
        _balayer(ID_OV)
        _balayer(ID_TIP)


# Fenetres devant le modele (meme principe que TraversesDossierCNC._dv_*) : la camera bouge, elles suivent.
_dv = {'ents': [], 'h': None, 'c': None, 'r': 0.0, 't': 0.0}


def _dv_point():
    des = _design()
    if des is None:
        return None
    if time.time() - _dv['t'] > 15.0:
        # boite des corps visibles : ~50 ms sur FS210, elle etait refaite pour CHAQUE fenetre (6 fois par redessin,
        # 3 redessins par clic : la vue figeait ~0,8 s, Maxence 2026-11-13) ; gardee 15 s (corps immobiles pendant
        # la commande)
        _dv['t'] = time.time()
        # corps VISIBLES seulement : la boite du composant racine compte les composants masques (CNC Toolkit a
        # (-200, 200)...) ; gonflee, elle mettait les fenetres hors de la zone affichee (FS210, 2026-11-11)
        try:
            a, b = _caf.boite_visible(des)
        except Exception:
            bb = des.rootComponent.boundingBox
            a, b = (tuple(bb.minPoint.asArray()), tuple(bb.maxPoint.asArray())) if bb is not None else (None, None)
        if a is None:
            _dv['c'] = None
        else:
            _dv['c'] = ((a[0] + b[0]) / 2.0, (a[1] + b[1]) / 2.0, (a[2] + b[2]) / 2.0)
            _dv['r'] = math.sqrt(sum((b[i] - a[i]) ** 2 for i in range(3))) / 2.0
    c = _dv['c']
    if c is None:
        return None
    cam = _app.activeViewport.camera
    e, t = cam.eye, cam.target
    d = (e.x - t.x, e.y - t.y, e.z - t.z)
    lg = math.sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2])
    if lg < 1e-9:
        return None
    d = (d[0] / lg, d[1] / lg, d[2] / lg)
    ec = (e.x - c[0]) * d[0] + (e.y - c[1]) * d[1] + (e.z - c[2]) * d[2]
    s = min(_dv['r'] * 1.2 + 1.0, ec * 0.5) if ec > 0 else 0.0
    p = adsk.core.Point3D.create(c[0] + d[0] * s, c[1] + d[1] * s, c[2] + d[2] * s)
    occ = des.activeOccurrence
    if occ is not None:
        inv = occ.transform2.copy()
        inv.invert()
        p.transformBy(inv)
    return p


def _dv_appliquer(ents):
    p = _dv_point()
    if p is None:
        return
    m = adsk.core.Matrix3D.create()
    m.translation = adsk.core.Vector3D.create(p.x, p.y, p.z)
    for x in ents:
        x.transform = m


class _DvCamHandler(adsk.core.CameraEventHandler):
    def notify(self, args):
        try:
            ents = [x for x in _dv['ents'] if x.isValid]
            _dv['ents'] = ents
            if ents:
                _dv_appliquer(ents)
            for g in list(_pastilles.values()):
                g.recaler(args.viewport)
        except Exception:
            pass


def _dv_poser(ps):
    try:
        _dv_appliquer([ps])
        _dv['ents'] = [x for x in _dv['ents'] if x.isValid] + [ps]
        _camera_suivre(True)
    except Exception:
        pass


def _camera_suivre(oui):
    try:
        if oui and _dv['h'] is None:
            h = _DvCamHandler()
            _app.cameraChanged.add(h)
            _dv['h'] = h
        elif not oui and _dv['h'] is not None:
            _app.cameraChanged.remove(_dv['h'])
            _dv['h'] = None
            _dv['ents'] = []
    except Exception:
        pass


_png_cache = {}


def _ov_maj():
    """Dessine les 4 fenetres (composant actif : sinon elles sont grisees)."""
    try:
        if not _ctx.get('ok'):
            _ov_effacer()
            return
        rows = _etat_rows()
        aff = _aff()
        n_c, i_c = _corps_n(), _corps_i()
        sig = (tuple(rows), tuple(aff), _actif['row'], _vp_larg(), _dpr(), n_c, i_c)
        if sig == _ov['sig'] and _ov['g'] is not None and _ov['g'].isValid:
            return
        _ov_effacer()
        g = _design().activeComponent.customGraphicsGroups.add()
        g.id = ID_OV
        k = _dpr()
        for i, rs in enumerate(aff):
            actif = _actif['row'] in rs
            if len(rs) == 2:
                row = (rows[rs[0]], rows[rs[1]])
                cle = (row, actif, _actif['row'] == rs[1], k)
            else:
                row = rows[rs[0]]
                cle = (row, actif, k)
            png = _png_cache.get(cle)
            if png is None:             # images gardees : seule la fenetre qui change est refaite (glisser fluide)
                if len(rs) == 2:
                    png = _png_ligne_lh(row[0], row[1], actif, _actif['row'] == rs[1])
                else:
                    png = _png_ligne(row, actif)
                if len(_png_cache) > 200:
                    _png_cache.clear()
                _png_cache[cle] = png
            ps = g.addPointSet(adsk.fusion.CustomGraphicsCoordinates.create([0.0, 0.0, 0.0]), [0],
                               adsk.fusion.CustomGraphicsPointTypes.UserDefinedCustomGraphicsPointType, png)
            ps.isSelectable = False
            ps.viewPlacement = adsk.fusion.CustomGraphicsViewPlacement.create(
                adsk.core.Point3D.create(0, 0, 0), adsk.fusion.ViewCorners.lowerLeftViewCorner,
                adsk.core.Point2D.create(OV_X + OV_W * k / 2.0, _ov_y(i) + OV_H * k / 2.0))
            _dv_poser(ps)
        if n_c > 1:                               # selecteur de corps (precedent / suivant)
            rc = ('C', _tt('CORPS'), '<', '%d/%d' % (i_c + 1, n_c), (_tt('PRINCIPAL') if i_c == 0 else
                  _tt('COPIE') + ' %d' % i_c), (255, 200, 60, 255), '', (150, 150, 150, 255))
            cle = (rc, True, k)
            png = _png_cache.get(cle)
            if png is None:
                png = _png_cache[cle] = _png_ligne(rc, True)
            ps = g.addPointSet(adsk.fusion.CustomGraphicsCoordinates.create([0.0, 0.0, 0.0]), [0],
                               adsk.fusion.CustomGraphicsPointTypes.UserDefinedCustomGraphicsPointType, png)
            ps.isSelectable = False
            ps.viewPlacement = adsk.fusion.CustomGraphicsViewPlacement.create(
                adsk.core.Point3D.create(0, 0, 0), adsk.fusion.ViewCorners.lowerLeftViewCorner,
                adsk.core.Point2D.create(OV_X + OV_W * k / 2.0, _ov_y(-1) + OV_H * k / 2.0))
            _dv_poser(ps)
        _ov['g'] = g
        _ov['sig'] = sig
    except Exception:
        _log('overlay erreur ' + traceback.format_exc()[-400:])


def _ov_assurer():
    try:
        ok = _ov['g'] is not None and _ov['g'].isValid
    except Exception:
        ok = False
    if not ok and _ctx.get('ok'):
        _ov['sig'] = None
        _ov_maj()


def _conge_eff(i):
    """Le bout i (de la piece choisie) est un conge asymetrique."""
    try:
        eff = (_calc_sel().get('bouts') or [None, None])[i]
        return eff is not None and eff[0] == 'conge'
    except Exception:
        return False


def _ov_zone(vp, pos):
    """(rang, zone) sous le curseur ; zone : 'type', 'tan', 'ligne' ; (None, None) hors des fenetres."""
    if _ov['g'] is None or not _ctx.get('ok'):
        return None, None
    k = _dpr()
    h = vp.height * k
    if _corps_n() > 1:                       # selecteur de corps, au-dessus des fenetres
        y_haut = h - (_ov_y(-1) + OV_H * k)
        if y_haut <= pos.y <= y_haut + OV_H * k:
            x = (pos.x - OV_X) / k
            if 0 <= x <= OV_W:
                _ov['row'] = -1
                if OV_M0 <= x <= OV_M1:
                    return -1, 'moins'
                if OV_P0 <= x <= OV_P1:
                    return -1, 'plus'
                return -1, 'ligne'
    for ia, rs in enumerate(_aff()):
        yb = _ov_y(ia)
        # viewportPosition : origine en haut a gauche, en pixels physiques
        y_haut = h - (yb + OV_H * k)
        if y_haut <= pos.y <= y_haut + OV_H * k:
            x = (pos.x - OV_X) / k
            if x < 0 or x > OV_W:
                return None, None
            r = rs[1] if (len(rs) == 2 and x >= OV_LH - 6) else rs[0]
            _ov['row'] = r
            if ROWS[r] == 'T':
                for k, x0, x1, _t in TN_ZONES:
                    if x0 <= x <= x1:
                        return r, k
                return r, 'ligne'
            if ROWS[r] == 'N':
                if OV_M0 <= x <= OV_M1:
                    return r, 'moins'
                if OV_P0 <= x <= OV_P1:
                    return r, 'plus'
                if OV_O0 <= x <= OV_O1 and _s.get('axe'):
                    return r, 'orient'
            if ROWS[r] in ('D0', 'D1'):
                if OV_T0 <= x <= OV_T1:
                    return r, 'type'
                if OV_G0 <= x <= OV_G1:
                    return r, 'tan'
                if x >= OV_S0 - 4 and _conge_eff(int(ROWS[r][1])):
                    return r, 'haut'
            if ROWS[r] == 'M':
                if OV_T0 <= x <= OV_T1:
                    return r, 'type'
                if OV_G0 <= x <= OV_G1:
                    return r, 'tan'
            return r, 'ligne'
    return None, None


def _tip_effacer():
    g = _tip['g']
    _tip['g'] = None
    _tip['cle'] = None
    try:
        if g is not None and g.isValid:
            g.deleteMe()
            _rafraichir_vue()
    except Exception:
        pass


def _texte_aide(r, z):
    if r is None:
        return None
    if r == -1:
        return "Corps precedent / suivant : choisit le corps a personnaliser (courbes)"
    nom = ROWS[r]
    if z in ('tn_dessus', 'tn_dessous', 'tn_cotes'):
        return "Tenons sur le dessus, le dessous ou les bouts droits (clic : oui / non)"
    if z in ('tn_moins', 'tn_plus'):
        return "Nombre de tenons par chant"
    if z == 'tn_place':
        return "Tenons centres (ecarts egaux) ou depuis le bord"
    if z == 'orient':
        return "Parallele a l'axe ou perpendiculaire au chemin"
    if z == 'moins':
        return "Une traverse de moins (symetrie sur l'axe)"
    if z == 'plus':
        return "Une traverse de plus, en symetrie sur l'axe de la forme"
    if nom == 'NM':
        return "Clic : nom de la piece (bouton Enregistrer comme piece)"
    if nom == 'M':
        if z == 'type':
            return "Extremite de la base utilisee (cote de la traverse)"
        if z == 'tan':
            return "Distance a l'extremite de la base : marche / arret"
        return "Clic puis tapez la distance entre la traverse et l'extremite de la base, et Entree"
    if z == 'type' and nom == 'D1':
        return "Forme de la fin : auto, arc, angle, droite, miroir du debut, conge"
    if z == 'type':
        return "Forme du bout : auto, arc 3 points, angle, droite, conge"
    if z == 'haut':
        return "Clic puis tapez la hauteur du conge et Entree"
    if z == 'tan':
        return "Cote tangent : dessous (dessus en retrait) ou dessus"
    if nom == 'N' and _sym_nb() == 1 and _s.get('axe'):
        return "Centrer la traverse sur l'axe"
    return {'T': "Cliquez un bouton : dessus, dessous, cotes, nombre, placement",
            'N': "Clic puis tapez l'entraxe et Entree",
            'P': "Glissez la poignee le long de l'arete, ou clic puis tapez la position et Entree",
            'L': "Clic puis tapez la longueur au clavier et Entree",
            'H': "Clic puis tapez la hauteur au clavier et Entree",
            'D0': "Clic puis tapez le retrait du debut et Entree" if not _conge_eff(0) else
                  "Clic puis tapez la largeur du conge et Entree",
            'D1': "Clic puis tapez le retrait de la fin et Entree" if not _conge_eff(1) else
                  "Clic puis tapez la largeur du conge et Entree"}.get(nom)


def _tip_maj(vp, pos):
    r, z = _ov_zone(vp, pos)
    txt = _texte_aide(r, z)
    if txt is None and _survol.get('i') is not None:
        # bout de l'apercu survole : bulle a cote de sa fenetre (DEBUT / FIN)
        r, z = ROWS.index('D%d' % _survol['i']), 'bout'
        txt = "Clic : forme suivante (auto, arc, angle, droite, conge)"
    cle = None if txt is None else (r, z, txt)
    if cle == _tip['cle'] and (cle is None or (_tip['g'] is not None and _tip['g'].isValid)):
        return
    _tip_effacer()
    if txt is None:
        return
    png, w, h = _png_info(_tt(txt))
    g = _design().activeComponent.customGraphicsGroups.add()
    g.id = ID_TIP
    k = _dpr()
    gauche = OV_X + (OV_W + 8) * k
    ps = g.addPointSet(adsk.fusion.CustomGraphicsCoordinates.create([0.0, 0.0, 0.0]), [0],
                       adsk.fusion.CustomGraphicsPointTypes.UserDefinedCustomGraphicsPointType, png)
    ps.isSelectable = False
    ps.viewPlacement = adsk.fusion.CustomGraphicsViewPlacement.create(
        adsk.core.Point3D.create(0, 0, 0), adsk.fusion.ViewCorners.lowerLeftViewCorner,
        adsk.core.Point2D.create(gauche + w * k / 2.0, _ov_y(_aff_index(r) if r >= 0 else -1) + OV_H * k / 2.0))
    _dv_poser(ps)
    _tip['g'] = g
    _tip['cle'] = cle
    _rafraichir_vue()


# --- Poignees (pastilles) -------------------------------------------------------------------------------------
# 1 = longueur (bout de fin), 2 = hauteur (milieu du dessus), 3 / 4 = retrait du debut / de la fin,
# 5 = position le long de l'arete (au pied de la traverse, glisse sur l'arete).

PAST_ROW = {5: None, 1: ROWS.index('L'), 2: ROWS.index('H'), 3: ROWS.index('D0'), 4: ROWS.index('D1'),
            6: ROWS.index('D0'), 7: ROWS.index('D1')}     # 6 / 7 : hauteur du conge du debut / de la fin


def _poignee_haut_conge(k, ck, bt, i, L, H):
    """Poignee de hauteur d'un conge asymetrique (sur le cote du bout), ou None."""
    typ, tan, _d, _det = bt
    h = getattr(bt, 'h', None)
    if typ != 'conge' or not h:
        return None
    x = 0.0 if i == 0 else L
    if tan == 'dessous':
        return (k, _pt(ck, x, H - h, 0.0), _pt(ck, x, H, 0.0), _v_mul(ck['n'], -1.0), h)
    return (k, _pt(ck, x, h, 0.0), _pt(ck, x, 0.0, 0.0), ck['n'], h)


def _poignees():
    """[(k, point monde, origine du trajet, direction, valeur courante le long)]"""
    calc = _cur['calc']
    if not _ctx.get('ok') or calc is None or calc.get('L') is None or calc.get('H') is None:
        return []
    c = _ctx
    L, H = calc['L'], calc['H']
    z = _cur['ep'] / 2.0
    if calc.get('piece'):
        return [(5, _pt(c, 0.0, 0.0, 0.0), None, None, c['s'])]
    # une seule poignee pour deplacer la traverse (5) ; longueur et hauteur se tapent dans les fenetres
    # (la poignee de longueur se retrouvait au milieu d'un arc et changeait la longueur, Maxence 2026-11-11)
    a0 = calc.get('a0') or 0.0                    # mode DISTANCE : debut sur le contour de la base
    # hauteur (Maxence 2026-11-13) : au milieu du dessus, entre les bouts (jamais sur un conge ou un arc)
    xh = []
    for i, bt in enumerate(calc.get('bouts') or []):
        typ, tan, d, _det = bt
        xh.append(d if (typ != 'droite' and tan == 'dessous') else 0.0)
    xm = a0 + (xh[0] + L - xh[1]) / 2.0 if len(xh) == 2 else a0 + L / 2.0
    # deplacement : a plat sur le corps du dessous, au milieu du bas de l'apercu (entre les bouts du dessous ; au
    # pied du debut, elle cachait les poignees du conge, Maxence 2026-11-17) ; le glisser suit toujours le point
    # du chemin le plus proche de la souris
    xb = [(bt[2] if (bt[0] != 'droite' and bt[1] == 'dessus') else 0.0) for bt in (calc.get('bouts') or [])]
    xbm = a0 + (xb[0] + L - xb[1]) / 2.0 if len(xb) == 2 else a0 + L / 2.0
    out = [(5, _pt(c, xbm, 0.0, 0.0), None, None, c['s'])]
    out.append((2, _pt(c, xm, H, 0.0), _pt(c, xm, 0.0, 0.0), c['n'], H))
    for i, bt in enumerate(calc.get('bouts') or []):
        typ, tan, d, _det = bt
        if typ == 'droite':
            continue
        y = H if tan == 'dessous' else 0.0
        if i == 0:
            out.append((3, _pt(c, a0 + d, y, 0.0), _pt(c, a0, y, 0.0), c['u'], d))
        else:
            out.append((4, _pt(c, a0 + L - d, y, 0.0), _pt(c, a0 + L, y, 0.0), _v_mul(c['u'], -1.0), d))
        hc = _poignee_haut_conge(6 + i, c, bt, i, L, H)
        if hc is not None:
            k_, p_, o_, d_, v_ = hc
            out.append((k_, _v_add(p_, _v_mul(c['u'], a0)), _v_add(o_, _v_mul(c['u'], a0)), d_, v_))
    _ = z
    return out


def _poignees_sym():
    """Poignees des courbes (bouts) de chaque piece en symetrie : numero 100 * (rang + 1) + 3 ou 4."""
    out = []
    if not _sym_actif() or _drag.get('k') in (1, 2, 5):
        return out
    vue = _sym['pieces'] if _drag.get('k') is None else (_sym.get('vue') or _sym['pieces'])
    for j, (ck, cc) in enumerate(vue):
        if not ck.get('ok') or cc.get('L') is None or cc.get('H') is None:
            continue
        L, H = cc['L'], cc['H']
        for i, bt in enumerate(cc.get('bouts') or []):
            typ, tan, d, _det = bt
            if typ == 'droite':
                continue
            y = H if tan == 'dessous' else 0.0
            k = 100 * (j + 1) + 3 + i
            if i == 0:
                out.append((k, _pt(ck, d, y, 0.0), _pt(ck, 0.0, y, 0.0), ck['u'], d))
            else:
                out.append((k, _pt(ck, L - d, y, 0.0), _pt(ck, L, y, 0.0), _v_mul(ck['u'], -1.0), d))
            hc = _poignee_haut_conge(100 * (j + 1) + 6 + i, ck, bt, i, L, H)
            if hc is not None:
                out.append(hc)
    return out


def _poignees_toutes():
    return _poignees() + _poignees_sym()


def _maj_pastilles():
    if _caf is None:
        return
    try:
        hs = _poignees_toutes()
    except Exception:
        _log('pastilles : ' + traceback.format_exc()[-200:])
        hs = []
    ks = set(h[0] for h in hs)
    for k in list(_pastilles):
        if k not in ks:
            g = _pastilles.pop(k, None)
            if g is not None:
                g.effacer()
    for k, p, _o, _d, _v in hs:
        try:
            g = _pastilles.get(k)
            if g is None:
                # retraits des bouts (forme des arcs) : losange, different des autres poignees
                g = _pastilles[k] = _caf.Poignee(ID_PASTILLE % k, 'losange' if k % 100 in (3, 4, 6, 7) else 'anneau')
                _camera_suivre(True)
            g.placer(p)
        except Exception:
            _log('pastille %d : %s' % (k, traceback.format_exc()[-200:]))


def _pastilles_effacer():
    for g in list(_pastilles.values()):
        g.effacer()
    anciens = list(_pastilles)
    _pastilles.clear()
    if _caf is not None:
        for k in (1, 2, 3, 4, 5) + tuple(anciens):
            _caf.balayer(ID_PASTILLE % k)


def _pastille_touchee(vp, pos):
    r = 14.0 * _dpr()
    best = None
    for k, p, _o, _d, _v in _poignees_toutes():
        q = vp.modelToViewSpace(adsk.core.Point3D.create(*p))
        d = math.hypot(q.x - pos.x, q.y - pos.y)
        if d <= r and (best is None or d < best[0]):
            best = (d, k)
    return best[1] if best else None


def _valeur_souris(vp, pos, o, dv, c=None):
    """Abscisse (cm) le long de la droite (o, dv) du point le plus proche de la souris, a l'ecran."""
    P = adsk.core.Point3D.create
    a = vp.modelToViewSpace(P(*o))
    lg = max(1.0, ((c or _ctx).get('Lmax') or 10.0))
    b = vp.modelToViewSpace(P(*_v_add(o, _v_mul(dv, lg))))
    ex, ey = b.x - a.x, b.y - a.y
    e2 = ex * ex + ey * ey
    if e2 < 1e-9:
        return None
    t = ((pos.x - a.x) * ex + (pos.y - a.y) * ey) / e2
    return t * lg


def _s_souris(vp, pos):
    r = _s_souris_d(vp, pos)
    return r[1] if r else None


def _s_souris_d(vp, pos):
    """(distance ecran, abscisse cm) du point de l'arete le plus proche de la souris (echantillons + affinage)."""
    c = _ctx
    ech = c.get('ech')
    if not ech:
        nb = 160
        ech = c['ech'] = [(c['Ltot'] * i / nb, _point_s(c, c['Ltot'] * i / nb)[0]) for i in range(nb + 1)]
    P = adsk.core.Point3D.create
    sc = [vp.modelToViewSpace(P(*q)) for _s0, q in ech]
    best = None
    for i in range(len(sc) - 1):
        a, b = sc[i], sc[i + 1]
        ex, ey = b.x - a.x, b.y - a.y
        e2 = ex * ex + ey * ey
        tt = 0.0 if e2 < 1e-9 else max(0.0, min(1.0, ((pos.x - a.x) * ex + (pos.y - a.y) * ey) / e2))
        d = math.hypot(a.x + ex * tt - pos.x, a.y + ey * tt - pos.y)
        if best is None or d < best[0]:
            best = (d, ech[i][0] + (ech[i + 1][0] - ech[i][0]) * tt)
    return best


# --- Selection en chaine (2026-11-12) : la traverse suit tout le contour de la face d'appui -------------------
# Glisser la poignee au-dela du bout de l'arete la fait passer sur l'arete suivante du contour (les aretes qui se
# touchent), comme si tout le contour de la face etait selectionne d'un coup.

_ch_ech = {}


def _chaine_entites():
    """Aretes selectionnees en chaine (Ctrl + clic), sans l'arete actuelle."""
    out = []
    for t in (_s.get('aretes') or []):
        e = _ch_ent.get(t)
        if e is None:
            try:
                r = _design().findEntityByToken(t)
                e = r[0] if r else None
            except Exception:
                e = None
            if e is not None:
                _ch_ent[t] = e
        if e is not None:
            out.append(e)
    return out


_ch_ent = {}


def _chaine_chercher(vp, pos):
    """(distance, arete, abscisse) de l'arete de la chaine (autre que l'actuelle) la plus proche de la souris."""
    best = None
    for e in _chaine_entites():
        k = e.entityToken
        ech = _ch_ech.get(k)
        if ech is None:
            try:
                ev = e.evaluator
                ok, p0, p1 = ev.getParameterExtents()
                ok2, lg = ev.getLengthAtParameter(p0, p1)
                if not ok or not ok2 or lg < 0.05:
                    _ch_ech[k] = []
                    continue
                ech = []
                for i in range(61):
                    sl = lg * i / 60
                    okk, pk = ev.getParameterAtLength(p0, sl)
                    if not okk:
                        pk = p0 + (p1 - p0) * i / 60
                    _o, q = ev.getPointAtParameter(pk)
                    ech.append((sl, q))
                _ch_ech[k] = ech
            except Exception:
                _ch_ech[k] = []
                continue
        if not ech:
            continue
        sc = [vp.modelToViewSpace(q) for _sl, q in ech]
        for i in range(len(sc) - 1):
            a, b = sc[i], sc[i + 1]
            ex, ey = b.x - a.x, b.y - a.y
            e2 = ex * ex + ey * ey
            tt = 0.0 if e2 < 1e-9 else max(0.0, min(1.0, ((pos.x - a.x) * ex + (pos.y - a.y) * ey) / e2))
            d = math.hypot(a.x + ex * tt - pos.x, a.y + ey * tt - pos.y)
            if best is None or d < best[0]:
                best = (d, e, ech[i][0] + (ech[i + 1][0] - ech[i][0]) * tt)
    return best


def _chaine_passer(e, sl):
    """La traverse passe sur l'arete e (a l'abscisse sl) de la chaine, memes reglages. Vrai si fait."""
    global _ctx
    old = _ctx
    try:
        nv = _contexte(_design(), e, None, sl, bool(_s.get('sens')), bool(_s.get('inv')), _ignores())
        if not nv.get('ok'):
            return False
        tous = [old['ent']] + _chaine_entites()
        _ctx = nv
        _repere(_ctx, round(_ctx['s'] * 100.0) / 100.0)
        _s['pos'] = _ctx['s']
        _s['edge'] = e.entityToken
        _s['aretes'] = [x.entityToken for x in tous if x.entityToken != e.entityToken]
        _bloc['sel'] = [e] + [x for x in tous if x.entityToken != e.entityToken]
        _sym['sig'] = None
        _log('chaine : passage sur l\'arete suivante (%.1f mm)' % (sl * 10.0))
        return True
    except Exception:
        _ctx = old
        _log('chaine erreur ' + traceback.format_exc()[-300:])
        return False


def _deplacer(s, detecter=True):
    """Traverse amenee a l'abscisse s de l'arete (detections relancees sauf pendant le glisser)."""
    if not _ctx.get('ok') or s is None:
        return
    s = max(0.0, min(_ctx['Ltot'], s))
    if _repere(_ctx, s):
        _s['pos'] = _ctx['s']
        if detecter:
            _detecter(_design(), _ctx, _ignores())


def _arrondi(v):
    """Pas de 1 mm pendant le glisser."""
    return round(v * 10.0) / 10.0


def _poignee_set(k, v):
    """La poignee k est amenee a la valeur v (cm) : longueur, hauteur ou retrait (mesure saisie)."""
    if v is None:
        return
    v = max(0.1, _arrondi(v))
    if k == 1:
        _s['L_auto'] = False
        _s['L_saisie'] = True
        _s['L_expr'] = _mm_txt(v)
        _s['L_delta'] = 0.0             # longueur donnee : le reglage + / - repart de 0
    elif k == 2:
        _s['H_auto'] = False
        _s['H_saisie'] = True
        _s['H_expr'] = _mm_txt(v)
    elif k in (3, 4):
        if k == 4:
            _detacher_fin(_s['b'])              # fin en miroir modifiee a la main : elle devient independante
        b = _s['b'][k - 3]
        if b['type'] == 'auto':
            calc = _cur['calc'] or {}
            eff = (calc.get('bouts') or [None, None])[k - 3]
            if eff is not None:
                b['type'], b['tan'] = eff[0], eff[1]
        b['auto'] = False
        b['expr'] = _mm_txt(max(0.0, v))
    elif k in (6, 7):
        if k == 7:
            _detacher_fin(_s['b'])
        _s['b'][k - 6]['hexpr'] = _mm_txt(max(0.1, v))          # hauteur du conge asymetrique


def _glisser_bout_sym(vp, k, o, dv):
    """Poignee de courbe d'une piece en symetrie : seule cette piece change (retrait propre a la piece)."""
    j, e = k // 100 - 1, k % 100 - 3
    haut = e >= 3                                # 6 / 7 : hauteur du conge
    if haut:
        e -= 3
    if j >= len(_sym['pieces']):
        return
    ck, cc = _sym['pieces'][j]
    v = _valeur_souris(vp, _souris['pos'], o, dv, ck)
    if v is None:
        return
    v = max(0.0, _arrondi(v))
    bs = _b_liste_sym(j, True)
    if e == 1:
        _detacher_fin(bs)
    if haut:
        bs[e]['hexpr'] = _mm_txt(max(0.1, v))
    else:
        bs[e]['auto'] = False
        bs[e]['expr'] = _mm_txt(v)
    _sym['pieces'][j] = (ck, _calc_pour(ck, j))
    _sym['vue'] = None


def _glisser_souris(vp):
    """Pendant le glisser d'une pastille : calcul pur (aucun champ de la commande), aperçu, fenetres, redessin."""
    t0 = time.perf_counter()
    if t0 - _drag.get('tm', 0.0) < 0.008:
        return
    _drag['tm'] = t0
    k = _drag['k']
    h = next((x for x in _poignees_toutes() if x[0] == k), None)
    if h is None:
        h = _drag.get('h')
    if h is None:
        return
    _drag['h'] = h
    _k, _p, o, dv, _v = h
    if k == 5:
        r0 = _s_souris_d(vp, _souris['pos'])
        sv = r0[1] if r0 else None
        if _s.get('aretes') and (r0 is None or r0[0] > 18.0 * _dpr()):
            rc = _chaine_chercher(vp, _souris['pos'])
            if rc is not None and (r0 is None or rc[0] < r0[0] - 4.0 * _dpr()) and _chaine_passer(rc[1], rc[2]):
                sv = _s_souris(vp, _souris['pos'])
        if sv is not None:
            _s['pos_expr'] = ''
            _deplacer(_arrondi(sv), detecter=False)
            _sym_glisser()
            _dist_depuis_position()              # mode DISTANCE : la distance suit la poignee
    elif k >= 100:
        _glisser_bout_sym(vp, k, o, dv)
    else:
        v = _valeur_souris(vp, _souris['pos'], o, dv)
        _poignee_set(k, v)
    ta = time.perf_counter()
    if k < 100:
        _cur['calc'] = _calc()
    tb = time.perf_counter()
    _apercu_maj()
    tc = time.perf_counter()
    if k not in (2, 3, 4, 6, 7) and k < 100 and tc - _drag.get('to', 0.0) >= 0.12:      # fenetres refaites au plus ~8 fois par seconde pendant le glisser
        _drag['to'] = tc
        _ov_maj()
    _ov_assurer()
    td = time.perf_counter()
    for kk, p, _o, _d, _v in _poignees_toutes():
        g = _pastilles.get(kk)
        if g is not None:
            g.placer(p)
    te = time.perf_counter()
    vp.refresh()
    tf = time.perf_counter()
    ch = _drag.setdefault('chrono', [0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])      # resume au lacher (journal)
    for i, d in enumerate((ta - t0, tb - ta, tc - tb, td - tc, te - td, tf - te)):
        ch[i + 1] += d
    ch[0] += 1


# --- Selection --------------------------------------------------------------------------------------------

def _bloquer_selection(inputs):
    _bloc['t'] = time.time()
    sel = inputs.itemById('arete')
    _bloc['sel'] = [sel.selection(i).entity for i in range(sel.selectionCount)]


_multi_foc = {'sel': None}


def _figer_multi(inputs):
    """Plusieurs aretes selectionnees : le champ n'est pas pris pour 'plein' par Fusion, qui lance son rectangle
    et remplace la selection au clic sur la poignee. On retire alors le focus du champ pendant le glisser
    (la selection est conservee, rien ne peut etre clique derriere) ; remis au relachement."""
    _multi_foc['sel'] = None
    try:
        sel = inputs.itemById('arete')
        # aussi a 0 arete (Fusion l'a deselectionnee juste avant le clic) : champ vide = rectangle de selection
        # au glisser de la poignee (Maxence 2026-11-16)
        if sel is not None and sel.selectionCount != 1 and sel.hasFocus:
            _en_cours['v'] = True
            try:
                sel.hasFocus = False
            finally:
                _en_cours['v'] = False
            _multi_foc['sel'] = sel
            _log('glisser multi : focus du champ retire (%d aretes)' % sel.selectionCount)
    except Exception:
        _log('figer multi : ' + traceback.format_exc()[-200:])


def _figer_multi_rendre():
    sel, _multi_foc['sel'] = _multi_foc['sel'], None
    if sel is None:
        return
    _en_cours['v'] = True
    try:
        sel.hasFocus = True
    except Exception:
        pass
    finally:
        _en_cours['v'] = False


def _restaurer_selection(inputs):
    """Un clic sur une fenetre ou une poignee ne doit rien selectionner derriere : on remet l'arete d'avant."""
    if _bloc['sel'] is None or (time.time() - _bloc['t'] > 10.0 and not _drag.get('k')):
        if _bloc['sel'] is not None:
            _log('selection : remise refusee (%.1f s)' % (time.time() - _bloc['t']))
        return False
    sel = inputs.itemById('arete')
    cur = [sel.selection(i).entity for i in range(sel.selectionCount)]
    try:
        if sorted(e.entityToken for e in cur) == sorted(e.entityToken for e in _bloc['sel']):
            return True
    except Exception:
        pass
    _log('selection : arete remise (%d -> %d)' % (len(cur), len(_bloc['sel'])))
    _en_cours['v'] = True               # les evenements des ajouts un a un (plusieurs aretes) sont ignores
    try:
        sel.clearSelection()
        for e in _bloc['sel']:
            try:
                sel.addSelection(e)
            except Exception:
                pass
    finally:
        _en_cours['v'] = False
    _garde_basculer(inputs)             # Fusion revalide (OK)
    return True


def _pos_voulue():
    """Position memorisee (cm) : expression saisie (parametre) ou valeur."""
    pe = _s.get('pos_expr')
    if pe:
        v = _eval_expr(pe)
        if v is not None:
            return v
    return _s.get('pos')


def _lire_selection(inputs, garder=False):
    """Arete choisie -> contexte et detections. garder : reglages conserves (modification, inversions)."""
    global _ctx
    sel = inputs.itemById('arete')
    if sel.selectionCount == 0:
        _ctx = {'ok': False}
        return
    s0 = sel.selection(0)
    e = s0.entity
    clic = None
    try:
        p = s0.point
        clic = (p.x, p.y, p.z)
    except Exception:
        clic = None
    pos = _pos_voulue() if garder else None
    if not garder:
        _s['pos_expr'] = ''
    _ctx = _contexte(_design(), e, clic, pos, bool(_s.get('sens')), bool(_s.get('inv')), _ignores())
    if _ctx.get('ok'):
        if pos is None:
            _repere(_ctx, round(_ctx['s'] * 100.0) / 100.0)          # 0,1 mm pres
        _s['pos'] = _ctx['s']
        _s['edge'] = e.entityToken
    if not garder:
        _s['L_auto'] = True
        _s['L_saisie'] = False
        _s['H_auto'] = True
        _s['H_saisie'] = False
        for b in _s['b']:
            b['auto'] = True
    _saisie['row'] = None


def _lire_selection_jeton(design, ins):
    """Apres une suppression dans la chronologie, l'arete et ses faces sont relues par leur jeton."""
    global _ctx
    try:
        r = design.findEntityByToken(_s.get('edge') or '')
        if r:
            _ctx = _contexte(design, r[0], None, _pos_voulue(), bool(_s.get('sens')), bool(_s.get('inv')))
    except Exception:
        _log('relecture arete : ' + traceback.format_exc()[-300:])


def _ignores():
    ed = _edition['v']
    return set(ed.get('corps', [])) if ed else None


# --- Rafraichissement --------------------------------------------------------------------------------------

def _rafraichir(inputs, poignees=True):
    _cur['ep'] = _ep_cm(inputs)
    if _ctx.get('ok') and _s.get('dist_on') and _drag.get('k') is None:
        try:
            _dist_appliquer()
        except Exception:
            _log('distance : ' + traceback.format_exc()[-300:])
    _cur['calc'] = _calc()
    _sym_maj()
    try:
        # message seulement s'il y a quelque chose a faire (les mesures sont dans les fenetres)
        cc = _cur['calc']
        msg = cc['msg']
        if cc.get('ok') and not cc.get('tn_manque') and not cc.get('piece'):
            msg = ''
        if _sym_actif() and not _sym_ok():
            msg = (msg + ' ' if msg else '') + _tt('(symetrie : une piece ne trouve pas sa place sur le contour ou '
                                                   'est invalide, changez l\'entraxe ou le nombre)')
        if time.time() - _confirm.get('t', 0.0) < 6.0 and _confirm.get('txt'):
            msg = _confirm['txt'] + ('\n' + msg if msg else '')     # piece qui vient d'etre enregistree
        tb = inputs.itemById('msg')
        if tb.text != msg:                  # un champ change = un cycle d'apercu Fusion : seulement si besoin
            tb.text = msg
        if tb.isVisible != bool(msg):
            tb.isVisible = bool(msg)
    except Exception:
        pass
    if poignees:
        _maj_pastilles()
    _ov_maj()
    _apercu_maj()
    _rafraichir_vue()
    try:        # trace : fenetres ou poignees absentes signalees le 2026-11-11 (cas non reproduit)
        g = _ov['g']
        _log('apercu : ctx %s %s raison %s, calc %s, fenetres %s, poignees %s' % (
            _ctx.get('ok'), _ctx.get('kind'), _ctx.get('raison'), (_cur['calc'] or {}).get('ok'),
            bool(g is not None and g.isValid), sorted(_pastilles)))
    except Exception:
        pass


def _appliquer(fn, inputs, poignees=True):
    _en_cours['v'] = True
    try:
        fn()
        _rafraichir(inputs, poignees)
    finally:
        _en_cours['v'] = False


def _set_val(inp, expr, cm):
    try:
        if expr and _eval_expr(expr) is not None:
            inp.expression = expr
        elif cm is not None:
            inp.value = cm
    except Exception:
        try:
            if cm is not None:
                inp.value = cm
        except Exception:
            pass


def _sync_champs(inputs):
    """Les champs de la boite suivent les reglages (modifies par la fenetre, les poignees, le clavier)."""
    calc = _cur['calc'] or _calc()
    inputs.itemById('L_auto').value = bool(_s['L_auto'])
    inputs.itemById('H_auto').value = bool(_s['H_auto'])
    _set_val(inputs.itemById('L'), None if _s['L_auto'] else _s['L_expr'], calc.get('L'))
    _set_val(inputs.itemById('H'), None if _s['H_auto'] else _s['H_expr'], calc.get('H'))
    pm = bool(_s.get('piece'))
    for gid in ('grp_tn',):
        try:
            inputs.itemById(gid).isVisible = not pm
        except Exception:
            pass
    if _ctx.get('ok'):
        _set_val(inputs.itemById('pos'), _s.get('pos_expr') or None, _ctx.get('s'))
    inputs.itemById('inv').value = bool(_s['inv'])
    inputs.itemById('sens').value = bool(_s['sens'])
    try:
        inputs.itemById('axes').value = bool(_s.get('axes'))
        inputs.itemById('axe').listItems.item(AXES_NOMS.index(_s.get('axe') or '')).isSelected = True
        inputs.itemById('para').value = bool(_s.get('para', True))
        inputs.itemById('para').isVisible = bool(_s.get('axe'))
        inputs.itemById('sym2').value = bool(_s.get('sym2'))
        inputs.itemById('sym2').isVisible = bool(_s.get('axe'))
    except Exception:
        pass
    try:
        inputs.itemById('sym').value = bool(_s.get('sym'))
        inputs.itemById('sym_nb').value = max(1, int(_s.get('sym_nb') or 1))
        inputs.itemById('sym_e').value = float(_s.get('sym_e') or 20.0)
    except Exception:
        pass
    for i in (0, 1):
        b = _s['b'][i]
        inputs.itemById('b%d_type' % i).listItems.item(TYPES.index(b['type'])).isSelected = True
        inputs.itemById('b%d_tan' % i).listItems.item(TANS.index(b['tan'])).isSelected = True
        inputs.itemById('b%d_auto' % i).value = bool(b['auto'])
        eff = (calc.get('bouts') or [None, None])[i]
        _set_val(inputs.itemById('b%d_d' % i), None if b['auto'] else b['expr'], eff[2] if eff else None)
        inputs.itemById('b%d_tan' % i).isEnabled = b['type'] != 'droite'
        inputs.itemById('b%d_d' % i).isEnabled = b['type'] != 'droite'
        try:
            hi = inputs.itemById('b%d_h' % i)
            if hi is not None:
                _set_val(hi, _b_hexpr(b), getattr(eff, 'h', None))
                hi.isVisible = b['type'] == 'conge'
        except Exception:
            pass
    for k in ('tn_dessus', 'tn_dessous', 'tn_cotes', 'mortaise_auto', 'marge_auto'):
        inputs.itemById(k).value = bool(_s[k])
    inputs.itemById('tn_nb').value = int(_s['tn_nb'])
    inputs.itemById('tn_len').value = _s['tn_len'] / 10.0
    inputs.itemById('tn_h').value = _s['tn_h'] / 10.0
    try:
        inputs.itemById('tn_h_auto').value = bool(_s.get('tn_h_auto', True))
    except Exception:
        pass
    inputs.itemById('tn_bord').value = _s['tn_bord'] / 10.0
    inputs.itemById('tn_bord').isEnabled = _s.get('tn_place') == 'bord'
    inputs.itemById('tn_place').listItems.item(1 if _s.get('tn_place') == 'bord' else 0).isSelected = True
    _garde_basculer(inputs)


def _garde_basculer(inputs):
    """Change un champ cache : Fusion relance la validation (OK grise pendant une saisie au clavier)."""
    try:
        g = inputs.itemById('garde')
        g.value = not g.value
    except Exception:
        pass


# --- Epaisseur (CPxx), comme Traverses de dossier ------------------------------------------------------------

NC_CP = {'CP10': 1.0, 'CP15': 1.5, 'CP18': 1.8}


def _ep_noms(design):
    noms = list(NC_CP)
    try:
        ups = design.userParameters
        for i in range(ups.count):
            n = ups.item(i).name
            if n.upper().startswith('CP') and n not in noms:
                noms.append(n)
    except Exception:
        pass
    return noms


def _ep_cm_nom(design, nom):
    p = design.allParameters.itemByName(nom)
    return p.value if p is not None else NC_CP.get(nom, 1.8)


def _ep_remplir(dd, design, defaut_cm, nom_defaut=None):
    trouve = False
    for n in _ep_noms(design):
        cm = _ep_cm_nom(design, n)
        sel = (not trouve) and ((nom_defaut is not None and n == nom_defaut) or
                                (nom_defaut is None and abs(cm - defaut_cm) < 1e-4))
        trouve = trouve or sel
        dd.listItems.add('%s (%s mm)' % (n, ('%.2f' % (cm * 10.0)).rstrip('0').rstrip('.')), sel, '')
    dd.listItems.add('Autre...', not trouve, '')
    return trouve


def _ep_cm(inputs):
    try:
        dd = inputs.itemById('ep_dd')
        if dd.selectedItem.index == dd.listItems.count - 1:
            return max(0.01, inputs.itemById('ep_autre').value)
        design = _design()
        return max(0.01, _ep_cm_nom(design, _ep_noms(design)[dd.selectedItem.index]))
    except Exception:
        return max(0.01, load_prefs()['epaisseur_mm'] / 10.0)


def _cp_nom_valeur(design, ep_cm, prefere=None):
    """Audit des parametres (2026-11-16) : une epaisseur deja enregistree est reutilisee, jamais recreee. Ordre :
    le parametre attendu (prefere, puis CPxx, xx = mm) s'il a cette valeur, sinon tout autre parametre CP* de meme
    valeur ; a defaut, nom a creer CPxx (CP18, CP12_5). Si ce nom est deja pris par une AUTRE valeur (CP18 passe a
    18,3 mm), un 0 est ajoute (CP18_0 = 18,0 mm) : on ne reprend jamais une valeur fausse."""
    nom = 'CP' + ('%g' % round(ep_cm * 10.0, 2)).replace('.', '_')
    cands = []
    try:
        ups = design.userParameters
        for i in range(ups.count):
            q = ups.item(i)
            if q.name.upper().startswith('CP') and abs(q.value - ep_cm) < 1e-4:
                cands.append(q.name)
    except Exception:
        pass
    for n in (prefere, nom):
        if n and n in cands:
            return n
    if cands:
        return cands[0]
    while design.allParameters.itemByName(nom) is not None:
        nom += '0' if '_' in nom else '_0'
    return nom


def _ep_parametre(design, inputs, ep_cm):
    nom = None
    try:
        dd = inputs.itemById('ep_dd')
        if dd.selectedItem.index < dd.listItems.count - 1:
            nom = _ep_noms(design)[dd.selectedItem.index]
    except Exception:
        nom = None
    if nom is None or design.allParameters.itemByName(nom) is None:
        nom = _cp_nom_valeur(design, ep_cm, nom)       # meme valeur deja en parametre : reutilisee
    if design.allParameters.itemByName(nom) is None:
        design.userParameters.add(nom, adsk.core.ValueInput.createByReal(ep_cm), 'mm', 'Epaisseur contreplaque')
    return nom


# --- Evenements de la commande ------------------------------------------------------------------------------

class _PreSelectHandler(adsk.core.SelectionEventHandler):
    """Rien n'est preselectionnable sous une poignee, sous les fenetres, ni pendant un glisser."""
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            if _drag.get('k') is not None:
                args.isSelectable = False
                return
            vp, pos = _souris.get('vp'), _souris.get('pos')
            if vp is None or pos is None:
                return
            r, _z = _ov_zone(vp, pos)
            if r is not None:
                args.isSelectable = False
                return
            if _axe_touche(vp, pos) is not None:
                # sous un axe de la forme : le clic choisit l'axe, il ne doit pas (de)selectionner l'arete
                args.isSelectable = False
                return
            rr = 16.0 * _dpr()
            for g in _pastilles.values():
                if g.p is None:
                    continue
                q = vp.modelToViewSpace(adsk.core.Point3D.create(*g.p))
                if math.hypot(q.x - pos.x, q.y - pos.y) <= rr:
                    args.isSelectable = False
                    return
        except Exception:
            pass


def _activer_row(r, ins):
    _actif['row'] = r
    _saisie['row'] = None
    _saisie['txt'] = ''


def _commencer_saisie(ins, haut=False):
    r = ROWS[_actif['row']]
    if _s.get('piece') and r != 'P':
        return                                  # piece de la bibliotheque : ses mesures sont fixes
    if (r == 'N' and _sym_nb() < 2) or r == 'T':
        return                                  # une seule traverse : pas d'entraxe
    if haut and r in ('D0', 'D1') and _conge_eff(int(r[1])):
        r = r + 'h'                             # hauteur du conge
    _saisie['row'] = r
    _saisie['txt'] = ''


def _valider_saisie(ins):
    r, txt = _saisie['row'], _saisie['txt'].strip()
    _saisie['row'] = None
    _saisie['txt'] = ''
    if not txt:
        return
    expr = txt.replace(',', '.')
    try:
        float(expr)
        expr = expr + ' mm'
    except Exception:
        pass
    if _eval_expr(expr) is None:
        _log('saisie invalide : ' + expr)
        return
    if r == 'N':
        _s['sym_e'] = max(0.1, _eval_expr(expr))
        _sym_recaler()
    elif r == 'P':
        _s['pos_expr'] = expr if _est_param(expr) else ''
        _deplacer(_eval_expr(expr))
        _sym_apres_glisser()
    elif r == 'L':
        _s['L_auto'] = False
        _s['L_saisie'] = True
        _s['L_expr'] = expr
        _s['L_delta'] = 0.0             # longueur donnee : le reglage + / - repart de 0
    elif r == 'H':
        _s['H_auto'] = False
        _s['H_saisie'] = True
        _s['H_expr'] = expr
    elif r == 'M':
        _s['dist_expr'] = expr                  # distance a l'extremite de la base
        _s['dist_on'] = True
        if _dist_dispo():
            _dist_orienter()
            if not _s.get('dist_cote'):
                _s['dist_cote'] = _dist_cote_auto(_ctx)
    elif r in ('D0h', 'D1h'):
        bl = _b_liste_sel(True)
        if r == 'D1h':
            _detacher_fin(bl)
        bl[int(r[1])]['hexpr'] = expr          # hauteur du conge
    else:
        if r == 'D1':
            _detacher_fin(_b_liste_sel(True))
        if _corps_i() == 0:
            _poignee_set(3 if r == 'D0' else 4, 0.1)        # fige le type effectif
        b = _b_liste_sel(True)[int(r[1])]
        b['auto'] = False
        b['expr'] = expr


_touche = {'vu': {}}


def _touches_pm():
    """{code: +1 / -1} : touches + et - (clavier et pave numerique ; codes Qt 43 et 45)."""
    K = adsk.core.KeyCodes
    d = {43: 1, 45: -1}
    for nom, v in (('PlusKeyCode', 1), ('MinusKeyCode', -1), ('NumPadPlusKeyCode', 1), ('NumPadMinusKeyCode', -1),
                   ('AddKeyCode', 1), ('SubtractKeyCode', -1)):
        c = getattr(K, nom, None)
        if isinstance(c, int):
            d[c] = v
    return d


CHAMPS_AUTO = {'L': 'L_auto', 'H': 'H_auto', 'b0_d': 'b0_auto', 'b1_d': 'b1_auto',
               'tn_h': 'tn_h_auto'}            # mesure -> case du mode automatique (saisie « A »)


def _saisie_auto(inp):
    """« A » (ou « a ») tape dans un champ de mesure qui a un mode automatique : le mode automatique est
    choisi (Maxence 2026-11-17). Le champ quitte le « A » et reprend sa valeur."""
    try:
        if str(inp.expression or '').strip().lower() not in ('a', 'auto'):
            return False
        inp.value = inp.value
        return True
    except Exception:
        return False


def _valider_auto(ins):
    """Touche A dans la fenetre active : sa mesure repasse en automatique (longueur, hauteur, retrait du bout).
    False si la fenetre active n'a pas de mode automatique (la saisie en cours est alors gardee)."""
    r = _saisie['row'] or ROWS[_actif['row']]
    if _s.get('piece') or r not in ('L', 'H', 'D0', 'D1'):
        return False
    _saisie['row'] = None
    _saisie['txt'] = ''
    if r == 'L':
        _s['L_auto'] = True
        _s['L_saisie'] = False
    elif r == 'H':
        _s['H_auto'] = True
        _s['H_saisie'] = False
    else:
        bl = _b_liste_sel(True)
        i = int(r[1])
        if i == 1 and bl[1].get('type') == 'miroir':
            i = 0                               # fin en miroir : elle suit le debut
        bl[i]['auto'] = True
    return True


class _KeyHandler(adsk.core.KeyboardEventHandler):
    """Saisie au clavier dans la fenetre active : chiffres, point/virgule, retour arriere, Entree.
    relache=True : branche sur keyUp, ne traite que les touches dont l'appui n'est pas arrive (pave numerique)."""
    def __init__(self, relache=False): super().__init__(); self.relache = relache
    def notify(self, args):
        try:
            ins = args.firingEvent.sender.commandInputs
            if not _ctx.get('ok'):
                return
            K = adsk.core.KeyCodes
            kc = args.keyCode
            vu = _touche['vu']
            if self.relache:
                # pave numerique 1, 2, 3 : Fusion garde l'appui pour lui, seul le relachement arrive ici
                t = vu.pop(kc, None)
                if t is not None and time.time() - t < 5.0:
                    return
                if not (48 <= kc <= 57 or kc in (K.PeriodKeyCode, K.CommaKeyCode) or kc in _touches_pm()):
                    return                      # relachement : chiffres, point, + et - seulement
                _log('clavier : touche %d vue seulement au relachement (mod %s)' % (
                    kc, getattr(args, 'modifierMask', '?')))
            else:
                vu[kc] = time.time()
            pm = _touches_pm()
            if kc in pm and _saisie['row'] is None:
                # + / - : 1 mm de plus ou de moins sur la longueur de toutes les pieces (remis a 0 a chaque creation)
                _s['L_delta'] = round((_s.get('L_delta') or 0.0) + 0.1 * pm[kc], 4)
                _log('clavier : longueur %s (touche %d)' % (_delta_txt() or '0', kc))
                _appliquer(lambda: _sync_champs(ins), ins, True)
                return
            chiffres = {getattr(K, 'D%dKeyCode' % i): str(i) for i in range(10)}
            ch = None
            if kc in chiffres:
                ch = chiffres[kc]
            elif kc in (K.PeriodKeyCode, K.CommaKeyCode):
                ch = '.'
            if ch is not None:
                if _saisie['row'] is None:
                    _commencer_saisie(ins)
                _saisie['txt'] += ch
                _appliquer(lambda: None, ins, False)
                _valider_si_change(ins)
                return
            # touche A : mesure de la fenetre active en automatique. Fusion lance aussi son raccourci Apparence
            # (qui ferme Traverse) tant que A lui est attribue ; sinon : Entree sans valeur (Maxence 2026-11-17)
            if kc == getattr(K, 'AKeyCode', 65) and _valider_auto(ins):
                _log('clavier : A -> mesure automatique')
                _appliquer_leger(ins)
                return
            if _saisie['row'] is None:
                return
            if kc not in (K.BackspaceKeyCode, K.DeleteKeyCode, K.ReturnKeyCode, K.EnterKeyCode, K.EscapeKeyCode):
                _log('clavier : touche %d ignoree pendant la saisie (mod %s)' % (kc, getattr(args, 'modifierMask', '?')))
            if kc in (K.BackspaceKeyCode, K.DeleteKeyCode):
                # Fusion traite aussi Retour arriere comme « supprimer la selection » : l'arete est remise
                _bloquer_selection(ins)
                _saisie['txt'] = _saisie['txt'][:-1]
                _appliquer(lambda: None, ins, False)
                _valider_si_change(ins)
                _redessiner_differe()
            elif kc in (K.ReturnKeyCode, K.EnterKeyCode):
                if not _saisie['txt'].strip() and _valider_auto(ins):
                    _log('clavier : Entree sans valeur -> mesure automatique')
                else:
                    _valider_saisie(ins)
                _appliquer_leger(ins)
            elif kc == K.EscapeKeyCode:
                _saisie['row'] = None
                _saisie['txt'] = ''
                _appliquer(lambda: None, ins, False)
                _valider_si_change(ins)
        except Exception:
            _log('clavier erreur ' + traceback.format_exc()[-400:])


class _MouseHandler(adsk.core.MouseEventHandler):
    def __init__(self, nom): super().__init__(); self.nom = nom
    def notify(self, args):
        try:
            _souris.update(pos=args.viewportPosition, vp=args.viewport, t=time.perf_counter())
            if _drag.get('k') is not None and self.nom == 'mouseDrag':
                d0 = _drag.get('pd')
                p = args.viewportPosition
                if d0 is not None and not _drag.get('bouge'):
                    if math.hypot(p.x - d0[0], p.y - d0[1]) < 4.0 * _dpr():
                        return
                    _drag['bouge'] = True
                _glisser_souris(args.viewport)
            elif self.nom == 'mouseMove' and _drag.get('k') is None:
                _lat_souris()
                _survol_maj(args.viewport, args.viewportPosition)
                _tip_maj(args.viewport, args.viewportPosition)
            elif _drag.get('k') is None:
                _lat_souris()                       # vue tournee / deplacee (bouton du milieu)
        except Exception:
            pass


class _MouseDownHandler(adsk.core.MouseEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            ins = args.firingEvent.sender.commandInputs
            vp, pos = args.viewport, args.viewportPosition
            _souris.update(pos=pos, vp=vp, t=time.perf_counter())
            _tip_effacer()
            if args.button != adsk.core.MouseButtons.LeftMouseButton:
                return
            try:                                  # Ctrl + clic sur une arete : elle s'ajoute a la chaine
                _souris['ctrl'] = bool(args.keyboardModifiers & adsk.core.KeyboardModifiers.CtrlKeyboardModifier)
            except Exception:
                _souris['ctrl'] = False
            r, z = _ov_zone(vp, pos)
            if r is not None:
                _bloquer_selection(ins)          # un clic sur une fenetre ne change jamais la selection Fusion
                try:
                    self._clic(ins, r, z)
                finally:
                    _bloc['t'] = time.time()
                    _redessiner_differe()
                return
            _bloc['sel'] = None
            if _caf is None:
                return
            k = _pastille_touchee(vp, pos)
            if k is not None:
                _bloquer_selection(ins)
                _ch_ech.clear()
                _ch_ent.clear()
                _drag.update(k=k, tm=0.0, bouge=False, pd=(pos.x, pos.y), td=time.perf_counter(), h=None, to=0.0,
                             fig=_caf.selections_figer(ins, 'plein'))
                _figer_multi(ins)
                return
            ib = _bout_touche(vp, pos)
            if ib is not None:
                # clic sur un bout de l'apercu : forme suivante (meme ordre que le bouton des fenetres)
                _bloquer_selection(ins)
                try:
                    _cur['ep'] = _ep_cm(ins)
                    _bout_suivant(ib)
                    _activer_row(ROWS.index('D%d' % ib), ins)
                    _appliquer_leger(ins)
                finally:
                    _bloc['t'] = time.time()
                    _redessiner_differe()
                return
            nom = _axe_touche(vp, pos)
            if nom is not None:
                # clic sur un axe de la forme : la traverse devient parallele a cet axe (re-clic : perpendiculaire)
                # Ctrl + clic sur l'autre axe : symetrie aussi sur celui-ci (les traverses sont recopiees de
                # l'autre cote), Ctrl + re-clic l'enleve (Maxence 2026-11-11)
                _bloquer_selection(ins)
                try:
                    ctrl = bool(args.keyboardModifiers & adsk.core.KeyboardModifiers.CtrlKeyboardModifier)
                except Exception:
                    ctrl = False
                try:
                    if ctrl and _s.get('axe') and nom != _s.get('axe'):
                        _s['sym2'] = not _s.get('sym2')
                        _choisir_axe(_s['axe'], ins)
                    else:
                        _s['sym2'] = False
                        _choisir_axe('' if _s.get('axe') == nom else nom, ins)
                finally:
                    # le calcul peut depasser 1 s : la remise de l'arete (deselectionnee par ce clic) reste permise
                    _bloc['t'] = time.time()
                    _redessiner_differe()
        except Exception:
            _log('mouseDown erreur ' + traceback.format_exc()[-400:])

    def _clic(self, ins, r, z):
        _cur['ep'] = _ep_cm(ins)
        if r == -1:                         # selecteur de corps : precedent / suivant
            n = _corps_n()
            if n > 1 and z in ('moins', 'plus'):
                _corps['i'] = (_corps_i() + (1 if z == 'plus' else -1)) % n
                _log('corps selectionne : %d / %d' % (_corps['i'] + 1, n))
                _ov['sig'] = None
                _apercu['sig'] = None
                _appliquer_leger(ins)
            return
        nom = ROWS[r]
        if nom == 'NM':
            # nom de la piece : la boite s'ouvre au RELACHEMENT du clic (ouverte pendant l'appui, Fusion prenait le
            # relachement pour un rectangle de selection, Maxence 2026-11-14)
            _activer_row(r, ins)
            _nom_attente['v'] = True
            _appliquer_leger(ins)
            return
        if nom == 'T':
            if z in ('tn_dessus', 'tn_dessous', 'tn_cotes'):
                _s[z] = not _s.get(z)
            elif z in ('tn_moins', 'tn_plus'):
                _s['tn_nb'] = max(1, min(20, int(_s.get('tn_nb') or 1) + (1 if z == 'tn_plus' else -1)))
            elif z == 'tn_place':
                _s['tn_place'] = 'bord' if _s.get('tn_place', 'centre') != 'bord' else 'centre'
            _activer_row(r, ins)
            _appliquer_leger(ins)
            return
        if z == 'orient':
            _s['para'] = not _s.get('para', True)
            _activer_row(r, ins)
            _choisir_axe(_s['axe'], ins)
            return
        if nom == 'N' and z == 'ligne' and _sym_nb() == 1 and _s.get('axe'):
            _activer_row(r, ins)
            _appliquer(lambda: (_sym_actif_axe() and _sym_placer(0.0), _sync_champs(ins)), ins, True)
            return
        if z in ('moins', 'plus'):
            _nb_traverses(_sym_nb() + (1 if z == 'plus' else -1), ins)
            _activer_row(r, ins)
            _appliquer(lambda: _sync_champs(ins), ins, True)
            return
        if nom == 'M':
            # distance a l'extremite de la base
            if z == 'tan':
                _s['dist_on'] = not _s.get('dist_on')
            elif z == 'type':
                if _s.get('dist_on') and _s.get('dist_cote'):
                    _s['dist_cote'] = -int(_s['dist_cote'])
                _s['dist_on'] = True
            else:
                _s['dist_on'] = True
            if _s['dist_on'] and _dist_dispo():
                _dist_orienter()
                if not _s.get('dist_cote'):
                    _s['dist_cote'] = _dist_cote_auto(_ctx)
            _activer_row(r, ins)
            if z == 'ligne':
                _commencer_saisie(ins)
            _appliquer_leger(ins)
            return
        if z == 'type' and nom in ('D0', 'D1'):
            _bout_suivant(int(nom[1]))
        elif z == 'tan' and nom in ('D0', 'D1'):
            if nom == 'D1':
                _detacher_fin(_b_liste_sel(True))
            b = _b_liste_sel(True)[int(nom[1])]
            if b['type'] == 'auto':
                eff = (_calc_sel().get('bouts') or [None, None])[int(nom[1])]
                b['type'] = eff[0] if eff and eff[0] != 'droite' else 'arc'
            b['tan'] = 'dessus' if b['tan'] == 'dessous' else 'dessous'
            if b['tan'] == 'dessus':
                b['auto'] = False
        _activer_row(r, ins)
        if z == 'ligne':
            _commencer_saisie(ins)
        elif z == 'haut':
            _commencer_saisie(ins, True)
        _appliquer_leger(ins)


def _bout_suivant(i):
    """Forme suivante du bout i de la piece choisie (bouton de forme des fenetres, clic sur le bout dans l'apercu)."""
    bl = _b_liste_sel(True)
    ordre = ORDRE_TYPES[i]
    t0 = bl[i]['type']
    if i == 1 and t0 == 'miroir':
        _detacher_fin(bl)                       # la fin quitte le miroir avec les reglages du debut
    b = bl[i]
    b['type'] = ordre[(ordre.index(t0) + 1) % len(ordre)] if t0 in ordre else ordre[0]


# --- Bouts de l'apercu cliquables (2026-11-13) : clic = forme suivante, survol = bout en jaune -------------------
_survol = {'i': None, 't': 0.0}
JAUNE_SURVOL = (255, 200, 60, 255)


def _bout_polys(c, calc):
    """[(i, [polyligne monde face 1, face 2])] des courbes des deux bouts de l'apercu."""
    out = []
    if not c.get('ok') or not calc or calc.get('piece') or calc.get('L') is None or calc.get('H') is None \
            or not calc.get('bouts'):
        return out
    L, H = calc['L'], calc['H']
    a0 = calc.get('a0') or 0.0
    e = _cur['ep'] / 2.0
    for i, bt in enumerate(calc['bouts']):
        typ, tan, d, _det = bt
        if typ != 'droite' and d <= 1e-6:
            typ = 'droite'
        try:
            g = _bout_geo(typ, tan, d, H, getattr(bt, 'h', None))
        except Exception:
            continue
        loc = g[2]
        if i == 1:
            loc = [(L - x, y) for x, y in loc]
        out.append((i, [[_pt(c, a0 + x, y, z) for x, y in loc] for z in (-e, e)]))
    return out


def _bout_touche(vp, pos):
    """Bout (0 / 1) de la piece principale sous la souris, ou None."""
    calc = _cur.get('calc')
    if _caf is None or not _ctx.get('ok') or not calc or _corps_i() != 0:
        return None
    r = 8.0 * _dpr()
    P = adsk.core.Point3D.create
    best = None
    for i, polys in _bout_polys(_ctx, calc):
        for poly in polys:
            sc = [vp.modelToViewSpace(P(*p)) for p in poly]
            for a, b in zip(sc, sc[1:]):
                ex, ey = b.x - a.x, b.y - a.y
                e2 = ex * ex + ey * ey
                t = 0.0 if e2 < 1e-9 else max(0.0, min(1.0, ((pos.x - a.x) * ex + (pos.y - a.y) * ey) / e2))
                d = math.hypot(a.x + ex * t - pos.x, a.y + ey * t - pos.y)
                if d <= r and (best is None or d < best[0]):
                    best = (d, i)
    return best[1] if best else None


def _survol_maj(vp, pos):
    """Survol d'un bout : redessine l'apercu seulement quand le bout survole change (au plus ~30 fois / s)."""
    t = time.perf_counter()
    if t - _survol['t'] < 0.03:
        return
    _survol['t'] = t
    try:
        i = _bout_touche(vp, pos)
    except Exception:
        i = None
    if i != _survol['i']:
        _survol['i'] = i
        _apercu_maj()
        _rafraichir_vue()


def _survol_lignes():
    i = _survol.get('i')
    if i is None:
        return []
    out = []
    for j, polys in _bout_polys(_ctx, _cur.get('calc')):
        if j != i:
            continue
        for poly in polys:
            for a, b in zip(poly, poly[1:]):
                out.extend(a)
                out.extend(b)
    return out


def _choisir_axe(nom, ins):
    _s['axe'] = nom if nom in AXES_NOMS else ''
    if not _s['axe']:
        _s['sym2'] = False
    _cur['ep'] = _ep_cm(ins)

    def f():
        if _ctx.get('ok'):
            _repere(_ctx, _ctx['s'])
            _detecter(_design(), _ctx, _ignores())
            _sym_recaler()
        _sync_champs(ins)
    _appliquer(f, ins, True)


# --- Chrono du relachement d'une poignee (journal) : etapes, cycles Fusion qui suivent, plus long trou entre deux
# mouvements de souris (= vue figee) dans les 4 s ----------------------------------------------------------------
_lat = {'t0': None, 'k': None, 'ev': [], 'tm': None, 'gap': 0.0, 'n': {}}


def _lat_debut(k):
    _lat_fin()
    _lat.update(t0=time.perf_counter(), k=k, ev=[], tm=None, gap=0.0, n={})


def _lat_note(nom, compter=False):
    if _lat['t0'] is None:
        return
    dt = time.perf_counter() - _lat['t0']
    if dt > 4.0:
        _lat_fin()
        return
    if compter:
        _lat['n'][nom] = _lat['n'].get(nom, 0) + 1
    else:
        _lat['ev'].append('%s %d' % (nom, int(dt * 1000)))


def _lat_souris():
    if _lat['t0'] is None:
        return
    t = time.perf_counter()
    if t - _lat['t0'] > 4.0:
        _lat_fin()
        return
    if _lat['tm'] is not None:
        _lat['gap'] = max(_lat['gap'], t - _lat['tm'])
    _lat['tm'] = t


def _lat_fin():
    if _lat['t0'] is None:
        return
    _lat['t0'] = None
    _log('lacher %s : %s ; evenements %s ; plus long arret de la souris ensuite %d ms' % (
        _lat['k'], ', '.join(_lat['ev']), _lat['n'], int(_lat['gap'] * 1000)))


def _appliquer_leger(ins):
    """Clic dans les fenetres : apercu, fenetres et poignees refaits, AUCUN champ de la boite touche (chaque champ
    relance le cycle d'apercu de Fusion) ; la validation (OK) n'est relancee que si elle change."""
    _appliquer(lambda: None, ins, True)
    _valider_si_change(ins)


def _valider_si_change(ins):
    """Relance la validation (OK) seulement si son resultat change."""
    try:
        c = _cur['calc']
        v = bool(c and c.get('ok')) and _sym_ok() and _saisie['row'] is None and not _dist_bloque()
        if v != (_bloc.get('val') or (None,))[0]:
            _garde_basculer(ins)
            _lat_note('validation relancee')
    except Exception:
        _garde_basculer(ins)


_nom_attente = {'v': False}


def _saisir_nom(ins):
    """Boite de saisie du nom de la piece, ouverte apres le relachement du clic sur la fenetre NOM ; la selection
    (arete, chaine) est figee pendant la boite puis remise telle quelle (aucun rectangle, rien de (de)selectionne)."""
    _bloquer_selection(ins)
    fig = None
    try:
        if _caf is not None:
            fig = _caf.selections_figer(ins, 'plein')
    except Exception:
        fig = None
    calc = _cur.get('calc') or {}
    try:
        # champ vide, pret a taper : nom + Entree ; Annuler ou vide = nom inchange (Maxence 2026-11-16)
        txt, annule = _ui.inputBox(_tt('Nouveau nom de la piece :'), _tt('Nom de la piece'), '')
        txt = (txt or '').strip()[:80]
        if not annule and txt:
            _s['enreg_nom'] = '' if txt == _nom_piece_defaut(calc) else txt
    except Exception:
        _log('nom piece : ' + traceback.format_exc()[-200:])
    finally:
        try:
            if _caf is not None and fig is not None:
                _caf.selections_rendre(fig)
        except Exception:
            pass
        _bloc['t'] = time.time()
        _ov['sig'] = None
        _appliquer_leger(ins)
        _redessiner_differe()                    # l'arete est remise si Fusion l'a deselectionnee


class _MouseUpHandler(adsk.core.MouseEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            ins = args.firingEvent.sender.commandInputs
            if _nom_attente['v']:
                _nom_attente['v'] = False
                _saisir_nom(ins)
                return
            k = _drag.get('k')
            if k is None:
                return
            bouge = _drag.get('bouge')
            fig = _drag.get('fig')
            ch = _drag.pop('chrono', None)
            if ch and ch[0]:
                _log('glisser %s chrono %d pas, ms/pas : prep %.1f calc %.1f apercu %.1f fenetres %.1f poignees %.1f refresh %.1f' % (
                    k, ch[0], *[1000.0 * v / ch[0] for v in ch[1:]]))
            _drag['k'] = None
            _drag['h'] = None
            _bloc['t'] = time.time()
            if _caf is not None and fig is not None:
                _caf.selections_rendre(fig)
            _figer_multi_rendre()
            if bouge and k == 5:
                _deplacer(_ctx.get('s'))           # position lachee : detections relancees a cet endroit
            # poignee cliquee (ou lachee) : sa mesure se tape tout de suite au clavier, Entree applique sans creer
            # la piece (OK grise des le clic, pas a la 1re touche ; Maxence 2026-11-13)
            try:
                kk = k % 100 if k >= 100 else k
                if k >= 100 and k // 100 < _corps_n():
                    _corps['i'] = k // 100                # piece en symetrie : ses propres bouts
                    _ov['sig'] = None
                elif k < 100 and k in (3, 4, 6, 7) and _corps.get('i'):
                    _corps['i'] = 0                       # poignee de la piece principale
                    _ov['sig'] = None
                cible = {2: ('H', False), 3: ('D0', False), 4: ('D1', False), 6: ('D0', True),
                         7: ('D1', True)}.get(kk)
                if kk == 5 and _s.get('dist_on'):
                    cible = ('M', False)
                if cible is not None and cible[0] in ROWS:
                    _activer_row(ROWS.index(cible[0]), ins)
                    _commencer_saisie(ins, cible[1])
                elif not bouge and PAST_ROW.get(k) is not None:
                    _activer_row(PAST_ROW[k], ins)
            except Exception:
                _log('saisie poignee : ' + traceback.format_exc()[-200:])
            _lat_debut(k)
            try:
                if bouge and k == 5:
                    _sym_apres_glisser()
                _lat_note('detections')
                if k in (2, 3, 4, 5, 6, 7) or k >= 100:
                    # poignee lachee : aucun champ de la boite n'est touche (chaque changement de champ relance le
                    # cycle d'apercu de Fusion, qui figeait la vue 1 a 2 s sur un gros document, Maxence 2026-11-13) ;
                    # la validation n'est relancee que si OK doit changer d'etat
                    _appliquer(lambda: None, ins, True)
                    _lat_note('rafraichir')
                    _valider_si_change(ins)
                else:
                    _appliquer(lambda: _sync_champs(ins), ins, True)
                    _lat_note('champs')
            finally:
                # le calcul (detections, pieces en symetrie) peut depasser 1 s : la remise de l'arete,
                # deselectionnee par le relachement, doit rester permise (OK grise, Maxence 2026-11-11)
                _bloc['t'] = time.time()
                _redessiner_differe()
        except Exception:
            _log('mouseUp erreur ' + traceback.format_exc()[-400:])


class _RedrawHandler(adsk.core.CustomEventHandler):
    """Redessin differe : un groupe cree PENDANT un clic de souris disparait (Fusion traite le clic ensuite)."""
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            if not _redraw['on']:
                return
            try:
                cmd = _cmd['c']
                if cmd is not None and _bloc['sel'] and _drag.get('k') is None:
                    sel = cmd.commandInputs.itemById('arete')
                    if sel is not None and sel.selectionCount == 0 and time.time() - _bloc['t'] < 10.0:
                        _log('selection : arete remise au redessin')
                        _en_cours['v'] = True
                        try:
                            for e in _bloc['sel']:
                                sel.addSelection(e)
                        finally:
                            _en_cours['v'] = False
                        _garde_basculer(cmd.commandInputs)
            except Exception:
                _log('remise redessin : ' + traceback.format_exc()[-200:])
            _ov['sig'] = None
            _ov_maj()
            _apercu_maj(force=True)
            _maj_pastilles()
            _rafraichir_vue()
            _lat_note('redessin')
        except Exception:
            _log('redraw erreur ' + traceback.format_exc()[-300:])


def _evt(store, ident, cls):
    if store['evt'] is None:
        try:
            _app.unregisterCustomEvent(ident)
        except Exception:
            pass
        store['evt'] = _app.registerCustomEvent(ident)
        store['h'] = cls()
        store['evt'].add(store['h'])


def _redessiner_differe():
    try:
        for _essai in (0, 1):
            _evt(_redraw, REDRAW_ID, _RedrawHandler)
            if _app.fireCustomEvent(REDRAW_ID, ''):
                break
            _redraw['evt'] = None          # evenement mort (add-in relance depuis un script) : reenregistre
    except Exception:
        _log('redessiner differe : ' + traceback.format_exc()[-200:])


class _InputChangedHandler(adsk.core.InputChangedEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            inp = args.input
            ins = inp.parentCommand.commandInputs
            iid = inp.id
            _lat_note('champ', True)
            if _en_cours['v'] or iid == 'garde':
                return
            if iid in CHAMPS_AUTO and _saisie_auto(inp):
                # « A » dans la mesure : sa case automatique est cochee, traite comme un clic sur la case
                _en_cours['v'] = True
                try:
                    inp = ins.itemById(CHAMPS_AUTO[iid])
                    inp.value = True
                finally:
                    _en_cours['v'] = False
                iid = inp.id
            if iid == 'nouveau':
                _nc_differer()
                return
            if iid == 'piece_mod':
                e = _piece()
                if e is not None and e['d'].get('src') == 'reseau':
                    # piece de Reseau CNC : elle se modifie dans la fenetre « Nouvel objet » de Reseau CNC
                    R = _module('ReseauTrajectoireCNC')
                    if R is None or not hasattr(R, 'modifier_piece_externe'):
                        _ui.messageBox(_tt('Cette piece vient de Reseau CNC : demarrez Reseau CNC pour la modifier.'),
                                       COMMAND_NAME)
                    else:
                        R.modifier_piece_externe(e['body'].entityToken, CMD_ID)
                    return
                if e is not None:
                    ed, vals = _piece_edition(e)
                    if vals:
                        _nc['a_ouvrir'] = (ed, vals)
                        _nc_differer()
                    else:
                        _ui.messageBox(_tt('Cette piece n\'a pas de reglages memorises : elle ne peut pas etre '
                                           'modifiee dans la fenetre.'), COMMAND_NAME)
                return
            if iid == 'enreg_btn':
                # la commande est validee en mode « piece » : OK habituel, mais rien n'est pose
                c = _cur.get('calc') or {}
                if _saisie['row'] is not None:
                    _valider_saisie(ins)
                    c = _calc()
                    _cur['calc'] = c
                if not (_ctx.get('ok') and c.get('ok')) or _s.get('piece'):
                    _ui.messageBox(_tt('Cliquez d\'abord une arete et reglez une traverse valide (pas une piece de la '
                                       'liste).'), COMMAND_NAME)
                    return
                # Fusion refuse doExecute depuis un bouton : les reglages sont figes ici, la commande est fermee
                # (l'apercu disparait), puis la piece est creee juste apres, hors de la commande (Maxence 2026-11-14)
                try:
                    ep = _ep_cm(ins)
                    _cur['ep'] = ep
                    v = _piece_valeurs(_design(), None, c, ep)
                    v['ep'] = None
                    _enreg_apres.update(v=v, ep=ep)
                    _evt(_enreg_evt, ENREG_ID, _EnregHandler)
                    if not _app.fireCustomEvent(ENREG_ID, ''):
                        _enreg_evt['evt'] = None
                        _evt(_enreg_evt, ENREG_ID, _EnregHandler)
                        _app.fireCustomEvent(ENREG_ID, '')
                except Exception:
                    _log('enregistrer piece : ' + traceback.format_exc()[-300:])
                return
            if iid == 'piece':
                k = inp.selectedItem.index if inp.selectedItem else 0
                ps = _pieces()
                _s['piece'] = ps[k - 1]['body'].entityToken if 0 < k <= len(ps) else None
                try:
                    ins.itemById('piece_mod').isVisible = bool(_s['piece'])
                except Exception:
                    pass
                _cur['ep'] = _ep_cm(ins)
                _appliquer(lambda: (_lire_selection(ins, garder=True), _sync_champs(ins)), ins, True)
                return
            if iid == 'arete':
                _piece_liste_sync(ins.itemById('piece'))
                if _restaurer_selection(ins):
                    _en_cours['v'] = True
                    try:
                        _rafraichir(ins)
                    finally:
                        _en_cours['v'] = False
                    return
                _cur['ep'] = _ep_cm(ins)
                sl = ins.itemById('arete')
                ents = [sl.selection(i).entity for i in range(sl.selectionCount)]
                if len(ents) > 1:
                    toks = [e.entityToken for e in ents]
                    if _souris.get('ctrl') and _ctx.get('ok') and _s.get('edge') in toks:
                        # Ctrl + clic : l'arete s'ajoute a la chaine, la traverse reste ou elle est
                        _s['aretes'] = [t for t in toks if t != _s['edge']]
                        _log('chaine : %d aretes selectionnees' % len(toks))
                        _en_cours['v'] = True
                        try:
                            _rafraichir(ins)
                        finally:
                            _en_cours['v'] = False
                        return
                    if not _souris.get('ctrl') and _bloc['sel'] is None:
                        # clic simple : la nouvelle arete remplace la selection
                        _en_cours['v'] = True
                        try:
                            sl.clearSelection()
                            sl.addSelection(ents[-1])
                        finally:
                            _en_cours['v'] = False

                def f():
                    _s['aretes'] = []
                    _lire_selection(ins)
                    _sym_recaler()
                    _sync_champs(ins)
                _appliquer(f, ins, True)
                return
            ok = True
            if iid == 'axes':
                _s['axes'] = bool(inp.value)
                if not _s['axes']:
                    _s['axe'] = ''
                try:
                    p = load_prefs()
                    p['axes'] = _s['axes']
                    save_prefs(p)
                except Exception:
                    pass
                _choisir_axe(_s['axe'], ins)
                return
            if iid == 'sym2':
                _s['sym2'] = bool(inp.value) and bool(_s.get('axe'))
                _choisir_axe(_s.get('axe') or '', ins)
                return
            if iid == 'para':
                _s['para'] = bool(inp.value)
                _choisir_axe(_s.get('axe') or '', ins)
                return
            if iid in ('sym', 'sym_nb', 'sym_e'):
                if iid == 'sym':
                    _s['sym'] = bool(inp.value)
                elif iid == 'sym_nb':
                    _s['sym_nb'] = max(1, int(inp.value))
                elif inp.isValidExpression:
                    _s['sym_e'] = max(0.1, inp.value)
                else:
                    return
                _cur['ep'] = _ep_cm(ins)
                _appliquer(lambda: (_sym_recaler(), _sync_champs(ins)), ins, True)
                return
            if iid == 'axe':
                k = inp.selectedItem.index if inp.selectedItem else 0
                if k:
                    _s['axes'] = True
                _choisir_axe(AXES_NOMS[k], ins)
                return
            if iid in ('inv', 'sens'):
                _s[iid] = bool(inp.value)
                _cur['ep'] = _ep_cm(ins)
                _appliquer(lambda: (_lire_selection(ins, garder=True), _sync_champs(ins)), ins, True)
                return
            if iid == 'pos':
                if inp.isValidExpression and _ctx.get('ok'):
                    _s['pos_expr'] = inp.expression if _est_param(inp.expression) else ''
                    _cur['ep'] = _ep_cm(ins)
                    _appliquer(lambda: (_deplacer(inp.value), _sym_apres_glisser(), _sync_champs(ins)), ins, True)
                return
            if iid == 'L_auto':
                _s['L_auto'] = bool(inp.value)
                if _s['L_auto']:
                    _s['L_saisie'] = False
            elif iid == 'L':
                if inp.isValidExpression:
                    _s['L_auto'] = False
                    _s['L_saisie'] = True
                    _s['L_expr'] = inp.expression
                    _s['L_delta'] = 0.0             # longueur donnee : le reglage + / - repart de 0
            elif iid == 'H_auto':
                _s['H_auto'] = bool(inp.value)
                if _s['H_auto']:
                    _s['H_saisie'] = False
            elif iid == 'H':
                if inp.isValidExpression:
                    _s['H_auto'] = False
                    _s['H_saisie'] = True
                    _s['H_expr'] = inp.expression
            elif iid in ('b0_type', 'b1_type'):
                _s['b'][int(iid[1])]['type'] = TYPES[inp.selectedItem.index if inp.selectedItem else 0]
            elif iid in ('b0_tan', 'b1_tan'):
                _s['b'][int(iid[1])]['tan'] = TANS[inp.selectedItem.index if inp.selectedItem else 0]
            elif iid in ('b0_auto', 'b1_auto'):
                _s['b'][int(iid[1])]['auto'] = bool(inp.value)
            elif iid in ('b0_d', 'b1_d'):
                if inp.isValidExpression:
                    b = _s['b'][int(iid[1])]
                    b['auto'] = False
                    b['expr'] = inp.expression
            elif iid in ('b0_h', 'b1_h'):
                if inp.isValidExpression:
                    _s['b'][int(iid[1])]['hexpr'] = inp.expression
            elif iid in ('tn_dessus', 'tn_dessous', 'tn_cotes', 'mortaise_auto', 'marge_auto'):
                _s[iid] = bool(inp.value)
            elif iid == 'tn_nb':
                _s['tn_nb'] = max(1, int(inp.value))
            elif iid == 'tn_place':
                _s['tn_place'] = 'bord' if (inp.selectedItem and inp.selectedItem.index == 1) else 'centre'
            elif iid in ('tn_len', 'tn_h', 'tn_bord'):
                _s[iid] = max(0.1, inp.value * 10.0)
                if iid == 'tn_h':
                    _s['tn_h_auto'] = False
            elif iid == 'tn_h_auto':
                _s['tn_h_auto'] = bool(inp.value)
            elif iid in ('ep_dd', 'ep_autre'):
                dd = ins.itemById('ep_dd')
                ins.itemById('ep_autre').isVisible = (dd.selectedItem.index == dd.listItems.count - 1)
                _cur['ep'] = _ep_cm(ins)

                def f_ep():                     # la longueur depend de l'epaisseur (mesuree aux coins)
                    if _ctx.get('ok'):
                        _detecter(_design(), _ctx, _ignores())
                        _sym_recaler()
                    _sync_champs(ins)
                _appliquer(f_ep, ins, True)
                return
            else:
                ok = False
            if ok:
                _appliquer(lambda: _sync_champs(ins), ins, True)
        except Exception:
            _log('inputChanged erreur ' + traceback.format_exc()[-600:])


class _PreviewHandler(adsk.core.CommandEventHandler):
    """executePreview : Fusion annule ce qui a ete cree pendant l'evenement precedent : on redessine s'il le faut."""
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            _lat_note('apercu Fusion', True)
            if _cur['calc'] is not None and _drag.get('k') is None:
                _ov_assurer()
                _apercu_maj()
                _maj_pastilles()
        except Exception:
            _log('preview erreur ' + traceback.format_exc()[-300:])


class _ValidateHandler(adsk.core.ValidateInputsEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            _lat_note('validation', True)
            c = _cur['calc']
            # pendant une saisie de cote, OK reste grise : Entree valide la cote sans creer la piece
            v = bool(c and c.get('ok')) and _sym_ok() and _saisie['row'] is None and not _dist_bloque()
            args.areInputsValid = v
            # trace : OK grise apres la poignee (Maxence 2026-11-11)
            cle = (v, bool(_ctx.get('ok')), bool(c and c.get('ok')), _sym_ok())
            if cle != _bloc.get('val'):
                _bloc['val'] = cle
                sel = args.inputs.itemById('arete')
                _log('validation : ok %s (ctx %s, calc %s, sym %s, arete %d)' % (
                    cle + (sel.selectionCount if sel else -1,)))
        except Exception:
            args.areInputsValid = False


# --- Creation ---------------------------------------------------------------------------------------------

def _blob(ep_cm):
    d = {k: _s[k] for k in CLES if k in _s}
    d['edge'] = _s.get('edge')
    return json.dumps({'v': 1, 's': d, 'ep': ep_cm, 'ep_nom': _cur.get('ep_nom')})


def _vers_comp(design):
    """Transformation monde -> composant actif (None si racine)."""
    occ = design.activeOccurrence
    if occ is None:
        return None
    m = occ.transform2.copy()
    m.invert()
    return m


def _nom_libre(comp, base):
    noms = set(comp.bRepBodies.item(i).name for i in range(comp.bRepBodies.count))
    k = 1
    while '%s %d' % (base, k) in noms:
        k += 1
    return '%s %d' % (base, k)


def _expr_ou(expr, cm):
    return expr if (expr and _eval_expr(expr) is not None) else _mm_txt(cm)


def _plan_axe(design, comp, c, loc):
    """Traverse parallele a un axe de la forme : esquisse « Axes forme » sur la face d'appui (axe en travers, fixe),
    plan normal a cet axe a la distance du point de l'arete (parametrique : distance le long de l'axe)."""
    c.pop('dist_param_ok', None)
    if _s.get('dist_on') and c.get('dist_ref') and _s.get('dist_cote'):
        try:
            pl = _plan_distance(design, comp, c, loc)
            if pl is not None:
                c['dist_param_ok'] = True
                return pl
        except Exception:
            _log('plan distance : ' + traceback.format_exc()[-400:])
    ax = _axes_forme(c)
    autre = 'larg' if c['axe'] == 'long' else 'long'
    d, t0, t1 = ax[autre]
    if _v_dot(d, c['w']) < 0:
        d, t0, t1 = _v_mul(d, -1.0), -t1, -t0
    marge = 0.1 * (t1 - t0) + 1.0
    A = _v_add(ax['o'], _v_mul(d, t0 - marge))
    B = _v_add(ax['o'], _v_mul(d, t1 + marge))
    f = c['f_app']
    try:
        if design.activeOccurrence is not None and f.assemblyContext is None:
            f = f.createForAssemblyContext(design.activeOccurrence)
    except Exception:
        pass
    ska = comp.sketches.add(f)
    ska.name = _tt('Axes forme')
    P3 = adsk.core.Point3D.create

    def ts(p):
        q = ska.modelToSketchSpace(loc(p))
        return P3(q.x, q.y, 0.0)
    for e in list(ska.sketchCurves):                 # les aretes projetees automatiquement : retirees
        try:
            e.deleteMe()
        except Exception:
            pass
    ln = ska.sketchCurves.sketchLines.addByTwoPoints(ts(A), ts(B))
    ln.isConstruction = True
    ln.isFixed = True
    try:
        ska.isVisible = False
    except Exception:
        pass
    dist = _v_dot(_v_sub(c['S'], A), d)
    Pp = loc(c['S'])
    # composant active dans un assemblage : Path.create refuse la ligne native (getObjectPath, Maxence
    # 2026-11-11, FS210) : on essaie la ligne native puis sa version dans le contexte de l'occurrence active
    lignes = [ln]
    try:
        if design.activeOccurrence is not None:
            lignes.append(ln.createForAssemblyContext(design.activeOccurrence))
    except Exception:
        pass
    path0 = None
    err = None
    for lg in lignes:
        try:
            path0 = adsk.fusion.Path.create(lg, adsk.fusion.ChainedCurveOptions.noChainedCurves)
            break
        except Exception as x:
            err = x
    if path0 is None:
        raise err
    for ex in (_mm_txt(dist), _mm_txt(max(0.0, _d3(A, B) - dist))):
        path = path0
        pi = comp.constructionPlanes.createInput()
        if not pi.setByPath(path, adsk.fusion.PathDistanceTypes.PhysicalPathDistanceType,
                            adsk.core.ValueInput.createByString(ex)):
            continue
        pl = comp.constructionPlanes.add(pi)
        g = pl.geometry
        o, nv = g.origin, g.normal
        if abs((Pp.x - o.x) * nv.x + (Pp.y - o.y) * nv.y + (Pp.z - o.z) * nv.z) < 0.005:
            return pl
        pl.deleteMe()
    raise RuntimeError('plan parallele a l\'axe impossible')


def _dist_parametre(design):
    """Parametre utilisateur de la distance (DIST_DOSSIER, DIST_DOSSIER_2...) : celui de la piece modifiee est
    repris, sinon un nouveau ; sa valeur = la distance saisie (nombre ou expression)."""
    ups = design.userParameters
    nom = _s.get('dist_param')
    expr = _s.get('dist_expr') or '170 mm'
    p = ups.itemByName(nom) if nom else None
    if p is None:
        nom, k = 'DIST_DOSSIER', 2
        while design.allParameters.itemByName(nom) is not None:
            nom = 'DIST_DOSSIER_%d' % k
            k += 1
        p = ups.add(nom, adsk.core.ValueInput.createByString(expr), 'mm',
                    _tt('Distance entre la traverse et l\'extremite de la base (Traverse corps CNC)'))
    else:
        p.expression = expr
    _s['dist_param'] = nom
    return nom


def _plan_distance(design, comp, c, loc):
    """Traverse parallele a l'axe en mode DISTANCE : esquisse « Distance mousse » sur la face d'appui ; l'arete de
    la base au point extreme est projetee, une ligne d'appui lui est tangente (perpendiculaire a l'epaisseur de la
    traverse), le chemin part de cette ligne vers l'interieur ; plan a DIST_DOSSIER + epaisseur / 2 sur ce chemin.
    Changer DIST_DOSSIER (Modifier > Parametres) deplace la traverse."""
    cote = float(_s['dist_cote'])
    g, Pe = _dist_ecart(c, cote)
    if Pe is None:
        return None
    S, u, w = c['S'], c['u'], _dist_w(c)
    f = c['f_app']
    # arete de la base qui porte le point extreme
    best = None
    lp = None
    for i in range(f.loops.count):
        if f.loops.item(i).isOuter:
            lp = f.loops.item(i)
    lp = lp or f.loops.item(0)
    P3 = adsk.core.Point3D.create
    for i in range(lp.edges.count):
        e = lp.edges.item(i)
        try:
            ok, prm = e.evaluator.getParameterAtPoint(P3(*Pe))
            ok2, q = e.evaluator.getPointAtParameter(prm)
            d = q.distanceTo(P3(*Pe)) if ok and ok2 else 1e9
        except Exception:
            d = 1e9
        if best is None or d < best[0]:
            best = (d, e)
    if best is None or best[0] > 0.05:
        return None
    arete = best[1]
    try:
        if design.activeOccurrence is not None:
            if f.assemblyContext is None:
                f = f.createForAssemblyContext(design.activeOccurrence)
            if arete.assemblyContext is None:
                arete = arete.createForAssemblyContext(design.activeOccurrence)
    except Exception:
        pass
    sk = comp.sketches.add(f)
    sk.name = _tt('Distance mousse')
    ok_fin = False
    try:
        for e in list(sk.sketchCurves):
            try:
                e.deleteMe()
            except Exception:
                pass

        def ts(p):
            q = sk.modelToSketchSpace(loc(p))
            return P3(q.x, q.y, 0.0)
        res = sk.project(arete)
        E = None
        for k in range(res.count):
            if isinstance(res.item(k), adsk.fusion.SketchCurve):
                E = res.item(k)
        if E is None:
            return None
        lines = sk.sketchCurves.sketchLines
        gc, dims = sk.geometricConstraints, sk.sketchDimensions
        AL = adsk.fusion.DimensionOrientations.AlignedDimensionOrientation
        vin = _v_mul(w, -cote)                    # de l'extremite vers l'interieur
        ax = _axes_forme(c)
        span = (ax['long'][2] - ax['long'][1]) + 4.0 if ax else 400.0
        Fl = lines.addByTwoPoints(ts(_v_add(Pe, _v_mul(vin, -2.0))), ts(_v_add(Pe, _v_mul(vin, span))))
        Fl.isConstruction = True
        Fl.isFixed = True
        R = lines.addByTwoPoints(ts(Pe), ts(_v_add(Pe, _v_mul(u, 3.0))))
        R.isConstruction = True
        coin = None                               # point extreme sur un coin de la base : la ligne y passe
        pe_sk = ts(Pe)
        for sp in (getattr(E, 'startSketchPoint', None), getattr(E, 'endSketchPoint', None)):
            try:
                if sp is not None and sp.geometry.distanceTo(pe_sk) < 0.01:
                    coin = sp
            except Exception:
                pass
        if coin is not None:
            gc.addCoincident(R.startSketchPoint, coin)
        elif isinstance(E, adsk.fusion.SketchLine):
            gc.addCoincident(R.startSketchPoint, E)   # bord droit perpendiculaire a l'epaisseur
        else:
            cco = gc.addCoincident(R.startSketchPoint, E)
            try:
                gc.addTangent(R, E)
            except Exception:
                # certaines courbes de base (splines) refusent la tangence (« invalid geometry », FS210
                # 2026-11-13) : la ligne d'appui est figee sur le point extreme (sinon elle glisserait sur la courbe)
                _log('distance : tangence refusee, ligne d\'appui figee sur le point extreme')
                try:
                    cco.deleteMe()
                except Exception:
                    pass
                R.startSketchPoint.isFixed = True
        gc.addPerpendicular(R, Fl)
        dims.addDistanceDimension(R.startSketchPoint, R.endSketchPoint, AL, ts(_v_add(Pe, _v_mul(u, 1.5))))
        ln = lines.addByTwoPoints(ts(Pe), ts(_v_add(Pe, _v_mul(vin, span))))
        ln.isConstruction = True
        gc.addCoincident(ln.startSketchPoint, R)
        gc.addCollinear(ln, Fl)
        ln.endSketchPoint.isFixed = True
        nom = _dist_parametre(design)
        ep_nom = _cur.get('ep_nom')
        ep_ex = ep_nom if (ep_nom and design.allParameters.itemByName(ep_nom) is not None) else _mm_txt(_cur['ep'])
        c['dist_ep_ex'] = ep_ex
        # (les bouts sont accroches par _dist_plans_faces, apres le plan : coupe de la base par les plans des faces)
        c.pop('dist_bouts_sk', None)
        try:
            bo = None
            if bo is not None:
                courbes = {}
                for i2 in range(lp.edges.count):
                    e2 = lp.edges.item(i2)
                    if e2.entityToken == best[1].entityToken:
                        courbes[i2] = E
                        continue
                    try:
                        if design.activeOccurrence is not None and e2.assemblyContext is None:
                            e2 = e2.createForAssemblyContext(design.activeOccurrence)
                        r2 = sk.project(e2)
                        for k2 in range(r2.count):
                            if isinstance(r2.item(k2), adsk.fusion.SketchCurve):
                                courbes[i2] = r2.item(k2)
                    except Exception:
                        _log('projection contour : ' + traceback.format_exc()[-150:])
                traces = {}
                for sgn in set([bo[2][0][0], bo[2][1][0]]):
                    fc = _dist_face_coupes(c, sgn, None)
                    if fc is None or fc[0][2] not in courbes or fc[1][2] not in courbes:
                        raise RuntimeError('trace de face sans contour')
                    FA = lines.addByTwoPoints(ts(fc[0][1]), ts(fc[1][1]))
                    FA.isConstruction = True
                    gc.addParallel(FA, R)
                    gc.addCoincident(FA.startSketchPoint, courbes[fc[0][2]])
                    gc.addCoincident(FA.endSketchPoint, courbes[fc[1][2]])
                    od = dims.addOffsetDimension(FA, R, ts(_v_add(fc[0][1], _v_mul(u, 2.0))))
                    od.parameter.expression = nom if cote * sgn > 0 else '%s + %s' % (nom, ep_ex)
                    traces[sgn] = FA
                c['dist_bouts_sk'] = (traces[bo[2][0][0]].startSketchPoint, traces[bo[2][1][0]].endSketchPoint)
        except Exception:
            _log('traces distance : ' + traceback.format_exc()[-300:])
        lignes = [ln]
        try:
            if design.activeOccurrence is not None:
                lignes.append(ln.createForAssemblyContext(design.activeOccurrence))
        except Exception:
            pass
        Pp = loc(S)
        for lg in lignes:
            try:
                path = adsk.fusion.Path.create(lg, adsk.fusion.ChainedCurveOptions.noChainedCurves)
            except Exception:
                continue
            pi = comp.constructionPlanes.createInput()
            if not pi.setByPath(path, adsk.fusion.PathDistanceTypes.PhysicalPathDistanceType,
                                adsk.core.ValueInput.createByString('%s + %s / 2' % (nom, ep_ex))):
                continue
            pl = comp.constructionPlanes.add(pi)
            gg = pl.geometry
            o, nv = gg.origin, gg.normal
            if abs((Pp.x - o.x) * nv.x + (Pp.y - o.y) * nv.y + (Pp.z - o.z) * nv.z) < 0.01:
                try:
                    sk.isVisible = False
                    pl.isLightBulbOn = False
                except Exception:
                    pass
                ok_fin = True
                _log('distance : plan parametrique %s + %s / 2' % (nom, ep_ex))
                return pl
            _log('distance : plan hors de la traverse (%.2f mm)' % (10.0 * abs((Pp.x - o.x) * nv.x + (Pp.y - o.y) * nv.y +
                                                                                 (Pp.z - o.z) * nv.z)))
            pl.deleteMe()
        return None
    finally:
        if not ok_fin:
            try:
                sk.deleteMe()
            except Exception:
                pass


def _dist_plans_faces(design, comp, c, plan, loc):
    """Mode DISTANCE : plans des deux faces de la traverse (decales de +/- epaisseur / 2 du plan de la traverse,
    donc ils la suivent) ; chacun coupe la face de la base (esquisse « Coupe face ») : Fusion recalcule cette coupe
    sur tout le contour, quelle que soit la courbe touchee. A chaque bout, le point de coupe de la face la plus a
    l'interieur est retenu (aucun coin dehors) ; _dessiner y accroche les bouts de la traverse (Maxence
    2026-11-13 : les bouts sortaient de la base quand DIST_DOSSIER changeait)."""
    c.pop('dist_bouts_sk', None)
    bo = _dist_bornes(c, None)
    if bo is None:
        return
    f = _dist_face(c)
    try:
        if design.activeOccurrence is not None and f.assemblyContext is None:
            f = f.createForAssemblyContext(design.activeOccurrence)
    except Exception:
        pass
    ep_ex = c.get('dist_ep_ex') or _mm_txt(_cur['ep'])
    S, u, w = c['S'], c['u'], _dist_w(c)
    Sl = loc(S)
    M = _vers_comp(design)

    def vec(v):                                   # direction monde -> composant
        q = adsk.core.Vector3D.create(*v)
        if M is not None:
            q.transformBy(M)
        return (q.x, q.y, q.z)
    wl, ul = vec(w), vec(u)
    faces = {}
    for signe in ('', '-'):
        pi = comp.constructionPlanes.createInput()
        pi.setByOffset(plan, adsk.core.ValueInput.createByString('%s(%s) / 2' % (signe, ep_ex)))
        pf = comp.constructionPlanes.add(pi)
        try:
            pf.isLightBulbOn = False
        except Exception:
            pass
        g = pf.geometry.origin
        sgn = 1.0 if ((g.x - Sl.x) * wl[0] + (g.y - Sl.y) * wl[1] + (g.z - Sl.z) * wl[2]) > 0 else -1.0
        skf = comp.sketches.add(pf)
        skf.name = _tt('Coupe face')
        for e in list(skf.sketchCurves):
            try:
                e.deleteMe()
            except Exception:
                pass
        res = skf.intersectWithSketchPlane([f])
        lns = [adsk.fusion.SketchLine.cast(x) for x in res if adsk.fusion.SketchLine.cast(x) is not None]
        if not lns:
            continue
        # la coupe qui passe au pied de la traverse (la plus longue si la base a des trous)
        ln = max(lns, key=lambda x: x.length)
        pts = []
        for sp in (ln.startSketchPoint, ln.endSketchPoint):
            q = skf.sketchToModelSpace(sp.geometry)
            pts.append(((q.x - Sl.x) * ul[0] + (q.y - Sl.y) * ul[1] + (q.z - Sl.z) * ul[2], sp))
        pts.sort(key=lambda x: x[0])
        faces[sgn] = (pts[0][1], pts[-1][1])
        try:
            skf.isVisible = False
        except Exception:
            pass
    s0, s1 = bo[2][0][0], bo[2][1][0]             # face la plus a l'interieur au debut / a la fin
    if s0 in faces and s1 in faces:
        c['dist_bouts_sk'] = (faces[s0][0], faces[s1][1])
        _log('distance : coupes des faces (debut %+d, fin %+d)' % (s0, s1))


def _plan_normal(design, comp, c, loc):
    """Plan de construction normal a l'arete a la position de la traverse (parametrique : distance le long de
    l'arete, l'expression saisie si c'est un parametre). Le sens du chemin est verifie (sinon Ltot - s)."""
    if c.get('para') and c.get('axe') in ('long', 'larg') and _axes_forme(c) is not None:
        return _plan_axe(design, comp, c, loc)
    s, Ltot = c['s'], c['Ltot']
    pe = _s.get('pos_expr')
    e1 = pe if (pe and _est_param(pe) and _eval_expr(pe) is not None) else _mm_txt(s)
    P = loc(c['S'])

    def essai(ex):
        path = adsk.fusion.Path.create(c['ent'], adsk.fusion.ChainedCurveOptions.noChainedCurves)
        pi = comp.constructionPlanes.createInput()
        if not pi.setByPath(path, adsk.fusion.PathDistanceTypes.PhysicalPathDistanceType,
                            adsk.core.ValueInput.createByString(ex)):
            return None, None
        pl = comp.constructionPlanes.add(pi)
        g = pl.geometry
        o, nv = g.origin, g.normal
        d = abs((P.x - o.x) * nv.x + (P.y - o.y) * nv.y + (P.z - o.z) * nv.z)
        if d < 0.005:
            return pl, o
        o = adsk.core.Point3D.create(o.x, o.y, o.z)
        pl.deleteMe()
        return None, o
    for ex in (e1, _mm_txt(max(0.0, Ltot - s))):
        pl, _o = essai(ex)
        if pl is not None:
            return pl
    # arete fermee (ovale...) : le chemin ne part pas du debut de l'evaluateur. Son depart est mesure (plan a 0)
    # puis la distance est recalee dans les deux sens (Maxence 2026-11-11, traverses perpendiculaires sur un ovale)
    pl, o = essai('0 mm')
    if pl is not None:
        return pl
    if o is not None:
        occ = design.activeOccurrence
        if occ is not None:
            o.transformBy(occ.transform2)            # composant -> monde (l'evaluateur est en monde)
        s0 = _s_du_point(c, (o.x, o.y, o.z))
        for dd in ((s - s0) % Ltot, (s0 - s) % Ltot):
            pl, _o = essai(_mm_txt(dd))
            if pl is not None:
                return pl
    raise RuntimeError('plan normal a l\'arete impossible')


def _dessiner(sk, c, calc, nc, loc):
    """Mode DISTANCE : le debut de la traverse est decale (a0) sur le contour de la base ; le repere est decale le
    temps du dessin (positions de depart des courbes), les bouts sont ensuite accroches aux traces des faces."""
    a0 = calc.get('a0') or 0.0
    S0 = c['S']
    if a0:
        c['S'] = _v_add(S0, _v_mul(c['u'], a0))
    try:
        return _dessiner_profil(sk, c, calc, nc, loc)
    finally:
        c['S'] = S0


def _dessiner_profil(sk, c, calc, nc, loc):
    """Dessine dans l'esquisse sk le profil entierement contraint de la traverse ; renvoie le plus grand profil."""
    P3 = adsk.core.Point3D.create
    L, H = calc['L'], calc['H']

    def ts(p):
        q = sk.modelToSketchSpace(loc(p))
        return P3(q.x, q.y, 0.0)          # pile dans le plan de l'esquisse (sinon points hors plan, mal contraints)

    # references : point d'intersection de l'arete, ligne d'intersection de la face d'appui (ou du plan de
    # l'esquisse de la courbe)
    I, ref = None, None
    S2 = ts(c['S'])
    u2 = _v_sub(tuple((lambda q: (q.x, q.y, q.z))(ts(_pt(c, 1.0, 0.0)))), (S2.x, S2.y, S2.z))
    a_garder = []
    if nc:
        I = sk.originPoint
    try:
        res = sk.intersectWithSketchPlane([c['ent']]) if not nc else []
        for e in res:
            sp = adsk.fusion.SketchPoint.cast(e)
            if sp is not None and sp.geometry.distanceTo(S2) < 0.01 and I is None:
                I = sp
            elif e is not None:
                a_garder.append(('x', e))
    except Exception:
        _log('intersection arete : ' + traceback.format_exc()[-300:])
    cible = c.get('f_app')
    if not nc:
        try:
            # arete de corps : intersection de la face d'appui ; courbe d'esquisse : sa projection (une ligne
            # en travers, le plan de son esquisse etant perpendiculaire au plan de la traverse)
            res = sk.intersectWithSketchPlane([cible]) if cible is not None else sk.project(c['ent'])
            for e in res:
                ln = adsk.fusion.SketchLine.cast(e)
                ok = False
                if ln is not None and ref is None:
                    a, b = ln.startSketchPoint.geometry, ln.endSketchPoint.geometry
                    d = _v_norm((b.x - a.x, b.y - a.y, 0.0))
                    uu = _v_norm((u2[0], u2[1], 0.0))
                    cr = abs(d[0] * uu[1] - d[1] * uu[0])
                    dist = abs((S2.x - a.x) * d[1] - (S2.y - a.y) * d[0])
                    ok = cr < 1e-3 and dist < 0.005
                if ok:
                    ref = ln
                else:
                    a_garder.append(('x', e))
        except Exception:
            _log('intersection appui : ' + traceback.format_exc()[-300:])
    # haut (et bouts en arc) accroches au corps du dessus, longueur accrochee au corps qui l'arrete : si ces corps
    # bougent, la traverse suit (demande de Maxence le 2026-11-11 : plus de cotes figees en haut)
    refH = refL = None
    H_auto = (not nc) and _s.get('H_auto') and c.get('H_det') is not None and abs(H - c['H_det']) < 1e-4
    L_auto = (not nc) and _s.get('L_auto') and c.get('L_det') is not None and abs(L - c['L_det']) < 1e-4
    for cle, voulu, auto in (('f_H', 'H', H_auto), ('f_L', 'L', L_auto)):
        f = c.get(cle)
        if not auto or f is None:
            continue
        try:
            res = sk.intersectWithSketchPlane([f])
        except Exception:
            _log('intersection %s : %s' % (cle, traceback.format_exc()[-200:]))
            continue
        uu = _v_norm((u2[0], u2[1], 0.0))
        for e in res:
            ln = adsk.fusion.SketchLine.cast(e)
            bon = False
            if ln is not None:
                a, b = ln.startSketchPoint.geometry, ln.endSketchPoint.geometry
                d = _v_norm((b.x - a.x, b.y - a.y, 0.0))
                cr = abs(d[0] * uu[1] - d[1] * uu[0])
                if voulu == 'H' and refH is None and cr < 1e-3:
                    q = ts(_pt(c, L / 2.0, H))            # ligne parallele a l'appui, a la hauteur H
                    bon = abs((q.x - a.x) * d[1] - (q.y - a.y) * d[0]) < 0.01
                    if bon:
                        refH = ln
                elif voulu == 'L' and refL is None and abs(cr - 1.0) < 1e-3:
                    q = ts(_pt(c, L, H / 2.0))            # ligne perpendiculaire, au bout L
                    bon = abs((q.x - a.x) * d[1] - (q.y - a.y) * d[0]) < 0.01
                    if bon:
                        refL = ln
            if not bon:
                a_garder.append(('x', e))
    for ln in (refH, refL):            # references seulement : pas de profils en plus
        if ln is not None:
            try:
                ln.isConstruction = True
            except Exception:
                pass
    for _t, e in a_garder:            # le reste des intersections : retire (ni profils parasites ni fouillis)
        try:
            e.deleteMe()
        except Exception:
            pass
    pb = None                          # mode DISTANCE : bouts sur les traces des faces (esquisse Distance mousse)
    if c.get('dist_param_ok') and c.get('dist_bouts_sk'):
        try:
            ps = []
            for spt in c['dist_bouts_sk']:
                r = sk.project(spt)
                ps.append([r.item(k) for k in range(r.count) if adsk.fusion.SketchPoint.cast(r.item(k))][0])
            I, pb = ps[0], ps[1]
        except Exception:
            _log('bouts distance : ' + traceback.format_exc()[-200:])
    E0, E1 = _pt(c, 0.0, 0.0), _pt(c, L, 0.0)
    E2, E3 = _pt(c, L, H), _pt(c, 0.0, H)
    lines = sk.sketchCurves.sketchLines
    gc = sk.geometricConstraints
    dims = sk.sketchDimensions
    AL = adsk.fusion.DimensionOrientations.AlignedDimensionOrientation
    Bl = lines.addByTwoPoints(I if I is not None else ts(E0), ts(E1))
    R = lines.addByTwoPoints(Bl.endSketchPoint, ts(E2))
    T = lines.addByTwoPoints(R.endSketchPoint, ts(E3))
    Lf = lines.addByTwoPoints(T.endSketchPoint, Bl.startSketchPoint)
    if ref is not None:
        gc.addCollinear(Bl, ref)
    if nc:
        g0, g1 = Bl.startSketchPoint.geometry, Bl.endSketchPoint.geometry
        if abs(g1.x - g0.x) >= abs(g1.y - g0.y):
            gc.addHorizontal(Bl)
        else:
            gc.addVertical(Bl)
    elif I is None or ref is None:
        _log('references incompletes (point %s, ligne %s) : dessous fige' % (I is not None, ref is not None))
        if I is None:
            Bl.startSketchPoint.isFixed = True
        if ref is None:
            Bl.isFixed = True
    gc.addPerpendicular(Bl, Lf)
    if refL is not None:
        gc.addCollinear(R, refL)
    else:
        gc.addPerpendicular(Bl, R)
    if refH is not None:
        gc.addCollinear(T, refH)
    else:
        gc.addParallel(T, Bl)
    lie_L = False
    if pb is not None and refL is None and calc.get('dist_fin_base', True):
        try:
            gc.addCoincident(Bl.endSketchPoint, pb)
            lie_L = True
            _log('distance : bouts accroches aux traces des faces sur la base')
        except Exception:
            _log('bout distance : ' + traceback.format_exc()[-200:])
    if not lie_L and c.get('dist_param_ok') and ref is not None and refL is None and _s.get('L_auto') and \
            not _s.get('L_delta'):
        # mode DISTANCE : le bout de la traverse est accroche au bout de la ligne d'intersection de la face d'appui
        # (le contour de la base) : DIST_DOSSIER change -> la longueur suit la base, les conges ne changent pas
        # (Maxence 2026-11-13)
        try:
            e1 = ts(E1)
            cand = [p for p in (ref.startSketchPoint, ref.endSketchPoint)
                    if I is None or p.geometry.distanceTo(I.geometry) > 0.5]
            p = min(cand, key=lambda x: x.geometry.distanceTo(e1)) if cand else None
            if p is not None and p.geometry.distanceTo(e1) < 3.0:
                gc.addCoincident(Bl.endSketchPoint, p)
                lie_L = True
                _log('distance : longueur accrochee au contour de la base')
        except Exception:
            _log('longueur sur la base : ' + traceback.format_exc()[-200:])
    try:
        if refL is None and not lie_L:
            dL = dims.addDistanceDimension(Bl.startSketchPoint, Bl.endSketchPoint, AL, ts(_pt(c, L / 2.0, -H * 0.25)))
            d = _s.get('L_delta') or 0.0
            if _s['L_auto'] or not d or not _est_param(_s.get('L_expr')):
                dL.parameter.expression = _mm_txt(L) if (_s['L_auto'] or d) else _expr_ou(_s['L_expr'], L)
            else:                       # parametre saisi : le reglage + / - s'ajoute a l'expression
                dL.parameter.expression = '(%s) %s %s' % (_s['L_expr'], '+' if d > 0 else '-', _mm_txt(abs(d)))
        if refH is None:
            dH = dims.addOffsetDimension(Bl, T, ts(_pt(c, -L * 0.06, H / 2.0)))
            dH.parameter.expression = _mm_txt(H) if _s['H_auto'] else _expr_ou(_s['H_expr'], H)
    except Exception:
        _log('expressions L/H : ' + traceback.format_exc()[-300:])
    _dims_debut.clear()
    for i, bt in enumerate(calc['bouts']):
        typ, tan, d, det = bt
        if typ == 'droite' or d <= 1e-6:
            continue
        sgn = 1.0 if i == 0 else -1.0
        x0 = 0.0 if i == 0 else L
        cb = Bl.startSketchPoint if i == 0 else Bl.endSketchPoint
        ch = T.endSketchPoint if i == 0 else T.startSketchPoint
        cote = Lf if i == 0 else R
        if typ == 'conge':
            try:
                _dessiner_conge(sk, c, i, getattr(bt, 'h', None) or 0.0, d, tan, det, H, sgn, x0, cb, ch, cote,
                                Bl, T, refH, ts)
            except Exception:
                _log('conge : ' + traceback.format_exc()[-400:])
                raise
            continue
        if tan == 'dessous':
            depart, coin, ligne = cb, ch, T
            Aw, Qw = _pt(c, x0, 0.0), _pt(c, x0 + sgn * d, H)
            Cw = _pt(c, x0 + sgn * (d * d + H * H) / (2.0 * d), 0.0)
            txt_y = H * 1.12
        else:
            depart, coin, ligne = ch, cb, Bl
            Aw, Qw = _pt(c, x0, H), _pt(c, x0 + sgn * d, 0.0)
            Cw = _pt(c, x0 + sgn * (d * d + H * H) / (2.0 * d), H)
            txt_y = -H * 0.12
        if typ == 'angle':
            cv = lines.addByTwoPoints(depart, ts(Qw))
            q = cv.endSketchPoint
        else:
            r = (d * d + H * H) / (2.0 * d)
            m = _v_add(_v_sub(Aw, Cw), _v_sub(Qw, Cw))
            mn = math.sqrt(_v_dot(m, m)) or 1.0
            Mw = _v_add(Cw, _v_mul(m, r / mn))
            cv = sk.sketchCurves.sketchArcs.addByThreePoints(depart, ts(Mw), ts(Qw))
            qs = ts(Qw)
            q = cv.startSketchPoint if cv.startSketchPoint.geometry.distanceTo(qs) < cv.endSketchPoint.geometry.distanceTo(qs) \
                else cv.endSketchPoint
        pp = None
        if det and tan == 'dessous' and refH is not None:
            # retrait trouve sur le corps du dessus : le bout de l'arc va sur le bord de ce corps (bout de la ligne
            # d'intersection), sans cote
            qg = q.geometry
            pp = min([refH.startSketchPoint, refH.endSketchPoint], key=lambda x: x.geometry.distanceTo(qg))
            if pp.geometry.distanceTo(qg) >= 0.02:
                pp = None
        if typ == 'arc':
            gc.addTangent(cv, cote)
        if pp is not None:
            gc.addCoincident(q, pp)
            continue
        gc.addCoincident(q, ligne)
        dd = dims.addDistanceDimension(coin, q, AL, ts(_pt(c, x0 + sgn * d / 2.0, txt_y)))
        try:
            b = _b_eff(i, _s['b'])
            dd.parameter.expression = _mm_txt(d) if det or b['auto'] else _expr_ou(b['expr'], d)
        except Exception:
            pass
        _lier_miroir(dd, (typ, tan, 'l'), i, d)
    # profil : la plus grande region (les petites sont les chutes entre le bout et l'enveloppe)
    best = None
    for k in range(sk.profiles.count):
        pr = sk.profiles.item(k)
        a = pr.areaProperties(adsk.fusion.CalculationAccuracy.LowCalculationAccuracy).area
        if best is None or a > best[0]:
            best = (a, pr)
    if best is None:
        raise RuntimeError('aucun profil')
    if not sk.isFullyConstrained:
        _log('esquisse non entierement contrainte')
    return best


_dims_debut = {}


def _lier_miroir(dim, cle, i, val):
    """Cote du debut memorisee ; cote de la fin en MIROIR = parametre de la cote du debut (modifier le debut dans
    la chronologie modifie aussi la fin)."""
    try:
        if i == 0:
            _dims_debut[cle] = (dim.parameter, val)
        elif _s['b'][1].get('type') == 'miroir' and cle in _dims_debut:
            p, v0 = _dims_debut[cle]
            if abs(v0 - val) < 1e-6:
                dim.parameter.expression = p.name
    except Exception:
        _log('cote miroir : ' + traceback.format_exc()[-200:])


def _dessiner_conge(sk, c, i, h, d, tan, det, H, sgn, x0, cb, ch, cote, Bl, T, refH, ts):
    """Conge asymetrique (Maxence 2026-11-13) : courbe conique de sommet le coin (donc tangente au cote et au dessus,
    ou au dessous), rho = racine(2) - 1 : quart d'ellipse exact de demi-axes largeur d et hauteur h. Les deux bouts
    sont accroches aux lignes et cotes depuis le coin (largeur, hauteur) : esquisse entierement contrainte."""
    gc, dims = sk.geometricConstraints, sk.sketchDimensions
    AL = adsk.fusion.DimensionOrientations.AlignedDimensionOrientation
    b = _b_eff(i, _s['b'])
    if tan == 'dessous':                 # coin du haut arrondi
        coin, ligne, autre = ch, T, cb
        Pc, Pl = _pt(c, x0, H - h), _pt(c, x0 + sgn * d, H)
        tx_l, tx_c = _pt(c, x0 + sgn * d / 2.0, H * 1.12), _pt(c, x0 - sgn * H * 0.12, H - h / 2.0)
    else:                                # coin du bas arrondi
        coin, ligne, autre = cb, Bl, ch
        Pc, Pl = _pt(c, x0, h), _pt(c, x0 + sgn * d, 0.0)
        tx_l, tx_c = _pt(c, x0 + sgn * d / 2.0, -H * 0.12), _pt(c, x0 - sgn * H * 0.12, h / 2.0)
    plein = h >= H - 1e-6                # hauteur = toute la traverse : le conge part de l'autre coin
    depart = autre if plein else ts(Pc)
    cv = sk.sketchCurves.sketchConicCurves.add(depart, ts(Pl), coin, RHO_CONGE)
    if cv is None:
        raise RuntimeError('courbe conique refusee')
    qc, ql = cv.startSketchPoint, cv.endSketchPoint
    if not plein:
        gc.addCoincident(qc, cote)
    pp = None
    if det and tan == 'dessous' and refH is not None:
        # retrait trouve sur le corps du dessus : la largeur va sur le bord de ce corps, sans cote
        qg = ql.geometry
        pp = min([refH.startSketchPoint, refH.endSketchPoint], key=lambda x: x.geometry.distanceTo(qg))
        if pp.geometry.distanceTo(qg) >= 0.02:
            pp = None
    if pp is not None:
        gc.addCoincident(ql, pp)
    else:
        gc.addCoincident(ql, ligne)
        dd = dims.addDistanceDimension(coin, ql, AL, ts(tx_l))
        try:
            dd.parameter.expression = _mm_txt(d) if det or b['auto'] else _expr_ou(b['expr'], d)
        except Exception:
            pass
        _lier_miroir(dd, ('conge', tan, 'l'), i, d)
    if not plein:
        dh = dims.addDistanceDimension(coin, qc, AL, ts(tx_c))
        try:
            dh.parameter.expression = _expr_ou(_b_hexpr(b), h)
        except Exception:
            pass
        _lier_miroir(dh, ('conge', tan, 'h'), i, h)


def _construire(design, comp, calc, ep_nom):
    """Plan normal a l'arete, esquisse entierement contrainte (intersection de l'arete = coin, intersection de la
    face d'appui = dessous), extrusion symetrique de l'epaisseur. Renvoie (sketch, extrusion, corps)."""
    c = _ctx
    P3 = adsk.core.Point3D.create
    M = _vers_comp(design)

    def loc(p):
        q = P3(*p)
        if M is not None:
            q.transformBy(M)
        return q

    nc = c.get('ent') is None                 # fenetre « Nouveau corps » : plan d'origine, coin a l'origine
    if nc:
        M = None
        plan = {'XY': comp.xYConstructionPlane, 'XZ': comp.xZConstructionPlane,
                'YZ': comp.yZConstructionPlane}[c.get('plan', 'XY')]
    else:
        c.pop('dist_param_ok', None)
        c.pop('dist_bouts_sk', None)
        plan = _plan_normal(design, comp, c, loc)
        try:
            plan.isLightBulbOn = False
        except Exception:
            pass
    if not nc and c.get('dist_param_ok'):
        try:
            _dist_plans_faces(design, comp, c, plan, loc)
        except Exception:
            _log('plans des faces : ' + traceback.format_exc()[-300:])
    sk = comp.sketches.add(plan)
    sk.name = _tt('Traverse corps')
    best = _dessiner(sk, c, calc, nc, loc)
    ei = comp.features.extrudeFeatures.createInput(best[1], adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
    if nc:
        # nouveau corps : l'epaisseur part du plan, du cote w
        o = sk.sketchToModelSpace(P3(0, 0, 0))
        zz = sk.sketchToModelSpace(P3(0, 0, 1))
        nk = (zz.x - o.x, zz.y - o.y, zz.z - o.z)
        sens = adsk.fusion.ExtentDirections.PositiveExtentDirection if _v_dot(nk, c['w']) > 0 else \
            adsk.fusion.ExtentDirections.NegativeExtentDirection
        ei.setOneSideExtent(adsk.fusion.DistanceExtentDefinition.create(
            adsk.core.ValueInput.createByString(ep_nom)), sens)
    else:
        # epaisseur centree sur le point de l'arete (plan au milieu de la traverse)
        ei.setSymmetricExtent(adsk.core.ValueInput.createByString(ep_nom), True)
    ex = comp.features.extrudeFeatures.add(ei)
    corps = ex.bodies.item(0) if ex.bodies.count else None
    if corps is not None:
        corps.name = _nom_libre(comp, _tt('Traverse'))
    if not nc and c.get('dist_ref') and _s.get('dist_on') and not c.get('dist_param_ok'):
        try:
            _dist_esquisse(design, comp, c, calc, loc)
        except Exception:
            _log('esquisse distance : ' + traceback.format_exc()[-400:])
    return sk, ex, corps


def _dist_esquisse(design, comp, c, calc, loc):
    """Esquisse « Distance mousse » sur la face d'appui : ligne d'appui sur le point extreme de la base (parallele a
    la traverse), trace de la face de la traverse, cote entre les deux (cote de reference : la position vient de
    l'outil ; la changer = Modifier dans l'historique, la traverse est recalculee a la nouvelle distance)."""
    cote = float(_s.get('dist_cote') or 1)
    g, P = _dist_ecart(c, cote)
    if P is None:
        return None
    f = _dist_face(c)
    try:
        if design.activeOccurrence is not None and f.assemblyContext is None:
            f = f.createForAssemblyContext(design.activeOccurrence)
    except Exception:
        pass
    sk = comp.sketches.add(f)
    sk.name = _tt('Distance mousse')
    for e in list(sk.sketchCurves):
        try:
            e.deleteMe()
        except Exception:
            pass
    P3 = adsk.core.Point3D.create

    def ts(p):
        q = sk.modelToSketchSpace(loc(p))
        return P3(q.x, q.y, 0.0)
    S, u, w = c['S'], c['u'], _dist_w(c)
    L = calc['L']
    dw = cote * _v_dot(_v_sub(P, S), w)
    du = _v_dot(_v_sub(P, S), u)
    a0, a1 = min(0.0, du) - 2.0, max(L, du) + 2.0
    base = _v_add(S, _v_mul(w, cote * dw))
    face = _v_add(S, _v_mul(w, cote * _cur['ep'] / 2.0))
    lines = sk.sketchCurves.sketchLines
    R = lines.addByTwoPoints(ts(_v_add(base, _v_mul(u, a0))), ts(_v_add(base, _v_mul(u, a1))))
    F = lines.addByTwoPoints(ts(face), ts(_v_add(face, _v_mul(u, L))))
    for ln in (R, F):
        ln.isConstruction = True
        ln.isFixed = True
    pt = sk.sketchPoints.add(ts(P))
    pt.isFixed = True
    try:
        sk.sketchDimensions.addOffsetDimension(F, R, ts(_v_add(_v_add(face, _v_mul(w, cote * g / 2.0)),
                                                              _v_mul(u, L / 2.0))), False)
    except Exception:
        _log('cote distance : ' + traceback.format_exc()[-200:])
    try:
        sk.isVisible = False
    except Exception:
        pass
    return sk


def _module(nom):
    m = sys.modules.get(nom)
    if m is not None:
        return m
    for k, mm in list(sys.modules.items()):
        if k.endswith(nom + '_py'):
            return mm
    return None


def _faces_tenons(corps, calc, M=None, noms=False):
    """Faces planes de la traverse creee : dessus, dessous, cotes droits (noms : [(cote, face)])."""
    c = _ctx

    def vc(v):
        if M is None:
            return v
        q = adsk.core.Vector3D.create(*v)
        q.transformBy(M)
        return (q.x, q.y, q.z)
    res = []
    voulues = []
    if _s['tn_dessus']:
        voulues.append(('dessus', c['n']))
    if _s['tn_dessous']:
        voulues.append(('dessous', _v_mul(c['n'], -1.0)))
    if _s['tn_cotes']:
        for i, (typ, _tan, d, _det) in enumerate(calc['bouts']):
            if typ == 'droite' or d <= 1e-6:
                voulues.append(('cote%d' % i, _v_mul(c['u'], -1.0 if i == 0 else 1.0)))
    for nom, nv in voulues:
        best = None
        for f in corps.faces:
            if not isinstance(f.geometry, adsk.core.Plane):
                continue
            pf = f.pointOnFace
            nf = _normale_face(f, (pf.x, pf.y, pf.z))
            if nf is None or _v_dot(nf, vc(nv)) < 0.999:
                continue
            a = f.area
            if best is None or a > best[0]:
                best = (a, f)
        if best is not None:
            res.append((nom, best[1]) if noms else best[1])
    return res


def _tenons_extr(cmp):
    """Jetons des extrusions « Tenon » du composant (pour reperer celles qu'un appel vient de creer)."""
    out = set()
    try:
        for ft in cmp.features.extrudeFeatures:
            if ft.name.startswith('Tenon'):
                out.add(ft.entityToken)
    except Exception:
        pass
    return out


def _param_epaisseur(design, cm):
    """Nom du parametre d'epaisseur qui vaut cm (CP18 pour 18 mm...) ; cree (CPxx) s'il n'existe pas."""
    for n in _ep_noms(design):
        try:
            if abs(_ep_cm_nom(design, n) - cm) < 1e-3 and design.allParameters.itemByName(n) is not None:
                return n
        except Exception:
            pass
    return _ep_parametre(design, None, cm)


def _tenons_parametre(design, cmp, avant, h):
    """Hauteur des tenons venus de l'epaisseur d'un corps : liee au parametre de cette epaisseur (CP18), pas a une
    valeur en dur (Maxence 2026-11-11)."""
    try:
        nom = _param_epaisseur(design, h)
        n = 0
        for ft in cmp.features.extrudeFeatures:
            if not ft.name.startswith('Tenon') or ft.entityToken in avant:
                continue
            ext = adsk.fusion.DistanceExtentDefinition.cast(ft.extentOne)
            if ext is not None and abs(ext.distance.value - h) < 1e-3:
                ext.distance.expression = nom
                n += 1
        _log('tenons : hauteur liee a %s (%d extrusions)' % (nom, n))
    except Exception:
        _log('tenons parametre : ' + traceback.format_exc()[-300:])


def _creer_tenons(design, corps, calc, M='comp'):
    if not (_s['tn_dessus'] or _s['tn_dessous'] or _s['tn_cotes']) or corps is None:
        return None
    tm = _module('TenonCNC')
    if tm is None or not hasattr(tm, 'create_tenons_core'):
        return _tt('Tenons CNC n\'est pas actif : tenons non crees.')
    faces = _faces_tenons(corps, calc, _vers_comp(design) if M == 'comp' else M, noms=True)
    if not faces:
        return None
    try:
        # une passe par hauteur : dessus = epaisseur du corps du dessus, dessous = celle du corps d'appui
        hts = calc.get('tn_hauteurs') or {}
        par_h = {}
        for nom, f in faces:
            h = round(hts.get(nom, _s['tn_h'] / 10.0), 4)
            par_h.setdefault(h, []).append(f)
        msgs = []
        try:
            cmp = corps.nativeObject.parentComponent if corps.nativeObject is not None else corps.parentComponent
        except Exception:
            cmp = None
        for h, fs in par_h.items():
            avant = _tenons_extr(cmp)
            r = tm.create_tenons_core(design, fs, 'tenon', _s['tn_bord'] / 10.0, int(_s['tn_nb']),
                                      _s['tn_len'] / 10.0, h, 1.0, 1.5, _centrer(_s), 'uniforme', 33.3,
                                      bool(_s['mortaise_auto']), bool(_s['marge_auto']))
            msgs += [m for m in (r.get('messages') or []) if m not in msgs]
            if _s.get('tn_h_auto', True):
                _tenons_parametre(design, cmp, avant, h)
        return '\n'.join(msgs) if msgs else None
    except Exception:
        _log('tenons erreur ' + traceback.format_exc()[-500:])
        return _tt('Tenons impossibles (voir le journal).')


def _degrouper_depuis(tl, debut, fin=None):
    """Les outils appeles (Tenons CNC) ont pu faire leur propre groupe : on le defait (contenu garde) pour tout
    regrouper dans « Traverse corps CNC »."""
    for i in range(tl.timelineGroups.count - 1, -1, -1):
        try:
            g = tl.timelineGroups.item(i)
            if not g.isCollapsed:
                continue                     # groupe deplie : pas le notre (Tenons CNC le laisse replie)
            if g.index >= debut and (fin is None or g.index <= fin):
                g.deleteMe(False)
        except Exception:
            _log('degrouper : ' + traceback.format_exc()[-200:])


def _grouper(tl, debut, fin=None):
    try:
        _degrouper_depuis(tl, debut)
        # un groupe replie compte pour une seule position : la fin est relue apres le degroupage
        fin = tl.markerPosition - 1 if fin is None else fin
        if fin > debut:
            grp = tl.timelineGroups.add(debut, fin)
            grp.name = GROUPE_NOM
            grp.isCollapsed = True
            return True
        elif fin == debut:
            tl.item(debut).name = GROUPE_NOM
            return True
    except Exception:
        _log('groupement erreur ' + traceback.format_exc()[-300:])
    return False


def _supprimer_anciens(design, tokens):
    r = design.findEntityByToken(tokens[0]) if tokens else None
    if r:
        try:
            g = r[0].timelineObject.parentGroup
            if g is not None and g.isCollapsed:
                g.isCollapsed = False
        except Exception:
            pass
    ok = True
    for tok in reversed(tokens):
        try:
            rr = design.findEntityByToken(tok)
            if rr:
                rr[0].deleteMe()
        except Exception:
            ok = False
            _log('suppression ancien erreur ' + traceback.format_exc()[-300:])
    return ok


class _ExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        global _ctx
        ins = args.command.commandInputs
        _apercu_effacer()
        _ov_effacer(True)
        _pastilles_effacer()
        try:
            design = _design()
            ep = _ep_cm(ins)
            _cur['ep'] = ep
            if _saisie['row'] is not None:
                if _saisie['txt'].strip():
                    _valider_saisie(ins)
                _saisie['row'] = None
                _saisie['txt'] = ''
            calc = _calc()
            if not calc['ok']:
                args.executeFailed = True
                args.executeFailedMessage = calc.get('msg') or _tt('Traverse invalide.')
                return
            if _s.get('enreg') and _piece() is None and _edition['v'] is None:
                # mode « enregistrer comme piece » : rien n'est pose, la traverse va dans les pieces
                msg = _enregistrer_piece(design, ins, calc, ep)
                if msg:
                    _ui.messageBox(msg, COMMAND_NAME)
                return
            tl = design.timeline
            ed = _edition['v']
            if ed is not None:
                _edition['v'] = None
                ok_suppr = _supprimer_anciens(design, ed['anciens'])
                _edition['v'] = None
                _lire_selection_jeton(design, ins)
                calc = _calc()
                if not ok_suppr:
                    _ui.messageBox(_tt("L'ancienne traverse n'a pas pu etre supprimee : d'autres fonctions utilisent "
                                       "son corps. La nouvelle est creee ; supprimez l'ancienne a la main."),
                                   COMMAND_NAME)
            debut = tl.markerPosition
            comp = design.activeComponent
            piece = _piece()
            # symetrie sur l'axe : la principale puis les autres pieces, chacune avec ses detections,
            # toutes dans le meme groupe ; chaque piece garde ses reglages (modifiable seule ensuite)
            sym_pos = []
            if _sym_actif():
                _sym['sig'] = None
                sym_pos, _m = _sym_positions()
            ctx0 = _ctx
            fa0 = None
            try:
                fa0 = ctx0['f_app'].entityToken if sym_pos else None
            except Exception:
                pass
            todo = [('', None, None)] + [(x, tok, sl) for x, tok, sl in sym_pos]
            crees = set()
            msgs = []
            ep_nom = None if piece is not None else _ep_parametre(design, ins, ep)
            _cur['ep_nom'] = ep_nom
            garde = {k: _s.get(k) for k in ('pos', 'pos_expr', 'edge', 'sym', 'sym2')}
            b_princ = _s['b']
            try:
                for ji, (x, tok, sl) in enumerate(todo):
                    _s['b'] = _sym_bov.get(ji - 1, b_princ) if tok is not None else b_princ
                    if tok is None:
                        _ctx = ctx0
                        cc = calc
                    else:
                        ign = set(_ignores() or ()) | crees
                        ck = _sym_contexte(design, tok, sl, ign, fa0)
                        if ck is None or not ck.get('ok'):
                            msgs.append(_tt('Une piece en symetrie n\'a pas pu etre placee.'))
                            continue
                        _ctx = ck
                        cc = _calc()
                        if not cc.get('ok'):
                            msgs.append(cc.get('msg') or _tt('Traverse invalide.'))
                            continue
                        _s.update(pos=ck['s'], pos_expr='', edge=tok)
                    if sym_pos and tok is not None:
                        # copies : sans symetrie ; la principale (1re du groupe) garde nombre, entraxe et axes :
                        # « Modifier » dans l'historique recharge tout le jeu (Maxence 2026-11-11)
                        _s['sym'] = False
                        _s['sym2'] = False
                    if piece is not None:
                        # piece de la bibliotheque : une copie posee en travers de l'arete (tenons compris)
                        sk, ex, corps = _poser_piece(design, comp, piece)
                    else:
                        sk, ex, corps = _construire(design, comp, cc, ep_nom)
                    blob = _blob(ep)
                    _s.update(garde)
                    for ent in (sk, ex):
                        try:
                            ent.attributes.add(ATTR_G, ATTR_N, blob)
                        except Exception:
                            _log('attribut : ' + traceback.format_exc()[-200:])
                    if corps is not None:
                        try:
                            crees.add(corps.entityToken)
                        except Exception:
                            pass
                    if piece is None:
                        m = _creer_tenons(design, corps, cc)
                        if m and m not in msgs:
                            msgs.append(m)
            finally:
                _ctx = ctx0
                _s['b'] = b_princ
                _s.update(garde)
            msg_t = '\n'.join(msgs) if msgs else None
            if not _grouper(tl, debut):
                _groupage_apres.update(debut=debut, ed=ed is not None)
            if ed is not None:
                try:
                    tl.moveToEnd()
                except Exception:
                    pass
            if msg_t:
                _ui.messageBox(msg_t, COMMAND_NAME)
            p = load_prefs()
            p['epaisseur_mm'] = round(ep * 10.0, 3)
            for i in (0, 1):
                p['b%d_type' % i] = _s['b'][i]['type']
                p['b%d_tan' % i] = _s['b'][i]['tan']
            for k in ('tn_dessus', 'tn_dessous', 'tn_cotes'):
                p[k] = bool(_s[k])
            p['tn_place'] = _s.get('tn_place', 'centre')
            p['tn_nb'] = int(_s.get('tn_nb') or 1)
            p['sym_nb'] = int(_s.get('sym_nb') or 2)
            p['sym_e_cm'] = float(_s.get('sym_e') or 20.0)
            save_prefs(p)
        except Exception as e:
            _log('execute erreur ' + traceback.format_exc()[-800:])
            args.executeFailed = True
            args.executeFailedMessage = 'Traverse impossible : ' + str(e).splitlines()[-1][:300] if str(e) else \
                'Traverse impossible.'


class _DestroyHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        global _ctx
        _redraw['on'] = False
        _apercu_effacer()          # toujours effacer overlay et apercus a la fermeture
        _ov_effacer(True)
        _pastilles_effacer()
        _camera_suivre(False)
        _drag['k'] = None
        _saisie['row'] = None
        _bloc['sel'] = None
        _ctx = {'ok': False}
        _sym.update(sig=None, pos=[], pieces=[], manque=0, hors=False, ctxs=[]); _sym_bov.clear(); _corps['i'] = 0
        _cur['calc'] = None
        _cmd['c'] = None
        _rafraichir_vue()
        if _groupage_apres:
            _differer_groupage()   # le groupement a echoue pendant la validation : refait apres la commande
        if _edition['v'] is not None:
            _edition['v'] = None   # modification annulee : retour a la fin de la chronologie, rien n'a change
            try:
                _design().timeline.moveToEnd()
            except Exception:
                pass
            _ov_effacer(True)      # graphismes poses pendant la modification (composant actif d'alors)
            _apercu_effacer()
            _pastilles_effacer()


class _GroupageHandler(adsk.core.CustomEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            if not _groupage_apres:
                return
            d = dict(_groupage_apres)
            _groupage_apres.clear()
            tl = _design().timeline
            _grouper(tl, d['debut'])
            if d.get('ed'):
                tl.moveToEnd()
        except Exception:
            _log('groupage apres erreur ' + traceback.format_exc()[-300:])


def _differer_groupage():
    try:
        _evt(_groupage, GROUPAGE_ID, _GroupageHandler)
        if not _app.fireCustomEvent(GROUPAGE_ID, ''):
            _groupage['evt'] = None
            raise RuntimeError('evenement non livre')
    except Exception:
        _log('differer groupage : ' + traceback.format_exc()[-200:])


def _piece_liste_sync(dp):
    """La liste « Piece » suit l'etat : par defaut (aucune piece choisie) c'est « Traverse dessinee » (mesures
    detectees, hauteur 100 mm par defaut) qui est selectionnee, jamais une piece creee (Maxence 2026-11-12)."""
    try:
        voulu = 0
        tok = _s.get('piece')
        if tok:
            for i, e in enumerate(_pieces()):
                if e['body'].entityToken == tok:
                    voulu = i + 1
        cur = dp.selectedItem.index if dp.selectedItem else -1
        if cur != voulu and voulu < dp.listItems.count:
            _log('piece : liste sur %d, remise sur %d' % (cur, voulu))
            _en_cours['v'] = True
            try:
                dp.listItems.item(voulu).isSelected = True
            finally:
                _en_cours['v'] = False
    except Exception:
        _log('piece liste : ' + traceback.format_exc()[-200:])


def _creer_champs(ins, p, ed_blob=None):
    # boite epuree (Maxence 2026-11-11) : l'essentiel ici, les mesures, les bouts et le nombre de traverses se
    # reglent dans les fenetres a gauche de la vue ; les champs caches restent (etat, modification)
    s = ins.addSelectionInput('arete', 'Arete ou courbe', 'Arete d\'un corps (droite, arc, spline) ou courbe '
                              'd\'esquisse : la traverse se place en travers, perpendiculaire a l\'arete')
    s.addSelectionFilter('Edges')
    s.addSelectionFilter('SketchCurves')
    s.setSelectionLimits(0, 0)          # min 0 : Fusion ne grise pas OK quand un clic sur une poignee vide le champ ; max illimite : Ctrl + clic ajoute une arete (chaine)
    dp = ins.addDropDownCommandInput('piece', 'Piece', adsk.core.DropDownStyles.TextListDropDownStyle)
    dp.listItems.add('Traverse dessinee (mesures detectees)', not _s.get('piece'), '')
    for e in _pieces():
        dp.listItems.add(e['nom'], e['body'].entityToken == _s.get('piece'), '')
    _piece_liste_sync(dp)
    dp.tooltip = ('Pieces creees avec « Creer un nouveau corps » (composant masque CNC Toolkit) : la piece choisie '
                  'est copiee en travers de l\'arete cliquee.')
    pm_ = ins.addBoolValueInput('piece_mod', 'Modifier la piece...', False, '', False)
    pm_.isVisible = bool(_s.get('piece'))
    ins.addBoolValueInput('nouveau', 'Creer un nouveau corps...', False, '', False)
    # bouton « Enregistrer comme piece » (Maxence 2026-11-14) : la traverse reglee en direct sur le modele est rangee
    # dans les pieces (composant masque CNC Toolkit) au lieu d'etre posee ; nom dans la fenetre NOM en haut a gauche
    en = ins.addBoolValueInput('enreg_btn', 'Enregistrer comme piece', False, '', False)
    en.tooltip = ('Range la traverse reglee ici dans les pieces (liste « Piece »), avec toutes ses mesures, sans '
                  'rien poser sur le modele. Nom : fenetre NOM en haut a gauche. On la modifie ensuite avec '
                  '« Modifier la piece ».')
    dd = ins.addDropDownCommandInput('ep_dd', 'Epaisseur', adsk.core.DropDownStyles.TextListDropDownStyle)
    ep0 = p['epaisseur_mm'] / 10.0
    nom0 = 'CP18'                       # par defaut : parametre CP18 (Maxence 2026-11-11)
    if ed_blob:
        ep0 = float(ed_blob.get('ep', ep0))
        nom0 = ed_blob.get('ep_nom')
    ok_cp = _ep_remplir(dd, _design(), ep0, nom0)
    ae = ins.addValueInput('ep_autre', 'Epaisseur libre', 'mm', adsk.core.ValueInput.createByReal(ep0))
    ae.isVisible = not ok_cp
    da = ins.addDropDownCommandInput('axe', 'Axe', adsk.core.DropDownStyles.TextListDropDownStyle)
    for k, nom in zip(AXES_NOMS, ('Aucun', 'Axe longueur', 'Axe largeur')):
        da.listItems.add(nom, k == (_s.get('axe') or ''), '')
    pa = ins.addBoolValueInput('para', 'Parallele a l\'axe (sinon perpendiculaire au chemin)', True, '',
                               bool(_s.get('para', True)))
    pa.isVisible = bool(_s.get('axe'))
    s2 = ins.addBoolValueInput('sym2', 'Symetrie aussi sur l\'autre axe (Ctrl + clic sur l\'axe)', True, '',
                               bool(_s.get('sym2')))
    s2.isVisible = bool(_s.get('axe'))
    da.tooltip = ('Traverses paralleles entre elles le long d\'une forme (ovoide...) : elles gardent la direction de '
                  'l\'axe quand on les glisse sur l\'arete.')
    ax = ins.addBoolValueInput('axes', 'Afficher les axes', True, '', bool(_s.get('axes')))
    ax.tooltip = 'Axes longueur et largeur de la forme : cliquez un axe dans la vue pour s\'y aligner.'
    ins.addTextBoxCommandInput('msg', '', '', 1, True)
    caches = []
    caches.append(ins.addValueInput('pos', 'Position le long de l\'arete', 'mm', adsk.core.ValueInput.createByReal(0.0)))
    caches.append(ins.addBoolValueInput('sym', 'Symetrie par rapport a l\'axe', True, '', bool(_s.get('sym'))))
    caches.append(ins.addIntegerSpinnerCommandInput('sym_nb', 'Nombre de pieces', 1, 30, 1,
                                                    max(1, int(_s.get('sym_nb') or 2))))
    caches.append(ins.addValueInput('sym_e', 'Entraxe', 'mm',
                                    adsk.core.ValueInput.createByReal(float(_s.get('sym_e') or 20.0))))
    caches.append(ins.addBoolValueInput('garde', 'garde', True, '', False))
    for x in caches:
        x.isVisible = False
    go = ins.addGroupCommandInput('grp_opt', 'Options')
    go.isExpanded = False
    goc = go.children
    goc.addBoolValueInput('inv', 'Inverser le cote (poser sur l\'autre face)', True, '', bool(_s['inv']))
    goc.addBoolValueInput('sens', 'Retourner la traverse (vers l\'autre cote de l\'arete)', True, '', bool(_s['sens']))
    gd = ins.addGroupCommandInput('grp_dim', 'Dimensions')
    gd.isVisible = False
    gdc = gd.children
    gdc.addBoolValueInput('L_auto', 'Longueur detectee (bout de la face d\'appui ou corps en face)', True, '', True)
    gdc.addValueInput('L', 'Longueur', 'mm', adsk.core.ValueInput.createByReal(50.0))
    gdc.addBoolValueInput('H_auto', 'Hauteur detectee (corps du dessus)', True, '', True)
    gdc.addValueInput('H', 'Hauteur', 'mm', adsk.core.ValueInput.createByReal(H_DEFAUT))
    for i, titre in ((0, 'Extremite du debut'), (1, 'Extremite de la fin')):
        gb = ins.addGroupCommandInput('grp_b%d' % i, titre)
        gb.isVisible = False                    # bouts : boutons des fenetres DEBUT / FIN
        gbc = gb.children
        d1 = gbc.addDropDownCommandInput('b%d_type' % i, 'Forme du bout', adsk.core.DropDownStyles.TextListDropDownStyle)
        for t, nom in zip(TYPES, TYPES_NOMS):
            d1.listItems.add(nom, t == _s['b'][i]['type'], '')
        d2 = gbc.addDropDownCommandInput('b%d_tan' % i, 'Cote tangent', adsk.core.DropDownStyles.TextListDropDownStyle)
        for t, nom in zip(TANS, TANS_NOMS):
            d2.listItems.add(nom, t == _s['b'][i]['tan'], '')
        gbc.addBoolValueInput('b%d_auto' % i, 'Retrait detecte (corps du dessus en retrait)', True, '', True)
        gbc.addValueInput('b%d_d' % i, 'Retrait du bout', 'mm', adsk.core.ValueInput.createByString('30 mm'))
        gbc.addValueInput('b%d_h' % i, 'Hauteur du conge', 'mm', adsk.core.ValueInput.createByString(H_CONGE))
    gt = ins.addGroupCommandInput('grp_tn', 'Tenons')
    gt.isExpanded = False
    gtc = gt.children
    gtc.addBoolValueInput('tn_dessus', 'Tenons sur le dessus', True, '', bool(_s['tn_dessus']))
    gtc.addBoolValueInput('tn_dessous', 'Tenons sur le dessous', True, '', bool(_s['tn_dessous']))
    gtc.addBoolValueInput('tn_cotes', 'Tenons sur les cotes (bouts droits)', True, '', bool(_s['tn_cotes']))
    gtc.addIntegerSpinnerCommandInput('tn_nb', 'Nombre de tenons', 1, 20, 1, int(_s['tn_nb']))
    gtc.addValueInput('tn_len', 'Longueur tenon', 'mm', adsk.core.ValueInput.createByReal(_s['tn_len'] / 10.0))
    gtc.addBoolValueInput('tn_h_auto', 'Hauteur = epaisseur du corps du dessus / du dessous', True, '',
                          bool(_s.get('tn_h_auto', True)))
    gtc.addValueInput('tn_h', 'Hauteur tenon', 'mm', adsk.core.ValueInput.createByReal(_s['tn_h'] / 10.0))
    gtc.addValueInput('tn_bord', 'Distance du bord', 'mm', adsk.core.ValueInput.createByReal(_s['tn_bord'] / 10.0))
    dp = gtc.addDropDownCommandInput('tn_place', 'Placement des tenons', adsk.core.DropDownStyles.TextListDropDownStyle)
    dp.listItems.add('Centres (ecarts egaux)', _s.get('tn_place', 'centre') != 'bord', '')
    dp.listItems.add('Depuis le bord (distance du bord)', _s.get('tn_place') == 'bord', '')
    gtc.addBoolValueInput('mortaise_auto', 'Mortaises automatiques', True, '', bool(_s['mortaise_auto']))
    gtc.addBoolValueInput('marge_auto', 'Marge automatique (jeu de Marge CNC)', True, '', bool(_s['marge_auto']))


class _CreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        global _s, _ctx
        try:
            cmd = args.command
            _cmd['c'] = cmd
            p = load_prefs()
            _s = _nouveau(p)
            _ctx = {'ok': False}
            _cur.update(calc=None, ep=p['epaisseur_mm'] / 10.0, ep_nom=None)
            _bloc['sel'] = None
            _sym.update(sig=None, pos=[], pieces=[], manque=0, hors=False, ctxs=[]); _sym_bov.clear(); _corps['i'] = 0
            _drag['k'] = None
            _saisie['row'] = None
            _actif['row'] = ROW_P
            _ov_effacer(True)
            _apercu_effacer()
            _pastilles_effacer()
            ed = _edition['v']
            blob = ed['blob'] if ed else None
            if blob:
                b = blob.get('s') or {}
                for k in CLES + ('edge',):
                    if k in b:
                        _s[k] = b[k]
            if _nc.get('poser'):
                _s['piece'] = _nc.pop('poser')
            ins = cmd.commandInputs
            _creer_champs(ins, p, blob)
            for ev, h in ((cmd.inputChanged, _InputChangedHandler()),
                          (cmd.validateInputs, _ValidateHandler()),
                          (cmd.executePreview, _PreviewHandler()),
                          (cmd.execute, _ExecuteHandler()),
                          (cmd.destroy, _DestroyHandler()),
                          (cmd.mouseDown, _MouseDownHandler()),
                          (cmd.preSelect, _PreSelectHandler()),
                          (cmd.mouseUp, _MouseUpHandler()),
                          (cmd.mouseDrag, _MouseHandler('mouseDrag')),
                          (cmd.mouseMove, _MouseHandler('mouseMove')),
                          (cmd.keyDown, _KeyHandler()),
                          (cmd.keyUp, _KeyHandler(True))):
                ev.add(h)
                _handlers.append(h)
            _redraw['evt'] = None            # evenements (re)enregistres depuis cette commande : ils survivent
            _redraw['on'] = True
            _dv['t'] = 0.0                      # boite des corps visibles refaite a l'ouverture
            _survol['i'] = None
            _cur['ep'] = _ep_cm(ins)
            if blob and _s.get('edge'):
                def f():
                    r = _design().findEntityByToken(_s['edge'])
                    if r:
                        ins.itemById('arete').addSelection(r[0])
                        for t in (_s.get('aretes') or []):
                            try:
                                r2 = _design().findEntityByToken(t)
                                if r2:
                                    ins.itemById('arete').addSelection(r2[0])
                            except Exception:
                                pass
                        _lire_selection(ins, garder=True)
                    _sync_champs(ins)
                _appliquer(f, ins, True)
            else:
                _appliquer(lambda: None, ins, True)
        except Exception:
            _log('cree erreur ' + traceback.format_exc()[-800:])
            _ui.messageBox('Erreur Traverse CNC:\n' + traceback.format_exc(), COMMAND_NAME)


# --- Fenetre « Nouveau corps » (palette HTML avec apercu dessine, demande de Maxence 2026-11-10) ----------------
# Bouton « Creer un nouveau corps » de la boite : la commande se ferme et la fenetre s'ouvre. Mesures (longueur,
# hauteur, largeur = epaisseur, en mm ou parametres), bouts droite / arc / angle avec leur retrait, pastilles a
# glisser dans le dessin ; meme calcul et meme creation que la traverse sur arete (esquisse entierement
# contrainte sur un plan d'origine, groupe « Traverse corps CNC », Modifier depuis l'historique).

NC_PAL_ID = 'TraverseCorpsCNC_nouveau'
NC_EVT_ID = 'TraverseCorpsCNC_nc'
NC_HTML = os.path.join(_ADDIN_DIR, 'nouveau_corps.html')
_nc = {'val': None, 'edition': None, 'h': []}
_nc_evt = {'evt': None, 'h': None}
PLANS = {'XY': ((1.0, 0.0, 0.0), (0.0, 1.0, 0.0)),
         'XZ': ((1.0, 0.0, 0.0), (0.0, 0.0, 1.0)),
         'YZ': ((0.0, 0.0, 1.0), (0.0, 1.0, 0.0))}


def _nc_defaut():
    p = load_prefs()
    v = p.get('nc_valeurs')
    if isinstance(v, dict) and v.get('b'):
        v = dict(v)
        v.pop('nom', None)                  # nouvelle piece : le nom est a donner (sinon automatique)
        return v
    return {'L': '100 mm', 'H': '50 mm', 'ep': 'CP18', 'plan': 'XY',
            'b': [{'type': 'droite', 'tan': 'dessous', 'd': '20 mm'}, {'type': 'droite', 'tan': 'dessous', 'd': '20 mm'}],
            'tn_dessus': False, 'tn_dessous': False, 'tn_cotes': False}


def _nc_tenons_defaut(v):
    """Reglages des tenons de la fenetre : ceux de Tenons CNC si la fenetre n'en a pas encore."""
    v = dict(v)
    s = _nouveau()
    for k in ('tn_nb', 'tn_len', 'tn_h', 'tn_bord', 'tn_place'):
        v.setdefault(k, s[k])
    return v


def _nc_ep(expr):
    """Epaisseur (cm) d'une expression ; CP10 / CP15 / CP18 acceptes meme si le parametre n'existe pas encore."""
    v = _eval_expr(expr)
    if v is None and (expr or '').strip().upper() in NC_CP:
        v = NC_CP[expr.strip().upper()]
    return v


def _nc_calc(v):
    """Valeurs de la fenetre -> calc (memes fonctions que la traverse sur arete) ; prepare _s et _ctx."""
    global _s, _ctx
    s = _nouveau()
    s.update(L_auto=False, L_expr=v.get('L') or '', L_saisie=True, H_auto=False, H_expr=v.get('H') or '',
             H_saisie=True, tn_dessus=bool(v.get('tn_dessus')), tn_dessous=bool(v.get('tn_dessous')),
             tn_cotes=bool(v.get('tn_cotes')), tn_place='bord' if v.get('tn_place') == 'bord' else 'centre')
    for k, mini in (('tn_nb', 1), ('tn_len', 0.1), ('tn_h', 0.1), ('tn_bord', 0.0)):
        try:
            x = float(str(v.get(k)).replace(',', '.'))
            s[k] = max(mini, int(x) if k == 'tn_nb' else x)
        except Exception:
            pass
    bs = []
    for b in (v.get('b') or [{}, {}])[:2]:
        t = b.get('type') if b.get('type') in ('droite', 'arc', 'angle', 'conge', 'miroir') else 'droite'
        bs.append({'type': t, 'tan': b.get('tan') if b.get('tan') in TANS else 'dessous', 'auto': False,
                   'expr': b.get('d') or '0 mm', 'hexpr': b.get('h') or H_CONGE})
    s['b'] = bs
    _s = s
    u, n = PLANS.get(v.get('plan'), PLANS['XY'])
    _ctx = {'ok': True, 'kind': 'nc', 'ent': None, 'plan': v.get('plan') if v.get('plan') in PLANS else 'XY',
            'S': (0.0, 0.0, 0.0), 'u': u, 'n': n, 'w': _v_cross(u, n), 'haut': None, 's': 0.0, 'Ltot': 0.0,
            'L_det': None, 'H_det': None}
    mauvais = []
    if _eval_expr(v.get('L')) is None:
        mauvais.append('L')
    if _eval_expr(v.get('H')) is None:
        mauvais.append('H')
    ep = _nc_ep(v.get('ep'))
    if ep is None or ep <= 0:
        mauvais.append('ep')
    for i, b in enumerate(bs):
        if b['type'] == 'miroir':
            continue                        # fin en miroir : mesures du debut
        if b['type'] != 'droite' and _eval_expr(b['expr']) is None:
            mauvais.append('d%d' % i)
        if b['type'] == 'conge' and _eval_expr(b['hexpr']) is None:
            mauvais.append('h%d' % i)
    _cur['ep'] = ep if ep else 1.8
    if mauvais:
        return {'ok': False, 'msg': _tt('Mesure invalide : entrez un nombre en mm ou un parametre.'), 'bad': mauvais}
    calc = _calc()
    calc['bad'] = []
    return calc


def _nc_json(calc):
    keys = ('ok', 'msg', 'L', 'H', 'prof', 'bouts', 'tenons', 'bad', 'tn_manque')
    d = {k: calc.get(k) for k in keys}
    d['hc'] = [getattr(b, 'h', None) for b in (calc.get('bouts') or [])]      # hauteurs des conges
    return json.dumps(d)


def _nc_epaisseurs():
    """Liste de la fenetre : parametres CPxx du document (pris tels quels, jamais recrees) + CP10, CP15, CP18."""
    out = {}
    design = _design()
    try:
        for i in range(design.userParameters.count if design else 0):
            p = design.userParameters.item(i)
            if p.name.upper().startswith('CP') and p.name[2:].replace('_', '').isdigit():
                out[p.name] = {'nom': p.name, 'mm': round(p.value * 10.0, 2), 'existe': True}
    except Exception:
        pass
    for k, cm in NC_CP.items():
        if not any(n.upper() == k for n in out):
            out[k] = {'nom': k, 'mm': round(cm * 10.0, 2), 'existe': False}
    return sorted(out.values(), key=lambda e: e['mm'])


def _nc_params():
    """Parametres utilisateur du document (nom, valeur en mm) : suggestions a la saisie d'une cote."""
    out = []
    try:
        design = _design()
        for i in range(design.userParameters.count if design else 0):
            p = design.userParameters.item(i)
            try:
                if p.unit in ('mm', 'cm', 'm', 'in', ''):
                    out.append({'nom': p.name, 'mm': round(p.value * 10.0, 2) if p.unit != '' else p.value})
            except Exception:
                pass
    except Exception:
        pass
    return sorted(out, key=lambda e: e['nom'].lower())


def _nc_ep_nom(design, expr):
    e = (expr or '').strip()
    if design.allParameters.itemByName(e) is not None:
        return e
    try:                                        # « cp18 » : le parametre CP18 du document (noms sensibles a la casse)
        for i in range(design.userParameters.count):
            n = design.userParameters.item(i).name
            if n.upper() == e.upper():
                return n
    except Exception:
        pass
    cm = NC_CP.get(e.upper())
    pref = e.upper() if cm is not None else None
    if cm is None and e and not _est_param(e):
        cm = _eval_expr(e)                      # « 18 » : epaisseur saisie en mm -> parametre CPxx (reutilise ou cree)
    if cm is not None and cm > 1e-6:
        nom = _cp_nom_valeur(design, cm, pref)
        if design.allParameters.itemByName(nom) is None:
            design.userParameters.add(nom, adsk.core.ValueInput.createByReal(cm), 'mm', 'Epaisseur contreplaque')
        return nom
    return e if _est_param(e) else _mm_txt(_eval_expr(e))


def _nc_creer(v):
    design = _design()
    if design is None:
        return _tt('Aucune conception active.')
    calc = _nc_calc(v)
    if not calc.get('ok'):
        return calc.get('msg') or _tt('Traverse invalide.')
    _apercu_effacer()
    v = {k: x for k, x in v.items() if k != '_edition'}
    tl = design.timeline
    ed = _nc['edition']
    if ed is not None and ed.get('ex'):
        msg, tok = _nc_maj_piece(design, v, ed)
        _nc['dernier_corps'] = tok
        if tok:
            p = load_prefs()
            p['nc_valeurs'] = v
            save_prefs(p)
        return msg
    if ed is not None:
        _nc['edition'] = None
        if not _supprimer_anciens(design, ed['anciens']):
            _ui.messageBox(_tt("L'ancienne traverse n'a pas pu etre supprimee : d'autres fonctions utilisent "
                               "son corps. La nouvelle est creee ; supprimez l'ancienne a la main."), COMMAND_NAME)
        calc = _nc_calc(v)
    prev = design.activeOccurrence
    occ = _cnc_occ(design)              # composant masque « CNC Toolkit » (comme Reseau CNC), hors du groupe
    comp = occ.component
    debut = tl.markerPosition
    ep_nom = _nc_ep_nom(design, v.get('ep'))
    sk, ex, corps = _construire(design, comp, calc, ep_nom)
    try:
        occ.isLightBulbOn = False
    except Exception:
        pass
    blob = json.dumps({'v': 1, 'nc': v, 'ep': _cur['ep'], 'ep_nom': ep_nom})
    for ent in (sk, ex):
        try:
            ent.attributes.add(ATTR_G, ATTR_N, blob)
        except Exception:
            pass
    nom = (v.get('nom') or '').strip()[:80] or \
        'Traverse %sx%sx%s' % (_mm_txt(calc['L'])[:-3], _mm_txt(calc['H'])[:-3], _mm_txt(_cur['ep'])[:-3])
    if corps is not None:
        noms = set(b.name for b in comp.bRepBodies if b != corps)
        k, n0 = 2, nom
        while nom in noms:
            nom = '%s (%d)' % (n0, k)
            k += 1
        corps.name = nom
        sk.name = nom
        try:
            corps.attributes.add(ATTR_G, ATTR_PIECE, json.dumps({
                'nom': nom, 'plan': _ctx.get('plan', 'XY'), 'ep_cm': _cur['ep'], 'ep_nom': ep_nom,
                'L': calc['L'], 'H': calc['H'], 'bouts': [list(b) for b in calc['bouts']],
                'prof': [[round(x, 5), round(y, 5)] for x, y in calc['prof']],
                'tenons': [list(t) for t in calc.get('tenons') or []],
                # arete de contact avec le chemin (bas de la face avant), commune avec Reseau CNC
                'contact': _contact_piece(corps, {'plan': _ctx.get('plan', 'XY')})}))
        except Exception:
            _log('attribut piece : ' + traceback.format_exc()[-300:])
    msg_t = None
    try:
        msg_t = _creer_tenons(design, corps.createForAssemblyContext(occ) if corps is not None else None, calc, None)
    finally:
        try:
            if prev is not None:
                prev.activate()
            else:
                design.activateRootComponent()
        except Exception:
            pass
    _nc['dernier_corps'] = corps.entityToken if corps is not None else None
    _grouper(tl, debut)
    if ed is not None:
        try:
            tl.moveToEnd()
        except Exception:
            pass
    p = load_prefs()
    p['nc_valeurs'] = v
    save_prefs(p)
    msg = _tt('Piece creee dans le composant masque « CNC Toolkit » : {0}. Posez-la sur une arete avec le bouton '
              'ci-dessous, ou choisissez-la dans « Piece » de Traverse sur corps.').replace(
        '{0}', corps.name if corps is not None else '?')
    return msg + ('\n' + msg_t if msg_t else '')


def _piece_valeurs(design, ins, calc, ep):
    """Reglages de la traverse reglee en direct -> valeurs de la fenetre « Nouveau corps » (meme format que ses
    pieces : elle les rouvre telles quelles). Les mesures detectees sont gardees a part ('detecte')."""
    ep_nom = None
    try:
        ep_nom = _ep_parametre(design, ins, ep) if ins is not None else _cur.get('ep_nom')
    except Exception:
        ep_nom = _cur.get('ep_nom')
    bs = []
    for i in (0, 1):
        brut = _s['b'][i]
        eff = calc['bouts'][i]
        be = _b_eff(i, _s['b'])
        h = getattr(eff, 'h', None)
        he = _b_hexpr(be)
        h_txt = he if _est_param(he) else _mm_txt(h if h else (_eval_expr(he) or 3.0))
        if i == 1 and brut.get('type') == 'miroir':
            bs.append({'type': 'miroir', 'tan': eff[1], 'd': _mm_txt(eff[2]), 'h': h_txt})
            continue
        typ = eff[0] if eff[2] > 1e-6 else 'droite'
        if typ not in ('droite', 'arc', 'angle', 'conge'):
            typ = 'droite'
        ex = be.get('expr')
        d_txt = ex if (not eff[3] and not be.get('auto') and _est_param(ex)) else _mm_txt(eff[2])
        bs.append({'type': typ, 'tan': eff[1], 'd': d_txt if typ != 'droite' else '20 mm', 'h': h_txt})
    hts = [v for v in (calc.get('tn_hauteurs') or {}).values() if v]
    tn_h = (hts[0] if hts else _s['tn_h'] / 10.0) * 10.0
    L, H = calc['L'], calc['H']
    nom = (_s.get('enreg_nom') or '').strip()
    v = {'nom': nom, 'plan': 'XY',
         'L': _s['L_expr'] if (not _s.get('L_auto') and _est_param(_s.get('L_expr'))) else _mm_txt(L),
         'H': _s['H_expr'] if (not _s.get('H_auto') and _est_param(_s.get('H_expr'))) else _mm_txt(H),
         'ep': ep_nom or _mm_txt(ep), 'b': bs,
         'tn_dessus': bool(_s.get('tn_dessus')), 'tn_dessous': bool(_s.get('tn_dessous')),
         'tn_cotes': bool(_s.get('tn_cotes')), 'tn_place': 'bord' if _s.get('tn_place') == 'bord' else 'centre',
         'tn_nb': str(int(_s.get('tn_nb') or 1)), 'tn_len': '%g' % round(_s['tn_len'], 3),
         'tn_h': '%g' % round(tn_h, 3), 'tn_bord': '%g' % round(_s['tn_bord'], 3),
         # mesures detectees sur le modele au moment de l'enregistrement (pour memoire)
         'detecte': {'L_mm': round(L * 10.0, 2), 'H_mm': round(H * 10.0, 2),
                     'L_auto': bool(_s.get('L_auto')), 'H_auto': bool(_s.get('H_auto')),
                     'retraits_mm': [round(b[2] * 10.0, 2) for b in calc['bouts']],
                     'retraits_auto': [bool(b[3]) for b in calc['bouts']]}}
    return v


def _enregistrer_piece(design, ins, calc, ep):
    """OK en mode « enregistrer comme piece » : la piece est creee comme par la fenetre « Nouveau corps » (dans le
    composant masque CNC Toolkit, groupe replie, reglages memorises pour la fenetre) ; rien n'est pose."""
    global _s, _ctx
    v = _piece_valeurs(design, ins, calc, ep)
    sv = (_s, _ctx, dict(_cur))
    try:
        _nc['edition'] = None
        msg = _nc_creer(v)
    finally:
        _s, _ctx = sv[0], sv[1]
        _cur.clear()
        _cur.update(sv[2])
    _log('piece enregistree depuis le modele : %s' % json.dumps(v)[:400])
    return msg


ENREG_ID = 'TraverseCorpsCNC_enreg'
_enreg_evt = {'evt': None, 'h': None}
_enreg_apres = {'v': None, 'ep': None}


class _EnregHandler(adsk.core.CustomEventHandler):
    """Bouton « Enregistrer comme piece » : la commande se ferme (apercu efface), puis la piece est creee dans la
    bibliotheque avec les reglages figes au clic."""
    def __init__(self): super().__init__()
    def notify(self, args):
        global _s, _ctx
        v, ep = _enreg_apres.get('v'), _enreg_apres.get('ep')
        _enreg_apres.update(v=None, ep=None)
        if not v:
            return
        try:
            try:
                if _ui.activeCommand == CMD_ID:
                    _ui.terminateActiveCommand()
            except Exception:
                pass
            design = _design()
            v['ep'] = _param_epaisseur(design, ep) if ep else '18 mm'
            sv = (_s, _ctx, dict(_cur))
            try:
                _nc['edition'] = None
                msg = _nc_creer(v)
            finally:
                _s, _ctx = sv[0], sv[1]
                _cur.clear()
                _cur.update(sv[2])
            _log('piece enregistree (bouton) : %s' % json.dumps(v)[:300])
            ok = bool(msg) and msg.startswith(_tt('Piece creee'))
            if not ok:
                _ui.messageBox(msg or _tt('La piece n\'a pas pu etre enregistree.'), COMMAND_NAME)
                return
            nom = msg.split(':')[-1].split('.')[0].strip() if ':' in msg else ''
            _confirm.update(t=time.time(), txt=_tt('Piece enregistree : {0}').replace('{0}', nom))
        except Exception:
            _log('enregistrer piece apres : ' + traceback.format_exc()[-400:])
            return
        # Traverse sur corps reste ouverte (Maxence 2026-11-14) : relancee aussitot, vide, prete pour la suite
        try:
            cd = _ui.commandDefinitions.itemById(CMD_ID)
            if cd is not None and _ui.activeCommand != CMD_ID:
                _action['t'] = time.time()
                cd.execute()
        except Exception:
            _log('relance apres enregistrement : ' + traceback.format_exc()[-200:])


_confirm = {'t': 0.0, 'txt': ''}


def _piece_edition(e):
    """(edition, valeurs) pour rouvrir une piece de la bibliotheque dans la fenetre « Nouveau corps »."""
    try:
        body = e['body']
        tok = body.entityToken
        comp = e['occ'].component
        for i in range(comp.features.extrudeFeatures.count):
            ex = comp.features.extrudeFeatures.item(i)
            a = ex.attributes.itemByName(ATTR_G, ATTR_N)
            if a is None:
                continue
            if not any(ex.bodies.item(k).entityToken == tok for k in range(ex.bodies.count)):
                continue
            blob = json.loads(a.value)
            if not blob.get('nc'):
                return None, None
            pr = ex.profile
            pr = pr.item(0) if isinstance(pr, adsk.core.ObjectCollection) else pr
            sk = pr.parentSketch if pr is not None else None
            if sk is None:
                return None, None
            vals = dict(blob['nc'])
            vals['nom'] = vals.get('nom') or e['nom']
            return {'sk': sk.entityToken, 'ex': ex.entityToken}, vals
    except Exception:
        _log('piece a modifier : ' + traceback.format_exc()[-300:])
    return None, None


def modifier_piece_externe(tok):
    """Appele par Reseau CNC (bibliotheque commune, Maxence 2026-11-14) : ouvre la fenetre « Nouveau corps » en
    modification sur une de nos pieces. La commande de l'appelant doit deja etre fermee. True si ouverte."""
    try:
        for e in _pieces():
            if e['body'].entityToken == tok and e['d'].get('src') != 'reseau':
                ed, vals = _piece_edition(e)
                if not vals:
                    break
                _nc['a_ouvrir'] = (ed, vals)
                _nc_differer()
                return True
    except Exception:
        _log('modifier piece externe : ' + traceback.format_exc()[-300:])
    _ui.messageBox(_tt('Cette piece n\'a pas de reglages memorises : elle ne peut pas etre modifiee dans la '
                       'fenetre.'), COMMAND_NAME)
    return False


def _retirer_tenons(design, corps, occ):
    """Retire les tenons poses par Tenons CNC sur la piece (comme Reseau CNC _nc_retirer_tenons)."""
    T = _module('TenonCNC')
    if T is None:
        return
    cles = set()
    for b in (corps, corps.createForAssemblyContext(occ)):
        try:
            cles.update(T._face_map_keys_for_body(design, b.entityToken))
        except Exception:
            pass
    n, err = 0, []
    try:
        if cles:
            n, err = T._delete_tenons_for_face_keys(design, sorted(cles))
    except Exception:
        _log('retrait tenons : ' + traceback.format_exc()[-300:])
    try:
        n2, err2 = T._delete_tenon_batch_for_body(corps)
        n, err = n + n2, list(err) + list(err2)
    except Exception:
        pass
    _log('retrait tenons piece : %d fonction(s), %d cle(s), erreurs %s' % (n, len(cles), err[:3]))


def _jetons_item(it):
    """Jetons des fonctions d'une entree de chronologie (les enfants si c'est un groupe)."""
    out = []
    try:
        if it.isGroup:
            g = adsk.fusion.TimelineGroup.cast(it)
            for j in range(g.count):
                out.extend(_jetons_item(g.item(j)))
        elif it.entity is not None:
            out.append(it.entity.entityToken)
    except Exception:
        pass
    return out


def _degrouper_entites(design, jetons):
    """Defait (contenu garde) les groupes qui contiennent ces fonctions. Chronologie au bout seulement.
    Un groupe deplie (ou rendu par timelineObject.parentGroup) a index et deleteMe en erreur « res >= 0 » :
    il est replie avant d'etre defait."""
    jetons = set(jetons)
    tl = design.timeline
    for _passe in range(4):                       # groupes imbriques : on recommence tant qu'il en reste
        trouve = False
        for i in range(tl.timelineGroups.count - 1, -1, -1):     # groupes imbriques compris
            try:
                g = tl.timelineGroups.item(i)
                if not jetons.intersection(_jetons_item(g)):
                    continue
                g.isCollapsed = True             # deleteMe echoue sur un groupe deplie (« res >= 0 »)
                g.deleteMe(False)
                trouve = True
            except Exception:
                _log('degrouper entite : ' + traceback.format_exc()[-200:])
        if not trouve:
            break


def _nc_maj_piece(design, v, ed):
    """Modifie la piece EN PLACE (meme esquisse, meme extrusion, meme corps) : les copies posees avec Traverse sur
    corps (copier-coller de ce corps) suivent. Tenons retires puis reposes juste apres la piece."""
    calc = _nc_calc(v)
    if not calc.get('ok'):
        return calc.get('msg') or _tt('Traverse invalide.'), None
    tl = design.timeline
    ex = adsk.fusion.ExtrudeFeature.cast(design.findEntityByToken(ed['ex'])[0])
    sk = adsk.fusion.Sketch.cast(design.findEntityByToken(ed['sk'])[0])
    corps = ex.bodies.item(0)
    occ = _cnc_occ(design)
    comp = occ.component
    tok_corps = corps.entityToken
    ep_nom = _nc_ep_nom(design, v.get('ep'))
    prev = design.activeOccurrence
    _retirer_tenons(design, corps, occ)
    ex = adsk.fusion.ExtrudeFeature.cast(design.findEntityByToken(ed['ex'])[0])
    sk = adsk.fusion.Sketch.cast(design.findEntityByToken(ed['sk'])[0])
    # le groupe de la piece est defait AVANT de reculer : une fois l'ancienne esquisse supprimee il serait casse
    # (Fusion ne sait plus le supprimer), et un groupe ne se supprime pas chronologie reculee
    _degrouper_entites(design, [ed['sk'], ed['ex']])
    ex = adsk.fusion.ExtrudeFeature.cast(design.findEntityByToken(ed['ex'])[0])
    sk = adsk.fusion.Sketch.cast(design.findEntityByToken(ed['sk'])[0])
    toks_tn = []
    try:
        ex.timelineObject.rollTo(True)
        # plan d'origine choisi
        plan = {'XY': comp.xYConstructionPlane, 'XZ': comp.xZConstructionPlane,
                'YZ': comp.yZConstructionPlane}[_ctx.get('plan', 'XY')]
        # nouvelle esquisse (inseree avant l'extrusion) : l'extrusion change de profil alors que l'ancien est encore
        # valide (Fusion refuse un profil remplace apres suppression de ses courbes), puis l'ancienne est supprimee
        P3 = adsk.core.Point3D.create
        ancien = sk
        nom_sk = ancien.name
        sk = comp.sketches.add(plan)
        best = _dessiner(sk, _ctx, calc, True, lambda p: P3(*p))
        ex.profile = best[1]
        try:
            ancien.deleteMe()
        except Exception:
            _log('ancienne esquisse : ' + traceback.format_exc()[-200:])
        sk.name = nom_sk
        try:
            sk.isVisible = False
        except Exception:
            pass
        ed['sk'] = sk.entityToken
        o = sk.sketchToModelSpace(P3(0, 0, 0))
        zz = sk.sketchToModelSpace(P3(0, 0, 1))
        nk = (zz.x - o.x, zz.y - o.y, zz.z - o.z)
        sens = adsk.fusion.ExtentDirections.PositiveExtentDirection if _v_dot(nk, _ctx['w']) > 0 else \
            adsk.fusion.ExtentDirections.NegativeExtentDirection
        ex.setOneSideExtent(adsk.fusion.DistanceExtentDefinition.create(
            adsk.core.ValueInput.createByString(ep_nom)), sens, adsk.core.ValueInput.createByString('0 deg'))
        # tenons reposes juste apres l'extrusion (avant les copies : elles les recoivent)
        tl.markerPosition = ex.timelineObject.index + 1
        corps = adsk.fusion.BRepBody.cast(design.findEntityByToken(tok_corps)[0])
        msg_t = None
        try:
            msg_t = _creer_tenons(design, corps.createForAssemblyContext(occ), calc, None)
        finally:
            try:
                if prev is not None:
                    prev.activate()
                else:
                    design.activateRootComponent()
            except Exception:
                pass
        # tenons ajoutes (entre l'extrusion et le marqueur), notes par jeton : regroupes chronologie au bout
        ex = adsk.fusion.ExtrudeFeature.cast(design.findEntityByToken(ed['ex'])[0])
        for i in range(ex.timelineObject.index + 1, tl.markerPosition):
            toks_tn.extend(_jetons_item(tl.item(i)))
    finally:
        tl.moveToEnd()
    # Tenons CNC a pu faire son propre groupe : defait chronologie au bout, puis un seul groupe pour la piece
    _degrouper_entites(design, toks_tn)
    try:
        sk = adsk.fusion.Sketch.cast(design.findEntityByToken(ed['sk'])[0])
        ex = adsk.fusion.ExtrudeFeature.cast(design.findEntityByToken(ed['ex'])[0])
        i0 = sk.timelineObject.index
        i1 = ex.timelineObject.index
        for t in toks_tn:
            try:
                i1 = max(i1, design.findEntityByToken(t)[0].timelineObject.index)
            except Exception:
                pass
        if i1 > i0:
            grp = tl.timelineGroups.add(i0, i1)
            grp.name = GROUPE_NOM
            grp.isCollapsed = True
        else:
            tl.item(i0).name = GROUPE_NOM
    except Exception:
        _log('regroupement piece : ' + traceback.format_exc()[-300:])
    corps = adsk.fusion.BRepBody.cast(design.findEntityByToken(tok_corps)[0])
    nom = (v.get('nom') or '').strip()[:80] or corps.name
    if nom != corps.name:
        noms = set(b.name for b in comp.bRepBodies if b.entityToken != tok_corps)
        k, n0 = 2, nom
        while nom in noms:
            nom = '%s (%d)' % (n0, k)
            k += 1
        corps.name = nom
        sk.name = nom
    blob = json.dumps({'v': 1, 'nc': v, 'ep': _cur['ep'], 'ep_nom': ep_nom})
    for ent in (sk, ex):
        try:
            a = ent.attributes.itemByName(ATTR_G, ATTR_N)
            if a is not None:
                a.value = blob
            else:
                ent.attributes.add(ATTR_G, ATTR_N, blob)
        except Exception:
            pass
    try:
        a = corps.attributes.itemByName(ATTR_G, ATTR_PIECE)
        d = {'nom': nom, 'plan': _ctx.get('plan', 'XY'), 'ep_cm': _cur['ep'], 'ep_nom': ep_nom,
             'L': calc['L'], 'H': calc['H'], 'bouts': [list(b) for b in calc['bouts']],
             'prof': [[round(x, 5), round(y, 5)] for x, y in calc['prof']],
             'tenons': [list(t) for t in calc.get('tenons') or []]}
        d['contact'] = _contact_piece(corps, d)          # arete de contact (bas de la face avant)
        if a is None:
            corps.attributes.add(ATTR_G, ATTR_PIECE, json.dumps(d))
        else:
            a.value = json.dumps(d)
    except Exception:
        _log('attribut piece : ' + traceback.format_exc()[-300:])
    msg = _tt('Piece {0} modifiee : ses copies suivent.').replace('{0}', nom)
    return msg + ('\n' + msg_t if msg_t else ''), tok_corps


class _NcHtmlHandler(adsk.core.HTMLEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            a = args.action
            _nc['dernier'] = a
            d = json.loads(args.data) if args.data else {}
            if a == 'nc_pret':
                args.returnData = json.dumps(_nc_tenons_defaut(_nc['val'] or _nc_defaut()))
                _nc_redessiner()
            elif a == 'nc_eps':
                args.returnData = json.dumps(_nc_epaisseurs())
            elif a == 'nc_params':
                args.returnData = json.dumps(_nc_params())
            elif a == 'nc_textes':
                args.returnData = json.dumps([_tt((t or '').strip()) for t in d.get('t', [])])
            elif a == 'nc_calc':
                global _s, _ctx
                if _cmd['c'] is not None:
                    # la boite Traverse sur corps est ouverte : son etat est garde, pas d'apercu 3D ici
                    sauve = (_s, _ctx, dict(_cur))
                    calc = _nc_calc(d)
                    _s, _ctx = sauve[0], sauve[1]
                    _cur.clear()
                    _cur.update(sauve[2])
                else:
                    calc = _nc_calc(d)             # la piece va dans le composant masque : pas d'apercu 3D
                args.returnData = _nc_json(calc)
            elif a == 'nc_creer':
                try:
                    if _cmd['c'] is not None:
                        _ui.terminateActiveCommand()
                    msg = _nc_creer(d)
                except Exception as e:
                    _log('nouveau corps erreur ' + traceback.format_exc()[-800:])
                    msg = _tt('Traverse impossible : ') + (str(e).splitlines()[-1][:300] if str(e) else '')
                _rafraichir_vue()
                args.returnData = json.dumps({'msg': msg, 'tok': _nc.pop('dernier_corps', None)})
            elif a == 'nc_poser':
                _nc['poser'] = d.get('tok')
                # la fenetre se ferme des le clic (elle restait affichee apres « Modifier la piece », Maxence
                # 2026-11-14) ; masquee ici (la supprimer dans son propre evenement est risque)
                _nc['edition'] = None
                try:
                    pal = _ui.palettes.itemById(NC_PAL_ID)
                    if pal is not None:
                        pal.isVisible = False
                except Exception:
                    _log('fermer fenetre : ' + traceback.format_exc()[-200:])
                _apercu_effacer()
                _differer()
        except Exception:
            _log('fenetre nouveau corps : ' + traceback.format_exc()[-500:])


class _NcClosedHandler(adsk.core.UserInterfaceGeneralEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            _apercu_effacer()
            _rafraichir_vue()
            if _nc['edition'] is not None:
                _nc['edition'] = None          # modification abandonnee : retour a la fin de la chronologie
                _design().timeline.moveToEnd()
        except Exception:
            pass


def _nc_ouvrir(vals=None):
    """Ouvre (ou recharge) la fenetre « Nouveau corps » avec ces valeurs (sinon les dernieres utilisees)."""
    _nc['val'] = vals
    pal = _ui.palettes.itemById(NC_PAL_ID)
    if pal is None:
        # URL file:/// avec des « / » (un chemin Windows a antislashs donne ERR_INVALID_URL, constate dans ToolkitCNC)
        import pathlib
        url = pathlib.PureWindowsPath(NC_HTML).as_uri() if os.name == 'nt' else pathlib.Path(NC_HTML).as_uri()
        pal = _ui.palettes.add(NC_PAL_ID, _tt('Nouveau corps (traverse)'), url, False, True, True, NC_TAILLE[0], NC_TAILLE[1], True)
        h1, h2 = _NcHtmlHandler(), _NcClosedHandler()
        pal.incomingFromHTML.add(h1)
        pal.closed.add(h2)
        _nc['h'] = [h1, h2]
        try:
            pal.dockingState = adsk.core.PaletteDockingStates.PaletteDockStateFloating
        except Exception:
            pass
        pal.isVisible = True
        _nc_placer(pal)
    else:
        if pal.isVisible:
            pal.sendInfoToHTML('nc_valeurs', json.dumps(_nc_tenons_defaut(vals or _nc_defaut())))
        else:
            pal.isVisible = True
            _nc_placer(pal)
            pal.sendInfoToHTML('nc_valeurs', json.dumps(_nc_tenons_defaut(vals or _nc_defaut())))
    return pal


NC_TAILLE = (580, 620)
NC_ECHELLE = 2.0                 # fenetre agrandie x2 (Maxence 2026-11-11), reduite si l'ecran est trop petit


def _nc_ecran():
    """(largeur, hauteur) logiques de l'ecran principal ; (0, 0) si inconnu."""
    try:
        import ctypes
        k = float(_dpr()) or 1.0
        u = ctypes.windll.user32
        return u.GetSystemMetrics(0) / k, u.GetSystemMetrics(1) / k
    except Exception:
        return 0, 0


def _nc_taille():
    """(largeur, hauteur) de la palette en pixels logiques : x2, sans depasser 92 % de la zone 3D."""
    e = NC_ECHELLE
    sw, sh = _nc_ecran()
    if sw:
        e = min(e, 0.92 * sw / NC_TAILLE[0], 0.92 * sh / NC_TAILLE[1])
    e = max(1.0, e)
    return int(NC_TAILLE[0] * e), int(NC_TAILLE[1] * e)


def _nc_placer(pal):
    """Fenetre a sa taille et au centre de la zone 3D (Fusion l'ouvrait petite, collee a gauche, page blanche)."""
    W, H = _nc_taille()
    try:
        pal.setSize(W, H)
    except Exception:
        _log('taille fenetre : ' + traceback.format_exc()[-200:])
    try:
        sw, sh = _nc_ecran()
        if sw:                                # centree sur l'ecran (Maxence 2026-11-11)
            x, y = int(sw / 2 - W / 2), int(sh / 2 - H / 2)
        else:
            vp = _app.activeViewport
            x, y = int(vp.width / 2 - W / 2), int(vp.height / 2 - H / 2)
        pal.setPosition(max(0, x), max(0, y))
        _log('fenetre : %dx%d en (%d, %d), ecran %.0fx%.0f' % (W, H, x, y, sw, sh))
    except Exception:
        _log('position fenetre : ' + traceback.format_exc()[-200:])


def _nc_redessiner():
    """La page est chargee : un petit changement de taille force Fusion a la peindre (fenetre blanche jusqu'a ce qu'on
    l'etire, constate le 2026-11-11), puis la taille normale est remise."""
    try:
        pal = _ui.palettes.itemById(NC_PAL_ID)
        if pal is not None:
            W, H = _nc_taille()
            pal.setSize(W + 1, H + 1)
            pal.setSize(W, H)
    except Exception:
        _log('redessin fenetre : ' + traceback.format_exc()[-200:])


def _nc_fermer():
    pal = _ui.palettes.itemById(NC_PAL_ID) if _ui else None
    if pal is not None:
        try:
            pal.deleteMe()
        except Exception:
            pass
    _nc['h'] = []


class _NcEvtHandler(adsk.core.CustomEventHandler):
    """Bouton de la boite : la commande se ferme, puis la fenetre s'ouvre (hors du gestionnaire de la commande).
    « Modifier la piece » : la fenetre s'ouvre remplie avec la piece, en modification (la piece est mise a jour en
    place, ses copies suivent)."""
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            try:
                if _ui.activeCommand == CMD_ID:
                    _ui.terminateActiveCommand()
            except Exception:
                pass
            ao = _nc.pop('a_ouvrir', None)
            if ao:
                _nc['edition'] = ao[0]
                vals = dict(ao[1])
                vals['_edition'] = True
                _nc_ouvrir(vals)
                return
            _nc_ouvrir(None)
        except Exception:
            _log('ouvrir nouveau corps : ' + traceback.format_exc()[-300:])


def _nc_differer():
    try:
        _evt(_nc_evt, NC_EVT_ID, _NcEvtHandler)
        if not _app.fireCustomEvent(NC_EVT_ID, ''):
            _nc_evt['evt'] = None
            _evt(_nc_evt, NC_EVT_ID, _NcEvtHandler)
            _app.fireCustomEvent(NC_EVT_ID, '')
    except Exception:
        _log('nouveau corps differe : ' + traceback.format_exc()[-300:])


# --- Pieces de la bibliotheque (composant masque « CNC Toolkit », comme Reseau CNC) ------------------------------
# La fenetre « Nouveau corps » cree la piece dans le composant masque « CNC Toolkit » (le meme que Reseau CNC, a
# X -2000 / Y +2000 mm). Dans Traverse sur corps, la liste « Piece » la choisit : un clic sur une arete pose une COPIE
# de la piece (copier-coller de corps + deplacement), en travers de l'arete ; rien n'est redessine.

CNC_COMP = 'CNC Toolkit'
CNC_POS = (-200.0, 200.0)
ATTR_PIECE = 'piece'


def _cnc_occ(design, creer=True):
    """Composant « CNC Toolkit » masque, a l'ecart du modele (cree au 1er usage, partage avec Reseau CNC)."""
    root = design.rootComponent
    for i in range(root.occurrences.count):
        o = root.occurrences.item(i)
        if o.component.name == CNC_COMP:
            return o
    if not creer:
        return None
    m = adsk.core.Matrix3D.create()
    m.translation = adsk.core.Vector3D.create(CNC_POS[0], CNC_POS[1], 0.0)
    occ = root.occurrences.addNewComponent(m)
    occ.component.name = CNC_COMP
    occ.isLightBulbOn = False
    return occ


RS_G, RS_CORPS = 'ReseauTrajectoireCNC', 'corps_bibliotheque'      # pieces de Reseau CNC (bibliotheque commune)


def _piece_reseau(b, a):
    """Piece creee par Reseau CNC (« Nouvel objet ») -> meme format que nos pieces (Maxence 2026-11-14 :
    bibliotheque commune). Panneau rectangle largeur x hauteur sur le plan XZ du composant (largeur selon X,
    hauteur selon Z) ; le cote de l'epaisseur est lu sur le corps (w_off)."""
    r = json.loads(a.value)
    ep = r.get('ep')
    try:
        p = _design().allParameters.itemByName(ep) if isinstance(ep, str) else None
        ep_cm = p.value if p is not None else (float(ep) if not isinstance(ep, str) else NC_CP.get(ep, 1.8))
    except Exception:
        ep_cm = 1.8
    L, H = float(r['l']), float(r['h'])
    # tenons de Reseau (chants haut / bas / gauche / droite, n tenons centres) -> format de l'apercu
    tn = []
    t = r.get('tenons')
    if t and t.get('cotes'):
        for cote in t['cotes']:
            lg = L if cote in ('haut', 'bas') else H
            nb = max(1, int(t['n']))
            tl = min(float(t['long']), lg / nb)
            jeu = (lg - nb * tl) / (nb + 1.0)
            nom = {'haut': 'dessus', 'bas': 'dessous', 'gauche': 'cote0', 'droite': 'cote1'}.get(cote)
            if nom:
                tn += [[nom, jeu + k * (tl + jeu), tl, float(t['haut'])] for k in range(nb)]
    d = {'nom': r.get('nom') or b.name, 'plan': 'XZ', 'ep_cm': ep_cm, 'ep_nom': ep if isinstance(ep, str) else None,
         'L': L, 'H': H, 'bouts': [['droite', 'dessous', 0.0, False]] * 2,
         'prof': [[0.0, 0.0], [L, 0.0], [L, H], [0.0, H], [0.0, 0.0]], 'tenons': tn, 'src': 'reseau'}
    d['contact'] = r.get('contact') or _contact_piece(b, d)
    return d


def _contact_piece(b, d):
    """Arete de contact d'une piece (Maxence 2026-11-14), en coordonnees du composant : l'arete du bas de la face
    avant (face posee sur le plan d'esquisse, a l'origine). {'u': longueur, 'haut': hauteur, 'avant': normale
    sortante de la face avant}. Commune avec Reseau CNC (qui l'appelle pour nos pieces)."""
    u0, n0 = PLANS.get(d.get('plan'), PLANS['XY'])
    w0 = _v_cross(u0, n0)
    sens = 1.0
    try:
        bb = b.boundingBox                      # espace du composant : de quel cote du plan d'esquisse est la matiere
        c = ((bb.minPoint.x + bb.maxPoint.x) / 2.0, (bb.minPoint.y + bb.maxPoint.y) / 2.0,
             (bb.minPoint.z + bb.maxPoint.z) / 2.0)
        sens = 1.0 if _v_dot(c, w0) >= 0.0 else -1.0
    except Exception:
        pass
    return {'u': list(u0), 'haut': list(n0), 'avant': list(_v_mul(w0, -sens)), 'x0': _contact_x0(d)}


def _contact_x0(d):
    """Debut de l'arete du bas le long de la longueur : un bout en arc, en conge ou en pente la fait commencer
    plus loin que x = 0 (Maxence 2026-11-14 : la piece etait en retrait du chemin)."""
    bas = [float(p[0]) for p in (d.get('prof') or []) if abs(float(p[1])) < 1e-4]
    return min(bas) if bas else 0.0


def _pieces():
    """[{'nom', 'body', 'occ', 'd'}] : pieces creees par la fenetre Nouveau corps (attribut TraverseCorpsCNC/piece)
    et pieces de Reseau CNC (attribut ReseauTrajectoireCNC/corps_bibliotheque, d['src'] = 'reseau')."""
    res = []
    try:
        occ = _cnc_occ(_design(), False)
        if occ is None:
            return res
        occs = [occ] + [occ.childOccurrences.item(c) for c in range(occ.childOccurrences.count)]
        for o in occs:
            for j in range(o.component.bRepBodies.count):
                b = o.component.bRepBodies.item(j)
                a = b.attributes.itemByName(ATTR_G, ATTR_PIECE) if o is occ else None
                try:
                    if a is not None:
                        res.append({'nom': b.name, 'body': b, 'occ': o, 'd': json.loads(a.value)})
                        continue
                    a = b.attributes.itemByName(RS_G, RS_CORPS)
                    if a is not None:
                        res.append({'nom': b.name, 'body': b, 'occ': o, 'd': _piece_reseau(b, a)})
                except Exception:
                    _log('piece %s : %s' % (b.name, traceback.format_exc()[-200:]))
    except Exception:
        _log('liste pieces : ' + traceback.format_exc()[-300:])
    return res


def _piece():
    """La piece choisie dans la boite (ou None)."""
    tok = _s.get('piece') if _s else None
    if not tok:
        return None
    for e in _pieces():
        if e['body'].entityToken == tok:
            return e
    return None


def _calc_piece(e):
    """calc d'une piece de la bibliotheque : ses mesures, son profil et ses tenons memorises."""
    d = e['d']
    c = {'ok': True, 'L': d['L'], 'H': d['H'], 'defaut': False, 'defaut_L': False, 'defaut_H': False,
         'bouts': [tuple(b) for b in d.get('bouts') or [('droite', 'dessous', 0.0, False)] * 2],
         'prof': [tuple(p) for p in d['prof']], 'tenons': [tuple(t) for t in d.get('tenons') or []],
         'info': None, 'raison': None, 'piece': True, 'ep': d.get('ep_cm', 1.8)}
    c['ok'] = True
    # bas de la piece sur le point clique : une piece dont le debut deborde (angle / arc vers le corps du dessus)
    # commence en bas a xb0 > 0 ; l'apercu est decale d'autant (comme _poser_piece ; Maxence 2026-11-14)
    c['a0'] = -_piece_xb0(d)
    ct = _contact_de(e)
    c['w_h'] = _contact_main(ct)                       # sens de l'epaisseur depuis la face avant (voir _poser_piece)
    _cur['ep'] = c['ep']                       # apercu a l'epaisseur de la piece
    c['msg'] = _tt('Piece {0} : {1} x {2}').replace('{0}', e['nom']).replace('{1}', _mm_txt(d['L'])) \
        .replace('{2}', _mm_txt(d['H']))
    return c


def _piece_xb0(d):
    """Debut (cm, le long) du bas de la piece dans son profil memorise : 0 pour un bout droit, le debord pour un debut
    en angle / arc vers le corps du dessus ; 0 si le profil est inconnu (pieces de Reseau CNC)."""
    try:
        pr = d.get('prof') or []
        xs = [p[0] for p in pr if abs(p[1]) < 1e-4]
        return max(0.0, min(xs)) if xs else 0.0
    except Exception:
        return 0.0


def _contact_de(e):
    """Arete de contact enregistree de la piece, sinon calculee (pieces creees avant le 2026-11-14)."""
    ct = e['d'].get('contact') or _contact_piece(e['body'], e['d'])
    if ct.get('x0') is None:
        ct = dict(ct, x0=_contact_x0(e['d']))
    return ct


def _contact_main(ct):
    """+1 si (longueur, hauteur, vers la matiere) est un repere direct, -1 sinon."""
    return 1.0 if _v_dot(_v_cross(ct['u'], ct['haut']), _v_mul(ct['avant'], -1.0)) >= 0.0 else -1.0


def _repere_matrice(o, u, n, w):
    m = adsk.core.Matrix3D.create()
    V = adsk.core.Vector3D.create
    m.setWithCoordinateSystem(adsk.core.Point3D.create(*o), V(*u), V(*n), V(*w))
    return m


def _poser_piece(design, comp, e):
    """Copie de la piece posee en travers de l'arete (copier-coller + deplacement libre). (copie, deplacement, corps)."""
    c = _ctx
    T = e['occ'].transform2
    tr = T.translation
    o0 = (tr.x, tr.y, tr.z)

    def vt(v):
        q = adsk.core.Vector3D.create(*v)
        q.transformBy(T)
        return (q.x, q.y, q.z)
    # arete de contact (Maxence 2026-11-14) : l'arete du bas de la face avant de la piece est posee pile sur le
    # point clique de l'arete ; l'epaisseur part de la face avant (plus centree). Repere source a l'origine de la
    # piece : longueur, hauteur, vers la matiere ; repere cible de meme orientation (sinon la copie serait miroir)
    ct = _contact_de(e)
    h = _contact_main(ct)
    src = _repere_matrice(o0, vt(ct['u']), vt(ct['haut']), vt(_v_mul(ct['avant'], -1.0)))
    w = _v_mul(_v_norm(_v_cross(c['u'], c['n'])), h)
    # le BAS de la piece (et non son origine) va sur le point clique : debut en debord (angle / arc) -> decale de xb0
    tgt = _repere_matrice(_v_sub(c['S'], _v_mul(c['u'], _piece_xb0(e['d']))), c['u'], c['n'], w)
    m = src.copy()
    m.invert()
    m.transformBy(tgt)
    M = _vers_comp(design)
    if M is not None:
        m.transformBy(M)
    col = adsk.core.ObjectCollection.create()
    col.add(e['body'].createForAssemblyContext(e['occ']))
    cp = comp.features.copyPasteBodies.add(col)
    nouveaux = adsk.core.ObjectCollection.create()
    corps = []
    for i in range(cp.bodies.count):
        b = cp.bodies.item(i)
        b.isLightBulbOn = True
        nouveaux.add(b)
        corps.append(b)
    mi = comp.features.moveFeatures.createInput2(nouveaux)
    mi.defineAsFreeMove(m)
    mf = comp.features.moveFeatures.add(mi)
    for b in corps:
        try:
            b.name = _nom_libre(comp, _tt('Traverse'))
        except Exception:
            pass
    return cp, mf, corps[0] if corps else None


# --- Modification depuis l'historique de CNC Toolkit (cnc_historique.modifier) --------------------------------

class _ActionHandler(adsk.core.CustomEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            cd = _ui.commandDefinitions.itemById(CMD_ID)
            deja = False
            try:
                deja = (_ui.activeCommand == CMD_ID)
            except Exception:
                pass
            if time.time() - _action.get('t', 0.0) < 5.0:
                deja = True
            if cd is not None and not deja:
                cd.execute()
        except Exception:
            _log('action erreur ' + traceback.format_exc()[-300:])


def _differer():
    """Ouvre la commande hors du gestionnaire de la palette (evenement personnalise, comme Reseau CNC)."""
    try:
        _evt(_action, ACTION_ID, _ActionHandler)
        if not _app.fireCustomEvent(ACTION_ID, 'go'):
            _action['evt'] = None
            _action['t'] = time.time()
            _ui.commandDefinitions.itemById(CMD_ID).execute()
    except Exception:
        _log('differer : ' + traceback.format_exc()[-200:])
        _ui.commandDefinitions.itemById(CMD_ID).execute()


def edit_group(g):
    """Appele par cnc_historique : recule la chronologie au debut du groupe « Traverse corps CNC » et rouvre la
    fenetre avec ses reglages ; a la validation la nouvelle traverse remplace l'ancienne. (ok, message)."""
    try:
        design = _design()
        if design is None or design.designType != adsk.fusion.DesignTypes.ParametricDesignType:
            return False, 'Conception parametrique (historique) requise.'
        try:
            g.isCollapsed = False
        except Exception:
            pass
        ents = [g.item(i).entity for i in range(g.count)]
        ents = [e for e in ents if adsk.fusion.Occurrence.cast(e) is None]     # jamais le composant CNC Toolkit
        blob = None
        corps = []
        nb_blobs = 0
        for e in ents:
            try:
                a = e.attributes.itemByName(ATTR_G, ATTR_N)
                if a is not None and adsk.fusion.Sketch.cast(e) is not None:
                    nb_blobs += 1             # une esquisse par piece
                if a is not None and blob is None:
                    blob = json.loads(a.value)
            except Exception:
                pass
            try:
                bs = getattr(e, 'bodies', None)
                if bs is not None:
                    corps += [bs.item(k).entityToken for k in range(bs.count)]
            except Exception:
                pass
        if blob is None:
            try:
                g.isCollapsed = True
            except Exception:
                pass
            return False, 'Traverse sans reglages memorises.'
        idx = g.item(0).index
        if blob.get('nc'):
            # piece de la fenetre Nouveau corps : modifiee EN PLACE a la validation (ses copies suivent)
            ex = next((e for e in ents if adsk.fusion.ExtrudeFeature.cast(e) is not None and
                       e.attributes.itemByName(ATTR_G, ATTR_N) is not None), None)
            sk = None
            try:
                pr = ex.profile if ex is not None else None
                pr = pr.item(0) if isinstance(pr, adsk.core.ObjectCollection) else pr
                sk = pr.parentSketch if pr is not None else None
            except Exception:
                sk = None
            if sk is not None and ex is not None:
                _nc['edition'] = {'sk': sk.entityToken, 'ex': ex.entityToken}
            else:
                _nc['edition'] = {'anciens': [e.entityToken for e in ents]}
                design.timeline.markerPosition = idx
            try:
                g.isCollapsed = True
            except Exception:
                pass
            vals = dict(blob['nc'])
            vals['_edition'] = True
            _nc_ouvrir(vals)
            return True, None
        # groupe de plusieurs pieces cree avant le 2026-11-11 15:25 : la symetrie n'etait pas memorisee dans la
        # principale ; elle est retrouvee par le nombre de pieces et le nombre memorise (sym_nb)
        try:
            bs = blob.get('s') or {}
            if nb_blobs > 1 and not bs.get('sym') and not bs.get('sym2') and bs.get('axe'):
                nb = max(1, int(bs.get('sym_nb') or 1))
                if nb_blobs == nb:
                    bs['sym'] = nb > 1
                elif nb_blobs == 2 * nb:
                    bs['sym'], bs['sym2'] = nb > 1, True
                _log('modifier : %d pieces, symetrie retrouvee %s / %s' % (nb_blobs, bs.get('sym'), bs.get('sym2')))
        except Exception:
            pass
        _edition['v'] = {'blob': blob, 'anciens': [e.entityToken for e in ents], 'corps': corps}
        try:
            _ui.activeSelections.clear()
        except Exception:
            pass
        design.timeline.markerPosition = idx
        _differer()
        return True, None
    except Exception as e:
        _edition['v'] = None
        _log('edit_group erreur ' + traceback.format_exc()[-400:])
        return False, str(e)[:200]


def run(context):
    global _app, _ui
    try:
        _app = adsk.core.Application.get()
        _ui = _app.userInterface
        old = _ui.commandDefinitions.itemById(CMD_ID)
        if old:
            old.deleteMe()
        res = os.path.join(_ADDIN_DIR, 'resources')
        cmd_def = _ui.commandDefinitions.addButtonDefinition(CMD_ID, COMMAND_NAME, COMMAND_DESC,
                                                             res if os.path.isdir(res) else '')
        on_created = _CreatedHandler()
        cmd_def.commandCreated.add(on_created)
        _handlers.append(on_created)
        panel = _ui.allToolbarPanels.itemById(PANEL_ID)
        if panel and not panel.controls.itemById(CMD_ID):
            panel.controls.addCommand(cmd_def)
        # evenements personnalises : enregistres a l'ouverture de la commande (voir _redessiner_differe / _differer)
    except Exception:
        if _ui:
            _ui.messageBox('Erreur au demarrage de Traverse sur corps CNC:\n' + traceback.format_exc())


def stop(context):
    _camera_suivre(False)
    try:
        for ev in (ACTION_ID, REDRAW_ID, GROUPAGE_ID):
            try:
                _app.unregisterCustomEvent(ev)
            except Exception:
                pass
        _action['evt'] = None
        _redraw['evt'] = None
        _groupage['evt'] = None
        _redraw['on'] = False
        _apercu_effacer()
        _ov_effacer(True)
        _pastilles_effacer()
        _nc_fermer()
        try:
            _app.unregisterCustomEvent(NC_EVT_ID)
        except Exception:
            pass
        _nc_evt['evt'] = None
        panel = _ui.allToolbarPanels.itemById(PANEL_ID)
        if panel:
            c = panel.controls.itemById(CMD_ID)
            if c:
                c.deleteMe()
        cd = _ui.commandDefinitions.itemById(CMD_ID)
        if cd:
            cd.deleteMe()
    except Exception:
        pass
    _handlers.clear()
