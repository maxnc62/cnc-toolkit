import adsk.core
import adsk.fusion
import traceback
import os
import json
import re
import math

# Apercu fluide partage (cnc_apercu_fluide.py a la racine de ToolkitCNC) : pastilles glissees par la
# souris, hors du cycle de commande Fusion (valide sur Traverse le 2026-11-04).
try:
    import sys as _sys
    _RACINE_TK = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if _RACINE_TK not in _sys.path:
        _sys.path.insert(0, _RACINE_TK)
    import cnc_apercu_fluide as _caf
except Exception:
    _caf = None

# ---------------------------------------------------------------------------
# Reseau sur la trajectoire CNC : meme outil que Solide > Creer > Reseau >
# Reseau sur la trajectoire (memes champs : type, type d'objet, objets,
# chemin, masquer, quantite, distance, point de depart, repartition,
# direction, orientation), avec en plus une CONTRAINTE AU PLAN (demande de
# l'utilisateur le 2026-10-12) : on choisit la face du corps "objet" qui doit
# se poser contre un plan (plan de decalage, plan d'origine, face plane).
#
# PRINCIPE
#   - Le resultat est toujours une VRAIE PathPatternFeature (fonction native,
#     parametrique, modifiable ensuite avec la boite native de Fusion) ;
#     l'apercu est cette meme fonction (corps gris).
#   - Contrainte au plan (corps seulement) : le chemin est PROJETE dans une
#     esquisse sur le plan choisi, et le reseau suit cette projection. Elle
#     reste liee au chemin d'origine : modifier une cote, un parametre ou la
#     longueur du chemin plus tot dans la timeline met le reseau a jour
#     (demande de l'utilisateur le 2026-10-13). Le chemin projete etant plan,
#     les copies ne tournent qu'autour de la normale du plan et ne decollent
#     pas du plan (limite du reseau natif sur un chemin en 3D). Si la face
#     d'appui choisie n'est pas sur le plan, une fonction Deplacer y pose le
#     corps d'origine. Esquisse + Deplacer + Reseau sont regroupes dans la
#     timeline ("Reseau trajectoire CNC").
#   - Les reglages (hors selections) sont memorises dans reseau_prefs.json.
# ---------------------------------------------------------------------------

_app = None
_ui = None
_handlers = []

CMD_ID       = 'ReseauTrajectoireCNCCmd'
COMMAND_NAME = 'Reseau sur la trajectoire CNC'
COMMAND_DESC = ('Reseau sur la trajectoire identique a celui de Fusion, avec en plus '
                'le choix de la face du corps a poser contre un plan')
PANEL_ID     = 'SolidCreatePanel'

_ADDIN_DIR = os.path.dirname(os.path.abspath(__file__))
PREFS_FILE = os.path.join(_ADDIN_DIR, 'reseau_prefs.json')
RESOURCES  = os.path.join(_ADDIN_DIR, 'resources')
GROUPE_TIMELINE = 'Reseau trajectoire CNC'

TYPES_OBJET  = [('corps', 'Corps'), ('faces', 'Faces'), ('fonctions', 'Fonctions'),
                ('composants', 'Composants')]
REPERES      = [('gauche', 'Face de gauche'), ('centre', 'Centre'), ('droite', 'Face de droite')]
REPARTITIONS = [('etendue', 'Étendue'), ('espacement', 'Espacement')]
DIRECTIONS   = [('une', 'Une direction'), ('symetrique', 'Symétrique')]
ORIENTATIONS = [('identique', 'Identique'), ('trajectoire', 'Direction de la trajectoire')]
CALCULS      = [('optimise', 'Optimisé'), ('identique', 'Identique'), ('ajuster', 'Ajuster')]

FILTRES_OBJET = {
    'corps': ('SolidBodies', 'SurfaceBodies'),
    'faces': ('Faces',),
    'fonctions': ('Features',),
    'composants': ('Occurrences',),
}

DEFAULT_PREFS = {
    'type_objet': 'corps', 'quantite': 3, 'repartition': 'etendue',
    'direction': 'une', 'orientation': 'identique', 'calcul': 'optimise',
    'inverser': False, 'qte_regle': True, 'regle_qte': '150:2, 300:3, 500:4, 700:5, +200',
    'ignorer_jonction': True,
}

_pending_prefs = None
# Le chemin change : on remet Distance a la longueur du chemin (comme la
# boite native) sauf si l'utilisateur a tape une distance depuis.
_dernier_chemin = None


def load_prefs():
    p = dict(DEFAULT_PREFS)
    try:
        with open(PREFS_FILE, 'r', encoding='utf-8') as f:
            saved = json.load(f)
        p.update({k: saved[k] for k in DEFAULT_PREFS if k in saved})
    except Exception:
        pass
    p['quantite'] = DEFAULT_PREFS['quantite']      # toujours 3 au demarrage
    if p.get('regle_qte') == '290:3, 500:4, 700:5, +200':
        p['regle_qte'] = DEFAULT_PREFS['regle_qte']      # ancienne regle par defaut
    return p


def save_prefs(prefs):
    try:
        p = load_prefs()
        p.update({k: prefs[k] for k in DEFAULT_PREFS if k in prefs})
        tmp = PREFS_FILE + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(p, f, indent=2, ensure_ascii=False)
        os.replace(tmp, PREFS_FILE)
    except Exception:
        pass


# --- Commandes natives (icones et boutons "Type") ---------------------------

_natifs = {}


IDS_NATIFS = {'PathPattern': 'PatternOnPath', 'RectangularPattern': 'PatternRectangular',
              'CircularPattern': 'PatternCircular'}


def _cmd_native(motcle):
    """Commande native de Fusion ('PathPattern', 'RectangularPattern',
    'CircularPattern') : Reseau sur la trajectoire / rectangulaire /
    circulaire du panneau Creer."""
    if motcle in _natifs:
        return _natifs[motcle]
    try:
        trouve = _ui.commandDefinitions.itemById(IDS_NATIFS[motcle])
    except Exception:
        trouve = None
    _natifs[motcle] = trouve
    return trouve


def _icone_native(motcle):
    d = _cmd_native(motcle)
    try:
        f = d.resourceFolder if d else ''
        return f if f and os.path.isfile(os.path.join(f, '16x16.png')) else ''
    except Exception:
        return ''


# --- Inputs -----------------------------------------------------------------

def _dropdown(inputs, id_, label, items, current):
    dd = inputs.addDropDownCommandInput(id_, label, adsk.core.DropDownStyles.TextListDropDownStyle)
    keys = [k for k, _ in items]
    if current not in keys:
        current = keys[0]
    for k, txt in items:
        dd.listItems.add(txt, k == current, '')
    return dd


def _dd_key(dd, items):
    sel = dd.selectedItem
    if sel is None:
        return items[0][0]
    # Par position (les libelles accentues ne servent pas de cle).
    try:
        return items[sel.index][0]
    except Exception:
        pass
    for k, txt in items:
        if txt == sel.name:
            return k
    return items[0][0]


def _selections(sel_input):
    return [sel_input.selection(i).entity for i in range(sel_input.selectionCount)]


def _set_filtres_objets(inputs):
    sel = inputs.itemById('objets')
    t = _dd_key(inputs.itemById('type_objet'), TYPES_OBJET)
    sel.clearSelectionFilter()
    for f in FILTRES_OBJET[t]:
        sel.addSelectionFilter(f)


def _build_inputs(cmd):
    p = load_prefs()
    inputs = cmd.commandInputs
    um = _app.activeProduct.unitsManager

    _dropdown(inputs, 'type_objet', "Type d'objet", TYPES_OBJET, p['type_objet'])
    nc = inputs.addBoolValueInput('nc_ouvrir', 'Nouvel objet…', False, '', False)
    nc.tooltip = ("Cree un corps ou un composant (largeur, hauteur, epaisseur, tenons) dans le composant masque « CNC Toolkit ». "
                  "Cette boite se ferme le temps de la creation, puis se rouvre.")
    bib = inputs.addDropDownCommandInput('biblio', 'Bibliothèque', adsk.core.DropDownStyles.TextListDropDownStyle)
    bib.listItems.add('— choisir une pièce —', True, '')
    for e in _nc_liste():
        bib.listItems.add(e['nom'], False, '')
    bib.tooltip = "Pieces creees avec « Nouvel objet » (composant masque CNC Toolkit) : la piece choisie devient l'objet du reseau."

    mod = inputs.addBoolValueInput('nc_modifier', 'Modifier la pièce choisie…', False, '', False)
    mod.tooltip = ("Modifie largeur, hauteur, epaisseur et nom de la piece choisie dans la bibliotheque ; "
                   "les copies et les tenons qui en dependent suivent. Cette boite se ferme le temps de la modification.")
    sel = inputs.addSelectionInput('objets', 'Objets', 'Objets a dupliquer')
    sel.setSelectionLimits(1, 1)
    # Chemin juste sous Objet, au-dessus de la vignette de la piece (Maxence 2026-11-14)
    ch = inputs.addSelectionInput('chemin', 'Chemin', 'Arete ou courbe d\'esquisse a suivre')
    ch.addSelectionFilter('Edges')
    ch.addSelectionFilter('SketchCurves')
    ch.setSelectionLimits(1, 0)
    bi = inputs.addImageCommandInput('biblio_img', '', _png_apercu_corps(40.0, 30.0, 1.8))
    bi.isFullWidth = True
    bi.isVisible = False
    grp = inputs.addGroupCommandInput('opt', 'Paramètre optionnel')
    grp.isExpanded = False
    gi = grp.children
    rp = gi.addButtonRowCommandInput('repere', 'Repère', False)
    for k, nom in REPERES:
        rp.listItems.add(nom, k == 'centre', os.path.join(RESOURCES, 'repere_' + k))
    rp.tooltip = ("Point du corps qui suit le chemin et porte la fleche : grande face "
                  "de gauche (cote debut du chemin), centre, ou grande face de droite "
                  "(cote ou part le reseau). Cette face arrive pile au bout du chemin.")
    _set_filtres_objets(inputs)
    ij = gi.addBoolValueInput('ignorer_jonction', 'Ignorer les jonctions CNC', True, '', bool(p['ignorer_jonction']))
    ij.tooltip = ("Le chemin est pris en entier, comme avant les jonctions CNC : l'arete coupee en deux "
                  "par une jonction est raccordee, et une jonction creee plus tard ne decale plus le reseau.")
    _jonc['on'] = bool(p['ignorer_jonction'])
    ec = gi.addBoolValueInput('eviter_cales', 'Éviter les cales de renfort', True, '', True)
    ec.tooltip = ("Une cale de renfort de jonction CNC (corps « Renfort_... ») est sur le chemin : deux corps du reseau "
                  "se placent de part et d'autre de la cale, avec le jeu ci-dessous, et les autres corps se repartissent "
                  "sur la distance restante. Marche avec « Copier le corps ».")
    jc = gi.addValueInput('jeu_cales', 'Jeu autour des cales', um.defaultLengthUnits,
                          adsk.core.ValueInput.createByReal(JEU_CALES))
    jc.tooltip = "Espace de fonctionnement entre un corps du reseau et une cale de renfort (2 mm par defaut)."
    cd = gi.addBoolValueInput('cree_debut', "Copier le corps", True, '', False)
    cd.tooltip = ("L'objet choisi n'est pas sur le chemin : l'outil en crée une copie au début "
                  "du chemin (meme orientation, posee sur le plan du chemin) et la duplique "
                  "le long du chemin. La face de gauche du 1er corps est au debut du chemin, "
                  "la face de droite du dernier au bout.")
    fc = gi.addBoolValueInput('fin_chemin', "Jusqu'au bout du chemin", True, '', False)
    fc.tooltip = ("La derniere copie reste au bout du chemin : si le chemin s'allonge ou "
                  "raccourcit (cote, parametre, extrusion), le reseau se recale tout seul.")
    pv = gi.addBoolValueInput('pivot', 'Pivoter (chant / face)', False, '', False)
    pv.tooltip = ("Tourne la copie du debut de 90 degres autour de la verticale : un clic passe du "
                  "chant contre le chemin a la face contre le chemin, un autre clic revient.")
    th = gi.addBoolValueInput('tenon_haut', 'Tenon du haut (traverse suspendue)', False, '', False)
    th.tooltip = ("Une traverse a deux tenons : par defaut elle est posee sur le chemin par son tenon du bas. "
                  "Coche : elle est retournee, de l'autre cote du chemin, accrochee par son tenon du haut.")
    ci = gi.addBoolValueInput('cote_inv', 'Inverser le cote (pivoter face)', False, '', False)
    ci.tooltip = ("Pivoter face : par defaut le corps se place du cote interieur de la courbe. "
                  "Coche : il passe de l'autre cote du chemin.")
    na = gi.addBoolValueInput('nb_auto', "Nombre selon la longueur", True, '', False)
    na.tooltip = ("Chaque chemin recoit autant de corps que sa longueur le permet : un corps "
                  "tous les « Espacement » au plus, le 1er au debut et le dernier au bout.")
    gi.addValueInput('pas_auto', 'Espacement entre corps', um.defaultLengthUnits,
                         adsk.core.ValueInput.createByReal(5.0))
    dlat = gi.addValueInput('decal_lat', 'Décalage latéral', um.defaultLengthUnits,
                                adsk.core.ValueInput.createByReal(0.0))
    dlat.tooltip = "Decale la copie du debut le long de son bord (dans le plan du chemin) : positif = vers la matiere. 0 = chant contre le chemin."
    dh = gi.addValueInput('decal_haut', 'Décalage en hauteur', um.defaultLengthUnits,
                              adsk.core.ValueInput.createByReal(0.0))
    dh.tooltip = ("Decale la copie perpendiculairement au plan du chemin (0 = le dessous de "
                  "l'objet repose sur le plan du chemin).")

    gi.addBoolValueInput('masquer', 'Masquer', True, '', False)
    tb = gi.addStringValueInput('masques', 'Copies masquées', '')
    tb.tooltip = ('Numeros des copies a ne pas creer, separes par des virgules '
                  '(1 = objet d\'origine). Ex : 2, 4')
    tb.isVisible = False

    qr = gi.addBoolValueInput('qte_regle', 'Quantité selon la longueur du chemin', True, '', bool(p['qte_regle']))
    qr.tooltip = ("À chaque chemin choisi, le nombre de corps vient de la règle ci-dessous "
                  "(longueur du chemin → nombre de corps). Tu peux ensuite l'ajuster à la main.")
    rg = gi.addStringValueInput('regle_qte', 'Règle (mm : corps)', str(p['regle_qte']))
    rg.tooltip = ("Jusqu'à telle longueur, tel nombre de corps. Ex : 150:2, 300:3, 700:5, +200 "
                  "= jusqu'à 150 mm 2 corps, jusqu'à 300 mm 3 corps, jusqu'à 700 mm 5 corps, puis "
                  "1 corps de plus tous les 200 mm.")
    gi.addIntegerSpinnerCommandInput('quantite', 'Quantité', 1, 10000, 1, int(p['quantite']))
    # Champ simple (pas de fleche) : un Distance natif affiche toujours sa
    # propre fleche droite depuis l'origine du dessin, loin du corps.
    gi.addValueInput('distance', 'Distance', um.defaultLengthUnits,
                         adsk.core.ValueInput.createByReal(1.0))
    ph = gi.addDistanceValueCommandInput('poignee', 'Ajuster',
                                             adsk.core.ValueInput.createByReal(0.0))
    ph.tooltip = ("Flèche posée sur la dernière copie : tire-la, la dernière copie "
                  "glisse le long du chemin et Distance s'ajuste.")
    ph.isVisible = False      # pas de fleche tant qu'aucun chemin n'est choisi
    # fleches supplementaires (une par chemin en mode « Copier le corps »), cachees
    # tant qu'il n'y a qu'un chemin : creees d'avance, on n'ajoute pas d'entree en cours de commande
    for k in range(1, NB_FLECHES):
        pk = gi.addDistanceValueCommandInput('poignee_%d' % k, 'Ajuster',
                                                 adsk.core.ValueInput.createByReal(0.0))
        pk.isVisible = False
    gi.addValueInput('depart', 'Point de départ', '', adsk.core.ValueInput.createByReal(0.0))
    _dropdown(gi, 'repartition', 'Répartition', REPARTITIONS, p['repartition'])
    _dropdown(gi, 'direction', 'Direction', DIRECTIONS, p['direction'])
    _dropdown(gi, 'orientation', 'Orientation', ORIENTATIONS, p['orientation'])
    gi.addBoolValueInput('inverser', 'Inverser le sens', True, '', bool(p['inverser']))
    _dropdown(gi, 'calcul', 'Type de calcul', CALCULS, p['calcul'])

    for k in range(NB_FLECHES):
        sl = gi.addIntegerSliderCommandInput('qs_%d' % k, 'Chemin %d (corps)' % (k + 1), 1, QSMAX, False)
        sl.valueOne = int(p['quantite'])
        sl.tooltip = "Glisse la barre pour changer la quantité de corps sur ce chemin."
        sl.isVisible = False

    msg = inputs.addTextBoxCommandInput('msg', '', '', 2, True)
    msg.isFullWidth = True
    msg.isVisible = False

    _update_visibility(inputs)


def _update_visibility(inputs):
    t = _dd_key(inputs.itemById('type_objet'), TYPES_OBJET)
    inputs.itemById('calcul').isVisible = (t == 'fonctions')
    inputs.itemById('masques').isVisible = bool(inputs.itemById('masquer').value)
    mode = _mode_debut(inputs)
    inputs.itemById('decal_lat').isVisible = mode
    inputs.itemById('decal_haut').isVisible = mode
    inputs.itemById('eviter_cales').isVisible = mode
    inputs.itemById('jeu_cales').isVisible = mode and bool(inputs.itemById('eviter_cales').value)
    inputs.itemById('repere').isEnabled = not mode
    auto = mode and bool(inputs.itemById('nb_auto').value)
    inputs.itemById('nb_auto').isVisible = mode
    inputs.itemById('pivot').isVisible = mode
    inputs.itemById('tenon_haut').isVisible = mode
    inputs.itemById('cote_inv').isVisible = mode
    inputs.itemById('pas_auto').isVisible = auto
    inputs.itemById('quantite').isEnabled = not auto
    inputs.itemById('qte_regle').isEnabled = not auto
    inputs.itemById('regle_qte').isVisible = bool(inputs.itemById('qte_regle').value) and not auto


_msg_vide = {'v': False}


def _set_msg(inputs, text):
    m = inputs.itemById('msg')
    text = text or ''
    if m.text != text:
        m.text = text
    if m.isVisible != bool(text):
        m.isVisible = bool(text)


def _current_prefs(inputs):
    return {
        'type_objet': _dd_key(inputs.itemById('type_objet'), TYPES_OBJET),
        'quantite': int(inputs.itemById('quantite').value),
        'repartition': _dd_key(inputs.itemById('repartition'), REPARTITIONS),
        'direction': _dd_key(inputs.itemById('direction'), DIRECTIONS),
        'orientation': _dd_key(inputs.itemById('orientation'), ORIENTATIONS),
        'calcul': _dd_key(inputs.itemById('calcul'), CALCULS),
        'inverser': bool(inputs.itemById('inverser').value),
        'qte_regle': bool(inputs.itemById('qte_regle').value),
        'regle_qte': inputs.itemById('regle_qte').value,
        'ignorer_jonction': _ignorer_jonction(inputs),
    }


def _masques(inputs):
    """Numeros (1 = origine) des copies a ne pas creer."""
    res = set()
    for morceau in inputs.itemById('masques').value.replace(';', ',').split(','):
        morceau = morceau.strip()
        if '-' in morceau:
            a, _, b = morceau.partition('-')
            try:
                res.update(range(int(a), int(b) + 1))
            except ValueError:
                pass
        elif morceau.isdigit():
            res.add(int(morceau))
    if not _mode_debut(inputs):
        res.discard(1)      # l'objet d'origine reste ; la copie du debut, elle, peut etre masquee
    return res


# --- Geometrie du chemin ------------------------------------------------------

def _vec(a, b):
    return adsk.core.Vector3D.create(b.x - a.x, b.y - a.y, b.z - a.z)


def _dist(a, b):
    return a.distanceTo(b)


def _courbe_monde(ent):
    """Courbe 3D (espace du document) d'une arete ou courbe d'esquisse."""
    if isinstance(ent, adsk.core.Curve3D):
        return ent.copy()              # segment de raccord d'une jonction (geometrie pure)
    n = ent.nativeObject if getattr(ent, 'assemblyContext', None) is not None else ent
    if isinstance(n, adsk.fusion.BRepEdge):
        g = n.geometry.copy()
    elif isinstance(n, adsk.fusion.SketchCurve):
        g = n.worldGeometry.copy()
    else:
        return None
    ctx = getattr(ent, 'assemblyContext', None)
    if ctx is not None:
        g.transformBy(ctx.transform2)
    return g


class _Chemin:
    """Chemin echantillonnable par abscisse curviligne. Les segments sont
    remis bout a bout (le sens du premier est choisi pour toucher le 2e)."""

    def __init__(self, entites):
        segs = []
        for e in entites:
            c = _courbe_monde(e)
            if c is None:
                continue
            ev = c.evaluator
            ok, p0, p1 = ev.getParameterExtents()
            ok, L = ev.getLengthAtParameter(p0, p1)
            ok, a = ev.getPointAtParameter(p0)
            ok, b = ev.getPointAtParameter(p1)
            if L > 1e-9:
                segs.append({'ev': ev, 'p0': p0, 'p1': p1, 'L': L, 'a': a, 'b': b, 'inv': False, 'ent': e})
        if not segs:
            raise ValueError('Chemin vide.')
        segs = self._ordonner(segs)
        self.segs = segs
        self.longueur = sum(s['L'] for s in segs)
        self.ferme = _dist(self._debut(segs[0]), self._fin(segs[-1])) < 1e-4

    @staticmethod
    def _debut(s):
        return s['b'] if s['inv'] else s['a']

    @staticmethod
    def _fin(s):
        return s['a'] if s['inv'] else s['b']

    def _ordonner(self, segs):
        if len(segs) == 1:
            return segs
        # Chainage glouton depuis un segment d'extremite (ou le premier).
        restants = segs[:]

        def voisins(s, pt):
            return sum(1 for o in segs if o is not s and min(_dist(pt, o['a']), _dist(pt, o['b'])) < 1e-4)

        depart = restants[0]
        for s in restants:
            if voisins(s, s['a']) == 0:
                depart = s
                break
            if voisins(s, s['b']) == 0:
                depart = s
                s['inv'] = True
                break
        else:
            depart['inv'] = _dist(depart['a'], restants[1]['a']) < 1e-4 or \
                _dist(depart['a'], restants[1]['b']) < 1e-4
        restants.remove(depart)
        ordre = [depart]
        while restants:
            fin = self._fin(ordre[-1])
            best = min(restants, key=lambda o: min(_dist(fin, o['a']), _dist(fin, o['b'])))
            best['inv'] = _dist(fin, best['b']) < _dist(fin, best['a'])
            restants.remove(best)
            ordre.append(best)
        return ordre

    def renverser(self):
        """Parcourt le chemin dans l'autre sens."""
        self.segs = [dict(s, inv=not s['inv']) for s in reversed(self.segs)]
        self._tab = None

    @property
    def debut(self):
        return self._debut(self.segs[0])

    @property
    def fin(self):
        return self._fin(self.segs[-1])

    @property
    def entites(self):
        return [sg['ent'] for sg in self.segs]

    def abscisse_proche(self, pt, smin=0.0, smax=None, n=400):
        """Abscisse du point du chemin le plus proche de pt, dans [smin, smax]."""
        smax = self.longueur if smax is None else smax
        if smax - smin < 1e-9:
            return smin
        pas = (smax - smin) / n
        px, py, pz = pt.x, pt.y, pt.z

        def _d2(k):      # balayage grossier en flottants (table), sans appel API
            q = self.fast(smin + k * pas)[0]
            return (q[0] - px) ** 2 + (q[1] - py) ** 2 + (q[2] - pz) ** 2
        best = min(range(n + 1), key=_d2)

        def _d2m(sv):    # raffinage sur la table (erreur d'interpolation < 1e-6 cm)
            q = self.fast(sv)[0]
            return (q[0] - px) ** 2 + (q[1] - py) ** 2 + (q[2] - pz) ** 2
        a, b = max(smin, smin + (best - 1) * pas), min(smax, smin + (best + 1) * pas)
        for _ in range(30):
            m1, m2 = a + (b - a) / 3, b - (b - a) / 3
            if _d2m(m1) < _d2m(m2):
                b = m2
            else:
                a = m1
        return (a + b) / 2

    def table(self, n=1500):
        """Echantillons (points, tangentes) en flottants tous les L/n : permet
        des evaluations sans appel a l'API (apercu fluide)."""
        t = getattr(self, '_tab', None)
        if t is None:
            pts, tgs = [], []
            for k in range(n + 1):
                p, d = self.point_tangente(self.longueur * k / n)
                pts.append((p.x, p.y, p.z))
                tgs.append((d.x, d.y, d.z))
            t = self._tab = (n, pts, tgs)
        return t

    def fast(self, s):
        """Comme point_tangente mais en flottants, par interpolation de table."""
        n, pts, tgs = self.table()
        L = self.longueur
        if self.ferme:
            s = s % L
        s = 0.0 if s < 0.0 else (L if s > L else s)
        u = s / L * n
        i = int(u)
        if i >= n:
            i = n - 1
        f = u - i
        a, b = pts[i], pts[i + 1]
        ta, tb = tgs[i], tgs[i + 1]
        tx, ty, tz = ta[0] + (tb[0] - ta[0]) * f, ta[1] + (tb[1] - ta[1]) * f, ta[2] + (tb[2] - ta[2]) * f
        ln = math.sqrt(tx * tx + ty * ty + tz * tz) or 1.0
        return ((a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, a[2] + (b[2] - a[2]) * f),
                (tx / ln, ty / ln, tz / ln))

    def point_tangente(self, s):
        """Point et tangente unitaire a l'abscisse s (0..longueur)."""
        if self.ferme:
            s = s % self.longueur
        s = max(0.0, min(self.longueur, s))
        cumul = 0.0
        seg = self.segs[-1]
        loc = seg['L']
        for sg in self.segs:
            if s <= cumul + sg['L'] + 1e-12:
                seg, loc = sg, s - cumul
                break
            cumul += sg['L']
        ev = seg['ev']
        l = (seg['L'] - loc) if seg['inv'] else loc
        ok, prm = ev.getParameterAtLength(seg['p0'], max(0.0, min(seg['L'], l)))
        ok, pt = ev.getPointAtParameter(prm)
        ok, d = ev.getFirstDerivative(prm)
        if seg['inv']:
            d.scaleBy(-1)
        d.normalize()
        return pt, d


def _abscisses(q, D, s0, L, repartition, symetrique, inverse, ferme):
    """Abscisses des instances (la 1re = l'objet d'origine, a s0). Memes
    regles que le reseau natif : Etendue = D entre la 1re et la derniere,
    Espacement = D entre deux instances ; Symetrique = de part et d'autre."""
    if q < 1:
        return []
    if symetrique:
        # Comme le natif (mesure du 2026-10-16) : Distance = etendue E d'UN cote
        # (etendue) ou pas (espacement). Impair : centre sur l'objet. Pair :
        # de -q/2 a q/2-1 pas (une copie de plus d'un cote), pas = 2 E / (q - 1).
        if q == 1:
            return [s0]
        pas = 2.0 * D / (q - 1) if repartition == 'etendue' else D
        if q % 2:
            ks = [0]
            k = 1
            while len(ks) < q:
                ks += [k, -k]
                k += 1
        else:
            ks = list(range(-(q // 2), q // 2))
            if inverse:
                ks = [-k for k in ks]
        return [s0 + k * pas for k in ks]
    if repartition == 'etendue':
        if q == 1:
            pas = 0.0
        elif ferme and abs(D - L) < 1e-6:
            pas = D / q   # tour complet : pas de doublon a l'arrivee
        else:
            pas = D / (q - 1)
    else:
        pas = D
    if inverse:
        pas = -pas
    return [s0 + i * pas for i in range(q)]


# --- Chemin -------------------------------------------------------------------

def _construire_chemin(ents):
    """(Path de Fusion, _Chemin) pour les entites choisies, dans l'ordre ou
    elles se suivent (dans l'ordre du clic, Fusion faisait un chemin decousu
    et une copie partait hors du chemin, essai du 2026-10-12). Un simple clic
    ne prend QUE l'arete cliquee ; le double clic ajoute les aretes
    connectees du meme plan (voir _etendre_plan)."""
    design = adsk.fusion.Design.cast(_app.activeProduct)
    feats = design.activeComponent.features
    chemin = _Chemin(ents)
    cc = adsk.core.ObjectCollection.create()
    for c in chemin.entites:
        cc.add(c)
    return feats.createPath(cc, False), chemin


def _chemin_de_path(path, reglages=None):
    """(entites, _Chemin) d'un Path de Fusion deja cree (meme ordre et meme sens qu'a la creation)."""
    ents = [path.item(i).entity for i in range(path.count)]
    return ents, _Chemin(ents)


_rep_echec = set()


def _chaine_esquisse(e, tol=None):
    """Courbes du chemin : toutes celles de l'esquisse « Chemin du reseau » (elle ne contient que le chemin et ses
    raccords), e en tete."""
    return [e] + [c for c in e.parentSketch.sketchCurves if c.entityToken != e.entityToken]


def _souder_ponts(chaine):
    """Les petits segments de raccord (non projetes) ne suivent pas les courbes projetees quand la spline
    d'origine est deplacee (ils restent a l'ancien endroit de la jonction, parfois a plusieurs cm). On les
    ramene entre les deux bouts de courbes les plus proches (le trou de la jonction), exactement sur ces bouts
    (Fusion refuse un chemin discontinu)."""
    sk = chaine[0].parentSketch

    def est_pont(c):
        return adsk.fusion.SketchLine.cast(c) is not None and not c.isReference and c.length < JONC_TOL
    ponts = [c for c in chaine if est_pont(c)]
    refs = [c for c in chaine if not est_pont(c)]
    bouts = []
    for c in refs:
        for nom in ('startSketchPoint', 'endSketchPoint'):
            bouts.append((c, getattr(c, nom).worldGeometry))
    utilises = set()
    for ln in ponts:
        best = None
        for i, (ca, pa) in enumerate(bouts):
            for k, (cb, pb) in enumerate(bouts):
                if k <= i or ca.entityToken == cb.entityToken or i in utilises or k in utilises:
                    continue
                d = pa.distanceTo(pb)
                if 1e-6 < d < JONC_TOL and (best is None or d < best[0]):
                    best = (d, i, k)
        if best is None:
            continue
        _d, i, k = best
        p, q = bouts[i][1], bouts[k][1]
        a, b = ln.startSketchPoint, ln.endSketchPoint
        if a.worldGeometry.distanceTo(p) + b.worldGeometry.distanceTo(q) > a.worldGeometry.distanceTo(q) + b.worldGeometry.distanceTo(p):
            p, q = q, p
        for sp, cible in ((a, p), (b, q)):
            tgt = sk.modelToSketchSpace(cible)
            cur = sp.geometry
            try:
                sp.move(adsk.core.Vector3D.create(tgt.x - cur.x, tgt.y - cur.y, tgt.z - cur.z))
            except Exception:
                _log('souder pont erreur %s' % traceback.format_exc()[-200:])
        utilises.update([i, k])


def _reparer_path(feat, reglages):
    """Le chemin de Fusion d'un reseau suivant l'esquisse « Chemin du reseau » a perdu des courbes (la spline
    d'origine a ete modifiee : Fusion ne garde que les courbes dont il retrouve l'identite) : le reseau suit
    alors un bout de chemin et les corps partent dans tous les sens. On rebranche le reseau sur toute la
    chaine de l'esquisse, parcourue dans le sens de la creation. Renvoie la fonction (relue)."""
    tok = feat.entityToken
    try:
        if tok in _rep_echec:
            return feat
        path = feat.path
        e = path.item(0).entity
        if adsk.fusion.SketchCurve.cast(e) is None or not e.parentSketch.name.startswith('Chemin du reseau'):
            return feat
        chaine = _chaine_esquisse(e)
        if len(chaine) <= path.count:
            return feat
        _souder_ponts(chaine)
        ch = _Chemin(chaine)
        d0 = (reglages or {}).get('debut')
        if d0:
            ref = adsk.core.Point3D.create(d0[0], d0[1], d0[2])
        else:
            pe = path.item(0)
            ev = pe.curve.evaluator
            ok, p0, p1 = ev.getParameterExtents()
            ok, ref = ev.getPointAtParameter(p1 if pe.isOpposedToEntity else p0)
        if not ch.ferme and ch.fin.distanceTo(ref) < ch.debut.distanceTo(ref):
            ch.renverser()
        toks = [c.entityToken for c in ch.entites]
        design = adsk.fusion.Design.cast(_app.activeProduct)
        tl = design.timeline
        grp = _deplier_groupe(design, feat)
        ok = False
        try:
            feat.timelineObject.rollTo(True)
            cc = adsk.core.ObjectCollection.create()
            for t in toks:
                r = design.findEntityByToken(t)
                if not r:
                    raise ValueError('courbe du chemin introuvable')
                cc.add(r[0])
            pnew = feat.parentComponent.features.createPath(cc, False)
            orient = bool(feat.isOrientationAlongPath)
            try:
                feat.path = pnew
            except RuntimeError:
                # point de depart / sens de l'ancien chemin incompatibles avec le nouveau : on les remet a zero
                feat.startPoint = 0.0
                feat.isFlipDirection = False
                feat.path = pnew
            feat.isOrientationAlongPath = orient
            ok = True
        finally:
            tl.moveToEnd()
            _replier_groupe(grp)
        _log('reparer chemin %s : %d courbe(s) au lieu de %d -> %s' % (feat.name, len(chaine), path.count, 'fait' if ok else 'rien'))
        r = design.findEntityByToken(tok)
        return adsk.fusion.PathPatternFeature.cast(r[0]) if r else feat
    except Exception:
        _log('reparer chemin erreur %s' % traceback.format_exc()[-500:])
        _rep_echec.add(tok)
        try:
            adsk.fusion.Design.cast(_app.activeProduct).timeline.moveToEnd()
        except Exception:
            pass
        return feat


_cache_ch = {}


def _chemin_cache(ents):
    """_Chemin des entites choisies, sans recreer le Path de Fusion : pendant le
    glisser de la fleche on le reconstruisait plusieurs fois par mouvement."""
    cle = tuple(e.entityToken for e in ents) + (bool(_jonc['on']),)
    ch = _cache_ch.get(cle)
    if ch is None:
        if len(_cache_ch) > 10:
            _cache_ch.clear()
        ch = None
        if _jonc['on']:
            try:
                ch = _chemin_sans_jonction_geo(ents)
            except Exception:
                _log('chemin sans jonction (geo) erreur %s' % traceback.format_exc()[-300:])
        if ch is None:
            ch = _construire_chemin(ents)[1]
        _cache_ch[cle] = ch
    return ch


def _jonc_voisines(a, b):
    """Deux aretes separees par un trait de jonction : bouts a moins de JONC_TOL, alignes et face a face."""
    try:
        ea, eb = adsk.fusion.BRepEdge.cast(a), adsk.fusion.BRepEdge.cast(b)
        if ea is None or eb is None:
            return False
        for P, T, _v in _jonc_bouts(ea):
            for Q, U, _w in _jonc_bouts(eb):
                d = P.distanceTo(Q)
                if d < 1e-4 or d > JONC_TOL:
                    continue
                w = P.vectorTo(Q)
                w.normalize()
                if w.dotProduct(T) >= math.cos(math.radians(40.0)) and T.dotProduct(U) <= -math.cos(math.radians(25.0)):
                    return True
    except Exception:
        pass
    return False


_cache_grp = {}


def _groupes_chemin(ents):
    """Chemins distincts parmi les entites choisies : les courbes dont les
    extremites se touchent forment un meme chemin."""
    cle = tuple(e.entityToken for e in ents) + (bool(_jonc['on']),)
    if cle in _cache_grp:
        return _cache_grp[cle]
    bouts = []
    for e in ents:
        try:
            ev = _courbe_monde(e).evaluator
            ok, p0, p1 = ev.getParameterExtents()
            bouts.append((ev.getPointAtParameter(p0)[1], ev.getPointAtParameter(p1)[1]))
        except Exception:
            bouts.append(None)
    n = len(ents)
    parent = list(range(n))

    def racine(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    for i in range(n):
        for j in range(i + 1, n):
            if bouts[i] and bouts[j] and min(_dist(a, b) for a in bouts[i] for b in bouts[j]) < 1e-4:
                parent[racine(j)] = racine(i)
            elif bouts[i] and bouts[j] and _jonc['on'] and _jonc_voisines(ents[i], ents[j]):
                parent[racine(j)] = racine(i)      # les deux cotes d'une jonction CNC : un seul chemin
    groupes = {}
    for i in range(n):
        groupes.setdefault(racine(i), []).append(ents[i])
    res = list(groupes.values())
    if len(_cache_grp) > 10:
        _cache_grp.clear()
    _cache_grp[cle] = res
    return res


def _ents_actifs(inputs):
    """Entites du chemin affiche dans la boite : en mode « Copier le corps »
    avec plusieurs chemins, le premier ; sinon toute la selection."""
    ents = _selections(inputs.itemById('chemin'))
    if len(ents) > 1 and _mode_debut(inputs):
        g = _groupes_chemin(ents)
        if g:
            return g[0]
    return ents


# --- Double clic : toutes les aretes connectees du meme plan -----------------

def _dans_plan(edge, plan, tol=1e-4):
    ev = edge.evaluator
    ok, p0, p1 = ev.getParameterExtents()
    for t in (0.0, 0.25, 0.5, 0.75, 1.0):
        ok, pt = ev.getPointAtParameter(p0 + (p1 - p0) * t)
        v = plan.origin.vectorTo(pt)
        if abs(v.dotProduct(plan.normal)) > tol:
            return False
    return True


def _plans_candidats(edge):
    """Plans qui peuvent contenir l'arete : son propre plan si c'est un arc ou
    un cercle, sinon les faces planes qui la bordent."""
    plans = []
    g = edge.geometry
    for typ in (adsk.core.Circle3D, adsk.core.Arc3D, adsk.core.Ellipse3D, adsk.core.EllipticalArc3D):
        c = typ.cast(g)
        if c is not None:
            try:
                plans.append(adsk.core.Plane.create(c.center, c.normal))
                return plans
            except Exception:
                pass
    # la plus grande face d'abord : a nombre d'aretes egal, c'est la grande
    # face du panneau qui est visee, pas son chant
    for f in sorted(edge.faces, key=lambda f: -f.area):
        pl = adsk.core.Plane.cast(f.geometry)
        if pl is not None:
            plans.append(pl)
    return plans


def _etendre_brep(seed):
    best = [seed]
    for plan in _plans_candidats(seed):
        vus = {seed.entityToken: seed}
        pile = [seed]
        while pile:
            e = pile.pop()
            for v in (e.startVertex, e.endVertex):
                for o in v.edges:
                    if o.entityToken in vus:
                        continue
                    try:
                        if _dans_plan(o, plan):
                            vus[o.entityToken] = o
                            pile.append(o)
                    except Exception:
                        pass
        if len(vus) > len(best):
            best = list(vus.values())
    return best


def _etendre_esquisse(seed):
    vus = {seed.entityToken: seed}
    pile = [seed]
    while pile:
        c = pile.pop()
        for pt in (c.startSketchPoint, c.endSketchPoint):
            if pt is None:
                continue
            for o in pt.connectedEntities:
                o = adsk.fusion.SketchCurve.cast(o)
                if o is not None and o.entityToken not in vus:
                    vus[o.entityToken] = o
                    pile.append(o)
    return list(vus.values())


def _etendre_plan(seed):
    """Aretes (ou courbes d'esquisse) connectees a seed et situees dans le meme
    plan. Au pire : seed seule."""
    try:
        if adsk.fusion.BRepEdge.cast(seed) is not None:
            return _etendre_brep(seed)
        if adsk.fusion.SketchCurve.cast(seed) is not None:
            return _etendre_esquisse(seed)
    except Exception:
        _log('etendre_plan erreur %s' % traceback.format_exc()[-600:])
    return [seed]


_clics = {'ents': {}, 't': {}}


def _suivre_clics(inputs):
    """Detecte un double clic dans la selection du chemin : le 2e clic sur la
    meme arete, dans les 0,6 s, la deselectionne (ou la laisse selectionnee) ;
    on prend alors toutes les aretes connectees du meme plan."""
    import time
    sel = inputs.itemById('chemin')
    now = time.perf_counter()
    cur = {}
    for i in range(sel.selectionCount):
        e = sel.selection(i).entity
        cur[e.entityToken] = e
    avant = _clics['ents']
    ajoutees = [k for k in cur if k not in avant]
    retirees = [k for k in avant if k not in cur]
    seed = None
    if len(retirees) == 1 and not ajoutees and now - _clics['t'].get(retirees[0], -9.0) < 0.6:
        seed = avant[retirees[0]]
    elif len(ajoutees) == 1 and now - _clics['t'].get(ajoutees[0], -9.0) < 0.6:
        seed = cur[ajoutees[0]]
    for k in ajoutees:
        _clics['t'][k] = now
    if seed is not None:
        _clics['t'].pop(seed.entityToken, None)
        sel.clearSelection()
        for e in _etendre_plan(seed):
            sel.addSelection(e)
        _log('double clic : %d aretes du meme plan' % sel.selectionCount)
        cur = {}
        for i in range(sel.selectionCount):
            e = sel.selection(i).entity
            cur[e.entityToken] = e
    _clics['ents'] = cur


def _debut_path(path):
    """Point de debut d'un Path de Fusion (document)."""
    pe = path.item(0)
    c = pe.curve
    ok, p0, p1 = c.evaluator.getParameterExtents()
    ok, a = c.evaluator.getPointAtParameter(p0)
    ok, b = c.evaluator.getPointAtParameter(p1)
    if path.count > 1:
        c2 = path.item(1).curve
        ok, q0, q1 = c2.evaluator.getParameterExtents()
        ok, a2 = c2.evaluator.getPointAtParameter(q0)
        ok, b2 = c2.evaluator.getPointAtParameter(q1)
        # le debut est l'extremite du 1er troncon qui ne touche pas le 2e
        return b if min(a.distanceTo(a2), a.distanceTo(b2)) < min(b.distanceTo(a2), b.distanceTo(b2)) else a
    return b if pe.isOpposedToEntity else a


def _sens_fusion(path, chemin):
    """(abscisse chez nous du debut du chemin de Fusion, +1/-1 selon que
    Fusion le parcourt dans notre sens ou non). Sur un chemin ferme, debut
    et fin sont confondus : comparer les bouts ne disait rien, Fusion
    pouvait tourner dans l'autre sens et les copies sortaient du chemin
    (projet ottoman, 2026-10-13). On regarde donc le debut ET le premier
    pas du chemin de Fusion."""
    pe = path.item(0)
    ev = pe.curve.evaluator
    ok, p0, p1 = ev.getParameterExtents()
    ok, L1 = ev.getLengthAtParameter(p0, p1)
    opp = bool(pe.isOpposedToEntity)
    if path.count > 1:
        # plus sur que le drapeau : le debut ne touche pas le 2e troncon
        d0 = _debut_path(path)
        ok, a = ev.getPointAtParameter(p0)
        opp = d0.distanceTo(a) > 1e-6
    ok, d0 = ev.getPointAtParameter(p1 if opp else p0)
    pas = min(0.1, L1 / 10.0)
    ok, pp = ev.getParameterAtLength(p0, (L1 - pas) if opp else pas)
    ok, q = ev.getPointAtParameter(pp)
    off = chemin.abscisse_proche(d0)
    pa = chemin.point_tangente(off + pas)[0]
    pb = chemin.point_tangente(off - pas)[0]
    return off, (1.0 if pa.distanceTo(q) <= pb.distanceTo(q) else -1.0)


def _params_fusion(path, chemin, s0, s_cible):
    """(startPoint, distance, isFlipDirection) de Fusion pour un objet a
    l'abscisse s0 et la copie visee a s_cible (abscisses de notre _Chemin).
    Fusion mesure Distance depuis le debut de SON chemin, qui peut commencer
    ailleurs et etre parcouru dans l'autre sens que le notre."""
    L = chemin.longueur
    try:
        off, sgn = _sens_fusion(path, chemin)
    except Exception:
        _log('sens_fusion erreur %s' % traceback.format_exc()[-400:])
        off, sgn = 0.0, 1.0
    if chemin.ferme:
        # Chemin ferme : mesures du 2026-10-13 (boucle de 4 troncons, 4
        # ordres de clic) : avec startPoint 0 Fusion fait glisser l'objet
        # depuis SA position, dans son sens de parcours, de Distance ; avec
        # startPoint 1 + inverse, dans l'autre sens. Tout autre startPoint
        # donnait des copies hors du chemin.
        glisse = max(-L, min(L, sgn * (s_cible - s0)))
        if glisse >= 0:
            return 0.0, glisse, False
        return 1.0, -glisse, True
    sf0 = max(0.0, min(L, sgn * (s0 - off)))
    s_cible = sf0 + sgn * (s_cible - s0)
    if sf0 >= L - 1e-9 and L > 0 and s_cible < sf0 - 1e-9:
        dist, flip = L - s_cible, True       # parti de la fin du chemin Fusion, vers le debut
    elif s_cible >= 0:
        dist, flip = s_cible, False
    else:
        dist, flip = L - s_cible, True       # mesuree depuis la fin du chemin
    return (sf0 / L if L > 0 else 0.0), dist, flip


# --- Apercu en lignes orange -------------------------------------------------
# Creer le vrai reseau a chaque changement de reglage (corps compris) rendait
# l'apercu lourd (retour du 2026-10-16) : on dessine le contour des copies en
# lignes orange (graphiques temporaires) et le reseau natif n'est cree qu'a
# la validation. Positions : le centre de chaque copie suit le chemin, avec la
# meme translation que Fusion, et pivote autour de son centre quand
# l'orientation suit la trajectoire (mesure du 2026-10-16).

_orange = {'g': [], 'cle': None, 'struct': None, 'mats': []}


def _effacer_orange():
    _mgfx.clear()
    gs = _orange['g']
    _orange['g'] = []
    _orange['cle'] = None
    _orange['struct'] = None
    _orange['mats'] = []
    _orange['geo'] = None
    _orange['nvis'] = 0
    for g in gs:
        try:
            if g is not None and g.isValid:
                g.deleteMe()
        except Exception:
            pass


def _polylignes_objets(objs):
    """Contours (liste de points) des objets : aretes des corps, sinon boite."""
    corps = []
    for o in objs:
        try:
            if isinstance(o, adsk.fusion.BRepBody):
                corps.append(o)
            elif isinstance(o, adsk.fusion.Occurrence):
                corps.extend(o.bRepBodies)
            elif isinstance(o, adsk.fusion.BRepFace):
                corps.append(o)
            elif hasattr(o, 'bodies'):
                corps.extend(o.bodies)
        except Exception:
            continue
    lignes = []
    for b in corps:
        # une arete en echec (parametre hors bornes par arrondi) ne doit pas
        # arreter les suivantes : le contour restait incomplet
        try:
            aretes = list(b.edges)
        except Exception:
            continue
        for e in aretes:
            try:
                if adsk.core.Line3D.cast(e.geometry) is not None:
                    lignes.append([e.startVertex.geometry, e.endVertex.geometry])
                    continue
                ev = e.evaluator
                ok, p0, p1 = ev.getParameterExtents()
                pts = []
                for i in range(17):
                    t = min(p1, max(p0, p0 + (p1 - p0) * i / 16))
                    ok, pt = ev.getPointAtParameter(t)
                    pts.append(pt)
                lignes.append(pts)
            except Exception:
                continue
    if lignes:
        return lignes
    bb = None
    for o in objs:
        try:
            ob = o.boundingBox
            if bb is None:
                bb = adsk.core.BoundingBox3D.create(ob.minPoint, ob.maxPoint)
            else:
                bb.combine(ob)
        except Exception:
            continue
    if bb is None:
        return []
    a, b = bb.minPoint, bb.maxPoint
    P3 = adsk.core.Point3D.create
    c = [P3(x, y, z) for x in (a.x, b.x) for y in (a.y, b.y) for z in (a.z, b.z)]
    return [[c[i], c[j]] for i, j in ((0, 1), (2, 3), (4, 5), (6, 7), (0, 2), (1, 3), (4, 6), (5, 7),
                                      (0, 4), (1, 5), (2, 6), (3, 7))]


def _s_ref(ch, objs, c):
    """Abscisse du point du chemin le plus proche du centre des objets (en cache)."""
    cle = ('ref', round(ch.longueur, 5), len(ch.segs), _cle_objets(objs), round(c.x, 4), round(c.y, 4), round(c.z, 4))
    if cle not in _cache_pivot:
        _cache_pivot[cle] = ch.abscisse_proche(c)
    return _cache_pivot[cle]


_ctx = {'ok': False}
_uid = {'n': 0}


def _rot_vers(a, b):
    """Rotation (9 flottants par lignes) amenant le vecteur unitaire a sur b par
    l'arc le plus court ; None si identite."""
    vx = a[1] * b[2] - a[2] * b[1]
    vy = a[2] * b[0] - a[0] * b[2]
    vz = a[0] * b[1] - a[1] * b[0]
    c = a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
    if vx * vx + vy * vy + vz * vz < 1e-18:
        return None if c > 0 else (-1.0, 0.0, 0.0, 0.0, -1.0, 0.0, 0.0, 0.0, 1.0)
    k = 1.0 / (1.0 + c)
    return (1 - k * (vy * vy + vz * vz), -vz + k * vx * vy, vy + k * vx * vz,
            vz + k * vx * vy, 1 - k * (vx * vx + vz * vz), -vx + k * vy * vz,
            -vy + k * vx * vz, vx + k * vy * vz, 1 - k * (vx * vx + vy * vy))


# --- Cales de renfort de jonction ---------------------------------------------
# La fonction « Jonction CNC » peut poser une cale de renfort (corps « Renfort_... ») sur la
# bande, de part et d'autre de la coupe. Un corps du reseau qui tomberait dessus fusionnerait
# avec elle : on repartit donc les corps autour des cales, deux corps de chaque cote avec un
# jeu de fonctionnement, les autres se repartissant sur la distance restante.

CALE_PREFIXE = 'Renfort_'
JEU_CALES = 1.0            # cm : jeu entre un corps du reseau et une cale (10 mm)
CALE_PORTEE = 12.0         # cm : une cale a moins de cette distance du chemin le concerne


def _eviter_cales(inputs):
    try:
        return inputs.itemById('eviter_cales').value is True
    except Exception:
        return False


def _jeu_cales(inputs):
    try:
        x = inputs.itemById('jeu_cales').value
        if isinstance(x, bool) or x is None:
            return JEU_CALES
        return max(0.0, float(x))
    except Exception:
        return JEU_CALES


def _corps_cales():
    """Corps de cale de renfort du document (vus depuis la racine)."""
    design = adsk.fusion.Design.cast(_app.activeProduct)
    root = design.rootComponent
    res, vus = [], set()

    def ajouter(b):
        try:
            if b.isValid and b.name.startswith(CALE_PREFIXE):
                t = b.entityToken
                if t not in vus:
                    vus.add(t)
                    res.append(b)
        except Exception:
            pass
    for b in root.bRepBodies:
        ajouter(b)
    for occ in root.allOccurrences:
        for b in occ.bRepBodies:
            ajouter(b)
    return res


def _projeter_table(ch, p):
    """(distance, abscisse) du point du chemin le plus proche de p (table d'echantillons du chemin)."""
    n, pts, _tg = ch.table()
    L = ch.longueur
    px, py, pz = p.x, p.y, p.z
    best, bi = None, 0
    for i in range(n + 1):
        a = pts[i]
        d = (a[0] - px) ** 2 + (a[1] - py) ** 2 + (a[2] - pz) ** 2
        if best is None or d < best:
            best, bi = d, i
    res = (best, bi * L / n)
    for j in (bi - 1, bi):
        if j < 0 or j >= n:
            continue
        a, b = pts[j], pts[j + 1]
        ab = (b[0] - a[0], b[1] - a[1], b[2] - a[2])
        l2 = ab[0] ** 2 + ab[1] ** 2 + ab[2] ** 2
        if l2 < 1e-18:
            continue
        t = max(0.0, min(1.0, ((px - a[0]) * ab[0] + (py - a[1]) * ab[1] + (pz - a[2]) * ab[2]) / l2))
        d = (a[0] + t * ab[0] - px) ** 2 + (a[1] + t * ab[1] - py) ** 2 + (a[2] + t * ab[2] - pz) ** 2
        if d < res[0]:
            res = (d, (j + t) * L / n)
    return math.sqrt(res[0]), res[1]


def _zones_cales(ch):
    """[(s_debut, s_fin)] : intervalles du chemin occupes par une cale de renfort (abscisses du chemin)."""
    zones = []
    try:
        corps = _corps_cales()
    except Exception:
        _log('cales : lecture erreur %s' % traceback.format_exc()[-300:])
        return zones
    for b in corps:
        try:
            pts = [v.geometry for v in b.vertices]
            proj = [_projeter_table(ch, p) for p in pts]
            ss = [s for d, s in proj if d <= CALE_PORTEE]
            if not ss:
                continue
            a, c = min(ss), max(ss)
            if ch.ferme and c - a > 0.5 * ch.longueur:
                continue            # la cale enjambe l'origine de la boucle : non geree
            zones.append((a, c))
        except Exception:
            _log('cales : zone erreur %s' % traceback.format_exc()[-300:])
    zones.sort()
    fus = []
    for z in zones:
        if fus and z[0] <= fus[-1][1] + 1e-6:
            fus[-1] = (fus[-1][0], max(fus[-1][1], z[1]))
        else:
            fus.append(z)
    return fus


def _plan_cales(L, ferme, s0, s_end, q, zones, hl, jeu):
    """Repartition des q corps quand des cales sont sur le chemin entre s0 et s_end (abscisses du centre
    des corps) : aucun corps a moins de hl + jeu d'une cale ; sur chaque troncon libre, un corps a
    chaque bout (de part et d'autre des cales) et les autres regulierement entre les deux.
    {'abs': [abscisses], 'portions': [{n, u0, u1, s_deb, s_fin}]} ou None s'il n'y a rien a adapter."""
    if q < 2 or not zones:
        return None
    sgn = 1.0 if s_end >= s0 else -1.0
    U = abs(s_end - s0)
    if U < 1e-6:
        return None
    marge = jeu + hl
    interdits = []
    for sa, sb in zones:
        uc = ((sa + sb) / 2.0 - s0) * sgn
        w = (sb - sa) / 2.0 + marge
        cands = [uc]
        if ferme:
            uc %= L
            cands = [uc - L, uc, uc + L]
        for c in cands:
            if c + w > 0 and c - w < U:
                interdits.append((c - w, c + w))
    if not interdits:
        return None
    interdits.sort()
    fus = []
    for z in interdits:
        if fus and z[0] <= fus[-1][1]:
            fus[-1] = (fus[-1][0], max(fus[-1][1], z[1]))
        else:
            fus.append(z)
    segs, cur = [], 0.0
    for ua, ub in fus:
        if ua > cur + 1e-6:
            segs.append((cur, min(ua, U)))
        cur = max(cur, ub)
        if cur >= U:
            break
    if cur < U - 1e-6:
        segs.append((cur, U))
    if not segs or q < 2 * len(segs):
        return None
    tot = sum(b - a for a, b in segs)
    if tot <= 1e-6:
        return None
    pas = tot / (q - len(segs))
    n = [max(2, 1 + int(round((b - a) / pas))) for a, b in segs]
    while sum(n) > q:
        cand = [i for i in range(len(n)) if n[i] > 2]
        if not cand:
            return None
        i = min(cand, key=lambda k: (segs[k][1] - segs[k][0]) / (n[k] - 1))
        n[i] -= 1
    while sum(n) < q:
        i = max(range(len(n)), key=lambda k: (segs[k][1] - segs[k][0]) / (n[k] - 1))
        n[i] += 1
    absc, portions = [], []
    for (a, b), k in zip(segs, n):
        absc += [s0 + sgn * (a + (b - a) * j / (k - 1)) for j in range(k)]
        portions.append({'n': k, 'u0': a, 'u1': b, 's_deb': s0 + sgn * a, 's_fin': s0 + sgn * b})
    return {'abs': absc, 'portions': portions}


def _ctx_calcul(inputs, ents=None, q=None, s0=None, e_vs=None):
    """Tout ce que l'apercu calcule hors Distance : reutilise tant qu'aucun autre
    reglage ne change (la fleche ne modifie que Distance)."""
    objs = _selections(inputs.itemById('objets'))
    solo = ents is None and q is None            # un seul chemin (pas un chemin d'un groupe)
    if ents is None:
        ents = _ents_actifs(inputs)
    ch = _chemin_cache(ents)
    L = ch.longueur
    rep = _dd_key(inputs.itemById('repartition'), REPARTITIONS)
    if q is None:
        q = int(inputs.itemById('quantite').value)
    else:
        rep = 'etendue'      # un chemin parmi plusieurs : etendue jusqu'au bout
    sym = _symetrique(inputs)
    vs = _vsym(inputs)
    orient = _dd_key(inputs.itemById('orientation'), ORIENTATIONS) == 'trajectoire'
    inv = bool(inputs.itemById('inverser').value) and not vs
    if s0 is None:
        s0 = _s0_dialogue(inputs, L)
    if vs and e_vs is not None and _pivot(inputs):
        ds_vs = -e_vs                    # un chemin parmi plusieurs : comme la creation (corps cree a gauche)
    else:
        ds_vs = -_etendue_sym(ch, objs, q) if (vs and solo and _pivot(inputs)) else 0.0
    T0 = _decal_debut(inputs, ch, objs, ds_vs, ents)
    dl = _decalage_pivot(ch, objs, _repere_cle(inputs), inv, T0)
    s0c = s0 - dl
    c = _centre_bbox(objs)
    if c is None:
        return None
    if T0 is not None:
        c = adsk.core.Point3D.create(c.x + T0.x, c.y + T0.y, c.z + T0.z)
    # Fusion garde l'objet rigidement attache au repere du chemin au point le
    # plus proche de son centre : la copie k est ce repere deplace en s_k, donc
    # le decalage centre -> chemin TOURNE avec le chemin (essai du 2026-10-16
    # sur un corps a 6 cm du chemin : 3 a 8 cm d'ecart avec une simple
    # translation).
    s_ref = _s_ref(ch, objs, c)
    p_ref, t_ref = ch.point_tangente(s_ref)
    # Chemin ouvert, depart ancre ailleurs qu'au centre : Fusion decale tout
    # le reseau de P(s_ref) - P(depart) (vecteur fixe, essai du 2026-10-16).
    if ch.ferme or ds_vs:
        decal = (0.0, 0.0, 0.0)
    else:
        pb = ch.point_tangente(s0c)[0]
        decal = (p_ref.x - pb.x, p_ref.y - pb.y, p_ref.z - pb.z)
    zones, hl = None, 0.0
    if _eviter_cales(inputs) and _mode_debut(inputs) and not _sym_dir(inputs) and not _nb_auto(inputs) and \
            ((_masques(inputs) == set()) if solo else not _gmasq.get(_gkey(ents))):
        try:
            zones = _zones_cales(ch) or None
            hl = _demi_epaisseur(objs) if zones else 0.0
        except Exception:
            _log('cales : apercu erreur %s' % traceback.format_exc()[-300:])
    _uid['n'] += 1
    return {
        'zones': [(a + dl, b + dl) for a, b in zones] if zones else None, 'hl': hl, 'jeu': _jeu_cales(inputs),
        'uid': _uid['n'], 'ok': False, 'objs': objs, 'ents': ents, 'ch': ch, 'L': L, 'q': q, 'rep': rep,
        'sym': sym, 'orient': orient, 'inv': inv, 's0': s0, 'T0': T0, 'dl': dl, 's0c': s0c,
        'c': (c.x, c.y, c.z), 's_ref': s_ref, 't0': (t_ref.x, t_ref.y, t_ref.z), 'decal': decal,
        'v0': (c.x - p_ref.x, c.y - p_ref.y, c.z - p_ref.z), 'masques': _masques(inputs),
        'vsym': vs, 'npas': _n_pas(inputs), 'emax': _etendue_sym(ch, objs, q) if vs else 0.0,
        'bords': _bords_apercu(ch, objs, T0) if (T0 is not None and orient) else None,
        'struct': (_cle_objets(objs), None if T0 is None else
                   (round(T0.x, 5), round(T0.y, 5), round(T0.z, 5), tuple(round(v, 4) for v in T0.m.asArray()))),
    }


def _mats_orange(cx, d_in, centres=None, cibles_out=None, exact=False):
    """Une matrice (16 flottants par lignes) par copie a dessiner. Bords sur le chemin (cx['bords']) :
    chaque copie est posee pour que ses deux bords touchent le chemin ; cibles_out recoit alors les
    abscisses (u, v) de ses bords (exact : chemin evalue par l'API, pour la creation)."""
    ch, L, q, rep, sym, inv = cx['ch'], cx['L'], cx['q'], cx['rep'], cx['sym'], cx['inv']
    s0, s0c, dl, T0 = cx['s0'], cx['s0c'], cx['dl'], cx['T0']
    vs = cx['vsym']
    if vs:
        # symetrique virtuel : de centre - E a centre + E, pas = 2 E / (q - 1)
        e = min(d_in if rep == 'etendue' else d_in * max(0.5, (q - 1) / 2.0), cx['emax'])
        s_b = L / 2.0 - e
        pas = 2.0 * e / (q - 1) if q > 1 else 0.0
        abs_ = [s_b + k * pas for k in range(q)]
        s0 = L / 2.0
        s0c = s0 - dl
    else:
        abs_ = _abscisses(q, d_in, s0, L, rep, sym, inv, ch.ferme)
    adapte = False
    if cx.get('zones') and not sym and len(abs_) > 1:
        pl = _plan_cales(L, ch.ferme, s0, abs_[-1], q, cx['zones'], cx['hl'], cx['jeu'])
        if pl and len(pl['abs']) == len(abs_):
            abs_ = pl['abs']
            adapte = True
    # Chemin ouvert : Fusion borne la cible (le centre ne depasse pas le bout),
    # ce qui raccourcit le pas de toutes les copies, comme dans _creer_natif.
    fac = 1.0
    fin = abs_[-1] if abs_ else s0
    if sym and abs_ and not vs:
        e1 = d_in if rep == 'etendue' else d_in * max(0.5, (q - 1) / 2.0)
        fin = s0 - e1 if inv else s0 + e1     # cible donnee a Fusion (un cote)
    if not ch.ferme and len(abs_) > 1 and abs(fin - s0) > 1e-9 and not vs and not adapte:
        cible = max(0.0, min(L, fin - dl))
        fac = (cible - s0c) / (fin - s0)
    cxx, cyy, czz = cx['c']
    v0x, v0y, v0z = cx['v0']
    dx, dy, dz = cx['decal']
    t0 = cx['t0']
    s_ref = cx['s_ref']
    orient = cx['orient']
    masques = cx['masques']
    t_b = ch.fast(s0c + (abs_[0] - s0))[1] if (vs and abs_) else None
    bords = cx.get('bords')
    Pb = _fn_chemin(ch, bords['nn'], bords['off'], exact) if bords is not None else None
    res = []
    for i, si in enumerate(abs_):
        masque_i = (i + 1) in masques
        passe = (i == 0 and T0 is None) or masque_i
        if passe and centres is None:
            continue   # l'original est deja affiche
        if ch.ferme:
            sk = s_ref + (si - s0)   # boucle : Fusion glisse l'objet depuis sa position
        else:
            sk = max(0.0, min(L, s0c + (si - s0) * fac))
        pk, tk = ch.fast(sk)
        r = _rot_vers(t0, tk if (orient or t_b is None) else t_b) if (orient or vs) else None
        if r is None:
            ox, oy, oz = v0x, v0y, v0z
            rcx, rcy, rcz = cxx, cyy, czz
            r = (1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0)
        else:
            ox = r[0] * v0x + r[1] * v0y + r[2] * v0z
            oy = r[3] * v0x + r[4] * v0y + r[5] * v0z
            oz = r[6] * v0x + r[7] * v0y + r[8] * v0z
            rcx = r[0] * cxx + r[1] * cyy + r[2] * czz
            rcy = r[3] * cxx + r[4] * cyy + r[5] * czz
            rcz = r[6] * cxx + r[7] * cyy + r[8] * czz
        if centres is not None and (i > 0 or T0 is not None):
            centres.append((i + 1, (pk[0] + ox + dx, pk[1] + oy + dy, pk[2] + oz + dz), masque_i))
        if passe:
            continue
        # p' = R (p - c) + centre_k  =  R p + (centre_k - R c)
        mk = [r[0], r[1], r[2], pk[0] + ox + dx - rcx,
              r[3], r[4], r[5], pk[1] + oy + dy - rcy,
              r[6], r[7], r[8], pk[2] + oz + dz - rcz,
              0.0, 0.0, 0.0, 1.0]
        if bords is not None:
            # ses deux bords sur le chemin, a la meme place que le fera la creation
            uv = _bords_cible(ch, bords, Pb, sk - s_ref)
            pb = _bords_pose(bords, Pb, uv) if uv is not None else None
            if pb is not None:
                mk = pb
            if cibles_out is not None:
                cibles_out.append(uv)
        res.append(mk)
    return res


# --- Cases « Masquer » sur les corps de l'apercu ------------------------------

_marq = {'g': None, 'cle': None, 'pts': []}
_png_cache = {}


def _png_case(coche):
    """Image PNG d'une case (cochee : copie gardee ; vide : copie masquee)."""
    if coche in _png_cache and os.path.isfile(_png_cache[coche]):
        return _png_cache[coche]
    import zlib, struct, tempfile
    n = 22
    seg = [((5.0, 11.0), (9.0, 16.0)), ((9.0, 16.0), (17.0, 6.0))]

    def dseg(x, y, a, b):
        ax, ay = a
        bx, by = b
        ex, ey = bx - ax, by - ay
        t = max(0.0, min(1.0, ((x - ax) * ex + (y - ay) * ey) / (ex * ex + ey * ey)))
        return math.hypot(ax + t * ex - x, ay + t * ey - y)

    raw = bytearray()
    for y in range(n):
        raw.append(0)
        for x in range(n):
            if x < 2 or y < 2 or x >= n - 2 or y >= n - 2:
                px = (40, 40, 40, 255) if coche else (200, 60, 40, 255)
            elif coche and min(dseg(x, y, a, b) for a, b in seg) < 1.6:
                px = (20, 140, 40, 255)
            else:
                px = (255, 255, 255, 255)
            raw += bytes(px)

    def chunk(t, d):
        c = struct.pack('>I', len(d)) + t + d
        return c + struct.pack('>I', zlib.crc32(t + d) & 0xffffffff)

    png = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', n, n, 8, 6, 0, 0, 0)) + \
        chunk(b'IDAT', zlib.compress(bytes(raw))) + chunk(b'IEND', b'')
    chemin = os.path.join(tempfile.gettempdir(), 'reseau_cnc_case_%d.png' % (1 if coche else 0))
    with open(chemin, 'wb') as f:
        f.write(png)
    _png_cache[coche] = chemin
    return chemin


def _effacer_marqueurs():
    g = _marq['g']
    _marq['g'] = None
    _marq['cle'] = None
    _marq['pts'] = []
    try:
        if g is not None and g.isValid:
            g.deleteMe()
    except Exception:
        pass


_gmasq = {}     # copies masquees par chemin (plusieurs chemins), cle = jetons des entites


def _vue_cam():
    try:
        cam = _app.activeViewport.camera
        return cam, cam.eye, cam.viewDirection
    except Exception:
        return None, None, None


def _devant(c, cam, eye, vd):
    """Point sur la meme ligne de visee que c mais pres de la camera : la case
    se voit a travers les corps (les points sont sinon caches par le volume)."""
    if cam is None:
        return list(c)
    try:
        if cam.cameraType == adsk.core.CameraTypes.OrthographicCameraType:
            k = ((c[0] - eye.x) * vd.x + (c[1] - eye.y) * vd.y + (c[2] - eye.z) * vd.z) * 0.9
            return [c[0] - vd.x * k, c[1] - vd.y * k, c[2] - vd.z * k]
        return [c[0] + (eye.x - c[0]) * 0.9, c[1] + (eye.y - c[1]) * 0.9, c[2] + (eye.z - c[2]) * 0.9]
    except Exception:
        return list(c)


def _hote_cg():
    """(composant actif, matrice monde -> composant ou None) : les graphismes poses dans un autre composant que le
    composant actif sont estompes par Fusion (apercu terne dans un sous-composant, retour de Maxence le 2026-11-11)."""
    des = adsk.fusion.Design.cast(_app.activeProduct)
    occ = des.activeOccurrence
    if occ is None:
        return des.rootComponent, None
    inv = occ.transform2.copy()
    inv.invert()
    return des.activeComponent, inv


def _cg_nouveau():
    return _hote_cg()[0].customGraphicsGroups.add()


def _cg_m(m):
    """Matrice (monde) d'un groupe de graphismes -> celle du composant actif."""
    inv = _hote_cg()[1]
    if inv is None:
        return m
    r = adsk.core.Matrix3D.create()
    r.setWithArray(_mul4(list(inv.asArray()), list(m.asArray())))
    return r


def _cg_pts(pts):
    """Coordonnees a plat (monde) -> composant actif."""
    inv = _hote_cg()[1]
    if inv is None:
        return pts
    out = []
    for i in range(0, len(pts), 3):
        q = adsk.core.Point3D.create(pts[i], pts[i + 1], pts[i + 2])
        q.transformBy(inv)
        out += [q.x, q.y, q.z]
    return out


def _marq_dessiner(cle, pts, rafraichir=True):
    """Dessine les cases : pts = [(cle_chemin, n, centre, masque)]."""
    _effacer_marqueurs()
    if not pts:
        return
    design = adsk.fusion.Design.cast(_app.activeProduct)
    g = _cg_nouveau()
    cam, eye, vd = _vue_cam()
    for coche in (True, False):
        sel = [p[2] for p in pts if p[3] != coche]
        if not sel:
            continue
        coords = _cg_pts([v for c in sel for v in _devant(c, cam, eye, vd)])
        ps = g.addPointSet(adsk.fusion.CustomGraphicsCoordinates.create(coords), list(range(len(sel))),
                           adsk.fusion.CustomGraphicsPointTypes.UserDefinedCustomGraphicsPointType,
                           _png_case(coche))
        ps.isSelectable = False
        try:
            ps.depthPriority = 1
        except Exception:
            pass
    _marq['g'] = g
    _marq['cle'] = cle
    _marq['pts'] = pts
    if rafraichir:
        _rafraichir()


class _CameraHandler(adsk.core.CameraEventHandler):
    """La vue tourne : les cases « Masquer » sont recalees devant la camera
    pour rester visibles a travers les corps."""
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            if _rpast:
                _rp_recaler()          # pastilles toujours devant le modele
            for g in list(_qpast.values()):
                g.recaler()
            if _marq['g'] is None or not _marq['pts']:
                return
            _marq_dessiner(_marq['cle'], list(_marq['pts']), rafraichir=False)
        except Exception:
            pass


def _maj_marqueurs(inputs):
    """Une case au centre de chaque copie de l'apercu (sauf la 1re) quand
    « Masquer » est coche : on clique la case pour masquer / remettre la copie."""
    try:
        if not inputs.itemById('masquer').value or not _ctx.get('ok'):
            if _marq['g'] is not None:
                _effacer_marqueurs()
            return
        cx = _ctx
        d_in = inputs.itemById('distance').value
        cam, eye, vd = _vue_cam()
        vue = (round(eye.x, 2), round(eye.y, 2), round(eye.z, 2), round(vd.x, 3), round(vd.y, 3), round(vd.z, 3)) if eye else None
        cle = (cx['uid'], round(d_in, 6), cx['q'], tuple(sorted(cx['masques'])), vue)
        if cle == _marq['cle'] and _marq['g'] is not None and _marq['g'].isValid:
            return
        centres = []
        _mats_orange(cx, d_in, centres)
        _marq_dessiner(cle, [(None, n, c, mk) for n, c, mk in centres])
    except Exception:
        _log('marqueurs erreur %s' % traceback.format_exc()[-500:])


def _case_touchee(inputs, vp, pos):
    """Numero de la copie dont la case est sous le curseur, sinon None."""
    if not _marq['pts'] or not inputs.itemById('masquer').value:
        return None
    P3 = adsk.core.Point3D.create
    best = None
    rayon = max(16.0, 11.0 * _dpr() + 4.0)      # la case est dessinee 22 px x l'echelle de l'ecran
    for k, n, c, masque in _marq['pts']:
        q = vp.modelToViewSpace(P3(c[0], c[1], c[2]))
        d = math.hypot(q.x - pos.x, q.y - pos.y)
        if d < rayon and (best is None or d < best[0]):
            best = (d, k, n)
    return (best[1], best[2]) if best else None


_bloc = {'t': 0.0, 'sel': None}


def _bloquer_selection(inputs):
    """Appuyer sur une case ne doit rien selectionner derriere : on garde la
    selection d'avant le clic et _traiter la remet."""
    import time
    _bloc['t'] = time.time()
    _bloc['sel'] = {iid: [e.entityToken for e in _selections(inputs.itemById(iid))] for iid in ('objets', 'chemin')}


def _restaurer_selection(inputs, iid):
    """Annule la selection faite par un clic sur une case (dans la seconde)."""
    import time
    if _bloc['sel'] is None or (time.time() - _bloc['t'] > 1.0 and _ov['on'] is None and not _rd['on']):
        return False
    design = adsk.fusion.Design.cast(_app.activeProduct)
    for k in ('objets', 'chemin'):
        sel = inputs.itemById(k)
        voulus = _bloc['sel'].get(k, [])
        if [e.entityToken for e in _selections(sel)] == voulus:
            continue
        sel.clearSelection()
        for tok in voulus:
            try:
                for e in design.findEntityByToken(tok):
                    sel.addSelection(e)
                    break
            except Exception:
                pass
    return True


def _clic_marqueur(inputs, vp, pos, repli=None):
    """Clic dans la vue : si une case est touchee, la copie correspondante est
    masquee / remise. Renvoie True si le clic a servi."""
    touche = _case_touchee(inputs, vp, pos) or repli      # repli : la case visee a l'appui de la souris
    if touche is None:
        return False
    cle_ch, n_case = touche
    if cle_ch is not None:
        # plusieurs chemins : copies masquees propres a chaque chemin
        _gmasq.setdefault(cle_ch, set()).symmetric_difference_update({n_case})
        gs = _multi(inputs)
        if gs:
            _apercu_multi(inputs, gs)
        _rafraichir()
        return True
    cur = _masques(inputs)
    cur.symmetric_difference_update({n_case})
    inputs.itemById('masques').value = ', '.join(str(k) for k in sorted(cur))
    _ctx['ok'] = False
    _orange['cle'] = None
    # redessin immediat : Fusion ne relance l'apercu qu'avec retard (jusqu'au
    # prochain mouvement de la vue)
    _apercu_orange(inputs, rapide=True)
    _maj_marqueurs(inputs)
    _rafraichir()
    return True


def _rafraichir():
    """Redessine la vue : un changement de reglage (repere...) deplacait les
    groupes sans que l'ecran suive (retour du 2026-10-19)."""
    try:
        _app.activeViewport.refresh()
    except Exception:
        pass


def _apercu_orange(inputs, rapide=False, d_force=None):
    """Contours orange des copies. rapide=True (apercu en direct) : reutilise le
    contexte tant que seul Distance change."""
    cx = _ctx if (rapide and _ctx.get('ok')) else None
    recalcule = False
    if cx is None:
        _log('apercu: contexte recalcule')
        cx = _ctx_calcul(inputs)
        recalcule = True
        if cx is None:
            _effacer_orange()
            return
        if rapide:
            _ctx.clear()
            _ctx.update(cx)
            _ctx['ok'] = True
            cx = _ctx
    d_in = inputs.itemById('distance').value if d_force is None else d_force
    # Meme reglages que le dernier dessin : rien a refaire (Fusion relance
    # l'apercu deux fois par mouvement de la fleche).
    cle = (cx['uid'], round(d_in, 6), cx['q'])
    gs = _orange['g']
    if cle == _orange.get('cle') and gs and gs[0].isValid:
        return
    arrs = _mats_orange(cx, d_in)
    pool = _orange.setdefault('pool', [])
    while len(pool) < len(arrs):
        pool.append(adsk.core.Matrix3D.create())
    for m, a in zip(pool, arrs):
        m.setWithArray(a)
    mats = pool[:len(arrs)]
    _orange['mats'] = mats
    struct = cx['struct']
    # Meme structure que le dessin precedent : on ne fait que deplacer les
    # groupes (une matrice par copie), sans recreer la geometrie : fluide. Le
    # nombre de copies change (poignee de quantite) : les groupes en trop sont
    # caches, les manquants crees seuls.
    if gs and _orange.get('struct') == struct and _orange.get('geo') and gs[0].isValid:
        try:
            n = len(mats)
            design = adsk.fusion.Design.cast(_app.activeProduct)
            if len(gs) < n:
                coords, idx = _orange['geo']
                couleur = adsk.fusion.CustomGraphicsSolidColorEffect.create(adsk.core.Color.create(255, 140, 0, 255))
                for m in mats[len(gs):]:
                    g = _cg_nouveau()
                    seg = g.addLines(adsk.fusion.CustomGraphicsCoordinates.create(coords), idx, False)
                    seg.weight = 2
                    seg.color = couleur
                    seg.isSelectable = False
                    g.transform = _cg_m(m)
                    gs.append(g)
            nv = _orange.get('nvis', len(gs))
            for k in range(n):
                gs[k].transform = _cg_m(mats[k])
            for k in range(nv, n):
                gs[k].isVisible = True
            for k in range(n, nv):
                gs[k].isVisible = False
            _orange['nvis'] = n
            _orange['cle'] = cle
            if recalcule:
                _rafraichir()
            return
        except Exception:
            _log('apercu maj sur place erreur %s' % traceback.format_exc()[-300:])
    objs, T0 = cx['objs'], cx['T0']
    _effacer_orange()
    _orange['mats'] = mats
    lignes = _polylignes_objets(objs)
    if not lignes or not mats:
        return
    coords, idx = [], []
    for pts in lignes:
        base = len(coords) // 3
        for pt in pts:
            q = pt if T0 is None else _appliquer(T0, pt)
            coords += [q.x, q.y, q.z]
        for j in range(len(pts) - 1):
            idx += [base + j, base + j + 1]
    design = adsk.fusion.Design.cast(_app.activeProduct)
    couleur = adsk.fusion.CustomGraphicsSolidColorEffect.create(adsk.core.Color.create(255, 140, 0, 255))
    nouveaux = []
    for m in mats:
        g = _cg_nouveau()
        seg = g.addLines(adsk.fusion.CustomGraphicsCoordinates.create(coords), idx, False)
        seg.weight = 2
        seg.color = couleur
        seg.isSelectable = False
        g.transform = _cg_m(m)
        nouveaux.append(g)
    _orange['g'] = nouveaux
    _orange['struct'] = struct
    _orange['geo'] = (coords, idx)
    _orange['nvis'] = len(nouveaux)
    _orange['cle'] = cle
    if recalcule:
        _rafraichir()


def _nb_auto(inputs):
    try:
        return bool(inputs.itemById('nb_auto').value) and _mode_debut(inputs)
    except Exception:
        return False


_s0_cache = {}


def _s0_groupe(inputs, corps, ents):
    """(chemin, abscisse de depart) prevus pour la copie du 1er corps sur ce chemin.
    Garde en memoire : tirer une fleche ne change ni le chemin ni le depart."""
    inv = bool(inputs.itemById('inverser').value)
    sig = (tuple(b.entityToken for b in corps), _gkey(ents), inv,
           round(inputs.itemById('decal_lat').value, 6), round(inputs.itemById('decal_haut').value, 6), _pivot(inputs),
           _haut(inputs), _sym_dir(inputs))
    r = _s0_cache.get(sig)
    if r is not None:
        return r
    if len(_s0_cache) > 30:
        _s0_cache.clear()
    ch = _chemin_cache(ents)
    T0 = _decal_debut(inputs, ch, corps, 0.0, ents)
    c0 = _centre_bbox(corps)
    c1 = adsk.core.Point3D.create(c0.x + T0.x, c0.y + T0.y, c0.z + T0.z)
    s0 = max(0.0, min(ch.longueur, ch.abscisse_proche(c1) + _decalage_pivot(
        ch, corps, _repere_cle(inputs), inv, T0)))
    _s0_cache[sig] = (ch, s0)
    return ch, s0


_gfin = {}      # fin choisie a la fleche, par chemin (cle = jetons des entites)
_sel_ver = {'v': 0}      # +1 a chaque reglage modifie dans la boite (hors fleches)
_gstat = {'ver': None, 'items': None, 'corps': [], 'tok': ()}

# Reglages propres a chaque chemin (cle = jetons des entites) : la boite montre ceux du
# chemin « selectionne » (barre bleue), les autres gardent les leurs.
PAR_CHEMIN = ('direction', 'orientation', 'inverser', 'pivot', 'tenon_haut', 'cote_inv', 'decal_lat', 'decal_haut')
_greg = {}
_chemin_sel = {'key': None, 'vus': set()}
_oeil = set()        # chemins dont les cases « Masquer » sont affichees (plusieurs chemins)
_LISTES = {'direction': DIRECTIONS, 'orientation': ORIENTATIONS, 'repartition': REPARTITIONS}


class _Val:
    def __init__(self, v):
        self.value = v


class _Elt:
    def __init__(self, i, nom):
        self.index = i
        self.name = nom


class _Liste:
    def __init__(self, items, cle):
        self.selectedItem = _Elt(0, items[0][1])
        for i, (k, txt) in enumerate(items):
            if k == cle:
                self.selectedItem = _Elt(i, txt)
                break


class _Vue:
    """La boite telle qu'un seul chemin la voit : ses propres reglages (reg) a la place de ceux
    de la boite, tout le reste (selections, masques...) vient de la vraie boite."""
    def __init__(self, inputs, reg):
        self._i = inputs
        self._r = reg

    def itemById(self, iid):
        if iid in self._r:
            v = self._r[iid]
            return _Liste(_LISTES[iid], v) if iid in _LISTES else _Val(v)
        return self._i.itemById(iid)

    def __getattr__(self, nom):
        return getattr(self.__dict__['_i'], nom)


def _lire_boite(inputs):
    return {'direction': _dd_key(inputs.itemById('direction'), DIRECTIONS),
            'orientation': _dd_key(inputs.itemById('orientation'), ORIENTATIONS),
            'inverser': bool(inputs.itemById('inverser').value),
            'pivot': bool(inputs.itemById('pivot').value),
            'tenon_haut': bool(inputs.itemById('tenon_haut').value),
            'cote_inv': bool(inputs.itemById('cote_inv').value),
            'decal_lat': inputs.itemById('decal_lat').value,
            'decal_haut': inputs.itemById('decal_haut').value}


def _reg_chemin(inputs, key):
    r = _greg.get(key)
    if r is None:
        r = _greg[key] = _lire_boite(inputs)
    return r


def _vue_chemin(inputs, key, q=3, auto=False, dist=1e6):
    reg = dict(_reg_chemin(inputs, key))
    if auto:
        reg['direction'] = 'une'       # pas de symetrie avec un nombre automatique
    reg.update(repartition='etendue', quantite=q, distance=dist)
    return _Vue(inputs, reg)


def _charger_boite(inputs, reg):
    _choisir(inputs.itemById('direction'), DIRECTIONS, reg['direction'])
    _choisir(inputs.itemById('orientation'), ORIENTATIONS, reg['orientation'])
    inputs.itemById('inverser').value = reg['inverser']
    inputs.itemById('pivot').value = reg['pivot']
    inputs.itemById('tenon_haut').value = bool(reg.get('tenon_haut', False))
    inputs.itemById('cote_inv').value = bool(reg.get('cote_inv', False))
    for iid in ('decal_lat', 'decal_haut'):
        inputs.itemById(iid).value = reg[iid]


def _choisir_chemin(inputs, key):
    """Le chemin `key` devient le chemin selectionne : la boite montre ses reglages."""
    if key == _chemin_sel['key'] or key not in _greg:
        return False
    _chemin_sel['key'] = key
    avant = _en_cours['v']
    _en_cours['v'] = True
    try:
        _charger_boite(inputs, _greg[key])
        gs = _multi(inputs)
        if gs:
            for g in gs:
                if g['key'] == key:
                    inputs.itemById('quantite').value = max(1, g['q'])
        _update_visibility(inputs)
    finally:
        _en_cours['v'] = avant
    _ctx['ok'] = False
    return True


def _synchro_selection(inputs):
    """Garde un chemin selectionne valide ; un chemin qu'on vient d'ajouter le devient."""
    try:
        _groupes_calc(inputs)
        items = _gstat['items']
        if not items:
            return
        cles = [it[1] for it in items]
        vus = _chemin_sel['vus']
        nouveaux = [k for k in cles if k not in vus]
        cur = _chemin_sel['key']
        if vus and nouveaux:
            cible = nouveaux[-1]
        elif cur in cles:
            cible = cur
        else:
            cible = cles[0]
        _chemin_sel['vus'] = set(cles)
        if _chemin_sel['key'] is None:
            _chemin_sel['key'] = cible
            return
        _choisir_chemin(inputs, cible)
        _chemin_sel['key'] = cible
    except Exception:
        _log('synchro selection erreur %s' % traceback.format_exc()[-300:])


def _maj_reg(inputs):
    """Un reglage propre au chemin vient de changer dans la boite : on le range pour le chemin choisi."""
    k = _chemin_sel['key']
    if k is not None and k in _greg:
        _greg[k] = _lire_boite(inputs)
    else:
        _groupes_calc(inputs)
        if _gstat['items']:
            _chemin_sel['key'] = _gstat['items'][0][1]
    _sel_ver['v'] += 1


def _idx_selection(gs):
    for i, g in enumerate(gs or ()):
        if g['key'] == _chemin_sel['key']:
            return i
    return 0


def _gkey(ents):
    return tuple(sorted(e.entityToken for e in ents))


def _regle_qte(texte, long_mm):
    """Nombre de corps pour un chemin de long_mm millimetres d'apres la regle « 290:3, 500:4, +200 »
    (jusqu'a 290 mm : 3 corps ; ... ; au-dela du dernier seuil : +1 corps tous les 200 mm). None si
    la regle est illisible."""
    seuils, plus = [], None
    try:
        for tok in str(texte).replace(';', ',').split(','):
            tok = tok.strip().lower().replace('mm', '').replace(' ', '')
            if not tok:
                continue
            if tok.startswith('+'):
                plus = float(tok[1:].replace(',', '.'))
            elif ':' in tok:
                a, _, b = tok.partition(':')
                seuils.append((float(a.replace(',', '.')), int(b)))
    except ValueError:
        return None
    if not seuils:
        return None
    seuils.sort()
    for lim, q in seuils:
        if long_mm <= lim + 0.5:
            return max(1, q)
    lim, q = seuils[-1]
    if plus and plus > 0:
        q += int((long_mm - lim) / plus + 1e-6)
    return max(1, min(10000, q))


def _q_regle(inputs, long_cm):
    """Quantite voulue par la regle pour ce chemin (longueur en cm), None si la regle est coupee."""
    try:
        if not inputs.itemById('qte_regle').value or _nb_auto(inputs):
            return None
        return _regle_qte(inputs.itemById('regle_qte').value, long_cm * 10.0)
    except Exception:
        return None


def _regle_sur_chemins(inputs, forcer=False):
    """Applique la regle aux chemins choisis : un seul chemin = champ Quantite ; plusieurs = une quantite
    par chemin (forcer : meme ceux deja regles)."""
    try:
        ents = _selections(inputs.itemById('chemin'))
        if not ents:
            return
        multi = _mode_debut(inputs)
        groupes = _groupes_chemin(ents) if multi else [ents]
        qs = []
        for g in groupes:
            q = _q_regle(inputs, _chemin_cache(g).longueur)
            if q is None:
                return
            qs.append(q)
            if multi and len(groupes) > 1:
                if forcer:
                    _gq[_gkey(g)] = q
                else:
                    _gq.setdefault(_gkey(g), q)
        if inputs.itemById('quantite').value != qs[0]:
            inputs.itemById('quantite').value = qs[0]
        _ctx['ok'] = False
    except Exception:
        _log('regle quantite erreur %s' % traceback.format_exc()[-300:])


def _groupes_calc(inputs):
    """[{ents, q, s0, s_fin, key, ch}] par chemin quand le mode « Copier le
    corps » a plusieurs chemins ou un nombre automatique, sinon None. s_fin :
    abscisse de la derniere copie (bout du chemin, ou fleche tiree)."""
    _pivot(inputs)
    if not _mode_debut(inputs):
        return None
    # la selection, les jetons et les abscisses de depart ne changent qu'avec un
    # reglage de la boite (_sel_ver) : tirer une fleche n'y touche pas (lire les
    # jetons de 100 aretes a chaque mouvement coutait ~30 ms)
    st = _gstat
    if st['ver'] != _sel_ver['v']:
        ents = _selections(inputs.itemById('chemin'))
        corps = [o for o in _selections(inputs.itemById('objets')) if isinstance(o, adsk.fusion.BRepBody)]
        items = None
        if ents and corps:
            items = []
            for g in _groupes_chemin(ents):
                cle = _gkey(g)
                ch, s0 = _s0_groupe(_vue_chemin(inputs, cle), corps, g)
                items.append((g, cle, ch, s0))
        st.update(ver=_sel_ver['v'], items=items, corps=corps,
                  tok=tuple(b.entityToken for b in corps))
    items = st['items']
    auto = _nb_auto(inputs)
    if not items or (len(items) <= 1 and not auto):
        return None
    res = []
    for g, key, ch, s0 in items:
        reg = _reg_chemin(inputs, key)
        inv = bool(reg['inverser'])
        sym = (reg['direction'] == 'symetrique') and not auto
        L = ch.longueur
        fin = _gfin.get(key)
        if fin is not None and not ch.ferme:
            fin = max(0.0, min(s0, fin)) if inv else max(s0, min(L, fin))
        else:
            fin = None
        if auto:
            pas = max(inputs.itemById('pas_auto').value, 1e-6)
            if ch.ferme:
                q = max(1, int(L / pas + 1e-6))
                fin = _bout(ch, s0, inv, q)
            else:
                if fin is None:
                    fin = _bout(ch, s0, inv, 2)
                q = min(10000, int(abs(fin - s0) / pas + 1e-6) + 1)
        else:
            q = _gq.get(key)
            if q is None:
                # 1er chemin : la quantite deja reglee ; chaque nouveau chemin demarre a 3 corps
                if not _gq and len(res) == 0:
                    q = int(inputs.itemById('quantite').value)
                else:
                    q = _q_regle(inputs, L) or 3
                _gq[key] = q
            if fin is None:
                fin = _bout(ch, s0, inv, q)
        if sym:
            # symetrique : de part et d'autre du centre, jusqu'aux deux bouts du chemin
            # (la fleche regle l'etendue d'un cote, au plus jusqu'au bout du chemin)
            e = _etendue_sym(ch, st['corps'], q)
            if fin is not None:
                e = min(e, abs(fin - s0))
            fin = s0 - e if inv else s0 + e
        res.append({'ents': g, 'q': q, 's0': s0, 's_fin': fin, 'key': key, 'ch': ch, 'inv': inv, 'sym': sym,
                    'e': abs(fin - s0) if sym else None,
                    'vue': _vue_chemin(inputs, key, q, auto, abs(fin - s0) if sym else 1e6)})
    return res


def _multi(inputs):
    gs = _groupes_calc(inputs)
    return gs if gs and len(gs) > 1 else None


_gref = {}
_gdrag = {'i': None}


NB_FLECHES = 8


def _poignee_input(inputs, i):
    return inputs.itemById('poignee' if i == 0 else 'poignee_%d' % i)


def _cacher_poignees(inputs, depuis):
    i = depuis
    while True:
        p = inputs.itemById('poignee_%d' % i)
        if p is None:
            break
        p.isVisible = False
        i += 1


def _placer_fleches_multi(inputs, gs):
    """Une fleche par chemin, sur la derniere copie de ce chemin."""
    _gref.clear()
    for i, g in enumerate(gs):
        ch = g['ch']
        inv = g['inv']
        pe, tg = ch.point_tangente(g['s_fin'])
        v = adsk.core.Vector3D.create(tg.x, tg.y, tg.z)
        if inv:
            v.scaleBy(-1)
        v.normalize()
        ph = _poignee_input(inputs, i)
        if ph is None:
            continue
        ph.isVisible = not _oeil          # en mode « Masquer » les fleches se cachent : un clic ne les deplace plus
        ph.setManipulator(pe, v)
        ph.value = 0.0
        if _caf is not None:
            ph.isVisible = False
            if _oeil:
                _rp_effacer()
            else:
                _rp_placer(i, pe)
        _gref[i] = {'s0': g['s0'], 'pe': pe, 'dir': v, 's_cur': g['s_fin'], 'key': g['key'], 'ch': ch, 'inv': inv,
                    'sym': g['sym'], 'emax': _etendue_sym(ch, _gstat['corps'], g['q']) if g['sym'] else None}
    _cacher_poignees(inputs, len(gs))
    _rp_cacher_depuis(len(gs))


def _poignee_multi(inputs, iid):
    """Une fleche de chemin est tiree : la derniere copie de ce chemin suit la souris."""
    try:
        i = 0 if iid == 'poignee' else int(iid.split('_')[1])
        ref = _gref.get(i)
        if ref is None:
            return
        ph = inputs.itemById(iid)
        val = ph.value
        import time
        m = _souris['pos'] if time.perf_counter() - _souris['t'] <= 0.5 else None
        cle = (round(m.x, 1), round(m.y, 1)) if m is not None else round(val, 6)
        if cle == ref.get('cle'):
            return
        ref['cle'] = cle
        ch, s0 = ref['ch'], ref['s0']
        inv = ref['inv']
        L = ch.longueur
        if ch.ferme:
            lo, hi = (s0 - L, s0) if inv else (s0, s0 + L)
        else:
            lo, hi = (0.0, s0) if inv else (s0, L)
        if ref.get('sym'):
            # symetrique : la fleche regle l'etendue d'un cote, bornee aux deux bouts du chemin
            if inv:
                lo = max(lo, s0 - ref['emax'])
            else:
                hi = min(hi, s0 + ref['emax'])
        s_fin = None
        try:
            s_fin = _abscisse_souris(ch, lo, hi, ref['s_cur'])
        except Exception:
            _log('souris erreur %s' % traceback.format_exc()[-400:])
        if s_fin is None:
            pe, v = ref['pe'], ref['dir']
            q = adsk.core.Point3D.create(pe.x + v.x * val, pe.y + v.y * val, pe.z + v.z * val)
            w = abs(val - ref.get('val', 0.0)) * 2.0 + 0.5
            s_fin = ch.abscisse_proche(q, max(lo, ref['s_cur'] - w), min(hi, ref['s_cur'] + w), n=40)
        else:
            pn, tn = ch.point_tangente(s_fin)
            vn = adsk.core.Vector3D.create(tn.x, tn.y, tn.z)
            if inv:
                vn.scaleBy(-1)
            vn.normalize()
            ref.update({'pe': pn, 'dir': vn, 'val': 0.0})
            ph.setManipulator(pn, vn)
            ph.value = 0.0
        ref['s_cur'] = s_fin
        _gfin[ref['key']] = s_fin
        _gdrag['i'] = i
    except Exception:
        _log('poignee_multi erreur %s' % traceback.format_exc()[-600:])


_mgfx = {}      # graphiques orange par chemin : {cle: {'grp', 'arrs', 'struct'}}
_mbase = {}     # contexte de calcul (hors quantite / masques) par chemin
_mcoords = {}


def _mg_effacer(ent):
    for g in ent.get('grp', []):
        try:
            if g is not None and g.isValid:
                g.deleteMe()
        except Exception:
            pass


def _apercu_multi(inputs, gs):
    """Contours orange de tous les chemins. Tirer une fleche ne fait que deplacer
    les groupes deja dessinés (une matrice par copie) ; un chemin n'est redessine
    que si son nombre de copies change."""
    corps, tok_corps = _gstat['corps'], _gstat['tok']
    _ctx['ok'] = False
    design = adsk.fusion.Design.cast(_app.activeProduct)
    c_sel = adsk.fusion.CustomGraphicsSolidColorEffect.create(adsk.core.Color.create(255, 105, 0, 255))
    c_aut = adsk.fusion.CustomGraphicsSolidColorEffect.create(adsk.core.Color.create(255, 165, 45, 255))
    cle_sel = _chemin_sel['key'] if len(gs) > 1 else gs[0]['key']
    actifs = set(_oeil)
    masquer = bool(actifs)
    glisse = _gdrag['i'] is not None
    cases = []
    vus = set()
    for g in gs:
        key = g['key']
        vus.add(key)
        reste = abs(g['s_fin'] - g['s0'])
        vue = g['vue']
        sig = (key, tok_corps, g['inv'], round(vue.itemById('decal_lat').value, 6),
               round(vue.itemById('decal_haut').value, 6), vue.itemById('orientation').selectedItem.index,
               round(g['s0'], 6), _pivot(vue), _haut(vue), g['sym'], _eviter_cales(vue), round(_jeu_cales(vue), 6))
        e_g = None
        if g['sym']:
            e_g = max(0.0, min(float(g['e']), _etendue_sym(g['ch'], _gstat['corps'], max(2, g['q']))))
        sig = sig + (bool(_cote_inv['v']), None if e_g is None else round(e_g, 5))
        base = _mbase.get(sig)
        if base is None:
            if len(_mbase) > 30:
                _mbase.clear()
            base = _ctx_calcul(vue, ents=g['ents'], q=g['q'], s0=g['s0'], e_vs=e_g)
            if base is None:
                continue
            _mbase[sig] = base
        cx = dict(base)
        cx['q'] = g['q']
        if cx['vsym']:
            cx['emax'] = _etendue_sym(cx['ch'], cx['objs'], g['q'])
        cx['masques'] = set(_gmasq.get(key, ()))
        cs = [] if (key in actifs and not glisse) else None
        arrs = _mats_orange(cx, reste, cs)
        if cs is not None:
            cases += [(key, n, c, mk) for n, c, mk in cs]
        est_sel = (key == cle_sel)
        couleur, epais = (c_sel, 2) if est_sel else (c_aut, 1)        # traits affines (2026-11-04)
        ent = _mgfx.get(key)
        if ent and ent['struct'] == cx['struct'] and len(ent['grp']) == len(arrs) \
                and (not arrs or ent['grp'][0].isValid):
            if ent.get('sel') != est_sel:
                for sg in ent.get('segs', []):
                    sg.color = couleur
                    sg.weight = epais
                ent['sel'] = est_sel
            if ent['arrs'] != arrs:
                for gr, a in zip(ent['grp'], arrs):
                    m = adsk.core.Matrix3D.create()
                    m.setWithArray(a)
                    gr.transform = _cg_m(m)
                ent['arrs'] = arrs
            continue
        if ent:
            _mg_effacer(ent)
        ck = (key, cx['struct'])
        cc = _mcoords.get(ck)
        if cc is None:
            coords, idx = [], []
            for pts in _polylignes_objets(cx['objs']):
                b0 = len(coords) // 3
                for pt in pts:
                    p = _appliquer(cx['T0'], pt)
                    coords += [p.x, p.y, p.z]
                for j in range(len(pts) - 1):
                    idx += [b0 + j, b0 + j + 1]
            if len(_mcoords) > 20:
                _mcoords.clear()
            cc = _mcoords[ck] = (coords, idx)
        coords, idx = cc
        grp = []
        segs = []
        for a in arrs:
            m = adsk.core.Matrix3D.create()
            m.setWithArray(a)
            gr = _cg_nouveau()
            seg = gr.addLines(adsk.fusion.CustomGraphicsCoordinates.create(coords), idx, False)
            seg.weight = epais
            seg.color = couleur
            seg.isSelectable = False
            gr.transform = _cg_m(m)
            grp.append(gr)
            segs.append(seg)
        _mgfx[key] = {'grp': grp, 'arrs': arrs, 'struct': cx['struct'], 'segs': segs, 'sel': est_sel}
    for key in [k for k in _mgfx if k not in vus]:
        _mg_effacer(_mgfx.pop(key))
    # le dessin simple repart de zero quand on revient a un seul chemin
    _orange['g'] = [gr for e in _mgfx.values() for gr in e['grp']]
    _orange['struct'] = 'multi'
    _orange['cle'] = None
    if not masquer or glisse:
        if _marq['g'] is not None:
            _effacer_marqueurs()
    else:
        cle = tuple((p[0], p[1], p[3], round(p[2][0], 2), round(p[2][1], 2), round(p[2][2], 2)) for p in cases)
        if cle != _marq.get('cle') or _marq['g'] is None or not _marq['g'].isValid:
            _marq_dessiner(cle, cases)
    if not glisse:
        _rafraichir()


_copie_info = {'move': None, 'sources': []}


_jonc = {'on': True}          # « Ignorer les jonctions CNC » (etat de la case, lu par _chemin_cache)
JONC_TOL = 0.5                 # cm : trou maximal franchi entre deux pieces coupees par une jonction


def _ignorer_jonction(inputs):
    try:
        return bool(inputs.itemById('ignorer_jonction').value)
    except Exception:
        return False


def _jonc_bouts(e):
    """[(point, tangente sortante unitaire, sommet)] aux deux bouts d'une arete (espace du document)."""
    ev = e.evaluator
    ok, p0, p1 = ev.getParameterExtents()
    res = []
    for t, sgn, v in ((p0, -1.0, e.startVertex), (p1, 1.0, e.endVertex)):
        ok, pt = ev.getPointAtParameter(t)
        ok, tg = ev.getTangent(t)
        tg.normalize()
        tg.scaleBy(sgn)
        res.append((pt, tg, v))
    return res


def _jonc_chaine(e, vus):
    """Arete e et ses voisines raccordees par un sommet en continuite de tangente."""
    res, pile = [e], [e]
    vus.add(e.entityToken)
    while pile:
        cur = pile.pop()
        for pt, tg, v in _jonc_bouts(cur):
            try:
                voisines = list(v.edges)
            except Exception:
                continue
            for n in voisines:
                if n.entityToken in vus:
                    continue
                for q, u, _v in _jonc_bouts(n):
                    if q.distanceTo(pt) < 1e-4 and tg.dotProduct(u) < -math.cos(math.radians(5.0)):
                        vus.add(n.entityToken)
                        res.append(n)
                        pile.append(n)
                        break
    return res


def _jonc_etendre(edges):
    """(aretes, [(P, Q)]) : les aretes choisies, prolongees de l'autre cote des traits de jonction
    (aretes alignees dont le bout est a moins de JONC_TOL du bout libre du chemin). Les (P, Q) sont
    les trous a raccorder."""
    design = adsk.fusion.Design.cast(_app.activeProduct)
    root = design.rootComponent
    S = list(edges)
    vus = {e.entityToken for e in S}
    ponts = []
    libres = []

    def bouts_libres(es, ignore=()):
        res = []
        tous = [(e, _jonc_bouts(e)) for e in S]
        for e in es:
            for pt, tg, v in _jonc_bouts(e):
                if any(pt.distanceTo(q) < 1e-4 for q in ignore):
                    continue
                relie = False
                for o, bb in tous:
                    if o.entityToken == e.entityToken:
                        continue
                    if any(pt.distanceTo(q) < 1e-4 for q, _u, _v in bb):
                        relie = True
                        break
                if not relie:
                    res.append((pt, tg))
        return res

    libres = bouts_libres(S)
    pas = 0
    while libres and pas < 40:
        pas += 1
        P, T = libres.pop()
        meilleur = None
        try:
            cands = root.findBRepUsingPoint(P, adsk.fusion.BRepEntityTypes.BRepEdgeEntityType, JONC_TOL, False)
        except Exception:
            cands = None
        for c in (cands or []):
            e = adsk.fusion.BRepEdge.cast(c)
            if e is None or e.entityToken in vus:
                continue
            for Q, U, _v in _jonc_bouts(e):
                d = Q.distanceTo(P)
                if d < 1e-4 or d > JONC_TOL:
                    continue
                w = P.vectorTo(Q)
                w.normalize()
                if w.dotProduct(T) < math.cos(math.radians(40.0)):
                    continue
                if T.dotProduct(U) > -math.cos(math.radians(25.0)):
                    continue
                if meilleur is None or d < meilleur[0]:
                    meilleur = (d, e, Q)
        if meilleur is None:
            continue
        _d, e, Q = meilleur
        nouvelles = _jonc_chaine(e, vus)
        S.extend(nouvelles)
        ponts.append((P, Q))
        libres.extend(bouts_libres(nouvelles, ignore=[Q]))
    # deux bouts libres proches et alignes (les deux cotes d'une jonction deja choisis) : raccord
    reste = bouts_libres(S)
    utilises = set()
    for i in range(len(reste)):
        for j in range(i + 1, len(reste)):
            if i in utilises or j in utilises:
                continue
            P, T = reste[i]
            Q, U = reste[j]
            d = P.distanceTo(Q)
            if d < 1e-4 or d > JONC_TOL:
                continue
            if any(P.distanceTo(a) < 1e-4 or P.distanceTo(b) < 1e-4 for a, b in ponts):
                continue                       # deja raccorde plus haut
            w = P.vectorTo(Q)
            w.normalize()
            if w.dotProduct(T) < math.cos(math.radians(40.0)) or T.dotProduct(U) > -math.cos(math.radians(25.0)):
                continue
            ponts.append((P, Q))
            utilises.update((i, j))
    return S, ponts


def _jonc_completer_selection(inputs):
    """Option « Ignorer les jonctions CNC » : ajoute a la selection du chemin les aretes situees de l'autre
    cote d'une jonction, pour que tout le chemin soit selectionne et visible."""
    try:
        if not _ignorer_jonction(inputs):
            return
        sel = inputs.itemById('chemin')
        edges = []
        for i in range(sel.selectionCount):
            e = adsk.fusion.BRepEdge.cast(sel.selection(i).entity)
            if e is None:
                return
            edges.append(e)
        if not edges:
            return
        S, _ponts = _jonc_etendre(edges)
        deja = {e.entityToken for e in edges}
        ajout = [e for e in S if e.entityToken not in deja]
        for e in ajout:
            sel.addSelection(e)
        if ajout:
            _log('jonction : %d arete(s) ajoutee(s) a la selection' % len(ajout))
            cur = {}
            for i in range(sel.selectionCount):
                e = sel.selection(i).entity
                cur[e.entityToken] = e
            _clics['ents'] = cur
    except Exception:
        _log('completer selection erreur %s' % traceback.format_exc()[-400:])


def _jonc_sens_naturel(liste, e0):
    """liste (aretes ou courbes d'esquisse) dans l'ordre qui fait parcourir e0 dans son sens naturel
    (debut -> fin de l'arete), comme avant la coupe."""
    if len(liste) < 2:
        return liste
    try:
        b = _jonc_bouts(e0)
        ch = _Chemin(liste)
        if ch.abscisse_proche(b[0][0]) > ch.abscisse_proche(b[1][0]):
            return list(liste)[::-1]
    except Exception:
        _log('sens naturel erreur %s' % traceback.format_exc()[-300:])
    return liste


def _chemin_sans_jonction_geo(ents):
    """_Chemin du chemin entier (geometrie seule, sans Path de Fusion), ou None s'il n'y a rien a raccorder."""
    edges = [adsk.fusion.BRepEdge.cast(e) for e in ents]
    if not edges or any(e is None for e in edges):
        return None
    S, ponts = _jonc_etendre(edges)
    if not ponts:
        return None
    # les trous des jonctions sont combles par un petit segment : sans lui, le chainage coupait le chemin en
    # deux morceaux parcourus en sens inverse (copies a l'envers d'un cote de la jonction)
    ponts_l = []
    for P, Q in ponts:
        try:
            ponts_l.append(adsk.core.Line3D.create(P, Q))
        except Exception:
            pass
    return _Chemin(_jonc_sens_naturel(list(S) + ponts_l, edges[0]))


def _jonc_echantillons(e, n=6):
    ev = e.evaluator
    ok, p0, p1 = ev.getParameterExtents()
    res = []
    for k in range(n + 1):
        t = p0 + (p1 - p0) * k / float(n)
        t = min(max(t, min(p0, p1)), max(p0, p1))
        ok, pt = ev.getPointAtParameter(t)
        if not ok:
            ok, pt = ev.getPointAtParameter(p0 + (p1 - p0) * (0.5 if k not in (0, n) else (0.0 if k == 0 else 1.0)))
        if ok:
            res.append(pt)
    return res


def _chemin_sans_jonction(design, comp, ents):
    """Esquisse « chemin » qui reprend (lien associatif) les aretes choisies, prolongees de l'autre cote
    des jonctions CNC et raccordees par un petit segment. Le reseau suit cette esquisse : une jonction creee
    plus tard (apres elle dans la chronologie) ne coupe plus son chemin. Renvoie ents inchange si rien a faire."""
    edges = [adsk.fusion.BRepEdge.cast(e) for e in ents]
    if not edges or any(e is None for e in edges):
        return ents
    S, ponts = _jonc_etendre(edges)
    face = None
    pts = [pt for e in S for pt in _jonc_echantillons(e)]
    for f in edges[0].faces:
        pl = adsk.core.Plane.cast(f.geometry)
        if pl is None:
            continue
        if all(abs(pl.normal.dotProduct(pl.origin.vectorTo(pt))) < 1e-3 for pt in pts):
            face = f
            break
    if face is None:
        _log('chemin sans jonction : chemin non plan, inchange')
        return ents
    sk = comp.sketches.addWithoutEdges(face)       # sans les aretes de la face
    sk.name = 'Chemin du reseau'
    sk.isComputeDeferred = True
    for e in S:
        sk.include(e)
    sk.isComputeDeferred = False
    if ponts:
        pts_sk = []
        for c in sk.sketchCurves:
            for nom in ('startSketchPoint', 'endSketchPoint'):
                sp = getattr(c, nom, None)
                if sp is not None:
                    pts_sk.append(sp)

        def proche(pt):
            best = min(pts_sk, key=lambda sp: sp.worldGeometry.distanceTo(pt))
            return best if best.worldGeometry.distanceTo(pt) < 1e-3 else None
        for P, Q in ponts:
            a, b = proche(P), proche(Q)
            if a is not None and b is not None:
                sk.sketchCurves.sketchLines.addByTwoPoints(a, b)
    sk.isLightBulbOn = False
    res = _jonc_sens_naturel([c for c in sk.sketchCurves], edges[0])
    _log('chemin sans jonction : %d arete(s) -> %d courbe(s), %d raccord(s)' % (len(edges), len(res), len(ponts)))
    return res if res else ents


def _creer_copie_debut(inputs, comp, objets, chemin, ents=None, saut=0.0, e_vs=None):
    """Mode 'creer le 1er corps au debut du chemin' : copie des corps choisis
    (copier-coller de corps), deplacee au debut du chemin sans tourner. Ce sont
    ces copies que le reseau duplique."""
    if _dd_key(inputs.itemById('type_objet'), TYPES_OBJET) != 'corps':
        raise ValueError("Creer le 1er corps au debut du chemin ne marche qu'avec des corps.")
    corps = [o for o in objets if isinstance(o, adsk.fusion.BRepBody)]
    if not corps:
        raise ValueError('Choisissez au moins un corps.')
    ds = -(e_vs if e_vs is not None else _e_vsym(inputs, chemin, corps)) if _vsym(inputs) else 0.0
    T0 = _decal_debut(inputs, chemin, corps, ds, ents, saut)
    src = adsk.core.ObjectCollection.create()
    for b in corps:
        src.add(b)
    cp = comp.features.copyPasteBodies.add(src)
    nouveaux = adsk.core.ObjectCollection.create()
    res = []
    for i in range(cp.bodies.count):
        nouveaux.add(cp.bodies.item(i))
        res.append(cp.bodies.item(i))
    mi = comp.features.moveFeatures.createInput2(nouveaux)
    mi.defineAsFreeMove(T0.m)
    mf = comp.features.moveFeatures.add(mi)
    _copie_info['dec'] = T0
    try:
        _copie_info['move'] = mf.entityToken
        _copie_info['sources'] = [b.entityToken for b in corps]
    except Exception:
        _copie_info['move'] = None
    return res


def _saut_masques(inputs, groupe, chemin, qn):
    """(nombre de copies de tete masquees, decalage le long du chemin du corps
    cree, numeros de copies masquees restants). Une copie masquee ne peut pas
    etre retiree si c'est le corps de depart du reseau : on le cree donc a la
    place de la 1re copie gardee et on supprime les copies de tete."""
    gm = groupe is not None
    masques = set(_gmasq.get(groupe['key'], ())) if gm else _masques(inputs)
    if not _mode_debut(inputs) or _vsym(inputs) or qn < 2:
        return 0, 0.0, masques
    saut = 0
    while saut + 1 in masques and saut + 1 < qn:
        saut += 1
    if saut == 0:
        return 0, 0.0, masques
    L = chemin.longueur
    if gm:
        s0, s_end = groupe['s0'], groupe['s_fin']
    else:
        s0 = _s0_dialogue(inputs, L)
        sgn = -1.0 if inputs.itemById('inverser').value else 1.0
        d = inputs.itemById('distance').value
        if _dd_key(inputs.itemById('repartition'), REPARTITIONS) == 'espacement':
            d *= _n_pas(inputs)
        s_end = s0 + sgn * d
        if not chemin.ferme:
            s_end = max(0.0, min(L, s_end))
    pas = abs(s_end - s0) / (qn - 1)
    return saut, saut * pas, {k - saut for k in masques if k > saut}


_objets_exec = {'tok': None}


def _objets_valides(inputs, objets):
    """Modification depuis l'historique (chronologie reculee) : apres la creation
    d'un 1er chemin, la selection des objets de la boite peut etre videe par
    Fusion (erreur « Choisissez au moins un corps » au 2e chemin). On retrouve
    alors les objets par leurs jetons, memorises au debut de l'execution."""
    toks = _objets_exec['tok']
    if not toks:
        return objets
    try:
        ok = [o for o in objets if getattr(o, 'isValid', True)]
        if len(ok) >= len(toks):
            return objets
        design = adsk.fusion.Design.cast(_app.activeProduct)
        res = []
        for t in toks:
            r = design.findEntityByToken(t)
            if r:
                res.append(r[0])
        if res:
            _log('objets retrouves par jeton : %d (selection : %d)' % (len(res), len(objets)))
            try:
                sel = inputs.itemById('objets')
                sel.clearSelection()
                for o in res:
                    sel.addSelection(o)
            except Exception:
                pass
            return res
    except Exception:
        _log('objets retrouves erreur %s' % traceback.format_exc()[-300:])
    return objets


def _creer_natif(inputs, apercu=False, groupe=None):
    _pivot(inputs)
    design = adsk.fusion.Design.cast(_app.activeProduct)
    comp = design.activeComponent
    objets = _selections(inputs.itemById('objets'))
    if not apercu:
        objets = _objets_valides(inputs, objets)
    orig_toks = {o.entityToken for o in objets}
    orig_noms = [o.name for o in objets]
    en_composants = _nc_est_composant(objets)       # piece de la bibliotheque creee comme composant
    gm = groupe is not None
    ents = groupe['ents'] if gm else _selections(inputs.itemById('chemin'))
    qn = groupe['q'] if gm else int(inputs.itemById('quantite').value)
    etendu = False
    _jonc['on'] = _ignorer_jonction(inputs)
    if _jonc['on']:
        try:
            ents2 = _chemin_sans_jonction(design, comp, ents)
            etendu = ents2 is not ents
            ents = ents2
        except Exception:
            _log('chemin sans jonction erreur %s' % traceback.format_exc()[-400:])
    path, chemin = _construire_chemin(ents)
    _copie_info['move'] = None
    _copie_info['dec'] = None
    # copies masquees en tete : on ne les cree pas, le corps cree prend la place de la 1re gardee
    saut_n, saut_len, masques_apres = _saut_masques(inputs, groupe, chemin, qn)
    portion = bool(gm and groupe.get('portion'))
    if portion:
        saut_len = groupe['saut_len']          # troncon entre deux cales : le corps cree part de son debut
    qn -= saut_n
    e_vs = None
    if _vsym(inputs):
        # demi-etendue unique : meme valeur pour placer la 1re copie et pour les parametres Fusion
        if gm and groupe.get('e') is not None:
            e_vs = max(0.0, min(float(groupe['e']), _etendue_sym(chemin, objets, max(2, groupe['q']))))
        else:
            e_vs = _e_vsym(inputs, chemin, objets)
            if etendu and _fin_chemin(inputs) and not gm:
                e_vs = _etendue_sym(chemin, objets, int(inputs.itemById('quantite').value))
    cx_bords, d_bords = None, None
    if _mode_debut(inputs) and not apercu and not portion and \
            _dd_key(inputs.itemById('orientation'), ORIENTATIONS) == 'trajectoire':
        # contexte de l'apercu, calcule avant la creation : les copies creees iront a ses places
        try:
            if gm:
                cx_bords = _ctx_calcul(inputs, ents=groupe['ents'], q=groupe['q'], s0=groupe['s0'],
                                       e_vs=e_vs if _vsym(inputs) else None)
                if cx_bords is not None:
                    cx_bords['masques'] = set(_gmasq.get(groupe['key'], ()))
                    if cx_bords['vsym']:
                        cx_bords['emax'] = _etendue_sym(cx_bords['ch'], cx_bords['objs'], groupe['q'])
                d_bords = abs(groupe['s_fin'] - groupe['s0'])
            else:
                cx_bords = _ctx_calcul(inputs)
                d_bords = inputs.itemById('distance').value
        except Exception:
            cx_bords = None
            _log('bords contexte erreur %s' % traceback.format_exc()[-300:])
    if _mode_debut(inputs) and not apercu:
        objets = _creer_copie_debut(inputs, comp, objets, chemin, ents, saut_len, e_vs)
    tok_copies = [o.entityToken for o in objets] if (_mode_debut(inputs) and not apercu) else []
    coll = adsk.core.ObjectCollection.create()
    for o in objets:
        coll.add(o)
    L = chemin.longueur
    rep = _dd_key(inputs.itemById('repartition'), REPARTITIONS)
    # Toujours en etendue cote Fusion : _params_fusion donne l'etendue TOTALE
    # (espacement = pas x nombre de pas). En type Espacement, Fusion prenait
    # cette etendue pour le pas : copies toutes au bout du chemin (essai du
    # 2026-10-16, espacement 11 cm, 6 copies).
    ptype = adsk.fusion.PatternDistanceType.ExtentPatternDistanceType
    # Nos reglages (comme la boite native vue par l'utilisateur) : la
    # distance part de l'objet. L'API, elle, mesure Distance depuis le debut
    # du chemin (essais du 2026-10-12 sur une droite de 500 mm : depart 0.5,
    # etendue 200 mm -> copies a 250, 225, 200 mm). On convertit donc en
    # abscisse de la derniere copie (etendue) ou de la 2e (espacement).
    s0 = _s0_dialogue(inputs, L)
    sgn = -1.0 if inputs.itemById('inverser').value else 1.0
    d_in = inputs.itemById('distance').value
    s_cible = s0 + sgn * (d_in * _n_pas(inputs) if rep == 'espacement' else d_in)
    if etendu and _fin_chemin(inputs) and not _vsym(inputs):
        s_cible = _bout(chemin, s0, sgn < 0, qn)      # le chemin entier est plus long que l'arete choisie
    if gm or saut_n:
        # plusieurs chemins / nombre automatique : etendue jusqu'au bout de
        # CE chemin, depart d'apres la copie creee
        inv_g = bool(inputs.itemById('inverser').value)
        s0 = max(0.0, min(L, chemin.abscisse_proche(_centre_bbox(objets)) + _decalage_pivot(
            chemin, objets, _repere_cle(inputs), inv_g, _zero(_pivot(inputs)))))
        sgn = -1.0 if inv_g else 1.0
        if gm:
            s_cible = groupe['s_fin']
        else:
            s_cible = max(0.0, min(L, s_cible)) if not chemin.ferme else s_cible
    vs = _vsym(inputs)
    if vs:
        # symetrique virtuel : du corps cree a gauche (centre - E) a la cible a
        # droite (centre + E), reseau a sens unique, pas = 2 E / (q - 1)
        e = e_vs
        s0 = L / 2.0 - e
        s_cible = L / 2.0 + e
        sgn = 1.0
    elif not chemin.ferme:
        # Au-dela du bout du chemin Fusion refuse le reseau : on s'arrete au bout.
        s_cible = max(0.0, min(L, s_cible))
    # etendue jusqu'au bout du chemin (case cochee ou non : l'etat de la case
    # n'etait pas fiable a la validation, aucun recalage n'etait enregistre)
    au_bout = (not vs and abs(s_cible - _bout(chemin, s0, sgn < 0, qn)) < 0.2)
    if vs:
        # symetrique : les deux corps des extremites ont leur face exterieure pile aux bouts du chemin
        au_bout = abs(s_cible - (L / 2.0 + _etendue_sym(chemin, objets, int(inputs.itemById('quantite').value)))) < 0.2
    _log('au_bout: rep=%s vs=%s s0=%.6f d_in=%.6f s_cible=%.6f bout=%.6f -> %s' % (
        rep, vs, s0, d_in, s_cible, _bout(chemin, s0, sgn < 0, qn), au_bout))
    # mode "creer au debut" : le corps peut etre decale du chemin (hauteur,
    # lateral) ; une translation nulle desactive le test "colle au chemin"
    s0_base = s0
    dl = _decalage_pivot(chemin, objets, _repere_cle(inputs), sgn < 0 and not vs,
                         _zero(_pivot(inputs)) if _mode_debut(inputs) else None)
    if dl:
        s0 -= dl
        s_cible = max(0.0, min(L, s_cible - dl))
    depart, dist, flip = _params_fusion(path, chemin, s0, s_cible)
    _log('creer vs=%s sym_dir=%s sym=%s ferme=%s L=%.2f s0=%.2f cible=%.2f depart=%.4f dist=%.2f flip=%s' % (
        vs, _sym_dir(inputs), _symetrique(inputs), chemin.ferme, L, s0, s_cible, depart, dist, flip))
    # Fusion refuse un reseau d'une seule copie (« count > 1 ») : on demande 2 copies et on supprime la 2e
    # (meme mecanisme que les copies masquees), il reste le corps de depart seul.
    un_seul = qn < 2
    if un_seul:
        qn = 2
    q = adsk.core.ValueInput.createByReal(qn)
    pps = comp.features.pathPatternFeatures
    pin = pps.createInput(coll, path, q, adsk.core.ValueInput.createByReal(dist), ptype)
    pin.startPoint = depart
    pin.isFlipDirection = flip
    pin.isSymmetric = False if (gm or un_seul) else _symetrique(inputs)
    orient_demandee = _dd_key(inputs.itemById('orientation'), ORIENTATIONS) == 'trajectoire'
    pin.isOrientationAlongPath = orient_demandee
    if _dd_key(inputs.itemById('type_objet'), TYPES_OBJET) == 'fonctions':
        opt = {'optimise': adsk.fusion.PatternComputeOptions.OptimizedPatternCompute,
               'identique': adsk.fusion.PatternComputeOptions.IdenticalPatternCompute,
               'ajuster': adsk.fusion.PatternComputeOptions.AdjustPatternCompute}
        pin.patternComputeOption = opt[_dd_key(inputs.itemById('calcul'), CALCULS)]
    feat = pps.add(pin)
    try:
        pe = [path.item(i).entity for i in range(path.count)]
        if pe and all(adsk.fusion.BRepEdge.cast(e) is not None for e in pe):
            feat.attributes.add(ATTR_GROUPE, 'chemin_sig', json.dumps([len(pe), round(sum(e.length for e in pe), 3), [e.entityToken for e in pe]]))
    except Exception:
        _log('empreinte chemin erreur %s' % traceback.format_exc()[-200:])
    _log('creer attribut: fin_chemin=%s au_bout=%s sym_dir=%s apercu=%s depart_champ=%.8f s0_exact=%s' % (
        _fin_chemin(inputs), au_bout, _sym_dir(inputs), apercu, inputs.itemById('depart').value, _dep_exact['s0']))
    if not apercu and ((_fin_chemin(inputs) and not portion) or au_bout or portion) and (not _sym_dir(inputs) or vs):
        try:
            reg_attr = ({
                'repere': _repere_cle(inputs), 'inverser': bool(inputs.itemById('inverser').value),
                'repartition': rep, 'mode_debut': _mode_debut(inputs), 'vsym': bool(vs),
                'dep': (s0_base / L) if (L > 0 and _mode_debut(inputs) and not vs and not gm and not saut_n) else None,
                'orientation': bool(feat.isOrientationAlongPath), 'saut': saut_n,
                'move': _copie_info['move'], 'sources': _copie_info['sources'], 'pivot': _pivot(inputs), 'haut': _haut(inputs), 'cote_inv': bool(_cote_inv['v']),
                'cote': getattr(_copie_info.get('dec'), 'cote_bords', None),
                'dlat': inputs.itemById('decal_lat').value, 'dhaut': inputs.itemById('decal_haut').value,
                'objets': [o.entityToken for o in objets],
                'debut': [chemin.debut.x, chemin.debut.y, chemin.debut.z]})
            if portion and groupe.get('cales'):
                reg_attr['cales'] = groupe['cales']
            try:
                reg_attr['sig'] = _sig_reseau(chemin, design, reg_attr)
            except Exception:
                pass
            feat.attributes.add(ATTR_GROUPE, ATTR_FIN, json.dumps(reg_attr))
        except Exception:
            _log('attribut fin erreur %s' % traceback.format_exc()[-400:])
    if not apercu and _blob['v'] is not None:
        try:
            feat.attributes.add(ATTR_GROUPE, ATTR_EDIT, json.dumps(_blob['v']))
        except Exception:
            _log('attribut edition erreur %s' % traceback.format_exc()[-300:])
    masques = set(masques_apres)
    if un_seul:
        masques.add(2)
    if not _mode_debut(inputs):
        masques.discard(1)
    cacher_copie = 1 in masques
    masques.discard(1)
    if masques and not apercu:
        # L'API exige le marqueur de timeline juste avant la fonction pour
        # masquer des elements. Numero 1 = origine = 1er element.
        try:
            elems = feat.patternElements
            ids = [elems.item(n - 1).id for n in sorted(masques) if n - 1 < elems.count]
            feat.timelineObject.rollTo(True)
            feat.suppressedElementsIds = ids
            # ecrire une propriete chronologie reculee remet l'orientation sur
            # « identique » (comme startPoint) : on la retablit
            feat.isOrientationAlongPath = orient_demandee
        except Exception:
            pass
        finally:
            try:
                design.timeline.moveToEnd()
            except Exception:
                pass
    if cacher_copie and not apercu and _mode_debut(inputs):
        # copie du debut « masquee » : on l'eteint (elle sert de graine au reseau,
        # on ne peut pas la supprimer)
        for tok in tok_copies:
            try:
                for e in design.findEntityByToken(tok):
                    adsk.fusion.BRepBody.cast(e).isLightBulbOn = False
                    break
            except Exception:
                _log('cacher copie erreur %s' % traceback.format_exc()[-300:])
    if not apercu and _mode_debut(inputs) and orient_demandee and _copie_info.get('dec') is not None:
        try:
            feat = _bords_copies(design, comp, feat, chemin, _copie_info['dec'], set(tok_copies) | orig_toks,
                                 cx_bords, d_bords, tok_copies)
        except Exception:
            _log('bords copies erreur %s' % traceback.format_exc()[-400:])
    if not apercu:
        crees = []
        try:
            crees = _renumeroter_copies(feat, tok_copies, orig_toks, orig_noms, design, chemin)
        except Exception:
            _log('renumerotation erreur %s' % traceback.format_exc()[-400:])
        if en_composants and crees:
            try:
                tf = feat.entityToken
                nouveaux = _en_composants(crees, design)
                if nouveaux:
                    feat = adsk.fusion.PathPatternFeature.cast(design.findEntityByToken(tf)[0])
                    a = feat.attributes.itemByName(ATTR_GROUPE, ATTR_FIN)
                    if a is not None:
                        reg = json.loads(a.value)
                        reg['objets'] = [nouveaux.get(t, t) for t in reg.get('objets', [])]
                        a.value = json.dumps(reg)
            except Exception:
                _log('copies en composants erreur %s' % traceback.format_exc()[-400:])
        _diag_composants(feat, comp, design, chemin, ents, objets, inputs, gm)
    return feat


def _plan_creation_cales(inputs, g=None):
    """{'ents', 'ch', 'plan'} si des cales de renfort sont sur le chemin du reseau a creer, sinon None.
    g : un chemin parmi plusieurs (groupe de _groupes_calc), sinon l'unique chemin de la boite."""
    vue = g['vue'] if g else inputs
    if not (_eviter_cales(vue) and _mode_debut(vue)) or _sym_dir(vue) or _nb_auto(inputs):
        return None
    if g is not None:
        if g.get('sym') or _gmasq.get(g['key']):
            return None
        ents = g['ents']
    else:
        if _masques(inputs):
            return None
        ents = _selections(inputs.itemById('chemin'))
        if not ents or len(_groupes_chemin(ents)) > 1:
            return None
    _jonc['on'] = _ignorer_jonction(inputs)
    ch = g['ch'] if g is not None else _chemin_cache(ents)
    zones = _zones_cales(ch)
    if not zones:
        return None
    objs = _selections(inputs.itemById('objets'))
    corps = [o for o in objs if isinstance(o, adsk.fusion.BRepBody)]
    if not corps:
        return None
    L = ch.longueur
    inv = bool(g['inv']) if g is not None else bool(inputs.itemById('inverser').value)
    if g is not None:
        q, s0, s_end = int(g['q']), g['s0'], g['s_fin']
        T0 = _decal_debut(vue, ch, corps, 0.0, ents)
        dl = _decalage_pivot(ch, corps, _repere_cle(vue), inv, T0)
    else:
        q = int(inputs.itemById('quantite').value)
        rep = _dd_key(inputs.itemById('repartition'), REPARTITIONS)
        d_in = inputs.itemById('distance').value
        # abscisses de repere (face avant du corps) comme le reseau normal : depart = celui de la copie du debut
        ch, s0 = _s0_groupe(inputs, corps, ents)
        T0 = _decal_debut(inputs, ch, corps, 0.0, ents)
        dl = _decalage_pivot(ch, corps, _repere_cle(inputs), inv, T0)
        sgn = -1.0 if inv else 1.0
        s_end = s0 + sgn * (d_in * _n_pas(inputs) if rep == 'espacement' else d_in)
        if not ch.ferme:
            s_end = max(0.0, min(L, s_end))
    plan = _plan_cales(L, ch.ferme, s0, s_end, q, [(a + dl, b + dl) for a, b in zones],
                       _demi_epaisseur(objs), _jeu_cales(vue))
    if plan is None:
        return None
    _log('cales : %d zone(s) %s -> %d troncon(s) %s' % (
        len(zones), [(round(a, 2), round(b, 2)) for a, b in zones], len(plan['portions']),
        [(p['n'], round(p['u0'], 2), round(p['u1'], 2)) for p in plan['portions']]))
    fin = (g is None and bool(_fin_chemin(inputs))) or (not ch.ferme and abs(s_end - _bout(ch, s0, inv, q)) < 0.2)
    return {'ents': ents, 'ch': ch, 'plan': plan, 'inv': inv, 'vue': vue, 'cle': g['key'] if g else None,
            'cales': {'np': len(plan['portions']), 'q': q, 'jeu': _jeu_cales(vue), 'fin': fin,
                      'd': abs(s_end - s0)}}


def _creer_portions(inputs, pl):
    res = []
    for i, p in enumerate(pl['plan']['portions']):
        g = {'ents': pl['ents'], 'q': p['n'], 's0': p['s_deb'], 's_fin': p['s_fin'], 'key': ('cales', pl['cle'], i),
             'saut_len': p['u0'], 'portion': True, 'ch': pl['ch'], 'inv': pl['inv'], 'sym': False, 'e': None,
             'vue': pl['vue'], 'cales': dict(pl['cales'], i=i)}
        res.append(_creer_natif(pl['vue'], groupe=g))
    return res


def _creer_reseau(inputs, g=None):
    """Reseau d'une seule piece, ou, s'il y a des cales de renfort sur le chemin, un reseau par troncon
    libre entre les cales (le meme chemin, le corps du debut de chaque troncon copie a sa place).
    g : un chemin parmi plusieurs."""
    pl = None
    try:
        pl = _plan_creation_cales(inputs, g)
    except Exception:
        _log('cales : plan erreur %s' % traceback.format_exc()[-400:])
    if pl is None:
        return [_creer_natif(g['vue'], groupe=g) if g is not None else _creer_natif(inputs)]
    return _creer_portions(inputs, pl)


def _renumeroter_copies(feat, tok_copies, orig_toks, orig_noms, design, chemin):
    """Nom des corps crees : « base (n) » avec n qui continue d'un reseau a l'autre
    (T1 (1), T1 (2), T1 (3), puis T1 (4)...), dans l'ordre le long du chemin."""
    if not orig_noms:
        return []
    base = re.sub(r'\s*\(\d+\)\s*$', '', orig_noms[0]).strip()
    if not base:
        return []
    crees, vus = [], set()
    cands = []
    for tok in tok_copies:
        try:
            cands.extend(design.findEntityByToken(tok)[:1])
        except Exception:
            pass
    for i in range(feat.bodies.count):
        cands.append(feat.bodies.item(i))
    for b in cands:
        b = adsk.fusion.BRepBody.cast(b)
        if b is None or not b.isValid:
            continue
        t = b.entityToken
        if t in vus or t in orig_toks:
            continue
        vus.add(t)
        crees.append(b)
    if not crees:
        return []

    def abscisse(b):
        try:
            return chemin.abscisse_proche(b.physicalProperties.centerOfMass)
        except Exception:
            return 0.0
    ordre = {id(b): k for k, b in enumerate(crees)}
    crees.sort(key=lambda b: (abscisse(b), ordre[id(b)]))
    motif = re.compile(r'^' + re.escape(base) + r'\s*\((\d+)\)$')
    deja = 0
    for ci in range(design.allComponents.count):
        c = design.allComponents.item(ci)
        for j in range(c.bRepBodies.count):
            b = c.bRepBodies.item(j)
            if b.entityToken in vus:
                continue
            m = motif.match(b.name)
            if m:
                deja = max(deja, int(m.group(1)))
    for k, b in enumerate(crees):          # noms provisoires : evite les collisions « (2) » -> « (2) »
        b.name = '__rt_tmp_%d' % k
    for k, b in enumerate(crees):
        b.name = '%s (%d)' % (base, deja + 1 + k)
    return crees


def _nc_est_composant(objets):
    """Vrai si l'objet choisi est une piece de la bibliotheque creee comme composant."""
    try:
        toks = set()
        for o in objets:
            n = getattr(o, 'nativeObject', None) or o
            toks.add(n.entityToken)
        return any(e['body'].entityToken in toks and e['occ'].entityToken != e['racine'].entityToken for e in _nc_liste())
    except Exception:
        return False


def _en_composants(corps, design):
    """Chaque corps cree devient un composant du meme nom (Corps -> Composant).
    Renvoie {ancien jeton: jeton du corps vu depuis la racine} pour les reseaux qui s'y referent."""
    infos = [(b.entityToken, b.name, b.isLightBulbOn) for b in corps if b.isValid]
    res = {}
    for tok, nom, visible in infos:
        # la chronologie se recalcule apres chaque conversion : on relit le corps par son jeton
        trouves = design.findEntityByToken(tok)
        b = adsk.fusion.BRepBody.cast(trouves[0]) if trouves else None
        if b is None or not b.isValid:
            _log('conversion composant : corps introuvable %s' % nom)
            continue
        nb = b.createComponent()           # le corps cree dans le nouveau composant, vu depuis la racine
        if nb is None:
            continue
        occ = nb.assemblyContext
        if occ is not None:
            occ.component.name = nom
            if not visible:
                occ.isLightBulbOn = False
        res[tok] = nb.entityToken
    return res


def _diag_composants(feat, comp, design, chemin, ents, objets, inputs=None, gm=False):
    """Journal de diagnostic : composant actif, transformation, position et
    orientation (monde) des corps crees, pour comparer a l'apercu quand le
    chemin et le corps sont dans des composants differents."""
    try:
        occ = design.activeOccurrence
        _log('diag composant actif=%s occurrence=%s' % (comp.name, 'oui' if occ is not None else 'racine'))
        if occ is not None:
            _log('diag transform actif=%s' % [round(v, 4) for v in occ.transform2.asArray()])
        for e in ents:
            _log('diag chemin %s composant=%s contexte=%s' % (
                type(e).__name__, getattr(getattr(getattr(e, 'body', None), 'parentComponent', None), 'name', '?'),
                getattr(getattr(e, 'assemblyContext', None), 'name', 'natif')))
        for o in objets:
            _log('diag objet %s composant=%s contexte=%s' % (
                type(o).__name__, getattr(getattr(o, 'parentComponent', None), 'name', '?'),
                getattr(getattr(o, 'assemblyContext', None), 'name', 'natif')))
        _log('diag chemin debut=%s fin=%s' % (
            [round(v, 3) for v in (chemin.point_tangente(0.0)[0].x, chemin.point_tangente(0.0)[0].y, chemin.point_tangente(0.0)[0].z)],
            [round(v, 3) for v in (chemin.point_tangente(chemin.longueur)[0].x, chemin.point_tangente(chemin.longueur)[0].y,
                                   chemin.point_tangente(chemin.longueur)[0].z)]))
        corps = [feat.bodies.item(i) for i in range(feat.bodies.count)]
        corps += [o for o in objets if isinstance(o, adsk.fusion.BRepBody)]
        for b in corps:
            bw = b
            if occ is not None:
                try:
                    bw = b.createForAssemblyContext(occ)
                except Exception:
                    bw = b
            c = bw.physicalProperties.centerOfMass
            f = _grandes_faces(bw)
            nrm = f[0].geometry.normal if f else None
            _log('diag corps com=(%.3f, %.3f, %.3f) normale=%s' % (
                c.x, c.y, c.z, '?' if nrm is None else '(%.3f, %.3f, %.3f)' % (nrm.x, nrm.y, nrm.z)))
        if inputs is not None and not gm:
            # ce que l'apercu avait prevu pour la meme creation
            srcs = [o for o in _selections(inputs.itemById('objets')) if isinstance(o, adsk.fusion.BRepBody)]
            cx = _ctx_calcul(inputs)
            arrs = _mats_orange(cx, inputs.itemById('distance').value)
            T0 = cx['T0']
            cs = srcs[0].physicalProperties.centerOfMass
            fs = _grandes_faces(srcs[0])
            n0 = fs[0].geometry.normal if fs else None
            p0 = adsk.core.Point3D.create(cs.x, cs.y, cs.z)
            v0 = None if n0 is None else adsk.core.Vector3D.create(n0.x, n0.y, n0.z)
            if T0 is not None:
                p0.transformBy(T0.m)
                if v0 is not None:
                    v0.transformBy(T0.m)
            _log('diag apercu 0 com=(%.3f, %.3f, %.3f) normale=%s' % (
                p0.x, p0.y, p0.z, '?' if v0 is None else '(%.3f, %.3f, %.3f)' % (v0.x, v0.y, v0.z)))
            for k, a in enumerate(arrs):
                m = adsk.core.Matrix3D.create()
                m.setWithArray(a)
                q = adsk.core.Point3D.create(p0.x, p0.y, p0.z)
                q.transformBy(m)
                nn = None
                if v0 is not None:
                    nn = adsk.core.Vector3D.create(v0.x, v0.y, v0.z)
                    nn.transformBy(m)
                _log('diag apercu %d com=(%.3f, %.3f, %.3f) normale=%s' % (
                    k + 1, q.x, q.y, q.z, '?' if nn is None else '(%.3f, %.3f, %.3f)' % (nn.x, nn.y, nn.z)))
    except Exception:
        _log('diag erreur %s' % traceback.format_exc()[-300:])


def _centre_objets(inputs):
    """Centre (document) des objets selectionnes, None si inconnu."""
    pts = []
    for o in _selections(inputs.itemById('objets')):
        try:
            bb = o.boundingBox
            pts.append(((bb.minPoint.x + bb.maxPoint.x) / 2, (bb.minPoint.y + bb.maxPoint.y) / 2,
                        (bb.minPoint.z + bb.maxPoint.z) / 2))
        except Exception:
            continue
    if not pts:
        return None
    n = float(len(pts))
    return adsk.core.Point3D.create(sum(p[0] for p in pts) / n, sum(p[1] for p in pts) / n,
                                    sum(p[2] for p in pts) / n)


def _grandes_faces(corps):
    """Les deux grandes faces planes opposees du panneau (pas les chants)."""
    planes = []
    for i in range(corps.faces.count):
        f = corps.faces.item(i)
        try:
            if isinstance(f.geometry, adsk.core.Plane):
                planes.append(f)
        except Exception:
            continue
    if len(planes) < 2:
        return []
    f1 = max(planes, key=lambda f: f.area)
    n1 = f1.geometry.normal
    opp = [f for f in planes if f is not f1 and abs(abs(f.geometry.normal.dotProduct(n1)) - 1) < 1e-3
           and abs(_vec(f1.centroid, f.centroid).dotProduct(n1)) > 1e-4]
    if not opp:
        return []
    return [f1, max(opp, key=lambda f: f.area)]


def _haut(inputs):
    """Traverse a deux tenons : posee sur son tenon du haut au lieu de celui du bas."""
    try:
        return bool(inputs.itemById('tenon_haut').value) and _mode_debut(inputs)
    except Exception:
        return False


_pivot_courant = {'v': False}      # dernier etat « pivoter » evalue (lu par _etendue_sym)
_cote_inv = {'v': False}           # case « Inverser le cote » (pivoter face) evaluee en dernier
_cote_force = {'v': None}          # recalage : cote du chemin retenu a la creation (le chemin change, pas le cote)


def _pivot(inputs):
    """Copie du debut tournee de 90 degres : face contre le chemin au lieu du chant."""
    try:
        r = bool(inputs.itemById('pivot').value) and _mode_debut(inputs)
    except Exception:
        r = False
    _pivot_courant['v'] = r
    try:
        _cote_inv['v'] = bool(inputs.itemById('cote_inv').value)
    except Exception:
        _cote_inv['v'] = False
    return r


def _objets_touchent_chemin(inputs, tol=0.02):
    """True si un objet choisi touche le chemin (distance mini <= tol cm), None si indetermine."""
    objs = _selections(inputs.itemById('objets'))
    ents = _selections(inputs.itemById('chemin'))
    if not objs or not ents:
        return None
    mm = _app.measureManager
    connu = False
    for o in objs:
        for e in ents:
            try:
                if mm.measureMinimumDistance(o, e).value <= tol:
                    return True
                connu = True
            except Exception:
                continue
    return False if connu else None


def _auto_copie(inputs):
    """Objet loin du chemin : « Copier le corps » se coche seul ; objet au contact : il se decoche.
    Reste modifiable a la main (n'est recalcule qu'au changement de selection)."""
    try:
        if not (inputs.itemById('objets').selectionCount and inputs.itemById('chemin').selectionCount):
            return False
        t = _objets_touchent_chemin(inputs)
        sep = len(_groupes_chemin(_selections(inputs.itemById('chemin')))) > 1
        _log('auto copie : touche=%s chemins separes=%s' % (t, sep))
        if sep:
            voulu = True       # chemins non joints : un reseau par chemin, ce qui demande « Copier le corps »
        elif t is None:
            return False
        else:
            voulu = not t
        cd = inputs.itemById('cree_debut')
        if bool(cd.value) == voulu:
            return False
        cd.value = voulu
        return True
    except Exception:
        _log('auto copie erreur %s' % traceback.format_exc()[-300:])
        return False


def _mode_debut(inputs):
    try:
        return bool(inputs.itemById('cree_debut').value)
    except Exception:
        return False


def _n_pas(inputs):
    """Nombre de pas entre l'objet et la derniere copie : q - 1 dans un sens,
    q // 2 en symetrique (copies alternees de part et d'autre)."""
    q = int(inputs.itemById('quantite').value)
    return max(0.5, (q - 1) / 2.0) if _sym_dir(inputs) else max(1, q - 1)


def _sym_dir(inputs):
    """Direction « symetrique » choisie."""
    try:
        return _dd_key(inputs.itemById('direction'), DIRECTIONS) == 'symetrique'
    except Exception:
        return False


def _vsym(inputs):
    """Symetrique « virtuel » : 1er corps cree + symetrique (chemin ouvert ou ferme). Le
    reseau de Fusion pair n'est pas centre : on cree un reseau a sens unique
    du bout gauche au bout droit (centre du chemin +/- E), symetrique pour
    tout nombre de copies ; Point de depart reste au milieu du chemin."""
    return bool(_sym_dir(inputs) and _mode_debut(inputs))


def _symetrique(inputs):
    """Reseau symetrique effectif cote Fusion (jamais en symetrique virtuel)."""
    return _sym_dir(inputs) and not _vsym(inputs)


def _e_vsym(inputs, ch, objs):
    """Etendue d'un cote (symetrique virtuel), bornee aux deux bouts du chemin."""
    _pivot(inputs)
    d = inputs.itemById('distance').value
    if _dd_key(inputs.itemById('repartition'), REPARTITIONS) == 'espacement':
        d *= max(0.5, (int(inputs.itemById('quantite').value) - 1) / 2.0)
    return max(0.0, min(d, _etendue_sym(ch, objs, int(inputs.itemById('quantite').value))))


_sym_msg = {'t': 0.0}


def _sym_bloquee(inputs):
    """Symetrique sans « creer le 1er corps » avec l'objet pose au bout du
    chemin ouvert : une moitie du reseau sortirait du chemin."""
    try:
        if not _sym_dir(inputs) or _mode_debut(inputs):
            return False
        objs = _selections(inputs.itemById('objets'))
        ents = _ents_actifs(inputs)
        if not objs or not ents:
            return False
        ch = _chemin_cache(ents)
        c = _centre_bbox(objs)
        if ch.ferme or c is None or ch.longueur <= 0:
            return False
        s0 = ch.abscisse_proche(c)
        return min(s0, ch.longueur - s0) < 0.1 * ch.longueur
    except Exception:
        return False


def _repere_cle(inputs):
    try:
        if _mode_debut(inputs) and _sym_dir(inputs):
            return 'centre'     # symetrique : le 1er corps est au centre du chemin
        if _mode_debut(inputs):
            # 1er corps : face de gauche au debut ; dernier : face de droite au
            # bout (gauche = arriere, droite = avant dans le sens du reseau,
            # aussi quand il est inverse)
            return 'droite'
        rp = inputs.itemById('repere')
        return REPERES[rp.selectedItem.index][0] if rp.selectedItem else 'centre'
    except Exception:
        return 'centre'


def _centre_bbox(objs):
    pts = []
    for o in objs:
        try:
            bb = o.boundingBox
            pts.append(((bb.minPoint.x + bb.maxPoint.x) / 2, (bb.minPoint.y + bb.maxPoint.y) / 2,
                        (bb.minPoint.z + bb.maxPoint.z) / 2))
        except Exception:
            continue
    if not pts:
        return None
    n = float(len(pts))
    return adsk.core.Point3D.create(sum(p[0] for p in pts) / n, sum(p[1] for p in pts) / n,
                                    sum(p[2] for p in pts) / n)


def _repere_objets(objs, k, ch, s0, inv):
    """Centre des objets, ou centre de leur grande face de gauche / droite
    (gauche = cote debut du chemin, droite = cote ou part le reseau)."""
    c = _centre_bbox(objs)
    f = _repere_face(objs, k, ch, s0, inv)
    return c if f is None else f.centroid


def _repere_face(objs, k, ch, s0, inv, dec=None):
    """Grande face de gauche / droite du corps, None pour le centre.
    dec : deplacement prevu (1er corps cree au debut, eventuellement tourne)."""
    c = _centre_bbox(objs)
    if k == 'centre' or c is None:
        return None
    if dec is not None:
        c = adsk.core.Point3D.create(c.x + dec.x, c.y + dec.y, c.z + dec.z)
    corps = [o for o in objs if isinstance(o, adsk.fusion.BRepBody)]
    faces = _grandes_faces(corps[0]) if corps else []
    _p, tg = ch.point_tangente(s0)
    sens = adsk.core.Vector3D.create(tg.x, tg.y, tg.z)
    if inv:
        sens.scaleBy(-1)
    if corps and getattr(dec, 'pivot', False):
        # copie pivotee : les faces de repere sont celles dont la normale suit le chemin
        al = []
        for i in range(corps[0].faces.count):
            f = corps[0].faces.item(i)
            try:
                pl = adsk.core.Plane.cast(f.geometry)
                if pl is not None:
                    al.append((abs(_tourner(dec, pl.normal).dotProduct(sens)), f))
            except Exception:
                continue
        if al:
            meilleur = max(a for a, _f in al)
            alignees = [f for a, f in al if a >= meilleur - 0.05]    # courbe : la tangente change le long du corps
            if len(alignees) >= 2:
                faces = alignees
    if not faces:
        return None
    faces.sort(key=lambda f: _vec(c, _appliquer(dec, f.centroid)).dotProduct(sens))
    return faces[-1] if k == 'droite' else faces[0]


def _s_face(ch, objs, k, sc, inv, decal=None):
    """Abscisse (bornee au chemin) ou le chemin traverse le PLAN de la face de
    repere, la plus proche de sc. Le centre de la face ne convient pas : un
    corps penche par rapport au chemin a son centre de face decale le long de
    la tangente, et la face arrivait trop loin du bout (retour du 2026-10-16,
    contreplaque penche d'environ 25 degres)."""
    f = _repere_face(objs, k, ch, sc, inv, decal)
    if f is None:
        return None
    pl = adsk.core.Plane.cast(f.geometry)
    cf = _appliquer(decal, f.centroid)
    if pl is None:
        return ch.abscisse_proche(cf)
    n = _tourner(decal, pl.normal)
    org = _appliquer(decal, pl.origin)
    L = ch.longueur

    def g(s):
        return org.vectorTo(ch.point_tangente(s)[0]).dotProduct(n)

    N = 120
    meilleur = None
    prev_s, prev_g = 0.0, g(0.0)
    for i in range(1, N + 1):
        si = L * i / N
        gi = g(si)
        if prev_g == 0.0 or prev_g * gi < 0.0:
            a, b, ga = prev_s, si, prev_g
            for _ in range(40):
                m = (a + b) / 2.0
                gm = g(m)
                if ga * gm <= 0.0:
                    b = m
                else:
                    a, ga = m, gm
            r = (a + b) / 2.0
            if meilleur is None or abs(r - sc) < abs(meilleur - sc):
                meilleur = r
        prev_s, prev_g = si, gi
    if meilleur is not None:
        return meilleur
    # le chemin ne traverse pas le plan (face avant le debut / apres la fin) :
    # on prolonge la tangente la plus proche
    s_e = 0.0 if abs(g(0.0)) < abs(g(L)) else L
    tg = ch.point_tangente(s_e)[1]
    den = tg.x * n.x + tg.y * n.y + tg.z * n.z
    if abs(den) < 1e-9:
        return ch.abscisse_proche(cf)
    return max(0.0, min(L, s_e - g(s_e) / den))


def _point_repere(inputs, ch=None, s0=None, inv=False):
    """Point de l'objet qui suit le chemin (voir _repere_objets) : cette face
    arrive pile au point vise du chemin, bout compris."""
    objs = _selections(inputs.itemById('objets'))
    if ch is None:
        return _centre_bbox(objs)
    return _repere_objets(objs, _repere_cle(inputs), ch, s0, inv)


# --- Bout du chemin parametrique --------------------------------------------
# Un reseau cree avec "Jusqu'au bout du chemin" garde un attribut. Apres
# chaque commande terminee (cote d'esquisse, parametre, extrusion...), si la
# chronologie est a la fin, on remesure son chemin et on recale le reseau pour
# que la face de repere de la derniere copie reste au bout du chemin.

ATTR_GROUPE = 'ReseauTrajectoireCNC'
ATTR_FIN = 'fin_chemin'
_resync_en_cours = {'v': False}


def _fin_chemin(inputs):
    try:
        return bool(inputs.itemById('fin_chemin').value)
    except Exception:
        return False


def _bout(ch, s0, inv, q):
    """Abscisse du "bout du chemin" pour la derniere copie. Chemin ouvert :
    son extremite. Chemin ferme : un tour complet, la derniere copie juste
    avant l'objet (copies regulieres tout autour) ; avant, la fleche butait
    sur la jonction du debut de la boucle (projet ottoman, 2026-10-13)."""
    if ch.ferme:
        tour = ch.longueur * (max(1, q) - 1) / float(max(1, q))
        return s0 - tour if inv else s0 + tour
    return 0.0 if inv else ch.longueur


def _bout_inputs(inputs, ch, s0):
    if _mode_debut(inputs) and _vsym(inputs):
        e = _etendue_sym(ch, _selections(inputs.itemById('objets')), int(inputs.itemById('quantite').value))
        return s0 - e if inputs.itemById('inverser').value else s0 + e
    return _bout(ch, s0, bool(inputs.itemById('inverser').value), int(inputs.itemById('quantite').value))


def _maj_case_fin(inputs, ch, s0, s_fin):
    """Coche la case quand la derniere copie est au bout du chemin."""
    try:
        inputs.itemById('fin_chemin').value = abs(s_fin - _bout_inputs(inputs, ch, s0)) < 0.2
    except Exception:
        pass


def _deplier_groupe(design, feat):
    """rollTo est impossible sur une entree d'un groupe replie : on deplie le
    groupe de chronologie qui contient feat et on le renvoie (a replier ensuite)."""
    try:
        g = feat.timelineObject.parentGroup
        if g is not None and g.isCollapsed:
            g.isCollapsed = False
            return g
    except Exception:
        _log('deplier groupe erreur %s' % traceback.format_exc()[-300:])
    return None


def _replier_groupe(g):
    try:
        if g is not None:
            g.isCollapsed = True
    except Exception:
        pass


def _replacer_copie(design, reglages, ch, ents, q_total=0, saut_fixe=None):
    """Mode 'copier le corps' : la spline a change, le 1er corps est replace
    au debut du nouveau chemin (on rejoue le deplacement de la copie).
    saut_fixe : decalage le long du chemin impose (troncon entre deux cales)."""
    _pivot_courant['v'] = bool(reglages.get('pivot'))
    _cote_inv['v'] = bool(reglages.get('cote_inv'))
    tok = reglages.get('move')
    if not tok:
        return False
    mf = design.findEntityByToken(tok)
    mf = adsk.fusion.MoveFeature.cast(mf[0]) if mf else None
    srcs = []
    for t in reglages.get('sources', []):
        r = design.findEntityByToken(t)
        if r:
            srcs.append(r[0])
    if mf is None or not mf.isValid or not srcs:
        return False
    _cache_pivot.clear()
    inv = bool(reglages.get('inverser'))
    saut_len = 0.0
    saut_n = int(reglages.get('saut', 0))
    if saut_fixe is not None:
        saut_len = float(saut_fixe)
    elif saut_n and q_total > 1:
        # copies de tete masquees : le corps cree est decale de saut_n pas, le pas
        # suivant la longueur du chemin (dernier corps au bout)
        d0 = _placement_debut(ch, srcs, inv, reglages.get('dlat', 0.0), reglages.get('dhaut', 0.0), ents, False, 0.0,
                              bool(reglages.get('pivot')), haut=bool(reglages.get('haut')))
        c0 = _centre_bbox(srcs)
        c1 = adsk.core.Point3D.create(c0.x + d0.x, c0.y + d0.y, c0.z + d0.z)
        s_un = ch.abscisse_proche(c1) + _decalage_pivot(ch, srcs, 'droite', inv, d0)
        saut_len = saut_n * abs(_bout(ch, s_un, inv, q_total) - s_un) / (q_total - 1)
    vs = bool(reglages.get('vsym'))
    ds = -_etendue_sym(ch, srcs, max(2, q_total)) if vs else 0.0
    dec = _placement_debut(ch, srcs, inv, reglages.get('dlat', 0.0),
                           reglages.get('dhaut', 0.0), ents, vs, ds, bool(reglages.get('pivot')), saut_len,
                           bool(reglages.get('haut')))
    a, b = dec.m.asArray(), mf.transform.asArray()
    if max(abs(x - y) for x, y in zip(a, b)) < 1e-6:
        return False
    tl = design.timeline
    grp = _deplier_groupe(design, mf)
    try:
        mf.timelineObject.rollTo(True)
        mf.transform = dec.m
    finally:
        tl.moveToEnd()
        _replier_groupe(grp)
    _log('replacer copie %s' % mf.name)
    return True


def _plan_cales_resync(design, reglages, ch, ents):
    """Reseau coupe par des cales (un reseau par troncon libre) : repartition recalculee sur le chemin
    et les cales d'AUJOURD'HUI. {'plan', 'dl', 's0'} ou None (cales disparues, troncons differents...)."""
    _pivot_courant['v'] = bool(reglages.get('pivot'))
    _cote_inv['v'] = bool(reglages.get('cote_inv'))
    cal = reglages.get('cales')
    if not cal or ch.longueur <= 0:
        return None
    srcs = []
    for t in reglages.get('sources', []):
        r = design.findEntityByToken(t)
        if r:
            srcs.append(r[0])
    if not srcs:
        return None
    L = ch.longueur
    inv = bool(reglages.get('inverser'))
    _cache_pivot.clear()
    dec0 = _placement_debut(ch, srcs, inv, reglages.get('dlat', 0.0), reglages.get('dhaut', 0.0), ents, False, 0.0,
                            bool(reglages.get('pivot')), 0.0, bool(reglages.get('haut')))
    c0 = _centre_bbox(srcs)
    c1 = adsk.core.Point3D.create(c0.x + dec0.x, c0.y + dec0.y, c0.z + dec0.z)
    dl = _decalage_pivot(ch, srcs, reglages.get('repere', 'droite'), inv, dec0)
    s0 = max(0.0, min(L, ch.abscisse_proche(c1) + dl))
    q = int(cal['q'])
    if cal.get('fin'):
        s_end = _bout(ch, s0, inv, q)
    else:
        s_end = s0 + (-1.0 if inv else 1.0) * float(cal['d'])
    if not ch.ferme:
        s_end = max(0.0, min(L, s_end))
    zones = [(a + dl, b + dl) for a, b in _zones_cales(ch)]
    plan = _plan_cales(L, ch.ferme, s0, s_end, q, zones, _demi_epaisseur(srcs), float(cal['jeu']))
    if plan is None or len(plan['portions']) != int(cal['np']):
        _log('cales resync : %s troncon(s) au lieu de %s, reseau laisse tel quel' % (
            None if plan is None else len(plan['portions']), cal['np']))
        return None
    return {'plan': plan, 'dl': dl, 's0': s0}


def _resync_reseau_calc(feat, reglages):
    _pivot_courant['v'] = bool(reglages.get('pivot'))
    _cote_inv['v'] = bool(reglages.get('cote_inv'))
    path = feat.path
    ents, ch = _chemin_de_path(path, reglages)
    L = ch.longueur
    # inputEntities exige de reculer la chronologie : on garde les jetons.
    design = adsk.fusion.Design.cast(_app.activeProduct)
    deplace = False
    cp = None
    pcal = None
    if reglages.get('cales'):
        try:
            cp = _plan_cales_resync(design, reglages, ch, ents)
        except Exception:
            _log('cales resync plan erreur %s' % traceback.format_exc()[-400:])
        if cp is None:
            return False
        pcal = cp['plan']['portions'][int(reglages['cales']['i'])]
    if L > 0 and reglages.get('mode_debut'):
        try:
            tok_feat = feat.entityToken
            deplace = _replacer_copie(design, reglages, ch, ents, int(feat.quantity.value) + int(reglages.get('saut', 0)),
                                      saut_fixe=(pcal['u0'] if pcal else None))
            if deplace:
                # le deplacement recalcule la chronologie : l'ancienne reference est perimee
                feat = adsk.fusion.PathPatternFeature.cast(design.findEntityByToken(tok_feat)[0])
        except Exception:
            _log('replacer erreur %s' % traceback.format_exc()[-500:])
    objs = []
    for tok in reglages.get('objets', []):
        try:
            trouves = design.findEntityByToken(tok)
            if trouves:
                objs.append(trouves[0])
        except Exception:
            continue
    if not objs:
        return False
    inv = bool(reglages.get('inverser'))
    if L <= 0:
        return False
    mode = bool(reglages.get('mode_debut'))
    zero = _zero(bool(reglages.get('pivot'))) if mode else None
    if mode and reglages.get('dep') is not None and not ch.ferme:
        s0 = max(0.0, min(L, reglages['dep'] * L))       # meme point de depart qu'a la creation
    elif mode:
        # 1er corps cree au debut : meme calcul qu'a la creation (_maj_chemin /
        # _creer_natif) : abscisse du centre du corps cree + decalage de repere
        c = _centre_bbox(objs)
        if c is None:
            return False
        s0 = max(0.0, min(L, ch.abscisse_proche(c) + _decalage_pivot(
            ch, objs, reglages.get('repere', 'droite'), inv, zero)))
    else:
        s0, inv = _depart_objets(ch, objs, reglages.get('repere', 'centre'), inv)
    s_cible = _bout(ch, s0, inv, int(feat.quantity.value))
    if reglages.get('vsym') and mode:
        # symetrique : du corps de gauche (centre - E) au corps de droite (centre + E)
        srcs = []
        for t in reglages.get('sources', []):
            r = design.findEntityByToken(t)
            if r:
                srcs.append(r[0])
        e = _etendue_sym(ch, srcs or objs, int(feat.quantity.value))
        s0, s_cible, inv = L / 2.0 - e, L / 2.0 + e, False
    dl = _decalage_pivot(ch, objs, reglages.get('repere', 'centre'), inv, zero)
    if dl:
        s0 -= dl
        s_cible = max(0.0, min(L, s_cible - dl))
    if pcal is not None:
        # troncon entre deux cales : bornes et nombre de corps d'apres la repartition recalculee
        s0 = pcal['s_deb'] - cp['dl']
        s_cible = pcal['s_fin'] - cp['dl']
        if not ch.ferme:
            s0 = max(0.0, min(L, s0))
            s_cible = max(0.0, min(L, s_cible))
        if int(feat.quantity.value) != int(pcal['n']):
            feat.quantity.expression = str(int(pcal['n']))
            deplace = True
        _log('cales resync troncon %s : n=%d s0=%.3f -> %.3f' % (reglages['cales']['i'], pcal['n'], s0, s_cible))
    depart, dist, flip = _params_fusion(path, ch, s0, s_cible)
    dp = feat.distance
    if ch.ferme:
        # Boucle : Fusion glisse l'objet depuis sa position, seule la distance
        # compte. Il renvoie startPoint = position de l'objet (pas le 0 donne
        # a la creation) et le reecrire decalait les copies hors du chemin
        # (essai du 2026-10-13) : on ne touche qu'a la distance.
        if abs(dp.value - dist) < 1e-5:
            return deplace
        dp.expression = '%.6f mm' % (dist * 10.0)
        _log('resync %s (boucle) L=%.3f s0=%.3f -> dist=%.3f' % (feat.name, L, s0, dist))
        return True
    orient = reglages.get('orientation')
    orient_voulue = bool(orient) if orient is not None else bool(feat.isOrientationAlongPath)
    orient_ok = orient is None or feat.isOrientationAlongPath == bool(orient)
    if abs(feat.startPoint - depart) < 1e-7 and abs(dp.value - dist) < 1e-5 and feat.isFlipDirection == flip \
            and orient_ok:
        return deplace
    # startPoint et le sens ne se modifient que chronologie reculee juste
    # avant la fonction (sinon "Didn't roll editing feature back").
    dp.expression = '%.6f mm' % (dist * 10.0)
    if abs(feat.startPoint - depart) >= 1e-7 or feat.isFlipDirection != flip or not orient_ok:
        tl = design.timeline
        grp = _deplier_groupe(design, feat)
        try:
            feat.timelineObject.rollTo(True)
            try:
                feat.startPoint = depart
                feat.isFlipDirection = flip
            except RuntimeError:
                # Fusion refuse certaines combinaisons point de depart / sens a l'ecriture : on passe par le milieu
                feat.startPoint = 0.5
                feat.isFlipDirection = flip
                feat.startPoint = depart
            # ecrire startPoint remet l'orientation sur le chemin a « identique »
            # (mesure du 2026-10-19) : on la rétablit toujours juste apres
            feat.isOrientationAlongPath = orient_voulue
        finally:
            tl.moveToEnd()
            _replier_groupe(grp)
    _log('resync %s L=%.3f s0=%.3f -> depart=%.5f dist=%.3f' % (feat.name, L, s0, depart, dist))
    return True


def _sig_reseau(ch, design, reglages):
    """Empreinte du chemin et des corps dont depend le reseau. Tant qu'elle ne
    change pas, rien a recaler : feat.startPoint relu ne vaut plus rien apres une
    ecriture chronologie reculee (il revient a 1.0), la comparer au calcul
    relancait un recalage complet (~2 s par reseau) apres CHAQUE commande."""
    L = ch.longueur
    sig = [round(L, 4), len(ch.segs)]
    for f in (0.0, 0.25, 0.5, 0.75, 1.0):
        p = ch.point_tangente(L * f)[0]
        sig += [round(p.x, 4), round(p.y, 4), round(p.z, 4)]
    for cle in ('objets', 'sources'):
        objs = []
        for tok in (reglages.get(cle) or []):
            try:
                r = design.findEntityByToken(tok)
                if r:
                    objs.append(r[0])
            except Exception:
                pass
        c = _centre_bbox(objs) if objs else None
        sig += [round(c.x, 4), round(c.y, 4), round(c.z, 4)] if c is not None else [0, 0, 0]
    if reglages.get('cales'):
        # les cales font partie des donnees : une cale deplacee ou ajoutee doit relancer le recalage
        try:
            for a, b in _zones_cales(ch):
                sig += [round(a, 3), round(b, 3)]
        except Exception:
            pass
    return sig


_migr_echec = set()
_MIGRER_BOUCLES = True


def _migrer_chemin(feat):
    """Reseau dont le chemin est fait d'aretes de plaque (cree sans l'option, ou avant elle) et que
    une jonction CNC a coupees depuis : on remonte avant la fonction, on ancre le chemin entier dans une
    esquisse « Chemin du reseau » (la plaque est encore entiere a cet endroit de la chronologie) et on
    y rebranche le reseau. Renvoie la fonction (relue) ; inchangee s'il n'y a rien a faire."""
    try:
        if not _jonc['on'] or feat.entityToken in _migr_echec:
            return feat, False
        path = feat.path
        ents = [path.item(i).entity for i in range(path.count)]
        edges = [adsk.fusion.BRepEdge.cast(e) for e in ents]
        if not edges or any(e is None for e in edges):
            return feat, False
        S, ponts = _jonc_etendre(edges)
        # empreinte du chemin (nombre d'aretes, longueur) enregistree sur la fonction : si elle change, le chemin
        # a ete coupe (une jonction fait perdre des aretes a la fonction, sans trou a franchir)
        sig_now = [len(edges), round(sum(e.length for e in edges), 3)]
        a_sig = feat.attributes.itemByName(ATTR_GROUPE, 'chemin_sig')
        change = False
        toks_orig = None
        if a_sig is not None:
            try:
                v = json.loads(a_sig.value)
                change = (v[0] != sig_now[0]) or abs(v[1] - sig_now[1]) > 0.02
                if change and len(v) > 2:
                    toks_orig = v[2]
            except Exception:
                change = False
        else:
            try:
                feat.attributes.add(ATTR_GROUPE, 'chemin_sig', json.dumps(sig_now + [[e.entityToken for e in edges]]))
            except Exception:
                pass
            # reseau d'avant ce suivi : la longueur du chemin notee a la creation dit si une jonction l'a coupe
            try:
                a_ed = feat.attributes.itemByName(ATTR_GROUPE, ATTR_EDIT)
                L_ed = float(json.loads(a_ed.value).get('L', 0.0)) if a_ed is not None else 0.0
                if L_ed > 0 and abs(L_ed - sig_now[1]) > max(0.05, 0.001 * L_ed):
                    change = True
            except Exception:
                pass
        if not ponts and not change:
            return feat, False
        design = adsk.fusion.Design.cast(_app.activeProduct)
        tok = feat.entityToken
        toks = toks_orig or [e.entityToken for e in edges]
        tl = design.timeline
        grp = _deplier_groupe(design, feat)
        ok = False
        try:
            feat.timelineObject.rollTo(True)
            comp = feat.parentComponent
            edges0 = []
            # le chemin tel que la fonction le voyait a sa creation : relu chronologie reculee (les aretes
            # d'une plaque coupee depuis n'ont plus les memes identifiants)
            try:
                pr = feat.path
                edges0 = [adsk.fusion.BRepEdge.cast(pr.item(i).entity) for i in range(pr.count)]
                if not edges0 or any(e is None for e in edges0):
                    edges0 = []
            except Exception:
                edges0 = []
            if not edges0:
                for t in toks:
                    r = design.findEntityByToken(t)
                    e0 = adsk.fusion.BRepEdge.cast(r[0]) if r else None
                    if e0 is None:
                        raise ValueError('arete introuvable avant la fonction')
                    edges0.append(e0)
            _log('migrer : chemin d\'origine %d arete(s), L=%.3f' % (len(edges0), sum(e.length for e in edges0)))
            ch_old = _Chemin(edges0)
            if ch_old.ferme and not _MIGRER_BOUCLES:
                # boucle : le rebranchement n'est pas verifie, on ne touche pas au reseau
                _migr_echec.add(tok)
                raise ValueError('chemin en boucle : rebranchement non fait')
            # position actuelle du reseau, en abscisses de NOTRE chemin (independantes du sens de Fusion)
            carte = None
            if ch_old.ferme and ch_old.longueur > 0:
                # boucle : Fusion fait glisser le corps depuis sa position, seuls comptent le sens et la distance
                off_o, sgn_o = _sens_fusion(feat.path, ch_old)
                dist0 = feat.distance.value
                carte = (0.0, sgn_o * (-dist0 if feat.isFlipDirection else dist0))
                # point de la boucle ou Fusion place le debut du reseau, en abscisses de notre chemin
                s_pt = (off_o + sgn_o * feat.startPoint * ch_old.longueur) % ch_old.longueur
            elif ch_old.longueur > 0:
                L0 = ch_old.longueur
                off_o, sgn_o = _sens_fusion(feat.path, ch_old)
                sf0 = feat.startPoint * L0
                dist0 = feat.distance.value
                sc_f = (L0 - dist0) if feat.isFlipDirection else dist0
                s0 = off_o + sgn_o * sf0
                carte = (s0, s0 + sgn_o * (sc_f - sf0))
            nouv = _chemin_sans_jonction(design, comp, edges0)
            if nouv is not edges0 and nouv != edges0:
                cc = adsk.core.ObjectCollection.create()
                for c in nouv:
                    cc.add(c)
                pnew = comp.features.createPath(cc, False)
                if ch_old.ferme and carte is not None:
                    # boucle : meme sens de parcours que l'ancien chemin, sinon le reseau partirait dans l'autre sens
                    sgn_old = _sens_fusion(feat.path, ch_old)[1]
                    if _sens_fusion(pnew, ch_old)[1] != sgn_old:
                        cc2 = adsk.core.ObjectCollection.create()
                        for c in list(nouv)[::-1]:
                            cc2.add(c)
                        pnew2 = comp.features.createPath(cc2, False)
                        if _sens_fusion(pnew2, ch_old)[1] == sgn_old:
                            pnew = pnew2
                        else:
                            raise ValueError('sens de la boucle non reproductible')
                    carte = None
                orient = bool(feat.isOrientationAlongPath)
                sp_old = feat.startPoint
                feat.path = pnew
                ok = True
                if ch_old.ferme:
                    # le debut du reseau est repositionne au meme point de la boucle (l'origine du nouveau chemin differe)
                    # (Fusion releve sur une boucle la position du corps : on ecrit 0, comme a la creation)
                    sp_new = (sp_old - feat.startPoint) % 1.0
                    _log('migrer boucle : startPoint avant %.5f, relu %.5f -> ecrit %.5f' % (sp_old, feat.startPoint, sp_new))
                    feat.startPoint = sp_new
                feat.isOrientationAlongPath = orient
                if carte is not None:
                    depart, dist2, flip2 = _params_fusion(pnew, ch_old, carte[0], carte[1])
                    _log('migrer carte s0=%.4f s_cible=%.4f ; avant start=%.5f dist=%.4f flip=%s ; apres start=%.5f dist=%.4f flip=%s L=%.4f' % (
                        carte[0], carte[1], feat.startPoint, feat.distance.value, feat.isFlipDirection, depart, dist2, flip2, ch_old.longueur))
                    if abs(feat.distance.value - dist2) > 1e-6:
                        feat.distance.expression = '%.6f mm' % (dist2 * 10.0)
                    if ch_old.ferme:
                        if feat.isFlipDirection != flip2:
                            try:
                                feat.startPoint = depart
                                feat.isFlipDirection = flip2
                            except RuntimeError:
                                feat.startPoint = 0.5
                                feat.isFlipDirection = flip2
                                feat.startPoint = depart
                    elif abs(feat.startPoint - depart) > 1e-7 or feat.isFlipDirection != flip2:
                        try:
                            feat.startPoint = depart
                            feat.isFlipDirection = flip2
                        except RuntimeError:
                            feat.startPoint = 0.5
                            feat.isFlipDirection = flip2
                            feat.startPoint = depart
                    # ecrire startPoint remet l'orientation sur le chemin a « identique » : on la retablit
                    feat.isOrientationAlongPath = orient
        finally:
            tl.moveToEnd()
            _replier_groupe(grp)
        _log('migrer chemin %s : %s' % (tok, 'fait' if ok else 'rien'))
        r = design.findEntityByToken(tok)
        feat2 = adsk.fusion.PathPatternFeature.cast(r[0]) if r else feat
        if ok:
            try:
                pe = [feat2.path.item(i).entity for i in range(feat2.path.count)]
                nv = json.dumps([len(pe), round(sum(e.length for e in pe), 3)])
                a2 = feat2.attributes.itemByName(ATTR_GROUPE, 'chemin_sig')
                if a2 is not None:
                    a2.value = nv
                else:
                    feat2.attributes.add(ATTR_GROUPE, 'chemin_sig', nv)
            except Exception:
                pass
        return feat2, ok
    except Exception:
        _log('migrer chemin erreur %s' % traceback.format_exc()[-500:])
        try:
            _migr_echec.add(feat.entityToken)
        except Exception:
            pass
        try:
            adsk.fusion.Design.cast(_app.activeProduct).timeline.moveToEnd()
        except Exception:
            pass
        return feat, False


def _resync_reseau(feat, reglages):
    design = adsk.fusion.Design.cast(_app.activeProduct)
    tok = feat.entityToken
    feat, migre = _migrer_chemin(feat)
    n_av = feat.path.count
    feat = _reparer_path(feat, reglages)
    if feat.path.count != n_av:
        migre = True
    path = feat.path
    ents, ch = _chemin_de_path(path, reglages)
    sig = _sig_reseau(ch, design, reglages)
    if reglages.get('sig') == sig and not migre:
        return False
    _cote_force['v'] = reglages.get('cote') or None
    try:
        res = _resync_reseau_calc(feat, reglages)
    finally:
        _cote_force['v'] = None
    try:
        if _recaler_bords(design, tok, _chemin_de_path(adsk.fusion.PathPatternFeature.cast(
                design.findEntityByToken(tok)[0]).path, reglages)[1]):
            res = True
    except Exception:
        _log('bords recalage erreur %s' % traceback.format_exc()[-400:])
    try:
        # le recalage a pu bouger les corps : empreinte recalculee apres
        feat = adsk.fusion.PathPatternFeature.cast(design.findEntityByToken(tok)[0])
        ch = _chemin_de_path(feat.path, reglages)[1]
        reglages['sig'] = _sig_reseau(ch, design, reglages)
        a = feat.attributes.itemByName(ATTR_GROUPE, ATTR_FIN)
        if a is not None:
            a.value = json.dumps(reglages)
    except Exception:
        _log('enregistrement empreinte erreur %s' % traceback.format_exc()[-300:])
    return res


def _migrer_reseaux_sans_attribut(design, deja):
    """Reseaux de ce module (groupe « Reseau CNC » de la chronologie) qui n'ont pas d'attribut de recalage :
    leur chemin d'aretes de plaque est protege lui aussi contre une jonction creee apres eux."""
    if not _jonc['on']:
        return
    try:
        tl = design.timeline
        toks = []
        for i in range(tl.count):
            it = tl.item(i)
            ent = it.entity
            if ent is None or not ent.objectType.endswith('PathPatternFeature'):
                continue
            g = it.parentGroup
            if not ((g is not None and g.name == GROUPE_NOM) or it.name == GROUPE_NOM):
                continue
            if ent.entityToken in deja:
                continue
            toks.append(ent.entityToken)
        for t in toks:
            r = design.findEntityByToken(t)
            f = adsk.fusion.PathPatternFeature.cast(r[0]) if r else None
            if f is not None and f.isValid and not f.isSuppressed:
                _migrer_chemin(f)
    except Exception:
        _log('migrer sans attribut erreur %s' % traceback.format_exc()[-400:])


def _resync_tous():
    if _resync_en_cours['v']:
        return
    design = adsk.fusion.Design.cast(_app.activeProduct)
    if design is None:
        return
    try:
        tl = design.timeline
        if tl.markerPosition < tl.count:
            return   # chronologie en arriere : on recalera en revenant a la fin
    except Exception:
        pass
    _resync_en_cours['v'] = True
    fait = False
    try:
        # un recalage recalcule la chronologie et perime les references des
        # autres reseaux : on garde les jetons et on relit chaque fonction
        a_faire = []
        for attr in design.findAttributes(ATTR_GROUPE, ATTR_FIN):
            try:
                a_faire.append((attr.parent.entityToken, attr.value or '{}'))
            except Exception:
                pass
        _migrer_reseaux_sans_attribut(design, {t for t, _v in a_faire})
        for tok, val in a_faire:
            try:
                trouves = design.findEntityByToken(tok)
                feat = adsk.fusion.PathPatternFeature.cast(trouves[0]) if trouves else None
                if feat is None or not feat.isValid or feat.isSuppressed:
                    continue
                if _resync_reseau(feat, json.loads(val)):
                    fait = True
            except Exception:
                _log('resync erreur %s' % traceback.format_exc()[-500:])
    finally:
        _resync_en_cours['v'] = False
    return fait


# Un recalage est une etape d'annulation a part : Ctrl+Z annulait d'abord
# le recalage (le reseau bougeait) et pas la cote modifiee (retours du
# 2026-10-13). On enchaine donc nous-memes le 2e Annuler (et le 2e Retablir)
# pour que la modification et son recalage s'annulent ensemble.
_pile = {'etat': None}
ACTION_ID = 'ReseauTrajectoireCNC_action'
_action = {'evt': None, 'h': None}


def _annuler_ensemble(cid):
    e = _pile['etat']
    _log('%s (etat %s)' % (cid, e))
    if cid == 'UndoCommand':
        if e == 'recale':
            _pile['etat'] = 'annul_auto'
            _differer('UndoCommand')
        elif e == 'annul_auto':
            _pile['etat'] = 'a_retablir'
        else:
            _pile['etat'] = None
    else:
        if e == 'a_retablir':
            _pile['etat'] = 'retab_auto'
            _differer('RedoCommand')
        elif e == 'retab_auto':
            _pile['etat'] = 'recale'
        else:
            _pile['etat'] = None


_focus_chemin = {'inputs': None}


class _ActionHandler(adsk.core.CustomEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            if args.additionalInfo == '@focus_chemin':
                ins = _focus_chemin['inputs']
                _focus_chemin['inputs'] = None
                if ins is not None:
                    ins.itemById('chemin').hasFocus = True
                return
            if args.additionalInfo == '@nc_palette':
                _nc_palette_evt()
                return
            if args.additionalInfo == '@nc_secouer':
                _nc_secouer()
                return
            if args.additionalInfo == '@nc_traverse':
                # bibliotheque commune : la boite Reseau se ferme, la fenetre de Traverse sur corps s'ouvre
                tok = _nc_etat.pop('traverse_mod', None)
                try:
                    if _ui.activeCommand == CMD_ID:
                        _ui.terminateActiveCommand()
                except Exception:
                    pass
                T = _module_addin('TraverseCorpsCNC')
                if tok and T is not None:
                    T.modifier_piece_externe(tok)
                return
            if args.additionalInfo == '@nc_fin':
                _nc_fin_evt()
                return
            d = _ui.commandDefinitions.itemById(args.additionalInfo)
            if d is not None:
                d.execute()
        except Exception:
            _log('action erreur %s' % traceback.format_exc()[-400:])


def _differer(cmd_id):
    try:
        if _action['evt'] is None:
            try:
                _app.unregisterCustomEvent(ACTION_ID)
            except Exception:
                pass
            _action['evt'] = _app.registerCustomEvent(ACTION_ID)
            _action['h'] = _ActionHandler()
            _action['evt'].add(_action['h'])
        _app.fireCustomEvent(ACTION_ID, cmd_id)
    except Exception:
        _log('differer erreur %s' % traceback.format_exc()[-400:])


# ActivateEnvironmentCommand se termine juste apres chaque Annuler : il
# relancait le recalage, que l'Annuler suivant defaisait... a l'infini
# (journal du 2026-10-13, reseau qui fait 0, 1, 0, 1).
CMDS_IGNOREES = ('UndoCommand', 'RedoCommand', 'SelectCommand', 'CommitCommand',
                 'ActivateEnvironmentCommand')


# Commandes d'affichage ou de navigation : elles ne modifient pas la geometrie
CMDS_VUE = ('Document', 'Launcher', 'Save', 'Orbit', 'Pan', 'Zoom', 'Fit', 'LookAt', 'View', 'Camera', 'Navigat', 'AutoSave',
            'ExpandGroup', 'CollapseGroup', 'Visibility', 'LightBulb', 'Inspect', 'Measure')


class _CommandTerminatedHandler(adsk.core.ApplicationCommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            # Annuler / Retablir : surtout ne pas recaler, sinon Ctrl+Z annule
            # le recalage et on le refait aussitot (boucle, retours du
            # 2026-10-13). Seules les commandes menees a terme comptent.
            import time
            cid = args.commandId or ''
            if cid == 'UndoCommand' or cid == 'RedoCommand':
                _pile['t'] = time.perf_counter()
                _annuler_ensemble(cid)
                return
            if time.perf_counter() - _pile.get('t', -10.0) < 2.0:
                return   # commande annexe d'un Annuler / Retablir
            if cid == CMD_ID or cid == NC_CMD_ID or cid in CMDS_IGNOREES or 'Undo' in cid or 'Redo' in cid:
                return
            if any(m in cid for m in CMDS_VUE):
                return   # tourner / deplacer la camera ne change pas le modele : pas de recalage (gel de ~5 s)
            if args.terminationReason != adsk.core.CommandTerminationReason.CompletedTerminationReason:
                return
            _pile['etat'] = None
            if _resync_tous():
                _pile['etat'] = 'recale'
                _log('recale apres %s' % cid)
        except Exception:
            _log('commandTerminated erreur %s' % traceback.format_exc()[-500:])


# Retour a la fin de la chronologie : deplacer le marqueur n'est pas une
# commande, donc rien ne recalait le reseau apres avoir modifie le chemin en
# arriere dans la chronologie (projet ottoman, 2026-10-13). Un minuteur
# regarde chaque seconde si le marqueur vient de revenir a la fin.
TICK_ID = 'ReseauTrajectoireCNC_tick'
_tick = {'evt': None, 'h': None, 'stop': None, 'fin': {}}


class _TickHandler(adsk.core.CustomEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            if _ov_orphelins and _ui.activeCommand != CMD_ID:
                _ov_purger()
            if _pending_fin['v'] > 0 and _ui.activeCommand != CMD_ID:
                _pending_fin['v'] -= 1
                if _pending_fin['v'] == 0:
                    t_ = adsk.fusion.Design.cast(_app.activeProduct).timeline
                    if t_.markerPosition < t_.count:
                        t_.moveToEnd()
                        _log('modification echouee : chronologie remise a la fin')
        except Exception:
            _pending_fin['v'] = 0
        try:
            pg = _pending_groupe['v']
            if pg is not None and _ui.activeCommand != CMD_ID:
                _pending_groupe['essais'] += 1
                if _grouper_par_jetons(pg[0], pg[1]):
                    _pending_groupe['v'] = None
                elif _pending_groupe['essais'] >= 20:
                    _pending_groupe['v'] = None
                    _log('groupement differe abandonne apres 20 essais')
                    _ui.messageBox("Le groupe « Réseau CNC » n'a pas pu être recréé dans la chronologie : les fonctions du "
                                   "réseau sont à plat (le réseau lui-même est correct). Sélectionne-les dans la chronologie "
                                   "puis clic droit > Créer un groupe.", 'Réseau CNC')
        except Exception:
            _pending_groupe['v'] = None
            _log('groupement differe erreur %s' % traceback.format_exc()[-300:])
        try:
            if _tip['g'] is not None:
                import time
                if time.perf_counter() - _souris.get('t', 0.0) > 2.5:
                    _tip_effacer()         # la souris ne bouge plus (ou a quitte la vue) : la bulle disparait
            design = adsk.fusion.Design.cast(_app.activeProduct)
            if design is None or _ui.activeCommand != 'SelectCommand':
                return
            tl = design.timeline
            cle = _app.activeDocument.name if _app.activeDocument else ''
            a_la_fin = tl.markerPosition >= tl.count
            avant = _tick['fin'].get(cle, True)
            _tick['fin'][cle] = a_la_fin
            if a_la_fin and not avant:
                _pile['etat'] = None
                if _resync_tous():
                    _log('recale au retour en fin de chronologie')
        except Exception:
            pass


def _demarrer_tick():
    import threading
    try:
        _tick['evt'] = _app.registerCustomEvent(TICK_ID)
        h = _TickHandler()
        _tick['evt'].add(h)
        _tick['h'] = h
        stop_evt = threading.Event()
        _tick['stop'] = stop_evt

        def boucle():
            while not stop_evt.wait(1.0):
                try:
                    _app.fireCustomEvent(TICK_ID, '')
                except Exception:
                    pass
        threading.Thread(target=boucle, daemon=True).start()
    except Exception:
        _log('tick erreur %s' % traceback.format_exc()[-400:])


def _arreter_tick():
    try:
        if _tick['stop'] is not None:
            _tick['stop'].set()
        if _tick['evt'] is not None and _tick['h'] is not None:
            _tick['evt'].remove(_tick['h'])
        _app.unregisterCustomEvent(TICK_ID)
    except Exception:
        pass
    _tick.update({'evt': None, 'h': None, 'stop': None})


def _dans_bbox(objs, pt, marge=0.2):
    for o in objs:
        try:
            bb = o.boundingBox
        except Exception:
            continue
        if all(getattr(bb.minPoint, a) - marge <= getattr(pt, a) <= getattr(bb.maxPoint, a) + marge
               for a in ('x', 'y', 'z')):
            return True
    return False


def _depart_objets(ch, objs, k, inv=None):
    """(abscisse de depart, sens inverse) pour des objets et un repere.
    Chemin qui touche l'objet (arete du corps, esquisse posee dessus) : on
    part du point du chemin le plus proche. Chemin a distance (esquisse a
    cote du corps) : le point le plus proche peut tomber n'importe ou au
    milieu et les copies partaient dans le mauvais sens (retours du
    2026-10-13) ; on part alors du bout du chemin le plus proche de l'objet,
    vers l'autre bout, comme le Reseau natif."""
    c = _centre_bbox(objs)
    L = ch.longueur
    if c is None or L <= 0:
        return 0.0, bool(inv)
    s0 = ch.abscisse_proche(c)
    colle = ch.ferme or _dans_bbox(objs, ch.point_tangente(s0)[0])
    if not colle:
        s0 = 0.0 if c.distanceTo(ch.debut) <= c.distanceTo(ch.fin) else L
    if inv is None:
        inv = s0 > L - s0
    r = _repere_objets(objs, k, ch, s0, inv)
    if r is not None and r is not c:
        if colle:
            sf = _s_face(ch, objs, k, s0, inv)
            s0 = sf if sf is not None else ch.abscisse_proche(r)
        else:
            # decalage de la face le long du chemin, depuis le bout
            _p, tg = ch.point_tangente(s0)
            s0 = max(0.0, min(L, s0 + _vec(c, r).dotProduct(tg)))
    return s0, inv


_cache_pivot = {}


_cle_cache = {}


def _cle_objets(objs):
    """Cle des objets (jeton + boite). La boite coute ~0.5 ms par corps et
    cette cle est demandee a chaque mouvement de la fleche : mise en cache par
    jetons (la geometrie ne change pas pendant la commande ; cache vide a
    chaque ouverture de la fenetre)."""
    try:
        jetons = tuple(o.entityToken for o in objs)
    except Exception:
        jetons = None
    if jetons is not None and jetons in _cle_cache:
        return _cle_cache[jetons]
    res = _cle_objets_calcul(objs)
    if jetons is not None:
        if len(_cle_cache) > 50:
            _cle_cache.clear()
        _cle_cache[jetons] = res
    return res


def _cle_objets_calcul(objs):
    cle = []
    for o in objs:
        try:
            bb = o.boundingBox
            cle.append((o.entityToken, round(bb.minPoint.x, 4), round(bb.minPoint.y, 4), round(bb.minPoint.z, 4),
                        round(bb.maxPoint.x, 4), round(bb.maxPoint.y, 4), round(bb.maxPoint.z, 4)))
        except Exception:
            cle.append(id(o))
    return tuple(cle)


def _decalage_pivot(ch, objs, k, inv, decal=None):
    """Mis en cache : ne depend ni de la distance ni de la quantite, et il
    coutait ~45 ms a chaque mouvement de la fleche (saccades du 2026-10-16).
    decal : translation deja prevue des objets (1er corps cree au debut)."""
    dk = None if decal is None else (round(decal.x, 5), round(decal.y, 5), round(decal.z, 5),
                                     tuple(round(v, 5) for v in decal.m.asArray()) if getattr(decal, 'm', None) else None)
    cle = (round(ch.longueur, 5), len(ch.segs), k, bool(inv), _cle_objets(objs), dk,
           bool(getattr(decal, 'pivot', False)))
    if cle not in _cache_pivot:
        if len(_cache_pivot) > 50:
            _cache_pivot.clear()
        _cache_pivot[cle] = _decalage_pivot_calcul(ch, objs, k, inv, decal)
    return _cache_pivot[cle]


def _decalage_pivot_calcul(ch, objs, k, inv, decal=None):
    """Chemin ouvert : ecart (en abscisse) entre la face de repere et le centre
    de l'objet. Fusion fait tourner chaque copie autour du CENTRE de l'objet et
    ne fait que la translater du deplacement du point de depart : ancrer le
    depart sur la face laissait donc le centre derriere le chemin, et plus le
    chemin tournait, plus les copies s'en ecartaient (essai du 2026-10-16 :
    ecart 2.00 -> 2.26 sur un quart de cercle, face de droite). On ancre donc
    le depart sur le centre et on retranche cet ecart a la cible."""
    try:
        if ch.ferme or k == 'centre':
            return 0.0
        c = _centre_bbox(objs)
        if c is None:
            return 0.0
        if decal is not None:
            c = adsk.core.Point3D.create(c.x + decal.x, c.y + decal.y, c.z + decal.z)
        sc = ch.abscisse_proche(c)
        p, tg = ch.point_tangente(sc)
        if decal is None and not _dans_bbox(objs, p):
            return 0.0
        sf = _s_face(ch, objs, k, sc, inv, decal)
        if sf is None:
            return 0.0
        # meme definition que l'abscisse de depart de _depart_objets (corps
        # penche par rapport au chemin : le produit scalaire avec la tangente
        # donnait un autre ecart et les copies se desaxaient quand meme)
        return sf - sc
    except Exception:
        return 0.0


# --- 1er corps cree au debut du chemin ---------------------------------------

def _points_objets(objs):
    pts = []
    for o in objs:
        try:
            if isinstance(o, adsk.fusion.BRepBody):
                for v in o.vertices:
                    pts.append(v.geometry)
                continue
        except Exception:
            pass
        try:
            bb = o.boundingBox
            for x in (bb.minPoint.x, bb.maxPoint.x):
                for y in (bb.minPoint.y, bb.maxPoint.y):
                    for z in (bb.minPoint.z, bb.maxPoint.z):
                        pts.append(adsk.core.Point3D.create(x, y, z))
        except Exception:
            continue
    return pts


class _Zero(object):
    """Pas de deplacement (copie deja en place) ; pivot : la copie est tournee,
    ses faces de repere sont celles qui regardent le chemin."""
    x = y = z = 0.0
    m = None

    def __init__(self, pivot=False):
        self.pivot = bool(pivot)


def _zero(pivot=False):
    return _Zero(pivot)


class _Dec(object):
    """Deplacement du 1er corps en mode 'creer au debut' : x, y, z = deplacement
    du centre, m = transformation complete (rotation + translation)."""

    def __init__(self, v, m):
        self.x, self.y, self.z, self.m = v.x, v.y, v.z, m


def _appliquer(dec, pt):
    """Point deplace : par la transformation complete, ou la simple translation."""
    if dec is None:
        return pt
    m = getattr(dec, 'm', None)
    if m is not None:
        q = pt.copy()
        q.transformBy(m)
        return q
    return adsk.core.Point3D.create(pt.x + dec.x, pt.y + dec.y, pt.z + dec.z)


def _tourner(dec, vec):
    """Vecteur tourne par la transformation (translation ignoree)."""
    m = getattr(dec, 'm', None) if dec is not None else None
    if m is None:
        return vec
    q = vec.copy()
    q.transformBy(m)
    return q


def _axe_chant(corps, fa, a, autres):
    """Normale (unitaire, perpendiculaire a a) du chant a mettre vers le chemin.
    Un panneau a tenons : les chants qui portent les tenons (le corps depasse
    de la grande face dans cet axe) vont selon n, tenons a la verticale ; sinon
    le chant le plus large. On mesure sur la grande face (les tenons ne la
    gonflent pas) : avec leurs faces en plus, le plus grand chant etait faux."""
    V3 = adsk.core.Vector3D.create
    v1 = max(autres, key=lambda f: f.area).geometry.normal.copy()
    k = v1.dotProduct(a)
    v1 = V3(v1.x - k * a.x, v1.y - k * a.y, v1.z - k * a.z)
    v1.normalize()
    try:
        v2 = a.crossProduct(v1)
        v2.normalize()

        def etendue(pts, u):
            d = [p.x * u.x + p.y * u.y + p.z * u.z for p in pts]
            return max(d) - min(d)

        fv = [fa.vertices.item(i).geometry for i in range(fa.vertices.count)]
        bv = [corps.vertices.item(i).geometry for i in range(corps.vertices.count)]
        pr1 = etendue(bv, v1) - etendue(fv, v1)
        pr2 = etendue(bv, v2) - etendue(fv, v2)
        tol = 0.01
        if pr1 > tol and pr2 <= tol:
            return v1
        if pr2 > tol and pr1 <= tol:
            return v2
        # tenons dans l'epaisseur du panneau (meme face que la grande face) :
        # les chants decoupes en plusieurs faces portent les tenons ; sur
        # l'axe des tenons les faces les plus exterieures sont les bouts des
        # tenons, plus etroites que celles de l'autre axe
        def faces_axe(u):
            fs = [f for f in autres if abs(f.geometry.normal.dotProduct(u)) > 0.95]
            ds = [(f.centroid.x * u.x + f.centroid.y * u.y + f.centroid.z * u.z, f.area) for f in fs]
            return fs, ds

        f1, d1 = faces_axe(v1)
        f2, d2 = faces_axe(v2)
        if len(f1) > 2 or len(f2) > 2:
            def aire_ext(ds):
                lo = min(d for d, _ in ds)
                hi = max(d for d, _ in ds)
                return sum(ar for d, ar in ds if abs(d - lo) < 1e-3 or abs(d - hi) < 1e-3)

            a1, a2 = aire_ext(d1), aire_ext(d2)
            if abs(a1 - a2) > 1e-3:
                return v1 if a1 < a2 else v2
        # pas de tenons (ou des deux cotes) : chant le plus large = celui dont
        # la normale est selon la plus courte dimension de la grande face
        return v1 if etendue(fv, v1) <= etendue(fv, v2) else v2
    except Exception:
        return v1


def _nc_contact(corps):
    """Arete de contact d'une piece de la bibliotheque (Maxence 2026-11-14), en coordonnees du composant :
    {'u': sens de la longueur, 'haut': sens de la hauteur, 'avant': normale sortante de la face avant}. L'arete
    de contact est l'arete du bas de la face avant (face posee sur le plan d'esquisse, a l'origine)."""
    bb = corps.boundingBox
    cy = (bb.minPoint.y + bb.maxPoint.y) / 2.0
    return {'u': [1.0, 0.0, 0.0], 'haut': [0.0, 0.0, 1.0], 'avant': [0.0, -1.0 if cy >= 0.0 else 1.0, 0.0]}


def _contact_objet(objs):
    """(U, Haut, Avant) en coordonnees monde pour une piece de la bibliotheque (Reseau CNC ou Traverse sur
    corps) choisie comme objet, sinon None : l'arete du bas de sa face avant est celle qui touche le chemin."""
    try:
        corps = [o for o in objs if isinstance(o, adsk.fusion.BRepBody)]
        if len(corps) != 1:
            return None
        b = corps[0]
        nat = b.nativeObject or b
        ct = None
        a = nat.attributes.itemByName(ATTR_GROUPE, ATTR_CORPS)
        if a is not None:
            ct = json.loads(a.value).get('contact') or _nc_contact(nat)
        else:
            a = nat.attributes.itemByName(TC_G, TC_PIECE)
            if a is None:
                return None
            d = json.loads(a.value)
            ct = d.get('contact')
            if not ct:
                T = _module_addin('TraverseCorpsCNC')
                ct = T._contact_piece(nat, d) if T is not None and hasattr(T, '_contact_piece') else None
        if not ct:
            return None
        x0 = ct.get('x0')
        if x0 is None:
            x0 = 0.0
            if a.groupName == TC_G:
                # debut de l'arete du bas le long de la longueur (un bout en arc ou en conge la fait commencer plus loin)
                bas = [float(p[0]) for p in (d.get('prof') or []) if abs(float(p[1])) < 1e-4]
                x0 = min(bas) if bas else 0.0
        M = b.assemblyContext.transform2 if b.assemblyContext is not None else None
        res = []
        for k in ('u', 'haut', 'avant'):
            v = adsk.core.Vector3D.create(*ct[k])
            if M is not None:
                v.transformBy(M)
            v.normalize()
            res.append(v)
        # point de depart de l'arete de contact (origine du composant + x0 le long de la longueur), en monde
        o = adsk.core.Point3D.create(0, 0, 0)
        if M is not None:
            o.transformBy(M)
        res.append(adsk.core.Point3D.create(o.x + res[0].x * x0, o.y + res[0].y * x0, o.z + res[0].z * x0))
        return tuple(res)
    except Exception:
        _log('contact objet erreur %s' % traceback.format_exc()[-300:])
        return None


def _rotation_contact(ct, te, n, pivot, lat_c, cote):
    """Rotation d'une piece de la bibliotheque : le bas (haut -> n) sur le plan du chemin ;
    pivote : face avant SUR le chemin, la piece du cote de la matiere (avant -> -cote x lat), longueur le long ;
    sinon : longueur vers la matiere depuis le chemin (u -> cote x lat), face avant vers l'arriere du chemin."""
    U, Hb, Av = ct[0], ct[1], ct[2]
    s = -1.0 if (cote or 1) < 0 else 1.0
    lat = adsk.core.Vector3D.create(lat_c.x * s, lat_c.y * s, lat_c.z * s)
    lat.normalize()
    hand_b = U.crossProduct(Hb).dotProduct(Av)
    if pivot:
        av_t = adsk.core.Vector3D.create(-lat.x, -lat.y, -lat.z)
        u_t = te.copy()
        if u_t.crossProduct(n).dotProduct(av_t) * hand_b < 0:
            u_t.scaleBy(-1)
    else:
        u_t = lat
        av_t = adsk.core.Vector3D.create(-te.x, -te.y, -te.z)
        if u_t.crossProduct(n).dotProduct(av_t) * hand_b < 0:
            av_t.scaleBy(-1)
    R = [[0.0] * 3 for _ in range(3)]
    for r in range(3):
        for c in range(3):
            R[r][c] = sum((t.x, t.y, t.z)[r] * (b.x, b.y, b.z)[c] for t, b in zip((u_t, n, av_t), (U, Hb, Av)))
    return R


def _rotation_debut(objs, te, n, pivot=False, lat_c=None, cote=None):
    """Rotation (liste 3x3 par lignes) qui met le corps comme les corps du
    reseau d'origine : la grande face du panneau perpendiculaire au chemin
    (normale = sens de marche te) et le chant le plus large vers le chemin,
    c'est-a-dire sa normale selon n (normale du plan du chemin). None si le
    corps n'est pas un panneau reconnaissable. Piece de la bibliotheque : son
    arete de contact enregistree decide (voir _rotation_contact)."""
    corps = [o for o in objs if isinstance(o, adsk.fusion.BRepBody)]
    if len(corps) != 1:
        return None
    ct = _contact_objet(objs)
    if ct is not None:
        if lat_c is None:
            lat_c = n.crossProduct(te)
        return _rotation_contact(ct, te, n, pivot, lat_c, cote)
    planes = []
    for i in range(corps[0].faces.count):
        f = corps[0].faces.item(i)
        try:
            if isinstance(f.geometry, adsk.core.Plane):
                planes.append(f)
        except Exception:
            continue
    if len(planes) < 3:
        return None
    fa = max(planes, key=lambda f: f.area)
    a = fa.geometry.normal.copy()
    a.normalize()
    autres = [f for f in planes if abs(f.geometry.normal.dotProduct(a)) < 0.05]
    if not autres:
        return None
    v = _axe_chant(corps[0], fa, a, autres)
    if a.dotProduct(te) < 0:
        a.scaleBy(-1)
    if v.dotProduct(n) < 0:
        v.scaleBy(-1)
    w = a.crossProduct(v)
    tw = te.crossProduct(n)
    cols_b = (a, v, w)
    cols_t = (te, n, tw)
    if pivot:
        # face contre le chemin : la grande face regarde le chemin (normale
        # laterale), le panneau court le long du chemin (rotation de 90 degres
        # autour de la normale du plan du chemin)
        cols_t = (n.crossProduct(te), n, te)
    R = [[0.0] * 3 for _ in range(3)]
    for r in range(3):
        for c in range(3):
            R[r][c] = sum(
                (t.x, t.y, t.z)[r] * (b.x, b.y, b.z)[c] for t, b in zip(cols_t, cols_b))
    return R


def _corps_candidats(ents, objs):
    """Corps qui portent le chemin : celui de l'arete choisie, sinon (esquisse)
    tous les corps du dessin sauf les objets choisis."""
    res = []
    for e in ents:
        try:
            if isinstance(e, adsk.fusion.BRepEdge):
                res.append(e.body)
        except Exception:
            continue
    if res:
        return res
    try:
        excl = set()
        for o in objs:
            try:
                excl.add(o.entityToken)
            except Exception:
                pass
        root = adsk.fusion.Design.cast(_app.activeProduct).rootComponent
        for b in list(root.bRepBodies) + [b for occ in root.allOccurrences for b in occ.bRepBodies]:
            if b.entityToken not in excl:
                res.append(b)
    except Exception:
        pass
    return res


def _cote_concave(ch, n):
    """+1 / -1 : cote (selon lat = n x tangente) vers lequel le chemin tourne (interieur de la courbe) ;
    0 si le chemin est droit."""
    try:
        L = ch.longueur
        tot = 0.0
        for fr in (0.2, 0.35, 0.5, 0.65, 0.8):
            P, tg = ch.point_tangente(L * fr)
            lat = n.crossProduct(adsk.core.Vector3D.create(tg.x, tg.y, tg.z))
            if lat.length < 1e-9:
                continue
            lat.normalize()
            w = min(L * 0.1, L * fr, L * (1.0 - fr))
            a = ch.point_tangente(L * fr - w)[0]
            b = ch.point_tangente(L * fr + w)[0]
            mid = adsk.core.Point3D.create((a.x + b.x) / 2.0, (a.y + b.y) / 2.0, (a.z + b.z) / 2.0)
            tot += _vec(P, mid).dotProduct(lat)
        if abs(tot) < 1e-4:
            return 0
        return 1 if tot > 0 else -1
    except Exception:
        return 0


def _cote_matiere(ents, ch, n, objs=()):
    """+1 / -1 : cote (selon lat = n x tangente) du chemin ou se trouve la
    matiere de la piece qui porte le chemin ; 0 si inconnu."""
    corps = _corps_candidats(ents, objs)
    if not corps:
        return 0
    # plusieurs points du chemin (pas le sommet de depart) et plusieurs
    # distances (une esquisse peut etre un peu a cote du bord de la piece)
    for fr in (0.5, 0.3, 0.7, 0.15, 0.85):
        P, tg = ch.point_tangente(ch.longueur * fr)
        lat = n.crossProduct(adsk.core.Vector3D.create(tg.x, tg.y, tg.z))
        if lat.length < 1e-9:
            continue
        lat.normalize()
        for eps in (0.05, 0.2, 0.5):
            res = []
            for sg in (1, -1):
                dedans = False
                for b in corps:
                    try:
                        for kn in (1, -1):
                            q = adsk.core.Point3D.create(
                                P.x + sg * lat.x * eps + kn * n.x * 0.05, P.y + sg * lat.y * eps + kn * n.y * 0.05,
                                P.z + sg * lat.z * eps + kn * n.z * 0.05)
                            if b.pointContainment(q) == adsk.fusion.PointContainment.PointInsidePointContainment:
                                dedans = True
                    except Exception:
                        continue
                res.append(dedans)
            if res[0] != res[1]:
                return 1 if res[0] else -1
    return 0


def _hauteur_tenon(objs, R, c, n):
    """Hauteur des tenons du cote du chemin (-n) pour le corps tourne par R
    autour de c : decalage entre le bout des tenons et le chant du panneau.
    0 sans tenon. Les tenons doivent finir dans la matiere du chemin."""
    try:
        corps = [o for o in objs if isinstance(o, adsk.fusion.BRepBody)]
        if len(corps) != 1:
            return 0.0
        groupes = {}
        for f in corps[0].faces:
            if not isinstance(f.geometry, adsk.core.Plane):
                continue
            g = f.geometry.normal
            nr = (R[0][0] * g.x + R[0][1] * g.y + R[0][2] * g.z, R[1][0] * g.x + R[1][1] * g.y + R[1][2] * g.z,
                  R[2][0] * g.x + R[2][1] * g.y + R[2][2] * g.z)
            if abs(nr[0] * n.x + nr[1] * n.y + nr[2] * n.z) < 0.95:
                continue
            ce = f.centroid
            d = (R[0][0] * (ce.x - c.x) + R[0][1] * (ce.y - c.y) + R[0][2] * (ce.z - c.z)) * n.x + \
                (R[1][0] * (ce.x - c.x) + R[1][1] * (ce.y - c.y) + R[1][2] * (ce.z - c.z)) * n.y + \
                (R[2][0] * (ce.x - c.x) + R[2][1] * (ce.y - c.y) + R[2][2] * (ce.z - c.z)) * n.z
            k = round(d, 3)
            groupes[k] = groupes.get(k, 0.0) + f.area
        if len(groupes) < 3:
            return 0.0
        ds = sorted(groupes)
        mid = (ds[0] + ds[-1]) / 2.0
        bas = [d for d in ds if d < mid]
        if len(bas) < 2:
            return 0.0
        coeur = max(bas, key=lambda d: groupes[d])
        return max(0.0, coeur - bas[0])
    except Exception:
        return 0.0


def _face_principale(objs):
    """Grande face plane du corps unique (les tenons ne la gonflent pas), ou None."""
    try:
        corps = [o for o in objs if isinstance(o, adsk.fusion.BRepBody)]
        if len(corps) != 1:
            return None
        pl = []
        for i in range(corps[0].faces.count):
            f = corps[0].faces.item(i)
            if isinstance(f.geometry, adsk.core.Plane):
                pl.append(f)
        return max(pl, key=lambda f: f.area) if pl else None
    except Exception:
        return None


def _demi_long(objs):
    """Demi-longueur le long du chemin du corps pivote (sur sa grande face, tenons exclus), 0 si inconnue."""
    try:
        fa = _face_principale(objs)
        if fa is None:
            return 0.0
        V3 = adsk.core.Vector3D.create
        R = _rotation_debut(objs, V3(1, 0, 0), V3(0, 0, 1), True)
        if R is None:
            return 0.0
        xs = []
        for i in range(fa.vertices.count):
            g = fa.vertices.item(i).geometry
            xs.append(R[0][0] * g.x + R[0][1] * g.y + R[0][2] * g.z)
        return (max(xs) - min(xs)) / 2.0 if xs else 0.0
    except Exception:
        return 0.0


def _arc_corde(ch, h, fin):
    """Abscisse (depuis le bout) du centre d'un corps de demi-longueur h dont une extremite est pile au
    bout du chemin et l'autre sur le chemin (corde 2 h) ; h sur un chemin droit."""
    try:
        L = ch.longueur
        if h <= 1e-9 or L <= 0.0:
            return max(0.0, h)
        P0 = ch.point_tangente(L if fin else 0.0)[0]

        def f(x):
            s = L - 2.0 * x if fin else 2.0 * x
            return P0.distanceTo(ch.point_tangente(max(0.0, min(L, s)))[0]) - 2.0 * h

        lo, hi = h, L / 2.0
        if hi <= lo or f(hi) < 0.0:
            return hi
        for _ in range(50):
            m = (lo + hi) / 2.0
            if f(m) < 0.0:
                lo = m
            else:
                hi = m
        return (lo + hi) / 2.0
    except Exception:
        return h


def _affiner_bouts(ch, objs, dec, c, n, te):
    """Ajuste la pose du 1er corps (decalage lateral + petite rotation autour de la
    normale n) pour que ses DEUX bouts gauche / droite soient exactement sur le
    chemin (distance mesuree dans le plan du chemin). Retourne le nouveau _Dec,
    ou dec si l'ajustement echoue."""
    import math
    try:
        brut = _points_objets(objs)
        if len(brut) < 4:
            return dec
        m0 = list(dec.m.asArray())
        fa = _face_principale(objs)
        brut_f = [fa.vertices.item(i).geometry for i in range(fa.vertices.count)] if fa is not None else brut

        def poser(M, p):
            return (M[0] * p.x + M[1] * p.y + M[2] * p.z + M[3], M[4] * p.x + M[5] * p.y + M[6] * p.z + M[7],
                    M[8] * p.x + M[9] * p.y + M[10] * p.z + M[11])

        pts = [poser(m0, p) for p in brut]
        pts_f = [poser(m0, p) for p in brut_f]
        te_u = (te.x, te.y, te.z)
        nl = math.sqrt(sum(v * v for v in te_u))
        te_u = tuple(v / nl for v in te_u)
        proj = [sum(a * b for a, b in zip(q, te_u)) for q in pts_f]
        pmin, pmax = min(proj), max(proj)

        def cote(q):     # (distance signee au chemin dans le plan, vecteur lateral)
            P = adsk.core.Point3D.create(q[0], q[1], q[2])
            sa = ch.abscisse_proche(P)
            Q, tg = ch.point_tangente(sa)
            lc = n.crossProduct(adsk.core.Vector3D.create(tg.x, tg.y, tg.z))
            lc.normalize()
            return (P.x - Q.x) * lc.x + (P.y - Q.y) * lc.y + (P.z - Q.z) * lc.z

        def extreme(cible):
            cand = [q for q, d in zip(pts_f, proj) if abs(d - cible) < 2e-3]
            return min(cand, key=lambda q: abs(cote(q))) if cand else None

        a, b = extreme(pmin), extreme(pmax)
        if a is None or b is None:
            return dec
        nn = (n.x, n.y, n.z)
        c0 = [sum(q[i] for q in pts) / len(pts) for i in range(3)]
        # lateral au centre : meme repere que celui du suivi du chemin
        sc = ch.abscisse_proche(adsk.core.Point3D.create(*c0))
        tgc = ch.point_tangente(sc)[1]
        lc0 = n.crossProduct(adsk.core.Vector3D.create(tgc.x, tgc.y, tgc.z))
        lc0.normalize()
        lc0 = (lc0.x, lc0.y, lc0.z)
        pc = tuple((min(q[i] for q in pts) + max(q[i] for q in pts)) / 2.0 for i in range(3))

        def rot_pt(q, th, dl):
            k = nn
            d = (q[0] - pc[0], q[1] - pc[1], q[2] - pc[2])
            kd = k[0] * d[0] + k[1] * d[1] + k[2] * d[2]
            kx = (k[1] * d[2] - k[2] * d[1], k[2] * d[0] - k[0] * d[2], k[0] * d[1] - k[1] * d[0])
            ct, st = math.cos(th), math.sin(th)
            return tuple(pc[i] + d[i] * ct + kx[i] * st + k[i] * kd * (1.0 - ct) + lc0[i] * dl for i in range(3))

        def F(dl, th):
            return cote(rot_pt(a, th, dl)), cote(rot_pt(b, th, dl))

        dl, th, eps = 0.0, 0.0, 1e-5
        for _ in range(8):
            ra, rb = F(dl, th)
            if max(abs(ra), abs(rb)) < 1e-7:
                break
            a1, b1 = F(dl + eps, th)
            a2, b2 = F(dl, th + eps)
            j = [[(a1 - ra) / eps, (a2 - ra) / eps], [(b1 - rb) / eps, (b2 - rb) / eps]]
            det = j[0][0] * j[1][1] - j[0][1] * j[1][0]
            if abs(det) < 1e-12:
                return dec
            ddl = -(j[1][1] * ra - j[0][1] * rb) / det
            dth = -(-j[1][0] * ra + j[0][0] * rb) / det
            dl += ddl
            th += dth
        ra, rb = F(dl, th)
        _log('bouts sur chemin : residus apres = %.6f %.6f (dl=%.5f th=%.6f)' % (ra, rb, dl, th))
        if max(abs(ra), abs(rb)) > 1e-3 or abs(th) > 0.2:
            return dec
        # nouvelle matrice = Translation(dl lc0) * Rotation(n, th ; pc) * m0
        ct, st = math.cos(th), math.sin(th)
        k = nn
        R3 = [[ct + k[0] * k[0] * (1 - ct), k[0] * k[1] * (1 - ct) - k[2] * st, k[0] * k[2] * (1 - ct) + k[1] * st],
              [k[1] * k[0] * (1 - ct) + k[2] * st, ct + k[1] * k[1] * (1 - ct), k[1] * k[2] * (1 - ct) - k[0] * st],
              [k[2] * k[0] * (1 - ct) - k[1] * st, k[2] * k[1] * (1 - ct) + k[0] * st, ct + k[2] * k[2] * (1 - ct)]]
        t3 = [pc[i] - sum(R3[i][j2] * pc[j2] for j2 in range(3)) + lc0[i] * dl for i in range(3)]
        Mn = [0.0] * 16
        for i in range(3):
            for j2 in range(3):
                Mn[4 * i + j2] = sum(R3[i][x] * m0[4 * x + j2] for x in range(3))
            Mn[4 * i + 3] = sum(R3[i][x] * m0[4 * x + 3] for x in range(3)) + t3[i]
        Mn[15] = 1.0
        mm = adsk.core.Matrix3D.create()
        mm.setWithArray(Mn)
        nouv = [poser(Mn, p) for p in brut]
        cn = [(min(q[i] for q in nouv) + max(q[i] for q in nouv)) / 2.0 for i in range(3)]
        T = adsk.core.Vector3D.create(cn[0] - c.x, cn[1] - c.y, cn[2] - c.z)
        res = _Dec(T, mm)
        res.pivot = dec.pivot
        return res
    except Exception:
        _log('bouts sur chemin erreur %s' % traceback.format_exc()[-300:])
        return dec


def _fleche_corde(ch, sc, h, lat):
    """Fleche (signee selon lat) de la corde de demi-longueur h centree sur
    l'abscisse sc : decalage a donner au centre d'un corps long le long du
    chemin vers le cote concave pour que ses deux bouts (gauche / droite)
    touchent le chemin au lieu de son centre. 0 sur un chemin droit."""
    try:
        if h <= 1e-6:
            return 0.0
        L = ch.longueur

        def deux(a):
            return (ch.point_tangente(max(0.0, min(L, sc - a)))[0],
                    ch.point_tangente(max(0.0, min(L, sc + a)))[0])

        lo, hi = h, 3.0 * h
        for _ in range(40):
            m = (lo + hi) / 2.0
            p1, p2 = deux(m)
            if p1.distanceTo(p2) < 2.0 * h:
                lo = m
            else:
                hi = m
        p1, p2 = deux((lo + hi) / 2.0)
        mid = adsk.core.Point3D.create((p1.x + p2.x) / 2.0, (p1.y + p2.y) / 2.0, (p1.z + p2.z) / 2.0)
        return _vec(ch.point_tangente(sc)[0], mid).dotProduct(lat)
    except Exception:
        return 0.0



# --- Bords gauche / droite de CHAQUE copie exactement sur le chemin ----------
# Le reseau natif pose chaque copie rigidement sur le repere du chemin : sur une
# courbe dont la courbure varie, les deux bords d'une copie ne touchent pas le
# chemin. Chaque copie est donc reposee a part (rotation autour de la normale du
# plan du chemin + translation dans ce plan) : ses deux bords contre le chemin,
# le milieu de ses bords garde son abscisse. Apercu : meme calcul en flottants
# (table du chemin) ; creation : une fonction Deplacer par copie, dans le groupe.

BORDS_TOL = 0.3          # cm : un bord a moins de ca du bout du chemin y est ancre
ATTR_BORDS = 'bords'


def _v3(a):
    return (a.x, a.y, a.z)


def _pl(v, n):
    k = v[0] * n[0] + v[1] * n[1] + v[2] * n[2]
    return (v[0] - k * n[0], v[1] - k * n[1], v[2] - k * n[2])


def _cr(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def _dt(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def _mat_pt(M, p):
    return (M[0] * p[0] + M[1] * p[1] + M[2] * p[2] + M[3], M[4] * p[0] + M[5] * p[1] + M[6] * p[2] + M[7],
            M[8] * p[0] + M[9] * p[1] + M[10] * p[2] + M[11])


def _mat_vec(M, v):
    return (M[0] * v[0] + M[1] * v[1] + M[2] * v[2], M[4] * v[0] + M[5] * v[1] + M[6] * v[2],
            M[8] * v[0] + M[9] * v[1] + M[10] * v[2])


def _mul4(A, B):
    R = [0.0] * 16
    for i in range(4):
        for j in range(4):
            R[4 * i + j] = A[4 * i] * B[j] + A[4 * i + 1] * B[4 + j] + A[4 * i + 2] * B[8 + j] + A[4 * i + 3] * B[12 + j]
    return R


def _fn_chemin(ch, nn, off, exact):
    """s -> (point decale de off dans le plan, tangente), en flottants."""
    if exact:
        def P(s):
            p, d = ch.point_tangente(s)
            t = (d.x, d.y, d.z)
            if off:
                la = _cr(nn, t)
                return (p.x + off * la[0], p.y + off * la[1], p.z + off * la[2]), t
            return (p.x, p.y, p.z), t
    else:
        def P(s):
            p, t = ch.fast(s)
            if off:
                la = _cr(nn, t)
                return (p[0] + off * la[0], p[1] + off * la[1], p[2] + off * la[2]), t
            return p, t
    return P


def _proj_abs(P, L, ferme, p, s_g, w, nn, n=12):
    """Abscisse du point du chemin le plus proche de p (distance dans le plan), cherchee dans s_g +- w."""
    lo, hi = s_g - w, s_g + w
    if not ferme:
        lo, hi = max(0.0, lo), min(L, hi)
    if hi - lo < 1e-9:
        return lo

    def d2(s):
        q = P(s)[0]
        v = _pl((p[0] - q[0], p[1] - q[1], p[2] - q[2]), nn)
        return v[0] * v[0] + v[1] * v[1] + v[2] * v[2]

    pas = (hi - lo) / n
    k = min(range(n + 1), key=lambda i: d2(lo + i * pas))
    a, b = max(lo, lo + (k - 1) * pas), min(hi, lo + (k + 1) * pas)
    g = 0.6180339887498949
    x1, x2 = b - g * (b - a), a + g * (b - a)
    f1, f2 = d2(x1), d2(x2)
    for _ in range(40):
        if f1 < f2:
            b, x2, f2 = x2, x1, f1
            x1 = b - g * (b - a)
            f1 = d2(x1)
        else:
            a, x1, f1 = x1, x2, f2
            x2 = a + g * (b - a)
            f2 = d2(x2)
        if b - a < 1e-7:
            break
    return (a + b) / 2.0


def _corde(P, L, ferme, sa, sb, D, nn, tol=BORDS_TOL):
    """(u, v) : abscisses ou poser les deux bords (u < v), a la distance D l'un de l'autre dans le
    plan du chemin. Bord a moins de tol d'un bout (chemin ouvert) : ancre sur ce bout ; sinon le
    milieu des abscisses (sa + sb) / 2 est garde. None si impossible."""
    def dist(u, v):
        p, q = P(u)[0], P(v)[0]
        w = _pl((q[0] - p[0], q[1] - p[1], q[2] - p[2]), nn)
        return math.sqrt(w[0] * w[0] + w[1] * w[1] + w[2] * w[2])

    def bis(f, lo, hi):    # f croissante, f(lo) <= 0 <= f(hi)
        if f(lo) > 0.0 or f(hi) < 0.0:
            return None
        for _ in range(50):
            m = (lo + hi) / 2.0
            if f(m) < 0.0:
                lo = m
            else:
                hi = m
            if hi - lo < 1e-9:
                break
        return (lo + hi) / 2.0

    portee = 4.0 * D + 1.0
    debut = not ferme and sa <= tol
    fin = not ferme and sb >= L - tol
    if not debut and not fin:
        m = (sa + sb) / 2.0
        dmax = portee if ferme else min(portee, 2.0 * min(m, L - m))
        d = bis(lambda d: dist(m - d / 2.0, m + d / 2.0) - D, 0.0, dmax)
        if d is not None:
            return m - d / 2.0, m + d / 2.0
        if ferme:
            return None
        debut = m < L / 2.0
        fin = not debut
    if debut:
        v = bis(lambda v: dist(0.0, v) - D, 0.0, min(L, portee))
        return None if v is None else (0.0, v)
    u = bis(lambda u: D - dist(u, L), max(0.0, L - portee), L)
    return None if u is None else (u, L)


def _corr_mat(a, b, pu, pv, nn, lim=0.35):
    """Correction rigide (16 flottants) : rotation autour de nn + translation dans le plan,
    qui amene a sur pu et b sur pv (dans le plan du chemin). None si l'ecart d'angle est grand."""
    vc = _pl((b[0] - a[0], b[1] - a[1], b[2] - a[2]), nn)
    vn = _pl((pv[0] - pu[0], pv[1] - pu[1], pv[2] - pu[2]), nn)
    th = math.atan2(_dt(_cr(vc, vn), nn), _dt(vc, vn))
    if abs(th) > lim:
        return None
    ct, st = math.cos(th), math.sin(th)
    k = nn
    R = [[ct + k[0] * k[0] * (1 - ct), k[0] * k[1] * (1 - ct) - k[2] * st, k[0] * k[2] * (1 - ct) + k[1] * st],
         [k[1] * k[0] * (1 - ct) + k[2] * st, ct + k[1] * k[1] * (1 - ct), k[1] * k[2] * (1 - ct) - k[0] * st],
         [k[2] * k[0] * (1 - ct) - k[1] * st, k[2] * k[1] * (1 - ct) + k[0] * st, ct + k[2] * k[2] * (1 - ct)]]
    t = _pl((pu[0] - a[0], pu[1] - a[1], pu[2] - a[2]), nn)
    M = [0.0] * 16
    for i in range(3):
        M[4 * i] = R[i][0]
        M[4 * i + 1] = R[i][1]
        M[4 * i + 2] = R[i][2]
        M[4 * i + 3] = a[i] + t[i] - (R[i][0] * a[0] + R[i][1] * a[1] + R[i][2] * a[2])
    M[15] = 1.0
    return M


def _faces_corps(body, M=None):
    """Faces planes du corps : (normale, centroide, aire, sommets) en flottants, posees par M."""
    res = []
    for i in range(body.faces.count):
        f = body.faces.item(i)
        try:
            g = f.geometry
            if not isinstance(g, adsk.core.Plane):
                continue
            nm, c = _v3(g.normal), _v3(f.centroid)
            vs = [_v3(f.vertices.item(j).geometry) for j in range(f.vertices.count)]
        except Exception:
            continue
        if M is not None:
            nm, c = _mat_vec(M, nm), _mat_pt(M, c)
            vs = [_mat_pt(M, v) for v in vs]
        res.append((nm, c, f.area, vs))
    return res


def _bords_faces(faces, P, L, ferme, nn, s_g=None, ch=None, sgn=None):
    """(a, b, s_centre, sgn) : les deux sommets extremes (le long du chemin) de la face plane du corps
    qui regarde le chemin (tenons exclus : ils ne sont pas sur cette face). sgn : cote (selon n x t)
    vers lequel regarde cette face ; donne, il fixe la face (copies : meme face que le 1er corps,
    meme si le chemin traverse le corps). None si introuvable."""
    pts = [v for f in faces for v in f[3]]
    if len(pts) < 4:
        return None
    c = tuple(sum(p[i] for p in pts) / len(pts) for i in range(3))
    if s_g is None:
        sc = ch.abscisse_proche(adsk.core.Point3D.create(*c))
    else:
        etd = max(math.sqrt(_dt(_pl((p[0] - c[0], p[1] - c[1], p[2] - c[2]), nn),
                                _pl((p[0] - c[0], p[1] - c[1], p[2] - c[2]), nn))) for p in pts)
        sc = _proj_abs(P, L, ferme, c, s_g, etd + 2.0, nn)
    p0, t = P(sc)
    t = _pl(t, nn)
    lt = math.sqrt(_dt(t, t))
    if lt < 1e-9:
        return None
    t = (t[0] / lt, t[1] / lt, t[2] / lt)
    la = _cr(nn, t)
    cands = []
    for nm, cf, ar, vs in faces:
        if _dt(nm, (cf[0] - c[0], cf[1] - c[1], cf[2] - c[2])) < 0.0:
            nm = (-nm[0], -nm[1], -nm[2])       # normale vers l'exterieur du corps
        k = _dt(nm, la)
        if abs(k) < 0.7 or len(vs) < 2 or (sgn is not None and k * sgn < 0.0):
            continue
        d = abs(_dt((cf[0] - p0[0], cf[1] - p0[1], cf[2] - p0[2]), la))
        cands.append((d, ar, vs, 1 if k > 0 else -1))
    if not cands:
        return None
    dmin = min(x[0] for x in cands)
    best = max((x for x in cands if x[0] <= dmin + 0.05), key=lambda x: x[1])
    vs, sgn_f = best[2], best[3]
    xs = [_dt((v[0] - p0[0], v[1] - p0[1], v[2] - p0[2]), t) for v in vs]

    def choisir(cible):
        grp = [v for v, x in zip(vs, xs) if abs(x - cible) < 1e-3]
        return min(grp, key=lambda v: abs(_dt((v[0] - p0[0], v[1] - p0[1], v[2] - p0[2]), la)))

    a, b = choisir(min(xs)), choisir(max(xs))
    if math.sqrt(_dt(_pl((b[0] - a[0], b[1] - a[1], b[2] - a[2]), nn),
                     _pl((b[0] - a[0], b[1] - a[1], b[2] - a[2]), nn))) < 1e-4:
        return None
    return a, b, sc, sgn_f


def _correction_bords(P, L, ferme, a, b, s_g, nn):
    """Correction (16 flottants) qui pose les bords a et b sur le chemin, ou None."""
    D = math.sqrt(_dt(_pl((b[0] - a[0], b[1] - a[1], b[2] - a[2]), nn),
                      _pl((b[0] - a[0], b[1] - a[1], b[2] - a[2]), nn)))
    w = D / 2.0 + 0.2 * D + 1.0
    sa = _proj_abs(P, L, ferme, a, s_g, w, nn)
    sb = _proj_abs(P, L, ferme, b, s_g, w, nn)
    if sa > sb:
        a, b, sa, sb = b, a, sb, sa
    r = _corde(P, L, ferme, sa, sb, D, nn)
    if r is None:
        _logc('bords : corde impossible sa=%.3f sb=%.3f D=%.3f' % (sa, sb, D))
        return None
    C = _corr_mat(a, b, P(r[0])[0], P(r[1])[0], nn)
    if C is None:
        _logc('bords : rotation trop grande sa=%.3f sb=%.3f' % (sa, sb))
    return C


def _bords_dec(ch, objs, dec):
    """1er corps (mode « Copier le corps ») : ses deux bords exactement sur le chemin."""
    try:
        nn = getattr(dec, 'n_bords', None)
        corps = [o for o in objs if isinstance(o, adsk.fusion.BRepBody)]
        if nn is None or getattr(dec, 'm', None) is None or len(corps) != 1:
            return dec
        off = dec.off_bords
        M0 = list(dec.m.asArray())
        P = _fn_chemin(ch, nn, off, True)
        L = ch.longueur
        # face qui regarde le chemin : celle tournee vers lui (le corps est du cote « cote » du chemin).
        # Les deux grandes faces d'un panneau ont la meme aire : sans ce choix, le corps passait
        # parfois de l'autre cote du chemin (grande face du fond posee sur le chemin).
        cote = getattr(dec, 'cote_bords', 0) or 0
        bd = _bords_faces(_faces_corps(corps[0], M0), P, L, ch.ferme, nn, None, ch, -cote if cote else None)
        if bd is None:
            return dec
        C = _correction_bords(P, L, ch.ferme, bd[0], bd[1], bd[2], nn)
        if C is None:
            _log('bords 1er corps : pas de correction')
            return dec
        Mn = _mul4(C, M0)
        mm = adsk.core.Matrix3D.create()
        mm.setWithArray(Mn)
        c = _centre_bbox(objs)
        brut = [_v3(p) for p in _points_objets(objs)]
        nouv = [_mat_pt(Mn, p) for p in brut]
        cn = [(min(q[i] for q in nouv) + max(q[i] for q in nouv)) / 2.0 for i in range(3)]
        res = _Dec(adsk.core.Vector3D.create(cn[0] - c.x, cn[1] - c.y, cn[2] - c.z), mm)
        res.pivot = getattr(dec, 'pivot', False)
        res.n_bords, res.off_bords = nn, off
        res.cote_bords = getattr(dec, 'cote_bords', None)
        return res
    except Exception:
        _log('bords 1er corps erreur %s' % traceback.format_exc()[-300:])
        return dec


def _bords_apercu(ch, objs, T0):
    """(a0, b0, n, off) : bords du 1er corps pose (coordonnees du dessin orange), ou None."""
    try:
        nn = getattr(T0, 'n_bords', None)
        corps = [o for o in objs if isinstance(o, adsk.fusion.BRepBody)]
        if nn is None or getattr(T0, 'm', None) is None or len(corps) != 1:
            return None
        cle = ('bords_ap', round(ch.longueur, 5), len(ch.segs), _cle_objets(objs),
               tuple(round(v, 6) for v in T0.m.asArray()), nn, round(T0.off_bords, 6))
        if cle in _cache_pivot:
            return _cache_pivot[cle]
        P = _fn_chemin(ch, nn, T0.off_bords, True)
        L = ch.longueur
        # meme face que le 1er corps (cote de la matiere) : sans ce choix, une piece au bout non plan (arc,
        # conge) prenait la face de l'AUTRE bout et toutes les copies passaient dehors (Maxence 2026-11-14)
        cote = getattr(T0, 'cote_bords', 0) or 0
        bd = _bords_faces(_faces_corps(corps[0], list(T0.m.asArray())), P, L, ch.ferme, nn, None, ch,
                          -cote if cote else None)
        r = None
        if bd is not None:
            a, b = bd[0], bd[1]
            D = math.sqrt(_dt(_pl((b[0] - a[0], b[1] - a[1], b[2] - a[2]), nn),
                              _pl((b[0] - a[0], b[1] - a[1], b[2] - a[2]), nn)))
            w = D / 2.0 + 0.2 * D + 1.0
            sa = _proj_abs(P, L, ch.ferme, a, bd[2], w, nn, 40)
            sb = _proj_abs(P, L, ch.ferme, b, bd[2], w, nn, 40)
            if sa > sb:
                a, b, sa, sb = b, a, sb, sa
            r = {'a0': a, 'b0': b, 'nn': nn, 'off': T0.off_bords, 'm0': (sa + sb) / 2.0, 'D': D, 'sgn': bd[3]}
        _cache_pivot[cle] = r
        return r
    except Exception:
        _log('bords apercu erreur %s' % traceback.format_exc()[-300:])
        return None


def _bords_cible(ch, bd, P, ds):
    """(u, v) : abscisses des deux bords de la copie dont le milieu est a ds (le long du chemin)
    du milieu des bords du 1er corps ; ancree sur un bout du chemin si elle y arrive. None si impossible."""
    try:
        m = bd['m0'] + ds
        D = bd['D']
        return _corde(P, ch.longueur, ch.ferme, m - D / 2.0, m + D / 2.0, D, bd['nn'])
    except Exception:
        return None


def _bords_pose(bd, P, uv):
    """Pose (16 flottants, sur le 1er corps pose) d'une copie dont les bords sont en u et v."""
    return _corr_mat(bd['a0'], bd['b0'], P(uv[0])[0], P(uv[1])[0], bd['nn'], 3.2)


def _bords_corriger_corps(design, ch, nn, off, toks, sgn=None):
    """Corrections (16 flottants, espace du composant actif) pour les corps donnes par jetons."""
    occ = design.activeOccurrence
    Tm = Ti = None
    if occ is not None:
        Tm = list(occ.transform2.asArray())
        ti = occ.transform2.copy()
        ti.invert()
        Ti = list(ti.asArray())
    P = _fn_chemin(ch, nn, off, True)
    L = ch.longueur
    res = []
    for tok in toks:
        C = None
        try:
            r = design.findEntityByToken(tok)
            b = adsk.fusion.BRepBody.cast(r[0]) if r else None
            if b is not None:
                bd = _bords_faces(_faces_corps(b, Tm), P, L, ch.ferme, nn, None, ch, sgn)
                if bd is not None:
                    C = _correction_bords(P, L, ch.ferme, bd[0], bd[1], bd[2], nn)
                    if C is not None and Ti is not None:
                        C = _mul4(Ti, _mul4(C, Tm))
        except Exception:
            _log('bords copie erreur %s' % traceback.format_exc()[-300:])
        res.append(C)
    return res


def _identite(C, tol=1e-7):
    I = (1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)
    return max(abs(x - y) for x, y in zip(C, I)) < tol


def _bords_vers_cibles(design, ch, bd, toks, cibles):
    """Corrections (16 flottants, espace du composant actif) qui amenent chaque corps sur la pose de
    l'apercu (cibles : [(u, v)] abscisses des bords). Corps et cibles apparies dans l'ordre le long du
    chemin (meme nombre) ou, a defaut, a la plus proche. None pour un corps sans cible."""
    occ = design.activeOccurrence
    Tm = Ti = None
    if occ is not None:
        Tm = list(occ.transform2.asArray())
        ti = occ.transform2.copy()
        ti.invert()
        Ti = list(ti.asArray())
    nn = bd['nn']
    P = _fn_chemin(ch, nn, bd['off'], True)
    L = ch.longueur
    infos = []
    for tok in toks:
        info = None
        try:
            r = design.findEntityByToken(tok)
            b = adsk.fusion.BRepBody.cast(r[0]) if r else None
            if b is not None:
                x = _bords_faces(_faces_corps(b, Tm), P, L, ch.ferme, nn, None, ch, bd['sgn'])
                if x is not None:
                    a, bb = x[0], x[1]
                    w = bd['D'] / 2.0 + 0.2 * bd['D'] + 1.0
                    sa = _proj_abs(P, L, ch.ferme, a, x[2], w, nn, 40)
                    sb = _proj_abs(P, L, ch.ferme, bb, x[2], w, nn, 40)
                    if sa > sb:
                        a, bb, sa, sb = bb, a, sb, sa
                    info = (a, bb, (sa + sb) / 2.0)
        except Exception:
            _log('bords copie erreur %s' % traceback.format_exc()[-300:])
        infos.append(info)
    cib = [(c, (c[0] + c[1]) / 2.0) for c in cibles if c is not None]
    paires = {}
    ok = [k for k, i in enumerate(infos) if i is not None]
    if len(ok) == len(cib) and not ch.ferme:
        for k, c in zip(sorted(ok, key=lambda k: infos[k][2]), sorted(cib, key=lambda c: c[1])):
            paires[k] = c[0]
    else:
        libres = list(cib)
        for k in ok:
            if not libres:
                break
            j = min(range(len(libres)), key=lambda j: abs(libres[j][1] - infos[k][2]))
            paires[k] = libres.pop(j)[0]
    res = []
    for k, info in enumerate(infos):
        C = None
        if info is not None and k in paires:
            u, v = paires[k]
            C = _corr_mat(info[0], info[1], P(u)[0], P(v)[0], nn, 1.5)
            if C is not None and Ti is not None:
                C = _mul4(Ti, _mul4(C, Tm))
        res.append(C)
    return res


def _bords_copies(design, comp, feat, ch, dec, exclure, cx=None, d_in=None, graines=()):
    """Creation : une fonction Deplacer par copie du reseau, pour que les deux bords de chaque copie
    touchent exactement le chemin, a la place que montrait l'apercu (cx, d_in : son contexte).
    Renvoie le reseau (relu : les deplacements perime la reference)."""
    nn = getattr(dec, 'n_bords', None) if dec is not None else None
    if nn is None:
        return feat
    tok_feat = feat.entityToken
    toks = []
    for t in graines:
        toks.append((-1, t))
    for i in range(feat.bodies.count):
        t = feat.bodies.item(i).entityToken
        if t not in exclure:
            toks.append((i, t))
    vis = []
    for i, t in toks:
        try:
            r = design.findEntityByToken(t)
            if r and adsk.fusion.BRepBody.cast(r[0]).isLightBulbOn:
                vis.append((i, t))
        except Exception:
            pass
    toks = vis
    bd = cx.get('bords') if cx else None
    Cs = None
    if bd is not None:
        try:
            cibles = []
            _mats_orange(cx, d_in, cibles_out=cibles, exact=True)
            Cs = _bords_vers_cibles(design, cx['ch'], bd, [t for _i, t in toks], cibles)
            ch = cx['ch']
        except Exception:
            _log('bords cibles erreur %s' % traceback.format_exc()[-400:])
            Cs = None
    if Cs is None:
        Cs = _bords_corriger_corps(design, ch, nn, dec.off_bords, [t for _i, t in toks])
    moves = []
    for (i, t), C in zip(toks, Cs):
        if C is None or _identite(C):
            continue
        try:
            b = design.findEntityByToken(t)[0]
            coll = adsk.core.ObjectCollection.create()
            coll.add(b)
            mm = adsk.core.Matrix3D.create()
            mm.setWithArray(C)
            mi = comp.features.moveFeatures.createInput2(coll)
            mi.defineAsFreeMove(mm)
            mf = comp.features.moveFeatures.add(mi)
            mf.name = 'Bords sur chemin %d' % (i + 2)
            moves.append([mf.entityToken, i])
        except Exception:
            _log('bords deplacer copie %d erreur %s' % (i, traceback.format_exc()[-300:]))
    feat = adsk.fusion.PathPatternFeature.cast(design.findEntityByToken(tok_feat)[0])
    try:
        feat.attributes.add(ATTR_GROUPE, ATTR_BORDS, json.dumps({'n': list(nn), 'off': dec.off_bords, 'moves': moves,
                                                                  'sgn': bd['sgn'] if bd else None}))
    except Exception:
        _log('bords attribut erreur %s' % traceback.format_exc()[-300:])
    _log('bords : %d copie(s) reposee(s) sur %d' % (len(moves), len(toks)))
    return feat


def _recaler_bords(design, tok_feat, ch):
    """Le chemin ou le corps a change : chaque copie est reposee (transformation de sa fonction
    Deplacer recalculee). Renvoie True si quelque chose a change."""
    r = design.findEntityByToken(tok_feat)
    feat = adsk.fusion.PathPatternFeature.cast(r[0]) if r else None
    a = feat.attributes.itemByName(ATTR_GROUPE, ATTR_BORDS) if feat is not None else None
    if a is None:
        return False
    info = json.loads(a.value)
    nn, off = tuple(info['n']), float(info.get('off', 0.0))
    mfs = []
    for tok, i in info.get('moves', []):
        rr = design.findEntityByToken(tok)
        mf = adsk.fusion.MoveFeature.cast(rr[0]) if rr else None
        if mf is not None and mf.isValid and mf.bodies.count:
            mfs.append(mf)
    if not mfs:
        return False
    # correction du corps tel qu'il est (deja deplace) : nouvelle transformation = C x ancienne
    Cs = _bords_corriger_corps(design, ch, nn, off, [mf.bodies.item(0).entityToken for mf in mfs], info.get('sgn'))
    a_faire = [(mf.entityToken, _mul4(C, list(mf.transform.asArray())))
               for mf, C in zip(mfs, Cs) if C is not None and not _identite(C, 1e-6)]
    if not a_faire:
        return False
    tl = design.timeline
    grp = _deplier_groupe(design, mfs[0])
    try:
        for tok, M in a_faire:
            mf = adsk.fusion.MoveFeature.cast(design.findEntityByToken(tok)[0])
            mf.timelineObject.rollTo(True)
            mm = adsk.core.Matrix3D.create()
            mm.setWithArray(M)
            mf.transform = mm
    finally:
        tl.moveToEnd()
        _replier_groupe(grp)
    _log('bords recales : %d copie(s)' % len(a_faire))
    return True


def _placement_debut(ch, objs, inv, dlat, dhaut, ents=(), sym=False, ds=0.0, pivot=False, saut=0.0, haut=False):
    """Pivote : le corps long le long du chemin n'est pas centre pres du depart,
    et Fusion garde ensuite sa position par rapport a la tangente DU POINT DU
    CHEMIN LE PLUS PROCHE DE SON CENTRE : on l'oriente donc sur cette tangente
    (quelques passes, la rotation deplace un peu le centre), sinon les copies
    restent inclinees sur un chemin courbe."""
    cle = ('debutP', round(ch.longueur, 5), len(ch.segs), bool(inv), round(dlat, 6), round(dhaut, 6),
           _cle_objets(objs), tuple(getattr(e, 'entityToken', '') for e in ents), bool(sym), round(ds, 6),
           bool(pivot), round(saut, 6), bool(haut), bool(_cote_inv['v']), _cote_force['v'])
    if cle in _cache_pivot:
        return _cache_pivot[cle]
    dec = _placement_debut_calc(ch, objs, inv, dlat, dhaut, ents, sym, ds, pivot, None, saut, haut)
    if pivot and not sym:
        c = _centre_bbox(objs)
        for _ in range(3):
            tc = ch.point_tangente(ch.abscisse_proche(_appliquer(dec, c)))[1]
            dec = _placement_debut_calc(ch, objs, inv, dlat, dhaut, ents, sym, ds, pivot, tc, saut, haut)
    dec = _bords_dec(ch, objs, dec)
    _cache_pivot[cle] = dec
    return dec


def _placement_debut_calc(ch, objs, inv, dlat, dhaut, ents=(), sym=False, ds=0.0, pivot=False, t_rot=None, saut=0.0,
                          haut=False):
    """Deplacement (_Dec) qui amene l'objet au debut du chemin : tourne comme
    les corps d'un reseau (grande face perpendiculaire au chemin, chant vers le
    chemin), centre sur le chemin (plus decalages), pose sur le plan du chemin,
    sa face arriere (gauche) traversant le chemin au point de depart."""
    cle = ('debut', round(ch.longueur, 5), len(ch.segs), bool(inv), round(dlat, 6), round(dhaut, 6),
           _cle_objets(objs), tuple(getattr(e, 'entityToken', '') for e in ents), bool(sym), round(ds, 6),
           bool(pivot), None if t_rot is None else (round(t_rot.x, 4), round(t_rot.y, 4), round(t_rot.z, 4)),
           round(saut, 6), bool(haut), bool(_cote_inv['v']), _cote_force['v'])
    if cle in _cache_pivot:
        return _cache_pivot[cle]
    V3 = adsk.core.Vector3D.create
    L = ch.longueur
    c = _centre_bbox(objs)
    if sym:
        inv = False     # symetrique : le 1er corps est au milieu du chemin, sans sens
    s_dep = L / 2.0 + ds if sym else (L if inv else 0.0)
    if saut and not sym:
        # 1res copies masquees : le corps cree prend la place de la 1re copie gardee
        s_dep = max(0.0, min(L, s_dep - saut if inv else s_dep + saut))
    P, t = ch.point_tangente(s_dep)
    t = V3(t.x, t.y, t.z)
    t.normalize()
    te = V3(-t.x, -t.y, -t.z) if inv else V3(t.x, t.y, t.z)
    # normale du plan du chemin (3 points), sinon verticale
    a, m, b = ch.point_tangente(0.0)[0], ch.point_tangente(L / 3.0)[0], ch.point_tangente(2.0 * L / 3.0)[0]
    n = _vec(m, a).crossProduct(_vec(m, b))
    if n.length < 1e-6 * max(1.0, L * L):
        n = V3(0, 0, 1) if abs(t.z) < 0.9 else V3(0, 1, 0)
    k = n.dotProduct(t)
    n = V3(n.x - k * t.x, n.y - k * t.y, n.z - k * t.z)
    n.normalize()
    if abs(n.z) > 0.3:
        if n.z < 0:
            n.scaleBy(-1)       # plan couche : l'objet repose dessus
    else:
        # plan debout : l'objet reste du cote du plan ou il se trouve
        if c is not None:
            pn = ch.point_tangente(ch.abscisse_proche(c))[0]
            if _vec(pn, c).dotProduct(n) < 0:
                n.scaleBy(-1)
    if haut:
        # traverse suspendue : le corps est de l'autre cote du chemin, tenon du haut contre lui
        n.scaleBy(-1)
        dhaut = -dhaut
    lat = n.crossProduct(t)
    lat.normalize()
    te_r, n_r = te, n
    lat_m = lat     # lateral dans le repere de la tangente a laquelle le corps est oriente
    if t_rot is not None:
        te_r = V3(t_rot.x, t_rot.y, t_rot.z)
        te_r.normalize()
        if inv:
            te_r.scaleBy(-1)
        k2 = n.dotProduct(te_r)
        n_r = V3(n.x - k2 * te_r.x, n.y - k2 * te_r.y, n.z - k2 * te_r.z)
        n_r.normalize()
        lat_m = n_r.crossProduct(V3(t_rot.x, t_rot.y, t_rot.z))
        lat_m.normalize()
    # le chant du corps est CONTRE le chemin (pas centre dessus), du cote ou se
    # trouve la matiere (face du plan du chemin qui porte l'arete choisie) ; calcule avant la rotation :
    # une piece de la bibliotheque est tournee pour que sa face avant soit sur le chemin, cote matiere
    cote = _cote_matiere(ents, ch, n, objs)
    if pivot:
        # (cote deja = cote de la matiere de la piece qui porte le chemin : le corps est sur cette piece ;
        # a defaut, cote interieur de la courbe)
        if not cote:
            cc = _cote_concave(ch, n)
            if cc:
                cote = cc
        if _cote_inv['v']:
            cote = -(cote or 1)
    if _cote_force['v'] is not None:
        cote = int(_cote_force['v'])
    R = _rotation_debut(objs, te_r, n_r, pivot, lat_m, cote)
    if R is None:
        R = [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]]

    def rot(p):     # c + R (p - c)
        d = (p.x - c.x, p.y - c.y, p.z - c.z)
        return adsk.core.Point3D.create(
            c.x + R[0][0] * d[0] + R[0][1] * d[1] + R[0][2] * d[2],
            c.y + R[1][0] * d[0] + R[1][1] * d[1] + R[1][2] * d[2],
            c.z + R[2][0] * d[0] + R[2][1] * d[1] + R[2][2] * d[2])

    pr = [rot(p) for p in _points_objets(objs)]
    if not pr:
        pr = [c]
    cr = adsk.core.Point3D.create(
        (min(p.x for p in pr) + max(p.x for p in pr)) / 2, (min(p.y for p in pr) + max(p.y for p in pr)) / 2,
        (min(p.z for p in pr) + max(p.z for p in pr)) / 2)     # centre de boite du corps tourne
    lo = min(_vec(cr, p).dotProduct(n) for p in pr)
    lo += _hauteur_tenon(objs, R, c, n)     # tenons dans la matiere du chemin
    off = 0.0
    if cote:
        lats = [_vec(cr, p).dotProduct(lat_m) for p in pr]
        off = -min(lats) if cote > 0 else -max(lats)
        ct = _contact_objet(objs)
        if ct is not None and len(ct) > 3:
            # piece de la bibliotheque : le DEBUT de son arete de contact (bas de la face avant) sur le chemin,
            # pas le bout de la boite (un bout en arc ou en conge la mettait en retrait, Maxence 2026-11-14)
            off = -_vec(cr, rot(ct[3])).dotProduct(lat_m)
        dl_l = dlat * cote
    else:
        dl_l = dlat
    dl_l += off
    # bouts gauche / droite sur le chemin (et non le centre) : decalage de la fleche de la corde
    te_u = V3(te_r.x, te_r.y, te_r.z)
    te_u.normalize()
    h_corde = _demi_long(objs) if pivot else 0.0
    if h_corde <= 0.0:
        ds_p = [_vec(cr, p).dotProduct(te_u) for p in pr]
        h_corde = (max(ds_p) - min(ds_p)) / 2.0
    sc_corde = s_dep if sym else max(0.0, min(L, s_dep - h_corde if inv else s_dep + h_corde))
    dl_l += _fleche_corde(ch, sc_corde, h_corde, lat_m)
    _log('placement debut cote=%s off=%.3f dlat=%.3f dhaut=%.3f R=%s ents=%s' % (
        cote, off, dlat, dhaut, 'oui' if _rotation_debut(objs, te, n) else 'non', [type(e).__name__ for e in ents]))
    cible = adsk.core.Point3D.create(
        P.x + lat_m.x * dl_l + n.x * (dhaut - lo), P.y + lat_m.y * dl_l + n.y * (dhaut - lo),
        P.z + lat_m.z * dl_l + n.z * (dhaut - lo))
    T0 = _vec(c, cible)

    def matrice(tr):    # p' = R p + tr, avec tr = c + (cible - cr) - R c  (+ glissement)
        mm = adsk.core.Matrix3D.create()
        mm.setWithArray([R[0][0], R[0][1], R[0][2], tr[0], R[1][0], R[1][1], R[1][2], tr[1],
                         R[2][0], R[2][1], R[2][2], tr[2], 0, 0, 0, 1])
        return mm

    Rc = (R[0][0] * c.x + R[0][1] * c.y + R[0][2] * c.z, R[1][0] * c.x + R[1][1] * c.y + R[1][2] * c.z,
          R[2][0] * c.x + R[2][1] * c.y + R[2][2] * c.z)
    tr = [c.x + cible.x - cr.x - Rc[0], c.y + cible.y - cr.y - Rc[1], c.z + cible.z - cr.z - Rc[2]]
    tr_init = list(tr)
    dec = _Dec(T0, matrice(tr))
    dec.pivot = bool(pivot)
    # face de debut au point de depart (le long de la tangente)
    f = None if sym else _repere_face(objs, 'gauche', ch, s_dep, inv, dec)
    pl = adsk.core.Plane.cast(f.geometry) if f is not None else None
    if pl is not None:
        nf = _tourner(dec, pl.normal)
        den = t.dotProduct(nf)
        if abs(den) > 1e-6:
            fp = _appliquer(dec, f.centroid)
            delta = _vec(fp, P).dotProduct(nf) / den
            T0 = V3(T0.x + t.x * delta, T0.y + t.y * delta, T0.z + t.z * delta)
            tr = [tr[0] + t.x * delta, tr[1] + t.y * delta, tr[2] + t.z * delta]
            dec = _Dec(T0, matrice(tr))
            dec.pivot = bool(pivot)
    if pivot and t_rot is not None and not sym:
        # le glissement le long de la tangente de depart (ou la courbure du
        # chemin) a decale le centre de cote : on le remet a la distance voulue
        # du chemin, mesuree dans le repere du point le plus proche du centre
        for _ in range(3):
            # centre de boite du corps tourne, a sa place actuelle
            c2 = adsk.core.Point3D.create(cible.x + tr[0] - tr_init[0], cible.y + tr[1] - tr_init[1],
                                          cible.z + tr[2] - tr_init[2])
            pc, tg = ch.point_tangente(ch.abscisse_proche(c2))
            lc = n.crossProduct(V3(tg.x, tg.y, tg.z))
            if lc.length < 1e-9:
                break
            lc.normalize()
            dl_c = dl_l - _fleche_corde(ch, sc_corde, h_corde, lat_m) + _fleche_corde(
                ch, ch.abscisse_proche(c2), h_corde, lc)
            err = dl_c - _vec(pc, c2).dotProduct(lc)
            if abs(err) < 1e-4:
                break
            T0 = V3(T0.x + lc.x * err, T0.y + lc.y * err, T0.z + lc.z * err)
            tr = [tr[0] + lc.x * err, tr[1] + lc.y * err, tr[2] + lc.z * err]
            dec = _Dec(T0, matrice(tr))
            dec.pivot = bool(pivot)
        dec = _affiner_bouts(ch, objs, dec, c, n, te_r)
    elif pivot and sym:
        dec = _affiner_bouts(ch, objs, dec, c, n, te_r)
    # bords gauche / droite sur le chemin (voir _bords_dec) : normale du plan et decalage lateral voulu
    dec.cote_bords = int(cote or 0)
    dec.n_bords = (n.x, n.y, n.z) if cote else None      # corps centre sur le chemin : pas de bords contre lui
    if not pivot and _contact_objet(objs) is not None:
        # piece de la bibliotheque en travers : c'est son arete de contact qui est sur le chemin, pas une face
        # plane du bout (pente, arc ou conge : elle partait en retrait)
        dec.n_bords = None
    dec.off_bords = float(dlat * cote if cote else dlat)
    _cache_pivot[cle] = dec
    return dec


_demi_cache = {}


def _demi_epaisseur(objs):
    """Demi-epaisseur (entre les deux grandes faces) du panneau choisi, 0 si inconnue."""
    try:
        cle = tuple(o.entityToken for o in objs)
        if cle in _demi_cache:
            return _demi_cache[cle]
        r = _demi_epaisseur_calc(objs)
        if len(_demi_cache) > 30:
            _demi_cache.clear()
        _demi_cache[cle] = r
        return r
    except Exception:
        return _demi_epaisseur_calc(objs)


def _demi_epaisseur_calc(objs):
    try:
        corps = [o for o in objs if isinstance(o, adsk.fusion.BRepBody)]
        gf = _grandes_faces(corps[0]) if len(corps) == 1 else []
        if len(gf) == 2:
            n1 = gf[0].geometry.normal
            return abs(_vec(gf[0].centroid, gf[1].centroid).dotProduct(n1)) / 2.0
    except Exception:
        pass
    return 0.0


def _etendue_sym(ch, objs, q=2):
    """Symetrique + 1er corps : etendue d'un cote quand le chemin est
    entierement parcouru : les corps des deux extremites ont leur face
    exterieure pile aux deux bouts du chemin (chemin ferme : copies
    regulierement reparties sur le tour, pas = L / q)."""
    if ch.ferme:
        return ch.longueur * (q - 1) / (2.0 * q) if q > 1 else 0.0
    if _pivot_courant['v']:
        # corps pivote : il court le long du chemin, ses bouts gauche / droite (hors tenons) sont a
        # exactement un corde du bout du chemin
        h = _demi_long(objs)
        if h > 0.0:
            return max(0.0, ch.longueur / 2.0 - max(_arc_corde(ch, h, False), _arc_corde(ch, h, True)))
    return max(0.0, ch.longueur / 2.0 - _demi_epaisseur(objs))


def _decal_debut(inputs, ch, objs, ds=0.0, ents=None, saut=0.0):
    """Deplacement du 1er corps en mode 'creer au debut', sinon None."""
    _pivot(inputs)
    if not _mode_debut(inputs):
        return None
    sym = _sym_dir(inputs)
    inv = bool(inputs.itemById('inverser').value)
    return _placement_debut(ch, objs, inv, inputs.itemById('decal_lat').value,
                            inputs.itemById('decal_haut').value,
                            _ents_actifs(inputs) if ents is None else ents, sym, ds, _pivot(inputs), saut, _haut(inputs))


_dep_exact = {'dep': None, 's0': None, 'L': None}


def _s0_dialogue(inputs, L):
    """Abscisse de depart : la case Point de depart arrondit la valeur ecrite
    (le bout du chemin n'etait jamais atteint a 1e-3 pres, case « jusqu'au
    bout » decochee, aucun recalage enregistre) : on garde la valeur exacte
    tant que la case n'a pas ete modifiee a la main."""
    dep = max(0.0, min(1.0, inputs.itemById('depart').value))
    e = _dep_exact
    if e['s0'] is not None and abs(dep - e['dep']) < 6e-3 and abs(L - e['L']) < 1e-6:
        return e['s0']
    return dep * L


def _maj_chemin(inputs, recaler=False, distance=None):
    """Chemin ou objets modifies : le point de depart se cale sur le point du
    chemin le plus proche de l'objet (le reseau natif part du bout du chemin,
    et les copies se retrouvaient decalees hors du chemin), la distance
    prend la longueur restante, et la fleche se place sur la derniere copie,
    dans le sens du chemin a cet endroit."""
    global _dernier_chemin
    _ctx['ok'] = False
    ents = _ents_actifs(inputs)
    if not ents:
        return
    try:
        ch = _construire_chemin(ents)[1]
    except Exception:
        _log('maj_chemin erreur %s' % traceback.format_exc()[-600:])
        return
    di = inputs.itemById('distance')
    dep = inputs.itemById('depart')
    cle = (round(ch.longueur, 6), inputs.itemById('objets').selectionCount)
    if recaler or cle != _dernier_chemin:
        _dernier_chemin = cle
        # Objet pose sur le chemin : on part du cote ou il reste le plus de
        # chemin. Chemin a distance : du bout le plus proche (_depart_objets).
        objs_m = _selections(inputs.itemById('objets'))
        T0 = _decal_debut(inputs, ch, objs_m)
        if T0 is not None:
            # 1er corps cree au debut : abscisse (de la face de repere de fin)
            # d'apres la position prevue de la copie
            inv = bool(inputs.itemById('inverser').value)
            c0 = _centre_bbox(objs_m)
            c1 = adsk.core.Point3D.create(c0.x + T0.x, c0.y + T0.y, c0.z + T0.z)
            sc1 = ch.abscisse_proche(c1)
            s0 = max(0.0, min(ch.longueur, sc1 + _decalage_pivot(ch, objs_m, _repere_cle(inputs), inv, T0)))
        else:
            s0, inv = _depart_objets(ch, objs_m, _repere_cle(inputs))
        dep.value = s0 / ch.longueur if ch.longueur > 0 else 0.0
        _dep_exact.update({'dep': dep.value, 's0': s0, 'L': ch.longueur})
        inputs.itemById('inverser').value = inv
        reste = abs(_bout_inputs(inputs, ch, s0) - s0)
        if _dd_key(inputs.itemById('repartition'), REPARTITIONS) == 'etendue':
            di.value = reste if distance is None else distance
        elif distance is None:
            di.value = reste / _n_pas(inputs)      # espacement : par defaut la derniere copie va au bout du chemin
    _placer_fleche(inputs, ch)


_poignee_ref = {}
_en_cours = {'v': False}
JOURNAL = os.path.join(_ADDIN_DIR, 'reseau_journal.txt')


_DEBUG = False


def _logc(msg):
    """Journal des evenements frequents (souris, apercu) : coupe par defaut, une
    ecriture de fichier a chaque mouvement de la fleche coutait des saccades."""
    if _DEBUG:
        _log(msg)


def _log(msg):
    """Journal de debug (reseau_journal.txt), tronque a ~100 Ko."""
    try:
        import time
        if os.path.exists(JOURNAL) and os.path.getsize(JOURNAL) > 100000:
            os.remove(JOURNAL)
        with open(JOURNAL, 'a', encoding='utf-8') as f:
            f.write('%s %s\n' % (time.strftime('%H:%M:%S'), msg))
    except Exception:
        pass


def _s_fin(inputs, ch, s0):
    """Abscisse de la derniere copie d'apres Distance / Repartition."""
    sgn = -1.0 if inputs.itemById('inverser').value else 1.0
    d = inputs.itemById('distance').value
    if _dd_key(inputs.itemById('repartition'), REPARTITIONS) == 'espacement':
        d *= _n_pas(inputs)
    s = s0 + sgn * d
    return s if ch.ferme else max(0.0, min(ch.longueur, s))


def _limites(inputs, ch, s0):
    """Plage d'abscisses ou peut tomber la derniere copie."""
    if _mode_debut(inputs) and _vsym(inputs):
        b = _bout_inputs(inputs, ch, s0)
        return (b, s0) if inputs.itemById('inverser').value else (s0, b)
    if ch.ferme:
        # un tour au plus, du cote du sens choisi (la jonction de debut de
        # boucle n'arrete plus la fleche)
        return (s0 - ch.longueur, s0) if inputs.itemById('inverser').value else (s0, s0 + ch.longueur)
    return (0.0, s0) if inputs.itemById('inverser').value else (s0, ch.longueur)


def _placer_fleche(inputs, ch=None):
    """Fleche posee sur le chemin, a la derniere copie, tangente au chemin,
    comme le Reseau natif. Un Distance natif dessine un trait DROIT de sa
    valeur depuis son origine (il sortait du chemin, retours du 2026-10-13) :
    on met donc son origine sur la derniere copie avec une valeur 0, et la
    forme du chemin est dessinee en pointilles (_dessiner_pointilles)."""
    _echant['cle'] = None
    try:
        if ch is None:
            ch = _chemin_cache(_ents_actifs(inputs))
        s0 = _s0_dialogue(inputs, ch.longueur)
        s_end = _s_fin(inputs, ch, s0)
        pe, tge = ch.point_tangente(s_end)
        v = adsk.core.Vector3D.create(tge.x, tge.y, tge.z)
        if inputs.itemById('inverser').value:
            v.scaleBy(-1)
        v.normalize()
        _poignee_ref.clear()
        _poignee_ref.update({'s0': s0, 's_ref': s_end, 'pe': pe, 'dir': v})
        ph = inputs.itemById('poignee')
        ph.isVisible = not bool(inputs.itemById('masquer').value)
        ph.setManipulator(pe, v)
        ph.value = 0.0
        if _caf is not None:
            ph.isVisible = False            # la pastille remplace la fleche native (glisser hors cycle Fusion)
            if inputs.itemById('masquer').value:
                _rp_effacer()
            else:
                _rp_placer(0, pe)
                _rp_cacher_depuis(1)
        _maj_case_fin(inputs, ch, s0, s_end)
        _sync_barres(inputs)
        if _DEBUG:
            _logc('fleche bout=%s dir=%s s0=%.2f s_end=%.2f' % ([round(c, 2) for c in pe.asArray()],
                                                             [round(c, 2) for c in v.asArray()], s0, s_end))
    except Exception:
        _log('placer_fleche erreur %s' % traceback.format_exc()[-600:])


QSMAX = 50      # maximum des barres de quantite (monte avec la quantite saisie si plus grande)
_gq = {}        # quantite choisie par chemin (cle = jetons des entites), modes a plusieurs chemins


def _sync_barres(inputs):
    """Une barre de quantite par chemin (en bas de la boite) : un seul chemin = la
    quantite ; plusieurs chemins = une quantite par chemin. Cachees en nombre automatique."""
    try:
        barres = [inputs.itemById('qs_%d' % i) for i in range(NB_FLECHES)]
        n = 0
        vals = []
        if inputs.itemById('objets').selectionCount and inputs.itemById('chemin').selectionCount \
                and not _nb_auto(inputs):
            gs = _multi(inputs)
            if gs:
                vals = [g['q'] for g in gs[:NB_FLECHES]]
            else:
                vals = [int(inputs.itemById('quantite').value)]
        for i, sl in enumerate(barres):
            if sl is None:
                continue
            if i < len(vals):
                v = max(1, vals[i])
                try:
                    if sl.maximumValue < v or sl.maximumValue > max(QSMAX, v):
                        sl.maximumValue = max(QSMAX, v)
                except Exception:
                    pass
                if sl.valueOne != v:
                    sl.valueOne = v
                sl.isVisible = False      # les barres vivent dans la vue 3D, plus dans la boite
            else:
                sl.isVisible = False
        syms = []
        if vals:
            items = _gstat['items'] if _mode_debut(inputs) else None
            if items and len(items) == len(vals):
                syms = [_reg_chemin(inputs, it[1])['direction'] == 'symetrique' for it in items]
            else:
                syms = [_sym_dir(inputs)]
        fins = []
        if vals:
            gs2 = _multi(inputs)
            if gs2 and len(gs2) == len(vals):
                for g in gs2:
                    if g['sym']:
                        fins.append(abs(g['e'] - _etendue_sym(g['ch'], _gstat['corps'], g['q'])) < 0.2)
                    else:
                        fins.append(abs(g['s_fin'] - _bout(g['ch'], g['s0'], g['inv'], g['q'])) < 0.2)
            else:
                fins = [bool(inputs.itemById('fin_chemin').value)]
        oeils = []
        if vals:
            gs3 = _multi(inputs)
            if gs3 and len(gs3) == len(vals):
                cles = {g['key'] for g in gs3}
                _oeil.intersection_update(cles)
                if inputs.itemById('masquer').value and not _oeil:
                    _oeil.update(cles)          # « Masquer » deja coche quand le 2e chemin arrive : tous
                oeils = [g['key'] in _oeil for g in gs3]
            else:
                oeils = [bool(inputs.itemById('masquer').value)]
        exts = []
        if vals:
            gs4 = _multi(inputs)
            if gs4 and len(gs4) == len(vals):
                exts = [bool(_gmasq.get(g['key'])) or g['key'] in _oeil for g in gs4]
            else:
                exts = [bool(inputs.itemById('masques').value) or bool(inputs.itemById('masquer').value)]
        hauts = []
        if vals:
            items = _gstat['items'] if _mode_debut(inputs) else None
            if items and len(items) == len(vals):
                hauts = [bool(_reg_chemin(inputs, it[1]).get('tenon_haut')) for it in items]
            else:
                hauts = [_haut(inputs)]
        pivots = []
        if vals:
            items = _gstat['items'] if _mode_debut(inputs) else None
            if items and len(items) == len(vals):
                pivots = [bool(_reg_chemin(inputs, it[1]).get('pivot')) for it in items]
            else:
                pivots = [bool(_pivot(inputs))]
        _ov_maj(vals, _idx_selection(_multi(inputs)) if len(vals) > 1 else 0, syms, fins, oeils, exts, hauts, pivots)
        if vals:
            _qp_maj(inputs)
        else:
            _qp_effacer()
    except Exception:
        _log('barres erreur %s' % traceback.format_exc()[-300:])


def _barre_changee(inputs, iid):
    """Une barre de la boite est glissee : la quantite du chemin correspondant suit."""
    try:
        _appliquer_q(inputs, int(iid.split('_')[1]), int(inputs.itemById(iid).valueOne))
    except Exception:
        _log('barre erreur %s' % traceback.format_exc()[-300:])


def _appliquer_q(inputs, i, v):
    """Quantite v pour le chemin i (un seul chemin : le champ Quantite)."""
    gs = _multi(inputs)
    if gs:
        if i < len(gs):
            _gfin.setdefault(gs[i]['key'], gs[i]['s_fin'])     # la fin du reseau ne bouge pas : les copies se resserrent
            _gq[gs[i]['key']] = v
            gs = _multi(inputs)
            _placer_fleches_multi(inputs, gs)
            _apercu_multi(inputs, gs)
        return
    qi = inputs.itemById('quantite')
    if int(qi.value) == v:
        return
    di = inputs.itemById('distance')
    if _dd_key(inputs.itemById('repartition'), REPARTITIONS) == 'espacement':
        total = di.value * _n_pas(inputs)      # distance debut -> fin conservee : seul l'espacement change
    else:
        total = None
    qi.value = v
    if total is not None:
        di.value = total / max(1, _n_pas(inputs))
    if _ctx.get('ok') and not _ctx.get('vsym'):
        _ctx['q'] = v          # seul le nombre de copies change : on garde le reste du contexte
        _ctx['npas'] = _n_pas(inputs)
    else:
        _ctx['ok'] = False
    _placer_fleche(inputs)


# --- Barres de quantite dans la vue (en bas a gauche) ---------------------------
# Graphiques colles au coin de la vue (viewPlacement) : toujours au-dessus du modele, ne
# bougent pas avec la camera. Un clic / glisser dessus est lu par les evenements souris.

OV_W, OV_H = 558, 28            # taille de l'image d'une ligne (pixels d'image)
OV_X, OV_Y, OV_GAP = 16, 60, 6  # marges depuis le coin bas gauche (pixels ecran)
OV_M0, OV_M1 = 74, 96           # bouton moins
OV_B0, OV_B1 = 102, 262         # debut / fin de la barre dans l'image
OV_P0, OV_P1 = 268, 290         # bouton plus
OV_S0, OV_S1 = 338, 366         # bouton symetrie dans l'image
OV_E0, OV_E1 = 372, 400 
OV_T0, OV_T1 = 406, 434         # bouton fleches haut / bas (tenon du haut)
OV_F0, OV_F1 = 440, 468         # bouton face / champ (pivoter)
OV_O0, OV_O1 = 474, 502         # bouton œil (Masquer), contre le bouton face / champ
OV_A0, OV_A1 = 492, 520         # œil quand Masquer est actif : plus a droite
OV_W_COURT = 510                # largeur de la ligne tant qu'aucun corps n'est masque
OV_X0, OV_X1 = 526, 554         # œil barre : remet tous les corps masques de ce chemin
        # bouton « jusqu'au bout » dans l'image
_dpr_cache = {}


def _dpr():
    """Fusion dessine les images des graphiques colles a la vue agrandies du facteur d'echelle
    de l'ecran (2 pour 192 dpi) alors que les positions de la vue sont en pixels ecran."""
    if 'k' not in _dpr_cache:
        k = 1.0
        try:
            import ctypes
            k = max(1.0, ctypes.windll.user32.GetDpiForSystem() / 96.0)
        except Exception:
            pass
        _dpr_cache['k'] = k
    return _dpr_cache['k']
OV_EXP = 1.6                                             # progressif : lent au debut, rapide a la fin
_ov = {'g': None, 'sig': None, 'on': None, 'qm': {}, 'vals': [], 't': 0.0}

_GLYPHES = {
    'C': '111100100100111', 'H': '101101111101101', 'E': '111100111100111', 'M': '101111111101101',
    'T': '111010010010010', 'O': '111101101101111', 'U': '101101101101111',
    'S': '111100111001111', 'I': '111010010010111', 'N': '111101101101101', ' ': '000000000000000',
    '0': '111101101101111', '1': '010110010010111', '2': '111001111100111', '3': '111001111001111',
    '4': '101101111001001', '5': '111100111001111', '6': '111100111101111', '7': '111001001001001',
    '8': '111101111101111', '9': '111101111001111',
    'A': '010101111101101', 'B': '110101110101110', 'D': '110101101101110', 'F': '111100110100100',
    'G': '011100101101011', 'J': '001001001101010', 'K': '101101110101101', 'L': '100100100100111',
    'P': '110101110100100', 'Q': '010101101111011', 'R': '110101110101101', 'V': '101101101101010',
    'W': '101101111111101', 'X': '101101010101101', 'Y': '101101010010010', 'Z': '111001010100111',
    "'": '010010000000000', '.': '000000000000010', ',': '000000000010100', '-': '000000111000000',
    ':': '000010000010000', '%': '101001010100101', '/': '001001010100100'}


def _png_ligne(i, q, t, sel=True, sym=False, fin=False, oeil=False, entete=False, ext=False, haut=False, pivot=False):
    """Image d'une ligne : « CHEMIN i », barre avec curseur a la fraction t, quantite q."""
    cle = 'ov%d_%d_%d_%d_%d_%d_%d%s' % (i, q, int(t * 1000), 1 if sel else 0, 1 if sym else 0, 1 if fin else 0, 1 if oeil else 0, ('T' if entete else '') + ('X' if ext else '') + ('H' if haut else '') + ('P' if pivot else ''))
    if cle in _png_cache and os.path.isfile(_png_cache[cle]):
        return _png_cache[cle]
    import zlib, struct, tempfile
    w, h = (OV_W if ext else OV_W_COURT), OV_H
    px = [[(40, 40, 40, 255)] * w for _ in range(h)]
    for x in range(w):
        for y in (0, 1, h - 1, h - 2):
            px[y][x] = (110, 110, 110, 255)
    for y in range(h):
        for x in (0, 1, w - 1, w - 2):
            px[y][x] = (110, 110, 110, 255)

    def texte(txt, x0, couleur):
        y0 = (h - 10) // 2
        for n, c in enumerate(txt):
            g = _GLYPHES.get(c, _GLYPHES[' '])
            for gy in range(5):
                for gx in range(3):
                    if g[gy * 3 + gx] == '1':
                        for dy in range(2):
                            for dx in range(2):
                                px[y0 + gy * 2 + dy][x0 + n * 8 + gx * 2 + dx] = couleur

    bleu = (20, 130, 215, 255) if sel else (120, 120, 120, 255)
    if sel:
        for x in range(w):
            for y in (0, 1, h - 1, h - 2):
                px[y][x] = (20, 130, 215, 255)
        for y in range(h):
            for x in (0, 1, w - 1, w - 2):
                px[y][x] = (20, 130, 215, 255)
    yc = h // 2
    if entete:
        texte('TOUT', 8, (235, 235, 235, 255))
    else:
        texte('CHEMIN %d' % (i + 1), 8, (235, 235, 235, 255) if sel else (140, 140, 140, 255))
        texte(str(q), OV_P1 + 8, (255, 200, 60, 255) if sel else (140, 140, 140, 255))
    # boutons : symetrie (deux triangles en miroir, comme l'icone de Fusion) et « jusqu'au bout »
    def bouton(x0, x1, actif):
        fond = (110, 55, 0, 255) if actif else (62, 62, 62, 255)
        bord = (255, 170, 60, 255) if actif else (125, 125, 125, 255)
        for x in range(x0, x1):
            for y in range(yc - 11, yc + 11):
                px[y][x] = bord if (x in (x0, x1 - 1) or y in (yc - 11, yc + 10)) else fond
        return (255, 140, 0, 255) if actif else (150, 150, 150, 255), (255, 225, 175, 255) if actif else (190, 190, 190, 255)

    if not entete:
        plein, clair = bouton(OV_M0, OV_M1, False)
        xm = (OV_M0 + OV_M1) // 2
        for x in range(xm - 5, xm + 5):
            for y in (yc - 1, yc):
                px[y][x] = clair
        plein, clair = bouton(OV_P0, OV_P1, False)
        xp = (OV_P0 + OV_P1) // 2
        for x in range(xp - 5, xp + 5):
            for y in (yc - 1, yc):
                px[y][x] = clair
        for y in range(yc - 5, yc + 5):
            for x in (xp - 1, xp):
                px[y][x] = clair
        plein, clair = bouton(OV_S0, OV_S1, sym)
        cx, ht = (OV_S0 + OV_S1) // 2, 15
        for r in range(ht):
            wd = 1 + (r * 8) // (ht - 1)
            y = yc - 7 + r
            for dx in range(1, wd + 1):
                px[y][cx + dx] = plein                                  # triangle plein (droite)
                bordure = (dx == wd or dx == 1 or r == ht - 1)
                if bordure:
                    px[y][cx - dx] = clair                             # triangle vide (gauche)
    def dessiner_oeil(x0, x1, actif, barre=False):
        plein, clair = bouton(x0, x1, actif)
        xo = (x0 + x1) // 2
        for dx in range(-9, 10):
            # contour de l'œil : deux arcs qui se rejoignent aux coins
            ey = int(round(5.0 * (1 - (dx / 9.0) ** 2) ** 0.8))
            for y in (yc - ey, yc + ey):
                px[y][xo + dx] = clair
        for dx in range(-3, 4):
            for dy in range(-3, 4):
                if dx * dx + dy * dy <= 9:
                    px[yc + dy][xo + dx] = plein
        if barre:
            for t in range(-9, 10):
                for e in (0, 1):
                    y, x = yc + t // 2 + e, xo + t
                    if 0 <= y < h:
                        px[y][x] = (255, 235, 200, 255)

    if ext:
        dessiner_oeil(OV_A0, OV_A1, oeil)
        dessiner_oeil(OV_X0, OV_X1, False, True)
    else:
        dessiner_oeil(OV_O0, OV_O1, False)
    if not entete:
        plein, clair = bouton(OV_T0, OV_T1, haut)
        xh = (OV_T0 + OV_T1) // 2
        for sens, dx in ((-1, -5), (1, 5)):                 # une fleche vers le haut, une vers le bas
            for y in range(yc - 6, yc + 7):
                px[y][xh + dx] = clair
            for k in range(4):
                yy = yc - 6 + k if sens < 0 else yc + 6 - k
                for x in range(xh + dx - k, xh + dx + k + 1):
                    px[yy][x] = clair
        # face / champ : panneau couche (face contre le chemin, actif) ou debout (champ)
        plein, clair = bouton(OV_F0, OV_F1, pivot)
        xf = (OV_F0 + OV_F1) // 2
        rx, ry = (9, 4) if pivot else (3, 9)
        for x in range(xf - rx, xf + rx + 1):
            for y in range(yc - ry, yc + ry + 1):
                bord_r = x in (xf - rx, xf + rx) or y in (yc - ry, yc + ry)
                px[y][x] = clair if bord_r else plein
        plein, clair = bouton(OV_E0, OV_E1, fin)
        x_a, x_b = OV_E0 + 6, OV_E1 - 8
        for x in range(x_a, x_b):
            for y in (yc - 1, yc):
                px[y][x] = plein
        for k in range(6):
            for y in range(yc - 5 + k, yc + 5 - k + 1):
                if 0 <= y < h:
                    px[y][x_b - 6 + k + 1 + 2] = plein if k < 6 else plein
        for y in range(yc - 6, yc + 7):
            for x in (OV_E1 - 7, OV_E1 - 6):
                px[y][x] = clair
    if not entete:
        kx = OV_B0 + int(round(t * (OV_B1 - OV_B0)))
        for x in range(OV_B0, OV_B1 + 1):
            for y in (yc - 1, yc, yc + 1):
                px[y][x] = bleu if x <= kx else (150, 150, 150, 255) if sel else (90, 90, 90, 255)
        for x in range(kx - 3, kx + 4):
            for y in range(yc - 9, yc + 9):
                px[y][x] = (255, 255, 255, 255) if (x in (kx - 3, kx + 3) or y in (yc - 9, yc + 8)) and sel else (200, 200, 200, 255) if (x in (kx - 3, kx + 3) or y in (yc - 9, yc + 8)) else bleu
    raw = bytearray()
    for y in range(h):
        raw.append(0)
        for x in range(w):
            raw += bytes(px[y][x])

    def chunk(tt, dd):
        c = struct.pack('>I', len(dd)) + tt + dd
        return c + struct.pack('>I', zlib.crc32(tt + dd) & 0xffffffff)

    png = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 6, 0, 0, 0)) + \
        chunk(b'IDAT', zlib.compress(bytes(raw))) + chunk(b'IEND', b'')
    chemin = os.path.join(tempfile.gettempdir(), 'reseau_cnc_%s.png' % cle)
    with open(chemin, 'wb') as f:
        f.write(png)
    _png_cache[cle] = chemin
    return chemin


def _ecrire_png(cle, px, w, h):
    import zlib, struct, tempfile
    raw = bytearray()
    for y in range(h):
        raw.append(0)
        for x in range(w):
            raw += bytes(px[y][x])

    def chunk(tt, dd):
        c = struct.pack('>I', len(dd)) + tt + dd
        return c + struct.pack('>I', zlib.crc32(tt + dd) & 0xffffffff)

    png = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 6, 0, 0, 0)) + \
        chunk(b'IDAT', zlib.compress(bytes(raw))) + chunk(b'IEND', b'')
    chemin = os.path.join(tempfile.gettempdir(), 'reseau_cnc_%s.png' % cle)
    with open(chemin, 'wb') as f:
        f.write(png)
    _png_cache[cle] = chemin
    return chemin


def _texte_px(px, txt, x0, y0, couleur):
    """Texte en capitales (accents retires) dans la grille de pixels px, police 3x5 agrandie x2."""
    import unicodedata
    txt = ''.join(c for c in unicodedata.normalize('NFD', txt) if unicodedata.category(c) != 'Mn').upper()
    for n, c in enumerate(txt):
        g = _GLYPHES.get(c, _GLYPHES[' '])
        for gy in range(5):
            for gx in range(3):
                if g[gy * 3 + gx] == '1':
                    for dy in range(2):
                        for dx in range(2):
                            px[y0 + gy * 2 + dy][x0 + n * 8 + gx * 2 + dx] = couleur


def _coupe(txt, n=34):
    lignes, cur = [], ''
    for mot in txt.split():
        if cur and len(cur) + 1 + len(mot) > n:
            lignes.append(cur)
            cur = mot
        else:
            cur = (cur + ' ' + mot).strip()
    if cur:
        lignes.append(cur)
    return lignes


def _png_info(txt):
    """Infobulle claire d'une ligne, comme les bulles natives de Fusion."""
    cle = 'tip2_%s' % abs(hash(txt))
    w = len(txt) * 8 + 12
    h = 24
    if cle in _png_cache and os.path.isfile(_png_cache[cle]):
        return _png_cache[cle], w, h
    px = [[(246, 246, 246, 255)] * w for _ in range(h)]
    for x in range(w):
        for y in (0, h - 1):
            px[y][x] = (110, 110, 110, 255)
    for y in range(h):
        for x in (0, w - 1):
            px[y][x] = (110, 110, 110, 255)
    _texte_px(px, txt, 6, 7, (20, 20, 20, 255))
    return _ecrire_png(cle, px, w, h), w, h


BTN_W, BTN_H = 220, 26


def _png_valider():
    """Bouton « Valider le masquage » : œil + coche + texte, sur fond vert."""
    cle = 'valider2'
    if cle in _png_cache and os.path.isfile(_png_cache[cle]):
        return _png_cache[cle]
    w, h = BTN_W, BTN_H
    px = [[(24, 110, 62, 255)] * w for _ in range(h)]
    for x in range(w):
        for y in (0, 1, h - 1, h - 2):
            px[y][x] = (235, 245, 235, 255)
    for y in range(h):
        for x in (0, 1, w - 1, w - 2):
            px[y][x] = (235, 245, 235, 255)
    yc = h // 2
    blanc = (245, 250, 245, 255)
    for dx in range(-10, 11):
        ey = int(round(6.0 * (1 - (dx / 10.0) ** 2) ** 0.8))
        for y in (yc - ey, yc + ey):
            px[y][18 + dx] = blanc
    for dx in range(-3, 4):
        for dy in range(-3, 4):
            if dx * dx + dy * dy <= 9:
                px[yc + dy][18 + dx] = blanc
    for t in range(5):                       # coche
        for e in (0, 1):
            px[yc + 2 + t + e][36 + t] = blanc
    for t in range(9):
        for e in (0, 1):
            px[yc + 6 - t + e][41 + t] = blanc
    _texte_px(px, 'VALIDER LE MASQUAGE', 58, yc - 5, blanc)
    return _ecrire_png(cle, px, w, h)


_tip = {'g': None, 'cle': None}



# --- Fenetres du bas a gauche toujours devant le modele (2026-11-05) ----------
# Une image posee en viewPlacement garde la profondeur de son point 3D : a
# l'origine, tout corps plus proche de la camera passait devant. On la decale
# vers la camera, juste devant la sphere englobante du modele, et on suit la
# camera (orbite, zoom) pour qu'elle reste toujours devant.
import time
_dv = {'ents': [], 'h': None, 'c': None, 'r': 0.0, 't': 0.0}


def _dv_point():
    app = adsk.core.Application.get()
    des = adsk.fusion.Design.cast(app.activeProduct)
    if des is None:
        return None
    if time.time() - _dv['t'] > 1.0:
        _dv['t'] = time.time()
        bb = des.rootComponent.boundingBox
        if bb is None:
            _dv['c'] = None
        else:
            a, b = bb.minPoint, bb.maxPoint
            _dv['c'] = ((a.x + b.x) / 2.0, (a.y + b.y) / 2.0, (a.z + b.z) / 2.0)
            _dv['r'] = a.distanceTo(b) / 2.0
    c = _dv['c']
    if c is None:
        return None
    cam = app.activeViewport.camera
    e, t = cam.eye, cam.target
    d = (e.x - t.x, e.y - t.y, e.z - t.z)
    lg = math.sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2])
    if lg < 1e-9:
        return None
    d = (d[0] / lg, d[1] / lg, d[2] / lg)
    ec = (e.x - c[0]) * d[0] + (e.y - c[1]) * d[1] + (e.z - c[2]) * d[2]
    # juste devant le modele, mais jamais derriere la camera (perspective tres zoomee)
    s = min(_dv['r'] * 1.2 + 1.0, ec * 0.5) if ec > 0 else 0.0
    p = adsk.core.Point3D.create(c[0] + d[0] * s, c[1] + d[1] * s, c[2] + d[2] * s)
    occ = des.activeOccurrence
    if occ is not None:
        inv = occ.transform2.copy()
        inv.invert()
        p.transformBy(inv)
    return p


def _dv_appliquer(ents):
    p = _dv_point()
    if p is None:
        return
    m = adsk.core.Matrix3D.create()
    m.translation = adsk.core.Vector3D.create(p.x, p.y, p.z)
    for x in ents:
        x.transform = m


class _DvCamHandler(adsk.core.CameraEventHandler):
    def notify(self, args):
        try:
            ents = [x for x in _dv['ents'] if x.isValid]
            _dv['ents'] = ents
            if ents:
                _dv_appliquer(ents)
        except Exception:
            pass


def _dv_poser(ps):
    """A appeler apres chaque ps.viewPlacement = ... d'une fenetre du bas a gauche."""
    try:
        _dv['t'] = 0.0
        _dv_appliquer([ps])
        _dv['ents'] = [x for x in _dv['ents'] if x.isValid] + [ps]
        if _dv['h'] is None:
            h = _DvCamHandler()
            adsk.core.Application.get().cameraChanged.add(h)
            _dv['h'] = h
    except Exception:
        pass


def _dv_arreter():
    try:
        if _dv['h'] is not None:
            adsk.core.Application.get().cameraChanged.remove(_dv['h'])
    except Exception:
        pass
    _dv['h'] = None
    _dv['ents'] = []


def _tip_effacer():
    g = _tip['g']
    _tip['g'] = None
    _tip['cle'] = None
    try:
        if g is not None and g.isValid:
            g.deleteMe()
            _rafraichir()      # sans redessin, la bulle restait a l'ecran plusieurs secondes
    except Exception:
        pass


TEXTES_AIDE = {
    's': "Symetrie autour du depart",
    'h': "Tenon du haut (retourne)",
    'v': "Face / champ (pivoter)",
    'f': "Jusqu'au bout du chemin",
    'o': "Masquer des corps",
    'oa': "Valider le masquage",
    'x': "Reafficher les corps",
    'xt': "Reafficher tous les corps",
    'ot': "Tout masquer",
    'm': "Une copie de moins",
    'p': "Une copie de plus"}


def _tip_cible(vp, pos):
    """(cle, ligne, x gauche de l'icone dans l'image, texte) de l'icone sous le curseur, sinon None."""
    i = _ov_ligne(vp, pos)
    if i is None:
        return None
    k = _dpr()
    oeils = _ov.get('oeils', [])
    actif = (bool(oeils) and all(oeils)) if i < 0 else (i < len(oeils) and oeils[i])
    if _ov_croix(vp, pos) is not None:
        return ('x', i, OV_X0, TEXTES_AIDE['xt' if i < 0 else 'x'])
    if _ov_oeil(vp, pos) is not None:
        t = 'ot' if (i < 0 and not actif) else ('oa' if actif else 'o')
        ex = _ov.get('exts', [])
        etendue = any(ex) if i < 0 else (i < len(ex) and ex[i])
        return (t, i, OV_A0 if etendue else OV_O0, TEXTES_AIDE[t])
    if _ov_sym(vp, pos) is not None:
        return ('s', i, OV_S0, TEXTES_AIDE['s'])
    if _ov_fin(vp, pos) is not None:
        return ('f', i, OV_E0, TEXTES_AIDE['f'])
    if _ov_haut(vp, pos) is not None:
        return ('h', i, OV_T0, TEXTES_AIDE['h'])
    if _ov_pivot(vp, pos) is not None:
        return ('v', i, OV_F0, TEXTES_AIDE['v'])
    pm = _ov_pm(vp, pos)
    if pm is not None:
        return ('m' if pm[1] < 0 else 'p', i, OV_M0 if pm[1] < 0 else OV_P0, TEXTES_AIDE['m' if pm[1] < 0 else 'p'])
    return None


def _tip_maj(vp, pos):
    """Infobulle sous forme de graphique colle a la vue, au-dessus de l'icone survole."""
    c = _tip_cible(vp, pos) if _ov['g'] is not None else None
    cle = None if c is None else (c[0], c[1])
    if cle == _tip['cle'] and (cle is None or (_tip['g'] is not None and _tip['g'].isValid)):
        return
    _tip_effacer()
    if c is None:
        return
    design = adsk.fusion.Design.cast(_app.activeProduct)
    png, w, h = _png_info(c[3])
    g = design.activeComponent.customGraphicsGroups.add()      # composant actif : sinon la fenetre est grisee
    k = _dpr()
    n = len(_ov['vals'])
    off = 1 if n >= 2 else 0
    nr = n + off
    rang = c[1] + off
    ex = _ov.get('exts', [])
    etendue = any(ex) if c[1] < 0 else (c[1] < len(ex) and ex[c[1]])
    # a droite de la ligne survolee : la bulle ne passe jamais sous une autre ligne
    gauche = OV_X + ((OV_W if etendue else OV_W_COURT) + 8) * k
    haut = OV_Y + (nr - 1 - rang) * (OV_H * k + OV_GAP) + (OV_H * k - h * k) / 2.0 - 8
    ps = g.addPointSet(adsk.fusion.CustomGraphicsCoordinates.create([0.0, 0.0, 0.0]), [0],
                       adsk.fusion.CustomGraphicsPointTypes.UserDefinedCustomGraphicsPointType, png)
    ps.isSelectable = False
    ps.viewPlacement = adsk.fusion.CustomGraphicsViewPlacement.create(
        adsk.core.Point3D.create(0, 0, 0), adsk.fusion.ViewCorners.lowerLeftViewCorner,
        adsk.core.Point2D.create(gauche + w * k / 2.0, haut + 8 + h * k / 2.0))
    _dv_poser(ps)
    _tip['g'] = g
    _tip['cle'] = cle
    _rafraichir()              # la bulle apparait tout de suite


def _btn_y_bas(n, k):
    """Centre vertical (depuis le bas de la vue) du bouton de validation : juste au-dessus des lignes."""
    nr = n + (1 if n >= 2 else 0)
    haut = OV_Y + nr * OV_H * k + (nr - 1) * OV_GAP
    return haut + 6 + BTN_H * k / 2.0


def _ov_valider(vp, pos):
    """Vrai si le bouton « Valider le masquage » est sous le curseur."""
    if not _ov.get('btn') or _ov['g'] is None:
        return False
    k = _dpr()
    cx = OV_X + BTN_W * k / 2.0
    yc = vp.height * k - _btn_y_bas(len(_ov['vals']), k)
    return abs(pos.x - cx) <= BTN_W * k / 2.0 and abs(pos.y - yc) <= BTN_H * k / 2.0


def _valider_masquage(inputs):
    """Clic sur « Valider le masquage » : meme effet que de decocher tous les œils."""
    _en_cours['v'] = True
    try:
        m = inputs.itemById('masquer')
        gs = _multi(inputs)
        if gs:
            _oeil.clear()
        m.value = False
        _masquer_maj(inputs, gs)
    finally:
        _en_cours['v'] = False
    _rafraichir()


_ov_orphelins = []      # groupes dont deleteMe a echoue (chronologie reculee en modification) : reessayes


def _ov_purger():
    """Reessaie de supprimer les groupes de fenetres restes affiches."""
    reste = []
    for g in _ov_orphelins:
        try:
            if g.isValid:
                g.deleteMe()
        except Exception:
            pass
        try:
            if g.isValid:
                reste.append(g)
        except Exception:
            pass
    _ov_orphelins[:] = reste


def _ov_effacer():
    g = _ov['g']
    _ov['g'] = None
    _ov['sig'] = None
    _tip_effacer()
    try:
        if g is not None and g.isValid:
            g.deleteMe()
    except Exception:
        pass
    try:
        if g is not None and g.isValid:
            _ov_orphelins.append(g)       # toujours la : on reessaiera
    except Exception:
        pass
    _ov_purger()


def _ov_q_de_t(t, qm):
    """Position t (0..1) de la barre -> quantite : 1 a 20 sur les 3 premiers quarts, puis
    de 20 a qm de plus en plus vite sur le dernier quart."""
    t = max(0.0, min(1.0, t))
    if t <= 0.75:
        q = 1 + 19.0 * t / 0.75
    else:
        q = 20 + (max(qm, 21) - 20) * (((t - 0.75) / 0.25) ** OV_EXP)
    return max(1, int(round(q)))


def _ov_t(i, q):
    qm = max(21, _ov['qm'].get(i, QSMAX))
    if q <= 20:
        return 0.75 * (max(1, q) - 1) / 19.0
    return 0.75 + 0.25 * (min(1.0, (q - 20) / float(qm - 20)) ** (1.0 / OV_EXP))


def _vp_larg():
    try:
        v = _app.activeViewport
        return (int(v.width), int(v.height))
    except Exception:
        return None


def _ov_maj(vals, sel=None, syms=None, fins=None, oeils=None, exts=None, hauts=None, pivots=None):
    """Dessine (ou met a jour) une ligne par chemin ; vals = quantites."""
    try:
        if sel is None:
            sel = _ov.get('sel', 0)
        if syms is None:
            syms = _ov.get('syms', [])
        syms = [bool(syms[i]) if i < len(syms) else False for i in range(len(vals))]
        if fins is None:
            fins = _ov.get('fins', [])
        fins = [bool(fins[i]) if i < len(fins) else False for i in range(len(vals))]
        if oeils is None:
            oeils = _ov.get('oeils', [])
        oeils = [bool(oeils[i]) if i < len(oeils) else False for i in range(len(vals))]
        if hauts is None:
            hauts = _ov.get('hauts', [])
        hauts = [bool(hauts[i]) if i < len(hauts) else False for i in range(len(vals))]
        _ov['hauts'] = hauts
        if pivots is None:
            pivots = _ov.get('pivots', [])
        pivots = [bool(pivots[i]) if i < len(pivots) else False for i in range(len(vals))]
        _ov['pivots'] = pivots
        if exts is None:
            exts = _ov.get('exts', [])
        exts = [bool(exts[i]) or oeils[i] if i < len(exts) else oeils[i] for i in range(len(vals))]
        _ov['sel'], _ov['syms'], _ov['fins'], _ov['oeils'], _ov['exts'] = sel, syms, fins, oeils, exts
        for i, v in enumerate(vals):
            _ov['qm'][i] = max(_ov['qm'].get(i, QSMAX), v)
        sig = (tuple(vals), tuple(_ov['qm'].get(i) for i in range(len(vals))), sel, tuple(syms), tuple(fins), tuple(oeils), tuple(exts), tuple(hauts), tuple(pivots), _vp_larg())
        if sig == _ov['sig'] and _ov['g'] is not None and _ov['g'].isValid:
            return
        _ov_effacer()
        _ov['vals'] = list(vals)
        if not vals:
            return
        design = adsk.fusion.Design.cast(_app.activeProduct)
        g = design.activeComponent.customGraphicsGroups.add()      # composant actif : sinon les fenetres sont grisees
        n = len(vals)
        k = _dpr()
        off = 1 if n >= 2 else 0          # une ligne « TOUT » en haut des qu'il y a deux chemins
        nr = n + off
        lignes = ([(None, _png_ligne(0, 1, 0.0, False, False, False, all(oeils), True, any(exts)))] if off else []) + \
            [(i, _png_ligne(i, v, _ov_t(i, v), i == sel, syms[i], fins[i], oeils[i], False, exts[i], hauts[i], pivots[i])) for i, v in enumerate(vals)]
        for r, (_i, png) in enumerate(lignes):
            ps = g.addPointSet(adsk.fusion.CustomGraphicsCoordinates.create([0.0, 0.0, 0.0]), [0],
                               adsk.fusion.CustomGraphicsPointTypes.UserDefinedCustomGraphicsPointType, png)
            ps.isSelectable = False
            ps.viewPlacement = adsk.fusion.CustomGraphicsViewPlacement.create(
                adsk.core.Point3D.create(0, 0, 0), adsk.fusion.ViewCorners.lowerLeftViewCorner,
                adsk.core.Point2D.create(OV_X + (OV_W if (any(exts) if _i is None else exts[_i]) else OV_W_COURT) * k / 2.0, OV_Y + (nr - 1 - r) * (OV_H * k + OV_GAP) + OV_H * k / 2.0))
            _dv_poser(ps)
        if any(oeils):
            ps = g.addPointSet(adsk.fusion.CustomGraphicsCoordinates.create([0.0, 0.0, 0.0]), [0],
                               adsk.fusion.CustomGraphicsPointTypes.UserDefinedCustomGraphicsPointType, _png_valider())
            ps.isSelectable = False
            ps.viewPlacement = adsk.fusion.CustomGraphicsViewPlacement.create(
                adsk.core.Point3D.create(0, 0, 0), adsk.fusion.ViewCorners.lowerLeftViewCorner,
                adsk.core.Point2D.create(OV_X + BTN_W * k / 2.0, _btn_y_bas(len(vals), k)))
            _dv_poser(ps)
        _ov['btn'] = bool(any(oeils))
        _ov['g'] = g
        _ov['sig'] = sig
        _log('overlay dessine %s' % list(vals))
    except Exception:
        _log('overlay erreur %s' % traceback.format_exc()[-400:])


def _ov_touche(vp, pos):
    """Indice de la ligne dont la barre est sous le curseur, sinon None."""
    n = len(_ov['vals'])
    if not n or _ov['g'] is None:
        return None
    k = _dpr()
    h = vp.height * k      # hauteur de la vue en pixels ecran (vp.height est donne en pixels logiques)
    off = 1 if n >= 2 else 0
    nr = n + off
    for i in range(n):
        yc = h - (OV_Y + (nr - 1 - (i + off)) * (OV_H * k + OV_GAP) + OV_H * k / 2.0)
        if OV_X + (OV_B0 - 6) * k <= pos.x <= OV_X + (OV_B1 + 6) * k and abs(pos.y - yc) <= OV_H * k / 2.0:
            return i
    return None


def _ov_ligne(vp, pos):
    """Indice de la ligne (barre ou nom) sous le curseur, sinon None."""
    n = len(_ov['vals'])
    if not n or _ov['g'] is None:
        return None
    k = _dpr()
    h = vp.height * k
    off = 1 if n >= 2 else 0
    nr = n + off
    for r in range(nr):
        yc = h - (OV_Y + (nr - 1 - r) * (OV_H * k + OV_GAP) + OV_H * k / 2.0)
        ex = _ov.get('exts', [])
        etendue = any(ex) if r < off else (r - off < len(ex) and ex[r - off])
        if OV_X <= pos.x <= OV_X + (OV_W if etendue else OV_W_COURT) * k and abs(pos.y - yc) <= OV_H * k / 2.0:
            return r - off          # -1 : la ligne « TOUT »
    return None


def _ov_sym(vp, pos):
    """Indice de la ligne dont le bouton S est sous le curseur, sinon None."""
    i = _ov_ligne(vp, pos)
    if i is None or i < 0:
        return None
    k = _dpr()
    return i if OV_X + OV_S0 * k <= pos.x <= OV_X + OV_S1 * k else None


def _ov_pm(vp, pos):
    """(ligne, -1 ou +1) si un bouton moins / plus est sous le curseur, sinon None."""
    i = _ov_ligne(vp, pos)
    if i is None or i < 0:
        return None
    k = _dpr()
    if OV_X + OV_M0 * k <= pos.x <= OV_X + OV_M1 * k:
        return i, -1
    if OV_X + OV_P0 * k <= pos.x <= OV_X + OV_P1 * k:
        return i, 1
    return None


def _ov_q_pas(inputs, i, delta):
    """Clic sur « - » ou « + » : un corps de moins / de plus sur ce chemin."""
    if i >= len(_ov['vals']) or _nb_auto(inputs):
        return
    q = max(1, min(10000, _ov['vals'][i] + delta))
    if q == _ov['vals'][i]:
        return
    _en_cours['v'] = True
    try:
        _appliquer_q(inputs, i, q)
        _sync_barres(inputs)
    finally:
        _en_cours['v'] = False
    _rafraichir()


_opac = {'liste': [], 'toks': set()}
OPACITE_MASQUER = 0.3


def _opacite_appliquer():
    """Tout le modele a 30 % (« Masquer ») : les valeurs d'origine sont gardees pour tout remettre."""
    design = adsk.fusion.Design.cast(_app.activeProduct)
    if design is None:
        return
    if _opac['liste']:
        try:
            b0 = _opac['liste'][0][0]
            if b0.isValid and abs(b0.opacity - OPACITE_MASQUER) < 1e-6:
                return           # deja applique (Fusion annule parfois les changements au debut d'un apercu)
        except Exception:
            pass
    for comp in design.allComponents:
        for i in range(comp.bRepBodies.count):
            b = comp.bRepBodies.item(i)
            try:
                orig = b.opacity
                if abs(orig - OPACITE_MASQUER) < 1e-6:
                    orig = 1.0       # deja a 30 % au depart : reste d'une session interrompue (les copies heritent de l'opacite de la source)
                tok = b.entityToken
                if tok not in _opac['toks']:
                    _opac['toks'].add(tok)
                    _opac['liste'].append((b, orig))
                if abs(orig - OPACITE_MASQUER) > 1e-6:
                    b.opacity = OPACITE_MASQUER
            except Exception:
                pass


def _opacite_ok():
    """True si le modele est bien a 30 % (premier corps memorise)."""
    try:
        b0 = _opac['liste'][0][0]
        return b0.isValid and abs(b0.opacity - OPACITE_MASQUER) < 1e-6
    except Exception:
        return False


def _opacite_restaurer():
    """Remet l'opacite d'origine de chaque corps modifie (toutes les sorties : valider, annuler, erreur)."""
    liste = _opac['liste']
    _opac['liste'] = []
    _opac['toks'] = set()
    for b, orig in liste:
        try:
            if b.isValid and abs(b.opacity - orig) > 1e-6:
                b.opacity = orig
        except Exception:
            pass


_filt = {'on': False}


def _filtres_masquer(inputs, on):
    """En mode « Masquer » rien du modele ne se selectionne (corps, aretes, faces) : seules les cases
    se cliquent. Les filtres des deux champs de selection n'acceptent alors presque rien."""
    if on == _filt['on']:
        return
    _filt['on'] = on
    for iid in ('objets', 'chemin'):
        sel = inputs.itemById(iid)
        sel.clearSelectionFilter()
        if on:
            sel.addSelectionFilter('Joints')
        elif iid == 'objets':
            _set_filtres_objets(inputs)
        else:
            sel.addSelectionFilter('Edges')
            sel.addSelectionFilter('SketchCurves')


def _opacite_gardant_selection(inputs, f):
    """Change l'opacite sans perdre les selections de la boite : modifier les corps fait parfois
    lacher le chemin ou l'objet choisis ; on les remet (sans declencher de reglage) s'ils ont saute."""
    voulus = {}
    try:
        voulus = {k: [e.entityToken for e in _selections(inputs.itemById(k))] for k in ('objets', 'chemin')}
    except Exception:
        pass
    avant = _en_cours['v']
    _en_cours['v'] = True
    try:
        f()
    finally:
        try:
            design = adsk.fusion.Design.cast(_app.activeProduct)
            for k, toks in voulus.items():
                sel = inputs.itemById(k)
                actuels = [e.entityToken for e in _selections(sel)]
                if actuels == toks:
                    continue
                _log('opacite : selection %s perdue (%d -> %d), remise' % (k, len(toks), len(actuels)))
                sel.clearSelection()
                for tok in toks:
                    for e in design.findEntityByToken(tok):
                        sel.addSelection(e)
                        break
        except Exception:
            _log('opacite selection erreur %s' % traceback.format_exc()[-300:])
        _en_cours['v'] = avant


def _opacite(inputs):
    """Suit la case « Masquer » : modele a 30 % tant qu'elle est cochee."""
    try:
        on = bool(inputs.itemById('masquer').value)

        def f():
            if on:
                _opacite_appliquer()
            else:
                _opacite_restaurer()
            _filtres_masquer(inputs, on)
        _opacite_gardant_selection(inputs, f)
    except Exception:
        _log('opacite erreur %s' % traceback.format_exc()[-300:])


def _ov_oeil(vp, pos):
    """Indice de la ligne dont l'icone œil est sous le curseur, sinon None."""
    i = _ov_ligne(vp, pos)
    if i is None:
        return None
    k = _dpr()
    actif = all(_ov.get('oeils', [])) if i < 0 else (i < len(_ov.get('oeils', [])) and _ov['oeils'][i])
    ex = _ov.get('exts', [])
    etendue = any(ex) if i < 0 else (i < len(ex) and ex[i])
    a, b = (OV_A0, OV_A1) if etendue else (OV_O0, OV_O1)
    return i if OV_X + a * k <= pos.x <= OV_X + b * k else None


def _ov_croix(vp, pos):
    """Indice de la ligne (-1 : « TOUT ») dont l'œil barre est sous le curseur, sinon None."""
    i = _ov_ligne(vp, pos)
    if i is None:
        return None
    ex = _ov.get('exts', [])
    actif = any(ex) if i < 0 else (i < len(ex) and ex[i])
    k = _dpr()
    return i if actif and OV_X + OV_X0 * k <= pos.x <= OV_X + OV_X1 * k else None


def _masquer_maj(inputs, gs):
    """Apres un changement d'œil : case Masquer, opacite, fleches, barres et cases a jour."""
    _update_visibility(inputs)
    _opacite(inputs)
    _ctx['ok'] = False
    if gs:
        _placer_fleches_multi(inputs, gs)
    elif inputs.itemById('chemin').selectionCount:
        _placer_fleche(inputs)
    _sync_barres(inputs)
    if gs:
        _apercu_multi(inputs, gs)
    else:
        _orange['cle'] = None
        try:
            _apercu_orange(inputs, rapide=True)
            _maj_marqueurs(inputs)
        except Exception:
            pass


def _ov_oeil_bascule(inputs, i):
    """Clic sur un œil : « Masquer » pour ce chemin (i), ou pour tous (i = -1, ligne « TOUT »)."""
    _en_cours['v'] = True
    try:
        m = inputs.itemById('masquer')
        gs = _multi(inputs)
        if gs:
            cles = [g['key'] for g in gs]
            if i < 0:
                if set(cles) <= _oeil:
                    _oeil.clear()
                else:
                    _oeil.update(cles)
            elif i < len(cles):
                _oeil.symmetric_difference_update({cles[i]})
            m.value = bool(_oeil)
        else:
            m.value = not m.value
        _masquer_maj(inputs, gs)
    finally:
        _en_cours['v'] = False
    _rafraichir()


def _ov_croix_clic(inputs, i):
    """Clic sur l'œil barre : tous les corps masques de ce chemin (i) ou de tous (-1) reviennent,
    et l'œil retourne a sa place."""
    _en_cours['v'] = True
    try:
        m = inputs.itemById('masquer')
        gs = _multi(inputs)
        if gs:
            cles = [g['key'] for g in gs]
            vises = cles if i < 0 else ([cles[i]] if i < len(cles) else [])
            for c in vises:
                _gmasq.pop(c, None)
                _oeil.discard(c)
            m.value = bool(_oeil)
        else:
            inputs.itemById('masques').value = ''
            m.value = False
        _masquer_maj(inputs, gs)
    finally:
        _en_cours['v'] = False
    _rafraichir()


def _ov_haut(vp, pos):
    """Indice de la ligne dont le bouton fleches haut / bas (tenon du haut) est sous le curseur."""
    i = _ov_ligne(vp, pos)
    if i is None or i < 0:
        return None
    k = _dpr()
    return i if OV_X + OV_T0 * k <= pos.x <= OV_X + OV_T1 * k else None


def _ov_pivot(vp, pos):
    """Indice de la ligne dont le bouton face / champ est sous le curseur."""
    i = _ov_ligne(vp, pos)
    if i is None or i < 0:
        return None
    k = _dpr()
    return i if OV_X + OV_F0 * k <= pos.x <= OV_X + OV_F1 * k else None


def _ov_fin(vp, pos):
    """Indice de la ligne dont le bouton « jusqu'au bout » est sous le curseur, sinon None."""
    i = _ov_ligne(vp, pos)
    if i is None or i < 0:
        return None
    k = _dpr()
    return i if OV_X + OV_E0 * k <= pos.x <= OV_X + OV_E1 * k else None


def _ov_fin_aller(inputs, i):
    """Clic sur la fleche-bouton : la derniere copie de ce chemin va jusqu'au bout."""
    if _nb_auto(inputs):
        return
    _en_cours['v'] = True
    try:
        gs = _multi(inputs)
        if gs:
            if i < len(gs):
                _choisir_chemin(inputs, gs[i]['key'])
                _gfin.pop(gs[i]['key'], None)
                gs = _multi(inputs)
                _placer_fleches_multi(inputs, gs)
                _apercu_multi(inputs, gs)
        else:
            inputs.itemById('fin_chemin').value = True
            ch = _chemin_cache(_ents_actifs(inputs))
            s0 = _s0_dialogue(inputs, ch.longueur)
            reste = abs(_bout_inputs(inputs, ch, s0) - s0)
            if _dd_key(inputs.itemById('repartition'), REPARTITIONS) == 'espacement':
                reste /= _n_pas(inputs)
            inputs.itemById('distance').value = reste
            _ctx['ok'] = False
            _placer_fleche(inputs, ch)
        _sync_barres(inputs)
    finally:
        _en_cours['v'] = False
    _rafraichir()


def _ov_sym_bascule(inputs, i):
    """Clic sur S : la symetrie s'active / se desactive pour ce chemin."""
    if not _mode_debut(inputs) or _nb_auto(inputs):
        return
    _en_cours['v'] = True
    try:
        _groupes_calc(inputs)
        items = _gstat['items']
        if items and i < len(items):
            key = items[i][1]
            if len(items) > 1:
                _choisir_chemin(inputs, key)
            elif _chemin_sel['key'] is None:
                _chemin_sel['key'] = key
            reg = _reg_chemin(inputs, key)
            reg['direction'] = 'une' if reg['direction'] == 'symetrique' else 'symetrique'
            _charger_boite(inputs, reg)
            _gfin.pop(key, None)
            _sel_ver['v'] += 1
            _ctx['ok'] = False
            _maj_chemin(inputs, recaler=True)
            gs = _multi(inputs)
            if gs:
                _placer_fleches_multi(inputs, gs)
                _apercu_multi(inputs, gs)
            else:
                _orange['cle'] = None      # un seul chemin : l'apercu orange est redessine tout de suite
                try:
                    _apercu_orange(inputs, rapide=True)
                    _maj_marqueurs(inputs)
                except Exception:
                    _log('apercu un chemin erreur %s' % traceback.format_exc()[-300:])
            _sync_barres(inputs)
    finally:
        _en_cours['v'] = False
    _rafraichir()


def _ov_pivot_bascule(inputs, i):
    """Clic sur face / champ : ce chemin passe de la face (pivoter) au champ, ou l'inverse."""
    if not _mode_debut(inputs):
        return
    _en_cours['v'] = True
    try:
        _groupes_calc(inputs)
        items = _gstat['items']
        if items and i < len(items):
            key = items[i][1]
            if len(items) > 1:
                _choisir_chemin(inputs, key)
            elif _chemin_sel['key'] is None:
                _chemin_sel['key'] = key
            reg = _reg_chemin(inputs, key)
            reg['pivot'] = not reg.get('pivot', False)
            _charger_boite(inputs, reg)
            _gfin.pop(key, None)
            _sel_ver['v'] += 1
            _ctx['ok'] = False
            _maj_chemin(inputs, recaler=True)
            gs = _multi(inputs)
            if gs:
                _placer_fleches_multi(inputs, gs)
                _apercu_multi(inputs, gs)
            else:
                _orange['cle'] = None
                try:
                    _apercu_orange(inputs, rapide=True)
                    _maj_marqueurs(inputs)
                except Exception:
                    _log('apercu un chemin erreur %s' % traceback.format_exc()[-300:])
            _sync_barres(inputs)
    finally:
        _en_cours['v'] = False
    _rafraichir()


def _ov_haut_bascule(inputs, i):
    """Clic sur les fleches haut / bas : la traverse de ce chemin passe sur son tenon du haut (ou du bas)."""
    if not _mode_debut(inputs):
        return
    _en_cours['v'] = True
    try:
        _groupes_calc(inputs)
        items = _gstat['items']
        if items and i < len(items):
            key = items[i][1]
            if len(items) > 1:
                _choisir_chemin(inputs, key)
            elif _chemin_sel['key'] is None:
                _chemin_sel['key'] = key
            reg = _reg_chemin(inputs, key)
            reg['tenon_haut'] = not reg.get('tenon_haut', False)
            _charger_boite(inputs, reg)
            _gfin.pop(key, None)
            _sel_ver['v'] += 1
            _ctx['ok'] = False
            _maj_chemin(inputs, recaler=True)
            gs = _multi(inputs)
            if gs:
                _placer_fleches_multi(inputs, gs)
                _apercu_multi(inputs, gs)
            else:
                _orange['cle'] = None      # un seul chemin : l'apercu orange est redessine tout de suite
                try:
                    _apercu_orange(inputs, rapide=True)
                    _maj_marqueurs(inputs)
                except Exception:
                    _log('apercu un chemin erreur %s' % traceback.format_exc()[-300:])
            _sync_barres(inputs)
    finally:
        _en_cours['v'] = False
    _rafraichir()


def _ov_choisir(inputs, i):
    """Clic sur une ligne : ce chemin devient le chemin selectionne (barre bleue)."""
    gs = _multi(inputs)
    if not gs or i >= len(gs):
        return
    _en_cours['v'] = True
    try:
        if _choisir_chemin(inputs, gs[i]['key']):
            _sync_barres(inputs)
            _apercu_multi(inputs, _multi(inputs))      # l'apercu du chemin choisi ressort
    finally:
        _en_cours['v'] = False


def _ov_glisse(inputs, pos, force=False, fin=False):
    """Glissiere bleue d'une fenetre de chemin. Pendant le glisser, aucun champ de la commande ne change
    (donc aucun cycle Fusion) : seuls l'apercu orange, les pastilles et la fenetre suivent. Au relachement
    (fin=True), la quantite est ecrite dans la commande en une fois."""
    import time
    i = _ov['on']
    if i is None or i >= len(_ov['vals']):
        return
    t = time.perf_counter()
    if not force and t - _ov['t'] < 0.012:
        return
    _ov['t'] = t
    k = _dpr()
    u = max(0.0, min(1.0, (pos.x - (OV_X + OV_B0 * k)) / float((OV_B1 - OV_B0) * k)))
    q = max(1, min(10000, _ov_q_de_t(u, _ov['qm'].get(i, QSMAX))))
    _q_vers(inputs, i, q, fin)


def _q_vers(inputs, i, q, fin=False):
    """Quantite q pour le chemin i : en direct (aucun champ ecrit) pendant le glisser, ecrite au
    relachement (fin=True). Partage par la glissiere bleue et la poignee de quantite."""
    if i is None or i >= len(_ov['vals']):
        return
    if fin:
        att = _ov.pop('attente', None)
        if att is not None and att[0] == i:
            q = att[1]
        elif q == _ov['vals'][i]:
            return
        _en_cours['v'] = True
        try:
            if att is not None:
                _ov_retablir_q(inputs, i)     # l'etat d'avant le glisser : _appliquer_q refait tout proprement
            _appliquer_q(inputs, i, q)
            _sync_barres(inputs)       # barres de la boite et ligne de la vue suivent
        finally:
            _en_cours['v'] = False
        _log('glissiere quantite : %d au relachement' % q)
        _rafraichir()
        return
    if q == _ov['vals'][i]:
        return
    _en_cours['v'] = True
    ok = False
    try:
        ok = _ov_q_rapide(inputs, i, q)
        if ok:
            _ov['attente'] = (i, q)
    except Exception:
        _log('glissiere rapide erreur %s' % traceback.format_exc()[-300:])
    finally:
        _en_cours['v'] = False
    if not ok:                             # cas non gere en direct : comme avant (ecriture a chaque cran)
        _log('glissiere : chemin lent (q=%d)' % q)
        _en_cours['v'] = True
        try:
            if _ov.pop('attente', None) is not None:
                _ov_retablir_q(inputs, i)
            _appliquer_q(inputs, i, q)
            _sync_barres(inputs)
        finally:
            _en_cours['v'] = False
    _rafraichir()


_ov_avant = {}


def _ov_q_rapide(inputs, i, q):
    """Nombre de copies change en direct, sans toucher aux champs de la commande."""
    import time
    t0 = time.perf_counter()
    gs = _multi(inputs)
    if gs:
        if i >= len(gs):
            return False
        key = gs[i]['key']
        if ('m', key) not in _ov_avant:
            _ov_avant[('m', key)] = (key in _gfin, _gfin.get(key), key in _gq, _gq.get(key))
        _gfin.setdefault(key, gs[i]['s_fin'])     # la fin du reseau ne bouge pas : les copies se resserrent
        _gq[key] = q
        gs = _multi(inputs)
        _apercu_multi(inputs, gs)
        for j, g in enumerate(gs):
            if _caf is not None and not _oeil:
                _rp_placer(j, g['ch'].point_tangente(g['s_fin'])[0])
    else:
        if not _ctx.get('ok'):
            _apercu_orange(inputs, rapide=True)    # contexte calcule une fois
        if not _ctx.get('ok'):
            return False
        if 's' not in _ov_avant:
            _ov_avant['s'] = (_ctx.get('q'), _ctx.get('npas'), _ctx.get('emax'))
        qi = inputs.itemById('quantite')
        d = inputs.itemById('distance').value
        sym = _sym_dir(inputs)
        npas_de = lambda n: max(0.5, (n - 1) / 2.0) if sym else max(1, n - 1)
        if _dd_key(inputs.itemById('repartition'), REPARTITIONS) == 'espacement':
            d = d * npas_de(int(qi.value)) / npas_de(q)    # debut -> fin conserve : seul l'espacement change
        _ctx['q'] = q
        _ctx['npas'] = npas_de(q)
        if _ctx.get('vsym'):
            _ctx['emax'] = _etendue_sym(_ctx['ch'], _ctx['objs'], q)   # symetrique : l'etendue maxi depend de q
        _apercu_orange(inputs, rapide=True, d_force=d)
    vals = list(_ov['vals'])
    vals[i] = q
    _ov_maj(vals)
    _ov.setdefault('perf', []).append(time.perf_counter() - t0)
    return True


def _ov_retablir_q(inputs, i):
    """Avant d'ecrire la valeur finale : l'etat interne revient a celui d'avant le glisser."""
    for cle, v in list(_ov_avant.items()):
        if cle == 's':
            _ctx['q'], _ctx['npas'], _ctx['emax'] = v
        else:
            key = cle[1]
            a_fin, fin, a_q, qq = v
            if a_fin:
                _gfin[key] = fin
            else:
                _gfin.pop(key, None)
            if a_q:
                _gq[key] = qq
            else:
                _gq.pop(key, None)
    _ov_avant.clear()
    pf = _ov.pop('perf', [])
    if pf:
        _log('perf glissiere : %d images, %.1f ms par image' % (len(pf), 1000 * sum(pf) / len(pf)))


_souris = {'pos': None, 'vp': None, 't': 0.0, 'n': 0}
_echant = {'cle': None, 'pts': []}


def _echantillons(ch, n=400):
    """Points du chemin tous les L/n (mis en cache pour le glisser)."""
    cle = (round(ch.longueur, 6), len(ch.segs), n)
    if _echant['cle'] != cle:
        _echant['pts'] = [(ch.longueur * k / n, ch.point_tangente(ch.longueur * k / n)[0]) for k in range(n + 1)]
        _echant['cle'] = cle
    return _echant['pts']


_scr = {'cle': None, 'pts': None}


def _ecran(ch, vp):
    """Points du chemin projetes a l'ecran (1 echantillon sur 4), gardes tant
    que la camera ne bouge pas : plus d'appel a l'API a chaque mouvement."""
    try:
        cam = vp.camera
        cle = (id(ch), tuple(round(v, 4) for v in cam.eye.asArray() + cam.target.asArray() + cam.upVector.asArray()),
               round(cam.viewExtents, 4), vp.width, vp.height)
    except Exception:
        cle = None
    if cle is None or cle != _scr['cle']:
        n, pts, _t = ch.table()
        P3 = adsk.core.Point3D.create
        res = []
        for i in range(0, n + 1, 4):
            q = vp.modelToViewSpace(P3(pts[i][0], pts[i][1], pts[i][2]))
            res.append((q.x, q.y))
        _scr['pts'] = res
        _scr['cle'] = cle
    return _scr['pts']


def _abscisse_souris(ch, lo, hi, s_prev):
    """Abscisse du point du chemin le plus proche de la souris A L'ECRAN :
    la copie suit le curseur dans les virages, comme le Reseau natif. On
    reste pres de la position precedente pour ne pas sauter d'une branche a
    une autre qui passerait sous le curseur."""
    import time
    if _souris['pos'] is None or time.perf_counter() - _souris['t'] > 0.5:
        return None
    vp, m = _souris['vp'], _souris['pos']
    ecr = _ecran(ch, vp)
    mx, my = m.x, m.y
    L = ch.longueur
    n = len(ecr) - 1
    pas = L / n
    fen = max(L * 0.15, 1.0)
    decal = (-L, 0.0, L) if ch.ferme else (0.0,)
    best = None
    for dc in decal:
        i0 = max(0, int((s_prev - dc - fen) / pas))
        i1 = min(n, int((s_prev - dc + fen) / pas) + 1)
        for i in range(i0, i1 + 1):
            sx = i * pas + dc
            if sx < lo - 1e-9 or sx > hi + 1e-9 or abs(sx - s_prev) > fen:
                continue
            d = (ecr[i][0] - mx) ** 2 + (ecr[i][1] - my) ** 2
            if best is None or d < best[0]:
                best = (d, i, dc)
    if best is None:
        return None
    _d, i, dc = best
    # affinage : projection du curseur sur les deux segments voisins
    sb, db = i * pas + dc, best[0]
    for j in (i - 1, i):
        if 0 <= j < n:
            ax, ay = ecr[j]
            bx, by = ecr[j + 1]
            ex, ey = bx - ax, by - ay
            e2 = ex * ex + ey * ey
            if e2 < 1e-12:
                continue
            t = max(0.0, min(1.0, ((mx - ax) * ex + (my - ay) * ey) / e2))
            dd = (ax + t * ex - mx) ** 2 + (ay + t * ey - my) ** 2
            if dd < db:
                db, sb = dd, (j + t) * pas + dc
    return max(lo, min(hi, sb))


# --- Glisser maison (pastilles, module cnc_apercu_fluide) ------------------------------
# Tirer la fleche native relancait tout le cycle de Fusion a chaque mouvement (~38 ms, saccades).
# Les pastilles sont tirees par mouseDown / mouseDrag / mouseUp : pendant le glisser on ne change
# aucun champ de la commande, seules les matrices des copies bougent ; la Distance est ecrite au
# relachement (un seul cycle).

_rpast = {}
_rd = {'on': False, 'tm': 0.0}


def _rp_placer(i, pe):
    if _caf is None:
        return
    try:
        g = _rpast.get(i)
        if g is None:
            g = _rpast[i] = _caf.Poignee('ReseauCNC_pastille%d' % i)
        g.placer((pe.x, pe.y, pe.z))
    except Exception:
        _log('pastille erreur %s' % traceback.format_exc()[-300:])


def _rp_cacher_depuis(n):
    for i in [k for k in _rpast if k >= n]:
        _rpast.pop(i).effacer()


def _rp_effacer():
    for g in list(_rpast.values()):
        g.effacer()
    _rpast.clear()
    if _caf is not None:
        for i in range(NB_FLECHES):
            _caf.balayer('ReseauCNC_pastille%d' % i)


def _rp_assurer(multi):
    """executePreview : remet les pastilles si Fusion les a annulees."""
    if _caf is None or _rd['on']:
        return
    try:
        if multi:
            if _oeil:
                return
            for i, ref in list(_gref.items()):
                _rp_placer(i, ref['pe'])
        elif 'pe' in _poignee_ref:
            _rp_placer(0, _poignee_ref['pe'])
    except Exception:
        pass


def _rp_recaler():
    for g in list(_rpast.values()):
        g.recaler()


# --- Poignee de quantite (2026-11-05) -----------------------------------------------
# Une pastille bleue « - + » au milieu de chaque chemin. Glissee le long du chemin : vers la droite
# de l'ecran le nombre de corps augmente, vers la gauche il diminue, avec la meme courbe que la
# glissiere bleue (1 a 20 sur les 3/4, puis jusqu'au maximum). Relachee, elle revient au milieu.
# Pendant le glisser : aucun champ ecrit (_q_vers), champs pleins (pas de rectangle), chemins remis.

_qpast = {}
_qd = {'on': False}


def _qp_chemins(inputs):
    """[(i, chemin)] : un par ligne de la fenetre des chemins."""
    if not _ov.get('vals') or _nb_auto(inputs):
        return []
    gs = _multi(inputs)
    if gs:
        return [(i, g['ch']) for i, g in enumerate(gs[:len(_ov['vals'])])]
    if not (inputs.itemById('objets').selectionCount and inputs.itemById('chemin').selectionCount):
        return []
    ch = _ctx['ch'] if _ctx.get('ok') and _ctx.get('ch') is not None else _chemin_cache(_ents_actifs(inputs))
    return [(0, ch)]


def _qp_placer(i, p):
    if _caf is None:
        return
    try:
        g = _qpast.get(i)
        if g is None:
            g = _qpast[i] = _caf.Poignee('ReseauCNC_quantite%d' % i, 'quantite')
        g.placer(p)
    except Exception:
        _log('poignee quantite erreur %s' % traceback.format_exc()[-300:])


def _qp_maj(inputs):
    """Pastilles de quantite au milieu des chemins (appele avec les fenetres de chemin)."""
    if _caf is None or _qd['on']:
        return
    try:
        items = _qp_chemins(inputs)
    except Exception:
        items = []
    for i, ch in items:
        try:
            pm = ch.point_tangente(ch.longueur / 2.0)[0]
            _qp_placer(i, (pm.x, pm.y, pm.z))
        except Exception:
            pass
    for k in [k for k in _qpast if k >= len(items)]:
        _qpast.pop(k).effacer()


def _qp_assurer():
    """executePreview : remet les pastilles de quantite si Fusion les a annulees."""
    for i, g in list(_qpast.items()):
        try:
            if g.p is not None and (g.g is None or not g.g.isValid):
                g.g = None
                g.placer(g.p)
        except Exception:
            pass


def _qp_effacer():
    for g in list(_qpast.values()):
        g.effacer()
    _qpast.clear()
    if _caf is not None:
        for i in range(NB_FLECHES):
            _caf.balayer('ReseauCNC_quantite%d' % i)


def _qp_touchee(vp, pos):
    r = 14.0 * _dpr()
    for i, g in _qpast.items():
        if g.p is None:
            continue
        q = vp.modelToViewSpace(adsk.core.Point3D.create(*g.p))
        if math.hypot(q.x - pos.x, q.y - pos.y) <= r:
            return i
    return None


def _qd_debut(ins, vp, pos):
    import time
    i = _qp_touchee(vp, pos)
    if i is None:
        return False
    ch = dict(_qp_chemins(ins)).get(i)
    if ch is None or i >= len(_ov['vals']):
        return False
    L = ch.longueur
    sm = L / 2.0
    pm, tg = ch.point_tangente(sm)
    sens = 1.0
    try:                                   # droite de l'ecran = plus de corps, quel que soit le sens du chemin
        a = vp.modelToViewSpace(pm)
        b = vp.modelToViewSpace(adsk.core.Point3D.create(pm.x + tg.x * L * 0.01, pm.y + tg.y * L * 0.01,
                                                         pm.z + tg.z * L * 0.01))
        if b.x - a.x < 0:
            sens = -1.0
    except Exception:
        pass
    _qd.clear()
    _qd.update(on=True, i=i, ch=ch, sm=sm, s=sm, sens=sens, t0=_ov_t(i, _ov['vals'][i]),
               qm=_ov['qm'].get(i, QSMAX), ins=ins, tm=0.0, n=0, calc=0.0, td=time.perf_counter())
    _souris.update(pos=pos, vp=vp, t=time.perf_counter())
    return True


def _qd_glisser(vp):
    import time
    t0 = time.perf_counter()
    if not _qd.get('on') or t0 - _qd.get('tm', 0.0) < 0.012:
        return
    _qd['tm'] = t0
    try:
        ins, ch = _qd['ins'], _qd['ch']
        if _rd_garde['sel'] is not None:
            _rd_verifier(ins)
        s = _abscisse_souris(ch, 0.0, ch.longueur, _qd['s'])
        if s is None:
            return
        _qd['s'] = s
        u = _qd['t0'] + _qd['sens'] * (s - _qd['sm']) / max(1e-9, ch.longueur / 2.0)
        u = max(0.0, min(1.0, u))
        q = max(1, min(10000, _ov_q_de_t(u, _qd['qm'])))
        p = ch.point_tangente(s)[0]
        _qp_placer(_qd['i'], (p.x, p.y, p.z))
        _q_vers(ins, _qd['i'], q)
        _ov_assurer()
        vp.refresh()
        _qd['n'] += 1
        _qd['calc'] += time.perf_counter() - t0
    except Exception:
        _log('poignee quantite glisser erreur %s' % traceback.format_exc()[-400:])


def _qd_fin(ins):
    import time
    if not _qd.get('on'):
        return
    i = _qd['i']
    n = _qd.get('n', 0)
    _log('perf poignee quantite : %d images en %.2f s, %.2f ms par image' % (
        n, time.perf_counter() - _qd.get('td', 0.0), 1000 * _qd.get('calc', 0.0) / max(1, n)))
    _qd['on'] = False
    _bloc['t'] = time.time()
    _rd_rendre(ins)
    _rd_verifier(ins, fin=True)
    _rd_garde['t'] = time.time()
    att = _ov.get('attente')
    if att is not None and att[0] == i:
        _q_vers(ins, i, att[1], fin=True)       # quantite ecrite une fois ; _sync_barres remet la pastille au milieu
    _qd.pop('ins', None)
    _qp_maj(ins)
    _rafraichir()


def _rd_proche_global(ch, lo, hi, vp, pos):
    """(abscisse, distance px) du point du chemin le plus proche du clic, sur tout le chemin."""
    ecr = _ecran(ch, vp)
    L = ch.longueur
    n = len(ecr) - 1
    if n < 1:
        return None, None
    pas = L / n
    best = None
    for dc in ((-L, 0.0, L) if ch.ferme else (0.0,)):
        for j in range(n):
            ax, ay = ecr[j]
            ex, ey = ecr[j + 1][0] - ax, ecr[j + 1][1] - ay
            e2 = ex * ex + ey * ey
            u = 0.0 if e2 < 1e-12 else max(0.0, min(1.0, ((pos.x - ax) * ex + (pos.y - ay) * ey) / e2))
            sx = (j + u) * pas + dc
            if sx < lo - 1e-9 or sx > hi + 1e-9:
                continue
            d = math.hypot(ax + u * ex - pos.x, ay + u * ey - pos.y)
            if best is None or d < best[0]:
                best = (d, sx)
    return (best[1], best[0]) if best else (None, None)


def _rd_debut(ins, vp, pos):
    """mouseDown : une pastille (ou son chemin) est attrapee ? Demarre le glisser maison."""
    if _caf is None or ins.itemById('masquer').value:
        return False
    import time
    r = 14.0 * _dpr()
    cands = []
    gs = _multi(ins)
    if gs:
        if _oeil:
            return False
        for i, ref in list(_gref.items()):
            ch, s0, inv = ref['ch'], ref['s0'], ref['inv']
            L = ch.longueur
            if ch.ferme:
                lo, hi = (s0 - L, s0) if inv else (s0, s0 + L)
            else:
                lo, hi = (0.0, s0) if inv else (s0, L)
            if ref.get('sym'):
                if inv:
                    lo = max(lo, s0 - ref['emax'])
                else:
                    hi = min(hi, s0 + ref['emax'])
            cands.append({'i': i, 'ch': ch, 's0': s0, 'lo': lo, 'hi': hi, 's': ref['s_cur'], 'pe': ref['pe'],
                          'key': ref['key'], 'multi': True})
    elif 'pe' in _poignee_ref:
        ch = _ctx['ch'] if _ctx.get('ok') else _chemin_cache(_ents_actifs(ins))
        s0 = _poignee_ref['s0']
        lo, hi = _limites(ins, ch, s0)
        cands.append({'i': 0, 'ch': ch, 's0': s0, 'lo': lo, 'hi': hi, 'pe': _poignee_ref['pe'],
                      's': _poignee_ref.get('s_cur', _poignee_ref['s_ref']), 'multi': False})
    if not cands:
        return False
    choix, saut = None, None
    for c in cands:
        q = vp.modelToViewSpace(c['pe'])
        d = math.hypot(q.x - pos.x, q.y - pos.y)
        if d <= r and (choix is None or d < choix[0]):
            choix = (d, c)
    if choix is None:
        for c in cands:
            sx, d = _rd_proche_global(c['ch'], c['lo'], c['hi'], vp, pos)
            if sx is not None and d <= r * 0.75 and (choix is None or d < choix[0]):
                choix, saut = (d, c), sx
    if choix is None:
        return False
    c = choix[1]
    if saut is not None:
        c['s'] = saut
    _rd.clear()
    _rd.update(c)
    _rd.update(on=True, tm=0.0, ins=ins, n=0, t0=time.perf_counter(), calc=0.0, pris=False,
               pd=(pos.x, pos.y), td=time.perf_counter())
    _souris.update(pos=pos, vp=vp, t=time.perf_counter())
    _effacer_pointilles()              # redessines au relachement
    if c['multi']:
        _gdrag['i'] = c['i']
        try:
            if _choisir_chemin(ins, c['key']):
                _sync_barres(ins)
        except Exception:
            pass
    _rd_appliquer(vp, c['s'])
    return True


def _rd_appliquer(vp, s):
    """Place la derniere copie a l'abscisse s : matrices des copies + pastille + redessin."""
    ins, ch = _rd['ins'], _rd['ch']
    if _rd_garde['sel'] is not None:
        _rd_verifier(ins)              # chemins vides par Fusion (clic sur l'arete) : remis AVANT l'apercu
    _rd['s'] = s
    pe = ch.point_tangente(s)[0]
    if _rd['multi']:
        ref = _gref.get(_rd['i'])
        if ref is not None:
            ref['s_cur'] = s
            ref['pe'] = pe
        _gfin[_rd['key']] = s
        gs = _multi(ins)
        if gs:
            _apercu_multi(ins, gs)
    else:
        _poignee_ref['s_cur'] = s
        d = abs(s - _rd['s0'])
        if _dd_key(ins.itemById('repartition'), REPARTITIONS) == 'espacement':
            d /= _n_pas(ins)
        _rd['d'] = d
        _apercu_orange(ins, rapide=True, d_force=d)
    _rp_placer(_rd['i'], pe)
    _ov_assurer()                      # les fenetres de chemin restent affichees pendant le glisser
    vp.refresh()                       # aucun cycle Fusion pendant le glisser : on demande le redessin


def _ov_assurer():
    """Fenetres de chemin effacees par un cycle Fusion : redessinees aussitot."""
    if not _ov.get('vals'):
        return
    try:
        ok = _ov['g'] is not None and _ov['g'].isValid
    except Exception:
        ok = False
    if not ok:
        _ov['sig'] = None
        _ov_maj(list(_ov['vals']))


def _rd_glisser(vp):
    import time
    t0 = time.perf_counter()
    if not _rd.get('on') or t0 - _rd.get('tm', 0.0) < 0.008:
        return
    _rd['tm'] = t0
    try:
        s = _abscisse_souris(_rd['ch'], _rd['lo'], _rd['hi'], _rd['s'])
        if s is None:
            return
        _rd_appliquer(vp, s)
        _rd['n'] += 1
        _rd['calc'] += time.perf_counter() - t0
    except Exception:
        _log('glisser maison erreur %s' % traceback.format_exc()[-400:])


def _rd_figer(ins):
    """Pendant le glisser, les champs de selection deja remplis sont declares PLEINS : Fusion ne lance
    pas son rectangle de selection quand le champ actif est plein (c'est pourquoi Traverse ne l'a pas)."""
    if _caf is None or _rd.get('fige') is not None:
        return
    try:
        import time
        _rd_garde['sel'] = {k: [e.entityToken for e in _selections(ins.itemById(k))] for k in ('objets', 'chemin')}
        _rd_garde['t'] = time.time()
        _rd_garde['ins'] = ins
    except Exception:
        _rd_garde['sel'] = None
    avant = _en_cours['v']
    _en_cours['v'] = True
    try:
        _rd['fige'] = _caf.selections_figer(ins, 'glisser')   # + champ actif sans focus (technique Traverse)
    except Exception:
        _rd['fige'] = None
        _log('figer erreur %s' % traceback.format_exc()[-300:])
    finally:
        _en_cours['v'] = avant
    try:                                   # diagnostic : etat des champs et des fenetres au moment d'attraper
        d = []
        for iid in ('objets', 'chemin'):
            sel = ins.itemById(iid)
            ok, mn, mx = sel.getSelectionLimits()
            d.append('%s n=%d lim=(%d,%d) focus=%s' % (iid, sel.selectionCount, mn, mx, sel.hasFocus))
        try:
            ovok = _ov['g'] is not None and _ov['g'].isValid
        except Exception:
            ovok = False
        _log('figer plein : %s | multi=%s sym=%s overlay=%s vals=%s' % (
            ', '.join(d), _rd.get('multi'), _symetrique(ins), ovok, _ov.get('vals')))
    except Exception:
        _log('figer diag erreur %s' % traceback.format_exc()[-300:])


_rd_garde = {'sel': None, 't': 0.0, 'ins': None}


def _rd_verifier(ins=None, fin=False):
    """Un double clic sur la pastille fait vider le champ chemin par Fusion (selection en chaine sur
    l'arete sous la pastille), sans que l'outil le voie : la selection d'avant le glisser est remise.
    Appele a la fin du glisser, puis aux mouvements de souris pendant 1,2 s."""
    import time
    g = _rd_garde
    if g['sel'] is None:
        return False
    actif = _rd.get('on') or _ov.get('on') is not None or _qd.get('on')   # pastille, glissiere ou quantite
    if not fin and not actif and time.time() - g['t'] > 1.2:
        g['sel'] = None
        return False
    ins = ins or g['ins']
    if ins is None:
        return False
    if actif and not fin:
        try:                               # pendant le glisser : simple comparaison des nombres (rapide)
            if all(ins.itemById(k).selectionCount == len(g['sel'].get(k, [])) for k in ('objets', 'chemin')):
                return False
        except Exception:
            return False
    try:
        abime = [k for k in ('objets', 'chemin')
                 if [e.entityToken for e in _selections(ins.itemById(k))] != g['sel'].get(k, [])]
    except Exception:
        return False
    if not abime:
        return False
    design = adsk.fusion.Design.cast(_app.activeProduct)
    avant = _en_cours['v']
    _en_cours['v'] = True
    g['remise'] = True
    try:
        for k in abime:
            sel = ins.itemById(k)
            sel.clearSelection()
            oks = []
            for tok in g['sel'].get(k, []):
                try:
                    for e in design.findEntityByToken(tok):
                        oks.append(bool(sel.addSelection(e)))
                        break
                    else:
                        oks.append('introuvable')
                except Exception as ex:
                    oks.append('erreur %s' % ex)
            _log('selection remise apres glisser (%s) : %s, n=%d' % (k, oks, sel.selectionCount))
        if not _rd.get('on') and ins.itemById('chemin').selectionCount:
            try:
                _sync_barres(ins)              # les fenetres de chemin reviennent
            except Exception:
                _log('remise selection barres erreur %s' % traceback.format_exc()[-300:])
    except Exception:
        _log('remise selection erreur %s' % traceback.format_exc()[-300:])
    finally:
        _en_cours['v'] = avant
        g['remise'] = False
    return True


def _rd_rendre(ins):
    etat = _rd.pop('fige', None)
    _log('rendre selection : etat=%s' % ('aucun' if etat is None else 'oui'))
    if _caf is None or etat is None:
        return
    avant = _en_cours['v']
    _en_cours['v'] = True
    try:
        _caf.selections_rendre(etat)
    except Exception:
        pass
    finally:
        _en_cours['v'] = avant


def _rd_fin(ins):
    """mouseUp : la valeur finale est ecrite dans la commande (un seul cycle Fusion)."""
    import time
    _rd_rendre(ins)
    _rd_verifier(ins, fin=True)
    _rd_garde['t'] = time.time()
    _rd['on'] = False
    _rd['pris'] = False
    _bloc['t'] = time.time()           # la selection faite par le relachement est encore annulee
    n = _rd.get('n', 0)
    try:
        ovok = _ov['g'] is not None and _ov['g'].isValid
    except Exception:
        ovok = False
    _log('fin glisser : overlay=%s vals=%s' % (ovok, _ov.get('vals')))
    _log('perf glisser maison : %d images en %.2f s, %.2f ms par image (calcul + redessin)' % (
        n, time.perf_counter() - _rd.get('t0', 0.0), 1000 * _rd.get('calc', 0.0) / max(1, n)))
    _en_cours['v'] = True
    try:
        if _rd['multi']:
            _gdrag['i'] = None
            gs = _multi(ins)
            if gs:
                _placer_fleches_multi(ins, gs)
                _apercu_multi(ins, gs)
                _sync_barres(ins)
        else:
            ch, s0, s = _rd['ch'], _rd['s0'], _rd['s']
            if _rd.get('d') is not None:
                ins.itemById('distance').value = _rd['d']
            _maj_case_fin(ins, ch, s0, s)
            _placer_fleche(ins)
            _dessiner_pointilles(ins)
    finally:
        _en_cours['v'] = False
    _rd.pop('ins', None)


def _poignee_tiree(inputs):
    """La fleche est tiree. La derniere copie va au point du chemin le plus
    proche de la souris a l'ecran (glisser continu dans les virages, retours
    du 2026-10-13). Sans position de souris, repli : point du chemin le plus
    proche du bout de la fleche (droite fixe), pres de la position
    precedente. La fleche est recalee sur le chemin au relachement."""
    try:
        if 'pe' not in _poignee_ref:
            return
        val = inputs.itemById('poignee').value
        import time
        m = _souris['pos'] if time.perf_counter() - _souris['t'] <= 0.5 else None
        cle = (round(m.x, 1), round(m.y, 1)) if m is not None else round(val, 6)
        if cle == _poignee_ref.get('cle'):
            return   # meme mouvement recu deux fois
        _poignee_ref['cle'] = cle
        ch = _ctx['ch'] if _ctx.get('ok') else _chemin_cache(_ents_actifs(inputs))
        s0, pe, v = (_poignee_ref[k] for k in ('s0', 'pe', 'dir'))
        s_prev = _poignee_ref.get('s_cur', _poignee_ref['s_ref'])
        lo, hi = _limites(inputs, ch, s0)
        mode = 'souris'
        s_fin = None
        try:
            s_fin = _abscisse_souris(ch, lo, hi, s_prev)
        except Exception:
            _log('souris erreur %s' % traceback.format_exc()[-400:])
        if s_fin is None:
            mode = 'fleche'
            q = adsk.core.Point3D.create(pe.x + v.x * val, pe.y + v.y * val, pe.z + v.z * val)
            w = abs(val - _poignee_ref.get('val', 0.0)) * 2.0 + 0.5
            s_fin = ch.abscisse_proche(q, max(lo, s_prev - w), min(hi, s_prev + w), n=40)
        _poignee_ref['val'] = val
        _poignee_ref['s_cur'] = s_fin
        if mode == 'souris':
            # La copie suit la souris : la fleche est recalee sur elle, sur le
            # chemin et tangente, pendant le glisser (comme le natif). Sa
            # valeur ne sert plus au calcul, donc ce recalage ne perturbe rien.
            pn, tn = ch.point_tangente(s_fin)
            vn = adsk.core.Vector3D.create(tn.x, tn.y, tn.z)
            if inputs.itemById('inverser').value:
                vn.scaleBy(-1)
            vn.normalize()
            _poignee_ref.update({'pe': pn, 'dir': vn, 's_ref': s_fin, 'val': 0.0})
            ph = inputs.itemById('poignee')
            ph.setManipulator(pn, vn)
            ph.value = 0.0
        d = abs(s_fin - s0)
        if _dd_key(inputs.itemById('repartition'), REPARTITIONS) == 'espacement':
            d /= _n_pas(inputs)
        inputs.itemById('distance').value = d
        _maj_case_fin(inputs, ch, s0, s_fin)
        _logc('poignee tiree (%s) val=%.2f -> s=%.2f distance=%.2f' % (mode, val, s_fin, d))
    except Exception:
        _log('poignee_tiree erreur %s' % traceback.format_exc()[-600:])


class _MouseHandler(adsk.core.MouseEventHandler):
    """Garde la derniere position de la souris (glisser et deplacement)."""
    def __init__(self, nom): super().__init__(); self.nom = nom
    def notify(self, args):
        try:
            import time
            _souris['pos'] = args.viewportPosition
            _souris['vp'] = args.viewport
            _souris['t'] = time.perf_counter()
            _souris['n'] += 1
            if _rd_garde['sel'] is not None and not _rd['on']:
                _rd_verifier(args.firingEvent.sender.commandInputs)
            if _qd.get('on') and self.nom == 'mouseDrag':
                _qd_glisser(args.viewport)
            elif _rd['on'] and (self.nom == 'mouseDrag' or _rd.get('pris')):
                _rd_glisser(args.viewport)     # glisser bouton enfonce, ou pastille attrapee par un clic
            elif _ov['on'] is not None and self.nom == 'mouseDrag':
                _ov_glisse(args.firingEvent.sender.commandInputs, args.viewportPosition)
            elif self.nom == 'mouseMove' and _ov['on'] is None:
                _tip_maj(args.viewport, args.viewportPosition)
            if _souris['n'] % 50 == 1:
                _logc('%s n=%d' % (self.nom, _souris['n']))
        except Exception:
            pass


def _recaler_fleche(inputs):
    """Fin du glisser : la fleche revient sur le chemin a la derniere copie."""
    if 's_cur' in _poignee_ref:
        _en_cours['v'] = True
        try:
            _placer_fleche(inputs)
        finally:
            _en_cours['v'] = False


class _MouseDownHandler(adsk.core.MouseEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            ins = args.firingEvent.sender.commandInputs
            _tip_effacer()
            _log('mouseDown diag : on=%s pris=%s fige=%s' % (_rd.get('on'), _rd.get('pris'), _rd.get('fige') is not None))
            if _rd['on'] and _rd.get('pris'):
                # pastille attrapee par un clic : ce clic la pose (aucun rectangle de selection)
                _bloquer_selection(ins)
                _rd_fin(ins)
                return
            if _ov_valider(args.viewport, args.viewportPosition):
                _bloquer_selection(ins)
                _valider_masquage(ins)
                return
            if ins.itemById('masquer').value:
                _bloquer_selection(ins)      # mode « Masquer » : un clic ne change aucune selection
                _case_down['v'] = _case_touchee(ins, args.viewport, args.viewportPosition)
            k = _ov_touche(args.viewport, args.viewportPosition)
            r = _ov_ligne(args.viewport, args.viewportPosition)
            rs = _ov_sym(args.viewport, args.viewportPosition)
            rf = _ov_fin(args.viewport, args.viewportPosition)
            rh = _ov_haut(args.viewport, args.viewportPosition)
            rv = _ov_pivot(args.viewport, args.viewportPosition)
            ro = _ov_oeil(args.viewport, args.viewportPosition)
            rx = _ov_croix(args.viewport, args.viewportPosition)
            if rx is not None:
                _bloquer_selection(ins)
                _ov_croix_clic(ins, rx)
                return
            if ro is not None:
                _bloquer_selection(ins)
                _ov_oeil_bascule(ins, ro)
                return
            if rf is not None:
                _bloquer_selection(ins)
                _ov_fin_aller(ins, rf)
                return
            if rh is not None:
                _bloquer_selection(ins)
                _ov_haut_bascule(ins, rh)
                return
            if rv is not None:
                _bloquer_selection(ins)
                _ov_pivot_bascule(ins, rv)
                return
            if rs is not None:
                _bloquer_selection(ins)
                _ov_sym_bascule(ins, rs)
                return
            if r is not None and r >= 0:
                _ov_choisir(ins, r)
            pm = _ov_pm(args.viewport, args.viewportPosition)
            if pm is not None:
                _bloquer_selection(ins)
                _ov_q_pas(ins, pm[0], pm[1])
                return
            if _ov['g'] is not None and _ov.get('nlog', 0) < 12:
                _ov['nlog'] = _ov.get('nlog', 0) + 1
                vp = args.viewport
                p0 = args.viewportPosition
                n = len(_ov['vals'])
                _log('overlay clic pos=(%.0f,%.0f) vp=%sx%s lignes=%d dpr=%.2f touche=%s' % (
                    p0.x, p0.y, vp.width, vp.height, n, _dpr(), k))
            if k is not None:
                _ov['on'] = k
                _bloquer_selection(ins)
                _rd_figer(ins)                 # champs pleins : pas de rectangle de selection pendant le glisser
                _ov_glisse(ins, args.viewportPosition, force=True)
                return
            if r is not None:
                _bloquer_selection(ins)
                return
            if args.button == adsk.core.MouseButtons.LeftMouseButton and _qpast and \
                    _qd_debut(ins, args.viewport, args.viewportPosition):
                _bloquer_selection(ins)
                _rd_figer(ins)                 # champs pleins : pas de rectangle de selection
                return
            if args.button == adsk.core.MouseButtons.LeftMouseButton and \
                    _rd_debut(ins, args.viewport, args.viewportPosition):
                _bloquer_selection(ins)
                _rd_figer(ins)
                return
            if _case_touchee(ins, args.viewport, args.viewportPosition) is not None:
                _bloquer_selection(ins)
            else:
                _bloc['sel'] = None
        except Exception:
            _log('mouseDown erreur %s' % traceback.format_exc()[-400:])


class _PreSelectHandler(adsk.core.SelectionEventHandler):
    """Rien n'est preselectionnable sous une pastille, ni pendant son glisser."""
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            if _rd_garde.get('remise'):
                return                         # remise de la selection par l'outil : toujours acceptee
            if _rd['on'] or _qd.get('on'):
                args.isSelectable = False
                return
            vp, pos = _souris.get('vp'), _souris.get('pos')
            if not (_rpast or _qpast) or vp is None or pos is None:
                return
            r = 16.0 * _dpr()
            for g in list(_rpast.values()) + list(_qpast.values()):
                if g.p is None:
                    continue
                q = vp.modelToViewSpace(adsk.core.Point3D.create(*g.p))
                if math.hypot(q.x - pos.x, q.y - pos.y) <= r:
                    args.isSelectable = False
                    return
        except Exception:
            pass


_case_down = {'v': None}


class _MouseUpHandler(adsk.core.MouseEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            _logc('mouseUp')
            ins = args.firingEvent.sender.commandInputs
            if _rd['on']:
                import time
                pd, m = _rd.get('pd'), args.viewportPosition
                if not _rd.get('pris') and pd is not None and time.perf_counter() - _rd.get('td', 0.0) < 0.4 \
                        and math.hypot(m.x - pd[0], m.y - pd[1]) < 5.0 * _dpr():
                    # appui + relachement rapide sans bouger : la pastille reste attrapee et suit la souris
                    # sans bouton (donc sans rectangle de selection) jusqu'au clic suivant
                    _rd['pris'] = True
                    _bloc['t'] = time.time()
                    _log('mouseUp diag : clic rapide, pastille prise')
                    return
                if _rd.get('pris'):
                    return
                _rd_fin(ins)
                return
            if _qd.get('on'):
                _qd_fin(ins)
                return
            if _ov['on'] is not None:
                import time
                _rd_rendre(ins)
                _rd_verifier(ins, fin=True)
                _rd_garde['t'] = time.time()
                _ov_glisse(ins, args.viewportPosition, force=True, fin=True)
                _ov['on'] = None
                return
            repli, _case_down['v'] = _case_down['v'], None
            if 's_cur' not in _poignee_ref and _gdrag['i'] is None and _clic_marqueur(
                    ins, args.viewport, args.viewportPosition, repli):
                return
            if _gdrag['i'] is not None:
                _gdrag['i'] = None
                gs = _multi(ins)
                if gs:
                    _en_cours['v'] = True
                    try:
                        _placer_fleches_multi(ins, gs)
                        _apercu_multi(ins, gs)      # remet les cases masquees
                        _sync_barres(ins)           # le bouton « jusqu'au bout » suit la fleche
                    finally:
                        _en_cours['v'] = False
                return
            _recaler_fleche(ins)
        except Exception:
            _log('mouseUp erreur %s' % traceback.format_exc()[-600:])


_pointilles = {'g': None}


def _effacer_pointilles():
    g = _pointilles['g']
    _pointilles['g'] = None
    _pointilles['l'] = None
    try:
        if g is not None and g.isValid:
            g.deleteMe()
    except Exception:
        pass


def _dessiner_pointilles(inputs):
    """Pointilles gris le long du chemin, de l'objet a la derniere copie
    (comme le Reseau natif). Une seule polyligne de 200 points, dont on ne
    fait que mettre a jour les coordonnees : tres leger a chaque mouvement."""
    try:
        if _ctx.get('ok'):
            ch, s0, inv, rep, npas = _ctx['ch'], _ctx['s0'], _ctx['inv'], _ctx['rep'], _ctx['npas']
        else:
            ch = _chemin_cache(_ents_actifs(inputs))
            s0 = _s0_dialogue(inputs, ch.longueur)
            inv = bool(inputs.itemById('inverser').value)
            rep = _dd_key(inputs.itemById('repartition'), REPARTITIONS)
            npas = _n_pas(inputs)
        d = inputs.itemById('distance').value * (npas if rep == 'espacement' else 1.0)
        s_end = s0 + (-d if inv else d)
        if not ch.ferme:
            s_end = max(0.0, min(ch.longueur, s_end))
        if abs(s_end - s0) < 1e-6:
            _effacer_pointilles()
            return
        n = 200
        pts = []
        for k in range(n + 1):
            p = ch.fast(s0 + (s_end - s0) * k / n)[0]
            pts += [p[0], p[1], p[2]]
        g, ln = _pointilles['g'], _pointilles.get('l')
        if g is not None and ln is not None and g.isValid:
            try:
                ln.coordinates.coordinatesAsDouble = _cg_pts(pts)
                return
            except Exception:
                pass
        _effacer_pointilles()
        design = adsk.fusion.Design.cast(_app.activeProduct)
        g = _cg_nouveau()
        lignes = g.addLines(adsk.fusion.CustomGraphicsCoordinates.create(_cg_pts(pts)), [], True)
        lignes.lineStylePattern = adsk.fusion.LineStylePatterns.dotLineStylePattern
        lignes.weight = 2
        lignes.color = adsk.fusion.CustomGraphicsSolidColorEffect.create(adsk.core.Color.create(110, 110, 110, 255))
        lignes.isSelectable = False
        _pointilles['g'] = g
        _pointilles['l'] = lignes
    except Exception:
        _log('pointilles erreur %s' % traceback.format_exc()[-600:])


def _lancer_natif(motcle):
    d = _cmd_native(motcle)
    if d is not None:
        try:
            d.execute()
        except Exception:
            pass


# --- Handlers ---------------------------------------------------------------

# OK cree le reseau puis rouvre aussitot la fenetre (memes objets, chemin et
# reglages) : seul Annuler ou Echap la ferme pour de bon.
_relance = {'v': None}


def _memoriser_relance(inputs):
    def jetons(iid):
        res = []
        sel = inputs.itemById(iid)
        for i in range(sel.selectionCount):
            try:
                res.append(sel.selection(i).entity.entityToken)
            except Exception:
                pass
        return res
    _relance['v'] = {
        'objets': jetons('objets'), 'chemin': jetons('chemin'),
        'cree_debut': _mode_debut(inputs),
        'decal_lat': inputs.itemById('decal_lat').value, 'decal_haut': inputs.itemById('decal_haut').value,
        'pivot': bool(inputs.itemById('pivot').value), 'tenon_haut': bool(inputs.itemById('tenon_haut').value),
        'cote_inv': bool(inputs.itemById('cote_inv').value),
        'fin_chemin': bool(inputs.itemById('fin_chemin').value),
        'nb_auto': bool(inputs.itemById('nb_auto').value), 'pas_auto': inputs.itemById('pas_auto').value,
        'masquer': bool(inputs.itemById('masquer').value), 'masques': inputs.itemById('masques').value,
    }


def _appliquer_relance(inputs):
    r = _relance['v']
    _relance['v'] = None
    if not r:
        return
    design = adsk.fusion.Design.cast(_app.activeProduct)
    for iid in ('objets', 'chemin'):
        if iid == 'chemin':
            continue     # l'objet reste choisi, on choisit un autre chemin
        sel = inputs.itemById(iid)
        for tok in r[iid]:
            try:
                for e in design.findEntityByToken(tok):
                    sel.addSelection(e)
                    break
            except Exception:
                _log('relance selection %s erreur %s' % (iid, traceback.format_exc()[-200:]))
    # « Masquer » ne se reporte pas : les numeros de copies masquees valent pour
    # le chemin qu'on vient de traiter, pas pour le suivant
    for iid in ('cree_debut', 'fin_chemin', 'nb_auto', 'pivot', 'tenon_haut', 'cote_inv'):
        inputs.itemById(iid).value = r.get(iid, False)
    inputs.itemById('pas_auto').value = r['pas_auto']
    for iid in ('decal_lat', 'decal_haut'):
        inputs.itemById(iid).value = r[iid]
    _update_visibility(inputs)
    inputs.itemById('chemin').hasFocus = True


# --- Modifier un reseau deja cree (double-clic dans la chronologie) -----------

ATTR_EDIT = 'edition'
EDIT_CMD_ID = 'ReseauTrajectoireCNC_edit'
_edition = {'v': None, 'cible': None}     # v : {blob, anciens, actif} pendant une modification
_blob = {'v': None}                       # reglages de la boite, ecrits sur chaque reseau cree


def _reglages_boite(inputs):
    """Tous les reglages de la boite : de quoi la rouvrir telle qu'elle etait."""
    def jetons(iid):
        res = []
        sel = inputs.itemById(iid)
        for i in range(sel.selectionCount):
            try:
                res.append(sel.selection(i).entity.entityToken)
            except Exception:
                pass
        return res
    b = {
        'objets': jetons('objets'), 'chemin': jetons('chemin'),
        'type_objet': _dd_key(inputs.itemById('type_objet'), TYPES_OBJET),
        'repartition': _dd_key(inputs.itemById('repartition'), REPARTITIONS),
        'direction': _dd_key(inputs.itemById('direction'), DIRECTIONS),
        'orientation': _dd_key(inputs.itemById('orientation'), ORIENTATIONS),
        'calcul': _dd_key(inputs.itemById('calcul'), CALCULS),
        'repere': _repere_cle(inputs) if not _mode_debut(inputs) else 'centre',
        'quantite': int(inputs.itemById('quantite').value),
        'inverser': bool(inputs.itemById('inverser').value),
        'cree_debut': _mode_debut(inputs), 'pivot': bool(inputs.itemById('pivot').value),
        'tenon_haut': bool(inputs.itemById('tenon_haut').value),
        'cote_inv': bool(inputs.itemById('cote_inv').value),
        'fin_chemin': bool(inputs.itemById('fin_chemin').value),
        'nb_auto': bool(inputs.itemById('nb_auto').value), 'pas_auto': inputs.itemById('pas_auto').value,
        'masquer': bool(inputs.itemById('masquer').value), 'masques': inputs.itemById('masques').value,
        'decal_lat': inputs.itemById('decal_lat').value, 'decal_haut': inputs.itemById('decal_haut').value,
        'eviter_cales': _eviter_cales(inputs), 'jeu_cales': _jeu_cales(inputs),
        'distance': inputs.itemById('distance').value, 'depart': inputs.itemById('depart').value,
        'gfin': [[list(k), v] for k, v in _gfin.items()],
        'gq': [[list(k), v] for k, v in _gq.items()],
        'gmasq': [[list(k), sorted(v)] for k, v in _gmasq.items()],
        'greg': [[list(k), v] for k, v in _greg.items()],
        'gsel': list(_chemin_sel['key']) if _chemin_sel['key'] is not None else None,
    }
    try:
        ch = _chemin_cache(_ents_actifs(inputs))
        b['L'] = ch.longueur
        b['s0'] = _s0_dialogue(inputs, ch.longueur)
    except Exception:
        pass
    return b


def _choisir(dd, items, cle):
    for i, (k, _) in enumerate(items):
        if k == cle:
            dd.listItems.item(i).isSelected = True
            return


def _appliquer_edition(inputs, b):
    """Remet dans la boite fraichement ouverte les reglages d'un reseau existant."""
    global _dernier_chemin
    design = adsk.fusion.Design.cast(_app.activeProduct)
    _choisir(inputs.itemById('type_objet'), TYPES_OBJET, b['type_objet'])
    _set_filtres_objets(inputs)
    for iid in ('objets', 'chemin'):
        sel = inputs.itemById(iid)
        for tok in b[iid]:
            try:
                r = design.findEntityByToken(tok)
                if r:
                    sel.addSelection(r[0])
            except Exception:
                _log('edition selection %s erreur %s' % (iid, traceback.format_exc()[-200:]))
    _choisir(inputs.itemById('repartition'), REPARTITIONS, b['repartition'])
    _choisir(inputs.itemById('direction'), DIRECTIONS, b['direction'])
    _choisir(inputs.itemById('orientation'), ORIENTATIONS, b['orientation'])
    _choisir(inputs.itemById('calcul'), CALCULS, b['calcul'])
    for i, (k, _) in enumerate(REPERES):
        if k == b['repere']:
            inputs.itemById('repere').listItems.item(i).isSelected = True
    for iid in ('cree_debut', 'pivot', 'fin_chemin', 'nb_auto', 'masquer', 'inverser'):
        inputs.itemById(iid).value = bool(b[iid])
    inputs.itemById('tenon_haut').value = bool(b.get('tenon_haut', False))
    inputs.itemById('cote_inv').value = bool(b.get('cote_inv', False))
    inputs.itemById('eviter_cales').value = bool(b.get('eviter_cales', False))
    inputs.itemById('jeu_cales').value = b.get('jeu_cales', JEU_CALES)
    inputs.itemById('quantite').value = b['quantite']
    inputs.itemById('masques').value = b['masques']
    for iid in ('pas_auto', 'decal_lat', 'decal_haut', 'distance', 'depart'):
        inputs.itemById(iid).value = b[iid]
    _gfin.clear()
    for k, v in b.get('gfin', []):
        _gfin[tuple(k)] = v
    _gq.clear()
    for k, v in b.get('gq', []):
        _gq[tuple(k)] = v
    _gmasq.clear()
    for k, v in b.get('gmasq', []):
        _gmasq[tuple(k)] = set(v)
    _greg.clear()
    for k, v in b.get('greg', []):
        _greg[tuple(k)] = v
    _chemin_sel['key'] = tuple(b['gsel']) if b.get('gsel') else None
    _chemin_sel['vus'] = set(_greg)
    if b.get('s0') is not None:
        _dep_exact.update({'dep': b['depart'], 's0': b['s0'], 'L': b.get('L')})
        _dernier_chemin = (round(b['L'], 6), inputs.itemById('objets').selectionCount)
    _update_visibility(inputs)
    _sel_ver['v'] += 1
    _ctx['ok'] = False
    gs = _multi(inputs)
    if inputs.itemById('masquer').value:
        if gs:
            _oeil.update(g['key'] for g in gs)
        _opacite(inputs)
    _log('edition restauree : objets=%d chemin=%d (voulus %d / %d) groupes=%s' % (
        inputs.itemById('objets').selectionCount, inputs.itemById('chemin').selectionCount,
        len(b['objets']), len(b['chemin']), len(gs) if gs else 0))
    if gs:
        _placer_fleches_multi(inputs, gs)
    elif inputs.itemById('chemin').selectionCount:
        _placer_fleche(inputs)


def _typer(ent):
    """Entite typee : la souris et les menus livrent parfois un objet brut."""
    for cls in (adsk.fusion.PathPatternFeature, adsk.fusion.MoveFeature, adsk.fusion.CopyPasteBody,
                adsk.fusion.TimelineGroup, adsk.fusion.TimelineObject):
        try:
            c = cls.cast(ent)
            if c is not None:
                # un composant actif (ex. STRUCTURE:1) livre un proxy : ses attributs
                # et son jeton sont vides, il faut l'objet natif
                nat = getattr(c, 'nativeObject', None)
                return nat if nat is not None else c
        except Exception:
            continue
    return ent


def _entrees_reseau(ent):
    """(entites de la chronologie du reseau, groupe ou None) pour une entite
    choisie dans la chronologie : le groupe « Réseau CNC », ou l'entree seule."""
    ent = _typer(ent)
    g = None
    try:
        if getattr(ent, 'isGroup', False) or isinstance(ent, adsk.fusion.TimelineGroup):
            g = adsk.fusion.TimelineGroup.cast(ent)
    except Exception:
        g = None
    if g is None:
        # timelineObject.index / parentGroup ne sont pas fiables pour une entree
        # d'un groupe : on cherche le groupe qui contient l'entite
        try:
            tok = ent.entityToken
            tl = adsk.fusion.Design.cast(_app.activeProduct).timeline
            for k in range(tl.timelineGroups.count):
                gk = tl.timelineGroups.item(k)
                items = [gk.item(n).entity for n in range(gk.count)]
                if any(x.entityToken == tok for x in items):
                    return items, gk
        except Exception:
            _log('entrees reseau erreur %s' % traceback.format_exc()[-200:])
        return [ent], None
    return [g.item(i).entity for i in range(g.count)], g


def _index_chrono(g, ents):
    """Position du reseau dans la chronologie. Groupe replie : g.index ; groupe
    deplie : g.index echoue, on prend celui de sa 1re entree ; en dernier
    recours (chronologie reculee par la commande de modification) on cherche
    l'entree dans la chronologie."""
    for lire in ((lambda: g.index), (lambda: g.item(0).index)) if g is not None \
            else ((lambda: ents[0].timelineObject.index),):
        try:
            return lire()
        except Exception:
            continue
    try:
        tl = adsk.fusion.Design.cast(_app.activeProduct).timeline
        prem = (g.item(0).entity if g is not None else ents[0]).entityToken
        for k in range(tl.count):
            o = tl.item(k)
            try:
                if not o.isGroup and o.entity.entityToken == prem:
                    return k
            except Exception:
                continue
    except Exception:
        _log('index chrono erreur %s' % traceback.format_exc()[-200:])
    return None


def _info_reseau(ent):
    """Reglages d'un de nos reseaux d'apres une entite de la chronologie, sinon None."""
    try:
        res = _entrees_reseau(ent)
        if not res:
            return None
        ents, g = res
        _log('info reseau : %d entrees, groupe=%s, types=%s' % (len(ents), g is not None,
                                                           [type(x).__name__ for x in ents][:6]))
        for e in ents:
            pp = adsk.fusion.PathPatternFeature.cast(e)
            if pp is None:
                continue
            a = pp.attributes.itemByName(ATTR_GROUPE, ATTR_EDIT)
            if a is None:
                _log('info reseau : reseau sans reglages enregistres (%s)' % pp.name)
                continue
            idx = _index_chrono(g, ents)
            if idx is None:
                _log('info reseau : position introuvable (groupe %s, %d entrees)' % (g is not None, len(ents)))
                continue
            return {'blob': json.loads(a.value), 'anciens': [x.entityToken for x in ents], 'index': idx}
    except Exception:
        _log('info reseau erreur %s' % traceback.format_exc()[-300:])
    return None


def _info_selection():
    try:
        sels = _ui.activeSelections
        _log('selection active : %d %s' % (sels.count, [type(sels.item(i).entity).__name__ for i in range(min(sels.count, 5))]))
        for i in range(sels.count):
            info = _info_reseau(sels.item(i).entity)
            if info:
                return info
    except Exception:
        _log('info selection erreur %s' % traceback.format_exc()[-300:])
    return None


def _demarrer_edition(info):
    """Recule la chronologie au debut du reseau et rouvre la boite avec ses
    reglages ; a la validation le nouveau reseau remplace l'ancien."""
    try:
        design = adsk.fusion.Design.cast(_app.activeProduct)
        try:
            _ui.activeSelections.clear()
        except Exception:
            pass
        _edition['v'] = {'blob': info['blob'], 'anciens': info['anciens'], 'actif': False}
        design.timeline.markerPosition = info['index']
        _differer(CMD_ID)
        _log('edition demarree index=%s entrees=%d' % (info['index'], len(info['anciens'])))
    except Exception:
        _edition['v'] = None
        _log('edition demarrage erreur %s' % traceback.format_exc()[-400:])


def _edition_pause(inputs):
    """Reseau en modification et on ouvre la boite « Nouvel objet » / « Modifier la piece » : la
    boite Reseau se ferme, mais la modification du reseau doit continuer a sa fermeture. On
    memorise les reglages ; la boite se rouvre ensuite avec eux (sans remettre la chronologie
    a la fin, ce qui faisait perdre le reseau, les poignees et le bouton OK)."""
    ed = _edition['v']
    if ed is None:
        return
    try:
        ed['blob'] = _reglages_boite(inputs)
    except Exception:
        _log('edition pause reglages erreur %s' % traceback.format_exc()[-300:])
    ed['actif'] = False
    _edition['pause'] = True


def _entite_par_jeton(design, tok):
    """Entite d'un jeton. Une esquisse placee APRES le curseur de la chronologie (modification
    depuis l'historique : chronologie reculee) n'est retrouvee ni par findEntityByToken ni dans
    component.sketches ; une fois la chronologie remise a la fin, on la cherche dans les esquisses."""
    rr = design.findEntityByToken(tok)
    if rr:
        return rr[0]
    for c in [design.rootComponent] + [c for c in design.allComponents]:
        for s in c.sketches:
            if s.entityToken == tok:
                return s
    return None


def _supprimer_anciens(design, tokens):
    """Supprime les entrees de l'ancien reseau (groupe deplie, de la derniere a la premiere).
    Les esquisses « Chemin du reseau » de l'ancien reseau ne sont pas retrouvees tant que la
    chronologie est reculee (elles restaient en double dans un groupe a part, 2026-11-04) :
    on remet la chronologie a la fin puis on les supprime."""
    r = design.findEntityByToken(tokens[0]) if tokens else None
    if r:
        try:
            g = r[0].timelineObject.parentGroup
            if g is not None and g.isCollapsed:
                g.isCollapsed = False
        except Exception:
            pass
    ok = True
    restes = []
    for tok in reversed(tokens):
        try:
            r = design.findEntityByToken(tok)
            if r:
                r[0].deleteMe()
            else:
                restes.append(tok)
        except Exception:
            ok = False
            _log('suppression ancien erreur %s' % traceback.format_exc()[-300:])
    if restes:
        try:
            design.timeline.moveToEnd()
        except Exception:
            pass
        for tok in restes:
            try:
                e = _entite_par_jeton(design, tok)
                if e is not None and e.deleteMe() is False:
                    ok = False
                    _log('suppression ancien : deleteMe a refuse (apres moveToEnd)')
            except Exception:
                ok = False
                _log('suppression ancien (apres moveToEnd) erreur %s' % traceback.format_exc()[-300:])
        _log('suppression ancien : %d entree(s) retrouvee(s) apres moveToEnd' % len(restes))
    return ok


# Ids des commandes de modification de fonction (double-clic dans la chronologie).
IDS_EDITION = ('FusionDcPathPatternEditCommand', 'PatternOnPath', 'FusionMoveCommand', 'MoveCommand', 'CopyPasteBodyCommand')


class _CmdStartingHandler(adsk.core.ApplicationCommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            cid = args.commandId or ''
            if cid == CMD_ID or cid == EDIT_CMD_ID or cid == NC_CMD_ID or cid in CMDS_IGNOREES or 'Undo' in cid or 'Redo' in cid:
                return
            _log('commandStarting %s' % cid)
            if _edition['v'] is not None:
                return
            if cid not in IDS_EDITION and 'Edit' not in cid:
                return
            info = _info_selection()
            if info is None:
                return
            try:
                args.isCanceled = True      # la boite native ne s'ouvre pas
            except Exception:
                _log('commandStarting : annulation impossible')
            _demarrer_edition(info)
        except Exception:
            _log('commandStarting erreur %s' % traceback.format_exc()[-300:])


class _EditCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            info = _edition['cible']
            _edition['cible'] = None
            if info:
                _demarrer_edition(info)
        except Exception:
            _log('edit created erreur %s' % traceback.format_exc()[-300:])


class _MenuHandler(adsk.core.MarkingMenuEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            info = None
            _log('menu : %d %s' % (len(args.selectedEntities), [type(e).__name__ for e in args.selectedEntities][:5]))
            for e in args.selectedEntities:
                info = _info_reseau(e)
                if info:
                    break
            if not info:
                return
            _edition['cible'] = info
            d = _ui.commandDefinitions.itemById(EDIT_CMD_ID)
            if d is not None:
                args.linearMarkingMenu.controls.addCommand(d)
        except Exception:
            _log('menu erreur %s' % traceback.format_exc()[-300:])


class _CreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            global _pending_prefs, _dernier_chemin
            _pending_prefs = None
            _dernier_chemin = None
            _clics['ents'] = {}
            _clics['t'] = {}
            _cache_ch.clear()
            _dep_exact.update({'dep': None, 's0': None, 'L': None})
            _cache_pivot.clear()
            _cache_grp.clear()
            _sel_ver['v'] += 1
            _gfin.clear()
            _gq.clear()
            _ov['qm'].clear()
            _ov_effacer()
            _s0_cache.clear()
            _mbase.clear()
            _mcoords.clear()
            _gmasq.clear()
            _greg.clear()
            _oeil.clear()
            _filt['on'] = False
            _chemin_sel.update(key=None, vus=set())
            _cle_cache.clear()
            _demi_cache.clear()
            cmd = args.command
            _log('cree')
            _ctx['ok'] = False
            _msg_vide['v'] = False
            _scr['cle'] = None
            _build_inputs(cmd)
            _log('inputs ok')
            try:
                _nc_preselection(cmd.commandInputs)
            except Exception:
                _log('preselection erreur %s' % traceback.format_exc()[-300:])
            try:
                ed = _edition['v']
                _edition['pause'] = False
                if ed is not None and not ed['actif']:
                    ed['actif'] = True
                    _appliquer_edition(cmd.commandInputs, ed['blob'])
                else:
                    avait_relance = _relance['v'] is not None
                    _appliquer_relance(cmd.commandInputs)
                    if avait_relance:
                        # Fusion remet le focus sur le 1er champ apres la creation :
                        # on le reprend une fois la fenetre affichee
                        _focus_chemin['inputs'] = cmd.commandInputs
                        _differer('@focus_chemin')
            except Exception:
                _log('relance / edition erreur %s' % traceback.format_exc()[-400:])
            for ev, h in ((cmd.inputChanged, _InputChangedHandler()),
                          (cmd.executePreview, _PreviewHandler()),
                          (cmd.validateInputs, _ValidateHandler()),
                          (cmd.execute, _ExecuteHandler()),
                          (cmd.destroy, _DestroyHandler()),
                          (cmd.mouseDown, _MouseDownHandler()),
                          (cmd.preSelect, _PreSelectHandler()),
                          (cmd.mouseUp, _MouseUpHandler()),
                          (cmd.mouseDrag, _MouseHandler('mouseDrag')),
                          (cmd.mouseMove, _MouseHandler('mouseMove')),
                          (cmd.mouseDoubleClick, _MouseHandler('mouseDoubleClick'))):
                ev.add(h)
                _handlers.append(h)
        except Exception:
            _log('cree erreur ' + traceback.format_exc()[-800:])
            _ui.messageBox('Erreur Reseau sur la trajectoire CNC:\n' + traceback.format_exc(), COMMAND_NAME)


_perf = {}


def _perf_add(nom, dt):
    """Mesure de fluidite : toutes les 40 mesures, une ligne (moyenne / maximum) dans le journal."""
    e = _perf.setdefault(nom, [0, 0.0, 0.0])
    e[0] += 1
    e[1] += dt
    e[2] = max(e[2], dt)
    if e[0] >= 40:
        _log('perf %s : %d mesures, moyenne %.1f ms, maximum %.1f ms' % (nom, e[0], e[1] / e[0] * 1000, e[2] * 1000))
        _perf[nom] = [0, 0.0, 0.0]


class _InputChangedHandler(adsk.core.InputChangedEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            inp = args.input
            inputs = inp.parentCommand.commandInputs
            iid = inp.id
            _logc('changed %s%s' % (iid, ' (ignore, reentrance)' if _en_cours['v'] else ''))
            if _en_cours['v']:
                return   # changement provoque par nos propres ecritures de valeurs
            if iid not in ('poignee', 'distance') and not iid.startswith('qs_'):
                _ctx['ok'] = False     # autre chose que la fleche : l'apercu recalcule tout
            if iid in ('objets', 'chemin') and _restaurer_selection(inputs, iid):
                return     # clic sur une case de l'apercu : rien a selectionner derriere
            if not iid.startswith('poignee') and iid != 'distance' and not iid.startswith('qs_'):
                _sel_ver['v'] += 1
            _en_cours['v'] = True
            import time
            t0 = time.perf_counter()
            try:
                self._traiter(inputs, iid, inp)
            finally:
                _en_cours['v'] = False
                if iid.startswith('poignee'):
                    _perf_add('fleche', time.perf_counter() - t0)
        except Exception:
            _log('inputChanged erreur %s' % traceback.format_exc()[-600:])

    def _traiter(self, inputs, iid, inp):
        try:
            if iid == 'type_reseau':
                nom = inp.selectedItem.name if inp.selectedItem else ''
                if 'rectangulaire' in nom:
                    _lancer_natif('RectangularPattern')
                elif 'circulaire' in nom:
                    _lancer_natif('CircularPattern')
                return
            if iid == 'biblio':
                k = inp.selectedItem.index - 1
                if k < 0:
                    _nc_etat['choix'] = None
                    _biblio_vignette(inputs, -1)
                    return
                if not _biblio_choisir(inputs, k):
                    return
                iid, inp = 'objets', inputs.itemById('objets')
                if not inputs.itemById('chemin').selectionCount:
                    # Fusion remet le focus sur le champ precedent apres le menu : on passe au chemin une fois la boite a jour
                    _focus_chemin['inputs'] = inputs
                    _differer('@focus_chemin')
            if iid == 'nc_ouvrir':
                inp.value = False
                _edition_pause(inputs)
                _differer('@nc_palette')
                return
            if iid == 'nc_modifier':
                inp.value = False
                k = inputs.itemById('biblio').selectedItem.index - 1
                liste = _nc_liste()
                if not 0 <= k < len(liste):
                    _ui.messageBox("Choisis d'abord une piece dans la bibliotheque.", 'Modifier la piece')
                    return
                if liste[k].get('src') == 'traverse':
                    # piece de Traverse sur corps : elle se modifie dans sa propre fenetre « Nouveau corps »
                    T = _module_addin('TraverseCorpsCNC')
                    if T is None or not hasattr(T, 'modifier_piece_externe'):
                        _ui.messageBox('Cette piece vient de Traverse sur corps : demarre Traverse sur corps pour la '
                                       'modifier.', 'Modifier la piece')
                        return
                    if _edition['v'] is not None:
                        _ui.messageBox('Valide d\'abord la modification du reseau, puis modifie la piece.',
                                       'Modifier la piece')
                        return
                    _nc_etat['traverse_mod'] = liste[k]['body'].entityToken
                    _differer('@nc_traverse')
                    return
                if not _nc_edition_preparer(liste[k]['body']):
                    return
                _nc_etat['dernier'] = None
                _edition_pause(inputs)
                _differer('@nc_palette')
                return
            if iid == 'type_objet':
                inputs.itemById('objets').clearSelection()
                _set_filtres_objets(inputs)
            if iid == 'chemin':
                _suivre_clics(inputs)
                _jonc_completer_selection(inputs)
            if iid == 'ignorer_jonction':
                _jonc['on'] = bool(inp.value)
                _jonc_completer_selection(inputs)
            if iid in PAR_CHEMIN and _mode_debut(inputs):
                _maj_reg(inputs)
            auto = False
            if iid in ('chemin', 'objets') and not (_edition['v'] is not None and not _edition['v'].get('actif')):
                auto = _auto_copie(inputs)
                if auto:
                    _update_visibility(inputs)
                    _gfin.clear()
            if iid in ('chemin', 'objets', 'nb_auto', 'pas_auto', 'cree_debut', 'inverser', 'repere',
                       'decal_lat', 'decal_haut', 'pivot', 'tenon_haut', 'cote_inv') and _nb_auto(inputs):
                gs = _groupes_calc(inputs)
                if gs:
                    inputs.itemById('quantite').value = max(1, gs[0]['q'])
            if iid in ('qte_regle', 'regle_qte'):
                _regle_sur_chemins(inputs, forcer=True)
                _gfin.clear()
                _sel_ver['v'] += 1
            elif iid in ('chemin', 'objets') and not (_edition['v'] is not None and not _edition['v'].get('actif')):
                _regle_sur_chemins(inputs)
            if iid in ('chemin', 'objets'):
                _log('traiter %s : maj_chemin (auto=%s)' % (iid, auto))
                _maj_chemin(inputs, recaler=auto)
                _log('traiter %s : maj_chemin fait' % iid)
            elif iid in ('nb_auto', 'pas_auto'):
                _maj_chemin(inputs, recaler=True)
            elif iid in ('repere', 'cree_debut') and not _log('changed %s -> recalage' % iid) or (iid == 'inverser' and _mode_debut(inputs)) \
                    or (iid in ('decal_lat', 'decal_haut', 'direction', 'pivot', 'tenon_haut', 'cote_inv') and _mode_debut(inputs)):
                _maj_chemin(inputs, recaler=True)
            elif iid == 'fin_chemin':
                if inp.value:
                    ch = _chemin_cache(_ents_actifs(inputs))
                    s0 = _s0_dialogue(inputs, ch.longueur)
                    reste = abs(_bout_inputs(inputs, ch, s0) - s0)
                    if _dd_key(inputs.itemById('repartition'), REPARTITIONS) == 'espacement':
                        reste /= _n_pas(inputs)
                    inputs.itemById('distance').value = reste
                    _placer_fleche(inputs, ch)
            elif iid.startswith('qs_'):
                _barre_changee(inputs, iid)
                return
            elif iid.startswith('poignee') and inputs.itemById('masquer').value:
                pass           # mode « Masquer » : la fleche ne bouge pas
            elif iid.startswith('poignee'):
                if _multi(inputs):
                    _poignee_multi(inputs, iid)
                    try:
                        ref = _gref.get(0 if iid == 'poignee' else int(iid.split('_')[1]))
                        if ref is not None and _choisir_chemin(inputs, ref['key']):
                            _sync_barres(inputs)
                            _apercu_multi(inputs, _multi(inputs))
                    except Exception:
                        pass
                else:
                    _poignee_tiree(inputs)
            elif iid == 'quantite' and _multi(inputs):
                gs = _multi(inputs)
                _appliquer_q(inputs, _idx_selection(gs), int(inp.value))
            elif iid in ('depart', 'inverser', 'distance', 'quantite', 'repartition'):
                _placer_fleche(inputs)
            if iid in ('direction', 'objets', 'chemin', 'cree_debut') and _sym_bloquee(inputs):
                inputs.itemById('direction').listItems.item(0).isSelected = True
                _ctx['ok'] = False
                _maj_chemin(inputs, recaler=True)
                import time
                if time.time() - _sym_msg['t'] > 3.0:
                    _sym_msg['t'] = time.time()
                    _ui.messageBox("Symétrie impossible : l'objet est au bout du chemin, une moitié du réseau sortirait du chemin.\n"
                               "Coche « Copier le corps » pour un réseau symétrique.")
                    _sym_msg['t'] = time.time()
            if iid in ('direction', 'chemin', 'objets', 'nb_auto', 'cree_debut') and _mode_debut(inputs) \
                    and _sym_dir(inputs) and _nb_auto(inputs):
                inputs.itemById('direction').listItems.item(0).isSelected = True
                _maj_chemin(inputs, recaler=True)
                if _mode_debut(inputs):
                    _maj_reg(inputs)
                _ui.messageBox("Symétrie impossible avec un nombre automatique.")
            if iid == 'masquer':
                gsm = _multi(inputs)
                if gsm:
                    _oeil.clear()
                    if inputs.itemById('masquer').value:
                        _oeil.update(g['key'] for g in gsm)
                _opacite(inputs)
            if iid in ('eviter_cales', 'jeu_cales'):
                _ctx['ok'] = False
                _sel_ver['v'] += 1
            if iid in ('type_objet', 'masquer', 'cree_debut', 'nb_auto', 'qte_regle', 'ignorer_jonction', 'eviter_cales'):
                _update_visibility(inputs)
            if iid in ('objets', 'cree_debut'):
                _gfin.clear()
            elif iid in ('inverser', 'decal_lat', 'decal_haut', 'direction', 'pivot', 'tenon_haut', 'cote_inv'):
                if _multi(inputs):
                    _gfin.pop(_chemin_sel['key'], None)     # seule la fin de CE chemin repart du bout
                else:
                    _gfin.clear()
            if iid in ('objets', 'cree_debut') or (iid == 'quantite' and not _multi(inputs)):
                _gq.clear()
            if not iid.startswith('poignee'):
                if iid in ('chemin', 'objets', 'cree_debut', 'nb_auto'):
                    _synchro_selection(inputs)
                gs = _multi(inputs)
                if gs:
                    _placer_fleches_multi(inputs, gs)
                else:
                    _cacher_poignees(inputs, 1)
                if not inputs.itemById('chemin').selectionCount:
                    inputs.itemById('poignee').isVisible = False
                _log('traiter %s : barres' % iid)
                _sync_barres(inputs)
                _log('traiter %s : termine' % iid)
            if iid == 'objets' and inputs.itemById('objets').selectionCount \
                    and not inputs.itemById('chemin').selectionCount:
                inputs.itemById('chemin').hasFocus = True
        except Exception:
            _log('inputChanged erreur %s' % traceback.format_exc()[-600:])


class _ValidateHandler(adsk.core.ValidateInputsEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            inputs = args.inputs
            ok = inputs.itemById('objets').selectionCount > 0 and \
                inputs.itemById('chemin').selectionCount > 0 and \
                inputs.itemById('distance').isValidExpression
            args.areInputsValid = ok
        except Exception:
            pass


class _PreviewHandler(adsk.core.CommandEventHandler):
    """Apercu = la vraie fonction Reseau de Fusion (corps gris, calcul natif :
    le plus leger meme avec beaucoup de copies). Fusion l'annule tout seul
    a chaque changement de reglage."""
    def __init__(self): super().__init__()
    def notify(self, args):
        global _pending_prefs
        inputs = args.command.commandInputs
        try:
            if _ov['vals']:
                try:
                    ok = _ov['g'] is not None and _ov['g'].isValid
                except Exception:
                    ok = False
                if not ok:
                    _log('overlay absent a l apercu : redessin %s' % _ov['vals'])
                    _ov['sig'] = None
                    _ov_maj(list(_ov['vals']))
            if _qpast:
                _qp_assurer()
            if inputs.itemById('masquer').value and _opac['liste'] and not _opacite_ok():
                _log('opacite : annulee par Fusion, remise a 30 %')
                _opacite_gardant_selection(inputs, _opacite_appliquer)       # remis a 30 % si Fusion a annule le changement
            if _DEBUG:
                _logc('preview objets=%d chemin=%d q=%s dist=%.3f' % (
                    inputs.itemById('objets').selectionCount, inputs.itemById('chemin').selectionCount,
                    inputs.itemById('quantite').value, inputs.itemById('distance').value))
            if not (inputs.itemById('objets').selectionCount and inputs.itemById('chemin').selectionCount):
                _set_msg(inputs, '')
                return
            import time
            t0 = time.perf_counter()
            gs = _multi(inputs)
            if gs:
                _effacer_pointilles()
                _apercu_multi(inputs, gs)
                _rp_assurer(True)
                _perf_add('apercu', time.perf_counter() - t0)
                if not _msg_vide['v']:
                    _set_msg(inputs, '')
                    _msg_vide['v'] = True
                return
            _apercu_orange(inputs, rapide=True)
            _rp_assurer(False)
            _maj_marqueurs(inputs)
            if _DEBUG:
                _logc('preview ok %.2f ms' % ((time.perf_counter() - t0) * 1000))
            _dessiner_pointilles(inputs)
            if not _msg_vide['v']:
                _set_msg(inputs, '')
                _msg_vide['v'] = True
        except ValueError as e:
            _log('preview ValueError %s' % e)
            _msg_vide['v'] = False
            _set_msg(inputs, str(e))
        except Exception as e:
            _log('preview erreur %s' % traceback.format_exc()[-600:])
            _msg_vide['v'] = False
            _set_msg(inputs, 'Reseau impossible avec ces reglages : ' + str(e).splitlines()[-1][:200])


GROUPE_NOM = 'Réseau CNC'


def _grouper_chronologie(tl, debut, fin=None):
    """Une utilisation de l'outil = un groupe replie dans la chronologie (comme
    les autres outils CNC Toolkit). Fusion exige 2 entrees au moins : sinon on
    renomme l'unique entree."""
    try:
        if fin is None:
            fin = tl.markerPosition - 1
        if fin > debut:
            grp = tl.timelineGroups.add(debut, fin)
            grp.name = GROUPE_NOM
            grp.isCollapsed = True
        elif fin == debut:
            tl.item(debut).name = GROUPE_NOM
        return True
    except Exception:
        _log('groupement chronologie erreur %s' % traceback.format_exc()[-400:])
        return False


# Groupement differe (2026-11-03) : apres une modification depuis l'historique,
# Fusion refuse parfois de grouper pendant l'evenement Execute (InternalValidation
# Error « feature ») alors que le meme groupement marche juste apres la fin de la
# commande. On garde les jetons de la 1re et de la derniere fonction du nouveau
# reseau ; le tick (1 s) les groupe des que la commande est finie.
_pending_groupe = {'v': None, 'essais': 0}
_pending_fin = {'v': 0}     # >0 : remettre la chronologie a la fin (echec d'une modification)


def _grouper_par_jetons(tok0, tok1):
    design = adsk.fusion.Design.cast(_app.activeProduct)
    tl = design.timeline
    r0 = design.findEntityByToken(tok0)
    r1 = design.findEntityByToken(tok1)
    if not r0 or not r1:
        _log('groupement differe : fonctions introuvables')
        return False
    i0 = r0[0].timelineObject.index
    i1 = r1[0].timelineObject.index
    if i1 < i0:
        i0, i1 = i1, i0
    try:
        if r0[0].timelineObject.parentGroup is not None:
            _log('groupement differe : deja groupe')
            return True
    except Exception:
        pass
    i1 = min(i1, tl.count - 1)          # un indice perime (fonctions supprimees depuis) ferait echouer le groupement
    ok = _grouper_chronologie(tl, i0, i1)
    _log('groupement differe %d..%d -> %s' % (i0, i1, ok))
    return ok


class _ExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        global _pending_prefs
        inputs = args.command.commandInputs
        if _edition['v'] is not None and _edition.get('pause'):
            # Fusion « execute » la commande quand une autre (Modifier la piece) la remplace :
            # en modification d'un reseau, seul OK doit valider, donc on ne cree rien ici
            _log('execute ignore : modification du reseau en pause (boite piece)')
            return
        _effacer_pointilles()
        _effacer_orange()
        _effacer_marqueurs()
        _ov_effacer()
        _opacite_gardant_selection(inputs, _opacite_restaurer)         # les corps retrouvent leur opacite avant la creation
        try:
            tl = adsk.fusion.Design.cast(_app.activeProduct).timeline
            debut = tl.markerPosition      # 1re entree creee par cette utilisation
            _blob['v'] = _reglages_boite(inputs)
            try:
                _objets_exec['tok'] = [o.entityToken for o in _selections(inputs.itemById('objets'))]
            except Exception:
                _objets_exec['tok'] = None
            gs = _groupes_calc(inputs)
            _log('execute : %d chemin(s) choisi(s), %d groupe(s)' % (
                inputs.itemById('chemin').selectionCount, len(gs) if gs else 0))
            if gs:
                for g in gs:
                    _creer_reseau(inputs, g)
            else:
                _creer_reseau(inputs)
            _objets_exec['tok'] = None
            fin = tl.markerPosition - 1
            tok_g = None
            try:
                if fin > debut:
                    tok_g = (tl.item(debut).entity.entityToken, tl.item(fin).entity.entityToken)
            except Exception:
                tok_g = None
            _blob['v'] = None
            _pending_prefs = _current_prefs(inputs)
            _memoriser_relance(inputs)
            ed = _edition['v']
            ok_suppr = True
            if ed is not None:
                # modification d'un reseau : l'ancien (apres le nouveau dans la chronologie) disparait
                # avant le groupement, sinon Fusion recalcule tout en double et refuse le groupe
                _edition['v'] = None
                _relance['v'] = None       # modification depuis l'historique : OK ferme la boite
                ok_suppr = _supprimer_anciens(adsk.fusion.Design.cast(_app.activeProduct), ed['anciens'])
            if ed is not None and tok_g is not None:
                # l'ancien reseau supprime, les indices calcules avant ne sont plus fiables : on regroupe d'apres les fonctions
                ok_grp = _grouper_par_jetons(tok_g[0], tok_g[1])
            else:
                ok_grp = _grouper_chronologie(tl, debut, fin)
            if not ok_grp and tok_g is not None:
                _pending_groupe['v'] = tok_g          # reessai quand la commande sera finie
                _pending_groupe['essais'] = 0
            _nc_remasquer()
            if ed is not None:
                tl.moveToEnd()             # chronologie remise a la fin ; la boite ne se rouvre pas
                if not ok_suppr:
                    _ui.messageBox("L'ancien reseau n'a pas pu etre supprime : d'autres fonctions de la chronologie "
                                   "(coupes, combinaisons...) utilisent ses corps. Le nouveau reseau est cree, "
                                   "supprime l'ancien a la main apres avoir change ces fonctions.", 'Reseau CNC')
        except ValueError as e:
            _objets_exec['tok'] = None
            if _edition['v'] is not None:
                _pending_fin['v'] = 3         # apres l'Annuler de Fusion
            _blob['v'] = None
            args.executeFailed = True
            args.executeFailedMessage = str(e)
        except Exception as e:
            _objets_exec['tok'] = None
            if _edition['v'] is not None:
                _pending_fin['v'] = 3         # apres l'Annuler de Fusion
            _blob['v'] = None
            args.executeFailed = True
            args.executeFailedMessage = 'Reseau impossible : ' + str(e).splitlines()[-1][:300]


class _DestroyHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        global _pending_prefs
        _log('destroy raison=%s' % args.terminationReason)
        for _f in (_ov_effacer, _effacer_pointilles, _effacer_orange, _effacer_marqueurs):
            try:
                _f()          # une etape qui echoue ne doit pas empecher les suivantes
            except Exception:
                _log('destroy nettoyage erreur %s' % traceback.format_exc()[-200:])
        _rd['on'] = False
        _rd.pop('ins', None)
        _rd_garde['sel'] = None
        _rd_garde['ins'] = None
        _ov_avant.clear()
        _ov.pop('attente', None)
        _ov.pop('perf', None)
        _qd['on'] = False
        _qd.pop('ins', None)
        _qp_effacer()
        _rp_effacer()
        try:
            _ov_effacer()
        except Exception:
            pass
        _ov['vals'] = []          # plus rien a redessiner une fois la commande fermee
        _opacite_restaurer()
        _ov['on'] = None
        _nc_remasquer()
        try:
            # la case et la regle de quantite se retiennent meme si la boite est fermee sans valider
            ins = args.command.commandInputs
            save_prefs({'qte_regle': bool(ins.itemById('qte_regle').value),
                        'regle_qte': ins.itemById('regle_qte').value})
        except Exception:
            pass
        try:
            if args.terminationReason == adsk.core.CommandTerminationReason.CompletedTerminationReason \
                    and _pending_prefs:
                save_prefs(_pending_prefs)
        except Exception:
            pass
        _pending_prefs = None
        if _edition['v'] is not None and _edition.get('pause'):
            _log('destroy : modification du reseau mise en pause (boite piece)')
        elif _edition['v'] is not None:
            # modification annulee : on revient a la fin de la chronologie, rien n'a change
            _edition['v'] = None
            _pending_fin['v'] = 3
            try:
                adsk.fusion.Design.cast(_app.activeProduct).timeline.moveToEnd()
            except Exception:
                pass
            try:
                _ov_effacer()          # chronologie remise a la fin : le groupe devient supprimable
            except Exception:
                pass
        if args.terminationReason == adsk.core.CommandTerminationReason.CompletedTerminationReason \
                and _relance['v']:
            _differer(CMD_ID)      # OK : la fenetre se rouvre
        else:
            _relance['v'] = None   # Annuler / Echap : on s'arrete


# --- Bibliotheque de corps : « Nouveau corps » -------------------------------

NC_CMD_ID = 'ReseauTrajectoireCNC_nouveau_corps'
NC_COMP = 'CNC Toolkit'                  # composant masque qui contient les corps de la bibliotheque
NC_POS = (-200.0, 200.0)                 # cm : X = -2000 mm (gauche), Y = +2000 mm
NC_GROUPE = 'Nouveau corps CNC'
ATTR_CORPS = 'corps_bibliotheque'
NC_CP = {'CP10': 1.0, 'CP15': 1.5, 'CP18': 1.8}      # epaisseurs de contreplaque (cm)


NC_PERC = (0.6, 0.8, 1.0, 1.2, 2.0)            # diametres de percement proposes (cm)
NC_PERC_NOM = 'Percement CNC'


def _nc_perc_nom(d_cm):
    mm = round(d_cm * 10.0, 2)
    return 'PERC' + ('%g' % mm).replace('.', '_')


def _nc_param_perc(design, d_cm):
    """Diametre de percement : parametre utilisateur PERCxx (xx = mm), cree s'il n'existe pas (modifiable dans Fusion)."""
    nom = _nc_perc_nom(d_cm)
    if design.allParameters.itemByName(nom) is None:
        design.userParameters.add(nom, adsk.core.ValueInput.createByReal(d_cm), 'mm', 'Diametre percement')
    return nom


def _nc_perc_liste(design):
    """Noms proposes pour le diametre : PERC6 / 8 / 10 / 12 puis les autres PERCxx du projet."""
    noms = [_nc_perc_nom(d) for d in NC_PERC]
    ups = design.userParameters
    for i in range(ups.count):
        n = ups.item(i).name
        if n.upper().startswith('PERC') and n not in noms:
            noms.append(n)
    return noms


def _nc_perc_cm(design, nom):
    p = design.allParameters.itemByName(nom)
    if p is not None:
        return p.value
    for d in NC_PERC:
        if _nc_perc_nom(d) == nom:
            return d
    return 0.8


def _nc_percement_creer(design, comp, corps, perc, larg, haut, ep_nom):
    """Trou rond traversant : esquisse « Percement CNC » (cercle sur le plan de la piece, diametre = parametre
    utilisateur PERCxx, centre cote depuis le coin bas-gauche) puis coupe d'extrusion sur ce seul corps."""
    P = adsk.core.Point3D.create
    nom_d = perc['d_nom']
    d_nom = _nc_param_perc(design, perc['d']) if not design.allParameters.itemByName(nom_d) else nom_d
    sk = comp.sketches.add(comp.xZConstructionPlane)
    sk.name = NC_PERC_NOM
    o = sk.sketchToModelSpace(P(0, 0, 0))
    ex = sk.sketchToModelSpace(P(1, 0, 0))
    ey = sk.sketchToModelSpace(P(0, 1, 0))
    sx = 1.0 if ex.x - o.x >= 0 else -1.0
    sz = 1.0 if ey.z - o.z >= 0 else -1.0
    x = larg / 2.0 if perc['centre'] else perc['x']
    y = haut / 2.0 if perc['centre'] else perc['y']
    c = sk.sketchCurves.sketchCircles.addByCenterRadius(P(sx * x, sz * y, 0), perc['d'] / 2.0)
    try:
        dd = sk.sketchDimensions.addDiameterDimension(c, P(sx * (x + perc['d']), sz * (y + perc['d']), 0))
        dd.parameter.expression = d_nom
        dx = sk.sketchDimensions.addDistanceDimension(sk.originPoint, c.centerSketchPoint,
                                                      adsk.fusion.DimensionOrientations.HorizontalDimensionOrientation,
                                                      P(sx * x / 2.0, -sz * 0.5, 0))
        dx.parameter.expression = '%.4f mm' % (x * 10.0)
        dy = sk.sketchDimensions.addDistanceDimension(sk.originPoint, c.centerSketchPoint,
                                                      adsk.fusion.DimensionOrientations.VerticalDimensionOrientation,
                                                      P(-sx * 0.5, sz * y / 2.0, 0))
        dy.parameter.expression = '%.4f mm' % (y * 10.0)
    except Exception:
        _log('percement cotes erreur %s' % traceback.format_exc()[-300:])
    ei = comp.features.extrudeFeatures.createInput(sk.profiles.item(0), adsk.fusion.FeatureOperations.CutFeatureOperation)
    ei.setSymmetricExtent(adsk.core.ValueInput.createByString('2 * ' + ep_nom), True)
    ei.participantBodies = [corps]
    f = comp.features.extrudeFeatures.add(ei)
    f.name = NC_PERC_NOM
    return d_nom


def _nc_percement_trouver(comp):
    """(esquisse, coupe) du percement d'une piece, ou (None, None)."""
    sk = ft = None
    for i in range(comp.sketches.count):
        if comp.sketches.item(i).name == NC_PERC_NOM:
            sk = comp.sketches.item(i)
    if sk is not None:
        for i in range(comp.features.extrudeFeatures.count):
            f = comp.features.extrudeFeatures.item(i)
            try:
                if f.operation == adsk.fusion.FeatureOperations.CutFeatureOperation and f.profile.parentSketch.name == NC_PERC_NOM:
                    ft = f
            except Exception:
                _log('percement recherche erreur %s' % traceback.format_exc()[-200:])
    return sk, ft


def _nc_percement_maj(design, comp, corps, perc, larg, haut, ep_nom):
    """Modification : met a jour le percement en place (cotes de l'esquisse), le retire ou le cree."""
    sk, ft = _nc_percement_trouver(comp)
    if perc is None:
        if ft is not None:
            ft.deleteMe()
        if sk is not None:
            sk.deleteMe()
        return None
    if sk is None or ft is None:
        return _nc_percement_creer(design, comp, corps, perc, larg, haut, ep_nom)
    d_nom = _nc_param_perc(design, perc['d']) if not design.allParameters.itemByName(perc['d_nom']) else perc['d_nom']
    x = larg / 2.0 if perc['centre'] else perc['x']
    y = haut / 2.0 if perc['centre'] else perc['y']
    for i in range(sk.sketchDimensions.count):
        dm = sk.sketchDimensions.item(i)
        if adsk.fusion.SketchDiameterDimension.cast(dm) is not None:
            dm.parameter.expression = d_nom
            continue
        dl = adsk.fusion.SketchLinearDimension.cast(dm)
        if dl is not None:
            v = x if dl.orientation == adsk.fusion.DimensionOrientations.HorizontalDimensionOrientation else y
            dl.parameter.expression = '%.4f mm' % (v * 10.0)
    return d_nom


def _nc_composant(design):
    """Composant « CNC Toolkit » masque, a l'ecart du modele (cree au 1er usage)."""
    root = design.rootComponent
    for i in range(root.occurrences.count):
        o = root.occurrences.item(i)
        if o.component.name == NC_COMP:
            return o
    m = adsk.core.Matrix3D.create()
    m.translation = adsk.core.Vector3D.create(NC_POS[0], NC_POS[1], 0.0)
    occ = root.occurrences.addNewComponent(m)
    occ.component.name = NC_COMP
    occ.isLightBulbOn = False
    return occ


def _cp_nom_valeur(design, ep_cm, prefere=None):
    """Audit des parametres (2026-11-16) : une epaisseur deja enregistree est reutilisee, jamais recreee. Ordre :
    le parametre attendu (prefere, puis CPxx, xx = mm) s'il a cette valeur, sinon tout autre parametre CP* de meme
    valeur ; a defaut, nom a creer CPxx (CP18, CP12_5). Si ce nom est deja pris par une AUTRE valeur (CP18 passe a
    18,3 mm), un 0 est ajoute (CP18_0 = 18,0 mm) : on ne reprend jamais une valeur fausse."""
    nom = 'CP' + ('%g' % round(ep_cm * 10.0, 2)).replace('.', '_')
    cands = []
    try:
        ups = design.userParameters
        for i in range(ups.count):
            q = ups.item(i)
            if q.name.upper().startswith('CP') and abs(q.value - ep_cm) < 1e-4:
                cands.append(q.name)
    except Exception:
        pass
    for n in (prefere, nom):
        if n and n in cands:
            return n
    if cands:
        return cands[0]
    while design.allParameters.itemByName(nom) is not None:
        nom += '0' if '_' in nom else '_0'
    return nom


def _nc_param_libre(design, ep_cm):
    """Epaisseur libre : parametre CPxx (xx = mm, ex. CP12), cree s'il n'existe pas."""
    nom = _cp_nom_valeur(design, ep_cm)          # meme valeur deja en parametre : reutilisee, jamais recreee
    if design.allParameters.itemByName(nom) is None:
        design.userParameters.add(nom, adsk.core.ValueInput.createByReal(ep_cm), 'mm', 'Epaisseur contreplaque')
    return nom


def _nc_param_ep(design, nom):
    """Parametre d'epaisseur existant, ou cree s'il s'agit de CP10 / CP15 / CP18."""
    p = design.allParameters.itemByName(nom)
    if p is None:
        if nom not in NC_CP:
            raise ValueError("Le parametre d'epaisseur « %s » n'existe pas." % nom)
        n2 = _cp_nom_valeur(design, NC_CP[nom], nom)     # meme valeur sous un autre nom : reutilisee
        p = design.allParameters.itemByName(n2)
        if p is None:
            p = design.userParameters.add(n2, adsk.core.ValueInput.createByReal(NC_CP[nom]), 'mm', 'Epaisseur contreplaque')
    return p.name


def _nc_epaisseurs(design):
    """Noms proposes pour l'epaisseur : CP10 / CP15 / CP18 puis les autres CPxx du projet."""
    noms = list(NC_CP)
    ups = design.userParameters
    for i in range(ups.count):
        n = ups.item(i).name
        if n.upper().startswith('CP') and n not in noms:
            noms.append(n)
    return noms


def _nc_nom_auto(larg, haut, ep_cm):
    def mm(v):
        return ('%.1f' % (v * 10.0)).rstrip('0').rstrip('.')
    return 'Panneau %sx%sx%s' % (mm(larg), mm(haut), mm(ep_cm))


def _nc_rect_contraintes(sk):
    """Lignes horizontales / verticales de l'esquisse rectangle : sans elles, changer une cote deforme le rectangle."""
    gc = sk.geometricConstraints
    deja = {gc.item(i).objectType.split('::')[-1] for i in range(gc.count)}
    if 'HorizontalConstraint' in deja or 'VerticalConstraint' in deja:
        return
    ls = sk.sketchCurves.sketchLines
    for i in range(ls.count):
        l = ls.item(i)
        a, b = l.startSketchPoint.geometry, l.endSketchPoint.geometry
        try:
            if abs(a.y - b.y) < 1e-6:
                gc.addHorizontal(l)
            elif abs(a.x - b.x) < 1e-6:
                gc.addVertical(l)
        except Exception:
            _log('contrainte rectangle erreur %s' % traceback.format_exc()[-200:])


def _creer_corps_bibliotheque(nom, larg, haut, ep, tenons=None, composant=False, perc=None):
    """Cree un panneau plein dans le composant masque « CNC Toolkit » : esquisse
    rectangle sur le plan Avant du composant (largeur selon X, hauteur selon Z),
    extrusion de l'epaisseur. larg, haut en cm ; ep = nom d'un parametre
    utilisateur (CP18...) ou epaisseur en cm. Un seul groupe dans la chronologie.
    tenons : None ou {'cotes': {...}, 'n', 'long', 'haut'} (cm), poses ensuite par Tenon CNC."""
    design = adsk.fusion.Design.cast(_app.activeProduct)
    tl = design.timeline
    debut = tl.markerPosition
    if larg <= 0 or haut <= 0:
        raise ValueError('Largeur et hauteur doivent etre positives.')
    P = adsk.core.Point3D.create
    occ = _nc_composant(design)
    comp = occ.component
    if composant:
        # un composant a part dans « CNC Toolkit » : il porte le corps (et ses tenons)
        sub = comp.occurrences.addNewComponent(adsk.core.Matrix3D.create())
        sub.component.name = nom
        comp = sub.component
        occ = next((occ.childOccurrences.item(i) for i in range(occ.childOccurrences.count)
                    if occ.childOccurrences.item(i).component == comp), occ)
    if isinstance(ep, str):
        ep_nom = _nc_param_ep(design, ep)
    else:
        if ep <= 0:
            raise ValueError("L'epaisseur doit etre positive.")
        ep_nom = _nc_param_libre(design, float(ep))
    sk = comp.sketches.add(comp.xZConstructionPlane)
    sk.name = nom
    o = sk.sketchToModelSpace(P(0, 0, 0))
    ex = sk.sketchToModelSpace(P(1, 0, 0))
    ey = sk.sketchToModelSpace(P(0, 1, 0))
    sx = 1.0 if ex.x - o.x >= 0 else -1.0       # la largeur part vers +X du modele
    sz = 1.0 if ey.z - o.z >= 0 else -1.0       # la hauteur monte vers +Z du modele
    lignes = sk.sketchCurves.sketchLines.addTwoPointRectangle(P(0, 0, 0), P(sx * larg, sz * haut, 0))
    coin = None
    hor = ver = None
    for i in range(lignes.count):
        l = lignes.item(i)
        a, b = l.startSketchPoint.geometry, l.endSketchPoint.geometry
        for pt in (l.startSketchPoint, l.endSketchPoint):
            g = pt.geometry
            if abs(g.x) < 1e-9 and abs(g.y) < 1e-9:
                coin = pt
        if abs(a.y - b.y) < 1e-9:
            hor = l
        else:
            ver = l
    sk.geometricConstraints.addCoincident(coin, sk.originPoint)
    _nc_rect_contraintes(sk)
    for l, orient, val in ((hor, adsk.fusion.DimensionOrientations.HorizontalDimensionOrientation, larg),
                           (ver, adsk.fusion.DimensionOrientations.VerticalDimensionOrientation, haut)):
        a, b = l.startSketchPoint.geometry, l.endSketchPoint.geometry
        txt = P((a.x + b.x) / 2.0 - sx * 0.5, (a.y + b.y) / 2.0 - sz * 0.5, 0)
        d = sk.sketchDimensions.addDistanceDimension(l.startSketchPoint, l.endSketchPoint, orient, txt)
        d.parameter.expression = '%.4f mm' % (val * 10.0)      # simple cote : pas de parametre utilisateur
    ei = comp.features.extrudeFeatures.createInput(sk.profiles.item(0), adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
    ei.setDistanceExtent(False, adsk.core.ValueInput.createByString(ep_nom))
    corps = comp.features.extrudeFeatures.add(ei).bodies.item(0)
    corps.name = nom
    if perc:
        try:
            perc = dict(perc, d_nom=_nc_percement_creer(design, comp, corps, perc, larg, haut, ep_nom))
        except Exception:
            _log('percement erreur %s' % traceback.format_exc()[-500:])
            _nc_etat_msgs.append("Le percement n'a pas pu etre cree (voir le journal).")
            perc = None
    try:
        corps.attributes.add(ATTR_GROUPE, ATTR_CORPS, json.dumps(
            {'nom': nom, 'l': larg, 'h': haut, 'ep': ep_nom, 'perc': perc, 'tenons': None if not tenons else {
                'cotes': sorted(tenons['cotes']), 'n': tenons['n'], 'long': tenons['long'], 'haut': tenons['haut']},
             'contact': _nc_contact(corps)}))      # arete de contact avec le chemin (bas de la face avant)
    except Exception:
        _log('attribut corps bibliotheque erreur %s' % traceback.format_exc()[-300:])
    fin = tl.markerPosition - 1
    try:
        if fin > debut:
            grp = tl.timelineGroups.add(debut, fin)
            grp.name = NC_GROUPE
            grp.isCollapsed = True
        elif fin == debut:
            tl.item(debut).name = NC_GROUPE
    except Exception:
        _log('groupement nouveau corps erreur %s' % traceback.format_exc()[-400:])
    if tenons and tenons['cotes']:
        _nc_tenons(design, corps, occ, tenons)
    return corps


def _nc_edition_preparer(body):
    """Memorise les valeurs actuelles de la piece pour pre-remplir la boite de modification."""
    try:
        d = json.loads(body.attributes.itemByName(ATTR_GROUPE, ATTR_CORPS).value)
        design = adsk.fusion.Design.cast(_app.activeProduct)
        p = design.allParameters.itemByName(d['ep']) if isinstance(d['ep'], str) else None
        t = d.get('tenons')
        if t:
            t = {'cotes': set(t['cotes']), 'n': t['n'], 'long': t['long'], 'haut': t['haut']}
        _nc_etat['edition'] = {'tok': body.entityToken, 'nom': d.get('nom') or body.name, 'l': d['l'], 'h': d['h'],
                               'ep': d['ep'], 'ep_cm': p.value if p is not None else 1.8, 'tenons': t, 'perc': d.get('perc')}
        return True
    except Exception:
        _log('edition preparer erreur %s' % traceback.format_exc()[-300:])
        _ui.messageBox("Cette piece ne peut pas etre modifiee (informations d'origine introuvables).", 'Modifier la piece')
        return False


def _modifier_corps_bibliotheque(tok, nom, larg, haut, ep, tenons=None, perc=None):
    """Modifie un corps de la bibliotheque en place : cotes de l'esquisse et distance d'extrusion
    (les copies et reseaux qui en dependent suivent). ep : nom de parametre ou epaisseur en cm.
    Les tenons existants sont retires puis recrees avec `tenons` (None : sans tenons)."""
    design = adsk.fusion.Design.cast(_app.activeProduct)
    e = None
    for x in _nc_liste():
        if x['body'].entityToken == tok:
            e = x
            break
    if e is None:
        raise ValueError('Piece introuvable dans la bibliotheque.')
    if larg <= 0 or haut <= 0:
        raise ValueError('Largeur et hauteur doivent etre positives.')
    corps, comp = e['body'], e['occ'].component
    if isinstance(ep, str):
        ep_nom = _nc_param_ep(design, ep)
    else:
        if ep <= 0:
            raise ValueError("L'epaisseur doit etre positive.")
        ep_nom = _nc_param_libre(design, float(ep))
    feat = None
    for i in range(comp.features.extrudeFeatures.count):
        f = comp.features.extrudeFeatures.item(i)
        if f.operation != adsk.fusion.FeatureOperations.NewBodyFeatureOperation:
            continue
        if any(f.bodies.item(j).entityToken == tok for j in range(f.bodies.count)):
            feat = f
            break
    if feat is None:
        raise ValueError("L'extrusion d'origine de la piece est introuvable.")
    sk = feat.profile.parentSketch
    _nc_rect_contraintes(sk)          # pieces creees avant ces contraintes
    for i in range(sk.sketchDimensions.count):
        d = adsk.fusion.SketchLinearDimension.cast(sk.sketchDimensions.item(i))
        if d is None:
            continue
        val = larg if d.orientation == adsk.fusion.DimensionOrientations.HorizontalDimensionOrientation else haut
        d.parameter.expression = '%.4f mm' % (val * 10.0)
    _nc_retirer_tenons(design, corps, e['occ'])
    ed = adsk.fusion.DistanceExtentDefinition.cast(feat.extentOne)
    ed.distance.expression = ep_nom
    try:
        d_nom = _nc_percement_maj(design, comp, corps, perc, larg, haut, ep_nom)
        if perc:
            perc = dict(perc, d_nom=d_nom)
    except Exception:
        _log('percement modification erreur %s' % traceback.format_exc()[-500:])
        _nc_etat_msgs.append("Le percement n'a pas pu etre modifie (voir le journal).")
    try:
        a = corps.attributes.itemByName(ATTR_GROUPE, ATTR_CORPS)
        d = json.loads(a.value)
        d.update({'nom': nom, 'l': larg, 'h': haut, 'ep': ep_nom, 'perc': perc, 'tenons': None if not (tenons and tenons['cotes']) else {
            'cotes': sorted(tenons['cotes']), 'n': tenons['n'], 'long': tenons['long'], 'haut': tenons['haut']}})
        a.value = json.dumps(d)
    except Exception:
        _log('attribut modification erreur %s' % traceback.format_exc()[-300:])
    if nom and corps.name != nom:
        corps.name = nom
        sk.name = nom
    if tenons and tenons['cotes']:
        _nc_tenons(design, corps, e['occ'], tenons)
    return corps


def _nc_retirer_tenons_restants(corps):
    """Filet de securite : les tenons que le fichier tenon_face_map.json ne connait plus (carte vidangee par un
    retrait annule avec Ctrl+Z, par ex.) restent dans la piece. On retire les extrusions « Tenon… » qui s'ajoutent
    au corps, avec leur esquisse."""
    n = 0
    try:
        comp = corps.parentComponent
        tok = corps.entityToken
        feats = []
        for i in range(comp.features.extrudeFeatures.count):
            f = comp.features.extrudeFeatures.item(i)
            if f.operation != adsk.fusion.FeatureOperations.JoinFeatureOperation or not f.name.startswith('Tenon'):
                continue
            if any(f.bodies.item(j).entityToken == tok for j in range(f.bodies.count)):
                feats.append(f)
        for f in reversed(feats):
            sk = None
            try:
                sk = f.profile.parentSketch
            except Exception:
                pass
            try:
                if f.deleteMe():
                    n += 1
            except Exception:
                _log('retrait tenons restants erreur %s' % traceback.format_exc()[-200:])
                continue
            try:
                if sk is not None and sk.isValid:
                    sk.deleteMe()
            except Exception:
                pass
    except Exception:
        _log('retrait tenons restants erreur %s' % traceback.format_exc()[-300:])
    return n


def _nc_retirer_tenons(design, corps, occ):
    """Retire les tenons poses par Tenon CNC sur le corps (le corps revient a son etat plein) et leurs traces
    dans tenon_face_map.json."""
    T = _module_addin('TenonCNC')
    if T is None:
        return
    cles = set()
    for b in (corps, corps.createForAssemblyContext(occ)):
        try:
            cles.update(T._face_map_keys_for_body(design, b.entityToken))
        except Exception:
            pass
    n, err = 0, []
    if cles:
        n, err = T._delete_tenons_for_face_keys(design, sorted(cles))
    try:
        n2, err2 = T._delete_tenon_batch_for_body(corps)      # ancien format groupe par corps
        n, err = n + n2, err + err2
    except Exception:
        pass
    for er in err:
        _log('retrait tenons erreur %s' % er)
    n3 = _nc_retirer_tenons_restants(corps)
    _log('retrait tenons : %d feature(s), %d cle(s), %d restante(s) retiree(s) par nom' % (n, len(cles), n3))


_nc_etat_msgs = []


def _module_addin(court):
    """Module d'un autre add-in CNC Toolkit deja charge par Fusion (comme ToolkitCNC._find_module)."""
    import sys
    m = sys.modules.get(court)
    if m is not None:
        return m
    for k, m in list(sys.modules.items()):
        if k.endswith(court + '_py'):
            return m
    return None


NC_COTES = (('haut', 'Haut', (0.0, 0.0, 1.0)), ('bas', 'Bas', (0.0, 0.0, -1.0)),
            ('gauche', 'Gauche', (-1.0, 0.0, 0.0)), ('droite', 'Droite', (1.0, 0.0, 0.0)))


def _nc_tenons(design, corps, occ, tenons):
    """Tenons sur les chants choisis du corps qui vient d'etre cree : Tenon CNC (create_tenons_core)."""
    TenonCNC = _module_addin('TenonCNC')
    if TenonCNC is None:
        _nc_etat_msgs.append('Tenon CNC est arrete : le corps est cree sans tenons.')
        return
    prev = design.activeOccurrence
    try:
        proxy = corps.createForAssemblyContext(occ)
        faces = []
        for cle, _, nrm in NC_COTES:
            if cle not in tenons['cotes']:
                continue
            best = None
            for i in range(proxy.faces.count):
                f = proxy.faces.item(i)
                try:
                    n = f.geometry.normal
                except Exception:
                    continue
                if n.x * nrm[0] + n.y * nrm[1] + n.z * nrm[2] > 0.99 and (best is None or f.area > best.area):
                    best = f
            if best is not None:
                faces.append(best)
        if not faces:
            return
        res = TenonCNC.create_tenons_core(
            design, faces, 'tenon', 0.0, tenons['n'], tenons['long'], tenons['haut'],
            0.5, 1.2, True, 'uniforme', 33.3, False, False)
        for m in (res or {}).get('messages', []):
            _nc_etat_msgs.append(m)
    except Exception:
        _log('tenons nouveau corps erreur %s' % traceback.format_exc()[-600:])
        _nc_etat_msgs.append('Les tenons n\'ont pas pu etre crees (voir le journal).')
    finally:
        try:
            if prev is not None:
                prev.activate()
            else:
                design.activateRootComponent()
        except Exception:
            pass


TC_G, TC_PIECE = 'TraverseCorpsCNC', 'piece'      # pieces de Traverse sur corps (bibliotheque commune)


def _nc_liste():
    """Corps de la bibliotheque : [{'nom', 'body', 'occ'}], reperes par leur attribut. Les pieces creees par
    Traverse sur corps (meme composant masque) y sont aussi, avec 'src': 'traverse' (Maxence 2026-11-14)."""
    res = []
    try:
        design = adsk.fusion.Design.cast(_app.activeProduct)
        root = design.rootComponent
        for i in range(root.occurrences.count):
            occ = root.occurrences.item(i)
            if occ.component.name != NC_COMP:
                continue
            for j in range(occ.component.bRepBodies.count):
                b = occ.component.bRepBodies.item(j)
                if b.attributes.itemByName(ATTR_GROUPE, ATTR_CORPS) is not None:
                    res.append({'nom': b.name, 'body': b, 'occ': occ, 'racine': occ})
                elif b.attributes.itemByName(TC_G, TC_PIECE) is not None:
                    res.append({'nom': b.name, 'body': b, 'occ': occ, 'racine': occ, 'src': 'traverse'})
            for c in range(occ.childOccurrences.count):         # objets crees comme composant
                sub = occ.childOccurrences.item(c)
                for j in range(sub.component.bRepBodies.count):
                    b = sub.component.bRepBodies.item(j)
                    if b.attributes.itemByName(ATTR_GROUPE, ATTR_CORPS) is not None:
                        res.append({'nom': b.name, 'body': b, 'occ': sub, 'racine': occ})
    except Exception:
        _log('liste bibliotheque erreur %s' % traceback.format_exc()[-300:])
    return res


_nc_visible = {'on': False}      # le composant a ete rallume pour pouvoir choisir un de ses corps


def _nc_remasquer():
    if not _nc_visible['on']:
        return
    _nc_visible['on'] = False
    try:
        for e in _nc_liste():
            e['racine'].isLightBulbOn = False
            break
    except Exception:
        _log('remasquer erreur %s' % traceback.format_exc()[-300:])


def _biblio_choisir(inputs, k):
    """Met le k-ieme corps de la bibliotheque comme objet du reseau."""
    liste = _nc_liste()
    if not 0 <= k < len(liste):
        return False
    e = liste[k]
    dd = inputs.itemById('type_objet')
    if _dd_key(dd, TYPES_OBJET) != 'corps':
        for i, (cle, _) in enumerate(TYPES_OBJET):
            if cle == 'corps':
                dd.listItems.item(i).isSelected = True
        _set_filtres_objets(inputs)
    sel = inputs.itemById('objets')
    sel.clearSelection()
    proxy = e['body'].createForAssemblyContext(e['occ'])
    ok = False
    try:
        sel.addSelection(proxy)
        ok = sel.selectionCount == 1
    except Exception:
        _log('biblio selection masquee erreur %s' % traceback.format_exc()[-200:])
    if not ok:
        # le composant masque refuse la selection : on l'allume le temps de la boite
        try:
            e['racine'].isLightBulbOn = True
            _nc_visible['on'] = True
            sel.clearSelection()
            sel.addSelection(proxy)
            ok = sel.selectionCount == 1
        except Exception:
            _log('biblio selection allumee erreur %s' % traceback.format_exc()[-200:])
    _log('biblio choisi %s ok=%s allume=%s' % (e['nom'], ok, _nc_visible['on']))
    _biblio_vignette(inputs, k)
    if ok:
        _nc_etat['choix'] = e['body'].entityToken
    return ok


def _biblio_vignette(inputs, k):
    """Vignette sombre de la piece choisie (cotes, epaisseur, tenons) sous la bibliotheque ; k < 0 la cache."""
    img = inputs.itemById('biblio_img')
    if img is None:
        return
    try:
        liste = _nc_liste()
        if not 0 <= k < len(liste):
            img.isVisible = False
            return
        if liste[k].get('src') == 'traverse':
            # piece de Traverse sur corps : son vrai contour (bouts, arcs, conges, pentes) et ses tenons
            t = json.loads(liste[k]['body'].attributes.itemByName(TC_G, TC_PIECE).value)
            img.imageFile = _png_apercu_profil(float(t['L']), float(t['H']), float(t.get('ep_cm') or 1.8),
                                               t.get('prof'), t.get('tenons'))
            img.isVisible = True
            return
        d = json.loads(liste[k]['body'].attributes.itemByName(ATTR_GROUPE, ATTR_CORPS).value)
        design = adsk.fusion.Design.cast(_app.activeProduct)
        ep = d['ep']
        ep = design.allParameters.itemByName(ep).value if isinstance(ep, str) else float(ep)
        t = d.get('tenons')
        if t:
            t = dict(t)
            t['cotes'] = set(t['cotes'])
        img.imageFile = _png_apercu_corps(d['l'], d['h'], ep, t, d.get('perc'))
        img.isVisible = True
    except Exception:
        _log('vignette bibliotheque erreur %s' % traceback.format_exc()[-300:])


def _nc_preselection(inputs):
    """Apres « Nouveau corps » : le corps qu'on vient de creer est deja l'objet du reseau."""
    tok = _nc_etat.get('dernier') or _nc_etat.get('choix')      # la piece qu'on vient de creer, sinon la derniere choisie
    _nc_etat['dernier'] = None
    if not tok:
        return
    liste = _nc_liste()
    for k, e in enumerate(liste):
        if e['body'].entityToken == tok:
            inputs.itemById('biblio').listItems.item(k + 1).isSelected = True
            if _biblio_choisir(inputs, k):
                _en_cours['v'] = True
                try:
                    _InputChangedHandler()._traiter(inputs, 'objets', inputs.itemById('objets'))
                finally:
                    _en_cours['v'] = False
                _focus_chemin['inputs'] = inputs
                _differer('@focus_chemin')
            return


def _nc_valeurs(ins):
    """(largeur, hauteur, epaisseur) en cm d'apres les champs de la boite Nouveau corps."""
    design = adsk.fusion.Design.cast(_app.activeProduct)
    larg, haut = ins.itemById('nc_larg').value, ins.itemById('nc_haut').value
    dd = ins.itemById('nc_ep')
    if dd.selectedItem.index == dd.listItems.count - 1:
        ep = ins.itemById('nc_ep_autre').value
    else:
        n = _nc_epaisseurs(design)[dd.selectedItem.index]
        p = design.allParameters.itemByName(n)
        ep = p.value if p is not None else NC_CP.get(n, 1.8)
    return larg, haut, ep


NC_IMG_W, NC_IMG_H = 300, 210


def _nc_segments_tenons(longueur, n, tlong):
    """(debut, fin) de chaque tenon le long d'un chant, centres et uniformement repartis."""
    n = max(1, int(n))
    tlong = min(tlong, longueur / n)
    jeu = (longueur - n * tlong) / (n + 1.0)
    return [(jeu + k * (tlong + jeu), jeu + k * (tlong + jeu) + tlong) for k in range(n)]


def _nc_trait(px, x0, y0, x1, y1, couleur, ep=2):
    """Segment dans la grille de pixels (Bresenham), epaisseur ep."""
    h, w = len(px), len(px[0])
    x0, y0, x1, y1 = int(round(x0)), int(round(y0)), int(round(x1)), int(round(y1))
    dx, dy = abs(x1 - x0), -abs(y1 - y0)
    sx, sy = (1 if x0 < x1 else -1), (1 if y0 < y1 else -1)
    err = dx + dy
    while True:
        for a in range(ep):
            for b in range(ep):
                if 0 <= y0 + b < h and 0 <= x0 + a < w:
                    px[y0 + b][x0 + a] = couleur
        if x0 == x1 and y0 == y1:
            break
        e2 = 2 * err
        if e2 >= dy:
            err += dy
            x0 += sx
        if e2 <= dx:
            err += dx
            y0 += sy


def _nc_texte(px, txt, cx, cy, couleur):
    """Texte centre sur (cx, cy) dans la grille de pixels."""
    w = len(txt) * 8
    x0 = max(2, min(len(px[0]) - w - 2, int(cx - w / 2.0)))
    y0 = max(2, min(len(px) - 12, int(cy - 5)))
    _texte_px(px, txt, x0, y0, couleur)


def _png_apercu_corps(larg, haut, ep, tenons=None, perc=None):
    """Vignette sombre du panneau (vue de face + epaisseur) avec ses trois cotes, comme le preview de Tenon CNC."""
    def mm(v):
        return ('%.1f' % (v * 10.0)).rstrip('0').rstrip('.')
    cle = 'nc_%s_%s_%s' % (mm(larg), mm(haut), mm(ep))
    if tenons and tenons['cotes']:
        cle += '_t%s_%d_%s_%s' % (''.join(sorted(c[0] for c in tenons['cotes'])), tenons['n'], mm(tenons['long']), mm(tenons['haut']))
    if perc:
        cle += '_p%s_%s_%s_%d' % (mm(perc['d']), mm(perc['x']), mm(perc['y']), 1 if perc['centre'] else 0)
    if cle in _png_cache and os.path.isfile(_png_cache[cle]):
        return _png_cache[cle]
    w, h = NC_IMG_W, NC_IMG_H
    px = [[(18, 18, 18, 255)] * w for _ in range(h)]
    marge_g, marge_d, marge_h, marge_b = 62, 14, 30, 36
    if tenons and tenons['cotes']:
        marge_b = 50
    if perc:
        marge_b += 14 if marge_b > 36 else 14
    libre_w, libre_h = w - marge_g - marge_d, h - marge_h - marge_b
    orange = (255, 140, 0, 255)
    clair = (235, 235, 235, 255)
    cotes = set(tenons['cotes']) if tenons else set()
    th = tenons['haut'] if cotes else 0.0
    tg = th if 'gauche' in cotes else 0.0
    td = th if 'droite' in cotes else 0.0
    thh = th if 'haut' in cotes else 0.0
    tb = th if 'bas' in cotes else 0.0
    # profondeur en oblique : l'epaisseur est dessinee en vraie proportion, au moins 8 px
    echelle = min(libre_w / (larg + tg + td + ep * 0.7), libre_h / (haut + thh + tb + ep * 0.7))
    dpx = max(8.0, ep * echelle * 0.7)
    echelle = min((libre_w - dpx) / (larg + tg + td), (libre_h - dpx) / (haut + thh + tb))
    rw, rh = larg * echelle, haut * echelle
    x0 = marge_g + (libre_w - rw - dpx - (tg + td) * echelle) / 2.0 + tg * echelle
    y0 = marge_h + dpx + (libre_h - rh - dpx - (thh + tb) * echelle) / 2.0 + thh * echelle
    x1, y1 = x0 + rw, y0 + rh
    # face arriere (decalee en haut a droite), aretes de profondeur, puis face avant
    for (ax, ay, bx, by) in ((x0 + dpx, y0 - dpx, x1 + dpx, y0 - dpx), (x1 + dpx, y0 - dpx, x1 + dpx, y1 - dpx),
                             (x1 + dpx, y1 - dpx, x1, y1), (x0, y0, x0 + dpx, y0 - dpx),
                             (x1, y0, x1 + dpx, y0 - dpx)):
        _nc_trait(px, ax, ay, bx, by, (150, 90, 20, 255), 1)
    for (ax, ay, bx, by) in ((x0, y0, x1, y0), (x1, y0, x1, y1), (x1, y1, x0, y1), (x0, y1, x0, y0)):
        _nc_trait(px, ax, ay, bx, by, orange, 2)
    if cotes:
        # tenons : n rectangles centres, uniformement repartis, saillie th
        for cote in cotes:
            horiz = cote in ('haut', 'bas')
            longueur = larg if horiz else haut
            segs = _nc_segments_tenons(longueur, tenons['n'], tenons['long'])
            for (d0, d1) in segs:
                if cote == 'haut':
                    r = (x0 + d0 * echelle, y0 - th * echelle, x0 + d1 * echelle, y0)
                elif cote == 'bas':
                    r = (x0 + d0 * echelle, y1, x0 + d1 * echelle, y1 + th * echelle)
                elif cote == 'gauche':
                    r = (x0 - th * echelle, y0 + d0 * echelle, x0, y0 + d1 * echelle)
                else:
                    r = (x1, y0 + d0 * echelle, x1 + th * echelle, y0 + d1 * echelle)
                for (ax, ay, bx, by) in ((r[0], r[1], r[2], r[1]), (r[2], r[1], r[2], r[3]),
                                         (r[2], r[3], r[0], r[3]), (r[0], r[3], r[0], r[1])):
                    _nc_trait(px, ax, ay, bx, by, (255, 200, 90, 255), 2)
        _nc_texte(px, '%d TENON%s - %s X %s MM' % (tenons['n'], 'S' if tenons['n'] > 1 else '', mm(tenons['long']), mm(th)), w / 2.0, h - 8, (255, 200, 90, 255))
    if perc:
        import math
        px_c = x0 + (larg / 2.0 if perc['centre'] else perc['x']) * echelle
        py_c = y1 - (haut / 2.0 if perc['centre'] else perc['y']) * echelle
        r = max(2.0, perc['d'] / 2.0 * echelle)
        for k in range(96):
            a0, a1 = 2 * math.pi * k / 96.0, 2 * math.pi * (k + 1) / 96.0
            _nc_trait(px, px_c + r * math.cos(a0), py_c + r * math.sin(a0), px_c + r * math.cos(a1), py_c + r * math.sin(a1), (255, 90, 0, 255), 2)
        _nc_trait(px, px_c - 3, py_c, px_c + 3, py_c, (255, 90, 0, 255), 1)
        _nc_trait(px, px_c, py_c - 3, px_c, py_c + 3, (255, 90, 0, 255), 1)
        _nc_texte(px, 'PERCEMENT D %s - X %s Y %s MM' % (mm(perc['d']), mm(perc['x'] if not perc['centre'] else larg / 2.0),
                                                       mm(perc['y'] if not perc['centre'] else haut / 2.0)),
                  w / 2.0, h - (22 if (tenons and tenons['cotes']) else 8), (255, 90, 0, 255))
    _nc_texte(px, mm(larg) + ' MM', (x0 + x1) / 2.0, y1 + tb * echelle + 12, clair)
    _nc_texte(px, mm(haut) + ' MM', marge_g / 2.0 - 2, (y0 + y1) / 2.0, clair)
    _nc_texte(px, mm(ep) + ' MM', x1 + dpx - 14, marge_h - 14 + 4, clair)
    return _ecrire_png(cle, px, w, h)


def _png_apercu_profil(L, H, ep, prof, tenons=()):
    """Vignette sombre d'une piece de Traverse sur corps (Maxence 2026-11-14) : son vrai contour (bouts droits, arcs,
    conges, pentes), ses tenons (cote, debut, largeur, saillie) et l'epaisseur en oblique, comme _png_apercu_corps."""
    import hashlib

    def mm(v):
        return ('%.1f' % (v * 10.0)).rstrip('0').rstrip('.')
    tenons = [tuple(t) for t in (tenons or [])]
    prof = [(float(p[0]), float(p[1])) for p in (prof or [])] or [(0.0, 0.0), (L, 0.0), (L, H), (0.0, H), (0.0, 0.0)]
    cle = 'ncp_' + hashlib.md5(json.dumps([round(L, 4), round(H, 4), round(ep, 4),
                                           [[round(x, 4), round(y, 4)] for x, y in prof],
                                           [[t[0]] + [round(float(v), 4) for v in t[1:]] for t in tenons]]).encode()).hexdigest()[:16]
    if cle in _png_cache and os.path.isfile(_png_cache[cle]):
        return _png_cache[cle]
    w, h = NC_IMG_W, NC_IMG_H
    px = [[(18, 18, 18, 255)] * w for _ in range(h)]
    marge_g, marge_d, marge_h, marge_b = 62, 14, 30, 36 if not tenons else 50
    libre_w, libre_h = w - marge_g - marge_d, h - marge_h - marge_b
    orange, clair, jaune = (255, 140, 0, 255), (235, 235, 235, 255), (255, 200, 90, 255)
    # rectangles des tenons (repere du profil : x le long, y en hauteur)
    rects = []
    for t in tenons:
        cote, a, wd, th = t[0], float(t[1]), float(t[2]), float(t[3])
        if cote == 'dessus':
            rects.append([(a, H), (a, H + th), (a + wd, H + th), (a + wd, H)])
        elif cote == 'dessous':
            rects.append([(a, 0.0), (a, -th), (a + wd, -th), (a + wd, 0.0)])
        elif cote == 'cote0':
            rects.append([(0.0, a), (-th, a), (-th, a + wd), (0.0, a + wd)])
        else:
            rects.append([(L, a), (L + th, a), (L + th, a + wd), (L, a + wd)])
    tous = prof + [p for r in rects for p in r]
    xmin, xmax = min(p[0] for p in tous), max(p[0] for p in tous)
    ymin, ymax = min(p[1] for p in tous), max(p[1] for p in tous)
    ew, eh = max(xmax - xmin, 1e-3), max(ymax - ymin, 1e-3)
    echelle = min(libre_w / (ew + ep * 0.7), libre_h / (eh + ep * 0.7))
    dpx = max(8.0, ep * echelle * 0.7)
    echelle = min((libre_w - dpx) / ew, (libre_h - dpx) / eh)
    ox = marge_g + (libre_w - dpx - ew * echelle) / 2.0
    oy = marge_h + dpx + (libre_h - dpx - eh * echelle) / 2.0

    def P(x, y):                            # y vers le haut dans le profil, vers le bas dans l'image
        return ox + (x - xmin) * echelle, oy + (ymax - y) * echelle
    # face arriere (decalee en haut a droite), aretes de profondeur aux coins, puis face avant
    for k in range(len(prof) - 1):
        (ax, ay), (bx, by) = P(*prof[k]), P(*prof[k + 1])
        _nc_trait(px, ax + dpx, ay - dpx, bx + dpx, by - dpx, (150, 90, 20, 255), 1)
    for k in range(len(prof) - 1):
        a = prof[k - 1] if k > 0 else prof[-2]
        b, c = prof[k], prof[k + 1]
        v1, v2 = (b[0] - a[0], b[1] - a[1]), (c[0] - b[0], c[1] - b[1])
        n1, n2 = math.hypot(*v1), math.hypot(*v2)
        if n1 > 1e-9 and n2 > 1e-9 and (v1[0] * v2[0] + v1[1] * v2[1]) / (n1 * n2) < 0.985:
            bx, by = P(*b)
            _nc_trait(px, bx, by, bx + dpx, by - dpx, (150, 90, 20, 255), 1)
    for k in range(len(prof) - 1):
        (ax, ay), (bx, by) = P(*prof[k]), P(*prof[k + 1])
        _nc_trait(px, ax, ay, bx, by, orange, 2)
    for r in rects:
        for k in range(4):
            (ax, ay), (bx, by) = P(*r[k]), P(*r[(k + 1) % 4])
            _nc_trait(px, ax, ay, bx, by, jaune, 2)
    if tenons:
        th = float(tenons[0][3])
        lg = float(tenons[0][2])
        _nc_texte(px, '%d TENON%s - %s X %s MM' % (len(tenons), 'S' if len(tenons) > 1 else '', mm(lg), mm(th)),
                  w / 2.0, h - 8, jaune)
    x0, y1 = P(0.0, 0.0)
    x1, y0 = P(L, H)
    _nc_texte(px, mm(L) + ' MM', (x0 + x1) / 2.0, P(0.0, ymin)[1] + 12, clair)
    _nc_texte(px, mm(H) + ' MM', marge_g / 2.0 - 2, (y0 + y1) / 2.0, clair)
    _nc_texte(px, mm(ep) + ' MM', P(xmax, ymax)[0] + dpx - 14, marge_h - 14 + 4, clair)
    return _ecrire_png(cle, px, w, h)


def _nc_remplir_dd(dd, design, defaut='CP18'):
    """Liste d'epaisseurs (CPxx du projet + « Autre… »), commune a l'epaisseur et a la hauteur des tenons."""
    for n in _nc_epaisseurs(design):
        p = design.allParameters.itemByName(n)
        cm = p.value if p is not None else NC_CP.get(n, 0.0)
        dd.listItems.add('%s (%s mm)' % (n, ('%.2f' % (cm * 10.0)).rstrip('0').rstrip('.')), n == defaut, '')
    dd.listItems.add('Autre…', False, '')


def _nc_valeur_dd(ins, dd_id, libre_id):
    """Valeur en cm d'une liste CPxx / Autre… (la valeur libre vient du champ libre_id)."""
    design = adsk.fusion.Design.cast(_app.activeProduct)
    dd = ins.itemById(dd_id)
    if dd.selectedItem.index == dd.listItems.count - 1:
        return ins.itemById(libre_id).value
    n = _nc_epaisseurs(design)[dd.selectedItem.index]
    p = design.allParameters.itemByName(n)
    return p.value if p is not None else NC_CP.get(n, 1.8)


def _nc_perc_champs(ins):
    """None si « Ajouter un percement » est decoche, sinon {'d', 'd_nom', 'centre', 'x', 'y'} (cm)."""
    if not ins.itemById('nc_perc').value:
        return None
    design = adsk.fusion.Design.cast(_app.activeProduct)
    dd = ins.itemById('nc_p_dd')
    if dd.selectedItem.index == dd.listItems.count - 1:
        d = ins.itemById('nc_p_autre').value
        d_nom = _nc_perc_nom(d)
    else:
        d_nom = _nc_perc_liste(design)[dd.selectedItem.index]
        d = _nc_perc_cm(design, d_nom)
    centre = bool(ins.itemById('nc_p_centre').value)
    larg, haut = ins.itemById('nc_larg').value, ins.itemById('nc_haut').value
    return {'d': d, 'd_nom': d_nom, 'centre': centre,
            'x': larg / 2.0 if centre else ins.itemById('nc_p_x').value,
            'y': haut / 2.0 if centre else ins.itemById('nc_p_y').value}


def _nc_alerte_perc(ins):
    p = _nc_perc_champs(ins)
    if not p:
        return ''

    def mm(v):
        return ('%.1f' % (v * 10.0)).rstrip('0').rstrip('.')
    larg, haut, _ = _nc_valeurs(ins)
    r = p['d'] / 2.0
    if p['d'] <= 0:
        return 'Le diametre du percement doit etre positif.'
    if p['d'] >= min(larg, haut) - 1e-6 or p['x'] - r < -1e-6 or p['x'] + r > larg + 1e-6 or p['y'] - r < -1e-6 or p['y'] + r > haut + 1e-6:
        return 'Le percement (diametre %s mm en x=%s, y=%s) depasse de la piece.' % (mm(p['d']), mm(p['x']), mm(p['y']))
    return ''


def _nc_alerte(ins):
    """Texte d'avertissement si les tenons ne tiennent pas sur un chant choisi ou si le percement depasse, sinon ''."""
    ap = _nc_alerte_perc(ins)
    t = _nc_tenons_champs(ins)
    if not t or not t['cotes']:
        return ap
    larg, haut, _ = _nc_valeurs(ins)

    def mm(v):
        return ('%.1f' % (v * 10.0)).rstrip('0').rstrip('.')
    res = []
    if t['long'] <= 0 or t['haut'] <= 0:
        res.append('La longueur et la hauteur du tenon doivent etre positives.')
    else:
        for cle, nom, _ in NC_COTES:
            if cle not in t['cotes']:
                continue
            lc = larg if cle in ('haut', 'bas') else haut
            if t['long'] >= lc - 1e-6:
                res.append('Chant %s (%s mm) : un tenon de %s mm est trop long, il doit rester plus court que le chant.' % (
                    nom.lower(), mm(lc), mm(t['long'])))
    if ap:
        res.append(ap)
    return ' '.join(res)


def _nc_nmax(ins):
    """Nombre maximal de tenons qui tiennent sur tous les chants choisis (au moins 1)."""
    t = _nc_tenons_champs(ins)
    if not t or not t['cotes'] or t['long'] <= 0:
        return 50
    larg, haut, _ = _nc_valeurs(ins)
    nmax = 50
    for cle, _, _ in NC_COTES:
        if cle in t['cotes']:
            lc = larg if cle in ('haut', 'bas') else haut
            nmax = min(nmax, int((lc - 1e-6) / t['long']))
    return max(1, nmax)


def _nc_maj_champs(ins):
    """Visibilite des champs de tenons, vignette et avertissement."""
    on = bool(ins.itemById('nc_tenons').value)
    for iid in ['nc_c_' + c for c, _, _ in NC_COTES] + ['nc_t_n', 'nc_t_long', 'nc_t_hdd']:
        ins.itemById(iid).isVisible = on
    hd = ins.itemById('nc_t_hdd')
    ins.itemById('nc_t_haut').isVisible = on and hd.selectedItem.index == hd.listItems.count - 1
    sp = ins.itemById('nc_t_n')
    nmax = _nc_nmax(ins)
    try:
        if sp.value > nmax:
            sp.value = nmax               # la fleche du haut ne depasse pas ce que les chants permettent
    except Exception:
        _log('nmax tenons erreur %s' % traceback.format_exc()[-200:])
    try:
        sp.name = 'Nombre de tenons (max %d)' % nmax
    except Exception:
        pass
    pon = bool(ins.itemById('nc_perc').value)
    for iid in ('nc_p_dd', 'nc_p_centre'):
        ins.itemById(iid).isVisible = pon
    pd = ins.itemById('nc_p_dd')
    ins.itemById('nc_p_autre').isVisible = pon and pd.selectedItem.index == pd.listItems.count - 1
    man = pon and not ins.itemById('nc_p_centre').value
    ins.itemById('nc_p_x').isVisible = man
    ins.itemById('nc_p_y').isVisible = man
    al = ins.itemById('nc_alerte')
    texte = _nc_alerte(ins)
    al.text = texte
    al.isVisible = bool(texte)


def _nc_tenons_champs(ins):
    """None si « Ajouter des tenons » est decoche, sinon {'cotes', 'n', 'long', 'haut'} (cm)."""
    if not ins.itemById('nc_tenons').value:
        return None
    cotes = {cle for cle, _, _ in NC_COTES if ins.itemById('nc_c_' + cle).value}
    return {'cotes': cotes, 'n': int(ins.itemById('nc_t_n').value),
            'long': ins.itemById('nc_t_long').value, 'haut': _nc_valeur_dd(ins, 'nc_t_hdd', 'nc_t_haut')}


def _nc_apercu(ins):
    """Met a jour la vignette de la boite Nouveau corps d'apres largeur, hauteur, epaisseur."""
    try:
        larg, haut, ep = _nc_valeurs(ins)
        if larg <= 0 or haut <= 0 or ep <= 0:
            return
        ins.itemById('nc_img').imageFile = _png_apercu_corps(larg, haut, ep, _nc_tenons_champs(ins), _nc_perc_champs(ins))
    except Exception:
        _log('apercu nouveau corps erreur %s' % traceback.format_exc()[-400:])


class _NCCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            cmd = args.command
            cmd.okButtonText = 'Créer'
            ins = cmd.commandInputs
            design = adsk.fusion.Design.cast(_app.activeProduct)
            um = design.unitsManager
            ty = ins.addDropDownCommandInput('nc_type', 'Créer un', adsk.core.DropDownStyles.TextListDropDownStyle)
            ty.listItems.add('Corps', True, '')
            ty.listItems.add('Composant', False, '')
            ty.tooltip = "Corps : un panneau dans « CNC Toolkit ». Composant : le meme panneau dans son propre composant."
            ins.addStringValueInput('nc_nom', 'Nom', '').tooltip = 'Vide : nom proposé d\'après les dimensions (ex. Panneau 400x300x18).'
            ins.addValueInput('nc_larg', 'Largeur', um.defaultLengthUnits, adsk.core.ValueInput.createByReal(10.0))
            ins.addValueInput('nc_haut', 'Hauteur', um.defaultLengthUnits, adsk.core.ValueInput.createByReal(10.0))
            dd = ins.addDropDownCommandInput('nc_ep', 'Épaisseur', adsk.core.DropDownStyles.TextListDropDownStyle)
            _nc_remplir_dd(dd, design)
            dd.tooltip = "Parametre d'epaisseur du projet (cree s'il n'existe pas) ou valeur libre."
            ins.addValueInput('nc_ep_autre', 'Épaisseur libre', um.defaultLengthUnits, adsk.core.ValueInput.createByReal(1.8)).isVisible = False
            tn = ins.addBoolValueInput('nc_tenons', 'Ajouter des tenons', True, '', True)
            tn.tooltip = "Pose des tenons sur les chants choisis avec Tenon CNC, en meme temps que le corps."
            for cle, nom, _ in NC_COTES:
                ins.addBoolValueInput('nc_c_' + cle, 'Chant ' + nom.lower(), True, '', cle in ('haut', 'bas')).isVisible = False
            ins.addIntegerSpinnerCommandInput('nc_t_n', 'Nombre de tenons', 1, 50, 1, 1).isVisible = False
            ins.addValueInput('nc_t_long', 'Longueur du tenon', um.defaultLengthUnits, adsk.core.ValueInput.createByReal(3.0)).isVisible = False
            hd = ins.addDropDownCommandInput('nc_t_hdd', 'Hauteur du tenon', adsk.core.DropDownStyles.TextListDropDownStyle)
            _nc_remplir_dd(hd, design)
            hd.tooltip = "Par defaut egale a l'epaisseur choisie ; on peut prendre un autre parametre CPxx ou une valeur libre."
            hd.isVisible = False
            ins.addValueInput('nc_t_haut', 'Hauteur libre', um.defaultLengthUnits, adsk.core.ValueInput.createByReal(1.8)).isVisible = False
            pc = ins.addBoolValueInput('nc_perc', 'Ajouter un percement', True, '', False)
            pc.tooltip = "Trou rond traversant sur la face de la piece. Le diametre est un parametre utilisateur Fusion (PERCxx), modifiable ensuite."
            pdd = ins.addDropDownCommandInput('nc_p_dd', 'Diamètre du percement', adsk.core.DropDownStyles.TextListDropDownStyle)
            for n in _nc_perc_liste(design):
                pdd.listItems.add('%s (%s mm)' % (n, ('%.2f' % (_nc_perc_cm(design, n) * 10.0)).rstrip('0').rstrip('.')), n == _nc_perc_nom(0.8), '')
            pdd.listItems.add('Autre…', False, '')
            pdd.tooltip = "Parametre PERCxx du projet (cree s'il n'existe pas) ou valeur libre."
            pdd.isVisible = False
            ins.addValueInput('nc_p_autre', 'Diamètre libre', um.defaultLengthUnits, adsk.core.ValueInput.createByReal(0.8)).isVisible = False
            pce = ins.addBoolValueInput('nc_p_centre', 'Centré sur la pièce', True, '', True)
            pce.tooltip = "Coche : percement au centre de la piece. Decoche : position manuelle depuis le coin bas-gauche."
            pce.isVisible = False
            ins.addValueInput('nc_p_x', 'Position largeur (depuis la gauche)', um.defaultLengthUnits, adsk.core.ValueInput.createByReal(5.0)).isVisible = False
            ins.addValueInput('nc_p_y', 'Position hauteur (depuis le bas)', um.defaultLengthUnits, adsk.core.ValueInput.createByReal(5.0)).isVisible = False
            al = ins.addTextBoxCommandInput('nc_alerte', '', '', 3, True)
            al.isFullWidth = True
            al.isVisible = False
            try:
                img = ins.addImageCommandInput('nc_img', '', _png_apercu_corps(10.0, 10.0, 1.8))
                img.isFullWidth = True
            except Exception:
                _log('image nouveau corps erreur %s' % traceback.format_exc()[-300:])
            msg = ins.addTextBoxCommandInput('nc_info', '', "Le corps est créé dans le composant masqué « CNC Toolkit », "
                                             "à l'écart du modèle. Seule l'épaisseur est un paramètre (CPxx).", 3, True)
            msg.isFullWidth = True
            ed = _nc_etat.get('edition')
            if ed is not None:
                cmd.okButtonText = 'Modifier'
                ty.isVisible = False
                t = ed['tenons']
                tn.value = bool(t)
                if t:
                    for cle, _, _ in NC_COTES:
                        ins.itemById('nc_c_' + cle).value = cle in t['cotes']
                    ins.itemById('nc_t_n').value = t['n']
                    ins.itemById('nc_t_long').value = t['long']
                    ins.itemById('nc_t_haut').value = t['haut']
                    hd = ins.itemById('nc_t_hdd')
                    hd.listItems.item(hd.listItems.count - 1).isSelected = True
                pe = ed.get('perc')
                ins.itemById('nc_perc').value = bool(pe)
                if pe:
                    pl = _nc_perc_liste(design)
                    if pe['d_nom'] in pl:
                        pdd.listItems.item(pl.index(pe['d_nom'])).isSelected = True
                    else:
                        pdd.listItems.item(pdd.listItems.count - 1).isSelected = True
                        ins.itemById('nc_p_autre').value = _nc_perc_cm(design, pe['d_nom'])
                    ins.itemById('nc_p_centre').value = bool(pe['centre'])
                    ins.itemById('nc_p_x').value = pe['x']
                    ins.itemById('nc_p_y').value = pe['y']
                msg.text = ("Modification de la pièce « %s » : les copies qui en dépendent suivent. "
                            "Les tenons sont recréés avec les valeurs ci-dessus." % ed['nom'])
                ins.itemById('nc_nom').value = ed['nom']
                ins.itemById('nc_larg').value = ed['l']
                ins.itemById('nc_haut').value = ed['h']
                noms = _nc_epaisseurs(design)
                if ed['ep'] in noms:
                    dd.listItems.item(noms.index(ed['ep'])).isSelected = True
                else:
                    dd.listItems.item(dd.listItems.count - 1).isSelected = True
                    p = design.allParameters.itemByName(ed['ep'])
                    ins.itemById('nc_ep_autre').value = p.value if p is not None else ed['ep_cm']
                    ins.itemById('nc_ep_autre').isVisible = True
            _nc_maj_champs(ins)
            _nc_apercu(ins)
            for ev, h in ((cmd.validateInputs, _NCValidateHandler()), (cmd.inputChanged, _NCChangedHandler()), (cmd.execute, _NCExecuteHandler()),
                          (cmd.destroy, _NCDestroyHandler())):
                ev.add(h)
                _handlers.append(h)
        except Exception:
            _log('nouveau corps cree erreur ' + traceback.format_exc()[-600:])


class _NCValidateHandler(adsk.core.ValidateInputsEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            ins = args.inputs
            larg, haut, ep = _nc_valeurs(ins)
            args.areInputsValid = larg > 0 and haut > 0 and ep > 0 and not _nc_alerte(ins)
        except Exception:
            args.areInputsValid = True


class _NCChangedHandler(adsk.core.InputChangedEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            ins = args.input.parentCommand.commandInputs
            if args.input.id == 'nc_ep':
                dd = ins.itemById('nc_ep')
                ins.itemById('nc_ep_autre').isVisible = (dd.selectedItem.index == dd.listItems.count - 1)
            if args.input.id == 'nc_ep':
                # la hauteur du tenon suit l'epaisseur (CP18 -> tenon de 18), modifiable ensuite
                dd, hd = ins.itemById('nc_ep'), ins.itemById('nc_t_hdd')
                hd.listItems.item(dd.selectedItem.index).isSelected = True
                ins.itemById('nc_t_haut').value = ins.itemById('nc_ep_autre').value
            if args.input.id == 'nc_ep_autre' and ins.itemById('nc_ep').selectedItem.index == ins.itemById('nc_ep').listItems.count - 1:
                hd = ins.itemById('nc_t_hdd')
                if hd.selectedItem.index == hd.listItems.count - 1:
                    ins.itemById('nc_t_haut').value = ins.itemById('nc_ep_autre').value
            if args.input.id.startswith('nc_'):
                _nc_maj_champs(ins)
                _nc_apercu(ins)
        except Exception:
            _log('nouveau corps changed erreur %s' % traceback.format_exc()[-300:])


_nc_etat = {'ok': False, 'dernier': None, 'edition': None, 'choix': None}     # edition : {'tok', 'tenons'} ; choix : piece de la bibliotheque retenue


class _NCExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            ins = args.command.commandInputs
            design = adsk.fusion.Design.cast(_app.activeProduct)
            larg, haut = ins.itemById('nc_larg').value, ins.itemById('nc_haut').value
            dd = ins.itemById('nc_ep')
            if dd.selectedItem.index == dd.listItems.count - 1:
                ep, ep_cm = ins.itemById('nc_ep_autre').value, ins.itemById('nc_ep_autre').value
            else:
                ep = _nc_epaisseurs(design)[dd.selectedItem.index]
                p = design.allParameters.itemByName(ep)
                ep_cm = p.value if p is not None else NC_CP.get(ep, 1.8)
            nom = ins.itemById('nc_nom').value.strip() or _nc_nom_auto(larg, haut, ep_cm)
            del _nc_etat_msgs[:]
            ed = _nc_etat.get('edition')
            if ed is not None:
                corps = _modifier_corps_bibliotheque(ed['tok'], nom, larg, haut, ep, _nc_tenons_champs(ins), _nc_perc_champs(ins))
            else:
                corps = _creer_corps_bibliotheque(nom, larg, haut, ep, _nc_tenons_champs(ins),
                                                  composant=ins.itemById('nc_type').selectedItem.index == 1, perc=_nc_perc_champs(ins))
            if _nc_etat_msgs:
                _ui.messageBox('\n'.join(_nc_etat_msgs[:6]), 'Nouvel objet CNC')
            _nc_etat['ok'] = True
            _nc_etat['dernier'] = corps.entityToken
        except ValueError as e:
            args.executeFailed = True
            args.executeFailedMessage = str(e)
        except Exception as e:
            _log('nouveau corps erreur %s' % traceback.format_exc()[-600:])
            args.executeFailed = True
            args.executeFailedMessage = 'Creation impossible : ' + str(e).splitlines()[-1][:300]


class _NCDestroyHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        # la boite Reseau se rouvre, que le corps ait ete cree ou non
        if not _nc_etat['ok']:
            _nc_etat['dernier'] = None
        _nc_etat['ok'] = False
        _nc_etat['edition'] = None
        _differer(CMD_ID)


# --- « Nouvel objet » : fenetre (palette HTML) -----------------------------------------------------------------
# Meme principe et meme design que « Creer un nouveau corps » de Traverse sur corps : tout se regle dans l'apercu
# (cotes cliquables avec saisie sur place, pastilles a glisser, epaisseur en pastille avec la liste des parametres CPxx
# du document, icones T pour les tenons, icone Ø pour le percement). Pas de choix de forme des bouts : la piece est un
# panneau rectangulaire. Creation / modification : memes fonctions qu'avant (_creer_corps_bibliotheque,
# _modifier_corps_bibliotheque), donc memes groupes de chronologie, historique et bibliotheque.

NC_PAL_ID = 'ReseauTrajectoireCNC_nouvel_objet'
NC_HTML = os.path.join(_ADDIN_DIR, 'nouvel_objet.html')
NC_TAILLE = (580, 620)
_nc_pal = {'h': [], 'fin': False, 'msgs': []}


def _tt(s):
    """Texte dans la langue choisie (cnc_i18n est charge par ToolkitCNC)."""
    try:
        import sys
        m = sys.modules.get('cnc_i18n')
        return m.t(s) if m is not None else s
    except Exception:
        return s


def _nc_mm_txt(cm):
    return ('%g' % round(cm * 10.0, 2)) + ' mm'


def _nc_eval_p(expr):
    """Valeur (cm) d'une expression ('800 mm', 'CP18*2', 'PERC8') ; None si invalide."""
    if not expr:
        return None
    try:
        um = adsk.fusion.Design.cast(_app.activeProduct).unitsManager
        if um.isValidExpression(expr, 'mm'):
            return um.evaluateExpression(expr, 'mm')
    except Exception:
        pass
    return None


def _nc_mm_expr(x):
    """Nombre seul = mm (« 30 » -> « 30 mm »), sinon l'expression telle quelle."""
    x = str(x or '').strip().replace(',', '.')
    return x + ' mm' if re.match(r'^[0-9]+(\.[0-9]+)?$', x) else x


def _nc_ep_p(expr):
    """Epaisseur (cm) ; CP10 / CP15 / CP18 acceptes meme si le parametre n'existe pas encore."""
    v = _nc_eval_p(expr)
    if v is None and (expr or '').strip().upper() in NC_CP:
        v = NC_CP[expr.strip().upper()]
    return v


def _nc_perc_p(expr):
    """(diametre cm, nom PERCxx) d'une expression de diametre ; None si invalide."""
    design = adsk.fusion.Design.cast(_app.activeProduct)
    e = (expr or '').strip()
    if design.allParameters.itemByName(e) is not None or e.upper() in [_nc_perc_nom(d) for d in NC_PERC]:
        d = _nc_perc_cm(design, e if design.allParameters.itemByName(e) is not None else e.upper())
        return d, (e if design.allParameters.itemByName(e) is not None else e.upper())
    d = _nc_eval_p(e)
    if d is None or d <= 0:
        return None
    return d, _nc_perc_nom(d)


def _nc_defaut_p():
    return {'nom': '', 'type': 'corps', 'L': '400 mm', 'H': '300 mm', 'ep': 'CP18', 'tn_cotes': [], 'tn_nb': '1',
            'tn_len': '30', 'tn_h': '18', 'tn_hauto': True, 'perc': False, 'p_d': _nc_perc_nom(0.8),
            'p_centre': True, 'p_x': '', 'p_y': ''}


def _nc_vals_edition(ed):
    """Valeurs de la piece a modifier (_nc_edition_preparer) -> valeurs de la fenetre."""
    v = _nc_defaut_p()
    ep_nom = ed['ep'] if isinstance(ed['ep'], str) else _nc_mm_txt(ed['ep_cm'])
    v.update(nom=ed['nom'], L=_nc_mm_txt(ed['l']), H=_nc_mm_txt(ed['h']), ep=ep_nom, _edition=True)
    t = ed.get('tenons')
    if t:
        v.update(tn_cotes=sorted(t['cotes']), tn_nb=str(t['n']), tn_len=('%g' % round(t['long'] * 10.0, 2)),
                 tn_h=('%g' % round(t['haut'] * 10.0, 2)), tn_hauto=abs(t['haut'] - ed['ep_cm']) < 1e-6)
    pe = ed.get('perc')
    if pe:
        v.update(perc=True, p_d=pe['d_nom'], p_centre=bool(pe['centre']), p_x=_nc_mm_txt(pe['x']), p_y=_nc_mm_txt(pe['y']))
    return v


_NC_COTE_HTML = {'haut': 'dessus', 'bas': 'dessous', 'gauche': 'cote0', 'droite': 'cote1'}


def _nc_calc_p(v):
    """Valeurs de la fenetre -> calcul (meme logique que les alertes de l'ancienne boite) pour l'apercu et la creation."""
    L, H = _nc_eval_p(v.get('L')), _nc_eval_p(v.get('H'))
    ep = _nc_ep_p(v.get('ep'))
    bad = []
    if L is None or L <= 0:
        bad.append('L')
    if H is None or H <= 0:
        bad.append('H')
    if ep is None or ep <= 0:
        bad.append('ep')
    if bad:
        return {'ok': False, 'msg': _tt('Mesure invalide : entrez un nombre en mm ou un parametre.'), 'bad': bad}
    res = {'ok': True, 'msg': '', 'bad': [], 'L': L, 'H': H, 'ep': ep, 'tenons': [], 'perc': None, 'warn': [],
           'tn_nmax': 50}
    erreurs = []
    cotes = [c for c in (v.get('tn_cotes') or []) if c in _NC_COTE_HTML]
    if cotes:
        tl = _nc_eval_p(_nc_mm_expr(v.get('tn_len')))
        th = ep if v.get('tn_hauto', True) else _nc_eval_p(_nc_mm_expr(v.get('tn_h')))
        if tl is None or tl <= 0:
            bad.append('tn_len')
            erreurs.append('La longueur du tenon doit etre positive.')
        if th is None or th <= 0:
            bad.append('tn_h')
            erreurs.append('La hauteur du tenon doit etre positive.')
        if not erreurs:
            nmax = 50
            for c in cotes:
                lc = L if c in ('haut', 'bas') else H
                nmax = min(nmax, int((lc - 1e-6) / tl))
                if tl >= lc - 1e-6:
                    erreurs.append('Chant %s (%s mm) : un tenon de %s mm est trop long.' % (
                        c, ('%g' % round(lc * 10, 1)), ('%g' % round(tl * 10, 1))))
                    bad.append('tn_len')
            nmax = max(1, nmax)
            try:
                nb = max(1, int(float(str(v.get('tn_nb') or '1').replace(',', '.'))))
            except Exception:
                nb = 1
            nb = min(nb, nmax)
            res.update(tn_nmax=nmax, tn_nb=nb, tn_h_mm=('%g' % round(th * 10.0, 2)), tn_long=tl, tn_haut=th, tn_cotes=cotes)
            if not erreurs:
                for c in cotes:
                    lc = L if c in ('haut', 'bas') else H
                    for a, b in _nc_segments_tenons(lc, nb, tl):
                        res['tenons'].append([_NC_COTE_HTML[c], a, b - a, th])
        elif th is not None:
            res['tn_h_mm'] = ('%g' % round(th * 10.0, 2))
    elif v.get('tn_hauto', True):
        res['tn_h_mm'] = ('%g' % round(ep * 10.0, 2))
    if v.get('perc'):
        pd = _nc_perc_p(v.get('p_d'))
        if pd is None:
            bad.append('p_d')
            erreurs.append('Le diametre du percement est invalide.')
        else:
            d, d_nom = pd
            if v.get('p_centre', True):
                x, y = L / 2.0, H / 2.0
            else:
                x, y = _nc_eval_p(v.get('p_x')), _nc_eval_p(v.get('p_y'))
                x = L / 2.0 if x is None else x
                y = H / 2.0 if y is None else y
            r = d / 2.0
            if d >= min(L, H) - 1e-6 or x - r < -1e-6 or x + r > L + 1e-6 or y - r < -1e-6 or y + r > H + 1e-6:
                erreurs.append('Le percement (diametre %s mm en x=%s, y=%s) depasse de la piece.' % (
                    ('%g' % round(d * 10, 1)), ('%g' % round(x * 10, 1)), ('%g' % round(y * 10, 1))))
            res['perc'] = {'d': d, 'd_nom': d_nom, 'x': x, 'y': y, 'centre': bool(v.get('p_centre', True))}
    if erreurs:
        res['ok'] = False
        res['msg'] = ' '.join(_tt(e) for e in erreurs)
    res['bad'] = bad
    return res


def _nc_json_p(calc):
    keys = ('ok', 'msg', 'L', 'H', 'ep', 'tenons', 'perc', 'bad', 'warn', 'tn_nmax', 'tn_nb', 'tn_h_mm')
    return json.dumps({k: calc.get(k) for k in keys if k in calc})


def _nc_listes_p():
    """Epaisseurs (CPxx du document + CP10/15/18) et diametres (PERCxx) proposes dans les menus de la fenetre."""
    design = adsk.fusion.Design.cast(_app.activeProduct)
    eps = []
    for n in _nc_epaisseurs(design):
        p = design.allParameters.itemByName(n)
        cm = p.value if p is not None else NC_CP.get(n, 1.8)
        eps.append({'nom': n, 'mm': round(cm * 10.0, 2)})
    percs = [{'nom': n, 'mm': round(_nc_perc_cm(design, n) * 10.0, 2)} for n in _nc_perc_liste(design)]
    return sorted(eps, key=lambda e: e['mm']), sorted(percs, key=lambda e: e['mm'])


def _nc_params_p():
    """Tous les parametres utilisateur de longueur du document (proposes dans la saisie des mesures)."""
    design = adsk.fusion.Design.cast(_app.activeProduct)
    out = []
    ups = design.userParameters
    for i in range(ups.count):
        p = ups.item(i)
        try:
            if p.unit in ('mm', 'cm', 'm', 'in', 'ft'):
                out.append({'nom': p.name, 'mm': round(p.value * 10.0, 2)})
        except Exception:
            pass
    return sorted(out, key=lambda e: e['nom'].lower())


def _nc_creer_p(v):
    """Cree (ou modifie) la piece avec les valeurs de la fenetre ; renvoie (ok, message)."""
    calc = _nc_calc_p(v)
    if not calc.get('ok'):
        return False, calc.get('msg') or 'Valeurs invalides.'
    design = adsk.fusion.Design.cast(_app.activeProduct)
    L, H, ep_cm = calc['L'], calc['H'], calc['ep']
    e = (v.get('ep') or '').strip()
    if design.allParameters.itemByName(e) is not None or e.upper() in NC_CP:
        ep = e if design.allParameters.itemByName(e) is not None else e.upper()
    else:
        ep = ep_cm                                  # valeur libre : parametre CPxx cree par la creation
    nom = (v.get('nom') or '').strip()[:80] or _nc_nom_auto(L, H, ep_cm)
    tenons = None
    if calc.get('tenons'):
        tenons = {'cotes': set(calc['tn_cotes']), 'n': calc['tn_nb'], 'long': calc['tn_long'], 'haut': calc['tn_haut']}
    perc = dict(calc['perc']) if calc.get('perc') else None
    del _nc_etat_msgs[:]
    ed = _nc_etat.get('edition')
    try:
        if ed is not None:
            corps = _modifier_corps_bibliotheque(ed['tok'], nom, L, H, ep, tenons, perc)
        else:
            corps = _creer_corps_bibliotheque(nom, L, H, ep, tenons, composant=(v.get('type') == 'composant'), perc=perc)
    except ValueError as ex:
        return False, str(ex)
    _nc_pal['msgs'] = list(_nc_etat_msgs)
    _nc_etat['ok'] = True
    _nc_etat['dernier'] = corps.entityToken
    return True, ''


class _NcHtmlHandler(adsk.core.HTMLEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            a = args.action
            d = json.loads(args.data) if args.data else {}
            if a == 'nc_pret':
                ed = _nc_etat.get('edition')
                args.returnData = json.dumps(_nc_vals_edition(ed) if ed is not None else _nc_defaut_p())
                _differer('@nc_secouer')
            elif a == 'nc_eps':
                args.returnData = json.dumps(_nc_listes_p()[0])
            elif a == 'nc_params':
                args.returnData = json.dumps(_nc_params_p())
            elif a == 'nc_percs':
                args.returnData = json.dumps(_nc_listes_p()[1])
            elif a == 'nc_textes':
                args.returnData = json.dumps([_tt((t or '').strip()) for t in d.get('t', [])])
            elif a == 'nc_calc':
                args.returnData = _nc_json_p(_nc_calc_p(d))
            elif a == 'nc_creer':
                try:
                    ok, msg = _nc_creer_p(d)
                except Exception as e:
                    _log('nouvel objet erreur ' + traceback.format_exc()[-800:])
                    ok, msg = False, 'Creation impossible : ' + (str(e).splitlines()[-1][:300] if str(e) else '')
                args.returnData = json.dumps({'ok': ok, 'msg': msg})
                if ok:
                    _differer('@nc_fin')            # la fenetre se ferme et la boite Reseau se rouvre (hors de ce gestionnaire)
        except Exception:
            _log('fenetre nouvel objet : ' + traceback.format_exc()[-500:])


class _NcClosedHandler(adsk.core.UserInterfaceGeneralEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            if _nc_pal['fin']:
                return
            _nc_pal['fin'] = True            # fermee a la main : la boite Reseau se rouvre, comme avant
            if not _nc_etat['ok']:
                _nc_etat['dernier'] = None
            _nc_etat['ok'] = False
            _nc_etat['edition'] = None
            _differer(_nc_etat.pop('retour', None) or CMD_ID)     # ouverte depuis Traverse sur corps : on y retourne
        except Exception:
            _log('fermeture fenetre nouvel objet : ' + traceback.format_exc()[-300:])


NC_ECHELLE = 2.0                 # fenetre agrandie x2 (Maxence 2026-11-11), reduite si l'ecran est trop petit


def _nc_ecran():
    """(largeur, hauteur) logiques de l'ecran principal ; (0, 0) si inconnu (meme methode que Traverse sur corps)."""
    try:
        import ctypes
        k = float(_dpr()) or 1.0
        u = ctypes.windll.user32
        return u.GetSystemMetrics(0) / k, u.GetSystemMetrics(1) / k
    except Exception:
        return 0, 0


def _nc_taille():
    """(largeur, hauteur) de la palette en pixels logiques : x2, sans depasser 92 % de l'ecran."""
    e = NC_ECHELLE
    sw, sh = _nc_ecran()
    if sw:
        e = min(e, 0.92 * sw / NC_TAILLE[0], 0.92 * sh / NC_TAILLE[1])
    e = max(1.0, e)
    return int(NC_TAILLE[0] * e), int(NC_TAILLE[1] * e)


def _nc_placer(pal):
    """Fenetre a sa taille (x2) et centree a l'ecran, comme Traverse sur corps."""
    W, H = _nc_taille()
    try:
        pal.setSize(W, H)
    except Exception:
        _log('taille fenetre : ' + traceback.format_exc()[-200:])
    try:
        sw, sh = _nc_ecran()
        if sw:
            x, y = int(sw / 2 - W / 2), int(sh / 2 - H / 2)
        else:
            vp = _app.activeViewport
            x, y = int(vp.width / 2 - W / 2), int(vp.height / 2 - H / 2)
        pal.setPosition(max(0, x), max(0, y))
        _log('fenetre nouvel objet : %dx%d en (%d, %d), ecran %.0fx%.0f' % (W, H, x, y, sw, sh))
    except Exception:
        _log('position fenetre : ' + traceback.format_exc()[-200:])


def _nc_secouer(pal=None):
    """Fenetre blanche a l'ouverture (il fallait l'etirer) : une fois la page chargee, on change la taille de 1 pixel
    puis on la remet, ce qui force Fusion a la redessiner."""
    try:
        pal = pal or _ui.palettes.itemById(NC_PAL_ID)
        if pal is None:
            return
        w, h = _nc_taille()
        pal.setSize(w + 1, h + 1)
        pal.setSize(w, h)
    except Exception:
        _log('secouer fenetre : ' + traceback.format_exc()[-200:])


def _nc_fermer_pal():
    pal = _ui.palettes.itemById(NC_PAL_ID) if _ui else None
    if pal is not None:
        try:
            pal.deleteMe()
        except Exception:
            pass
    _nc_pal['h'] = []


def _nc_ouvrir_pal():
    """Ouvre (ou recharge) la fenetre « Nouvel objet » (valeurs de la piece en modification, sinon par defaut)."""
    import pathlib
    _nc_pal['fin'] = True
    _nc_fermer_pal()
    _nc_pal['fin'] = False
    url = pathlib.PureWindowsPath(NC_HTML).as_uri() if os.name == 'nt' else pathlib.Path(NC_HTML).as_uri()
    pal = _ui.palettes.add(NC_PAL_ID, _tt('Nouvel objet'), url, False, True, True, NC_TAILLE[0], NC_TAILLE[1], True)
    h1, h2 = _NcHtmlHandler(), _NcClosedHandler()
    pal.incomingFromHTML.add(h1)
    pal.closed.add(h2)
    _nc_pal['h'] = [h1, h2]
    try:
        pal.dockingState = adsk.core.PaletteDockingStates.PaletteDockStateFloating
    except Exception:
        pass
    pal.isVisible = True
    _nc_placer(pal)
    return pal


def _nc_palette_evt():
    """Evenement differe : la boite Reseau se ferme, puis la fenetre s'ouvre (jamais depuis le gestionnaire de la boite)."""
    try:
        if _ui.activeCommand in (CMD_ID, _nc_etat.get('retour')):
            _ui.terminateActiveCommand()
    except Exception:
        pass
    _nc_ouvrir_pal()


def modifier_piece_externe(tok, retour=None):
    """Appele par Traverse sur corps (bibliotheque commune, Maxence 2026-11-14) : ouvre la fenetre « Nouvel objet »
    en modification sur une de nos pieces ; `retour` = commande a rouvrir a la fermeture (sinon Reseau CNC)."""
    for e in _nc_liste():
        if e['body'].entityToken == tok and e.get('src') != 'traverse':
            if not _nc_edition_preparer(e['body']):
                return False
            _nc_etat['dernier'] = None
            _nc_etat['retour'] = retour
            _differer('@nc_palette')
            return True
    _ui.messageBox('Piece introuvable dans la bibliotheque.', 'Modifier la piece')
    return False


def _nc_fin_evt():
    """Piece creee : la fenetre se ferme et la boite Reseau se rouvre avec la piece choisie."""
    _nc_pal['fin'] = True
    _nc_fermer_pal()
    msgs = list(_nc_pal['msgs'])
    _nc_pal['msgs'] = []
    _nc_etat['ok'] = False
    _nc_etat['edition'] = None
    if msgs:
        _ui.messageBox('\n'.join(msgs[:6]), 'Nouvel objet CNC')
    _differer(_nc_etat.pop('retour', None) or CMD_ID)     # ouverte depuis Traverse sur corps : on y retourne


def _controle_reseau(panel):
    """Menu deroulant Reseau du panneau Creer (celui qui contient la commande
    native), pour ranger notre bouton a cote du reseau natif."""
    natif = _cmd_native('PathPattern')
    if natif is None:
        return None, None
    for i in range(panel.controls.count):
        c = panel.controls.item(i)
        if c.objectType == adsk.core.DropDownControl.classType():
            try:
                if c.controls.itemById(natif.id):
                    return c.controls, natif.id
            except Exception:
                continue
    return None, natif.id


def run(context):
    global _app, _ui
    try:
        _app = adsk.core.Application.get()
        _ui = _app.userInterface
        old = _ui.commandDefinitions.itemById(CMD_ID)
        if old:
            old.deleteMe()
        res = _icone_native('PathPattern') or (RESOURCES if os.path.isdir(RESOURCES) else '')
        cmd_def = _ui.commandDefinitions.addButtonDefinition(CMD_ID, COMMAND_NAME, COMMAND_DESC, res)
        on_created = _CreatedHandler()
        cmd_def.commandCreated.add(on_created)
        _handlers.append(on_created)
        on_term = _CommandTerminatedHandler()
        _ui.commandTerminated.add(on_term)
        _handlers.append(on_term)
        _term['h'] = on_term
        olde = _ui.commandDefinitions.itemById(EDIT_CMD_ID)
        if olde:
            olde.deleteMe()
        oldn = _ui.commandDefinitions.itemById(NC_CMD_ID)
        if oldn:
            oldn.deleteMe()
        nc_def = _ui.commandDefinitions.addButtonDefinition(NC_CMD_ID, 'Nouvel objet CNC', 'Cree un corps ou un composant dans le composant masque CNC Toolkit', '')
        on_nc = _NCCreatedHandler()
        nc_def.commandCreated.add(on_nc)
        _handlers.append(on_nc)
        edit_def = _ui.commandDefinitions.addButtonDefinition(EDIT_CMD_ID, 'Modifier le réseau CNC', 'Rouvre la boîte du réseau CNC sélectionné', '')
        on_edit = _EditCreatedHandler()
        edit_def.commandCreated.add(on_edit)
        _handlers.append(on_edit)
        on_start = _CmdStartingHandler()
        _ui.commandStarting.add(on_start)
        _handlers.append(on_start)
        _term['start'] = on_start
        on_menu = _MenuHandler()
        _ui.markingMenuDisplaying.add(on_menu)
        _handlers.append(on_menu)
        _term['menu'] = on_menu
        on_cam = _CameraHandler()
        _app.cameraChanged.add(on_cam)
        _handlers.append(on_cam)
        _term['cam'] = on_cam
        _arreter_tick()
        _demarrer_tick()
        panel = _ui.allToolbarPanels.itemById(PANEL_ID)
        if panel:
            ctrls, apres = _controle_reseau(panel)
            if ctrls is None:
                ctrls = panel.controls
            if not ctrls.itemById(CMD_ID):
                if apres and ctrls.itemById(apres):
                    ctrls.addCommand(cmd_def, apres, False)
                else:
                    ctrls.addCommand(cmd_def)
    except Exception:
        if _ui:
            _ui.messageBox('Erreur au demarrage de Reseau sur la trajectoire CNC:\n' + traceback.format_exc())


_term = {'h': None}


def stop(context):
    _dv_arreter()
    _arreter_tick()
    try:
        if _action['evt'] is not None:
            _action['evt'].remove(_action['h'])
        _app.unregisterCustomEvent(ACTION_ID)
    except Exception:
        pass
    _action.update({'evt': None, 'h': None})
    try:
        if _term['h'] is not None:
            _ui.commandTerminated.remove(_term['h'])
            _term['h'] = None
    except Exception:
        pass
    for ev, cle in ((_ui.commandStarting, 'start'), (_ui.markingMenuDisplaying, 'menu'), (_app.cameraChanged, 'cam')):
        try:
            if _term.get(cle) is not None:
                ev.remove(_term[cle])
                _term[cle] = None
        except Exception:
            pass
    try:
        _nc_pal['fin'] = True
        _nc_fermer_pal()
    except Exception:
        pass
    try:
        nd = _ui.commandDefinitions.itemById(NC_CMD_ID)
        if nd:
            nd.deleteMe()
    except Exception:
        pass
    try:
        ed = _ui.commandDefinitions.itemById(EDIT_CMD_ID)
        if ed:
            ed.deleteMe()
    except Exception:
        pass
    try:
        panel = _ui.allToolbarPanels.itemById(PANEL_ID)
        if panel:
            ctrls, _ = _controle_reseau(panel)
            for cs in (ctrls, panel.controls):
                if cs is None:
                    continue
                c = cs.itemById(CMD_ID)
                if c:
                    c.deleteMe()
        cd = _ui.commandDefinitions.itemById(CMD_ID)
        if cd:
            cd.deleteMe()
    except Exception:
        pass
    _handlers.clear()
