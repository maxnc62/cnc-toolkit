import adsk.core
import adsk.fusion
import traceback
import os
import json
import math

# ---------------------------------------------------------------------------
# Reseau sur la trajectoire CNC : meme outil que Solide > Creer > Reseau >
# Reseau sur la trajectoire (memes champs : type, type d'objet, objets,
# chemin, masquer, quantite, distance, point de depart, repartition,
# direction, orientation), avec en plus une CONTRAINTE AU PLAN (demande de
# l'utilisateur le 2026-10-12) : on choisit la face du corps "objet" qui doit
# se poser contre un plan (plan de decalage, plan d'origine, face plane).
#
# PRINCIPE
#   - Le resultat est toujours une VRAIE PathPatternFeature (fonction native,
#     parametrique, modifiable ensuite avec la boite native de Fusion) ;
#     l'apercu est cette meme fonction (corps gris).
#   - Contrainte au plan (corps seulement) : le chemin est PROJETE dans une
#     esquisse sur le plan choisi, et le reseau suit cette projection. Elle
#     reste liee au chemin d'origine : modifier une cote, un parametre ou la
#     longueur du chemin plus tot dans la timeline met le reseau a jour
#     (demande de l'utilisateur le 2026-10-13). Le chemin projete etant plan,
#     les copies ne tournent qu'autour de la normale du plan et ne decollent
#     pas du plan (limite du reseau natif sur un chemin en 3D). Si la face
#     d'appui choisie n'est pas sur le plan, une fonction Deplacer y pose le
#     corps d'origine. Esquisse + Deplacer + Reseau sont regroupes dans la
#     timeline ("Reseau trajectoire CNC").
#   - Les reglages (hors selections) sont memorises dans reseau_prefs.json.
# ---------------------------------------------------------------------------

_app = None
_ui = None
_handlers = []

CMD_ID       = 'ReseauTrajectoireCNCCmd'
COMMAND_NAME = 'Reseau sur la trajectoire CNC'
COMMAND_DESC = ('Reseau sur la trajectoire identique a celui de Fusion, avec en plus '
                'le choix de la face du corps a poser contre un plan')
PANEL_ID     = 'SolidCreatePanel'

_ADDIN_DIR = os.path.dirname(os.path.abspath(__file__))
PREFS_FILE = os.path.join(_ADDIN_DIR, 'reseau_prefs.json')
RESOURCES  = os.path.join(_ADDIN_DIR, 'resources')
GROUPE_TIMELINE = 'Reseau trajectoire CNC'

TYPES_OBJET  = [('corps', 'Corps'), ('faces', 'Faces'), ('fonctions', 'Fonctions'),
                ('composants', 'Composants')]
REPERES      = [('gauche', 'Face de gauche'), ('centre', 'Centre'), ('droite', 'Face de droite')]
REPARTITIONS = [('etendue', 'Étendue'), ('espacement', 'Espacement')]
DIRECTIONS   = [('une', 'Une direction'), ('symetrique', 'Symétrique')]
ORIENTATIONS = [('identique', 'Identique'), ('trajectoire', 'Direction de la trajectoire')]
CALCULS      = [('optimise', 'Optimisé'), ('identique', 'Identique'), ('ajuster', 'Ajuster')]

FILTRES_OBJET = {
    'corps': ('SolidBodies', 'SurfaceBodies'),
    'faces': ('Faces',),
    'fonctions': ('Features',),
    'composants': ('Occurrences',),
}

DEFAULT_PREFS = {
    'type_objet': 'corps', 'quantite': 3, 'repartition': 'etendue',
    'direction': 'une', 'orientation': 'identique', 'calcul': 'optimise',
    'inverser': False,
}

_pending_prefs = None
# Le chemin change : on remet Distance a la longueur du chemin (comme la
# boite native) sauf si l'utilisateur a tape une distance depuis.
_dernier_chemin = None


def load_prefs():
    p = dict(DEFAULT_PREFS)
    try:
        with open(PREFS_FILE, 'r', encoding='utf-8') as f:
            saved = json.load(f)
        p.update({k: saved[k] for k in DEFAULT_PREFS if k in saved})
    except Exception:
        pass
    return p


def save_prefs(prefs):
    try:
        p = load_prefs()
        p.update({k: prefs[k] for k in DEFAULT_PREFS if k in prefs})
        tmp = PREFS_FILE + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(p, f, indent=2, ensure_ascii=False)
        os.replace(tmp, PREFS_FILE)
    except Exception:
        pass


# --- Commandes natives (icones et boutons "Type") ---------------------------

_natifs = {}


IDS_NATIFS = {'PathPattern': 'PatternOnPath', 'RectangularPattern': 'PatternRectangular',
              'CircularPattern': 'PatternCircular'}


def _cmd_native(motcle):
    """Commande native de Fusion ('PathPattern', 'RectangularPattern',
    'CircularPattern') : Reseau sur la trajectoire / rectangulaire /
    circulaire du panneau Creer."""
    if motcle in _natifs:
        return _natifs[motcle]
    try:
        trouve = _ui.commandDefinitions.itemById(IDS_NATIFS[motcle])
    except Exception:
        trouve = None
    _natifs[motcle] = trouve
    return trouve


def _icone_native(motcle):
    d = _cmd_native(motcle)
    try:
        f = d.resourceFolder if d else ''
        return f if f and os.path.isfile(os.path.join(f, '16x16.png')) else ''
    except Exception:
        return ''


# --- Inputs -----------------------------------------------------------------

def _dropdown(inputs, id_, label, items, current):
    dd = inputs.addDropDownCommandInput(id_, label, adsk.core.DropDownStyles.TextListDropDownStyle)
    keys = [k for k, _ in items]
    if current not in keys:
        current = keys[0]
    for k, txt in items:
        dd.listItems.add(txt, k == current, '')
    return dd


def _dd_key(dd, items):
    sel = dd.selectedItem
    if sel is None:
        return items[0][0]
    # Par position (les libelles accentues ne servent pas de cle).
    try:
        return items[sel.index][0]
    except Exception:
        pass
    for k, txt in items:
        if txt == sel.name:
            return k
    return items[0][0]


def _selections(sel_input):
    return [sel_input.selection(i).entity for i in range(sel_input.selectionCount)]


def _set_filtres_objets(inputs):
    sel = inputs.itemById('objets')
    t = _dd_key(inputs.itemById('type_objet'), TYPES_OBJET)
    sel.clearSelectionFilter()
    for f in FILTRES_OBJET[t]:
        sel.addSelectionFilter(f)


def _build_inputs(cmd):
    p = load_prefs()
    inputs = cmd.commandInputs
    um = _app.activeProduct.unitsManager

    row = inputs.addButtonRowCommandInput('type_reseau', 'Type', False)
    row.listItems.add('Réseau rectangulaire', False, _icone_native('RectangularPattern'))
    row.listItems.add('Réseau circulaire', False, _icone_native('CircularPattern'))
    row.listItems.add('Réseau sur la trajectoire', True, _icone_native('PathPattern'))

    _dropdown(inputs, 'type_objet', "Type d'objet", TYPES_OBJET, p['type_objet'])

    sel = inputs.addSelectionInput('objets', 'Objets', 'Objets a dupliquer')
    sel.setSelectionLimits(1, 0)
    ch = inputs.addSelectionInput('chemin', 'Chemin', 'Arete ou courbe d\'esquisse a suivre')
    ch.addSelectionFilter('Edges')
    ch.addSelectionFilter('SketchCurves')
    ch.setSelectionLimits(1, 0)
    rp = inputs.addButtonRowCommandInput('repere', 'Repère', False)
    for k, nom in REPERES:
        rp.listItems.add(nom, k == 'centre', os.path.join(RESOURCES, 'repere_' + k))
    rp.tooltip = ("Point du corps qui suit le chemin et porte la fleche : grande face "
                  "de gauche (cote debut du chemin), centre, ou grande face de droite "
                  "(cote ou part le reseau). Cette face arrive pile au bout du chemin.")
    _set_filtres_objets(inputs)

    inputs.addBoolValueInput('masquer', 'Masquer', True, '', False)
    tb = inputs.addStringValueInput('masques', 'Copies masquées', '')
    tb.tooltip = ('Numeros des copies a ne pas creer, separes par des virgules '
                  '(1 = objet d\'origine). Ex : 2, 4')
    tb.isVisible = False

    inputs.addIntegerSpinnerCommandInput('quantite', 'Quantité', 1, 10000, 1, int(p['quantite']))
    # Champ simple (pas de fleche) : un Distance natif affiche toujours sa
    # propre fleche droite depuis l'origine du dessin, loin du corps.
    inputs.addValueInput('distance', 'Distance', um.defaultLengthUnits,
                         adsk.core.ValueInput.createByReal(1.0))
    ph = inputs.addDistanceValueCommandInput('poignee', 'Ajuster',
                                             adsk.core.ValueInput.createByReal(0.0))
    ph.tooltip = ("Flèche posée sur la dernière copie : tire-la, la dernière copie "
                  "glisse le long du chemin et Distance s'ajuste.")
    fc = inputs.addBoolValueInput('fin_chemin', "Jusqu'au bout du chemin", True, '', False)
    fc.tooltip = ("La derniere copie reste au bout du chemin : si le chemin s'allonge ou "
                  "raccourcit (cote, parametre, extrusion), le reseau se recale tout seul.")
    inputs.addValueInput('depart', 'Point de départ', '', adsk.core.ValueInput.createByReal(0.0))
    _dropdown(inputs, 'repartition', 'Répartition', REPARTITIONS, p['repartition'])
    _dropdown(inputs, 'direction', 'Direction', DIRECTIONS, p['direction'])
    _dropdown(inputs, 'orientation', 'Orientation', ORIENTATIONS, p['orientation'])
    inputs.addBoolValueInput('inverser', 'Inverser le sens', True, '', bool(p['inverser']))
    _dropdown(inputs, 'calcul', 'Type de calcul', CALCULS, p['calcul'])

    msg = inputs.addTextBoxCommandInput('msg', '', '', 2, True)
    msg.isFullWidth = True
    msg.isVisible = False

    _update_visibility(inputs)


def _update_visibility(inputs):
    t = _dd_key(inputs.itemById('type_objet'), TYPES_OBJET)
    inputs.itemById('calcul').isVisible = (t == 'fonctions')
    inputs.itemById('masques').isVisible = bool(inputs.itemById('masquer').value)


def _set_msg(inputs, text):
    m = inputs.itemById('msg')
    text = text or ''
    if m.text != text:
        m.text = text
    if m.isVisible != bool(text):
        m.isVisible = bool(text)


def _current_prefs(inputs):
    return {
        'type_objet': _dd_key(inputs.itemById('type_objet'), TYPES_OBJET),
        'quantite': int(inputs.itemById('quantite').value),
        'repartition': _dd_key(inputs.itemById('repartition'), REPARTITIONS),
        'direction': _dd_key(inputs.itemById('direction'), DIRECTIONS),
        'orientation': _dd_key(inputs.itemById('orientation'), ORIENTATIONS),
        'calcul': _dd_key(inputs.itemById('calcul'), CALCULS),
        'inverser': bool(inputs.itemById('inverser').value),
    }


def _masques(inputs):
    """Numeros (1 = origine) des copies a ne pas creer."""
    if not inputs.itemById('masquer').value:
        return set()
    res = set()
    for morceau in inputs.itemById('masques').value.replace(';', ',').split(','):
        morceau = morceau.strip()
        if '-' in morceau:
            a, _, b = morceau.partition('-')
            try:
                res.update(range(int(a), int(b) + 1))
            except ValueError:
                pass
        elif morceau.isdigit():
            res.add(int(morceau))
    res.discard(1)
    return res


# --- Geometrie du chemin ------------------------------------------------------

def _vec(a, b):
    return adsk.core.Vector3D.create(b.x - a.x, b.y - a.y, b.z - a.z)


def _dist(a, b):
    return a.distanceTo(b)


def _courbe_monde(ent):
    """Courbe 3D (espace du document) d'une arete ou courbe d'esquisse."""
    n = ent.nativeObject if getattr(ent, 'assemblyContext', None) is not None else ent
    if isinstance(n, adsk.fusion.BRepEdge):
        g = n.geometry.copy()
    elif isinstance(n, adsk.fusion.SketchCurve):
        g = n.worldGeometry.copy()
    else:
        return None
    ctx = getattr(ent, 'assemblyContext', None)
    if ctx is not None:
        g.transformBy(ctx.transform2)
    return g


class _Chemin:
    """Chemin echantillonnable par abscisse curviligne. Les segments sont
    remis bout a bout (le sens du premier est choisi pour toucher le 2e)."""

    def __init__(self, entites):
        segs = []
        for e in entites:
            c = _courbe_monde(e)
            if c is None:
                continue
            ev = c.evaluator
            ok, p0, p1 = ev.getParameterExtents()
            ok, L = ev.getLengthAtParameter(p0, p1)
            ok, a = ev.getPointAtParameter(p0)
            ok, b = ev.getPointAtParameter(p1)
            if L > 1e-9:
                segs.append({'ev': ev, 'p0': p0, 'p1': p1, 'L': L, 'a': a, 'b': b, 'inv': False, 'ent': e})
        if not segs:
            raise ValueError('Chemin vide.')
        segs = self._ordonner(segs)
        self.segs = segs
        self.longueur = sum(s['L'] for s in segs)
        self.ferme = _dist(self._debut(segs[0]), self._fin(segs[-1])) < 1e-4

    @staticmethod
    def _debut(s):
        return s['b'] if s['inv'] else s['a']

    @staticmethod
    def _fin(s):
        return s['a'] if s['inv'] else s['b']

    def _ordonner(self, segs):
        if len(segs) == 1:
            return segs
        # Chainage glouton depuis un segment d'extremite (ou le premier).
        restants = segs[:]

        def voisins(s, pt):
            return sum(1 for o in segs if o is not s and min(_dist(pt, o['a']), _dist(pt, o['b'])) < 1e-4)

        depart = restants[0]
        for s in restants:
            if voisins(s, s['a']) == 0:
                depart = s
                break
            if voisins(s, s['b']) == 0:
                depart = s
                s['inv'] = True
                break
        else:
            depart['inv'] = _dist(depart['a'], restants[1]['a']) < 1e-4 or \
                _dist(depart['a'], restants[1]['b']) < 1e-4
        restants.remove(depart)
        ordre = [depart]
        while restants:
            fin = self._fin(ordre[-1])
            best = min(restants, key=lambda o: min(_dist(fin, o['a']), _dist(fin, o['b'])))
            best['inv'] = _dist(fin, best['b']) < _dist(fin, best['a'])
            restants.remove(best)
            ordre.append(best)
        return ordre

    @property
    def debut(self):
        return self._debut(self.segs[0])

    @property
    def fin(self):
        return self._fin(self.segs[-1])

    @property
    def entites(self):
        return [sg['ent'] for sg in self.segs]

    def abscisse_proche(self, pt, smin=0.0, smax=None, n=400):
        """Abscisse du point du chemin le plus proche de pt, dans [smin, smax]."""
        smax = self.longueur if smax is None else smax
        if smax - smin < 1e-9:
            return smin
        pas = (smax - smin) / n
        best = min(range(n + 1), key=lambda k: self.point_tangente(smin + k * pas)[0].distanceTo(pt))
        a, b = max(smin, smin + (best - 1) * pas), min(smax, smin + (best + 1) * pas)
        for _ in range(30):
            m1, m2 = a + (b - a) / 3, b - (b - a) / 3
            if self.point_tangente(m1)[0].distanceTo(pt) < self.point_tangente(m2)[0].distanceTo(pt):
                b = m2
            else:
                a = m1
        return (a + b) / 2

    def point_tangente(self, s):
        """Point et tangente unitaire a l'abscisse s (0..longueur)."""
        if self.ferme:
            s = s % self.longueur
        s = max(0.0, min(self.longueur, s))
        cumul = 0.0
        seg = self.segs[-1]
        loc = seg['L']
        for sg in self.segs:
            if s <= cumul + sg['L'] + 1e-12:
                seg, loc = sg, s - cumul
                break
            cumul += sg['L']
        ev = seg['ev']
        l = (seg['L'] - loc) if seg['inv'] else loc
        ok, prm = ev.getParameterAtLength(seg['p0'], max(0.0, min(seg['L'], l)))
        ok, pt = ev.getPointAtParameter(prm)
        ok, d = ev.getFirstDerivative(prm)
        if seg['inv']:
            d.scaleBy(-1)
        d.normalize()
        return pt, d


def _abscisses(q, D, s0, L, repartition, symetrique, inverse, ferme):
    """Abscisses des instances (la 1re = l'objet d'origine, a s0). Memes
    regles que le reseau natif : Etendue = D entre la 1re et la derniere,
    Espacement = D entre deux instances ; Symetrique = de part et d'autre."""
    if q < 1:
        return []
    if symetrique:
        # Comme le natif : q instances en tout, alternees de part et d'autre
        # (0, +1, -1, +2...) ; en etendue, Distance = un cote.
        idx = [0]
        k = 1
        while len(idx) < q:
            idx.append(k)
            if len(idx) < q:
                idx.append(-k)
            k += 1
        cote = max(abs(i) for i in idx)
        pas = (D / cote if cote else 0.0) if repartition == 'etendue' else D
        return [s0 + i * pas for i in idx]
    if repartition == 'etendue':
        if q == 1:
            pas = 0.0
        elif ferme and abs(D - L) < 1e-6:
            pas = D / q   # tour complet : pas de doublon a l'arrivee
        else:
            pas = D / (q - 1)
    else:
        pas = D
    if inverse:
        pas = -pas
    return [s0 + i * pas for i in range(q)]


# --- Contrainte au plan -------------------------------------------------------

def _construire_chemin(ents):
    """(Path de Fusion, _Chemin) pour les entites choisies. Une seule entite :
    tout l'enchainement tangent, comme la boite native. Plusieurs : dans
    l'ordre ou elles se suivent (dans l'ordre du clic, Fusion faisait un
    chemin decousu et une copie partait hors du chemin, essai du 2026-10-12)."""
    design = adsk.fusion.Design.cast(_app.activeProduct)
    feats = design.activeComponent.features
    if len(ents) == 1:
        path = feats.createPath(ents[0], True)
        try:
            chaine = [path.item(i).entity for i in range(path.count)]
            ctx = getattr(ents[0], 'assemblyContext', None)
            if ctx is not None:
                chaine = [e if getattr(e, 'assemblyContext', None) is not None
                          else e.createForAssemblyContext(ctx) for e in chaine]
            chemin = _Chemin(chaine)
        except Exception:
            chemin = _Chemin(ents)
        return path, chemin
    chemin = _Chemin(ents)
    cc = adsk.core.ObjectCollection.create()
    for c in chemin.entites:
        cc.add(c)
    return feats.createPath(cc, False), chemin


def _debut_path(path):
    """Point de debut d'un Path de Fusion (document)."""
    pe = path.item(0)
    c = pe.curve
    ok, p0, p1 = c.evaluator.getParameterExtents()
    ok, a = c.evaluator.getPointAtParameter(p0)
    ok, b = c.evaluator.getPointAtParameter(p1)
    if path.count > 1:
        c2 = path.item(1).curve
        ok, q0, q1 = c2.evaluator.getParameterExtents()
        ok, a2 = c2.evaluator.getPointAtParameter(q0)
        ok, b2 = c2.evaluator.getPointAtParameter(q1)
        # le debut est l'extremite du 1er troncon qui ne touche pas le 2e
        return b if min(a.distanceTo(a2), a.distanceTo(b2)) < min(b.distanceTo(a2), b.distanceTo(b2)) else a
    return b if pe.isOpposedToEntity else a


def _sens_fusion(path, chemin):
    """(abscisse chez nous du debut du chemin de Fusion, +1/-1 selon que
    Fusion le parcourt dans notre sens ou non). Sur un chemin ferme, debut
    et fin sont confondus : comparer les bouts ne disait rien, Fusion
    pouvait tourner dans l'autre sens et les copies sortaient du chemin
    (2026-10-13). On regarde donc le debut ET le premier
    pas du chemin de Fusion."""
    pe = path.item(0)
    ev = pe.curve.evaluator
    ok, p0, p1 = ev.getParameterExtents()
    ok, L1 = ev.getLengthAtParameter(p0, p1)
    opp = bool(pe.isOpposedToEntity)
    if path.count > 1:
        # plus sur que le drapeau : le debut ne touche pas le 2e troncon
        d0 = _debut_path(path)
        ok, a = ev.getPointAtParameter(p0)
        opp = d0.distanceTo(a) > 1e-6
    ok, d0 = ev.getPointAtParameter(p1 if opp else p0)
    pas = min(0.1, L1 / 10.0)
    ok, pp = ev.getParameterAtLength(p0, (L1 - pas) if opp else pas)
    ok, q = ev.getPointAtParameter(pp)
    off = chemin.abscisse_proche(d0)
    pa = chemin.point_tangente(off + pas)[0]
    pb = chemin.point_tangente(off - pas)[0]
    return off, (1.0 if pa.distanceTo(q) <= pb.distanceTo(q) else -1.0)


def _params_fusion(path, chemin, s0, s_cible):
    """(startPoint, distance, isFlipDirection) de Fusion pour un objet a
    l'abscisse s0 et la copie visee a s_cible (abscisses de notre _Chemin).
    Fusion mesure Distance depuis le debut de SON chemin, qui peut commencer
    ailleurs et etre parcouru dans l'autre sens que le notre."""
    L = chemin.longueur
    try:
        off, sgn = _sens_fusion(path, chemin)
    except Exception:
        _log('sens_fusion erreur %s' % traceback.format_exc()[-400:])
        off, sgn = 0.0, 1.0
    if chemin.ferme:
        # Chemin ferme : mesures du 2026-10-13 (boucle de 4 troncons, 4
        # ordres de clic) : avec startPoint 0 Fusion fait glisser l'objet
        # depuis SA position, dans son sens de parcours, de Distance ; avec
        # startPoint 1 + inverse, dans l'autre sens. Tout autre startPoint
        # donnait des copies hors du chemin.
        glisse = max(-L, min(L, sgn * (s_cible - s0)))
        if glisse >= 0:
            return 0.0, glisse, False
        return 1.0, -glisse, True
    sf0 = max(0.0, min(L, sgn * (s0 - off)))
    s_cible = sf0 + sgn * (s_cible - s0)
    if s_cible >= 0:
        dist, flip = s_cible, False
    else:
        dist, flip = L - s_cible, True       # mesuree depuis la fin du chemin
    return (sf0 / L if L > 0 else 0.0), dist, flip


def _creer_natif(inputs, apercu=False):
    design = adsk.fusion.Design.cast(_app.activeProduct)
    comp = design.activeComponent
    objets = _selections(inputs.itemById('objets'))
    coll = adsk.core.ObjectCollection.create()
    for o in objets:
        coll.add(o)
    ents = _selections(inputs.itemById('chemin'))
    path, chemin = _construire_chemin(ents)
    L = chemin.longueur
    rep = _dd_key(inputs.itemById('repartition'), REPARTITIONS)
    ptype = adsk.fusion.PatternDistanceType.ExtentPatternDistanceType if rep == 'etendue' \
        else adsk.fusion.PatternDistanceType.SpacingPatternDistanceType
    # Nos reglages (comme la boite native vue par l'utilisateur) : la
    # distance part de l'objet. L'API, elle, mesure Distance depuis le debut
    # du chemin (essais du 2026-10-12 sur une droite de 500 mm : depart 0.5,
    # etendue 200 mm -> copies a 250, 225, 200 mm). On convertit donc en
    # abscisse de la derniere copie (etendue) ou de la 2e (espacement).
    s0 = max(0.0, min(1.0, inputs.itemById('depart').value)) * L
    sgn = -1.0 if inputs.itemById('inverser').value else 1.0
    d_in = inputs.itemById('distance').value
    s_cible = s0 + sgn * (d_in * (int(inputs.itemById('quantite').value) - 1) if rep == 'espacement' else d_in)
    if not chemin.ferme:
        # Au-dela du bout du chemin Fusion refuse le reseau : on s'arrete au bout.
        s_cible = max(0.0, min(L, s_cible))
    depart, dist, flip = _params_fusion(path, chemin, s0, s_cible)
    q = adsk.core.ValueInput.createByReal(int(inputs.itemById('quantite').value))
    pps = comp.features.pathPatternFeatures
    pin = pps.createInput(coll, path, q, adsk.core.ValueInput.createByReal(dist), ptype)
    pin.startPoint = depart
    pin.isFlipDirection = flip
    pin.isSymmetric = _dd_key(inputs.itemById('direction'), DIRECTIONS) == 'symetrique'
    pin.isOrientationAlongPath = _dd_key(inputs.itemById('orientation'), ORIENTATIONS) == 'trajectoire'
    if _dd_key(inputs.itemById('type_objet'), TYPES_OBJET) == 'fonctions':
        opt = {'optimise': adsk.fusion.PatternComputeOptions.OptimizedPatternCompute,
               'identique': adsk.fusion.PatternComputeOptions.IdenticalPatternCompute,
               'ajuster': adsk.fusion.PatternComputeOptions.AdjustPatternCompute}
        pin.patternComputeOption = opt[_dd_key(inputs.itemById('calcul'), CALCULS)]
    feat = pps.add(pin)
    if not apercu and _fin_chemin(inputs):
        try:
            feat.attributes.add(ATTR_GROUPE, ATTR_FIN, json.dumps({
                'repere': _repere_cle(inputs), 'inverser': bool(inputs.itemById('inverser').value),
                'repartition': rep, 'objets': [o.entityToken for o in objets]}))
        except Exception:
            _log('attribut fin erreur %s' % traceback.format_exc()[-400:])
    masques = _masques(inputs)
    if masques and not apercu:
        # L'API exige le marqueur de timeline juste avant la fonction pour
        # masquer des elements. Numero 1 = origine = 1er element.
        try:
            elems = feat.patternElements
            ids = [elems.item(n - 1).id for n in sorted(masques) if n - 1 < elems.count]
            feat.timelineObject.rollTo(True)
            feat.suppressedElementsIds = ids
        except Exception:
            pass
        finally:
            try:
                design.timeline.moveToEnd()
            except Exception:
                pass
    return feat


def _centre_objets(inputs):
    """Centre (document) des objets selectionnes, None si inconnu."""
    pts = []
    for o in _selections(inputs.itemById('objets')):
        try:
            bb = o.boundingBox
            pts.append(((bb.minPoint.x + bb.maxPoint.x) / 2, (bb.minPoint.y + bb.maxPoint.y) / 2,
                        (bb.minPoint.z + bb.maxPoint.z) / 2))
        except Exception:
            continue
    if not pts:
        return None
    n = float(len(pts))
    return adsk.core.Point3D.create(sum(p[0] for p in pts) / n, sum(p[1] for p in pts) / n,
                                    sum(p[2] for p in pts) / n)


def _grandes_faces(corps):
    """Les deux grandes faces planes opposees du panneau (pas les chants)."""
    planes = []
    for i in range(corps.faces.count):
        f = corps.faces.item(i)
        try:
            if isinstance(f.geometry, adsk.core.Plane):
                planes.append(f)
        except Exception:
            continue
    if len(planes) < 2:
        return []
    f1 = max(planes, key=lambda f: f.area)
    n1 = f1.geometry.normal
    opp = [f for f in planes if f is not f1 and abs(abs(f.geometry.normal.dotProduct(n1)) - 1) < 1e-3
           and abs(_vec(f1.centroid, f.centroid).dotProduct(n1)) > 1e-4]
    if not opp:
        return []
    return [f1, max(opp, key=lambda f: f.area)]


def _repere_cle(inputs):
    try:
        rp = inputs.itemById('repere')
        return REPERES[rp.selectedItem.index][0] if rp.selectedItem else 'centre'
    except Exception:
        return 'centre'


def _centre_bbox(objs):
    pts = []
    for o in objs:
        try:
            bb = o.boundingBox
            pts.append(((bb.minPoint.x + bb.maxPoint.x) / 2, (bb.minPoint.y + bb.maxPoint.y) / 2,
                        (bb.minPoint.z + bb.maxPoint.z) / 2))
        except Exception:
            continue
    if not pts:
        return None
    n = float(len(pts))
    return adsk.core.Point3D.create(sum(p[0] for p in pts) / n, sum(p[1] for p in pts) / n,
                                    sum(p[2] for p in pts) / n)


def _repere_objets(objs, k, ch, s0, inv):
    """Centre des objets, ou centre de leur grande face de gauche / droite
    (gauche = cote debut du chemin, droite = cote ou part le reseau)."""
    c = _centre_bbox(objs)
    if k == 'centre' or c is None:
        return c
    corps = [o for o in objs if isinstance(o, adsk.fusion.BRepBody)]
    faces = _grandes_faces(corps[0]) if corps else []
    if not faces:
        return c
    _p, tg = ch.point_tangente(s0)
    sens = adsk.core.Vector3D.create(tg.x, tg.y, tg.z)
    if inv:
        sens.scaleBy(-1)
    faces.sort(key=lambda f: _vec(c, f.centroid).dotProduct(sens))
    return (faces[-1] if k == 'droite' else faces[0]).centroid


def _point_repere(inputs, ch=None, s0=None, inv=False):
    """Point de l'objet qui suit le chemin (voir _repere_objets) : cette face
    arrive pile au point vise du chemin, bout compris."""
    objs = _selections(inputs.itemById('objets'))
    if ch is None:
        return _centre_bbox(objs)
    return _repere_objets(objs, _repere_cle(inputs), ch, s0, inv)


# --- Bout du chemin parametrique --------------------------------------------
# Un reseau cree avec "Jusqu'au bout du chemin" garde un attribut. Apres
# chaque commande terminee (cote d'esquisse, parametre, extrusion...), si la
# chronologie est a la fin, on remesure son chemin et on recale le reseau pour
# que la face de repere de la derniere copie reste au bout du chemin.

ATTR_GROUPE = 'ReseauTrajectoireCNC'
ATTR_FIN = 'fin_chemin'
_resync_en_cours = {'v': False}


def _fin_chemin(inputs):
    try:
        return bool(inputs.itemById('fin_chemin').value) and \
            _dd_key(inputs.itemById('repartition'), REPARTITIONS) == 'etendue'
    except Exception:
        return False


def _bout(ch, s0, inv, q):
    """Abscisse du "bout du chemin" pour la derniere copie. Chemin ouvert :
    son extremite. Chemin ferme : un tour complet, la derniere copie juste
    avant l'objet (copies regulieres tout autour) ; avant, la fleche butait
    sur la jonction du debut de la boucle (2026-10-13)."""
    if ch.ferme:
        tour = ch.longueur * (max(1, q) - 1) / float(max(1, q))
        return s0 - tour if inv else s0 + tour
    return 0.0 if inv else ch.longueur


def _bout_inputs(inputs, ch, s0):
    return _bout(ch, s0, bool(inputs.itemById('inverser').value), int(inputs.itemById('quantite').value))


def _maj_case_fin(inputs, ch, s0, s_fin):
    """Coche la case quand la derniere copie est au bout du chemin."""
    try:
        inputs.itemById('fin_chemin').value = abs(s_fin - _bout_inputs(inputs, ch, s0)) < 1e-3
    except Exception:
        pass


def _resync_reseau(feat, reglages):
    path = feat.path
    ents = [path.item(i).entity for i in range(path.count)]
    ch = _Chemin(ents)
    L = ch.longueur
    # inputEntities exige de reculer la chronologie : on garde les jetons.
    design = adsk.fusion.Design.cast(_app.activeProduct)
    objs = []
    for tok in reglages.get('objets', []):
        try:
            trouves = design.findEntityByToken(tok)
            if trouves:
                objs.append(trouves[0])
        except Exception:
            continue
    if not objs:
        return False
    inv = bool(reglages.get('inverser'))
    if L <= 0:
        return False
    s0, inv = _depart_objets(ch, objs, reglages.get('repere', 'centre'), inv)
    depart, dist, flip = _params_fusion(path, ch, s0, _bout(ch, s0, inv, int(feat.quantity.value)))
    dp = feat.distance
    if ch.ferme:
        # Boucle : Fusion glisse l'objet depuis sa position, seule la distance
        # compte. Il renvoie startPoint = position de l'objet (pas le 0 donne
        # a la creation) et le reecrire decalait les copies hors du chemin
        # (essai du 2026-10-13) : on ne touche qu'a la distance.
        if abs(dp.value - dist) < 1e-5:
            return False
        dp.expression = '%.6f mm' % (dist * 10.0)
        _log('resync %s (boucle) L=%.3f s0=%.3f -> dist=%.3f' % (feat.name, L, s0, dist))
        return True
    if abs(feat.startPoint - depart) < 1e-7 and abs(dp.value - dist) < 1e-5 and feat.isFlipDirection == flip:
        return False
    # startPoint et le sens ne se modifient que chronologie reculee juste
    # avant la fonction (sinon "Didn't roll editing feature back").
    dp.expression = '%.6f mm' % (dist * 10.0)
    if abs(feat.startPoint - depart) >= 1e-7 or feat.isFlipDirection != flip:
        tl = design.timeline
        try:
            feat.timelineObject.rollTo(True)
            feat.startPoint = depart
            feat.isFlipDirection = flip
        finally:
            tl.moveToEnd()
    _log('resync %s L=%.3f s0=%.3f -> depart=%.5f dist=%.3f' % (feat.name, L, s0, depart, dist))
    return True


def _resync_tous():
    if _resync_en_cours['v']:
        return
    design = adsk.fusion.Design.cast(_app.activeProduct)
    if design is None:
        return
    try:
        tl = design.timeline
        if tl.markerPosition < tl.count:
            return   # chronologie en arriere : on recalera en revenant a la fin
    except Exception:
        pass
    _resync_en_cours['v'] = True
    fait = False
    try:
        for attr in design.findAttributes(ATTR_GROUPE, ATTR_FIN):
            try:
                feat = adsk.fusion.PathPatternFeature.cast(attr.parent)
                if feat is None or not feat.isValid or feat.isSuppressed:
                    continue
                if _resync_reseau(feat, json.loads(attr.value or '{}')):
                    fait = True
            except Exception:
                _log('resync erreur %s' % traceback.format_exc()[-500:])
    finally:
        _resync_en_cours['v'] = False
    return fait


# Un recalage est une etape d'annulation a part : Ctrl+Z annulait d'abord
# le recalage (le reseau bougeait) et pas la cote modifiee (retours du
# 2026-10-13). On enchaine donc nous-memes le 2e Annuler (et le 2e Retablir)
# pour que la modification et son recalage s'annulent ensemble.
_pile = {'etat': None}
ACTION_ID = 'ReseauTrajectoireCNC_action'
_action = {'evt': None, 'h': None}


def _annuler_ensemble(cid):
    e = _pile['etat']
    _log('%s (etat %s)' % (cid, e))
    if cid == 'UndoCommand':
        if e == 'recale':
            _pile['etat'] = 'annul_auto'
            _differer('UndoCommand')
        elif e == 'annul_auto':
            _pile['etat'] = 'a_retablir'
        else:
            _pile['etat'] = None
    else:
        if e == 'a_retablir':
            _pile['etat'] = 'retab_auto'
            _differer('RedoCommand')
        elif e == 'retab_auto':
            _pile['etat'] = 'recale'
        else:
            _pile['etat'] = None


class _ActionHandler(adsk.core.CustomEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            d = _ui.commandDefinitions.itemById(args.additionalInfo)
            if d is not None:
                d.execute()
        except Exception:
            _log('action erreur %s' % traceback.format_exc()[-400:])


def _differer(cmd_id):
    try:
        if _action['evt'] is None:
            try:
                _app.unregisterCustomEvent(ACTION_ID)
            except Exception:
                pass
            _action['evt'] = _app.registerCustomEvent(ACTION_ID)
            _action['h'] = _ActionHandler()
            _action['evt'].add(_action['h'])
        _app.fireCustomEvent(ACTION_ID, cmd_id)
    except Exception:
        _log('differer erreur %s' % traceback.format_exc()[-400:])


# ActivateEnvironmentCommand se termine juste apres chaque Annuler : il
# relancait le recalage, que l'Annuler suivant defaisait... a l'infini
# (journal du 2026-10-13, reseau qui fait 0, 1, 0, 1).
CMDS_IGNOREES = ('UndoCommand', 'RedoCommand', 'SelectCommand', 'CommitCommand',
                 'ActivateEnvironmentCommand')


class _CommandTerminatedHandler(adsk.core.ApplicationCommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            # Annuler / Retablir : surtout ne pas recaler, sinon Ctrl+Z annule
            # le recalage et on le refait aussitot (boucle, retours du
            # 2026-10-13). Seules les commandes menees a terme comptent.
            import time
            cid = args.commandId or ''
            if cid == 'UndoCommand' or cid == 'RedoCommand':
                _pile['t'] = time.perf_counter()
                _annuler_ensemble(cid)
                return
            if time.perf_counter() - _pile.get('t', -10.0) < 2.0:
                return   # commande annexe d'un Annuler / Retablir
            if cid == CMD_ID or cid in CMDS_IGNOREES or 'Undo' in cid or 'Redo' in cid:
                return
            if args.terminationReason != adsk.core.CommandTerminationReason.CompletedTerminationReason:
                return
            _pile['etat'] = None
            if _resync_tous():
                _pile['etat'] = 'recale'
                _log('recale apres %s' % cid)
        except Exception:
            _log('commandTerminated erreur %s' % traceback.format_exc()[-500:])


# Retour a la fin de la chronologie : deplacer le marqueur n'est pas une
# commande, donc rien ne recalait le reseau apres avoir modifie le chemin en
# arriere dans la chronologie (2026-10-13). Un minuteur
# regarde chaque seconde si le marqueur vient de revenir a la fin.
TICK_ID = 'ReseauTrajectoireCNC_tick'
_tick = {'evt': None, 'h': None, 'stop': None, 'fin': {}}


class _TickHandler(adsk.core.CustomEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            design = adsk.fusion.Design.cast(_app.activeProduct)
            if design is None or _ui.activeCommand != 'SelectCommand':
                return
            tl = design.timeline
            cle = _app.activeDocument.name if _app.activeDocument else ''
            a_la_fin = tl.markerPosition >= tl.count
            avant = _tick['fin'].get(cle, True)
            _tick['fin'][cle] = a_la_fin
            if a_la_fin and not avant:
                _pile['etat'] = None
                if _resync_tous():
                    _log('recale au retour en fin de chronologie')
        except Exception:
            pass


def _demarrer_tick():
    import threading
    try:
        _tick['evt'] = _app.registerCustomEvent(TICK_ID)
        h = _TickHandler()
        _tick['evt'].add(h)
        _tick['h'] = h
        stop_evt = threading.Event()
        _tick['stop'] = stop_evt

        def boucle():
            while not stop_evt.wait(1.0):
                try:
                    _app.fireCustomEvent(TICK_ID, '')
                except Exception:
                    pass
        threading.Thread(target=boucle, daemon=True).start()
    except Exception:
        _log('tick erreur %s' % traceback.format_exc()[-400:])


def _arreter_tick():
    try:
        if _tick['stop'] is not None:
            _tick['stop'].set()
        if _tick['evt'] is not None and _tick['h'] is not None:
            _tick['evt'].remove(_tick['h'])
        _app.unregisterCustomEvent(TICK_ID)
    except Exception:
        pass
    _tick.update({'evt': None, 'h': None, 'stop': None})


def _dans_bbox(objs, pt, marge=0.2):
    for o in objs:
        try:
            bb = o.boundingBox
        except Exception:
            continue
        if all(getattr(bb.minPoint, a) - marge <= getattr(pt, a) <= getattr(bb.maxPoint, a) + marge
               for a in ('x', 'y', 'z')):
            return True
    return False


def _depart_objets(ch, objs, k, inv=None):
    """(abscisse de depart, sens inverse) pour des objets et un repere.
    Chemin qui touche l'objet (arete du corps, esquisse posee dessus) : on
    part du point du chemin le plus proche. Chemin a distance (esquisse a
    cote du corps) : le point le plus proche peut tomber n'importe ou au
    milieu et les copies partaient dans le mauvais sens (retours du
    2026-10-13) ; on part alors du bout du chemin le plus proche de l'objet,
    vers l'autre bout, comme le Reseau natif."""
    c = _centre_bbox(objs)
    L = ch.longueur
    if c is None or L <= 0:
        return 0.0, bool(inv)
    s0 = ch.abscisse_proche(c)
    colle = ch.ferme or _dans_bbox(objs, ch.point_tangente(s0)[0])
    if not colle:
        s0 = 0.0 if c.distanceTo(ch.debut) <= c.distanceTo(ch.fin) else L
    if inv is None:
        inv = s0 > L - s0
    r = _repere_objets(objs, k, ch, s0, inv)
    if r is not None and r is not c:
        if colle:
            s0 = ch.abscisse_proche(r)
        else:
            # decalage de la face le long du chemin, depuis le bout
            _p, tg = ch.point_tangente(s0)
            s0 = max(0.0, min(L, s0 + _vec(c, r).dotProduct(tg)))
    return s0, inv


def _maj_chemin(inputs, recaler=False):
    """Chemin ou objets modifies : le point de depart se cale sur le point du
    chemin le plus proche de l'objet (le reseau natif part du bout du chemin,
    et les copies se retrouvaient decalees hors du chemin), la distance
    prend la longueur restante, et la fleche se place sur la derniere copie,
    dans le sens du chemin a cet endroit."""
    global _dernier_chemin
    ents = _selections(inputs.itemById('chemin'))
    if not ents:
        return
    try:
        ch = _construire_chemin(ents)[1]
    except Exception:
        _log('maj_chemin erreur %s' % traceback.format_exc()[-600:])
        return
    di = inputs.itemById('distance')
    dep = inputs.itemById('depart')
    cle = (round(ch.longueur, 6), inputs.itemById('objets').selectionCount)
    if recaler or cle != _dernier_chemin:
        _dernier_chemin = cle
        # Objet pose sur le chemin : on part du cote ou il reste le plus de
        # chemin. Chemin a distance : du bout le plus proche (_depart_objets).
        s0, inv = _depart_objets(ch, _selections(inputs.itemById('objets')), _repere_cle(inputs))
        dep.value = s0 / ch.longueur if ch.longueur > 0 else 0.0
        inputs.itemById('inverser').value = inv
        reste = abs(_bout(ch, s0, inv, int(inputs.itemById('quantite').value)) - s0)
        if _dd_key(inputs.itemById('repartition'), REPARTITIONS) == 'etendue':
            di.value = reste
    _placer_fleche(inputs, ch)


_poignee_ref = {}
_en_cours = {'v': False}
JOURNAL = os.path.join(_ADDIN_DIR, 'reseau_journal.txt')


def _log(msg):
    """Journal de debug (reseau_journal.txt), tronque a ~100 Ko."""
    try:
        import time
        if os.path.exists(JOURNAL) and os.path.getsize(JOURNAL) > 100000:
            os.remove(JOURNAL)
        with open(JOURNAL, 'a', encoding='utf-8') as f:
            f.write('%s %s\n' % (time.strftime('%H:%M:%S'), msg))
    except Exception:
        pass


def _s_fin(inputs, ch, s0):
    """Abscisse de la derniere copie d'apres Distance / Repartition."""
    sgn = -1.0 if inputs.itemById('inverser').value else 1.0
    d = inputs.itemById('distance').value
    if _dd_key(inputs.itemById('repartition'), REPARTITIONS) == 'espacement':
        d *= max(1, int(inputs.itemById('quantite').value) - 1)
    s = s0 + sgn * d
    return s if ch.ferme else max(0.0, min(ch.longueur, s))


def _limites(inputs, ch, s0):
    """Plage d'abscisses ou peut tomber la derniere copie."""
    if ch.ferme:
        # un tour au plus, du cote du sens choisi (la jonction de debut de
        # boucle n'arrete plus la fleche)
        return (s0 - ch.longueur, s0) if inputs.itemById('inverser').value else (s0, s0 + ch.longueur)
    return (0.0, s0) if inputs.itemById('inverser').value else (s0, ch.longueur)


def _placer_fleche(inputs, ch=None):
    """Fleche posee sur le chemin, a la derniere copie, tangente au chemin,
    comme le Reseau natif. Un Distance natif dessine un trait DROIT de sa
    valeur depuis son origine (il sortait du chemin, retours du 2026-10-13) :
    on met donc son origine sur la derniere copie avec une valeur 0, et la
    forme du chemin est dessinee en pointilles (_dessiner_pointilles)."""
    _echant['cle'] = None
    try:
        if ch is None:
            ch = _construire_chemin(_selections(inputs.itemById('chemin')))[1]
        s0 = max(0.0, min(1.0, inputs.itemById('depart').value)) * ch.longueur
        s_end = _s_fin(inputs, ch, s0)
        pe, tge = ch.point_tangente(s_end)
        v = adsk.core.Vector3D.create(tge.x, tge.y, tge.z)
        if inputs.itemById('inverser').value:
            v.scaleBy(-1)
        v.normalize()
        _poignee_ref.clear()
        _poignee_ref.update({'s0': s0, 's_ref': s_end, 'pe': pe, 'dir': v})
        ph = inputs.itemById('poignee')
        ph.setManipulator(pe, v)
        ph.value = 0.0
        _maj_case_fin(inputs, ch, s0, s_end)
        _log('fleche bout=%s dir=%s s0=%.2f s_end=%.2f' % ([round(c, 2) for c in pe.asArray()],
                                                         [round(c, 2) for c in v.asArray()], s0, s_end))
    except Exception:
        _log('placer_fleche erreur %s' % traceback.format_exc()[-600:])


_souris = {'pos': None, 'vp': None, 't': 0.0, 'n': 0}
_echant = {'cle': None, 'pts': []}


def _echantillons(ch, n=400):
    """Points du chemin tous les L/n (mis en cache pour le glisser)."""
    cle = (round(ch.longueur, 6), len(ch.segs), n)
    if _echant['cle'] != cle:
        _echant['pts'] = [(ch.longueur * k / n, ch.point_tangente(ch.longueur * k / n)[0]) for k in range(n + 1)]
        _echant['cle'] = cle
    return _echant['pts']


def _abscisse_souris(ch, lo, hi, s_prev):
    """Abscisse du point du chemin le plus proche de la souris A L'ECRAN :
    la copie suit le curseur dans les virages, comme le Reseau natif. On
    reste pres de la position precedente pour ne pas sauter d'une branche a
    une autre qui passerait sous le curseur."""
    import time
    if _souris['pos'] is None or time.perf_counter() - _souris['t'] > 0.5:
        return None
    vp, m = _souris['vp'], _souris['pos']
    pts = _echantillons(ch)
    fen = max(ch.longueur * 0.15, 1.0)

    def d2(pt):
        q = vp.modelToViewSpace(pt)
        return (q.x - m.x) ** 2 + (q.y - m.y) ** 2

    decal = (-ch.longueur, 0.0, ch.longueur) if ch.ferme else (0.0,)
    cand = [(sx + m, pt) for sx, pt in pts for m in decal
            if lo - 1e-9 <= sx + m <= hi + 1e-9 and abs(sx + m - s_prev) <= fen]
    if not cand:
        return None
    sb, _p = min(cand, key=lambda c: d2(c[1]))
    pas = ch.longueur / (len(pts) - 1)
    a, b = max(lo, sb - pas), min(hi, sb + pas)
    best = min((a + (b - a) * k / 20 for k in range(21)), key=lambda sx: d2(ch.point_tangente(sx)[0]))
    return best


def _poignee_tiree(inputs):
    """La fleche est tiree. La derniere copie va au point du chemin le plus
    proche de la souris a l'ecran (glisser continu dans les virages, retours
    du 2026-10-13). Sans position de souris, repli : point du chemin le plus
    proche du bout de la fleche (droite fixe), pres de la position
    precedente. La fleche est recalee sur le chemin au relachement."""
    try:
        if 'pe' not in _poignee_ref:
            return
        val = inputs.itemById('poignee').value
        import time
        m = _souris['pos'] if time.perf_counter() - _souris['t'] <= 0.5 else None
        cle = (round(m.x, 1), round(m.y, 1)) if m is not None else round(val, 6)
        if cle == _poignee_ref.get('cle'):
            return   # meme mouvement recu deux fois
        _poignee_ref['cle'] = cle
        ch = _construire_chemin(_selections(inputs.itemById('chemin')))[1]
        s0, pe, v = (_poignee_ref[k] for k in ('s0', 'pe', 'dir'))
        s_prev = _poignee_ref.get('s_cur', _poignee_ref['s_ref'])
        lo, hi = _limites(inputs, ch, s0)
        mode = 'souris'
        s_fin = None
        try:
            s_fin = _abscisse_souris(ch, lo, hi, s_prev)
        except Exception:
            _log('souris erreur %s' % traceback.format_exc()[-400:])
        if s_fin is None:
            mode = 'fleche'
            q = adsk.core.Point3D.create(pe.x + v.x * val, pe.y + v.y * val, pe.z + v.z * val)
            w = abs(val - _poignee_ref.get('val', 0.0)) * 2.0 + 0.5
            s_fin = ch.abscisse_proche(q, max(lo, s_prev - w), min(hi, s_prev + w), n=40)
        _poignee_ref['val'] = val
        _poignee_ref['s_cur'] = s_fin
        if mode == 'souris':
            # La copie suit la souris : la fleche est recalee sur elle, sur le
            # chemin et tangente, pendant le glisser (comme le natif). Sa
            # valeur ne sert plus au calcul, donc ce recalage ne perturbe rien.
            pn, tn = ch.point_tangente(s_fin)
            vn = adsk.core.Vector3D.create(tn.x, tn.y, tn.z)
            if inputs.itemById('inverser').value:
                vn.scaleBy(-1)
            vn.normalize()
            _poignee_ref.update({'pe': pn, 'dir': vn, 's_ref': s_fin, 'val': 0.0})
            ph = inputs.itemById('poignee')
            ph.setManipulator(pn, vn)
            ph.value = 0.0
        d = abs(s_fin - s0)
        if _dd_key(inputs.itemById('repartition'), REPARTITIONS) == 'espacement':
            d /= max(1, int(inputs.itemById('quantite').value) - 1)
        inputs.itemById('distance').value = d
        _maj_case_fin(inputs, ch, s0, s_fin)
        _log('poignee tiree (%s) val=%.2f -> s=%.2f distance=%.2f' % (mode, val, s_fin, d))
    except Exception:
        _log('poignee_tiree erreur %s' % traceback.format_exc()[-600:])


class _MouseHandler(adsk.core.MouseEventHandler):
    """Garde la derniere position de la souris (glisser et deplacement)."""
    def __init__(self, nom): super().__init__(); self.nom = nom
    def notify(self, args):
        try:
            import time
            _souris['pos'] = args.viewportPosition
            _souris['vp'] = args.viewport
            _souris['t'] = time.perf_counter()
            _souris['n'] += 1
            if _souris['n'] % 50 == 1:
                _log('%s n=%d' % (self.nom, _souris['n']))
        except Exception:
            pass


def _recaler_fleche(inputs):
    """Fin du glisser : la fleche revient sur le chemin a la derniere copie."""
    if 's_cur' in _poignee_ref:
        _en_cours['v'] = True
        try:
            _placer_fleche(inputs)
        finally:
            _en_cours['v'] = False


class _MouseUpHandler(adsk.core.MouseEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            _log('mouseUp')
            _recaler_fleche(args.firingEvent.sender.commandInputs)
        except Exception:
            _log('mouseUp erreur %s' % traceback.format_exc()[-600:])


_pointilles = {'g': None}


def _effacer_pointilles():
    g = _pointilles['g']
    _pointilles['g'] = None
    try:
        if g is not None and g.isValid:
            g.deleteMe()
    except Exception:
        pass


def _dessiner_pointilles(inputs):
    """Pointilles gris le long du chemin, de l'objet a la derniere copie
    (comme le Reseau natif). Une seule polyligne : leger meme pour un long
    chemin."""
    _effacer_pointilles()
    try:
        ch = _construire_chemin(_selections(inputs.itemById('chemin')))[1]
        s0 = max(0.0, min(1.0, inputs.itemById('depart').value)) * ch.longueur
        s_end = _s_fin(inputs, ch, s0)
        if abs(s_end - s0) < 1e-6:
            return
        n = 200
        pts = []
        for k in range(n + 1):
            pt = ch.point_tangente(s0 + (s_end - s0) * k / n)[0]
            pts += [pt.x, pt.y, pt.z]
        design = adsk.fusion.Design.cast(_app.activeProduct)
        g = design.rootComponent.customGraphicsGroups.add()
        lignes = g.addLines(adsk.fusion.CustomGraphicsCoordinates.create(pts), [], True)
        lignes.lineStylePattern = adsk.fusion.LineStylePatterns.dotLineStylePattern
        lignes.weight = 2
        lignes.color = adsk.fusion.CustomGraphicsSolidColorEffect.create(adsk.core.Color.create(110, 110, 110, 255))
        lignes.isSelectable = False
        _pointilles['g'] = g
    except Exception:
        _log('pointilles erreur %s' % traceback.format_exc()[-600:])


def _lancer_natif(motcle):
    d = _cmd_native(motcle)
    if d is not None:
        try:
            d.execute()
        except Exception:
            pass


# --- Handlers ---------------------------------------------------------------

class _CreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            global _pending_prefs, _dernier_chemin
            _pending_prefs = None
            _dernier_chemin = None
            cmd = args.command
            _log('cree')
            _build_inputs(cmd)
            _log('inputs ok')
            for ev, h in ((cmd.inputChanged, _InputChangedHandler()),
                          (cmd.executePreview, _PreviewHandler()),
                          (cmd.validateInputs, _ValidateHandler()),
                          (cmd.execute, _ExecuteHandler()),
                          (cmd.destroy, _DestroyHandler()),
                          (cmd.mouseUp, _MouseUpHandler()),
                          (cmd.mouseDrag, _MouseHandler('mouseDrag')),
                          (cmd.mouseMove, _MouseHandler('mouseMove'))):
                ev.add(h)
                _handlers.append(h)
        except Exception:
            _log('cree erreur ' + traceback.format_exc()[-800:])
            _ui.messageBox('Erreur Reseau sur la trajectoire CNC:\n' + traceback.format_exc(), COMMAND_NAME)


class _InputChangedHandler(adsk.core.InputChangedEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            inp = args.input
            inputs = inp.parentCommand.commandInputs
            iid = inp.id
            _log('changed %s%s' % (iid, ' (ignore, reentrance)' if _en_cours['v'] else ''))
            if _en_cours['v']:
                return   # changement provoque par nos propres ecritures de valeurs
            _en_cours['v'] = True
            try:
                self._traiter(inputs, iid, inp)
            finally:
                _en_cours['v'] = False
        except Exception:
            _log('inputChanged erreur %s' % traceback.format_exc()[-600:])

    def _traiter(self, inputs, iid, inp):
        try:
            if iid == 'type_reseau':
                nom = inp.selectedItem.name if inp.selectedItem else ''
                if 'rectangulaire' in nom:
                    _lancer_natif('RectangularPattern')
                elif 'circulaire' in nom:
                    _lancer_natif('CircularPattern')
                return
            if iid == 'type_objet':
                inputs.itemById('objets').clearSelection()
                _set_filtres_objets(inputs)
            if iid in ('chemin', 'objets'):
                _maj_chemin(inputs)
            elif iid == 'repere':
                _maj_chemin(inputs, recaler=True)
            elif iid == 'fin_chemin':
                if inp.value:
                    ch = _construire_chemin(_selections(inputs.itemById('chemin')))[1]
                    s0 = max(0.0, min(1.0, inputs.itemById('depart').value)) * ch.longueur
                    reste = abs(_bout_inputs(inputs, ch, s0) - s0)
                    if _dd_key(inputs.itemById('repartition'), REPARTITIONS) == 'espacement':
                        reste /= max(1, int(inputs.itemById('quantite').value) - 1)
                    inputs.itemById('distance').value = reste
                    _placer_fleche(inputs, ch)
            elif iid == 'poignee':
                _poignee_tiree(inputs)
            elif iid in ('depart', 'inverser', 'distance', 'quantite', 'repartition'):
                _placer_fleche(inputs)
            if iid in ('type_objet', 'masquer'):
                _update_visibility(inputs)
        except Exception:
            _log('inputChanged erreur %s' % traceback.format_exc()[-600:])


class _ValidateHandler(adsk.core.ValidateInputsEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            inputs = args.inputs
            ok = inputs.itemById('objets').selectionCount > 0 and \
                inputs.itemById('chemin').selectionCount > 0 and \
                inputs.itemById('distance').isValidExpression
            args.areInputsValid = ok
        except Exception:
            pass


class _PreviewHandler(adsk.core.CommandEventHandler):
    """Apercu = la vraie fonction Reseau de Fusion (corps gris, calcul natif :
    le plus leger meme avec beaucoup de copies). Fusion l'annule tout seul
    a chaque changement de reglage."""
    def __init__(self): super().__init__()
    def notify(self, args):
        global _pending_prefs
        inputs = args.command.commandInputs
        try:
            _log('preview objets=%d chemin=%d q=%s dist=%.3f' % (
                inputs.itemById('objets').selectionCount, inputs.itemById('chemin').selectionCount,
                inputs.itemById('quantite').value, inputs.itemById('distance').value))
            if not (inputs.itemById('objets').selectionCount and inputs.itemById('chemin').selectionCount):
                _set_msg(inputs, '')
                return
            import time
            t0 = time.perf_counter()
            _creer_natif(inputs, apercu=True)
            _log('preview ok %.0f ms' % ((time.perf_counter() - t0) * 1000))
            _dessiner_pointilles(inputs)
            _set_msg(inputs, '')
            _pending_prefs = _current_prefs(inputs)
        except ValueError as e:
            _log('preview ValueError %s' % e)
            _set_msg(inputs, str(e))
        except Exception as e:
            _log('preview erreur %s' % traceback.format_exc()[-600:])
            _set_msg(inputs, 'Reseau impossible avec ces reglages : ' + str(e).splitlines()[-1][:200])


class _ExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        global _pending_prefs
        inputs = args.command.commandInputs
        _effacer_pointilles()
        try:
            _creer_natif(inputs)
            _pending_prefs = _current_prefs(inputs)
        except ValueError as e:
            args.executeFailed = True
            args.executeFailedMessage = str(e)
        except Exception as e:
            args.executeFailed = True
            args.executeFailedMessage = 'Reseau impossible : ' + str(e).splitlines()[-1][:300]


class _DestroyHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        global _pending_prefs
        _effacer_pointilles()
        try:
            if args.terminationReason == adsk.core.CommandTerminationReason.CompletedTerminationReason \
                    and _pending_prefs:
                save_prefs(_pending_prefs)
        except Exception:
            pass
        _pending_prefs = None


def _controle_reseau(panel):
    """Menu deroulant Reseau du panneau Creer (celui qui contient la commande
    native), pour ranger notre bouton a cote du reseau natif."""
    natif = _cmd_native('PathPattern')
    if natif is None:
        return None, None
    for i in range(panel.controls.count):
        c = panel.controls.item(i)
        if c.objectType == adsk.core.DropDownControl.classType():
            try:
                if c.controls.itemById(natif.id):
                    return c.controls, natif.id
            except Exception:
                continue
    return None, natif.id


def run(context):
    global _app, _ui
    try:
        _app = adsk.core.Application.get()
        _ui = _app.userInterface
        old = _ui.commandDefinitions.itemById(CMD_ID)
        if old:
            old.deleteMe()
        res = _icone_native('PathPattern') or (RESOURCES if os.path.isdir(RESOURCES) else '')
        cmd_def = _ui.commandDefinitions.addButtonDefinition(CMD_ID, COMMAND_NAME, COMMAND_DESC, res)
        on_created = _CreatedHandler()
        cmd_def.commandCreated.add(on_created)
        _handlers.append(on_created)
        on_term = _CommandTerminatedHandler()
        _ui.commandTerminated.add(on_term)
        _handlers.append(on_term)
        _term['h'] = on_term
        _arreter_tick()
        _demarrer_tick()
        panel = _ui.allToolbarPanels.itemById(PANEL_ID)
        if panel:
            ctrls, apres = _controle_reseau(panel)
            if ctrls is None:
                ctrls = panel.controls
            if not ctrls.itemById(CMD_ID):
                if apres and ctrls.itemById(apres):
                    ctrls.addCommand(cmd_def, apres, False)
                else:
                    ctrls.addCommand(cmd_def)
    except Exception:
        if _ui:
            _ui.messageBox('Erreur au demarrage de Reseau sur la trajectoire CNC:\n' + traceback.format_exc())


_term = {'h': None}


def stop(context):
    _arreter_tick()
    try:
        if _action['evt'] is not None:
            _action['evt'].remove(_action['h'])
        _app.unregisterCustomEvent(ACTION_ID)
    except Exception:
        pass
    _action.update({'evt': None, 'h': None})
    try:
        if _term['h'] is not None:
            _ui.commandTerminated.remove(_term['h'])
            _term['h'] = None
    except Exception:
        pass
    try:
        panel = _ui.allToolbarPanels.itemById(PANEL_ID)
        if panel:
            ctrls, _ = _controle_reseau(panel)
            for cs in (ctrls, panel.controls):
                if cs is None:
                    continue
                c = cs.itemById(CMD_ID)
                if c:
                    c.deleteMe()
        cd = _ui.commandDefinitions.itemById(CMD_ID)
        if cd:
            cd.deleteMe()
    except Exception:
        pass
    _handlers.clear()
