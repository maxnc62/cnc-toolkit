# -*- coding: utf-8 -*-
"""
SELECT FACE CNC - Add-in Fusion
--------------------------------
Cliquer une face plane de reference : l'add-in selectionne toutes les faces
planes coplanaires (meme plan, meme orientation) sur TOUS les corps visibles
du design. Les chants (faces verticales) ne sont jamais pris.

Options :
  - Tolerance de hauteur (mm)
  - Ignorer la hauteur : prend toutes les faces paralleles orientees pareil,
    quelle que soit leur hauteur (utile si les pieces n'ont pas toutes la
    meme epaisseur).
  - Inclure les faces opposees : prend aussi les faces du meme plan tournees
    dans l'autre sens.
"""

import adsk.core
import adsk.fusion
import traceback

APP_NAME = 'SELECT FACE CNC'
CMD_ID = 'SelectFaceCNC_Cmd'
CUSTOM_EVENT_ID = 'SelectFaceCNC_ApplySelection'
WORKSPACE_ID = 'FusionSolidEnvironment'
PANEL_IDS = ['SelectPanel', 'SolidScriptsAddinsPanel']

ANGLE_TOL = 1e-6  # tolerance sur le produit scalaire des normales

_app = None
_ui = None
_handlers = []
_custom_event = None
_pending_faces = []


# --------------------------------------------------------------------------
# Geometrie
# --------------------------------------------------------------------------
def _face_plane(face):
    """Retourne (point, normale unitaire) de la face dans l'espace monde,
    en tenant compte de l'orientation reelle de la face."""
    pt = face.pointOnFace
    ok, normal = face.evaluator.getNormalAtPoint(pt)
    if not ok:
        return None, None
    normal.normalize()
    return pt, normal


def _iter_visible_bodies(design):
    root = design.rootComponent
    for body in root.bRepBodies:
        if body.isVisible:
            yield body
    for occ in root.allOccurrences:
        for body in occ.bRepBodies:  # proxies dans le contexte de l'assemblage
            if body.isVisible:
                yield body


def find_matching_faces(design, ref_face, tol_cm, ignore_height, include_opposite):
    ref_pt, ref_n = _face_plane(ref_face)
    if ref_n is None:
        return []

    result = []
    for body in _iter_visible_bodies(design):
        for face in body.faces:
            if face.geometry.surfaceType != adsk.core.SurfaceTypes.PlaneSurfaceType:
                continue
            pt, n = _face_plane(face)
            if n is None:
                continue
            dot = n.dotProduct(ref_n)
            if dot >= 1.0 - ANGLE_TOL:
                pass
            elif include_opposite and dot <= -1.0 + ANGLE_TOL:
                pass
            else:
                continue
            if not ignore_height:
                v = ref_pt.vectorTo(pt)
                if abs(v.dotProduct(ref_n)) > tol_cm:
                    continue
            result.append(face)
    return result


# --------------------------------------------------------------------------
# Handlers
# --------------------------------------------------------------------------
class ApplySelectionHandler(adsk.core.CustomEventHandler):
    """Applique la selection APRES la fin de la commande (sinon Fusion la vide)."""

    def notify(self, args):
        global _pending_faces
        try:
            faces = _pending_faces
            _pending_faces = []
            if not faces:
                return
            sel = _ui.activeSelections
            sel.clear()
            added = 0
            for f in faces:
                try:
                    sel.add(f)
                    added += 1
                except Exception:
                    pass
            bodies = set()
            for f in faces:
                try:
                    bodies.add(f.body.entityToken)
                except Exception:
                    pass
            _log('{} : {} faces selectionnees sur {} corps.'.format(APP_NAME, added, len(bodies)))
        except Exception:
            _ui.messageBox('Erreur {} :\n{}'.format(APP_NAME, traceback.format_exc()))


class CommandExecuteHandler(adsk.core.CommandEventHandler):
    def notify(self, args):
        global _pending_faces
        try:
            inputs = args.command.commandInputs
            sel_in = adsk.core.SelectionCommandInput.cast(inputs.itemById('refFace'))
            tol_in = adsk.core.ValueCommandInput.cast(inputs.itemById('tol'))
            ign_in = adsk.core.BoolValueCommandInput.cast(inputs.itemById('ignoreHeight'))
            opp_in = adsk.core.BoolValueCommandInput.cast(inputs.itemById('opposite'))

            if sel_in.selectionCount < 1:
                return
            ref_face = adsk.fusion.BRepFace.cast(sel_in.selection(0).entity)
            design = adsk.fusion.Design.cast(_app.activeProduct)
            if not design or not ref_face:
                return

            _pending_faces = find_matching_faces(
                design, ref_face, tol_in.value, ign_in.value, opp_in.value)
            _app.fireCustomEvent(CUSTOM_EVENT_ID, '')
        except Exception:
            _ui.messageBox('Erreur {} :\n{}'.format(APP_NAME, traceback.format_exc()))


class CommandCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def notify(self, args):
        try:
            cmd = args.command
            cmd.isRepeatable = True
            cmd.okButtonText = 'Selectionner'
            inputs = cmd.commandInputs

            sel_in = inputs.addSelectionInput(
                'refFace', 'Face de reference',
                'Cliquez la face superieure d\'une piece')
            sel_in.addSelectionFilter('PlanarFaces')
            sel_in.setSelectionLimits(1, 1)

            inputs.addValueInput(
                'tol', 'Tolerance hauteur', 'mm',
                adsk.core.ValueInput.createByString('0.01 mm'))
            inputs.addBoolValueInput(
                'ignoreHeight', 'Ignorer la hauteur (toutes epaisseurs)', True, '', False)
            inputs.addBoolValueInput(
                'opposite', 'Inclure les faces opposees', True, '', False)

            on_exec = CommandExecuteHandler()
            cmd.execute.add(on_exec)
            _handlers.append(on_exec)
        except Exception:
            _ui.messageBox('Erreur {} :\n{}'.format(APP_NAME, traceback.format_exc()))


# --------------------------------------------------------------------------
# Utilitaires
# --------------------------------------------------------------------------
def _log(msg):
    try:
        _app.log(msg)
    except Exception:
        pass
    try:
        palette = _ui.palettes.itemById('TextCommands')
        if palette:
            palette.writeText(msg)
    except Exception:
        pass


# --------------------------------------------------------------------------
# Cycle de vie
# --------------------------------------------------------------------------
def run(context):
    global _app, _ui, _custom_event
    try:
        _app = adsk.core.Application.get()
        _ui = _app.userInterface

        cmd_def = _ui.commandDefinitions.itemById(CMD_ID)
        if cmd_def:
            cmd_def.deleteMe()
        cmd_def = _ui.commandDefinitions.addButtonDefinition(
            CMD_ID, APP_NAME,
            'Selectionne toutes les faces coplanaires a la face cliquee, '
            'sur tous les corps visibles (sans les chants).',
            './resources')
        on_created = CommandCreatedHandler()
        cmd_def.commandCreated.add(on_created)
        _handlers.append(on_created)

        try:
            _app.unregisterCustomEvent(CUSTOM_EVENT_ID)
        except Exception:
            pass
        _custom_event = _app.registerCustomEvent(CUSTOM_EVENT_ID)
        on_apply = ApplySelectionHandler()
        _custom_event.add(on_apply)
        _handlers.append(on_apply)

        # Boutons de ruban (PANEL_IDS) RETIRES : devenus inutiles depuis la
        # creation de CNC Toolkit, qui retrouve et execute cette
        # CommandDefinition directement depuis sa palette. On nettoie
        # quand meme un eventuel bouton residuel d'une installation
        # precedente.
        ws = _ui.workspaces.itemById(WORKSPACE_ID)
        for pid in PANEL_IDS:
            panel = ws.toolbarPanels.itemById(pid) if ws else None
            if not panel:
                continue
            ctrl = panel.controls.itemById(CMD_ID)
            if ctrl:
                ctrl.deleteMe()
    except Exception:
        if _ui:
            _ui.messageBox('Erreur au demarrage {} :\n{}'.format(APP_NAME, traceback.format_exc()))


def stop(context):
    global _custom_event
    try:
        ws = _ui.workspaces.itemById(WORKSPACE_ID)
        for pid in PANEL_IDS:
            panel = ws.toolbarPanels.itemById(pid) if ws else None
            if panel:
                ctrl = panel.controls.itemById(CMD_ID)
                if ctrl:
                    ctrl.deleteMe()
        cmd_def = _ui.commandDefinitions.itemById(CMD_ID)
        if cmd_def:
            cmd_def.deleteMe()
        if _custom_event:
            _app.unregisterCustomEvent(CUSTOM_EVENT_ID)
            _custom_event = None
        _handlers.clear()
    except Exception:
        if _ui:
            _ui.messageBox('Erreur a l\'arret {} :\n{}'.format(APP_NAME, traceback.format_exc()))
