import adsk.core
import adsk.fusion
import traceback
import os
import sys
import json
import math
import time

# Apercu fluide partage (cnc_apercu_fluide.py a la racine de ToolkitCNC) : pastilles glissees par la souris.
try:
    _RACINE_TK = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if _RACINE_TK not in sys.path:
        sys.path.insert(0, _RACINE_TK)
    import cnc_apercu_fluide as _caf
except Exception:
    _caf = None

# ---------------------------------------------------------------------------
# Montants de dossier CNC (2026-11-07)
#
# Montants de renfort a l'ARRIERE d'un dossier : un contreplaque a plat (la dalle) porte un contreplaque
# debout (le dossier). L'utilisateur choisit le chemin = la base du dossier sur la dalle. Les montants sont
# repartis sur ce chemin comme Reseau CNC / Traverse CNC (poignee centrale = quantite, poignees des bouts =
# marges, symetrie, jusqu'au bout), mais leurs dimensions sont DETECTEES :
#   - hauteur : le contreplaque debout, au droit du montant (le sommet arrondi du dossier est suivi) ;
#   - largeur : la dalle sous le chemin, du chemin jusqu'a son bord (le bord ovale est suivi).
# Le centre de l'epaisseur du montant est aligne sur le chemin (pour le moment).
# Phase 2 : courbe exterieure asymetrique en haut du montant (quart d'ellipse), manuelle ou automatique
# (par defaut 2/3 de la largeur et 2/3 de la hauteur).
# Fenetre « MONTANTS » en bas a gauche : modele ReseauTrajectoireCNC (_png_ligne / _ov_*).
# Apercus : CustomGraphics uniquement (orange (255,90,0), rouge (220,30,30) si invalide).
# Resultat : un corps par montant (BaseFeature), groupe replie « Montants dossier CNC » dans la chronologie,
# reglages memorises : le bouton Modifier de l'historique CNC Toolkit rouvre la fenetre.
# ---------------------------------------------------------------------------

_app = None
_ui = None
_handlers = []

CMD_ID = 'MontantsDossierCNCCmd'
COMMAND_NAME = 'Montants de dossier CNC'
COMMAND_DESC = 'Cree des montants de renfort a l\'arriere d\'un dossier, hauteur et largeur detectees automatiquement'
PANEL_ID = 'SolidCreatePanel'
GROUPE_NOM = 'Montants dossier CNC'
NB_MAX = 50
ATTR_G, ATTR_N = 'MontantsDossierCNC', 'edit'

_ADDIN_DIR = os.path.dirname(os.path.abspath(__file__))
PREFS_FILE = os.path.join(_ADDIN_DIR, 'montants_prefs.json')

ORANGE = (255, 90, 0, 255)
ROUGE = (220, 30, 30, 255)

CV_MODES = ('aucune', 'auto', 'manuelle')
DEFAULT_PREFS = {'epaisseur_mm': 18.0, 'n': 3, 'm1': 0.0, 'm2': 0.0, 'sym': True, 'h_auto': True, 'h_mm': 300.0,
                 'l_auto': True, 'l_mm': 150.0, 'retrait': 0.0, 'decal': 0.0, 'cv_mode': 'aucune',
                 'cv_w': 66.7, 'cv_h': 66.7, 'cv_a': 100.0, 'cv_b': 150.0,
                 'ten_on': False, 'ten_dos': True, 'ten_bas': True, 'ten_auto': True, 'ten_n_dos': 2, 'ten_n_bas': 2,
                 'ten_len': 30.0, 'ten_edge': 30.0, 'ten_h_auto': True, 'ten_h': 18.0, 'param': True}
CLES = ('c', 'n', 'm1', 'm2', 'sym', 'cote', 'h_auto', 'h_mm', 'l_auto', 'l_mm', 'retrait', 'decal',
        'cv_mode', 'cv_w', 'cv_h', 'cv_a', 'cv_b', 'fin_m',
        'ten_on', 'ten_dos', 'ten_bas', 'ten_auto', 'ten_n_dos', 'ten_n_bas', 'ten_len', 'ten_edge', 'ten_h_auto', 'ten_h',
        'param')
SEL_IDS = ('chemin',)

_s = {}                    # reglages du jeu de montants ACTIF (c'est toujours l'un des dicts de _jeux, ou le modele)
_jeux = []                 # un jeu de reglages par chemin selectionne (une fenetre MONTANTS chacun)
_act = {'i': 0}
_cur = {'calc': None, 'ep': 1.8, 'ep_nom': None}
_en_cours = {'v': False}   # evite la reentrance des evenements provoques par nos ecritures
_drag = {'k': None}
_sel_fig = {'e': None}   # champs de selection figes pendant le glisser d'une poignee
_souris = {'pos': None, 'vp': None, 't': 0.0}
_bloc = {'t': 0.0, 'sel': None}
_bar = {'on': False, 'tm': 0.0}
_edition = {'v': None}     # modification demandee par l'historique : {blob, anciens}
_cache_traj = {}
_cache_ent = {}
_cache_faces = {}
_cf = {'ignores': set()}
_pastilles = {}
_qd = {'on': False}
ID_APERCU = 'MontantsDossierCNC_apercu'
ID_PASTILLE = 'MontantsDossierCNC_pastille%d'
ACTION_ID = 'MontantsDossierCNC_action'
REDRAW_ID = 'MontantsDossierCNC_redraw'
_action = {'evt': None, 'h': None}
_redraw = {'evt': None, 'h': None, 'on': False}


def _tt(s):
    """Texte dans la langue choisie (cnc_i18n est charge par ToolkitCNC)."""
    try:
        m = sys.modules.get('cnc_i18n')
        return m.t(s) if m is not None else s
    except Exception:
        return s


def _log(msg):
    try:
        with open(os.path.join(_ADDIN_DIR, 'montants_journal.txt'), 'a', encoding='utf-8') as f:
            f.write(time.strftime('%H:%M:%S ') + msg + '\n')
    except Exception:
        pass


def load_prefs():
    p = dict(DEFAULT_PREFS)
    try:
        with open(PREFS_FILE, 'r', encoding='utf-8') as f:
            p.update(json.load(f))
    except Exception:
        pass
    return p


def save_prefs(p):
    try:
        with open(PREFS_FILE, 'w', encoding='utf-8') as f:
            json.dump(p, f)
    except Exception:
        pass


def _nouveau(p=None):
    p = p or load_prefs()
    return {'c': [], 'n': max(1, min(NB_MAX, int(p['n']))), 'm1': float(p['m1']), 'm2': float(p['m2']),
            'sym': bool(p['sym']), 'cote': False, 'h_auto': bool(p['h_auto']), 'h_mm': float(p['h_mm']),
            'l_auto': bool(p['l_auto']), 'l_mm': float(p['l_mm']), 'retrait': float(p['retrait']),
            'decal': float(p['decal']), 'cv_mode': p['cv_mode'] if p['cv_mode'] in CV_MODES else 'aucune',
            'cv_w': float(p['cv_w']), 'cv_h': float(p['cv_h']), 'cv_a': float(p['cv_a']), 'cv_b': float(p['cv_b']),
            'fin_m': None, 'ten_on': bool(p['ten_on']), 'ten_dos': bool(p['ten_dos']), 'ten_bas': bool(p['ten_bas']),
            'ten_auto': bool(p['ten_auto']), 'ten_n_dos': int(p['ten_n_dos']), 'ten_n_bas': int(p['ten_n_bas']),
            'ten_len': float(p['ten_len']), 'ten_edge': float(p['ten_edge']), 'ten_h_auto': bool(p['ten_h_auto']),
            'ten_h': float(p['ten_h']), 'param': bool(p.get('param', True))}


def _design():
    return adsk.fusion.Design.cast(_app.activeProduct)


def _face_monde(f):
    """(centre, normale unitaire, origine du plan) d'une face PLANE dans l'espace du document.
    La geometrie d'une face d'un composant est lue sur l'objet natif puis transformee
    (la lire sur le proxy donnait un centrage faux, retour du 2026-11-03)."""
    n = f.nativeObject if getattr(f, 'assemblyContext', None) is not None else f
    g = n.geometry
    if not isinstance(g, adsk.core.Plane):
        return None
    c = _monde(f, p=n.centroid)
    nv = _v_norm(_monde(f, v=g.normal))
    o = _monde(f, p=g.origin)
    return c, nv, o


def _dist_rayon(o, d, f):
    """Distance de o a la face f le long de d (plan : exacte ; autre surface : approchee par la boite)."""
    i = None
    try:
        i = _face_monde(f)
    except Exception:
        pass
    if i is not None:
        _c, n, po = i
        den = _v_dot(n, d)
        if abs(den) < 1e-9:
            return None
        t = _v_dot(_v_sub(po, (o.x, o.y, o.z)), n) / den
        return t if t > 0 else None
    bb = f.boundingBox
    ts = []
    for x in (bb.minPoint.x, bb.maxPoint.x):
        for y in (bb.minPoint.y, bb.maxPoint.y):
            for z in (bb.minPoint.z, bb.maxPoint.z):
                ts.append((x - o.x) * d[0] + (y - o.y) * d[1] + (z - o.z) * d[2])
    t = min(ts)
    return t if max(ts) > 0 else None


def _ents(design, tokens):
    res = []
    for tok in tokens:
        e = _cache_ent.get(tok)
        if e is None or not getattr(e, 'isValid', True):
            e = None
            try:
                r = design.findEntityByToken(tok)
                if r:
                    e = r[0]
                    _cache_ent[tok] = e
            except Exception:
                pass
        if e is not None:
            res.append(e)
    return res


def _monde(ent, p=None, v=None):
    """Point (p) ou vecteur (v) natif d'une entite d'un composant -> espace du document."""
    ctx = getattr(ent, 'assemblyContext', None)
    if p is not None:
        q = p.copy()
        if ctx is not None:
            q.transformBy(ctx.transform2)
        return (q.x, q.y, q.z)
    w = v.copy()
    if ctx is not None:
        w.transformBy(ctx.transform2)
    return (w.x, w.y, w.z)


def _courbe_monde(ent):
    n = ent.nativeObject if getattr(ent, 'assemblyContext', None) is not None else ent
    if isinstance(n, adsk.fusion.BRepEdge):
        g = n.geometry.copy()
    elif isinstance(n, adsk.fusion.SketchCurve):
        g = n.worldGeometry.copy()
    else:
        return None
    ctx = getattr(ent, 'assemblyContext', None)
    if ctx is not None:
        g.transformBy(ctx.transform2)
    return g


def _echantillonner(ent, n=120):
    c = _courbe_monde(ent)
    if c is None:
        return []
    if isinstance(c, adsk.core.Line3D):
        a, b = c.startPoint, c.endPoint
        return [(a.x, a.y, a.z), (b.x, b.y, b.z)]
    ev = c.evaluator
    ok, p0, p1 = ev.getParameterExtents()
    pts = []
    for k in range(n + 1):
        ok, p = ev.getPointAtParameter(p0 + (p1 - p0) * k / n)
        if ok:
            pts.append((p.x, p.y, p.z))
    return pts


def _d3(a, b):
    return math.sqrt((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 + (a[2] - b[2]) ** 2)


class _Trajet:
    """Chemin echantillonne par abscisse curviligne (fraction 0..1)."""

    def __init__(self, ents):
        segs = [s for s in (_echantillonner(e) for e in ents) if len(s) >= 2]
        if not segs:
            raise ValueError('chemin vide')
        chain = segs.pop(0)
        while segs:
            best = None
            for i, s in enumerate(segs):
                for d, mode, rev in ((_d3(chain[-1], s[0]), 'a', False), (_d3(chain[-1], s[-1]), 'a', True),
                                     (_d3(s[-1], chain[0]), 'p', False), (_d3(s[0], chain[0]), 'p', True)):
                    if best is None or d < best[0]:
                        best = (d, i, mode, rev)
            _d, i, mode, rev = best
            s = segs.pop(i)
            seg = s[::-1] if rev else s
            chain = chain + seg[1:] if mode == 'a' else seg[:-1] + chain
        self.pts = chain
        self.cum = [0.0]
        for i in range(1, len(chain)):
            self.cum.append(self.cum[-1] + _d3(chain[i - 1], chain[i]))
        self.longueur = self.cum[-1]
        if self.longueur < 1e-9:
            raise ValueError('chemin nul')

    def at(self, f):
        """(point, tangente) en flottants a la fraction f."""
        f = max(0.0, min(1.0, f))
        s = f * self.longueur
        lo, hi = 0, len(self.cum) - 1
        while hi - lo > 1:
            m = (lo + hi) // 2
            if self.cum[m] <= s:
                lo = m
            else:
                hi = m
        a, b = self.pts[lo], self.pts[lo + 1]
        L = self.cum[lo + 1] - self.cum[lo] or 1.0
        u = (s - self.cum[lo]) / L
        p = tuple(a[k] + (b[k] - a[k]) * u for k in range(3))
        t = tuple((b[k] - a[k]) / L for k in range(3))
        return p, t

    def frac_point(self, q):
        """Fraction du chemin au point le plus proche de q (point clique), affinee sur le segment."""
        pts = self.pts
        best = min(range(len(pts)), key=lambda i: _d3(pts[i], q))
        sb, db = self.cum[best], _d3(pts[best], q)
        for j in (best - 1, best):
            if 0 <= j < len(pts) - 1:
                a, b = pts[j], pts[j + 1]
                e = _v_sub(b, a)
                e2 = _v_dot(e, e)
                if e2 < 1e-18:
                    continue
                u = max(0.0, min(1.0, _v_dot(_v_sub(q, a), e) / e2))
                dd = _d3(_v_add(a, _v_mul(e, u)), q)
                if dd < db:
                    db, sb = dd, self.cum[j] + u * (self.cum[j + 1] - self.cum[j])
        return sb / self.longueur

    def proche_3d(self, q):
        best = min(range(len(self.pts)), key=lambda i: _d3(self.pts[i], q))
        return self.cum[best] / self.longueur


def _traj(ents_tokens, design):
    cle = tuple(ents_tokens)
    if cle not in _cache_traj:
        if len(_cache_traj) > 40:
            _cache_traj.clear()
        try:
            _cache_traj[cle] = _Trajet(_ents(design, ents_tokens))
        except ValueError:
            for tok in ents_tokens:              # entite perdue (chronologie reculee, recalcul) : on relit les jetons
                _cache_ent.pop(tok, None)
            try:
                _cache_traj[cle] = _Trajet(_ents(design, ents_tokens))
            except ValueError:
                _log('chemin introuvable : %d jeton(s), resolus=%d' % (len(ents_tokens), len(_ents(design, ents_tokens))))
                raise
    return _cache_traj[cle]


def _v_sub(a, b): return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def _v_add(a, b): return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def _v_mul(a, k): return (a[0] * k, a[1] * k, a[2] * k)


def _v_dot(a, b): return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def _v_cross(a, b): return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def _v_norm(a):
    n = math.sqrt(_v_dot(a, a))
    return (a[0] / n, a[1] / n, a[2] / n) if n > 1e-12 else (0.0, 0.0, 0.0)


def _vers_haut():
    try:
        o = _app.preferences.generalPreferences.defaultModelingOrientation
        if o == adsk.core.DefaultModelingOrientations.YUpModelingOrientation:
            return (0.0, 1.0, 0.0)
    except Exception:
        pass
    return (0.0, 0.0, 1.0)


def _rayon(design, o, dv):
    """[(face, distance)] des faces touchees par le rayon parti de o (Point3D) dans la direction dv. Distance
    exacte lue sur les points d'impact de Fusion (faces courbes, splines comprises) ; l'ancienne approximation
    par la boite d'une face courbe donnait des largeurs fausses (FS210, 2026-11-05). None si echec."""
    hp = adsk.core.ObjectCollection.create()
    try:
        faces = design.rootComponent.findBRepUsingRay(o, adsk.core.Vector3D.create(dv[0], dv[1], dv[2]),
                                                      adsk.fusion.BRepEntityTypes.BRepFaceEntityType, -1.0, True, hp)
    except Exception:
        return None
    if faces is None:
        return None
    exact = hp.count == faces.count
    out = []
    for i in range(faces.count):
        f = faces.item(i)
        if _cf['ignores']:
            try:
                if f.body.entityToken in _cf['ignores']:
                    continue                 # recalcul automatique : les anciennes traverses ne comptent pas
            except Exception:
                pass
        if exact:
            h = hp.item(i)
            t = (h.x - o.x) * dv[0] + (h.y - o.y) * dv[1] + (h.z - o.z) * dv[2]
            t = t if t > 0 else None
        else:
            t = _dist_rayon(o, dv, f)
        out.append((f, t))
    return out


def _sortie_corps(design, body, q, dv, tmax):
    """Distance de q (dans body) a la vraie sortie de body le long de dv : premier impact apres lequel le point
    est hors du corps. Les faces traversees sans sortir (mortaise, autre corps, face interne) sont ignorees."""
    hits = _rayon(design, adsk.core.Point3D.create(*q), dv)
    if hits is None:
        return None
    ts = [t for _f, t in hits if t is not None and 1e-4 < t <= tmax]
    for t in sorted(set(round(x, 5) for x in ts)):
        pt = adsk.core.Point3D.create(*_v_add(q, _v_mul(dv, t + 0.03)))
        try:
            if body.pointContainment(pt) == adsk.fusion.PointContainment.PointOutsidePointContainment:
                return t
        except Exception:
            return None
    return None


_dv = {'ents': [], 'h': None, 'c': None, 'r': 0.0, 't': 0.0}


def _dv_point():
    app = adsk.core.Application.get()
    des = adsk.fusion.Design.cast(app.activeProduct)
    if des is None:
        return None
    if time.time() - _dv['t'] > 1.0:
        _dv['t'] = time.time()
        bb = des.rootComponent.boundingBox
        if bb is None:
            _dv['c'] = None
        else:
            a, b = bb.minPoint, bb.maxPoint
            _dv['c'] = ((a.x + b.x) / 2.0, (a.y + b.y) / 2.0, (a.z + b.z) / 2.0)
            _dv['r'] = a.distanceTo(b) / 2.0
    c = _dv['c']
    if c is None:
        return None
    cam = app.activeViewport.camera
    e, t = cam.eye, cam.target
    d = (e.x - t.x, e.y - t.y, e.z - t.z)
    lg = math.sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2])
    if lg < 1e-9:
        return None
    d = (d[0] / lg, d[1] / lg, d[2] / lg)
    ec = (e.x - c[0]) * d[0] + (e.y - c[1]) * d[1] + (e.z - c[2]) * d[2]
    # juste devant le modele, mais jamais derriere la camera (perspective tres zoomee)
    s = min(_dv['r'] * 1.2 + 1.0, ec * 0.5) if ec > 0 else 0.0
    p = adsk.core.Point3D.create(c[0] + d[0] * s, c[1] + d[1] * s, c[2] + d[2] * s)
    occ = des.activeOccurrence
    if occ is not None:
        inv = occ.transform2.copy()
        inv.invert()
        p.transformBy(inv)
    return p


def _dv_appliquer(ents):
    p = _dv_point()
    if p is None:
        return
    m = adsk.core.Matrix3D.create()
    m.translation = adsk.core.Vector3D.create(p.x, p.y, p.z)
    for x in ents:
        x.transform = m


class _DvCamHandler(adsk.core.CameraEventHandler):
    def notify(self, args):
        try:
            ents = [x for x in _dv['ents'] if x.isValid]
            _dv['ents'] = ents
            if ents:
                _dv_appliquer(ents)
        except Exception:
            pass


def _dv_poser(ps):
    """A appeler apres chaque ps.viewPlacement = ... d'une fenetre du bas a gauche."""
    try:
        _dv['t'] = 0.0
        _dv_appliquer([ps])
        _dv['ents'] = [x for x in _dv['ents'] if x.isValid] + [ps]
        if _dv['h'] is None:
            h = _DvCamHandler()
            adsk.core.Application.get().cameraChanged.add(h)
            _dv['h'] = h
    except Exception:
        pass


def _dv_arreter():
    try:
        if _dv['h'] is not None:
            adsk.core.Application.get().cameraChanged.remove(_dv['h'])
    except Exception:
        pass
    _dv['h'] = None
    _dv['ents'] = []


def _balayer(ident):
    """Supprime TOUS les groupes graphiques portant cet id (composant actif et racine) :
    un groupe orphelin (rechargement du module, erreur...) restait affiche a l'ecran."""
    try:
        design = _design()
        comps = {design.rootComponent.entityToken: design.rootComponent}
        ac = design.activeComponent
        comps[ac.entityToken] = ac
        for comp in comps.values():
            gs = comp.customGraphicsGroups
            for i in range(gs.count - 1, -1, -1):
                try:
                    g = gs.item(i)
                    if g.id == ident:
                        g.deleteMe()
                except Exception:
                    pass
    except Exception:
        pass


def _supprimer_groupes(grps):
    for g in list(grps.values()):
        try:
            if g.isValid:
                g.deleteMe()
        except Exception:
            pass


def _ecran(tr, vp):
    """Points du chemin projetes a l'ecran (gardes tant que la camera ne bouge pas)."""
    try:
        cam = vp.camera
        cle = (id(tr), tuple(round(v, 4) for v in cam.eye.asArray() + cam.target.asArray() + cam.upVector.asArray()),
               round(cam.viewExtents, 4), vp.width, vp.height)
    except Exception:
        cle = None
    c = getattr(tr, '_scr', None)
    if c is None or cle is None or c[0] != cle:
        res = []
        P3 = adsk.core.Point3D.create
        for p in tr.pts:
            q = vp.modelToViewSpace(P3(p[0], p[1], p[2]))
            res.append((q.x, q.y))
        tr._scr = (cle, res)
    return tr._scr[1]


def _frac_souris(tr, vp, m):
    """Fraction du chemin dont le point est le plus proche de la souris, a l'ecran."""
    ecr = _ecran(tr, vp)
    best = min(range(len(ecr)), key=lambda i: (ecr[i][0] - m.x) ** 2 + (ecr[i][1] - m.y) ** 2)
    sb = tr.cum[best]
    db = (ecr[best][0] - m.x) ** 2 + (ecr[best][1] - m.y) ** 2
    for j in (best - 1, best):
        if 0 <= j < len(ecr) - 1:
            ax, ay = ecr[j]
            ex, ey = ecr[j + 1][0] - ax, ecr[j + 1][1] - ay
            e2 = ex * ex + ey * ey
            if e2 < 1e-12:
                continue
            u = max(0.0, min(1.0, ((m.x - ax) * ex + (m.y - ay) * ey) / e2))
            dd = (ax + u * ex - m.x) ** 2 + (ay + u * ey - m.y) ** 2
            if dd < db:
                db, sb = dd, tr.cum[j] + u * (tr.cum[j + 1] - tr.cum[j])
    return sb / tr.longueur


class _CameraHandler(adsk.core.CameraEventHandler):
    """La vue tourne : les pastilles sont recalees devant la camera (elles passent devant les corps)."""
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            for g in list(_pastilles.values()):
                g.recaler(args.viewport)
        except Exception:
            pass


_camera = {'h': None}


def _camera_suivre(oui):
    try:
        if oui and _camera['h'] is None and _caf is not None:
            _camera['h'] = _CameraHandler()
            _app.cameraChanged.add(_camera['h'])
        elif not oui and _camera['h'] is not None:
            _app.cameraChanged.remove(_camera['h'])
            _camera['h'] = None
    except Exception:
        _log('camera : ' + traceback.format_exc()[-200:])


def _pastilles_effacer():
    for g in list(_pastilles.values()):
        g.effacer()
    _pastilles.clear()
    if _caf is not None:
        for k in (0, 1, 2):
            _caf.balayer(ID_PASTILLE % k)


def _ep_noms(design):
    """Noms proposes : CP10 / CP15 / CP18 puis les autres parametres CPxx du projet."""
    noms = list(NC_CP)
    try:
        ups = design.userParameters
        for i in range(ups.count):
            n = ups.item(i).name
            if n.upper().startswith('CP') and n not in noms:
                noms.append(n)
    except Exception:
        pass
    return noms


def _ep_cm_nom(design, nom):
    p = design.allParameters.itemByName(nom)
    return p.value if p is not None else NC_CP.get(nom, 1.8)


def _ep_remplir(dd, design, defaut_cm):
    """Liste deroulante des epaisseurs (CPxx du projet + « Autre... ») ; renvoie True si une valeur est choisie."""
    trouve = False
    for n in _ep_noms(design):
        cm = _ep_cm_nom(design, n)
        sel = (not trouve) and abs(cm - defaut_cm) < 1e-4
        trouve = trouve or sel
        dd.listItems.add('%s (%s mm)' % (n, ('%.2f' % (cm * 10.0)).rstrip('0').rstrip('.')), sel, '')
    dd.listItems.add('Autre...', not trouve, '')
    return trouve


def _ep_choisir(inputs, cm):
    """Selectionne la ligne dont la valeur est cm, sinon « Autre... » avec la valeur saisie."""
    dd = inputs.itemById('ep_dd')
    design = _design()
    noms = _ep_noms(design)
    for i, n in enumerate(noms):
        if abs(_ep_cm_nom(design, n) - cm) < 1e-4:
            dd.listItems.item(i).isSelected = True
            inputs.itemById('ep_autre').isVisible = False
            return
    dd.listItems.item(dd.listItems.count - 1).isSelected = True
    a = inputs.itemById('ep_autre')
    a.value = cm
    a.isVisible = True


def _ep_cm(inputs):
    try:
        dd = inputs.itemById('ep_dd')
        if dd is not None:
            if dd.selectedItem.index == dd.listItems.count - 1:
                return max(0.01, inputs.itemById('ep_autre').value)
            design = _design()
            return max(0.01, _ep_cm_nom(design, _ep_noms(design)[dd.selectedItem.index]))
        return max(0.01, inputs.itemById('epaisseur').value)
    except Exception:
        return max(0.01, load_prefs()['epaisseur_mm'] / 10.0)


def _cp_nom_valeur(design, ep_cm, prefere=None):
    """Audit des parametres (2026-11-16) : une epaisseur deja enregistree est reutilisee, jamais recreee. Ordre :
    le parametre attendu (prefere, puis CPxx, xx = mm) s'il a cette valeur, sinon tout autre parametre CP* de meme
    valeur ; a defaut, nom a creer CPxx (CP18, CP12_5). Si ce nom est deja pris par une AUTRE valeur (CP18 passe a
    18,3 mm), un 0 est ajoute (CP18_0 = 18,0 mm) : on ne reprend jamais une valeur fausse."""
    nom = 'CP' + ('%g' % round(ep_cm * 10.0, 2)).replace('.', '_')
    cands = []
    try:
        ups = design.userParameters
        for i in range(ups.count):
            q = ups.item(i)
            if q.name.upper().startswith('CP') and abs(q.value - ep_cm) < 1e-4:
                cands.append(q.name)
    except Exception:
        pass
    for n in (prefere, nom):
        if n and n in cands:
            return n
    if cands:
        return cands[0]
    while design.allParameters.itemByName(nom) is not None:
        nom += '0' if '_' in nom else '_0'
    return nom


def _ep_parametre(design, inputs, ep_cm):
    """Le parametre d'epaisseur existe dans le projet : CP10 / CP15 / CP18 crees s'ils manquent, ou CPxx
    pour une epaisseur libre (comme Reseau CNC). Renvoie son nom."""
    nom = None
    try:
        dd = inputs.itemById('ep_dd')
        if dd is not None and dd.selectedItem.index < dd.listItems.count - 1:
            nom = _ep_noms(design)[dd.selectedItem.index]
    except Exception:
        nom = None
    if nom is None or design.allParameters.itemByName(nom) is None:
        nom = _cp_nom_valeur(design, ep_cm, nom)       # meme valeur deja en parametre : reutilisee
    if design.allParameters.itemByName(nom) is None:
        design.userParameters.add(nom, adsk.core.ValueInput.createByReal(ep_cm), 'mm', 'Epaisseur contreplaque')
    return nom


class _PreSelectHandler(adsk.core.SelectionEventHandler):
    """Rien n'est preselectionnable sous une poignee (ni pendant son glisser) : on attrape la poignee,
    pas la face ou l'arete qui est derriere."""
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            if _drag.get('maison') or _qd.get('on'):
                args.isSelectable = False
                return
            vp, pos = _souris.get('vp'), _souris.get('pos')
            if _caf is None or vp is None or pos is None or not _pastilles:
                return
            r = 16.0 * _dpr()
            for g in _pastilles.values():
                if g.p is None:
                    continue
                q = vp.modelToViewSpace(adsk.core.Point3D.create(*g.p))
                if math.hypot(q.x - pos.x, q.y - pos.y) <= r:
                    args.isSelectable = False
                    return
        except Exception:
            pass


def _supprimer_anciens(design, tokens):
    """Supprime les entrees de l'ancienne traverse (groupe deplie, de la derniere a la premiere)."""
    r = design.findEntityByToken(tokens[0]) if tokens else None
    if r:
        try:
            g = r[0].timelineObject.parentGroup
            if g is not None and g.isCollapsed:
                g.isCollapsed = False
        except Exception:
            pass
    ok = True
    for tok in reversed(tokens):
        try:
            r = design.findEntityByToken(tok)
            if r:
                r[0].deleteMe()
        except Exception:
            ok = False
            _log('suppression ancien erreur ' + traceback.format_exc()[-300:])
    return ok


class _ActionHandler(adsk.core.CustomEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            cd = _ui.commandDefinitions.itemById(CMD_ID)
            if cd is not None:
                cd.execute()
        except Exception:
            _log('action erreur ' + traceback.format_exc()[-300:])


def _differer():
    """Ouvre la commande hors du gestionnaire de la palette (evenement personnalise, comme Reseau CNC)."""
    try:
        if _action['evt'] is None:
            try:
                _app.unregisterCustomEvent(ACTION_ID)
            except Exception:
                pass
            _action['evt'] = _app.registerCustomEvent(ACTION_ID)
            _action['h'] = _ActionHandler()
            _action['evt'].add(_action['h'])
        if not _app.fireCustomEvent(ACTION_ID, ''):
            raise RuntimeError('evenement non livre')
    except Exception:
        _log('differer : ' + traceback.format_exc()[-200:])
        _ui.commandDefinitions.itemById(CMD_ID).execute()


def _rafraichir_vue():
    try:
        _app.activeViewport.refresh()
    except Exception:
        pass


def _nom_libre(comp, base):
    noms = set(comp.bRepBodies.item(i).name for i in range(comp.bRepBodies.count))
    k = 1
    while '%s %d' % (base, k) in noms:
        k += 1
    return '%s %d' % (base, k)


_GLYPHES = {
    'C': '111100100100111', 'H': '101101111101101', 'E': '111100111100111', 'M': '101111111101101',
    'T': '111010010010010', 'O': '111101101101111', 'U': '101101101101111',
    'S': '111100111001111', 'I': '111010010010111', 'N': '111101101101101', ' ': '000000000000000',
    '0': '111101101101111', '1': '010110010010111', '2': '111001111100111', '3': '111001111001111',
    '4': '101101111001001', '5': '111100111001111', '6': '111100111101111', '7': '111001001001001',
    '8': '111101111101111', '9': '111101111001111',
    'A': '010101111101101', 'B': '110101110101110', 'D': '110101101101110', 'F': '111100110100100',
    'G': '011100101101011', 'J': '001001001101010', 'K': '101101110101101', 'L': '100100100100111',
    'P': '110101110100100', 'Q': '010101101111011', 'R': '110101110101101', 'V': '101101101101010',
    'W': '101101111111101', 'X': '101101010101101', 'Y': '101101010010010', 'Z': '111001010100111',
    "'": '010010000000000', '.': '000000000000010', ',': '000000000010100', '-': '000000111000000',
    ':': '000010000010000', '%': '101001010100101', '/': '001001010100100'}


NC_CP = {'CP10': 1.0, 'CP15': 1.5, 'CP18': 1.8}      # epaisseurs de contreplaque (cm), comme Reseau CNC
_png_cache = {}
_dpr_cache = {}


# --- Detection des dimensions (rayons) ---------------------------------------------------------------------

def _hits(design, o, d):
    """[(face, distance)] des faces touchees par le rayon parti de o dans la direction d (monde, cm)."""
    r = _rayon(design, adsk.core.Point3D.create(*o), d)
    return r or []


def _corps_contenant(design, q):
    """Corps (visibles) qui contiennent le point q : les faces touchees par un rayon vers le haut et vers le bas
    donnent les candidats, la reponse est confirmee par pointContainment (findBRepUsingPoint ne rend que les
    corps tout proches du point, pas ceux qui le contiennent)."""
    vus = {}
    for d in ((0.0, 1.0, 0.0), (0.0, -1.0, 0.0), (1.0, 0.0, 0.0)):
        for f, t in _hits(design, q, d):
            if t is not None and t > 1e-4:
                try:
                    b = f.body
                    vus[b.entityToken] = b
                except Exception:
                    pass
    p = adsk.core.Point3D.create(*q)
    out = []
    for b in vus.values():
        try:
            if b.pointContainment(p) != adsk.fusion.PointContainment.PointOutsidePointContainment:
                out.append(b)
        except Exception:
            pass
    return out


def _libre(design, q):
    return not _corps_contenant(design, q)


def _h_en(design, p, a, up):
    """Hauteur (cm) du contreplaque debout au-dessus du chemin au point p : sonde DANS le dossier (cote -a, un peu
    au-dessus du chemin) puis rayon vers le haut jusqu'a la vraie sortie du corps. None si rien trouve."""
    for off in (0.3, 0.1, 0.8, 1.2):
        q = _v_add(_v_add(p, _v_mul(a, -off)), _v_mul(up, 0.3))
        bs = _corps_contenant(design, q)
        if bs:
            ex = _sortie_corps(design, bs[0], q, up, 2000.0)
            if ex is not None:
                return ex + 0.3
    return None


def _w_en(design, p, a, up, dec=0.0):
    """Largeur (cm) disponible de la dalle, du chemin (decale de dec) jusqu'a son bord, dans le sens a : sonde dans la
    dalle (un peu sous le chemin), rayon horizontal jusqu'a la vraie sortie du corps."""
    for dz in (0.3, 0.1, 0.8):
        q = _v_add(_v_add(p, _v_mul(a, 0.05 + dec)), _v_mul(up, -dz))
        bs = _corps_contenant(design, q)
        if bs:
            ex = _sortie_corps(design, bs[0], q, a, 2000.0)
            if ex is not None:
                return ex + 0.05
    return None


def _tb_en(design, p, a, up, dec=0.0):
    """Epaisseur (cm) de la dalle sous le montant : sonde juste sous le chemin, rayon vers le bas jusqu'a la sortie."""
    q = _v_add(_v_add(p, _v_mul(a, 0.3 + dec)), _v_mul(up, -0.05))
    bs = _corps_contenant(design, q)
    if bs:
        ex = _sortie_corps(design, bs[0], q, _v_mul(up, -1.0), 500.0)
        if ex is not None:
            return ex + 0.05
    return None


def _tp_en(design, p, a, up, dec=0.0):
    """Epaisseur (cm) du CP debout derriere le montant : sonde juste derriere la face du montant, un peu au-dessus
    du chemin, rayon vers l'arriere jusqu'a la sortie."""
    q = _v_add(_v_add(p, _v_mul(a, dec - 0.05)), _v_mul(up, 0.5))
    bs = _corps_contenant(design, q)
    if bs:
        ex = _sortie_corps(design, bs[0], q, _v_mul(a, -1.0), 500.0)
        if ex is not None:
            return ex + 0.05
    return None


NPROF = 48
_prof = {'cle': None, 'x': None, 'h': None, 'w': None, 'tb': None, 'tp': None}
_prof_multi = {}


def _prof_inv():
    _prof['cle'] = None
    _prof_multi.clear()


def _cadre_chemin(tr, x, cote):
    """(p, th, a, up) au point d'abscisse x (cm) du chemin : th tangente horizontale, a sens de la largeur."""
    L = tr.longueur
    p, tg = tr.at(max(0.0, min(1.0, x / L)))
    up = _vers_haut()
    th = _v_sub(tg, _v_mul(up, _v_dot(tg, up)))
    if _v_dot(th, th) < 1e-10:
        return None
    th = _v_norm(th)
    a = _v_norm(_v_cross(th, up))
    if cote:
        a = _v_mul(a, -1.0)
    return p, th, a, up


def _cote_auto(design, tr):
    """Cote du montant : l'arriere du dossier = le cote ou il n'y a PAS de corps juste au-dessus du chemin. Renvoie
    True si le sens inverse (-a) est le bon, False si +a, None si indecidable."""
    cd = _cadre_chemin(tr, tr.longueur / 2.0, False)
    if cd is None:
        return None
    p, th, a, up = cd
    res = {}
    for sg in (1, -1):
        q = _v_add(_v_add(p, _v_mul(a, 0.05 * sg)), _v_mul(up, 0.3))
        res[sg] = _libre(design, q)
    if res[1] and not res[-1]:
        return False
    if res[-1] and not res[1]:
        return True
    return None


def _profil(design, s, tr):
    """Hauteur et largeur disponibles echantillonnees le long du chemin (tableau garde tant que le chemin, le cote
    et le decalage ne changent pas) : l'aperçu interpole, la creation mesure exactement."""
    cle = (tuple(s['c']), bool(s['cote']), round(s['decal'], 3), round(tr.longueur, 4), bool(s['ten_on']))
    if cle in _prof_multi:
        return _prof_multi[cle]
    L = tr.longueur
    xs, hs, ws, tbs, tps = [], [], [], [], []
    for k in range(NPROF + 1):
        x = L * k / NPROF
        cd = _cadre_chemin(tr, x, s['cote'])
        h = w = tb = tp = None
        if cd is not None:
            p, th, a, up = cd
            h = _h_en(design, p, a, up)
            w = _w_en(design, p, a, up, s['decal'] / 10.0)
            if s['ten_on']:
                tb = _tb_en(design, p, a, up, s['decal'] / 10.0)
                tp = _tp_en(design, p, a, up, s['decal'] / 10.0)
        xs.append(x)
        hs.append(h)
        ws.append(w)
        tbs.append(tb)
        tps.append(tp)
    d = dict(cle=cle, x=xs, h=hs, w=ws, tb=tbs, tp=tps)
    if len(_prof_multi) > 24:
        _prof_multi.clear()
    _prof_multi[cle] = d
    return d


def _interp(xs, vs, x):
    """Valeur interpolee en x ; None si l'un des deux echantillons voisins manque."""
    if x <= xs[0]:
        return vs[0]
    if x >= xs[-1]:
        return vs[-1]
    lo, hi = 0, len(xs) - 1
    while hi - lo > 1:
        m = (lo + hi) // 2
        if xs[m] <= x:
            lo = m
        else:
            hi = m
    a, b = vs[lo], vs[hi]
    if a is None or b is None:
        return a if b is None else b
    u = (x - xs[lo]) / (xs[hi] - xs[lo])
    return a + (b - a) * u


# --- Calcul des montants --------------------------------------------------------------------------------

def _positions(Lt, n, e, m1, m2):
    """Abscisses (cm) des centres des montants : entre les marges (mm) du debut et de la fin, le premier et le dernier
    a fleur des marges ; un seul montant : au milieu. Renvoie aussi (x0, x1), abscisses des deux poignees."""
    x0 = m1 / 10.0 + e
    x1 = Lt - m2 / 10.0 - e
    if x1 < x0 - 1e-6:
        return [], (x0, x1)
    if n == 1:
        return [(x0 + x1) / 2.0], (x0, x1)
    sp = (x1 - x0) / (n - 1)
    return [x0 + i * sp for i in range(n)], (x0, x1)


def _tenons_champ(L, n, auto, tlen, edge):
    """[(debut, largeur)] en cm le long d'un champ de longueur L. Regle de Maxence (2026-11-07) : tenons de 30 mm
    decales de 30 mm des deux bouts ; automatique : deux tenons sur un grand champ, un seul tenon centre sur un
    petit champ. Manuel : n tenons, reduits si le champ est trop court."""
    if L < tlen + 0.2:
        return []
    if auto:
        n = 2 if L >= 2.0 * edge + 3.0 * tlen - 1e-6 else 1
    n = max(1, int(n))
    while n > 1:
        c0, c1 = edge + tlen / 2.0, L - edge - tlen / 2.0
        if c1 - c0 >= (n - 1) * tlen - 1e-6 and c1 > c0:
            sp = (c1 - c0) / (n - 1)
            return [(c0 + i * sp - tlen / 2.0, tlen) for i in range(n)]
        n -= 1
    return [((L - tlen) / 2.0, tlen)]


def _tenons_montant(design, s, c, p, a, up, e, dec, tb, tp, exact):
    """Boites locales (x0, x1, y0, y1, z0, z1) des tenons d'un montant : champ du dessous (dans la dalle) et champ du dos
    (dans le CP debout). Profondeur = epaisseur detectee du CP qui recoit le tenon, ou valeur saisie."""
    boites, n_bas, n_dos = [], 0, 0
    tlen, edge = s['ten_len'] / 10.0, s['ten_edge'] / 10.0
    W, H = c['W'], c['H']
    if s['ten_bas']:
        T = tb if s['ten_h_auto'] else s['ten_h'] / 10.0
        if exact and s['ten_h_auto']:
            T = _tb_en(design, p, a, up, dec)
        if T:
            for st, wd in _tenons_champ(W, s['ten_n_bas'], s['ten_auto'], tlen, edge):
                boites.append((st, st + wd, -T, 0.0, -e, e))
                n_bas += 1
    if s['ten_dos']:
        T = tp if s['ten_h_auto'] else s['ten_h'] / 10.0
        if exact and s['ten_h_auto']:
            T = _tp_en(design, p, a, up, dec)
        if T:
            for st, wd in _tenons_champ(H, s['ten_n_dos'], s['ten_auto'], tlen, edge):
                boites.append((-T, 0.0, st, st + wd, -e, e))
                n_dos += 1
    return boites, n_bas, n_dos


def _courbe(s, W, H):
    """(A, B) cm : demi-axes du quart d'ellipse du coin exterieur haut (0, 0 si aucune courbe)."""
    m = s['cv_mode']
    if m == 'auto':
        A, B = W * s['cv_w'] / 100.0, H * s['cv_h'] / 100.0
    elif m == 'manuelle':
        A, B = s['cv_a'] / 10.0, s['cv_b'] / 10.0
    else:
        return 0.0, 0.0
    A, B = max(0.0, min(W, A)), max(0.0, min(H, B))
    if A < 0.05 or B < 0.05:
        return 0.0, 0.0
    return A, B


def _un_montant(design, s, tr, x, e, ep, exact):
    """Geometrie du montant d'abscisse x : repere local (ex = largeur, ey = haut, ez = epaisseur), L x H x ep."""
    c = {'ok': False, 'msg': 'ERR', 'x': x, 'W': 0.0, 'H': 0.0, 'e': e}
    cd = _cadre_chemin(tr, x, s['cote'])
    if cd is None:
        c['msg'] = 'ORIENT'
        return c
    p, th, a, up = cd
    dec = s['decal'] / 10.0
    ex, ey, ez = a, up, th
    o = _v_add(p, _v_mul(a, dec))
    # abscisses ou la hauteur / la largeur sont lues : milieu et deux faces du montant (le plus bas / le plus etroit)
    xs3 = (x - e, x, x + e)
    pr = None if exact else _profil(design, s, tr)
    if exact:
        hv, wv = [], []
        for xx in xs3:
            c3 = _cadre_chemin(tr, max(0.0, min(tr.longueur, xx)), s['cote'])
            if c3 is None:
                continue
            hv.append(_h_en(design, c3[0], c3[2], c3[3]))
            wv.append(_w_en(design, c3[0], c3[2], c3[3], dec))
    else:
        hv = [_interp(pr['x'], pr['h'], xx) for xx in xs3]
        wv = [_interp(pr['x'], pr['w'], xx) for xx in xs3]
    hv = [v for v in hv if v is not None]
    wv = [v for v in wv if v is not None]
    if s['h_auto']:
        if not hv:
            c['msg'] = 'HAUT'
            return c
        H = min(hv)
    else:
        H = s['h_mm'] / 10.0
    if s['l_auto']:
        if not wv:
            c['msg'] = 'LARG'
            return c
        W = min(wv) - s['retrait'] / 10.0
    else:
        W = s['l_mm'] / 10.0
    if H < 0.3:
        c['msg'] = 'HAUT'
        return c
    if W < 0.3:
        c['msg'] = 'LARG'
        return c
    A, B = _courbe(s, W, H)
    c.update(ok=True, msg='OK', o=o, ex=ex, ey=ey, ez=ez, W=W, H=H, A=A, B=B, p=p, tenons=[], n_bas=0, n_dos=0)
    if s['ten_on']:
        if exact:
            tb = tp = None
        else:
            tb, tp = _interp(pr['x'], pr['tb'], x), _interp(pr['x'], pr['tp'], x)
        c['tenons'], c['n_bas'], c['n_dos'] = _tenons_montant(design, s, c, p, a, up, e, dec, tb, tp, exact)
    c['centre'] = _w(c, (W / 2.0, H / 2.0, 0.0))
    return c


def _w(c, q):
    """Point local (x largeur, y haut, z epaisseur) -> monde."""
    o, ex, ey, ez = c['o'], c['ex'], c['ey'], c['ez']
    return (o[0] + ex[0] * q[0] + ey[0] * q[1] + ez[0] * q[2],
            o[1] + ex[1] * q[0] + ey[1] * q[1] + ez[1] * q[2],
            o[2] + ex[2] * q[0] + ey[2] * q[1] + ez[2] * q[2])


def _calc(design, s, ep, exact=False):
    """Calcul de tous les montants : dict 'ok', 'msg', 'inst' (un par montant), 'L' (chemin), 'xs'."""
    r = {'ok': False, 'msg': 'CHEMIN', 'inst': [], 'nok': 0, 'ntot': 0, 'L': 0.0}
    if not s['c']:
        return r
    try:
        tr = _traj(s['c'], design)
        Lt = tr.longueur
        e = ep / 2.0
        xs, poig = _positions(Lt, int(s['n']), e, s['m1'], s['m2'])
        r.update(L=Lt, xs=xs, poig=poig, tr=tr)
        if not xs:
            r['msg'] = 'HORS'
            return r
        insts = [_un_montant(design, s, tr, x, e, ep, exact) for x in xs]
        if len(xs) > 1 and (xs[1] - xs[0]) < ep - 1e-4:
            for c in insts:
                if c['ok']:
                    c.update(ok=False, msg='CHEV')
        r.update(inst=insts, ntot=len(insts), nok=sum(1 for c in insts if c['ok']))
        r['ok'] = r['nok'] > 0
        if not r['ok']:
            r['msg'] = insts[0]['msg']
        else:
            r['msg'] = 'OK'
    except Exception:
        _log('calc erreur ' + traceback.format_exc()[-500:])
        r.update(ok=False, msg='ERR')
    return r


MESSAGES = {
    'CHEMIN': "Selectionnez le chemin : la base du dossier, sur la dalle a plat.",
    'ORIENT': "Chemin vertical : non gere.",
    'HAUT': "Hauteur du dossier introuvable : saisissez une hauteur.",
    'LARG': "Largeur de la dalle introuvable : saisissez une largeur.",
    'HORS': "Montants hors du chemin : reduisez les marges ou l'epaisseur.",
    'CHEV': "Montants qui se chevauchent : reduisez le nombre.",
    'ERR': "Calcul impossible pour ces montants."}


# --- Apercu 3D (CustomGraphics) ------------------------------------------------------------------------

_apercu = {'g': [], 'sig': None}


def _profil_pts(c, n_arc=14):
    """Polygone (x, y) local du montant : rectangle dont le coin exterieur haut est un quart d'ellipse."""
    W, H, A, B = c['W'], c['H'], c['A'], c['B']
    pts = [(0.0, 0.0), (W, 0.0)]
    if A > 0 and B > 0:
        pts.append((W, H - B))
        for k in range(1, n_arc):
            th = (math.pi / 2.0) * k / n_arc
            pts.append((W - A + A * math.cos(th), H - B + B * math.sin(th)))
        pts.append((W - A, H))
    else:
        pts.append((W, H))
    pts.append((0.0, H))
    return pts


def _lignes_montant(c):
    """Aretes (paires de points monde) du montant : contour sur les deux faces + montants verticaux aux sommets."""
    e = c['e']
    pts = _profil_pts(c)
    out = []
    for z in (-e, e):
        for i in range(len(pts)):
            a, b = pts[i], pts[(i + 1) % len(pts)]
            out += list(_w(c, (a[0], a[1], z))) + list(_w(c, (b[0], b[1], z)))
    pas = max(1, len(pts) // 8)
    for i in range(0, len(pts), pas):
        out += list(_w(c, (pts[i][0], pts[i][1], -e))) + list(_w(c, (pts[i][0], pts[i][1], e)))
    for (x0, x1, y0, y1, z0, z1) in c.get('tenons') or []:          # tenons : boites filaires
        co = [(x, y, z) for x in (x0, x1) for y in (y0, y1) for z in (z0, z1)]
        for i, j in ((0, 1), (2, 3), (4, 5), (6, 7), (0, 2), (1, 3), (4, 6), (5, 7), (0, 4), (1, 5), (2, 6), (3, 7)):
            out += list(_w(c, co[i])) + list(_w(c, co[j]))
    return out


def _apercu_effacer():
    for g in _apercu['g']:
        try:
            if g.isValid:
                g.deleteMe()
        except Exception:
            pass
    _apercu['g'] = []
    _apercu['sig'] = None
    _balayer(ID_APERCU)


def _apercu_maj(calc, force=False):
    """Un groupe orange (montants valides) et un groupe rouge (invalides), recrees quand la forme change ; le nouveau
    groupe est cree AVANT la suppression de l'ancien (jamais d'image vide)."""
    try:
        if calc is None:
            _apercu_effacer()
            return
        ok_l, ko_l = [], []
        for c in calc['inst']:
            if c.get('o') is not None and c.get('W', 0) > 0:
                (ok_l if c['ok'] else ko_l).extend(_lignes_montant(c))
        sig = (tuple(round(v, 3) for v in ok_l), tuple(round(v, 3) for v in ko_l))
        ok = _apercu['sig'] == sig and not force
        if ok:
            try:
                ok = all(g.isValid for g in _apercu['g'])
            except Exception:
                ok = False
        if ok:
            return
        root = _design().rootComponent
        nouveaux = []
        for pts, col in ((ok_l, ORANGE), (ko_l, ROUGE)):
            if not pts:
                continue
            g = root.customGraphicsGroups.add()
            g.id = ID_APERCU
            ln = g.addLines(adsk.fusion.CustomGraphicsCoordinates.create(pts), [], False)
            ln.weight = 2
            ln.color = adsk.fusion.CustomGraphicsSolidColorEffect.create(adsk.core.Color.create(*col))
            ln.isSelectable = False
            nouveaux.append(g)
        anciens = _apercu['g']
        _apercu['g'] = nouveaux
        _apercu['sig'] = sig
        for g in anciens:
            try:
                if g.isValid:
                    g.deleteMe()
            except Exception:
                pass
    except Exception:
        _log('apercu erreur ' + traceback.format_exc()[-400:])


class _RedrawHandler(adsk.core.CustomEventHandler):
    """Redessin differe : un groupe cree PENDANT un clic de souris disparait (Fusion traite le clic ensuite)."""
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            if not _redraw['on']:
                return
            _ov['sig'] = None
            _ov_maj()
            _apercu_maj(_tous_calculs(), force=True)
            _rafraichir_vue()
        except Exception:
            _log('redraw erreur ' + traceback.format_exc()[-300:])


def _redessiner_differe():
    try:
        for essai in (0, 1):
            if _redraw['evt'] is None:
                try:
                    _app.unregisterCustomEvent(REDRAW_ID)
                except Exception:
                    pass
                _redraw['evt'] = _app.registerCustomEvent(REDRAW_ID)
                _redraw['h'] = _RedrawHandler()
                _redraw['evt'].add(_redraw['h'])
            if _app.fireCustomEvent(REDRAW_ID, ''):
                break
            _redraw['evt'] = None          # evenement mort (add-in relance depuis un script) : on le reenregistre
    except Exception:
        _log('redessiner differe : ' + traceback.format_exc()[-200:])


# --- Fenetre « MONTANTS » en bas a gauche (modele : ReseauTrajectoireCNC) -------------------------------------

OV_W, OV_H = 536, 28
OV_GAP = 6                        # espace entre deux fenetres (une par chemin)
OV_X, OV_Y = 16, 60
OV_M0, OV_M1 = 74, 96            # bouton moins
OV_B0, OV_B1 = 102, 262          # barre de quantite
OV_P0, OV_P1 = 268, 290          # bouton plus
OV_S0, OV_S1 = 338, 366          # symetrie
OV_E0, OV_E1 = 372, 400          # jusqu'au bout
OV_T0, OV_T1 = 406, 434          # cote du montant (fleches haut / bas)
OV_C0, OV_C1 = 440, 468          # courbe exterieure
OV_N0, OV_N1 = 474, 502          # tenons sur les champs plats
OV_EXP = 1.6                     # barre non lineaire : 1 a 20 sur les 3 premiers quarts, puis jusqu'au maximum
_ov = {'g': None, 'sig': None, 'on': None, 'row': 0}
_tip = {'g': None, 'cle': None}


def _q_de_t(t, qm=NB_MAX):
    t = max(0.0, min(1.0, t))
    if t <= 0.75:
        q = 1 + 19.0 * t / 0.75
    else:
        q = 20 + (max(qm, 21) - 20) * (((t - 0.75) / 0.25) ** OV_EXP)
    return max(1, min(qm, int(round(q))))


def _t_de_q(q, qm=NB_MAX):
    qm = max(21, qm)
    if q <= 20:
        return 0.75 * (max(1, q) - 1) / 19.0
    return 0.75 + 0.25 * (min(1.0, (q - 20) / float(qm - 20)) ** (1.0 / OV_EXP))


def _ecrire_png(cle, px, w, h):
    import zlib, struct, tempfile
    raw = bytearray()
    for y in range(h):
        raw.append(0)
        for x in range(w):
            raw += bytes(px[y][x])

    def chunk(tt, dd):
        c = struct.pack('>I', len(dd)) + tt + dd
        return c + struct.pack('>I', zlib.crc32(tt + dd) & 0xffffffff)

    png = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 6, 0, 0, 0)) + \
        chunk(b'IDAT', zlib.compress(bytes(raw))) + chunk(b'IEND', b'')
    chemin = os.path.join(tempfile.gettempdir(), 'montants_cnc_%s.png' % cle)
    with open(chemin, 'wb') as f:
        f.write(png)
    _png_cache[cle] = chemin
    return chemin


def _dpr():
    """Fusion dessine les images des graphiques colles a la vue agrandies du facteur d'echelle de l'ecran."""
    if 'k' not in _dpr_cache:
        k = 1.0
        try:
            import ctypes
            k = max(1.0, ctypes.windll.user32.GetDpiForSystem() / 96.0)
        except Exception:
            pass
        _dpr_cache['k'] = k
    return _dpr_cache['k']


def _texte_px(px, txt, x0, y0, couleur):
    """Capitales sans accent, police 3x5 agrandie x2, pas de 8 px."""
    import unicodedata
    txt = ''.join(c for c in unicodedata.normalize('NFD', txt) if unicodedata.category(c) != 'Mn').upper()
    for n, c in enumerate(txt):
        g = _GLYPHES.get(c, _GLYPHES[' '])
        for gy in range(5):
            for gx in range(3):
                if g[gy * 3 + gx] == '1':
                    for dy in range(2):
                        for dx in range(2):
                            xx, yy = x0 + n * 8 + gx * 2 + dx, y0 + gy * 2 + dy
                            if 0 <= yy < len(px) and 0 <= xx < len(px[0]):
                                px[yy][xx] = couleur


def _png_ligne(q, t, sym, fin, cote, cv, ten=False, actif=True, num=0):
    """Ligne « MONTANTS » : nom, - barre +, quantite, symetrie, jusqu'au bout, cote, courbe. Active (cadre bleu)."""
    nom = _tt('MONTANTS')
    cle = 'l3_%d_%d_%d_%d_%d_%s_%d_%s_%d_%d' % (q, int(t * 1000), sym, fin, cote, cv, ten, nom, actif, num)
    if cle in _png_cache and os.path.isfile(_png_cache[cle]):
        return _png_cache[cle]
    w, h = OV_W, OV_H
    BLEU = (20, 130, 215, 255)
    cadre = BLEU if actif else (95, 95, 95, 255)
    px = [[(40, 40, 40, 255) if actif else (32, 32, 32, 255)] * w for _ in range(h)]
    for x in range(w):
        for y in (0, 1, h - 1, h - 2):
            px[y][x] = cadre
    for y in range(h):
        for x in (0, 1, w - 1, w - 2):
            px[y][x] = cadre
    if num:
        _texte_px(px, str(num), OV_N1 + 10, (h - 10) // 2, (255, 200, 60, 255) if actif else (150, 150, 150, 255))
    yc = h // 2
    _texte_px(px, nom, 8, (h - 10) // 2, (235, 235, 235, 255))
    _texte_px(px, str(q), OV_P1 + 8, (h - 10) // 2, (255, 200, 60, 255))

    def bouton(x0, x1, actif):
        fond = (110, 55, 0, 255) if actif else (62, 62, 62, 255)
        bord = (255, 170, 60, 255) if actif else (125, 125, 125, 255)
        for x in range(x0, x1):
            for y in range(yc - 11, yc + 11):
                px[y][x] = bord if (x in (x0, x1 - 1) or y in (yc - 11, yc + 10)) else fond
        return (255, 140, 0, 255) if actif else (150, 150, 150, 255), (255, 225, 175, 255) if actif else (190, 190, 190, 255)

    plein, clair = bouton(OV_M0, OV_M1, False)
    xm = (OV_M0 + OV_M1) // 2
    for x in range(xm - 5, xm + 5):
        for y in (yc - 1, yc):
            px[y][x] = clair
    plein, clair = bouton(OV_P0, OV_P1, False)
    xp = (OV_P0 + OV_P1) // 2
    for x in range(xp - 5, xp + 5):
        for y in (yc - 1, yc):
            px[y][x] = clair
    for y in range(yc - 5, yc + 5):
        for x in (xp - 1, xp):
            px[y][x] = clair
    # symetrie : deux triangles en miroir
    plein, clair = bouton(OV_S0, OV_S1, sym)
    cx, ht = (OV_S0 + OV_S1) // 2, 15
    for r in range(ht):
        wd = 1 + (r * 8) // (ht - 1)
        y = yc - 7 + r
        for dx in range(1, wd + 1):
            px[y][cx + dx] = plein
            if dx == wd or dx == 1 or r == ht - 1:
                px[y][cx - dx] = clair
    # jusqu'au bout : fleche vers une barre
    plein, clair = bouton(OV_E0, OV_E1, fin)
    x_a, x_b = OV_E0 + 6, OV_E1 - 8
    for x in range(x_a, x_b):
        for y in (yc - 1, yc):
            px[y][x] = plein
    for k in range(6):
        for y in range(yc - 5 + k, yc + 5 - k + 1):
            if 0 <= y < h:
                px[y][x_b - 6 + k + 1 + 2] = plein
    for y in range(yc - 6, yc + 7):
        for x in (OV_E1 - 7, OV_E1 - 6):
            px[y][x] = clair
    # cote : une fleche vers le haut, une vers le bas ; actif quand le cote est inverse
    plein, clair = bouton(OV_T0, OV_T1, cote)
    xh = (OV_T0 + OV_T1) // 2
    for sens, dx in ((-1, -5), (1, 5)):
        for y in range(yc - 6, yc + 7):
            px[y][xh + dx] = clair
        for k in range(4):
            yy = yc - 6 + k if sens < 0 else yc + 6 - k
            for x in range(xh + dx - k, xh + dx + k + 1):
                px[yy][x] = clair
    # courbe exterieure : coin arrondi du montant (aucune : angle droit ; auto : arc plein ; manuelle : arc + points)
    plein, clair = bouton(OV_C0, OV_C1, cv != 'aucune')
    xc = (OV_C0 + OV_C1) // 2
    x0, x1, y0, y1 = xc - 8, xc + 8, yc - 8, yc + 8
    for y in range(y0, y1 + 1):
        px[y][x0] = clair                                     # cote du dossier (a gauche)
    for x in range(x0, x1 + 1):
        px[y1][x] = clair                                     # pied
    if cv == 'aucune':
        for x in range(x0, x1 + 1):
            px[y0][x] = clair
        for y in range(y0, y1 + 1):
            px[y][x1] = clair
    else:
        A, B = 11.0, 8.0
        for k in range(0, 21):
            th = (math.pi / 2.0) * k / 20.0
            xx = int(round(x1 - A + A * math.cos(th)))
            yy = int(round(y0 + B - B * math.sin(th)))
            for ddx in (0, 1):
                if x0 <= xx - ddx <= x1:
                    px[yy][xx - ddx] = plein
        for x in range(x0, int(x1 - A) + 1):
            px[y0][x] = clair
        for y in range(int(y0 + B), y1 + 1):
            px[y][x1] = clair
        if cv == 'manuelle':
            for ddx in range(-2, 3):
                for ddy in range(-2, 3):
                    px[y0 + ddy + 1][x1 - 11 + ddx] = (255, 235, 200, 255)
    # tenons : montant avec un tenon vers le bas (dans la dalle) et vers l'arriere (dans le dossier)
    plein, clair = bouton(OV_N0, OV_N1, ten)
    xt = (OV_N0 + OV_N1) // 2
    for x in range(xt - 3, xt + 8):
        for y in (yc - 8, yc + 3):
            px[y][x] = clair
    for y in range(yc - 8, yc + 4):
        for x in (xt - 3, xt + 7):
            px[y][x] = clair
    for x in range(xt + 0, xt + 5):
        for y in range(yc + 4, yc + 9):
            px[y][x] = plein if x not in (xt, xt + 4) and y != yc + 8 else clair
    # barre de quantite
    kx = OV_B0 + int(round(t * (OV_B1 - OV_B0)))
    for x in range(OV_B0, OV_B1 + 1):
        for y in (yc - 1, yc, yc + 1):
            px[y][x] = BLEU if x <= kx else (150, 150, 150, 255)
    for x in range(kx - 3, kx + 4):
        for y in range(yc - 9, yc + 9):
            px[y][x] = (255, 255, 255, 255) if (x in (kx - 3, kx + 3) or y in (yc - 9, yc + 8)) else BLEU
    return _ecrire_png(cle, px, w, h)


def _png_info(txt):
    """Infobulle claire, comme les bulles natives de Fusion."""
    cle = 'tip_%s' % abs(hash(txt))
    w = len(txt) * 8 + 12
    h = 24
    if cle in _png_cache and os.path.isfile(_png_cache[cle]):
        return _png_cache[cle], w, h
    px = [[(246, 246, 246, 255)] * w for _ in range(h)]
    for x in range(w):
        for y in (0, h - 1):
            px[y][x] = (110, 110, 110, 255)
    for y in range(h):
        for x in (0, w - 1):
            px[y][x] = (110, 110, 110, 255)
    _texte_px(px, txt, 6, 7, (20, 20, 20, 255))
    return _ecrire_png(cle, px, w, h), w, h


def _vp_larg():
    try:
        v = _app.activeViewport
        return (int(v.width), int(v.height))
    except Exception:
        return None


def _est_fin(s=None):
    s = _s if s is None else s
    return s['m1'] < 0.05 and s['m2'] < 0.05


def _ov_etat(s=None):
    s = _s if s is None else s
    return (int(s['n']), _t_de_q(int(s['n'])), bool(s['sym']), _est_fin(s), bool(s['cote']), s['cv_mode'], bool(s['ten_on']))


def _lignes_jeux():
    """Les jeux dessines : un par chemin selectionne (ou le modele seul tant qu'aucun chemin n'est choisi)."""
    return list(_jeux) if _jeux else ([_s] if _s.get('c') else [])


def _ov_y(r):
    """Bas de la fenetre de rang r (0 = la plus basse), en pixels depuis le bas de la vue."""
    return OV_Y + r * (OV_H * _dpr() + OV_GAP)


def _ov_effacer():
    g = _ov['g']
    _ov['g'] = None
    _ov['sig'] = None
    _tip_effacer()
    try:
        if g is not None and g.isValid:
            g.deleteMe()
    except Exception:
        pass


def _ov_maj():
    """Dessine (ou met a jour) les fenetres « MONTANTS » (une par chemin ; composant actif : sinon elles sont grisees)."""
    try:
        jx = _lignes_jeux()
        if not jx:
            _ov_effacer()
            return
        sts = [_ov_etat(j) for j in jx]
        ia = _act['i'] if _jeux else 0
        sig = (tuple(sts), ia, _vp_larg(), _tt('MONTANTS'))
        if sig == _ov['sig'] and _ov['g'] is not None and _ov['g'].isValid:
            return
        _ov_effacer()
        design = _design()
        g = design.activeComponent.customGraphicsGroups.add()
        k = _dpr()
        multi = len(jx) > 1
        for r, st in enumerate(sts):
            png = _png_ligne(st[0], st[1], st[2], st[3], st[4], st[5], st[6], r == ia, (r + 1) if multi else 0)
            ps = g.addPointSet(adsk.fusion.CustomGraphicsCoordinates.create([0.0, 0.0, 0.0]), [0],
                               adsk.fusion.CustomGraphicsPointTypes.UserDefinedCustomGraphicsPointType, png)
            ps.isSelectable = False
            ps.viewPlacement = adsk.fusion.CustomGraphicsViewPlacement.create(
                adsk.core.Point3D.create(0, 0, 0), adsk.fusion.ViewCorners.lowerLeftViewCorner,
                adsk.core.Point2D.create(OV_X + OV_W * k / 2.0, _ov_y(r) + OV_H * k / 2.0))
            _dv_poser(ps)
        _ov['g'] = g
        _ov['sig'] = sig
    except Exception:
        _log('overlay erreur ' + traceback.format_exc()[-400:])


def _ov_assurer():
    """Fenetre effacee par un cycle Fusion : redessinee aussitot."""
    try:
        ok = _ov['g'] is not None and _ov['g'].isValid
    except Exception:
        ok = False
    if not ok and _lignes_jeux():
        _ov['sig'] = None
        _ov_maj()


def _ov_zone(vp, pos):
    """Zone de la fenetre sous le curseur : 'moins', 'plus', 'barre', 'sym', 'fin', 'cote', 'courbe', 'ligne' ou None."""
    nb = len(_lignes_jeux())
    if _ov['g'] is None or not nb:
        return None
    k = _dpr()
    h = vp.height * k
    r = int(round((h - pos.y - _ov_y(0) - OV_H * k / 2.0) / (OV_H * k + OV_GAP)))
    if r < 0 or r >= nb:
        return None
    yc = h - (_ov_y(r) + OV_H * k / 2.0)
    if abs(pos.y - yc) > OV_H * k / 2.0:
        return None
    _ov['row'] = r
    x = (pos.x - OV_X) / k
    if x < 0 or x > OV_W:
        return None
    if OV_M0 <= x <= OV_M1:
        return 'moins'
    if OV_P0 <= x <= OV_P1:
        return 'plus'
    if OV_B0 - 6 <= x <= OV_B1 + 6:
        return 'barre'
    if OV_S0 <= x <= OV_S1:
        return 'sym'
    if OV_E0 <= x <= OV_E1:
        return 'fin'
    if OV_T0 <= x <= OV_T1:
        return 'cote'
    if OV_C0 <= x <= OV_C1:
        return 'courbe'
    if OV_N0 <= x <= OV_N1:
        return 'tenons'
    return 'ligne'


def _tip_effacer():
    g = _tip['g']
    _tip['g'] = None
    _tip['cle'] = None
    try:
        if g is not None and g.isValid:
            g.deleteMe()
            _rafraichir_vue()
    except Exception:
        pass


def _texte_aide(zone):
    cv = {'aucune': "Courbe du haut : aucune - clic : automatique",
          'auto': "Courbe du haut : automatique - clic : manuelle",
          'manuelle': "Courbe du haut : manuelle - clic : aucune"}
    return {'moins': "Un montant de moins", 'plus': "Un montant de plus",
            'sym': "Symetrie : memes marges au debut et a la fin",
            'fin': "Jusqu'au bout du chemin",
            'cote': "Cote du montant - clic : inverser",
            'courbe': cv[(_lignes_jeux()[_ov['row']] if _ov['row'] < len(_lignes_jeux()) else _s)['cv_mode']],
            'tenons': "Tenons sur les champs plats - clic : activer ou non"}.get(zone)


_ZONE_X = {'moins': OV_M0, 'plus': OV_P0, 'sym': OV_S0, 'fin': OV_E0, 'cote': OV_T0, 'courbe': OV_C0, 'tenons': OV_N0}


def _tip_maj(vp, pos):
    """Infobulle (graphique colle a la vue) a droite de la ligne, au survol d'une icone."""
    z = _ov_zone(vp, pos) if _ov['g'] is not None else None
    txt = _texte_aide(z) if z in _ZONE_X else None
    cle = None if txt is None else (z, txt)
    if cle == _tip['cle'] and (cle is None or (_tip['g'] is not None and _tip['g'].isValid)):
        return
    _tip_effacer()
    if txt is None:
        return
    design = _design()
    png, w, h = _png_info(_tt(txt))
    g = design.activeComponent.customGraphicsGroups.add()
    k = _dpr()
    gauche = OV_X + (OV_W + 8) * k
    haut = _ov_y(_ov['row']) + (OV_H * k - h * k) / 2.0 - 8
    ps = g.addPointSet(adsk.fusion.CustomGraphicsCoordinates.create([0.0, 0.0, 0.0]), [0],
                       adsk.fusion.CustomGraphicsPointTypes.UserDefinedCustomGraphicsPointType, png)
    ps.isSelectable = False
    ps.viewPlacement = adsk.fusion.CustomGraphicsViewPlacement.create(
        adsk.core.Point3D.create(0, 0, 0), adsk.fusion.ViewCorners.lowerLeftViewCorner,
        adsk.core.Point2D.create(gauche + w * k / 2.0, haut + 8 + h * k / 2.0))
    _dv_poser(ps)
    _tip['g'] = g
    _tip['cle'] = cle
    _rafraichir_vue()


# --- Poignees (pastilles) : marges du debut et de la fin, quantite au centre ---------------------------------

def _poignees():
    """[(k, trajet, fraction)] : 1 = premier montant (marge du debut), 2 = dernier montant (marge de la fin)."""
    if not _s['c']:
        return []
    tr = _traj(_s['c'], _design())
    Lt = tr.longueur
    xs, (a, b) = _positions(Lt, int(_s['n']), _cur['ep'] / 2.0, _s['m1'], _s['m2'])
    return [(1, tr, max(0.0, min(1.0, a / Lt))), (2, tr, max(0.0, min(1.0, b / Lt)))]


def _poignee_set(k, f, tr):
    """La pastille k est amenee a la fraction f du chemin : marge correspondante (la symetrie lie les deux marges)."""
    Lt = tr.longueur
    x = f * Lt
    e = _cur['ep'] / 2.0
    if k == 1:
        m = round(max(0.0, min(x - e, Lt - 2.0 * e - (0.0 if _s['sym'] else _s['m2'] / 10.0))) * 10.0, 1)
        _s['m1'] = m
        if _s['sym']:
            _s['m2'] = m
    else:
        m = round(max(0.0, min(Lt - x - e, Lt - 2.0 * e - (0.0 if _s['sym'] else _s['m1'] / 10.0))) * 10.0, 1)
        _s['m2'] = m
        if _s['sym']:
            _s['m1'] = m
    if _s['sym']:                                    # les deux marges egales ne doivent pas se croiser
        _s['m1'] = _s['m2'] = min(_s['m1'], max(0.0, (Lt - 2.0 * e) * 5.0 - 0.1))


def _qp_pos():
    if _caf is None or not _s['c']:
        return None
    hs = _poignees()
    if not hs:
        return None
    tr = hs[0][1]
    fs = [h[2] for h in hs]
    f = sum(fs) / len(fs)
    if abs(fs[-1] - fs[0]) < 0.04:
        f = fs[0] + (0.08 if fs[0] < 0.5 else -0.08)
    return tr, max(0.0, min(1.0, f))


def _maj_pastilles():
    """Pastilles orange des bouts et pastille bleue de quantite (recreees si Fusion les a annulees)."""
    if _caf is None:
        return
    try:
        hs = _poignees()
    except Exception:
        _log('pastilles : ' + traceback.format_exc()[-200:])
        hs = []
    qp = None
    try:
        qp = _qp_pos()
    except Exception:
        pass
    ks = set(h[0] for h in hs)
    if qp is not None:
        ks.add(0)
    for k in list(_pastilles):
        if k not in ks:
            g = _pastilles.pop(k, None)
            if g is not None:
                g.effacer()
    for k, tr, f in hs:
        try:
            g = _pastilles.get(k)
            if g is None:
                g = _pastilles[k] = _caf.Poignee(ID_PASTILLE % k)
                _camera_suivre(True)
            g.placer(tr.at(f)[0])
        except Exception:
            _log('pastille %d : %s' % (k, traceback.format_exc()[-200:]))
    if qp is not None and not _qd.get('on'):
        try:
            g = _pastilles.get(0)
            if g is None:
                g = _pastilles[0] = _caf.Poignee(ID_PASTILLE % 0, 'quantite')
                _camera_suivre(True)
            g.placer(qp[0].at(qp[1])[0])
        except Exception:
            _log('pastille quantite : ' + traceback.format_exc()[-200:])


def _pastille_touchee(vp, pos):
    """Numero de la pastille attrapee : sur la pastille, sinon sur le chemin (saut au point clique, vers la plus
    proche des deux pastilles des bouts)."""
    if not _s['c']:
        return None, None
    r = 14.0 * _dpr()
    hs = _poignees()
    best = None
    for k, tr, f in hs:
        q = vp.modelToViewSpace(adsk.core.Point3D.create(*tr.at(f)[0]))
        d = math.hypot(q.x - pos.x, q.y - pos.y)
        if d <= r and (best is None or d < best[0]):
            best = (d, k)
    if best is not None:
        return best[1], None
    if hs:
        tr = hs[0][1]
        ecr = _ecran(tr, vp)
        for j in range(len(ecr) - 1):
            ax, ay = ecr[j]
            ex, ey = ecr[j + 1][0] - ax, ecr[j + 1][1] - ay
            e2 = ex * ex + ey * ey
            u = 0.0 if e2 < 1e-12 else max(0.0, min(1.0, ((pos.x - ax) * ex + (pos.y - ay) * ey) / e2))
            d = math.hypot(ax + u * ex - pos.x, ay + u * ey - pos.y)
            if d <= r * 0.75 and (best is None or d < best[0]):
                fc = (tr.cum[j] + u * (tr.cum[j + 1] - tr.cum[j])) / tr.longueur
                kk = min(hs, key=lambda h: abs(h[2] - fc))[0]
                best = (d, kk, fc)
    return (best[1], best[2]) if best is not None else (None, None)


def _qd_debut(ins, vp, pos):
    g = _pastilles.get(0)
    if g is None or g.p is None:
        return False
    q = vp.modelToViewSpace(adsk.core.Point3D.create(*g.p))
    if math.hypot(q.x - pos.x, q.y - pos.y) > 14.0 * _dpr():
        return False
    qp = _qp_pos()
    if qp is None:
        return False
    tr, fm = qp
    p, tg = tr.at(fm)
    sens = 1.0
    try:                               # droite de l'ecran = plus de montants, quel que soit le sens du chemin
        a = vp.modelToViewSpace(adsk.core.Point3D.create(*p))
        b = vp.modelToViewSpace(adsk.core.Point3D.create(*_v_add(p, _v_mul(tg, tr.longueur * 0.01))))
        if b.x - a.x < 0:
            sens = -1.0
    except Exception:
        pass
    _cur['ep'] = _ep_cm(ins)
    _qd.clear()
    _qd.update(on=True, tr=tr, fm=fm, sens=sens, t0=_t_de_q(int(_s['n'])), tm=0.0)
    _souris.update(pos=pos, vp=vp, t=time.perf_counter())
    return True


def _qd_glisser(vp):
    t0 = time.perf_counter()
    if not _qd.get('on') or t0 - _qd.get('tm', 0.0) < 0.012:
        return
    _qd['tm'] = t0
    try:
        tr = _qd['tr']
        f = _frac_souris(tr, vp, _souris['pos'])
        q = _q_de_t(_qd['t0'] + _qd['sens'] * (f - _qd['fm']) / 0.5)
        g = _pastilles.get(0)
        if g is not None:
            g.placer(tr.at(f)[0])
        if q != int(_s['n']):
            _s['n'] = q
            _rafraichir_rapide()
        vp.refresh()
    except Exception:
        _log('poignee quantite : ' + traceback.format_exc()[-300:])


def _qd_fin(ins):
    _qd['on'] = False
    _sel_rendre(ins)
    _qd.pop('tr', None)
    _bloc['t'] = time.time()
    _appliquer(lambda: _sync_champs(ins), ins, True)
    _redessiner_differe()


def _glisser_souris(vp):
    """Pendant le glisser d'une pastille, l'aperçu suit la SOURIS (aucun cycle de calcul de Fusion)."""
    t0 = time.perf_counter()
    if _en_cours['v'] or t0 - _drag.get('tm', 0.0) < 0.008:
        return
    _drag['tm'] = t0
    k = _drag['k']
    hs = _poignees()
    tr = next((h[1] for h in hs if h[0] == k), None)
    if tr is None:
        return
    _poignee_set(k, _frac_souris(tr, vp, _souris['pos']), tr)
    _rafraichir_rapide()
    for kk, trk, fk in _poignees():
        g = _pastilles.get(kk)
        if g is not None:
            g.placer(trk.at(fk)[0])
    q = _qp_pos()
    g0 = _pastilles.get(0)
    if q is not None and g0 is not None:
        g0.placer(q[0].at(q[1])[0])
    vp.refresh()


def _clic_simple(pos):
    pd = _drag.get('pd')
    if pd is None or pos is None:
        return False
    return time.perf_counter() - _drag.get('td', 0.0) < 0.4 and math.hypot(pos.x - pd[0], pos.y - pd[1]) < 5.0 * _dpr()


def _sel_figer(ins):
    """Debut du glisser d'une poignee : pas de rectangle de selection de Fusion (meme technique que Traverse CNC :
    champs remplis declares pleins, champ actif sans focus s'il n'a pas exactement 1 element)."""
    if _caf is None:
        return
    avant = _en_cours['v']
    _en_cours['v'] = True
    try:
        _sel_fig['e'] = _caf.selections_figer(ins, 'glisser')
    except Exception:
        _sel_fig['e'] = None
    finally:
        _en_cours['v'] = avant


def _sel_rendre(ins):
    etat, _sel_fig['e'] = _sel_fig['e'], None
    if _caf is None or etat is None:
        return
    avant = _en_cours['v']
    _en_cours['v'] = True
    try:
        _caf.selections_rendre(etat)
    except Exception:
        pass
    finally:
        _en_cours['v'] = avant


def _fin_maison(ins):
    _drag['k'] = None
    _sel_rendre(ins)
    if _drag.get('maison'):
        _drag['maison'] = False
        _drag['pris'] = False
        _bloc['t'] = time.time()
    _appliquer(lambda: _sync_champs(ins), ins, True)
    _redessiner_differe()


# --- Selection ------------------------------------------------------------------------------------------

def _selections(sel):
    return [sel.selection(i).entity for i in range(sel.selectionCount)]


def _bloquer_selection(inputs):
    _bloc['t'] = time.time()
    _bloc['sel'] = {iid: [e.entityToken for e in _selections(inputs.itemById(iid))] for iid in SEL_IDS}


def _restaurer_selection(inputs, iid):
    """Un clic sur une fenetre ne doit rien selectionner derriere : on remet la selection d'avant."""
    if _bloc['sel'] is None or (time.time() - _bloc['t'] > 1.0 and not _drag.get('maison') and not _qd.get('on')):
        return False
    design = _design()
    for k in SEL_IDS:
        sel = inputs.itemById(k)
        voulus = _bloc['sel'].get(k, [])
        if [e.entityToken for e in _selections(sel)] == voulus:
            continue
        sel.clearSelection()
        for e in _ents(design, voulus):
            sel.addSelection(e)
    return True


def _charger_selection(inputs):
    sel = inputs.itemById('chemin')
    sel.clearSelection()
    toks = []
    for j in (_jeux or [_s]):
        toks.extend(t for t in j['c'] if t not in toks)
    for e in _ents(_design(), toks):
        sel.addSelection(e)


def _copie_jeu(src, tok):
    j = dict(src)
    j['c'] = [tok]
    j['fin_m'] = list(src['fin_m']) if src.get('fin_m') else None
    return j


def _lire_selection(inputs):
    """Un jeu de reglages par chemin selectionne : les jeux existants gardent leurs reglages, un nouveau chemin recoit
    une copie des reglages du jeu actif (et devient le jeu actif)."""
    global _s
    toks = [e.entityToken for e in _selections(inputs.itemById('chemin'))]
    nouveaux, ajoutes = [], []
    for t in toks:
        j = next((x for x in _jeux if t in x['c']), None)
        if j is None:
            j = next((x for x in nouveaux if t in x['c']), None)
        if j is None:
            if not _jeux and not nouveaux and not _s.get('c'):
                j = _s                                   # le modele devient le premier jeu
                j['c'] = [t]
            else:
                j = _copie_jeu(_s, t)
            ajoutes.append(j)
            try:
                cote = _cote_auto(_design(), _traj(j['c'], _design()))
                if cote is not None:
                    j['cote'] = cote
            except Exception:
                _log('cote auto : ' + traceback.format_exc()[-200:])
        if all(j is not x for x in nouveaux):
            nouveaux.append(j)
    ancien = _s
    _jeux[:] = nouveaux
    _prof_inv()
    if not nouveaux:
        _s = _copie_jeu(ancien, None)
        _s['c'] = []
        _act['i'] = 0
        return
    if ajoutes:
        i = next(k for k, x in enumerate(nouveaux) if x is ajoutes[-1])
    else:
        i = next((k for k, x in enumerate(nouveaux) if x is ancien), 0)
    _act['i'] = i
    _s = nouveaux[i]


def _activer(i, inputs):
    """La fenetre cliquee devient la fenetre active : les champs de la boite montrent ses reglages."""
    global _s
    if not _jeux or i == _act['i'] or not (0 <= i < len(_jeux)):
        return
    _act['i'] = i
    _s = _jeux[i]
    _appliquer(lambda: _sync_champs(inputs), inputs, True)


# --- Rafraichissement -----------------------------------------------------------------------------------

def _resume(c):
    if not c['ok']:
        return _tt(MESSAGES.get(c['msg'], MESSAGES['ERR']))
    hs = [int(round(i['H'] * 10)) for i in c['inst'] if i['ok']]
    ws = [int(round(i['W'] * 10)) for i in c['inst'] if i['ok']]
    txt = _tt('Montants : {0} sur {1}, hauteur {2} mm, largeur {3} mm.')
    rng = lambda v: str(min(v)) if min(v) == max(v) else '%d-%d' % (min(v), max(v))
    txt = txt.replace('{0}', str(c['nok'])).replace('{1}', str(c['ntot'])).replace('{2}', rng(hs)).replace('{3}', rng(ws))
    if _s['ten_on']:
        nb = sum(i.get('n_bas', 0) for i in c['inst'] if i['ok'])
        nd = sum(i.get('n_dos', 0) for i in c['inst'] if i['ok'])
        txt += ' ' + _tt('Tenons : {0} sur le dos, {1} dessous.').replace('{0}', str(nd)).replace('{1}', str(nb))
    if c['nok'] < c['ntot']:
        bad = next(i for i in c['inst'] if not i['ok'])
        txt += ' ' + _tt(MESSAGES.get(bad['msg'], MESSAGES['ERR']))
    return txt


def _tous_calculs():
    """Calcul de tous les chemins reunis (aperçu) ; None si rien a montrer."""
    cs = _cur.get('calcs') or []
    if not cs:
        return _cur['calc']
    return {'inst': [i for c in cs for i in c['inst']]}


def _rafraichir(inputs, poignees=False):
    design = _design()
    ep = _ep_cm(inputs)
    _cur['ep'] = ep
    jx = list(_jeux) if _jeux else [_s]
    cs = [_calc(design, j, ep) for j in jx]
    ia = _act['i'] if _jeux else 0
    c = cs[ia]
    _cur['calcs'] = cs
    _cur['calc'] = c
    txt = _resume(c)
    if len(jx) > 1:
        txt = _tt('Chemin {0} sur {1} : ').replace('{0}', str(ia + 1)).replace('{1}', str(len(jx))) + txt
        mauvais = [str(k + 1) for k, x in enumerate(cs) if not x['ok']]
        if mauvais:
            txt += ' ' + _tt('Chemins invalides : {0}.').replace('{0}', ', '.join(mauvais))
    inputs.itemById('msg').text = txt
    if poignees:
        _maj_pastilles()
    _ov_maj()
    _apercu_maj(_tous_calculs())
    _rafraichir_vue()


def _rafraichir_rapide():
    """Pendant un glisser : calcul (profil interpole), aperçu et fenetre, rien d'autre."""
    c = _calc(_design(), _s, _cur['ep'])
    _cur['calc'] = c
    cs = _cur.get('calcs')
    if cs and _jeux and 0 <= _act['i'] < len(cs):
        cs[_act['i']] = c
    _apercu_maj(_tous_calculs())
    _ov_maj()
    _ov_assurer()


def _appliquer(fn, inputs, poignees=False):
    """Ecritures de champs sous garde (leurs evenements sont ignores), puis rafraichissement."""
    _en_cours['v'] = True
    try:
        fn()
        _rafraichir(inputs, poignees)
    finally:
        _en_cours['v'] = False


def _sync_champs(inputs):
    """Les champs de la boite suivent les reglages (modifies par la fenetre, les pastilles ou l'historique)."""
    inputs.itemById('nb').value = int(_s['n'])
    inputs.itemById('mode_crea').listItems.item(0 if _s.get('param', True) else 1).isSelected = True
    inputs.itemById('m1').value = _s['m1'] / 10.0
    inputs.itemById('m2').value = _s['m2'] / 10.0
    inputs.itemById('sym').value = bool(_s['sym'])
    inputs.itemById('cote').value = bool(_s['cote'])
    inputs.itemById('hauteur_auto').value = bool(_s['h_auto'])
    inputs.itemById('hauteur').value = _s['h_mm'] / 10.0
    inputs.itemById('hauteur').isEnabled = not _s['h_auto']
    inputs.itemById('largeur_auto').value = bool(_s['l_auto'])
    inputs.itemById('largeur').value = _s['l_mm'] / 10.0
    inputs.itemById('largeur').isEnabled = not _s['l_auto']
    inputs.itemById('retrait').value = _s['retrait'] / 10.0
    inputs.itemById('retrait').isEnabled = bool(_s['l_auto'])
    inputs.itemById('decal').value = _s['decal'] / 10.0
    dd = inputs.itemById('cv_mode')
    dd.listItems.item(CV_MODES.index(_s['cv_mode'])).isSelected = True
    inputs.itemById('cv_w').value = _s['cv_w']
    inputs.itemById('cv_h').value = _s['cv_h']
    inputs.itemById('cv_a').value = _s['cv_a'] / 10.0
    inputs.itemById('cv_b').value = _s['cv_b'] / 10.0
    inputs.itemById('ten_on').value = bool(_s['ten_on'])
    inputs.itemById('ten_dos').value = bool(_s['ten_dos'])
    inputs.itemById('ten_bas').value = bool(_s['ten_bas'])
    inputs.itemById('ten_auto').value = bool(_s['ten_auto'])
    inputs.itemById('ten_n_dos').value = int(_s['ten_n_dos'])
    inputs.itemById('ten_n_bas').value = int(_s['ten_n_bas'])
    inputs.itemById('ten_n_dos').isEnabled = not _s['ten_auto']
    inputs.itemById('ten_n_bas').isEnabled = not _s['ten_auto']
    inputs.itemById('ten_len').value = _s['ten_len'] / 10.0
    inputs.itemById('ten_edge').value = _s['ten_edge'] / 10.0
    inputs.itemById('ten_h_auto').value = bool(_s['ten_h_auto'])
    inputs.itemById('ten_h').value = _s['ten_h'] / 10.0
    inputs.itemById('ten_h').isEnabled = not _s['ten_h_auto']
    auto, man = _s['cv_mode'] == 'auto', _s['cv_mode'] == 'manuelle'
    inputs.itemById('cv_w').isVisible = auto
    inputs.itemById('cv_h').isVisible = auto
    inputs.itemById('cv_a').isVisible = man
    inputs.itemById('cv_b').isVisible = man


def _rebloquer(inputs):
    try:
        _bloquer_selection(inputs)
    except Exception:
        pass


# --- Actions de la fenetre ------------------------------------------------------------------------------

def _set_n(inputs, n):
    n = max(1, min(NB_MAX, int(n)))
    if n == int(_s['n']):
        return
    _s['n'] = n
    _appliquer(lambda: _sync_champs(inputs), inputs, True)
    _rebloquer(inputs)


def _bascule_sym(inputs):
    _s['sym'] = not _s['sym']
    if _s['sym']:
        _s['m2'] = _s['m1']

    _appliquer(lambda: _sync_champs(inputs), inputs, True)
    _rebloquer(inputs)


def _bascule_fin(inputs):
    """Jusqu'au bout du chemin : marges a zero ; un second clic remet les marges d'avant."""
    if _est_fin():
        m = _s.get('fin_m') or [20.0, 20.0]
        _s['m1'], _s['m2'] = float(m[0]), float(m[1])
    else:
        _s['fin_m'] = [_s['m1'], _s['m2']]
        _s['m1'] = _s['m2'] = 0.0
    _appliquer(lambda: _sync_champs(inputs), inputs, True)
    _rebloquer(inputs)


def _bascule_cote(inputs):
    _s['cote'] = not _s['cote']
    _prof_inv()
    _appliquer(lambda: _sync_champs(inputs), inputs, True)
    _rebloquer(inputs)


def _bascule_courbe(inputs):
    _s['cv_mode'] = CV_MODES[(CV_MODES.index(_s['cv_mode']) + 1) % len(CV_MODES)]
    _appliquer(lambda: _sync_champs(inputs), inputs, True)
    _rebloquer(inputs)


def _bascule_tenons(inputs):
    _s['ten_on'] = not _s['ten_on']
    _prof_inv()
    _appliquer(lambda: _sync_champs(inputs), inputs, True)
    _rebloquer(inputs)


def _barre_vers(vp, pos):
    """Position de la souris sur la barre -> quantite (aperçu seul pendant le glisser)."""
    k = _dpr()
    x = (pos.x - OV_X) / k
    t = (x - OV_B0) / float(OV_B1 - OV_B0)
    q = _q_de_t(t)
    if q != int(_s['n']):
        _s['n'] = q
        _rafraichir_rapide()
        vp.refresh()


class _MouseHandler(adsk.core.MouseEventHandler):
    def __init__(self, nom): super().__init__(); self.nom = nom
    def notify(self, args):
        try:
            _souris.update(pos=args.viewportPosition, vp=args.viewport, t=time.perf_counter())
            if _bar['on'] and self.nom == 'mouseDrag':
                if time.perf_counter() - _bar['tm'] >= 0.012:
                    _bar['tm'] = time.perf_counter()
                    _barre_vers(args.viewport, args.viewportPosition)
            elif _qd.get('on') and self.nom == 'mouseDrag':
                _qd_glisser(args.viewport)
            elif _drag.get('maison') and _drag['k'] is not None and (self.nom == 'mouseDrag' or _drag.get('pris')):
                _glisser_souris(args.viewport)
            elif self.nom == 'mouseMove' and _drag['k'] is None:
                _tip_maj(args.viewport, args.viewportPosition)
        except Exception:
            pass


class _MouseDownHandler(adsk.core.MouseEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            ins = args.firingEvent.sender.commandInputs
            vp, pos = args.viewport, args.viewportPosition
            _tip_effacer()
            if _drag.get('pris') and _drag['k'] is not None:
                _bloquer_selection(ins)           # poignee attrapee par un clic : ce clic la pose
                _fin_maison(ins)
                return
            z = _ov_zone(vp, pos)
            if z is None:
                _bloc['sel'] = None
                if _caf is not None and args.button == adsk.core.MouseButtons.LeftMouseButton:
                    if _qd_debut(ins, vp, pos):
                        _bloquer_selection(ins)
                        _sel_figer(ins)            # pas de rectangle de selection pendant le glisser
                        return
                    k, f = _pastille_touchee(vp, pos)
                    if k is not None:
                        _bloquer_selection(ins)
                        _sel_figer(ins)            # pas de rectangle de selection pendant le glisser
                        _cur['ep'] = _ep_cm(ins)
                        if f is not None:
                            trk = next((h[1] for h in _poignees() if h[0] == k), None)
                            if trk is not None:
                                _poignee_set(k, f, trk)
                        _drag.update(k=k, maison=True, tm=0.0, pris=False, pd=(pos.x, pos.y), td=time.perf_counter())
                        _souris.update(pos=pos, vp=vp, t=time.perf_counter())
                        _glisser_souris(vp)
                return
            _bloquer_selection(ins)                # un clic sur la fenetre ne change jamais la selection Fusion
            try:
                self._clic(ins, vp, pos, z)
            finally:
                _redessiner_differe()
        except Exception:
            _log('mouseDown erreur ' + traceback.format_exc()[-400:])

    def _clic(self, ins, vp, pos, z):
        try:
            _cur['ep'] = _ep_cm(ins)
            if _jeux and _ov['row'] != _act['i']:
                _activer(_ov['row'], ins)
            if z == 'moins':
                _set_n(ins, int(_s['n']) - 1)
            elif z == 'plus':
                _set_n(ins, int(_s['n']) + 1)
            elif z == 'barre':
                _bar.update(on=True, tm=time.perf_counter())
                _barre_vers(vp, pos)
            elif z == 'sym':
                _bascule_sym(ins)
            elif z == 'fin':
                _bascule_fin(ins)
            elif z == 'cote':
                _bascule_cote(ins)
            elif z == 'courbe':
                _bascule_courbe(ins)
            elif z == 'tenons':
                _bascule_tenons(ins)
        except Exception:
            _log('clic fenetre erreur ' + traceback.format_exc()[-400:])


class _MouseUpHandler(adsk.core.MouseEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            ins = args.firingEvent.sender.commandInputs
            if _bar['on']:
                _bar['on'] = False
                _bloc['t'] = time.time()
                _appliquer(lambda: _sync_champs(ins), ins, True)
                _redessiner_differe()
                return
            if _qd.get('on'):
                _qd_fin(ins)
                return
            if _drag['k'] is not None:
                if _drag.get('maison') and not _drag.get('pris') and _clic_simple(args.viewportPosition):
                    _drag['pris'] = True
                    _bloc['t'] = time.time()
                    return
                if _drag.get('pris'):
                    return                         # attrapee : c'est le prochain clic qui la pose
                _fin_maison(ins)
        except Exception:
            _log('mouseUp erreur ' + traceback.format_exc()[-400:])


# --- Creation des corps ---------------------------------------------------------------------------------

def _boite_tbm(tbm, c, x0, x1, y0, y1, z0, z1):
    """Boite temporaire pour des bornes locales (x largeur, y hauteur, z epaisseur)."""
    P3, V3 = adsk.core.Point3D.create, adsk.core.Vector3D.create
    ctr = _w(c, ((x0 + x1) / 2.0, (y0 + y1) / 2.0, (z0 + z1) / 2.0))
    obb = adsk.core.OrientedBoundingBox3D.create(P3(*ctr), V3(*c['ex']), V3(*c['ez']), x1 - x0, z1 - z0, y1 - y0)
    return tbm.createBox(obb)


def _corps_temporaire(c, ep_cm):
    """Corps du montant : boite largeur x hauteur x epaisseur, coin exterieur haut arrondi par un quart d'ellipse."""
    tbm = adsk.fusion.TemporaryBRepManager.get()
    P3, V3 = adsk.core.Point3D.create, adsk.core.Vector3D.create
    DIFF = adsk.fusion.BooleanTypes.DifferenceBooleanType
    e = ep_cm / 2.0
    W, H, A, B = c['W'], c['H'], c['A'], c['B']
    corps = _boite_tbm(tbm, c, 0.0, W, 0.0, H, -e, e)
    if A > 0 and B > 0:
        m = 0.5
        coin = _boite_tbm(tbm, c, W - A, W + m, H - B, H + m, -e - m, e + m)
        cx, cy = W - A, H - B
        p1, p2 = _w(c, (cx, cy, -e - m)), _w(c, (cx, cy, e + m))
        if A >= B:
            ell = tbm.createEllipticalCylinderOrCone(P3(*p1), A, B, P3(*p2), A, V3(*c['ex']))
        else:
            ell = tbm.createEllipticalCylinderOrCone(P3(*p1), B, A, P3(*p2), B, V3(*c['ey']))
        tbm.booleanOperation(coin, ell, DIFF)       # il ne reste que l'angle exterieur a retirer
        tbm.booleanOperation(corps, coin, DIFF)
    UN = adsk.fusion.BooleanTypes.UnionBooleanType
    for b in c.get('tenons') or []:
        tbm.booleanOperation(corps, _boite_tbm(tbm, c, *b), UN)
    try:
        occ = _design().activeOccurrence
        if occ is not None:                          # composant actif en edition : coordonnees du composant
            inv = occ.transform2.copy()
            inv.invert()
            tbm.transform(corps, inv)
    except Exception:
        _log('transform erreur ' + traceback.format_exc()[-200:])
    return corps


def _blob(ep_cm):
    """Reglages ecrits sur ce que l'on cree : l'historique de CNC Toolkit rouvre la fenetre telle qu'elle etait."""
    return json.dumps({'v': 1, 's': {k: _s[k] for k in CLES}, 'ep': ep_cm, 'ep_nom': _cur.get('ep_nom')})


def _ep_choisir_nom(inputs, cm, nom):
    """Rouvre la fenetre sur le parametre CPxx utilise a la creation (sa valeur d'aujourd'hui), sinon sur l'epaisseur
    enregistree."""
    try:
        design = _design()
        noms = _ep_noms(design)
        if nom and nom in noms and design.allParameters.itemByName(nom) is not None:
            inputs.itemById('ep_dd').listItems.item(noms.index(nom)).isSelected = True
            inputs.itemById('ep_autre').isVisible = False
            return
    except Exception:
        _log('ep nom erreur ' + traceback.format_exc()[-200:])
    _ep_choisir(inputs, cm)


def _profil_montant(c):
    """Contour du montant (x largeur, y haut, cm) : rectangle, tenons du dessous et du dos, coin exterieur haut arrondi.
    Renvoie (points, indices de debut et de fin de la courbe, points de la courbe)."""
    W, H, A, B = c['W'], c['H'], c['A'], c['B']
    bas = sorted((t for t in (c.get('tenons') or []) if t[3] <= 1e-9 and t[2] < -1e-9 and t[0] >= -1e-9), key=lambda t: t[0])
    dos = sorted((t for t in (c.get('tenons') or []) if t[1] <= 1e-9 and t[0] < -1e-9 and t[2] >= -1e-9), key=lambda t: -t[2])
    pts = [(0.0, 0.0)]
    for (x0, x1, y0, y1, z0, z1) in bas:
        pts += [(x0, 0.0), (x0, y0), (x1, y0), (x1, 0.0)]
    pts += [(W, 0.0)]
    cour = []
    if A > 0 and B > 0:
        pts += [(W, H - B)]
        cx, cy = W - A, H - B
        n = 24
        for i in range(n + 1):
            t = math.pi / 2.0 * i / n
            cour.append((cx + A * math.cos(t), cy + B * math.sin(t)))
        pts += [(W - A, H)]
    else:
        pts += [(W, H)]
    pts += [(0.0, H)]
    for (x0, x1, y0, y1, z0, z1) in dos:
        pts += [(0.0, y1), (x0, y1), (x0, y0), (0.0, y0)]
    out = []
    for q in pts:
        if not out or abs(q[0] - out[-1][0]) > 1e-6 or abs(q[1] - out[-1][1]) > 1e-6:
            out.append(q)
    if len(out) > 1 and abs(out[0][0] - out[-1][0]) < 1e-6 and abs(out[0][1] - out[-1][1]) < 1e-6:
        out.pop()
    return out, cour


def _param_epaisseur(design, cm):
    """Parametre CPxx dont la valeur est cm (la profondeur d'un tenon = l'epaisseur du CP qui le recoit), ou None."""
    try:
        ups = design.userParameters
        for i in range(ups.count):
            q = ups.item(i)
            if q.name.upper().startswith('CP') and abs(q.value - cm) < 1e-4:
                return q.name
    except Exception:
        pass
    return None


def _lier_tenons(design, sk, c, F, libres_haut=()):
    """La profondeur de chaque tenon est une cote de l'esquisse egale au parametre CPxx de meme valeur : changer
    l'epaisseur du CP femelle allonge ou raccourcit les tenons. F(x, y) : point local -> point d'esquisse.
    Vitesse : points et lignes de l'esquisse lus une seule fois, calcul de l'esquisse differe pendant la pose des
    contraintes (un seul calcul a la fin au lieu d'un par point fixe)."""
    lignes = sk.sketchCurves.sketchLines
    L = []                                              # (ligne, debut, fin) lus une fois
    for k in range(lignes.count):
        ln = lignes.item(k)
        L.append((ln, ln.startSketchPoint.geometry, ln.endSketchPoint.geometry))
    PTS = []                                            # (point, geometrie, reference ?)
    for k in range(sk.sketchPoints.count):
        pt = sk.sketchPoints.item(k)
        PTS.append((pt, pt.geometry, pt.isReference))

    def near(g, q):
        return g.distanceTo(F(q[0], q[1])) < 1e-5

    def ligne(p, q, sauf=None):
        for ln, a, b in L:
            if (near(a, p) and near(b, q)) or (near(a, q) and near(b, p)):
                return ln
        return None

    def voisine(p, sauf):
        for ln, a, b in L:
            if ln is sauf:
                continue
            if near(a, p) or near(b, p):
                return ln
        return None

    libres = []
    travail = []
    for (x0, x1, y0, y1, z0, z1) in c.get('tenons') or []:
        if y1 <= 1e-9 and y0 < -1e-9:                      # champ du dessous : profondeur = -y0
            nom = _param_epaisseur(design, -y0)
            if nom is None:
                continue
            s1, fo, s2 = ligne((x0, 0.0), (x0, y0)), ligne((x0, y0), (x1, y0)), ligne((x1, y0), (x1, 0.0))
            if None in (s1, fo, s2):
                continue
            libres += [(x0, y0), (x1, y0)]
            travail.append((nom, s1, fo, s2, (x0, 0.0), (x1, 0.0)))
        elif x1 <= 1e-9 and x0 < -1e-9:                    # champ du dos : profondeur = -x0
            nom = _param_epaisseur(design, -x0)
            if nom is None:
                continue
            s1, fo, s2 = ligne((0.0, y1), (x0, y1)), ligne((x0, y1), (x0, y0)), ligne((x0, y0), (0.0, y0))
            if None in (s1, fo, s2):
                continue
            libres += [(x0, y0), (x0, y1)]
            travail.append((nom, s1, fo, s2, (0.0, y1), (0.0, y0)))
    if not travail and not libres_haut:
        return
    FL = [F(q[0], q[1]) for q in libres]
    FH = [F(q[0], q[1]) for q in libres_haut]
    differe = DIFFERER_CONTRAINTES
    if differe:
        try:
            if sk.isComputeDeferred:
                differe = False                         # deja differe par l'appelant : il relancera le calcul
            else:
                sk.isComputeDeferred = True
        except Exception:
            differe = False
    try:
        for pt, g, ref in PTS:                             # tout est fixe sauf le fond des tenons lies et le haut
            if ref:
                continue
            # le haut a pu bouger de quelques dixiemes de mm en s'accrochant au dossier : tolerance plus large
            if not any(g.distanceTo(q) < 1e-5 for q in FL) and not any(g.distanceTo(q) < 0.08 for q in FH):
                try:
                    pt.isFixed = True
                except Exception:
                    pass
        cons, dims = sk.geometricConstraints, sk.sketchDimensions
        for q in FL:                                       # extremites distinctes au meme endroit : soudees
            voisins = [pt for pt, g, ref in PTS if g.distanceTo(q) < 1e-5]
            for v in voisins[1:]:
                try:
                    cons.addCoincident(voisins[0], v)
                except Exception:
                    pass
        for (nom, s1, fo, s2, ha, hb) in travail:
            v1, v2 = s1.startSketchPoint.geometry, s1.endSketchPoint.geometry
            tp = adsk.core.Point3D.create((v1.x + v2.x) / 2.0 + 1.0, (v1.y + v2.y) / 2.0 + 1.0, 0.0)
            d = dims.addDistanceDimension(s1.startSketchPoint, s1.endSketchPoint,
                                          adsk.fusion.DimensionOrientations.AlignedDimensionOrientation, tp)
            d.parameter.expression = nom
            n1, n2 = voisine(ha, s1), voisine(hb, s2)
            suite = [(cons.addPerpendicular, fo, s1)]
            if n1 is not None:
                suite.append((cons.addPerpendicular, s1, n1))
            if n2 is not None:
                suite.append((cons.addPerpendicular, s2, n2))
            for fn, a, b in suite:                          # deja satisfaite ou redondante : sans importance
                try:
                    fn(a, b)
                except Exception:
                    pass
    finally:
        if differe:
            try:
                sk.isComputeDeferred = False
            except Exception:
                pass


DIFFERER_CONTOUR = True       # trace du contour sans calcul intermediaire (vitesse)
INTERSECTION_AVANT = False    # True : projection avant le trace differe -> le haut ne suit plus le dossier (mesure 2026-11-09)
DIFFERER_TOUT = False         # True : haut differe aussi -> le haut ne suit plus le dossier (mesure 2026-11-09)
DIFFERER_CONTRAINTES = True   # un seul calcul d'esquisse pour toutes les contraintes des tenons (vitesse)


ARC_ASSOC = False        # coin arrondi accroche au dossier : instable (rotation de l'ellipse libre), desactive pour l'instant


def _arc_ellipse(sk, F, c, pa):
    """Quart d'ellipse du coin (vrai arc elliptique, extremites partagees) du point pa = (W, H-B) au point (W-A, H).
    Renvoie (arc, centre, point haut, ligne centre-pa, ligne centre-haut) ou None."""
    V3 = adsk.core.Vector3D.create
    W, H, A, B = c['W'], c['H'], c['A'], c['B']
    cpt = sk.sketchPoints.add(F(W - A, H - B))
    g0, g1, g2 = cpt.geometry, pa.geometry, F(W - A, H)
    v1 = V3(g1.x - g0.x, g1.y - g0.y, 0.0)
    v2 = V3(g2.x - g0.x, g2.y - g0.y, 0.0)
    major, minor = (v1, v2) if A >= B else (v2, v1)
    arcs = sk.sketchCurves.sketchEllipticalArcs
    attendu = math.pi / 2.0 * math.sqrt((A * A + B * B) / 2.0)
    arc = None
    for deb, fin in ((pa, g2), (g2, pa)):
        a = arcs.addByEndPoints(cpt, major, minor, deb, fin)
        ev = a.geometry.evaluator
        ok, p0, p1 = ev.getParameterExtents()
        ok2, L = ev.getLengthAtParameter(p0, p1)
        if ok and ok2 and L < 1.4 * attendu:
            arc = a
            break
        a.deleteMe()
    if arc is None:
        cpt.deleteMe()
        return None
    q2 = arc.startSketchPoint if arc.startSketchPoint.geometry.distanceTo(g2) < 1e-5 else arc.endSketchPoint
    l1 = sk.sketchCurves.sketchLines.addByTwoPoints(cpt, pa)
    l2 = sk.sketchCurves.sketchLines.addByTwoPoints(cpt, q2)
    l1.isConstruction = True
    l2.isConstruction = True
    return arc, cpt, q2, l1, l2


def _face_dossier(design, comp, c):
    """Face verticale du dossier contre laquelle le montant s'appuie (celle qui contient le point du chemin), la plus haute
    si plusieurs ; None si introuvable. Coordonnees du composant actif."""
    try:
        up = _vers_haut()
        pw = adsk.core.Point3D.create(*c['p'])
        occ = design.activeOccurrence
        if occ is not None:
            inv = occ.transform2.copy()
            inv.invert()
            pw.transformBy(inv)
        best = None
        corps = [comp.bRepBodies.item(i) for i in range(comp.bRepBodies.count)]
        try:                                         # le dossier peut etre dans un composant (occurrence) : proxies
            for o in comp.allOccurrences:
                for i in range(o.bRepBodies.count):
                    corps.append(o.bRepBodies.item(i))
        except Exception:
            pass
        for b in corps:
            if (b.name or '').startswith(_tt('Montant')) or (b.name or '').startswith('Montant'):
                continue
            for f in b.faces:
                g = f.geometry
                if g.surfaceType != adsk.core.SurfaceTypes.PlaneSurfaceType:
                    continue
                n = g.normal
                if abs(n.x * up[0] + n.y * up[1] + n.z * up[2]) > 0.2:
                    continue
                o = g.origin
                dist = abs((pw.x - o.x) * n.x + (pw.y - o.y) * n.y + (pw.z - o.z) * n.z)
                if dist > 2e-3:
                    continue
                bb = f.boundingBox                           # le point du chemin est sur le bord de la face
                if (pw.x < bb.minPoint.x - 1e-3 or pw.x > bb.maxPoint.x + 1e-3 or pw.y < bb.minPoint.y - 1e-3 or
                        pw.y > bb.maxPoint.y + 1e-3 or pw.z < bb.minPoint.z - 1e-3 or pw.z > bb.maxPoint.z + 1e-3):
                    continue
                top = max(v.geometry.x * up[0] + v.geometry.y * up[1] + v.geometry.z * up[2] for v in f.vertices)
                if best is None or top > best[0]:
                    best = (top, f)
        return best[1] if best else None
    except Exception:
        _log('face dossier : ' + traceback.format_exc()[-200:])
        return None


def _lier_haut(sk, c, F, face, extra=None, ents=None):
    """Le haut du montant suit le dossier : on projette l'intersection de la face du dossier dans le plan du montant et le
    coin haut du contour est accroche au sommet de cette ligne. Renvoie les points locaux laisses libres ([] si non
    pris en charge : courbe de coin, face absente...)."""
    courbe = c['A'] > 0 and c['B'] > 0
    if face is None or (courbe and extra is None):
        return []
    # tenons du dos : leurs positions sont des distances au pied du montant ; ils ne suivent pas encore le haut
    try:
        W, H = c['W'], c['H']
        if ents is None:
            ents = sk.intersectWithSketchPlane([face])
        o2, ux2, uy2 = F(0.0, 0.0), F(1.0, 0.0), F(0.0, 1.0)
        ux = (ux2.x - o2.x, ux2.y - o2.y)
        uy = (uy2.x - o2.x, uy2.y - o2.y)
        top = None
        topy = None
        lin = None
        for e in ents or []:
            for pt in (e.startSketchPoint, e.endSketchPoint):
                g = pt.geometry
                lx = (g.x - o2.x) * ux[0] + (g.y - o2.y) * ux[1]
                ly = (g.x - o2.x) * uy[0] + (g.y - o2.y) * uy[1]
                if abs(lx) < 0.05 and 0.0 < ly < H + 100.0 and (topy is None or ly > topy):
                    top, topy, lin = pt, ly, e   # sommet du dossier = point le plus haut de la ligne projetee contre le montant
        if top is None:
            _log('haut : sommet du dossier introuvable (%d courbes projetees)' % len(ents or []))
            return []
        ecart = abs(topy - H)
        if ecart > 0.05:
            _log('haut : le sommet du dossier est a %.2f cm du haut mesure du montant : ecart conserve en cote' % (topy - H))
        lignes = sk.sketchCurves.sketchLines
        SP = []                                               # points et lignes lus une seule fois (vitesse)
        for k in range(sk.sketchPoints.count):
            sp = sk.sketchPoints.item(k)
            if not sp.isReference:
                SP.append((sp, sp.geometry))
        SL = []
        for k in range(lignes.count):
            ln = lignes.item(k)
            if not ln.isReference:
                SL.append((ln, ln.startSketchPoint.geometry, ln.endSketchPoint.geometry))

        def pt_de(q):
            fq = F(q[0], q[1])
            for sp, g in SP:
                if g.distanceTo(fq) < 1e-5:
                    return sp
            return None

        def ligne_a(q, sauf_pts=()):
            fq = F(q[0], q[1])
            for ln, a, b in SL:
                if a.distanceTo(fq) < 1e-5 or b.distanceTo(fq) < 1e-5:
                    yield ln

        A, B = c['A'], c['B']
        cons = sk.geometricConstraints
        ptl, pbr = pt_de((0.0, H)), pt_de((W, 0.0))
        pt_droit = pt_de((W, H - B)) if courbe else pt_de((W, H))      # haut du bord droit
        pt_haut = pt_de((W - A, H)) if courbe else pt_de((W, H))       # fin du bord haut (cote droit)
        if None in (ptl, pbr, pt_droit, pt_haut):
            return []
        droite = haut = None
        bas = list(ligne_a((W, 0.0)))
        for ln in bas:
            a, b = ln.startSketchPoint, ln.endSketchPoint
            autre = b if a.geometry.distanceTo(F(W, 0.0)) < 1e-5 else a
            if autre.geometry.distanceTo(pt_droit.geometry) < 1e-5:
                droite = ln
        for ln in ligne_a((0.0, H)):
            a, b = ln.startSketchPoint, ln.endSketchPoint
            autre = b if a.geometry.distanceTo(F(0.0, H)) < 1e-5 else a
            if autre.geometry.distanceTo(pt_haut.geometry) < 1e-5:
                haut = ln
        base = None
        for ln in bas:
            if droite is not None and ln.entityToken == droite.entityToken:
                continue
            base = ln
        if droite is None or haut is None or base is None:
            _log('haut : lignes du contour introuvables')
            return []
        if ecart <= 0.05:
            cons.addCoincident(ptl, top)
        else:                                                 # le montant s'arrete sous le sommet : il reste sur la ligne, a cote fixe
            cons.addCoincident(ptl, lin)
            g1, g2 = ptl.geometry, top.geometry
            tpd = adsk.core.Point3D.create((g1.x + g2.x) / 2.0 + 0.3, (g1.y + g2.y) / 2.0 + 0.3, 0.0)
            dd0 = sk.sketchDimensions.addDistanceDimension(ptl, top, adsk.fusion.DimensionOrientations.AlignedDimensionOrientation, tpd)
            dd0.parameter.value = ecart
        cons.addPerpendicular(droite, base)
        cons.addParallel(haut, base)
        if not courbe:
            return [(0.0, H), (W, H)]
        if extra is None or extra[0] != 'conique':
            return []
        cn = extra[1]
        K = cn.apexSketchPoint
        cons.addCoincident(K, haut)                           # apex = coin du rectangle (intersection haut / bord droit)
        cons.addCoincident(K, droite)
        dims = sk.sketchDimensions
        for pp, val in ((pt_droit, B), (pt_haut, A)):
            g1, g2 = K.geometry, pp.geometry
            tp = adsk.core.Point3D.create((g1.x + g2.x) / 2.0 + 0.3, (g1.y + g2.y) / 2.0 + 0.3, 0.0)
            dd = dims.addDistanceDimension(K, pp, adsk.fusion.DimensionOrientations.AlignedDimensionOrientation, tp)
            dd.parameter.value = val
        return [(0.0, H), (W, H), (W, H - B), (W - A, H)]
    except Exception:
        _log('haut : ' + traceback.format_exc()[-400:])
        return []


def _corps_param(design, comp, c, nom_ep, chemin=None, face=None):
    """Montant parametrique : esquisse du contour, extrusion symetrique d'epaisseur = parametre CPxx (changer le
    parametre met la piece a jour). Avec `chemin` (entite, rapport le long du chemin) l'esquisse est sur un plan
    lie au chemin : le montant suit le chemin ; sinon contour a l'origine puis deplacement a sa place."""
    P3, V3 = adsk.core.Point3D.create, adsk.core.Vector3D.create
    pts, cour = _profil_montant(c)
    if chemin is not None:
        pi = comp.constructionPlanes.createInput()
        pi.setByDistanceOnPath(chemin[0], adsk.core.ValueInput.createByReal(chemin[1]))
        plan = comp.constructionPlanes.add(pi)
        plan.name = 'Plan montant'
        plan.isLightBulbOn = False
        if len(chemin) > 2 and abs(chemin[2]) > 1e-6:       # decalage d'occurrence ignore par Fusion : plan decale
            po = comp.constructionPlanes.createInput()
            po.setByOffset(plan, adsk.core.ValueInput.createByReal(chemin[2]))
            plan2 = comp.constructionPlanes.add(po)
            plan2.name = 'Plan montant (decale)'
            plan2.isLightBulbOn = False
            plan = plan2
        sk = comp.sketches.add(plan)

        def F(x, y):
            w = _w(c, (x, y, 0.0))
            q = sk.modelToSketchSpace(P3(w[0], w[1], w[2]))
            return P3(q.x, q.y, 0.0)
    else:
        sk = comp.sketches.add(comp.xYConstructionPlane)

        def F(x, y):
            return P3(x, y, 0.0)
    sk.name = 'Montant dossier'
    ents_dos = None
    if INTERSECTION_AVANT and chemin is not None and face is not None:
        try:                                         # projection du dossier AVANT de differer le calcul (associative)
            ents_dos = sk.intersectWithSketchPlane([face])
        except Exception:
            ents_dos = None
            _log('intersection dossier : ' + traceback.format_exc()[-200:])
    _fc = {}
    _F0 = F

    def F(x, y):                                     # conversions memorisees : chacune est un appel a Fusion
        k = (round(x, 7), round(y, 7))
        r = _fc.get(k)
        if r is None:
            r = _fc[k] = _F0(x, y)
        return r
    if DIFFERER_CONTOUR:
        try:
            sk.isComputeDeferred = True              # trace du contour sans calcul a chaque segment
        except Exception:
            pass
    lines = sk.sketchCurves.sketchLines
    n = len(pts)
    A, B, W, H = c['A'], c['B'], c['W'], c['H']
    prec = None                                  # dernier point d'esquisse : les segments se partagent leurs extremites
    premier = None
    extra = None
    for i in range(n):
        a, b = pts[i], pts[(i + 1) % n]
        pa = prec
        coin = cour and abs(a[0] - W) < 1e-6 and abs(a[1] - (H - B)) < 1e-6 and abs(b[0] - (W - A)) < 1e-6 and abs(b[1] - H) < 1e-6
        if coin and chemin is not None and pa is not None and ARC_ASSOC:
            try:
                extra = _arc_ellipse(sk, F, c, pa)
            except Exception:
                extra = None
                _log('arc ellipse : ' + traceback.format_exc()[-300:])
            if extra is not None:
                prec = extra[2]
                continue
        if coin and chemin is not None and face is not None and pa is not None:
            try:                                     # coin = conique (apex = coin du rectangle) : suit le haut du dossier
                fin = F(W - A, H)
                cn = sk.sketchCurves.sketchConicCurves.add(pa, fin, F(W, H), 0.41421356237)
                if cn is not None:
                    extra = ('conique', cn)
                    prec = cn.endSketchPoint
                    continue
            except Exception:
                _log('conique : ' + traceback.format_exc()[-200:])
        if coin:
            col = adsk.core.ObjectCollection.create()
            for q in cour:
                col.add(F(q[0], q[1]))
            sp = sk.sketchCurves.sketchFittedSplines.add(col)
            if pa is not None:
                try:
                    sk.geometricConstraints.addCoincident(sp.startSketchPoint, pa)
                except Exception:
                    _log('courbe : jonction ' + traceback.format_exc()[-120:])
            else:
                premier = sp.startSketchPoint
            prec = sp.endSketchPoint
        else:
            if pa is None:
                ln = lines.addByTwoPoints(F(a[0], a[1]), F(b[0], b[1]))
                premier = ln.startSketchPoint
            elif i == n - 1:
                ln = lines.addByTwoPoints(pa, premier)
            else:
                ln = lines.addByTwoPoints(pa, F(b[0], b[1]))
            prec = ln.endSketchPoint
    if DIFFERER_CONTOUR and not DIFFERER_TOUT:
        try:
            sk.isComputeDeferred = False
        except Exception:
            pass
    libres_haut = []
    try:
        if chemin is not None:
            libres_haut = _lier_haut(sk, c, F, face, extra, ents_dos)
        try:
            _lier_tenons(design, sk, c, F, libres_haut)
        except Exception:
            _log('tenons parametriques erreur ' + traceback.format_exc()[-300:])
    finally:
        try:
            if sk.isComputeDeferred:
                sk.isComputeDeferred = False         # un seul calcul de l'esquisse, contraintes comprises
        except Exception:
            pass
    if sk.profiles.count < 1:
        raise RuntimeError('contour de montant non ferme')
    # TOUS les profils : la ligne projetee du dossier (x = 0) coupe les tenons du dos en profils separes ; avec le
    # seul plus grand profil, ces tenons manquaient (corrige le 2026-11-09)
    prof = adsk.core.ObjectCollection.create()
    for i in range(sk.profiles.count):
        prof.add(sk.profiles.item(i))
    ext = comp.features.extrudeFeatures
    ei = ext.createInput(prof, adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
    ei.setSymmetricExtent(adsk.core.ValueInput.createByString(nom_ep), True)
    f = ext.add(ei)
    corps = f.bodies.item(0)
    if f.bodies.count > 1:                           # morceaux disjoints (ne devrait pas arriver) : le plus gros
        for i in range(f.bodies.count):
            if f.bodies.item(i).volume > corps.volume:
                corps = f.bodies.item(i)
    if chemin is not None:
        return sk, f, None, corps
    # deplacement : repere local (x, y, z = x ^ y) -> position du montant (coordonnees du composant actif)
    ex, ey = c['ex'], c['ey']
    ez = _v_norm(_v_cross(ex, ey))
    ey = _v_norm(_v_cross(ez, ex))
    ex = _v_norm(ex)
    o = P3(*c['o'])
    vx, vy, vz = V3(*ex), V3(*ey), V3(*ez)
    try:
        occ = design.activeOccurrence
        if occ is not None:
            inv = occ.transform2.copy()
            inv.invert()
            o.transformBy(inv)
            for v in (vx, vy, vz):
                v.transformBy(inv)
    except Exception:
        _log('transform erreur ' + traceback.format_exc()[-200:])
    m = adsk.core.Matrix3D.create()
    m.setToAlignCoordinateSystems(P3(0, 0, 0), V3(1, 0, 0), V3(0, 1, 0), V3(0, 0, 1), o, vx, vy, vz)
    col = adsk.core.ObjectCollection.create()
    col.add(corps)
    mi = comp.features.moveFeatures.createInput2(col)
    mi.defineAsFreeMove(m)
    mv = comp.features.moveFeatures.add(mi)
    return sk, f, mv, corps


_cache_lie = {}      # jeton de la courbe du chemin -> (sens inverse ?, ecart a la normale) mesure une fois par creation


def _chemin_lie(design, comp, c):
    """(courbe, rapport) : le plan du montant se pose a ce rapport de la longueur de la courbe du chemin qui passe par le
    point du montant (chemin d'une ou plusieurs courbes) ; None si introuvable (le montant est alors place par un
    deplacement fixe)."""
    try:
        for tok in _s['c']:                           # les entites en cache deviennent perimees apres chaque ajout a la chronologie
            _cache_ent.pop(tok, None)
        ents = _ents(design, _s['c'])
        P3 = adsk.core.Point3D.create
        occ = design.activeOccurrence
        wq = (c['p'][0], c['p'][1], c['p'][2])
        best = None
        for e in ents:
            try:
                tr = _Trajet([e])
                f = tr.frac_point(wq)
                pp, _t = tr.at(f)
                d = _d3(pp, wq)
            except Exception:
                continue
            if best is None or d < best[0]:
                best = (d, e, f)
        if best is None or best[0] > 0.05:
            return None
        e, r = best[1], best[2]
        try:
            cle = e.entityToken
        except Exception:
            cle = None
        mem = _cache_lie.get(cle) if cle else None
        if mem is not None and abs(mem[1]) < 5e-4:         # sens deja mesure et plan sans ecart : on evite 2 plans d'essai
            return (e, (1.0 - r) if mem[0] else r, 0.0)
        cand = None
        for rr in (r, 1.0 - r):                       # le sens du chemin peut etre inverse par rapport a la courbe
            pi = comp.constructionPlanes.createInput()
            pi.setByDistanceOnPath(e, adsk.core.ValueInput.createByReal(rr))
            pl = comp.constructionPlanes.add(pi)
            try:
                g = pl.geometry
                o, n = g.origin, g.normal
                w = P3(wq[0], wq[1], wq[2])
                if occ is not None:
                    inv = occ.transform2.copy()
                    inv.invert()
                    w.transformBy(inv)
                # Fusion ignore parfois le decalage de l'occurrence du chemin : on garde l'ecart le long de la normale
                dn = (w.x - o.x) * n.x + (w.y - o.y) * n.y + (w.z - o.z) * n.z
                # ... et on verifie que le point tombe bien dans le plan apres cette correction (sens du chemin)
                tang = math.sqrt(max(0.0, o.distanceTo(w) ** 2 - dn * dn))
            finally:
                pl.deleteMe()
            if cand is None or abs(dn) < abs(cand[2]) - 1e-9 or (abs(abs(dn) - abs(cand[2])) <= 1e-9 and tang < cand[3]):
                cand = (e, rr, dn, tang)
        if cand is not None and abs(cand[2]) < 5.0 and cand[3] < 5.0:
            if cle:
                _cache_lie[cle] = (abs(cand[1] - r) > 1e-9 and abs(cand[1] - (1.0 - r)) < 1e-9, cand[2])
            if abs(cand[2]) < 5e-4:
                return (cand[0], cand[1], 0.0)
            if abs(cand[2]) > 1e-6:
                _log('chemin lie : decalage %.3f cm le long de la normale, plan corrige' % cand[2])
            return (cand[0], cand[1], cand[2])
    except Exception:
        _log('chemin lie : ' + traceback.format_exc()[-200:])
    return None


def _creer_corps(design, c, ep_cm, blob, idx):
    comp = design.activeComponent
    param = design.designType == adsk.fusion.DesignTypes.ParametricDesignType
    nom_ep = _cur.get('ep_nom')
    if param and nom_ep and design.allParameters.itemByName(nom_ep) is not None and _s.get('param', True):
        try:
            lie = _chemin_lie(design, comp, c)
            face = _face_dossier(design, comp, c) if lie is not None else None
            _log('montant : x=%.2f H=%.2f W=%.2f A=%.2f B=%.2f chemin lie=%s face dossier=%s tenons=%d' % (
                c['x'], c['H'], c['W'], c['A'], c['B'], lie is not None, face is not None, len(c.get('tenons') or [])))
            sk, f, mv, corps = _corps_param(design, comp, c, nom_ep, lie, face)
            corps.name = _nom_libre(comp, _tt('Montant'))
            for obj in (sk, f, mv, corps):
                try:
                    if obj is not None:
                        obj.attributes.add(ATTR_G, ATTR_N, blob)
                except Exception:
                    _log('attribut erreur ' + traceback.format_exc()[-200:])
            return corps, f
        except Exception:
            _log('montant parametrique erreur ' + traceback.format_exc()[-500:])
            raise
    tmp = _corps_temporaire(c, ep_cm)
    if param:
        bf = comp.features.baseFeatures.add()
        bf.startEdit()
        try:
            corps = comp.bRepBodies.add(tmp, bf)
            corps.name = _nom_libre(comp, _tt('Montant'))       # nom donne DANS la fonction de base (sinon perdu)
        finally:
            bf.finishEdit()
    else:
        bf = None
        corps = comp.bRepBodies.add(tmp)
        corps.name = _nom_libre(comp, _tt('Montant'))
    for obj in (bf, corps):
        try:
            if obj is not None:
                obj.attributes.add(ATTR_G, ATTR_N, blob)
        except Exception:
            _log('attribut erreur ' + traceback.format_exc()[-200:])
    return corps, bf


def _creer_direct(design, a_faire, ep_cm, blob):
    """Mode sans esquisse : un corps par montant, tous poses dans une seule fonction de base."""
    comp = design.activeComponent
    tmps = [_corps_temporaire(ci, ep_cm) for ci in a_faire]
    pris = set(comp.bRepBodies.item(i).name for i in range(comp.bRepBodies.count))
    base = _tt('Montant')
    noms = []
    k = 1
    while len(noms) < len(tmps):                    # noms calcules d'avance (la fonction de base ne voit pas ses corps)
        if '%s %d' % (base, k) not in pris:
            noms.append('%s %d' % (base, k))
        k += 1
    if design.designType == adsk.fusion.DesignTypes.ParametricDesignType:
        bf = comp.features.baseFeatures.add()
        bf.startEdit()
        try:
            for t, nom in zip(tmps, noms):
                corps = comp.bRepBodies.add(t, bf)
                corps.name = nom                             # nom donne DANS la fonction de base
        finally:
            bf.finishEdit()
        objs = [bf] + [bf.bodies.item(i) for i in range(bf.bodies.count)]
    else:
        objs = []
        for t, nom in zip(tmps, noms):
            corps = comp.bRepBodies.add(t)
            corps.name = nom
            objs.append(corps)
    for obj in objs:
        try:
            obj.attributes.add(ATTR_G, ATTR_N, blob)
        except Exception:
            _log('attribut erreur ' + traceback.format_exc()[-200:])
    return len(tmps)


def _rafraichir_modele(design):
    """Une occurrence deplacee a la main sans position capturee revient a sa place des qu'une operation entre dans la
    chronologie : on provoque ce recalcul (plan temporaire cree puis supprime) AVANT de mesurer, pour mesurer le modele
    tel qu'il restera."""
    try:
        comp = design.activeComponent
        pi = comp.constructionPlanes.createInput()
        pi.setByOffset(comp.xYConstructionPlane, adsk.core.ValueInput.createByReal(0.0))
        pl = comp.constructionPlanes.add(pi)
        pl.deleteMe()
    except Exception:
        _log('rafraichir : ' + traceback.format_exc()[-150:])
    _cache_ent.clear()
    _cache_traj.clear()
    _cache_lie.clear()
    try:
        _cache_faces.clear()
    except Exception:
        pass
    try:
        _prof_inv()
    except Exception:
        pass


def _creer_tout(design, ep, blob):
    """Un corps par montant (mesures exactes), puis un repere (2e entree : le groupe de l'historique)."""
    _rafraichir_modele(design)
    c = _calc(design, _s, ep, exact=True)
    a_faire = [i for i in c['inst'] if i['ok']]
    param = design.designType == adsk.fusion.DesignTypes.ParametricDesignType
    centres = []
    if not _s.get('param', True):
        # sans esquisse : tous les montants dans UNE fonction de base (geometrie directe, tres rapide) ; le bouton
        # « Mettre a jour le dossier CNC » les recree avec les reglages memorises
        _creer_direct(design, a_faire, ep, blob)
        centres = [ci['centre'] for ci in a_faire]
        a_faire = []
    for k, ci in enumerate(a_faire):
        _creer_corps(design, ci, ep, blob, k)
        centres.append(ci['centre'])
    if param and centres:
        try:
            comp = design.activeComponent
            sk = comp.sketches.add(comp.xYConstructionPlane)
            sk.name = 'Repere ' + GROUPE_NOM
            q = sk.modelToSketchSpace(adsk.core.Point3D.create(*centres[0]))
            sk.sketchPoints.add(adsk.core.Point3D.create(q.x, q.y, 0.0))
            sk.isLightBulbOn = False
            sk.attributes.add(ATTR_G, ATTR_N, blob)
        except Exception:
            _log('repere erreur ' + traceback.format_exc()[-300:])
    return len(centres)


def _grouper(tl, debut, fin=None):
    """Une utilisation = un groupe replie (fin == debut : on renomme l'entree)."""
    try:
        if fin is None:
            fin = tl.markerPosition - 1
        if fin > debut:
            grp = tl.timelineGroups.add(debut, fin)
            grp.name = GROUPE_NOM
            grp.isCollapsed = True
            return True
        elif fin == debut:
            tl.item(debut).name = GROUPE_NOM
            return True
    except Exception:
        _log('groupement erreur ' + traceback.format_exc()[-300:])
    return False


# --- Evenements de la commande --------------------------------------------------------------------------

CHAMPS_AUTO = {'hauteur': 'hauteur_auto', 'largeur': 'largeur_auto', 'ten_h': 'ten_h_auto'}   # mesure -> case du mode automatique (saisie « A »)


def _saisie_auto(inp):
    """« A » (ou « a ») tape dans un champ de mesure qui a un mode automatique : le mode automatique est
    choisi (Maxence 2026-11-17). Le champ quitte le « A » et reprend sa valeur."""
    try:
        if str(inp.expression or '').strip().lower() not in ('a', 'auto'):
            return False
        inp.value = inp.value
        return True
    except Exception:
        return False


class _InputChangedHandler(adsk.core.InputChangedEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            inp = args.input
            ins = inp.parentCommand.commandInputs
            iid = inp.id
            if _en_cours['v']:
                return
            if iid in CHAMPS_AUTO and _saisie_auto(inp):
                # « A » dans la mesure : sa case automatique est cochee, traite comme un clic sur la case
                _en_cours['v'] = True
                try:
                    inp = ins.itemById(CHAMPS_AUTO[iid])
                    inp.value = True
                finally:
                    _en_cours['v'] = False
                iid = inp.id
            if iid in SEL_IDS and _restaurer_selection(ins, iid):
                return
            if iid == 'chemin':
                _en_cours['v'] = True
                try:
                    _lire_selection(ins)
                    _sync_champs(ins)
                    _rafraichir(ins, True)
                finally:
                    _en_cours['v'] = False
                return
            ok = True
            if iid == 'mode_crea':
                _s['param'] = (inp.selectedItem.index == 0) if inp.selectedItem else True
            elif iid == 'nb':
                _s['n'] = max(1, min(NB_MAX, int(inp.value)))
            elif iid == 'm1':
                _s['m1'] = max(0.0, inp.value * 10.0)
                if _s['sym']:
                    _s['m2'] = _s['m1']
            elif iid == 'm2':
                _s['m2'] = max(0.0, inp.value * 10.0)
                if _s['sym']:
                    _s['m1'] = _s['m2']
            elif iid == 'sym':
                _s['sym'] = bool(inp.value)
                if _s['sym']:
                    _s['m2'] = _s['m1']
            elif iid == 'cote':
                _s['cote'] = bool(inp.value)
                _prof_inv()
            elif iid == 'hauteur_auto':
                _s['h_auto'] = bool(inp.value)
            elif iid == 'hauteur':
                _s['h_mm'] = max(1.0, inp.value * 10.0)
                _s['h_auto'] = False
            elif iid == 'largeur_auto':
                _s['l_auto'] = bool(inp.value)
            elif iid == 'largeur':
                _s['l_mm'] = max(1.0, inp.value * 10.0)
                _s['l_auto'] = False
            elif iid == 'retrait':
                _s['retrait'] = max(0.0, inp.value * 10.0)
            elif iid == 'decal':
                _s['decal'] = inp.value * 10.0
                _prof_inv()
            elif iid == 'cv_mode':
                _s['cv_mode'] = CV_MODES[inp.selectedItem.index if inp.selectedItem else 0]
            elif iid == 'cv_w':
                _s['cv_w'] = max(1.0, min(100.0, inp.value))
            elif iid == 'cv_h':
                _s['cv_h'] = max(1.0, min(100.0, inp.value))
            elif iid == 'cv_a':
                _s['cv_a'] = max(1.0, inp.value * 10.0)
            elif iid == 'cv_b':
                _s['cv_b'] = max(1.0, inp.value * 10.0)
            elif iid in ('ten_on', 'ten_dos', 'ten_bas', 'ten_auto', 'ten_h_auto'):
                _s[iid] = bool(inp.value)
                _prof_inv()
            elif iid in ('ten_n_dos', 'ten_n_bas'):
                _s[iid] = max(1, min(12, int(inp.value)))
            elif iid == 'ten_len':
                _s['ten_len'] = max(5.0, inp.value * 10.0)
            elif iid == 'ten_edge':
                _s['ten_edge'] = max(0.0, inp.value * 10.0)
            elif iid == 'ten_h':
                _s['ten_h'] = max(1.0, inp.value * 10.0)
                _s['ten_h_auto'] = False
            elif iid in ('ep_dd', 'ep_autre'):
                dd = ins.itemById('ep_dd')
                ins.itemById('ep_autre').isVisible = (dd.selectedItem.index == dd.listItems.count - 1)
            else:
                ok = False
            if ok:
                _appliquer(lambda: _sync_champs(ins), ins, True)
        except Exception:
            _log('inputChanged erreur ' + traceback.format_exc()[-600:])


class _PreviewHandler(adsk.core.CommandEventHandler):
    """executePreview : Fusion annule, a chaque changement, ce qui a ete cree pendant l'evenement precedent
    (y compris nos groupes graphiques) : fenetre, apercu et pastilles sont recrees s'ils ont disparu."""
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            if _cur['calc'] is not None:
                if not (_drag['k'] is not None and _ov['g'] is not None and _ov['g'].isValid):
                    _ov_maj()
                _apercu_maj(_tous_calculs())
                _maj_pastilles()
        except Exception:
            _log('preview erreur ' + traceback.format_exc()[-300:])


class _ValidateHandler(adsk.core.ValidateInputsEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            cs = _cur.get('calcs') or ([_cur['calc']] if _cur['calc'] else [])
            args.areInputsValid = bool(cs) and all(c and c['ok'] for c in cs)
        except Exception:
            args.areInputsValid = False


def _renommer_doublons(design, base):
    """Apres remplacement d'un groupe, Fusion a pu nommer les nouveaux corps « <base> n (1) » (les anciens existaient
    encore) : on leur rend leur nom simple quand il est libre."""
    import re as _re
    try:
        comp = design.activeComponent
        corps = [comp.bRepBodies.item(i) for i in range(comp.bRepBodies.count)]
        noms = set(b.name for b in corps)
        motif = _re.compile(r'^(' + _re.escape(base) + r' \d+) \(\d+\)$')
        for b in corps:
            m = motif.match(b.name or '')
            if m and m.group(1) not in noms:
                noms.discard(b.name)
                b.name = m.group(1)
                noms.add(b.name)
    except Exception:
        _log('renommer : ' + traceback.format_exc()[-200:])


def _supprimer_anciens_groupe(design, tokens):
    """Modification : l'ancien groupe est supprime avec tout son contenu (esquisses, plans, extrusions, decoupes) ;
    a defaut, entree par entree."""
    try:
        r = design.findEntityByToken(tokens[0]) if tokens else None
        g = r[0].timelineObject.parentGroup if r else None
        if g is not None:
            g.deleteMe(True)
            return True
    except Exception:
        _log('suppression ancien groupe : ' + traceback.format_exc()[-200:])
    return _supprimer_anciens(design, tokens)


def _basculer_jeu(jeu):
    global _s
    _s = jeu


class _ExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        ins = args.command.commandInputs
        _apercu_effacer()
        _ov_effacer()
        try:
            design = _design()
            ep = _ep_cm(ins)
            try:
                _cur['ep_nom'] = _ep_parametre(design, ins, ep)
            except Exception:
                _log('parametre epaisseur erreur ' + traceback.format_exc()[-300:])
            tl = None
            debut = 0
            try:
                tl = design.timeline
                debut = tl.markerPosition
            except Exception:
                pass
            ed = _edition['v']
            edite = ed is not None
            n = 0
            for jeu in (list(_jeux) or [_s]):
                _basculer_jeu(jeu)
                ok_suppr = True
                if ed is not None and tl is not None:
                    # modification : seul le premier jeu remplace l'ancien groupe, supprime AVANT la creation (sinon les
                    # nouveaux corps naissent « Montant 1 (1) » et reprennent ce nom a chaque recalcul)
                    try:
                        _rafraichir_modele(design)
                        if any(i['ok'] for i in _calc(design, _s, ep, exact=True)['inst']):
                            _edition['v'] = None
                            ok_suppr = _supprimer_anciens_groupe(design, ed['anciens'])
                        else:
                            ed = None
                    except Exception:
                        _log('suppression avant creation : ' + traceback.format_exc()[-200:])
                debut = tl.markerPosition if tl is not None else 0
                nj = _creer_tout(design, ep, _blob(ep))
                n += nj
                if tl is None or not nj:
                    continue
                fin = tl.markerPosition - 1
                if not _grouper(tl, debut, fin):
                    _groupage_apres.update(debut=debut, fin=fin, ed=ed is not None)    # refait apres la commande
                if ed is not None:
                    tl.moveToEnd()
                    if not ok_suppr:
                        _ui.messageBox("Les anciens montants n'ont pas pu etre supprimes : d'autres fonctions de la "
                                       "chronologie utilisent leurs corps. Les nouveaux sont crees ; supprimez les "
                                       "anciens a la main.", COMMAND_NAME)
                    ed = None
            if tl is not None and n and edite:
                try:
                    tl.moveToEnd()
                except Exception:
                    pass
                _renommer_doublons(design, _tt('Montant'))       # chronologie complete : tous les noms visibles
            if n == 0:
                args.executeFailed = True
                args.executeFailedMessage = _tt('Aucun montant valide.')
            else:
                sp = {k: _s[k] for k in DEFAULT_PREFS if k in _s}
                sp['epaisseur_mm'] = round(ep * 10.0, 3)
                save_prefs(sp)
        except Exception as e:
            _log('execute erreur ' + traceback.format_exc()[-600:])
            args.executeFailed = True
            args.executeFailedMessage = 'Montants impossibles : ' + str(e).splitlines()[-1][:300]


_groupage_apres = {}


class _DestroyHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        _redraw['on'] = False
        _apercu_effacer()          # toujours effacer overlay et apercus a la fermeture
        _ov_effacer()
        _drag['k'] = None
        _drag['maison'] = False
        _drag['pris'] = False
        _bar['on'] = False
        _qd['on'] = False
        _qd.pop('tr', None)
        _pastilles_effacer()
        _camera_suivre(False)
        _bloc['sel'] = None
        _cache_traj.clear()
        _cache_ent.clear()
        _cache_faces.clear()
        _prof_inv()
        _jeux.clear()
        _cur['calcs'] = []
        _rafraichir_vue()
        if _groupage_apres:
            # le groupement a echoue pendant la validation : refait juste apres la fin de la commande
            _differer_groupage()
        if _edition['v'] is not None:
            # modification annulee (ou echouee) : retour a la fin de la chronologie, rien n'a change
            _edition['v'] = None
            try:
                _design().timeline.moveToEnd()
            except Exception:
                pass


GROUPAGE_ID = 'MontantsDossierCNC_groupage'
_groupage = {'evt': None, 'h': None}


class _GroupageHandler(adsk.core.CustomEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            if not _groupage_apres:
                return
            d = dict(_groupage_apres)
            _groupage_apres.clear()
            tl = _design().timeline
            _grouper(tl, d['debut'], d['fin'])
            if d.get('ed'):
                tl.moveToEnd()
        except Exception:
            _log('groupage apres erreur ' + traceback.format_exc()[-300:])


def _differer_groupage():
    try:
        if _groupage['evt'] is None:
            try:
                _app.unregisterCustomEvent(GROUPAGE_ID)
            except Exception:
                pass
            _groupage['evt'] = _app.registerCustomEvent(GROUPAGE_ID)
            _groupage['h'] = _GroupageHandler()
            _groupage['evt'].add(_groupage['h'])
        if not _app.fireCustomEvent(GROUPAGE_ID, ''):
            _groupage['evt'] = None
            raise RuntimeError('evenement non livre')
    except Exception:
        _log('differer groupage : ' + traceback.format_exc()[-200:])


class _CreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        global _s
        try:
            cmd = args.command
            p = load_prefs()
            _jeux.clear()
            _act['i'] = 0
            _s = _nouveau(p)
            _cur.update(calc=None, calcs=[], ep=p['epaisseur_mm'] / 10.0)
            _cache_traj.clear()
            _cache_ent.clear()
            _cache_faces.clear()
            _prof_inv()
            _bloc['sel'] = None
            _ov_effacer()
            _apercu_effacer()
            ins = cmd.commandInputs
            ins.addTextBoxCommandInput('msg', '', '', 2, True)
            s = ins.addSelectionInput('chemin', 'Chemin', 'Base du dossier : arete ou courbe d\'esquisse, sur la dalle a plat')
            s.addSelectionFilter('Edges')
            s.addSelectionFilter('SketchCurves')
            s.setSelectionLimits(0, 0)          # plusieurs chemins : une fenetre MONTANTS et un jeu de montants chacun
            dmc = ins.addDropDownCommandInput('mode_crea', 'Mode de creation', adsk.core.DropDownStyles.TextListDropDownStyle)
            dmc.listItems.add('Avec esquisse (parametrique)', bool(_s.get('param', True)), '')
            dmc.listItems.add('Sans esquisse (rapide)', not _s.get('param', True), '')
            dmc.tooltip = ('Avec esquisse : les pieces suivent le dossier et le parametre CP. Sans esquisse : creation tres '
                           'rapide, le bouton Mettre a jour le dossier CNC les recree.')
            gm = ins.addGroupCommandInput('grp_mont', 'Montants')
            gm.isExpanded = True
            gc = gm.children
            gc.addIntegerSpinnerCommandInput('nb', 'Nombre de montants', 1, NB_MAX, 1, int(_s['n']))
            gc.addValueInput('m1', 'Marge au debut', 'mm', adsk.core.ValueInput.createByReal(_s['m1'] / 10.0))
            gc.addValueInput('m2', 'Marge a la fin', 'mm', adsk.core.ValueInput.createByReal(_s['m2'] / 10.0))
            gc.addBoolValueInput('sym', 'Symetrie (memes marges)', True, '', bool(_s['sym']))
            gc.addBoolValueInput('cote', 'Inverser le cote', True, '', False)
            gd = ins.addGroupCommandInput('grp_dim', 'Dimensions')
            gd.isExpanded = True
            gdc = gd.children
            dd = gdc.addDropDownCommandInput('ep_dd', 'Epaisseur', adsk.core.DropDownStyles.TextListDropDownStyle)
            ok_cp = _ep_remplir(dd, _design(), p['epaisseur_mm'] / 10.0)
            ae = gdc.addValueInput('ep_autre', 'Epaisseur libre', 'mm', adsk.core.ValueInput.createByReal(p['epaisseur_mm'] / 10.0))
            ae.isVisible = not ok_cp
            gdc.addBoolValueInput('hauteur_auto', 'Hauteur detectee (dossier)', True, '', bool(_s['h_auto']))
            gdc.addValueInput('hauteur', 'Hauteur', 'mm', adsk.core.ValueInput.createByReal(_s['h_mm'] / 10.0))
            gdc.addBoolValueInput('largeur_auto', 'Largeur detectee (dalle)', True, '', bool(_s['l_auto']))
            gdc.addValueInput('largeur', 'Largeur', 'mm', adsk.core.ValueInput.createByReal(_s['l_mm'] / 10.0))
            gdc.addValueInput('retrait', 'Retrait au bord de la dalle', 'mm', adsk.core.ValueInput.createByReal(_s['retrait'] / 10.0))
            gdc.addValueInput('decal', 'Decalage depuis le chemin', 'mm', adsk.core.ValueInput.createByReal(_s['decal'] / 10.0))
            gv = ins.addGroupCommandInput('grp_cv', 'Courbe exterieure du haut')
            gv.isExpanded = False
            gvc = gv.children
            dd = gvc.addDropDownCommandInput('cv_mode', 'Courbe', adsk.core.DropDownStyles.TextListDropDownStyle)
            for m, nom in zip(CV_MODES, ('Aucune', 'Automatique', 'Manuelle')):
                dd.listItems.add(nom, m == _s['cv_mode'], '')
            gvc.addValueInput('cv_w', 'Largeur de la courbe (% de la largeur)', '', adsk.core.ValueInput.createByReal(_s['cv_w']))
            gvc.addValueInput('cv_h', 'Hauteur de la courbe (% de la hauteur)', '', adsk.core.ValueInput.createByReal(_s['cv_h']))
            gvc.addValueInput('cv_a', 'Largeur de la courbe', 'mm', adsk.core.ValueInput.createByReal(_s['cv_a'] / 10.0))
            gvc.addValueInput('cv_b', 'Hauteur de la courbe', 'mm', adsk.core.ValueInput.createByReal(_s['cv_b'] / 10.0))
            gt = ins.addGroupCommandInput('grp_ten', 'Tenons sur les champs plats')
            gt.isExpanded = True
            gtc = gt.children
            gtc.addBoolValueInput('ten_on', 'Tenons', True, '', bool(_s['ten_on']))
            gtc.addBoolValueInput('ten_dos', 'Champ du dos (contre le dossier)', True, '', bool(_s['ten_dos']))
            gtc.addBoolValueInput('ten_bas', 'Champ du dessous (dans la dalle)', True, '', bool(_s['ten_bas']))
            gtc.addBoolValueInput('ten_auto', 'Nombre automatique (2 sur un grand champ, 1 sur un petit)', True, '', bool(_s['ten_auto']))
            gtc.addIntegerSpinnerCommandInput('ten_n_dos', 'Tenons sur le champ du dos', 1, 12, 1, int(_s['ten_n_dos']))
            gtc.addIntegerSpinnerCommandInput('ten_n_bas', 'Tenons sur le champ du dessous', 1, 12, 1, int(_s['ten_n_bas']))
            gtc.addValueInput('ten_len', 'Longueur des tenons', 'mm', adsk.core.ValueInput.createByReal(_s['ten_len'] / 10.0))
            gtc.addValueInput('ten_edge', 'Decalage du bord', 'mm', adsk.core.ValueInput.createByReal(_s['ten_edge'] / 10.0))
            gtc.addBoolValueInput('ten_h_auto', 'Hauteur detectee (epaisseur des CP)', True, '', bool(_s['ten_h_auto']))
            gtc.addValueInput('ten_h', 'Hauteur des tenons', 'mm', adsk.core.ValueInput.createByReal(_s['ten_h'] / 10.0))
            for ev, h in ((cmd.inputChanged, _InputChangedHandler()),
                          (cmd.validateInputs, _ValidateHandler()),
                          (cmd.executePreview, _PreviewHandler()),
                          (cmd.execute, _ExecuteHandler()),
                          (cmd.destroy, _DestroyHandler()),
                          (cmd.mouseDown, _MouseDownHandler()),
                          (cmd.preSelect, _PreSelectHandler()),
                          (cmd.mouseUp, _MouseUpHandler()),
                          (cmd.mouseDrag, _MouseHandler('mouseDrag')),
                          (cmd.mouseMove, _MouseHandler('mouseMove'))):
                ev.add(h)
                _handlers.append(h)
            _redraw['evt'] = None            # evenements (re)enregistres depuis cette commande : ils survivent
            _redraw['on'] = True
            ed = _edition['v']
            if ed is not None:
                b = ed['blob']
                _s.update({k: v for k, v in (b.get('s') or {}).items() if k in CLES})
                if _s.get('c'):
                    _jeux[:] = [_s]
                try:
                    _ep_choisir_nom(ins, float(b['ep']), b.get('ep_nom'))
                except Exception:
                    _log('epaisseur edition erreur ' + traceback.format_exc()[-200:])

                def f():
                    _charger_selection(ins)
                    _sync_champs(ins)
                _appliquer(f, ins, True)
            else:
                _appliquer(lambda: _sync_champs(ins), ins, True)
            ins.itemById('chemin').hasFocus = not ed
        except Exception:
            _log('cree erreur ' + traceback.format_exc()[-800:])
            _ui.messageBox('Erreur Montants de dossier CNC:\n' + traceback.format_exc(), COMMAND_NAME)


# --- Modification depuis l'historique de CNC Toolkit (cnc_historique.modifier) --------------------------------

def edit_group(g):
    """Appele par cnc_historique : recule la chronologie au debut du groupe « Montants dossier CNC » et rouvre la
    fenetre avec ses reglages ; a la validation les nouveaux montants remplacent les anciens. (ok, message)."""
    try:
        design = _design()
        if design is None or design.designType != adsk.fusion.DesignTypes.ParametricDesignType:
            return False, 'Conception parametrique (historique) requise.'
        ents = [g.item(i).entity for i in range(g.count)]
        blob = None
        for e in ents:
            try:
                a = e.attributes.itemByName(ATTR_G, ATTR_N)
                if a is not None:
                    blob = json.loads(a.value)
                    break
            except Exception:
                continue
        if blob is None:
            return False, 'Montants crees avant la version modifiable : pas de reglages memorises.'
        tl = design.timeline
        idx = None
        for lire in (lambda: g.index, lambda: g.item(0).index):
            try:
                idx = lire()
                break
            except Exception:
                continue
        if idx is None:
            return False, 'Position du groupe introuvable.'
        _edition['v'] = {'blob': blob, 'anciens': [e.entityToken for e in ents]}
        try:
            _ui.activeSelections.clear()
        except Exception:
            pass
        tl.markerPosition = idx
        _differer()
        return True, None
    except Exception as e:
        _edition['v'] = None
        _log('edit_group erreur ' + traceback.format_exc()[-400:])
        return False, str(e)[:200]


# --- Mise a jour sans fenetre (bouton « Mettre a jour le dossier » de Traverses de dossier CNC) -----------------

def _blob_groupe(g):
    for i in range(g.count):
        try:
            a = g.item(i).entity.attributes.itemByName(ATTR_G, ATTR_N)
            if a is not None:
                return json.loads(a.value)
        except Exception:
            continue
    return None


def _supprimer_groupe(design, g, tokens):
    """Supprime l'ancien groupe avec tout son contenu (esquisses, plans, extrusions) ; a defaut, entree par entree."""
    try:
        g.deleteMe(True)
        return True
    except Exception:
        _log('suppression groupe : ' + traceback.format_exc()[-200:])
    return _supprimer_anciens(design, tokens)


def maj_groupe_montants(g):
    """Remesure (hauteur, largeur, tenons, epaisseur du parametre CPxx) et recree un jeu de montants avec ses reglages
    memorises, sans fenetre. Renvoie (ok, message)."""
    try:
        design = _design()
        blob = _blob_groupe(g)
        if blob is None:
            return False, 'pas de reglages memorises'
        tl = design.timeline
        idx = None
        for lire in (lambda: g.index, lambda: g.item(0).index):
            try:
                idx = lire()
                break
            except Exception:
                continue
        if idx is None:
            return False, 'position du groupe introuvable'
        anciens = [g.item(i).entity.entityToken for i in range(g.count)]
        _cache_traj.clear()
        _cache_ent.clear()
        _cache_faces.clear()
        _prof_inv()
        _s.clear()
        _s.update(_nouveau())
        _s.update({k: v for k, v in (blob.get('s') or {}).items() if k in CLES})
        ep = float(blob.get('ep', 1.8))
        nom = blob.get('ep_nom')
        pr = design.allParameters.itemByName(nom) if nom else None
        if pr is not None:
            ep = pr.value
        else:
            nom = None
        _cur['ep'] = ep
        _cur['ep_nom'] = nom
        tl.markerPosition = idx
        _rafraichir_modele(design)
        if not any(i['ok'] for i in _calc(design, _s, ep, exact=True)['inst']):
            tl.moveToEnd()
            return False, 'aucun montant valide'
        # l'ancien groupe est supprime AVANT la creation : sinon les nouveaux corps naissent « Montant 1 (1) » et
        # reprennent ce nom a chaque recalcul de la chronologie
        ok = _supprimer_groupe(design, g, anciens)
        debut = tl.markerPosition
        n = _creer_tout(design, ep, _blob(ep))
        if not n:
            tl.moveToEnd()
            return False, 'aucun montant valide (anciens montants supprimes)'
        fin = tl.markerPosition - 1
        if not _grouper(tl, debut, fin):
            _groupage_apres.update(debut=debut, fin=fin, ed=True)
        tl.moveToEnd()
        _renommer_doublons(design, _tt('Montant'))       # chronologie complete : tous les noms visibles
        return ok, None if ok else 'anciens montants non supprimes'
    except Exception as e:
        _log('maj groupe erreur ' + traceback.format_exc()[-500:])
        try:
            _design().timeline.moveToEnd()
        except Exception:
            pass
        return False, str(e)[:200]


def _ancre_groupe(g):
    """Jeton d'une entite du groupe : il reste valable quand d'autres groupes sont recrees (l'ordre de
    timelineGroups, lui, change a chaque recreation : un groupe recree passe en fin de collection)."""
    for i in range(g.count):
        try:
            a = g.item(i).entity.attributes.itemByName(ATTR_G, ATTR_N)
            if a is not None:
                return g.item(i).entity.entityToken
        except Exception:
            continue
    return None


def groupe_par_ancre(design, tok):
    try:
        r = design.findEntityByToken(tok)
        return r[0].timelineObject.parentGroup if r else None
    except Exception:
        return None


def maj_tous_montants():
    """Met a jour tous les jeux de montants du document. Renvoie (nombre mis a jour, messages d'erreur)."""
    design = _design()
    tgs = design.timeline.timelineGroups
    cibles = []
    for i in range(tgs.count):
        g = tgs.item(i)
        if _blob_groupe(g) is not None and (g.name or '').startswith(GROUPE_NOM):
            cibles.append((_ancre_groupe(g), g.name))
    nb, err = 0, []
    for tok, nom in cibles:                       # chaque groupe retrouve par son ancre, pas par son rang
        g = groupe_par_ancre(design, tok) if tok else None
        if g is None:
            err.append('%s : groupe introuvable' % nom)
            continue
        ok, msg = maj_groupe_montants(g)
        if ok:
            nb += 1
        else:
            err.append('%s : %s' % (nom, msg))
    return nb, err


def run(context):
    global _app, _ui
    try:
        _app = adsk.core.Application.get()
        _ui = _app.userInterface
        old = _ui.commandDefinitions.itemById(CMD_ID)
        if old:
            old.deleteMe()
        res = os.path.join(_ADDIN_DIR, 'resources')
        cmd_def = _ui.commandDefinitions.addButtonDefinition(CMD_ID, COMMAND_NAME, COMMAND_DESC,
                                                             res if os.path.isdir(res) else '')
        on_created = _CreatedHandler()
        cmd_def.commandCreated.add(on_created)
        _handlers.append(on_created)
        panel = _ui.allToolbarPanels.itemById(PANEL_ID)
        if panel and not panel.controls.itemById(CMD_ID):
            panel.controls.addCommand(cmd_def)
        # evenements personnalises : enregistres a l'ouverture de la commande (voir _redessiner_differe / _differer)
    except Exception:
        if _ui:
            _ui.messageBox('Erreur au demarrage de Montants de dossier CNC:\n' + traceback.format_exc())


def stop(context):
    _dv_arreter()
    try:
        for ev in (ACTION_ID, REDRAW_ID, GROUPAGE_ID):
            try:
                _app.unregisterCustomEvent(ev)
            except Exception:
                pass
        _action['evt'] = None
        _redraw['evt'] = None
        _groupage['evt'] = None
        _redraw['on'] = False
        _apercu_effacer()
        _ov_effacer()
        _pastilles_effacer()
        panel = _ui.allToolbarPanels.itemById(PANEL_ID)
        if panel:
            c = panel.controls.itemById(CMD_ID)
            if c:
                c.deleteMe()
        cd = _ui.commandDefinitions.itemById(CMD_ID)
        if cd:
            cd.deleteMe()
    except Exception:
        pass
    _handlers.clear()
