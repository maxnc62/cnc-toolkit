import adsk.core
import adsk.fusion
import traceback
import os
import json
import math
import sys
import time
import uuid

# Barre de chargement commune du Toolkit (ToolkitCNC/cnc_progress.py)
_TK_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _TK_DIR not in sys.path:
    sys.path.append(_TK_DIR)
import cnc_progress

# ---------------------------------------------------------------------------
# Dogbone CNC : ajoute des dogbones dans les coins interieurs des entailles,
# mortaises et tenons de la suite CNC Toolkit (voir conception_dogbone.md).
#
# PRINCIPE
#   - Axe d'usinage d'un corps = axe d'epaisseur du panneau (deux plus
#     grandes faces planes opposees, meme calcul qu'Entaille CNC/Marge CNC).
#   - Coin a traiter = arete DROITE, PARALLELE a cet axe, entre deux faces
#     PLANES elles-memes paralleles a l'axe, et RENTRANTE (test par sondage
#     de point : milieu + eps*(n1 - n2) est dans la matiere pour un coin
#     rentrant, hors matiere pour un coin saillant, quel que soit l'angle).
#   - Filtre "coupes CNC" (par defaut) : au moins une des deux faces du coin
#     appartient a une fonction Entaille/Mortaise/Tenon/Marge CNC (groupe
#     d'historique, nom ou attributs), via feature.faces (faces ACTUELLES,
#     aucun entityToken stocke - lecon MargeCNC).
#   - Dogbone classique : cylindre de rayon r = fraise/2 + jeu, centre sur
#     la bissectrice du coin, a la distance r du coin cote vide : le cercle
#     passe exactement par le coin et mord dans les deux parois.
#   - Un coin deja traite touche une face cylindrique : il n'est plus
#     detecte, relancer l'outil ne cree pas de doublon.
#
# CREATION (lecons TenonCNC/EntailleCNC)
#   - Cylindres construits en memoire (TemporaryBRepManager), fusionnes en
#     UN corps outil par corps cible, inseres dans une BaseFeature par corps
#     (pour pouvoir retirer les dogbones d'un seul corps proprement).
#   - UN SEUL design.computeAll() pour tout le lot, puis relecture des
#     corps via base_feat.bodies (jamais la reference retournee par add()).
#   - Une Combiner en Couper par corps, taguee 'DogboneCNC'. Le tout dans un
#     groupe d'historique "Dogbone CNC".
#   - Aucun JSON partage n'est lu ni ecrit. Seules les preferences du
#     panneau vont dans dogbone_prefs.json (ce dossier).
# ---------------------------------------------------------------------------

_app = None
_ui = None
_handlers = []

CMD_ID       = 'DogboneCNCCmd'
COMMAND_NAME = 'Dogbone CNC'
COMMAND_DESC = ('Ajoute des dogbones dans les coins interieurs des entailles, '
                'mortaises et tenons CNC des corps selectionnes')

ATTR_GROUP = 'DogboneCNC'
GROUP_NAME = 'Dogbone CNC'
FEAT_NAME  = 'Dogbone'

_ADDIN_DIR = os.path.dirname(os.path.abspath(__file__))
PREFS_FILE = os.path.join(_ADDIN_DIR, 'dogbone_prefs.json')
DEBUG_LOG  = os.path.join(_ADDIN_DIR, 'dogbone_debug.log')

DEFAULT_PREFS = {'diam_mm': 8.0, 'jeu_mm': 0.1, 'cnc_only': True,
                 'auto_entaille': False, 'auto_tenon': False,
                 # avec "Coupes CNC seulement" : prend aussi les entailles faites
                 # sans CNC Toolkit (Combiner / Extrusion en coupe), mais pas les
                 # coins du contour des pieces (demande de l'utilisateur, 2026-10-11)
                 'manual_cuts': True}

# Groupes d'historique / noms / attributs qui reperent une coupe CNC.
CNC_GROUP_NAMES = ('Entaille CNC', 'Mortaise CNC', 'Tenon CNC', 'Marge CNC')
CNC_NAME_PREFIXES = ('Tenon', 'Mortaise CNC', 'Entaille', 'Marge CNC')
CNC_ATTR_GROUPS = ('MortaiseCNC', 'TenonCNC', 'MargeCNC', 'EntailleCNC')

_TOL_PAR  = 1e-3    # tolerance de parallelisme (sur 1 - |cos|)
_TOL_PERP = 1e-2    # tolerance de perpendicularite (|cos|)
_EPS_CM   = 0.01    # 0,1 mm : sondage de concavite
_EXT_CM   = 0.05    # 0,5 mm : prolongement aux bouts debouchants
_SKX_CM   = 0.1     # 1 mm : depassement de l'extrusion d'esquisse de chaque
                    # cote de la piece (demande de l'utilisateur 2026-10-11)
_OVL_CM   = 0.01    # 0,1 mm : le cercle depasse le coin (entaille un peu
                    # gauche : sinon fines faces parasites le long du coin)

_preview_cg = None


def _dbg(msg):
    try:
        with open(DEBUG_LOG, 'a', encoding='utf-8') as f:
            f.write(time.strftime('%Y-%m-%d %H:%M:%S ') + str(msg) + '\n')
    except Exception:
        pass


# --- Preferences ------------------------------------------------------------

def load_prefs():
    p = dict(DEFAULT_PREFS)
    try:
        with open(PREFS_FILE, 'r', encoding='utf-8') as f:
            p.update(json.load(f))
    except Exception:
        pass
    return p


def save_prefs(prefs):
    try:
        p = load_prefs()
        p.update({k: prefs[k] for k in DEFAULT_PREFS if k in prefs})
        with open(PREFS_FILE, 'w', encoding='utf-8') as f:
            json.dump(p, f, indent=2)
    except Exception:
        pass


# --- Collecte des corps -----------------------------------------------------

def _add_body(out, seen, body):
    try:
        if body is None or not body.isSolid or not body.isVisible:
            return
        occ = body.assemblyContext
        key = (body.nativeObject.entityToken if occ else body.entityToken,
               occ.fullPathName if occ else '')
        if key in seen:
            return
        seen.add(key)
        out.append(body)
    except Exception:
        pass


def _add_occurrence(out, seen, occ):
    try:
        if not occ.isVisible:
            return
        for b in occ.bRepBodies:
            _add_body(out, seen, b)
        for child in occ.childOccurrences:
            _add_occurrence(out, seen, child)
    except Exception:
        pass


def collect_bodies(design, entities=None):
    """entities : liste de BRepBody / Occurrence / Component. None = tout le
    modele (corps de la racine + toutes les occurrences visibles)."""
    out, seen = [], set()
    root = design.rootComponent
    if entities is None:
        entities = [root]
    for e in entities:
        b = adsk.fusion.BRepBody.cast(e)
        if b is not None:
            _add_body(out, seen, b)
            continue
        o = adsk.fusion.Occurrence.cast(e)
        if o is not None:
            _add_occurrence(out, seen, o)
            continue
        c = adsk.fusion.Component.cast(e)
        if c is not None:
            if c == root:
                for b in root.bRepBodies:
                    _add_body(out, seen, b)
                for o in root.occurrences:
                    _add_occurrence(out, seen, o)
            else:
                for o in root.allOccurrencesByComponent(c):
                    _add_occurrence(out, seen, o)
    return out


# --- Geometrie --------------------------------------------------------------

def _true_thickness_axis(body):
    """Normale des deux plus grandes faces planes opposees (axe d'epaisseur
    du panneau) - meme technique qu'EntailleCNC/MargeCNC._true_thickness."""
    try:
        planar = [f for f in body.faces if isinstance(f.geometry, adsk.core.Plane)]
        if len(planar) < 2:
            return None
        planar.sort(key=lambda f: -f.area)
        p1 = adsk.core.Plane.cast(planar[0].geometry)
        p2 = adsk.core.Plane.cast(planar[1].geometry)
        if abs(abs(p1.normal.dotProduct(p2.normal)) - 1.0) > 0.05:
            return None
        n = p1.normal.copy()
        n.normalize()
        return n
    except Exception:
        return None


def _face_normal(face, pt=None):
    """Normale SORTANTE d'une face plane (evaluator : tient compte de
    isParamReversed, contrairement a Plane.normal)."""
    try:
        if pt is None:
            pt = face.pointOnFace
        ok, n = face.evaluator.getNormalAtPoint(pt)
        if ok:
            n.normalize()
            return n
    except Exception:
        pass
    return None


def _offset(p, v, d):
    return adsk.core.Point3D.create(p.x + v.x * d, p.y + v.y * d, p.z + v.z * d)


def _inside(body, p):
    try:
        return body.pointContainment(p) == adsk.fusion.PointContainment.PointInsidePointContainment
    except Exception:
        return False


def _manual_flag(manual_cuts):
    if manual_cuts is None:
        return bool(load_prefs().get('manual_cuts', True))
    return bool(manual_cuts)


def _cnc_face_keys(design, manual_cuts=False, manual_out=None):
    """Cles (entityToken de corps natif, tempId de face) des faces creees par
    une fonction Entaille/Mortaise/Tenon/Marge CNC, a l'etat ACTUEL du
    modele (feature.faces, pas de jeton stocke).
    manual_out : set qui recoit a part les faces des coupes faites a la main
    (sinon elles vont dans le meme set)."""
    keys = set()
    mkeys = keys if manual_out is None else manual_out
    # timeline.item() ne parcourt que le premier niveau : un groupe y
    # apparait comme UN element (isGroup, entity None) - on descend dedans.
    items = []

    def walk(coll, in_cnc_group):
        for i in range(coll.count):
            try:
                it = coll.item(i)
                if it.isGroup:
                    g = adsk.fusion.TimelineGroup.cast(it)
                    walk(g, in_cnc_group or g.name in CNC_GROUP_NAMES)
                else:
                    items.append((it, in_cnc_group))
            except Exception:
                continue
    try:
        walk(design.timeline, False)
    except Exception:
        return keys
    for item, is_cnc in items:
        try:
            if item.isSuppressed or item.isRolledBack:
                continue
            feat = adsk.fusion.Feature.cast(item.entity)
            if feat is None:
                continue
            if not is_cnc:
                try:
                    nm = feat.name or ''
                    if nm.startswith(CNC_NAME_PREFIXES):
                        is_cnc = True
                except Exception:
                    pass
            if not is_cnc:
                try:
                    for a in feat.attributes:
                        if a.groupName in CNC_ATTR_GROUPS:
                            is_cnc = True
                            break
                except Exception:
                    pass
            is_manual = False
            if not is_cnc and manual_cuts:
                # entaille faite a la main : toute fonction en mode Couper
                # (sauf nos propres dogbones), et tout Decaler les faces : un
                # jeu fait a la main reprend les faces de la coupe qu'il
                # decale (feature.faces ne les rend plus a la coupe)
                try:
                    if adsk.fusion.OffsetFacesFeature.cast(feat) is not None:
                        is_manual = True
                    elif (feat.operation == adsk.fusion.FeatureOperations.CutFeatureOperation
                            and feat.attributes.itemByName(ATTR_GROUP, 'link') is None):
                        is_manual = True
                except Exception:
                    pass
            if not is_cnc and not is_manual:
                continue
            dest = keys if is_cnc else mkeys
            for f in feat.faces:
                try:
                    dest.add((f.body.entityToken, f.tempId))
                except Exception:
                    pass
        except Exception:
            continue
    if manual_cuts:
        # Certaines fonctions n'apparaissent pas dans le parcours de
        # l'historique (ex. Decaler les faces dans un composant de MARBLE
        # ARMCHAIR, 2026-10-11) : on reprend aussi les fonctions de chaque
        # composant.
        try:
            comps = list(design.allComponents)
        except Exception:
            comps = []
        for comp in comps:
            try:
                feats = comp.features
                n = feats.count
            except Exception:
                continue
            for i in range(n):
                try:
                    feat = feats.item(i)
                    try:
                        if feat.isSuppressed:
                            continue
                    except Exception:
                        pass
                    ok = adsk.fusion.OffsetFacesFeature.cast(feat) is not None
                    if not ok:
                        try:
                            ok = (feat.operation == adsk.fusion.FeatureOperations.CutFeatureOperation
                                  and feat.attributes.itemByName(ATTR_GROUP, 'link') is None)
                        except Exception:
                            ok = False
                    if not ok:
                        continue
                    for f in feat.faces:
                        try:
                            mkeys.add((f.body.entityToken, f.tempId))
                        except Exception:
                            pass
                except Exception:
                    continue
    # Jonction CNC : le morceau detache (Corps1_B...) a des faces qui
    # n'appartiennent plus a aucune fonction (ni Mortaise, ni Marge) : ses
    # coins n'etaient jamais "CNC" (2026-10-13). Ces faces orphelines
    # passent au tri des coupes a la main (entaille en U / corps voisin).
    try:
        jb = {}
        tlg = design.timeline.timelineGroups
        for gi in range(tlg.count):
            grp = tlg.item(gi)
            if not grp.name.startswith('Jonction'):
                continue
            for j in range(grp.count):
                try:
                    jf = adsk.fusion.Feature.cast(grp.item(j).entity)
                    if jf is None:
                        continue
                    for b in jf.bodies:
                        jb[b.entityToken] = b
                except Exception:
                    continue
        if jb:
            owned = set()
            for item, _c in items:
                try:
                    feat = adsk.fusion.Feature.cast(item.entity)
                    if feat is None or item.isSuppressed or item.isRolledBack:
                        continue
                    for f in feat.faces:
                        try:
                            tok = f.body.entityToken
                            if tok in jb:
                                owned.add((tok, f.tempId))
                        except Exception:
                            pass
                except Exception:
                    continue
            for tok, b in jb.items():
                for f in b.faces:
                    k = (tok, f.tempId)
                    if k not in owned and k not in keys:
                        mkeys.add(k)
    except Exception:
        pass
    return keys


def _face_key(native_face):
    try:
        return (native_face.body.entityToken, native_face.tempId)
    except Exception:
        return None


def _is_flat(face):
    """Face plane, y compris une face plane rendue en NurbsSurface (une coupe
    decalee le fait : un coin sur deux oublie sur M (25), 2026-10-11)."""
    try:
        if isinstance(face.geometry, adsk.core.Plane):
            return True
        ev = face.evaluator
        rng = ev.parametricRange()
        if isinstance(rng, tuple):
            rng = rng[-1]
        u0, v0 = rng.minPoint.x, rng.minPoint.y
        du, dv = rng.maxPoint.x - u0, rng.maxPoint.y - v0
        n0 = None
        for a in (0.1, 0.5, 0.9):
            for b in (0.1, 0.5, 0.9):
                ok, n = ev.getNormalAtParameter(adsk.core.Point2D.create(u0 + du * a, v0 + dv * b))
                if not ok:
                    return False
                n.normalize()
                if n0 is None:
                    n0 = n
                elif n0.dotProduct(n) < 1.0 - 1e-6:
                    return False
        return n0 is not None
    except Exception:
        return False


def _notch_corner(c, concave_ids, w_max):
    """Coin d'entaille/mortaise : une de ses deux faces porte, a moins de
    w_max, un AUTRE coin rentrant (fond d'entaille en U, mortaise). Un
    epaulement, une feuillure, ou un large creux ou se pose un panneau (pied
    du dossier de MARBLE ARMCHAIR, 2026-10-11) n'en ont pas besoin."""
    eid = c['edge'].tempId
    ax = c['axis']
    m0 = _offset(c['p0'], c['p0'].vectorTo(c['p1']), 0.5)
    for f in c['faces']:
        try:
            for oe in f.edges:
                if oe.tempId == eid or oe.tempId not in concave_ids:
                    continue
                q0, q1 = oe.startVertex.geometry, oe.endVertex.geometry
                v = m0.vectorTo(_offset(q0, q0.vectorTo(q1), 0.5))
                a = v.dotProduct(ax)
                w = (max(v.length ** 2 - a * a, 0.0)) ** 0.5
                if w <= w_max:
                    return True
        except Exception:
            continue
    return False


def find_corners(native_body, cnc_keys=None, manual_keys=None, occupied=None):
    """Coins rentrants d'un corps NATIF (coordonnees du composant).
    cnc_keys : set de cles _face_key, ou None (pas de filtre).
    manual_keys : cles des coupes faites a la main ; un coin qui ne touche
    qu'elles n'est garde que s'il est un coin d'entaille (_notch_corner) ou
    si un autre corps occupe le coin (occupied(coin) -> bool).
    Retourne une liste de dict {p0, p1, void_dir, axis}."""
    axis = _true_thickness_axis(native_body)
    if axis is None:
        return []
    corners = []
    for edge in native_body.edges:
        try:
            line = adsk.core.Line3D.cast(edge.geometry)
            if line is None:
                continue
            p0, p1 = edge.startVertex.geometry, edge.endVertex.geometry
            d = p0.vectorTo(p1)
            L = d.length
            if L < 1e-4:
                continue
            d.normalize()
            if 1.0 - abs(d.dotProduct(axis)) > _TOL_PAR:
                continue
            faces = edge.faces
            if faces.count != 2:
                continue
            f1, f2 = faces.item(0), faces.item(1)
            if not (_is_flat(f1) and _is_flat(f2)):
                continue
            mid = adsk.core.Point3D.create((p0.x + p1.x) / 2, (p0.y + p1.y) / 2, (p0.z + p1.z) / 2)
            n1, n2 = _face_normal(f1, mid), _face_normal(f2, mid)
            if n1 is None or n2 is None:
                continue
            if abs(n1.dotProduct(axis)) > _TOL_PERP or abs(n2.dotProduct(axis)) > _TOL_PERP:
                continue
            if abs(n1.dotProduct(n2)) > 0.999:
                continue
            diff = n1.copy()
            diff.subtract(n2)
            diff.normalize()
            if not _inside(native_body, _offset(mid, diff, _EPS_CM)):
                continue
            if not _inside(native_body, _offset(mid, diff, -_EPS_CM)):
                continue
            void_dir = n1.copy()
            void_dir.add(n2)
            if void_dir.length < 1e-6:
                continue
            void_dir.normalize()
            corners.append({'p0': p0, 'p1': p1, 'void_dir': void_dir, 'axis': d,
                            'edge': edge, 'faces': (f1, f2)})
        except Exception:
            _dbg('find_corners arete EXCEPTION: ' + traceback.format_exc())
            continue
    if cnc_keys is None:
        return corners
    concave_ids = set(c['edge'].tempId for c in corners)
    # largeur max d'une entaille : 3 x l'epaisseur (aretes de coin traversantes)
    w_max = 3.0 * max(c['p0'].distanceTo(c['p1']) for c in corners) if corners else 0.0
    kept = []
    for c in corners:
        k1, k2 = _face_key(c['faces'][0]), _face_key(c['faces'][1])
        if k1 in cnc_keys or k2 in cnc_keys:
            kept.append(c)
        elif (manual_keys and (k1 in manual_keys or k2 in manual_keys)
                and (_notch_corner(c, concave_ids, w_max)
                     or (occupied is not None and occupied(c)))):
            kept.append(c)
    return kept


def _dogbone_axis_points(native_body, c, r):
    """Extremites de l'axe du cylindre : coin decale de r cote vide,
    prolonge de _EXT_CM aux bouts qui debouchent sur une face exterieure."""
    v, d = c['void_dir'], c['axis']
    a = _offset(c['p0'], v, r - _OVL_CM)
    b = _offset(c['p1'], v, r - _OVL_CM)
    # bout p0 : au-dela de p0 (sens -d), juste dans la matiere pres du coin
    probe0 = _offset(_offset(c['p0'], d, -_EXT_CM), v, -_EPS_CM)
    if not _inside(native_body, probe0):
        a = _offset(a, d, -_EXT_CM)
    probe1 = _offset(_offset(c['p1'], d, _EXT_CM), v, -_EPS_CM)
    if not _inside(native_body, probe1):
        b = _offset(b, d, _EXT_CM)
    return a, b


def _body_context(body):
    """(corps natif, composant, Matrix3D composant->monde)."""
    occ = body.assemblyContext
    if occ is not None:
        native = body.nativeObject
        return native, native.parentComponent, occ.transform2
    return body, body.parentComponent, adsk.core.Matrix3D.create()


def _world_bodies(design):
    """Corps solides du modele, caches compris (on cache souvent les pieces
    voisines pour travailler), en coordonnees monde, avec leur boite :
    [(corps, (xmin, ymin, zmin, xmax, ymax, zmax), cle)]."""
    out = []
    root = design.rootComponent

    def add(b, occ):
        try:
            if not b.isSolid:
                return
            bb = b.boundingBox
            key = ((occ.fullPathName if occ is not None else ''), b.name)
            out.append((b, (bb.minPoint.x, bb.minPoint.y, bb.minPoint.z,
                            bb.maxPoint.x, bb.maxPoint.y, bb.maxPoint.z), key))
        except Exception:
            pass
    for b in root.bRepBodies:
        add(b, None)
    for occ in root.allOccurrences:
        try:
            for b in occ.bRepBodies:
                add(b, occ)
        except Exception:
            continue
    return out


def _occupied_fn(world, body, xf):
    """Fonction coin -> True si un AUTRE corps occupe le coin (sonde a
    1,5 mm cote vide, au milieu de l'arete : passe un jeu d'assemblage). Demande de l'utilisateur 2026-10-11."""
    occ = body.assemblyContext
    me = ((occ.fullPathName if occ is not None else ''), body.name)
    inside = adsk.fusion.PointContainment.PointInsidePointContainment

    def fn(c):
        mid = _offset(c['p0'], c['p0'].vectorTo(c['p1']), 0.5)
        p = _offset(mid, c['void_dir'], 0.15)
        q = _offset(mid, c['void_dir'], -0.15)
        p.transformBy(xf)
        q.transformBy(xf)
        for ob, (x0, y0, z0, x1, y1, z1), key in world:
            if key == me:
                continue
            if not (x0 <= p.x <= x1 and y0 <= p.y <= y1 and z0 <= p.z <= z1):
                continue
            try:
                if ob.pointContainment(p) != inside:
                    continue
                # un corps qui remplit aussi la matiere du corps teste est une
                # copie de reference (MODEL 3D LEHANNEUR), pas une piece voisine
                if ob.pointContainment(q) == inside:
                    continue
                return True
            except Exception:
                continue
        return False
    return fn


def analyse(design, bodies, diam_mm, jeu_mm, cnc_only=True, manual_cuts=None):
    """Detection pure (aucune modification). Retourne une liste de dict par
    corps ayant au moins un coin : {body, native, comp, xform, corners, r}."""
    r = (diam_mm / 2.0 + jeu_mm) / 10.0
    manual_keys = set()
    cnc_keys = _cnc_face_keys(design, _manual_flag(manual_cuts), manual_keys) if cnc_only else None
    world = _world_bodies(design) if manual_keys else None
    res = []
    cnc_progress.etape('Detection des coins...', 0, len(bodies))
    for b in bodies:
        cnc_progress.avance()
        try:
            native, comp, xf = _body_context(b)
            occupied = _occupied_fn(world, b, xf) if world is not None else None
            corners = find_corners(native, cnc_keys, manual_keys, occupied)
            if corners:
                res.append({'body': b, 'native': native, 'comp': comp, 'xform': xf,
                            'corners': corners, 'r': r})
        except Exception:
            _dbg('analyse EXCEPTION: ' + traceback.format_exc())
    return res


# --- Preview (CustomGraphics, aucune modification du document) --------------

def clear_preview():
    global _preview_cg
    try:
        if _preview_cg is not None and _preview_cg.isValid:
            _preview_cg.deleteMe()
    except Exception:
        pass
    _preview_cg = None
    try:
        _app.activeViewport.refresh()
    except Exception:
        pass


def draw_preview(design, analysis):
    """Cercles orange aux deux bouts de chaque dogbone + 2 generatrices."""
    global _preview_cg
    clear_preview()
    coords = []
    idx = []
    seg = 24

    def add_pt(p, xf):
        q = p.copy()
        q.transformBy(xf)
        coords.extend([q.x, q.y, q.z])
        return len(coords) // 3 - 1

    for item in analysis:
        r, xf, native = item['r'], item['xform'], item['native']
        for c in item['corners']:
            a, b = _dogbone_axis_points(native, c, r)
            d = c['axis']
            u = c['void_dir']
            w = d.crossProduct(u)
            w.normalize()
            for center in (a, b):
                ring = []
                for k in range(seg):
                    t = 2 * math.pi * k / seg
                    p = adsk.core.Point3D.create(
                        center.x + r * (math.cos(t) * u.x + math.sin(t) * w.x),
                        center.y + r * (math.cos(t) * u.y + math.sin(t) * w.y),
                        center.z + r * (math.cos(t) * u.z + math.sin(t) * w.z))
                    ring.append(add_pt(p, xf))
                for k in range(seg):
                    idx.extend([ring[k], ring[(k + 1) % seg]])
            for s in (1, -1):
                pa = _offset(a, w, s * r)
                pb = _offset(b, w, s * r)
                idx.extend([add_pt(pa, xf), add_pt(pb, xf)])
    if not idx:
        return
    try:
        root = design.rootComponent
        _preview_cg = root.customGraphicsGroups.add()
        cc = adsk.fusion.CustomGraphicsCoordinates.create(coords)
        lines = _preview_cg.addLines(cc, idx, False)
        lines.color = adsk.fusion.CustomGraphicsSolidColorEffect.create(
            adsk.core.Color.create(255, 140, 0, 255))
        lines.weight = 3.0
        lines.depthPriority = 1
        _app.activeViewport.refresh()
    except Exception:
        _dbg('draw_preview EXCEPTION: ' + traceback.format_exc())


def _draw_selected(design, bodies):
    """Corps retenus par le panneau, en bleu transparent dans le meme
    groupe que le preview : Fusion ne surligne que le dernier corps clique,
    c'est ce bleu qui montre la liste complete."""
    global _preview_cg
    try:
        if _preview_cg is None or not _preview_cg.isValid:
            _preview_cg = design.rootComponent.customGraphicsGroups.add()
        tbm = adsk.fusion.TemporaryBRepManager.get()
        color = adsk.fusion.CustomGraphicsSolidColorEffect.create(
            adsk.core.Color.create(40, 120, 255, 90))
        for b in bodies:
            native, _comp, xf = _body_context(b)
            tmp = tbm.copy(native)
            tbm.transform(tmp, xf)
            g = _preview_cg.addBRepBody(tmp)
            g.color = color
            g.depthPriority = 0
        _app.activeViewport.refresh()
    except Exception:
        _dbg('draw_selected EXCEPTION: ' + traceback.format_exc())


def summary(analysis):
    return {'n_corners': sum(len(i['corners']) for i in analysis),
            'n_bodies': len(analysis)}


# --- Creation ---------------------------------------------------------------

# --- Dogbones en esquisse (2026-10-07, demande de l'utilisateur : "si je bouge un
# corps, tout doit suivre") ---------------------------------------------------
# Pour chaque coin : esquisse sur la face par ou le coin debouche, aretes des
# deux parois projetees (liees au corps), cercle de rayon r dont le centre est
# tenu a distance fixe de chacune des deux parois (lignes de construction
# paralleles + cotes). Une extrusion en coupe par face et profondeur. Si le
# corps bouge, ou si l'entaille (elle aussi en esquisse) se deplace, les
# cercles suivent. Un coin qui ne s'y prete pas passe en mode fige (BaseFeature
# + Combiner, comme avant). _SKETCH_MODE = False revient a l'ancien mode.

_SKETCH_MODE = True


def _same(a, b):
    try:
        return a.tempId == b.tempId
    except Exception:
        return False


def _refind_edge(native, c):
    """Arete actuelle du coin (les references BRep ne survivent pas a une
    extrusion sur le corps) : retrouvee par ses extremites."""
    for e in native.edges:
        try:
            if adsk.core.Line3D.cast(e.geometry) is None:
                continue
            a, b = e.startVertex.geometry, e.endVertex.geometry
            if ((a.distanceTo(c['p0']) < 1e-5 and b.distanceTo(c['p1']) < 1e-5)
                    or (a.distanceTo(c['p1']) < 1e-5 and b.distanceTo(c['p0']) < 1e-5)):
                return e
        except Exception:
            continue
    return None


def _corner_sketch_plan(native, c, thick_axis=None):
    """(vertex de depart, face d'esquisse, aretes des 2 parois, profondeur)
    ou None."""
    d, v = c['axis'], c['void_dir']
    e = _refind_edge(native, c)
    if e is None or e.faces.count != 2:
        return None
    open0 = not _inside(native, _offset(_offset(c['p0'], d, -_EXT_CM), v, -_EPS_CM))
    open1 = not _inside(native, _offset(_offset(c['p1'], d, _EXT_CM), v, -_EPS_CM))
    # cote d'ouverture : celui du point p0 / p1 de c ; l'arete retrouvee peut
    # etre orientee dans l'autre sens.
    v_p0, v_p1 = e.startVertex, e.endVertex
    if v_p0.geometry.distanceTo(c['p0']) > 1e-5:
        v_p0, v_p1 = v_p1, v_p0
    if open0 and open1 and thick_axis is not None:
        # traversant : toujours la meme face du panneau (moins d'esquisses)
        side = c['p0'].vectorTo(c['p1']).dotProduct(thick_axis)
        vert, far_open = (v_p1, True) if side > 0 else (v_p0, True)
    elif open0:
        vert, far_open = v_p0, open1
    elif open1:
        vert, far_open = v_p1, open0
    else:
        return None
    walls = (e.faces.item(0), e.faces.item(1))
    face = None
    for f in vert.faces:
        if _same(f, walls[0]) or _same(f, walls[1]):
            continue
        if not isinstance(f.geometry, adsk.core.Plane):
            continue
        n = _face_normal(f, vert.geometry)
        if n is None or abs(abs(n.dotProduct(d)) - 1.0) > _TOL_PAR:
            continue
        face = f
        break
    if face is None:
        return None
    wall_edges = []
    for ed in vert.edges:
        if _same(ed, e) or adsk.core.Line3D.cast(ed.geometry) is None:
            continue
        if not any(_same(ed, x) for x in face.edges):
            continue
        wall_edges.append(ed)
    if len(wall_edges) != 2:
        return None
    depth = c['p0'].distanceTo(c['p1']) + (_SKX_CM if far_open else 0.0)
    return vert, face, wall_edges, depth


def _sketch_dogbones(item, params, link_fn):
    """Cree les dogbones en esquisse d'un corps. Retourne
    (n_coins_faits, coins_restants, fonctions_creees)."""
    native, comp, r = item['native'], item['comp'], item['r']
    thick = _true_thickness_axis(native)
    todo = list(item['corners'])
    rest = []
    n_done = 0
    feats = []
    P = adsk.core.Point3D.create
    while todo:
        # Plans recalcules a chaque tour : chaque extrusion change les faces
        # et aretes du corps. On traite un groupe (face, profondeur) par tour.
        groups = {}
        for c in todo:
            try:
                plan = _corner_sketch_plan(native, c, thick)
            except Exception:
                plan = None
            if plan is None:
                rest.append(c)
                continue
            vert, face, wall_edges, depth = plan
            key = (face.tempId, round(depth, 4))
            groups.setdefault(key, {'face': face, 'depth': depth, 'items': []})['items'].append(
                (c, vert, wall_edges))
        if not groups:
            break
        g = list(groups.values())[0]
        done_ids = set(id(c) for c, _v, _w in g['items'])
        todo = [c for c in todo if id(c) not in done_ids and any(
            id(c) == id(x) for gg in groups.values() for x, _v, _w in gg['items'])]
        sk = ext = None
        try:
            vol_before = native.volume
            sk = comp.sketches.addWithoutEdges(g['face'])
            sk.name = 'Dogbone (esquisse)'
            circles = []
            # Coin d'equerre (parois exactement perpendiculaires a l'esquisse,
            # coupes CNC Toolkit) : cercle contraint aux parois projetees, il
            # suit l'entaille. Coin un peu de travers (entaille faite a la
            # main) : cercle simplement pose, sinon courbes hors plan et
            # extrusion en jaune au recalcul (MARBLE ARMCHAIR 2026-10-11).
            skn = sk.xDirection.crossProduct(sk.yDirection)
            skn.normalize()
            lines = sk.sketchCurves.sketchLines
            # Toutes les parois projetees en UN appel (une arete commune a 2
            # coins n'est projetee qu'une fois) : chaque project() relancait
            # le calcul de l'esquisse (55 s pour 240 coins - vitesse
            # 2026-10-11). Lignes retrouvees par leurs extremites.
            squares = []
            wall_by_id = {}
            for c, vert, wall_edges in g['items']:
                sq = (1.0 - abs(c['axis'].dotProduct(skn)) < 1e-9
                      and abs(c['void_dir'].dotProduct(skn)) < 1e-7)
                squares.append(sq)
                if sq:
                    for we in wall_edges:
                        wall_by_id.setdefault(we.tempId, we)
            line_by_id = {}
            if wall_by_id:
                try:
                    col = adsk.core.ObjectCollection.create()
                    for we in wall_by_id.values():
                        col.add(we)
                    pr = sk.project(col)
                    cands = []
                    for i in range(pr.count):
                        ln = adsk.fusion.SketchLine.cast(pr.item(i))
                        if ln is not None:
                            cands.append((ln, sk.sketchToModelSpace(ln.startSketchPoint.geometry),
                                          sk.sketchToModelSpace(ln.endSketchPoint.geometry)))
                    for tid, we in wall_by_id.items():
                        a0, a1 = we.startVertex.geometry, we.endVertex.geometry
                        for ln, q0, q1 in cands:
                            if ((a0.distanceTo(q0) < 1e-5 and a1.distanceTo(q1) < 1e-5)
                                    or (a0.distanceTo(q1) < 1e-5 and a1.distanceTo(q0) < 1e-5)):
                                line_by_id[tid] = ln
                                break
                except Exception:
                    _dbg('esquisse dogbone : projection groupee refusee : ' + traceback.format_exc())
            sk.isComputeDeferred = True
            for ln in line_by_id.values():
                ln.isConstruction = True
            projected = []
            for (c, vert, wall_edges), sq in zip(g['items'], squares):
                wl = None
                if sq:
                    wl = [line_by_id.get(we.tempId) for we in wall_edges]
                    if any(ln is None for ln in wl):
                        wl = None
                projected.append(wl)
            for (c, vert, wall_edges), wl in zip(g['items'], projected):
                ctr = sk.modelToSketchSpace(_offset(vert.geometry, c['void_dir'], r - _OVL_CM))
                ctr = P(ctr.x, ctr.y, 0)  # dans le plan de l'esquisse
                circ = sk.sketchCurves.sketchCircles.addByCenterRadius(ctr, r)
                for ln in (wl or []):
                    a, b = ln.startSketchPoint.geometry, ln.endSketchPoint.geometry
                    dx, dy = b.x - a.x, b.y - a.y
                    L = math.hypot(dx, dy) or 1.0
                    cl = lines.addByTwoPoints(circ.centerSketchPoint,
                                              P(ctr.x + dx / L * r, ctr.y + dy / L * r, 0))
                    cl.isConstruction = True
                    sk.geometricConstraints.addParallel(cl, ln)
                    sk.sketchDimensions.addOffsetDimension(
                        ln, cl, P(ctr.x + r, ctr.y + r, 0))
                sk.sketchDimensions.addDiameterDimension(circ, P(ctr.x + 2 * r, ctr.y, 0))
                circles.append(circ)
            sk.isComputeDeferred = False
            circ_toks = set(circ.entityToken for circ in circles)
            profs = adsk.core.ObjectCollection.create()
            for pr in sk.profiles:
                ok = True
                for lp in pr.profileLoops:
                    for pc in lp.profileCurves:
                        try:
                            if pc.sketchEntity.entityToken not in circ_toks:
                                ok = False
                        except Exception:
                            ok = False
                if ok:
                    profs.add(pr)
            if profs.count == 0:
                raise RuntimeError('aucun profil')
            if profs.count != len(circles):
                _dbg('esquisse dogbone : %d profils pour %d cercles' % (profs.count, len(circles)))
            # Points de controle : dans la matiere derriere chaque paroi, a
            # l'interieur du cercle. Encore dans la matiere apres la coupe =
            # cercle pas extrude (vu sur MARBLE ARMCHAIR 2026-10-11) : le coin
            # repasse en mode fige.
            checks = []
            for c, _v, _w in g['items']:
                pts = []
                try:
                    e = _refind_edge(native, c)
                    mid = _offset(c['p0'], c['p0'].vectorTo(c['p1']), 0.5)
                    c0 = _offset(mid, c['void_dir'], r - _OVL_CM)
                    for f in e.faces:
                        n = _face_normal(f, mid)
                        if n is not None:
                            pts.append(_offset(c0, n, -0.9 * r))
                except Exception:
                    pts = []
                checks.append((c, pts))
            efs = comp.features.extrudeFeatures
            # Deux cotes : la profondeur dans la piece, et 1 mm vers
            # l'exterieur, pour couper toute la piece. Cote matiere = oppose a
            # la normale sortante de la face d'esquisse.
            dist = lambda v: adsk.fusion.DistanceExtentDefinition.create(
                adsk.core.ValueInput.createByReal(v))
            sides = [(_SKX_CM, g['depth']), (g['depth'], _SKX_CM)]
            try:
                fnrm = _face_normal(g['face'])
                skn = sk.xDirection.crossProduct(sk.yDirection)
                if fnrm is not None and skn.dotProduct(fnrm) < 0:
                    sides.reverse()
            except Exception:
                pass
            for one, two in sides:
                ei = efs.createInput(profs, adsk.fusion.FeatureOperations.CutFeatureOperation)
                ei.setTwoSidesExtent(dist(one), dist(two))
                ei.participantBodies = [native]
                ext = efs.add(ei)
                if vol_before - sum(b.volume for b in ext.bodies) > 1e-6:
                    break
                ext.deleteMe()
                ext = None
            if ext is None:
                raise RuntimeError('rien retire')
            ext.name = FEAT_NAME
            link_fn(ext, sk)
            feats.append(ext)
            missed = [c for c, pts in checks if any(_inside(native, q) for q in pts)]
            if missed:
                _dbg('esquisse dogbone : %d coin(s) non coupe(s), passage en fige' % len(missed))
            n_done += len(g['items']) - len(missed)
            rest.extend(missed)
        except Exception:
            _dbg('esquisse dogbone refusee : ' + traceback.format_exc())
            for f in (ext, sk):
                try:
                    if f is not None and f.isValid:
                        f.deleteMe()
                except Exception:
                    pass
            rest.extend(c for c, _v, _w in g['items'])
    return n_done, rest, feats


# --- Reseaux : dogbones sur le corps d'origine, avant le reseau ---------------
# Demande de l'utilisateur (2026-10-13) : un corps recopie par un reseau (sur la
# trajectoire de Toolkit, rectangulaire, circulaire) ou une symetrie ne recoit
# pas ses propres dogbones ; on les cree sur le corps d'origine juste AVANT le
# reseau dans la chronologie, et le reseau les recopie. Origine = corps du
# reseau dont aucune face n'est creee par le reseau (inputEntities n'est pas
# lisible sans reculer la chronologie).

_PATTERN_KINDS = ('pathPatternFeatures', 'rectangularPatternFeatures',
                  'circularPatternFeatures', 'mirrorFeatures')


def _body_token(b):
    try:
        return (b.nativeObject if b.assemblyContext else b).entityToken
    except Exception:
        return None


def _pattern_map(design):
    """(tokens des copies -> token d'origine, token d'origine -> timelineObject
    du 1er reseau qui le recopie). Reseaux supprimes ou recules ignores."""
    copy_src, first = {}, {}
    try:
        comps = list(design.allComponents)
    except Exception:
        return copy_src, first
    for comp in comps:
        for kind in _PATTERN_KINDS:
            try:
                coll = getattr(comp.features, kind)
                n = coll.count
            except Exception:
                continue
            for i in range(n):
                try:
                    p = coll.item(i)
                    tlo = p.timelineObject
                    if p.isSuppressed or tlo.isRolledBack:
                        continue
                    owned = set()
                    for f in p.faces:
                        try:
                            owned.add(f.body.entityToken)
                        except Exception:
                            pass
                    srcs, cps = [], []
                    for b in p.bodies:
                        (cps if b.entityToken in owned else srcs).append(b.entityToken)
                    if len(srcs) != 1:
                        continue  # plusieurs corps d'origine : copie -> origine ambigu
                    s = srcs[0]
                    for t in cps:
                        copy_src[t] = s
                    if s not in first or tlo.index < first[s].index:
                        first[s] = tlo
                except Exception:
                    _dbg('pattern_map EXCEPTION: ' + traceback.format_exc())
    return copy_src, first


def _root_source(copy_src, tok):
    seen = set()
    while tok in copy_src and tok not in seen:
        seen.add(tok)
        tok = copy_src[tok]
    return tok


def drop_pattern_copies(design, bodies):
    """Retire les copies de reseau dont le corps d'origine est dans la liste,
    et les occurrences en double d'un meme composant (ses dogbones valent
    pour toutes ses occurrences)."""
    copy_src, _first = _pattern_map(design)
    toks = set(_body_token(b) for b in bodies)
    out, seen = [], set()
    for b in bodies:
        t = _body_token(b)
        if t in seen:
            continue
        seen.add(t)
        if t in copy_src and _root_source(copy_src, t) in toks:
            continue
        out.append(b)
    return out


def create_dogbones(design, bodies, diam_mm, jeu_mm, cnc_only=True, manual_cuts=None):
    """Comme _create_dogbones_core, mais un corps d'origine de reseau est
    traite juste avant son 1er reseau (les copies suivent), puis tout le
    reste en fin de chronologie (coupes faites apres le reseau)."""
    try:
        copy_src, first = _pattern_map(design)
    except Exception:
        copy_src, first = {}, {}
    toks = set(_body_token(b) for b in bodies)
    groups = {}
    for t in toks:
        if t in first and t not in copy_src:
            groups.setdefault(first[t].index, (first[t], []))[1].append(t)
    if not groups:
        return _create_dogbones_core(design, drop_pattern_copies(design, bodies),
                                     diam_mm, jeu_mm, cnc_only, manual_cuts)
    refs = []
    for b in bodies:
        try:
            refs.append((b, _body_token(b), b.assemblyContext))
        except Exception:
            pass
    tl = design.timeline
    total = {'error': None, 'n_corners': 0, 'n_bodies': 0, 'messages': []}
    names = set()

    def add(res):
        if res.get('error') and not total['error']:
            total['error'] = res['error']
        total['n_corners'] += res.get('n_corners', 0)
        total['n_bodies'] += res.get('n_bodies', 0)
        total['messages'] += [m for m in res.get('messages', [])
                              if not m.startswith('Aucun coin')]
    pos = tl.markerPosition
    at_end = pos >= tl.count
    back = None if at_end else tl.item(pos)
    try:
        for _idx, (tlo, src_toks) in sorted(groups.items(), key=lambda kv: kv[0]):
            try:
                tlo.rollTo(True)
                src = []
                for t in src_toks:
                    for e in design.findEntityByToken(t):
                        b = adsk.fusion.BRepBody.cast(e)
                        if b is not None and b.isValid:
                            src.append(b)
                            names.add(b.name)
                            break
                if src:
                    res = _create_dogbones_core(design, src, diam_mm, jeu_mm, cnc_only, manual_cuts)
                    add(res)
                    n_cp = sum(1 for c in copy_src if _root_source(copy_src, c) in src_toks)
                    if res.get('n_corners') and n_cp:
                        total['messages'].append(
                            'Reseau : dogbones de "%s" crees avant le reseau, recopies sur %d copie(s).'
                            % ('", "'.join(b.name for b in src), n_cp))
            except Exception:
                total['messages'].append('Reseau : creation avant le reseau impossible.')
                _dbg('pattern pass EXCEPTION: ' + traceback.format_exc())
    finally:
        try:
            if back is not None and back.isValid:
                back.rollTo(True)
            else:
                tl.moveToEnd()
        except Exception:
            _dbg('pattern restore marker EXCEPTION: ' + traceback.format_exc())
    # fin de chronologie : origines + copies (seuls les coins pas encore
    # coupes ressortent, ex. une coupe faite apres le reseau)
    rest = []
    seen = set()
    for b, t, occ in refs:
        if t in seen:
            continue
        seen.add(t)
        try:
            if not b.isValid:
                b = None
                for e in design.findEntityByToken(t):
                    nb = adsk.fusion.BRepBody.cast(e)
                    if nb is not None:
                        b = nb.createForAssemblyContext(occ) if occ is not None else nb
                        break
            if b is not None:
                rest.append(b)
        except Exception:
            _dbg('pattern refind EXCEPTION: ' + traceback.format_exc())
    add(_create_dogbones_core(design, rest, diam_mm, jeu_mm, cnc_only, manual_cuts))
    if total['n_corners'] == 0 and not total['messages']:
        total['messages'].append('Aucun coin interieur a traiter sur la selection.')
    return total


def _create_dogbones_core(design, bodies, diam_mm, jeu_mm, cnc_only=True, manual_cuts=None):
    """Coeur pur. Retourne {'error', 'n_corners', 'n_bodies', 'messages'}."""
    messages = []
    manual_cuts = _manual_flag(manual_cuts)
    analysis = analyse(design, bodies, diam_mm, jeu_mm, cnc_only, manual_cuts)
    clear_preview()
    if not analysis:
        return {'error': None, 'n_corners': 0, 'n_bodies': 0,
                'messages': ['Aucun coin interieur a traiter sur la selection.']}
    tbm = adsk.fusion.TemporaryBRepManager.get()
    tl = design.timeline
    start_index = tl.markerPosition
    params = json.dumps({'diam_mm': diam_mm, 'jeu_mm': jeu_mm, 'cnc_only': bool(cnc_only),
                         'manual_cuts': manual_cuts,
                         'type': 'classique', 'version': 1})

    # 0) Mode esquisse d'abord ; les coins refuses restent pour le mode fige.
    n_sk_corners = 0
    sk_bodies = set()
    if _SKETCH_MODE:
        def _tag(ext, sk):
            link = uuid.uuid4().hex
            for f in (ext, sk):
                try:
                    f.attributes.add(ATTR_GROUP, 'params', params)
                    f.attributes.add(ATTR_GROUP, 'link', link)
                    f.attributes.add(ATTR_GROUP, 'body_name', item['native'].name)
                    f.attributes.add(ATTR_GROUP, 'mode', 'esquisse')
                except Exception:
                    pass
        cnc_progress.etape('Dogbones en esquisse...', 0, len(analysis))
        for item in analysis:
            cnc_progress.avance()
            try:
                n_done, rest, _feats = _sketch_dogbones(item, params, _tag)
            except Exception:
                _dbg('esquisse EXCEPTION: ' + traceback.format_exc())
                continue
            if n_done:
                n_sk_corners += n_done
                sk_bodies.add(item['native'].name)
            item['corners'] = rest
        analysis = [it for it in analysis if it['corners']]

    # 1) Corps outils transitoires : un par corps cible (cylindres unis).
    pending = []
    cnc_progress.etape('Outils de coupe...', 0, len(analysis))
    for item in analysis:
        cnc_progress.avance()
        tool = None
        for c in item['corners']:
            try:
                a, b = _dogbone_axis_points(item['native'], c, item['r'])
                cyl = tbm.createCylinderOrCone(a, item['r'], b, item['r'])
                if tool is None:
                    tool = cyl
                else:
                    tbm.booleanOperation(tool, cyl, adsk.fusion.BooleanTypes.UnionBooleanType)
            except Exception:
                messages.append('Cylindre impossible sur "%s".' % item['native'].name)
        if tool is not None:
            pending.append((item, tool))

    # 2) Une BaseFeature par corps cible, puis UN SEUL computeAll.
    inserted = []
    cnc_progress.etape('Insertion des outils...', 0, len(pending))
    for item, tool in pending:
        cnc_progress.avance()
        comp = item['comp']
        try:
            bf = comp.features.baseFeatures.add()
            bf.startEdit()
            try:
                comp.bRepBodies.add(tool, bf)
            finally:
                bf.finishEdit()
            bf.name = 'Dogbone (outils)'
            inserted.append((item, bf))
        except Exception:
            messages.append('Insertion impossible pour "%s".' % item['native'].name)
            _dbg('BaseFeature EXCEPTION: ' + traceback.format_exc())
    if inserted:
        cnc_progress.etape('Recalcul du modele...')
        try:
            design.computeAll()
        except Exception:
            pass
        try:
            adsk.doEvents()
        except Exception:
            pass

    # 3) Une Combiner en Couper par corps.
    n_ok_bodies, n_ok_corners = 0, 0
    cnc_progress.etape('Decoupe des dogbones...', 0, len(inserted))
    for item, bf in inserted:
        cnc_progress.avance()
        native = item['native']
        try:
            if bf.bodies.count == 0:
                raise RuntimeError('BaseFeature vide')
            tool_body = bf.bodies.item(0)
            pre = native.faces.count
            col = adsk.core.ObjectCollection.create()
            col.add(tool_body)
            cf = item['comp'].features.combineFeatures
            ci = cf.createInput(native, col)
            ci.operation = adsk.fusion.FeatureOperations.CutFeatureOperation
            ci.isKeepToolBodies = False
            feat = cf.add(ci)
            feat.name = FEAT_NAME
            link = uuid.uuid4().hex
            for f in (feat, bf):
                try:
                    f.attributes.add(ATTR_GROUP, 'params', params)
                    f.attributes.add(ATTR_GROUP, 'link', link)
                    f.attributes.add(ATTR_GROUP, 'body_name', native.name)
                except Exception:
                    pass
            try:
                res_body = feat.bodies.item(0) if feat.bodies.count else native
                feat.attributes.add(ATTR_GROUP, 'sig', json.dumps(_body_sig(res_body)))
            except Exception:
                _dbg('sig EXCEPTION: ' + traceback.format_exc())
            if native.faces.count <= pre:
                messages.append('Dogbones sans effet sur "%s".' % native.name)
            n_ok_bodies += 1
            n_ok_corners += len(item['corners'])
        except Exception:
            messages.append('Decoupe impossible sur "%s" : %s' % (
                native.name, traceback.format_exc().strip().splitlines()[-1]))
            _dbg('Combine EXCEPTION: ' + traceback.format_exc())

    # 4) Groupe d'historique.
    try:
        end_index = tl.markerPosition - 1
        if end_index > start_index:
            grp = tl.timelineGroups.add(start_index, end_index)
            grp.name = GROUP_NAME
    except Exception:
        _dbg('timelineGroup EXCEPTION: ' + traceback.format_exc())

    return {'error': None, 'n_corners': n_ok_corners + n_sk_corners,
            'n_bodies': len(sk_bodies | set(it['native'].name for it, _bf in inserted)) if sk_bodies else n_ok_bodies,
            'messages': messages}


def _native_key(native_body):
    try:
        return (native_body.parentComponent.id, native_body.name)
    except Exception:
        return None


def remove_dogbones(design, bodies=None, keys=None):
    """Supprime les fonctions DogboneCNC (Combiner + sa BaseFeature, reliees
    par l'attribut 'link') des corps donnes (None = tout le document).
    keys : ensemble de (comp_id, body_name), a la place de bodies.
    Retourne le nombre de corps traites."""
    natives = set(keys) if keys is not None else None
    if bodies is not None:
        natives = []
        for b in bodies:
            try:
                natives.append(_native_key(_body_context(b)[0]))
            except Exception:
                pass
    combines, bases = [], {}
    try:
        attrs = design.findAttributes(ATTR_GROUP, 'link')
    except Exception:
        attrs = []
    for a in attrs:
        cf = adsk.fusion.CombineFeature.cast(a.parent) or adsk.fusion.ExtrudeFeature.cast(a.parent)
        if cf is not None:
            combines.append((cf, a.value))
            continue
        bf = adsk.fusion.BaseFeature.cast(a.parent) or adsk.fusion.Sketch.cast(a.parent)
        if bf is not None:
            bases[a.value] = bf
    targets = []
    n = 0
    for cf, link in combines:
        try:
            if natives is not None:
                # cle (composant, nom de corps tague a la creation) : les
                # entityToken ne sont pas canoniques et cf.targetBody exige
                # de reculer l'historique jusqu'a la fonction.
                bn = cf.attributes.itemByName(ATTR_GROUP, 'body_name')
                if (cf.parentComponent.id, bn.value if bn else None) not in natives:
                    continue
            targets.append(cf)
            bf = bases.get(link)
            if bf is not None:
                targets.append(bf)
            n += 1
        except Exception:
            _dbg('remove EXCEPTION: ' + traceback.format_exc())
    if targets:
        _delete_features_batch(design, targets)
    return n


def _tl_index(tlo, expanded):
    """Index d'une fonction dans l'historique. TimelineObject.index echoue
    pour une fonction d'un groupe replie : on deplie le groupe (memorise
    dans expanded pour le replier ensuite)."""
    try:
        return tlo.index
    except Exception:
        pass
    try:
        g = tlo.parentGroup
        if g is not None and g.isCollapsed:
            g.isCollapsed = False
            expanded.append(g)
        return tlo.index
    except Exception:
        return None


def _delete_features_batch(design, feats):
    """Supprime les fonctions en un seul recalcul : chaque deleteMe en fin
    d'historique recalcule toute la suite (23 corps : 23 s). On recule le
    marqueur avant la premiere fonction, on supprime tout, puis on remet le
    marqueur (a la fin s'il y etait)."""
    tl = design.timeline
    pos = tl.markerPosition
    at_end = pos >= tl.count
    expanded = []
    idx = []
    for f in feats:
        try:
            idx.append(_tl_index(f.timelineObject, expanded))
        except Exception:
            idx.append(None)
    known = [(i, k) for k, i in enumerate(idx) if i is not None]
    if known:
        first_i, first_k = min(known)
        if first_i < pos:
            try:
                feats[first_k].timelineObject.rollTo(True)
            except Exception:
                _dbg('rollTo EXCEPTION: ' + traceback.format_exc())
    for f in feats:
        try:
            f.deleteMe()
        except Exception:
            _dbg('remove EXCEPTION: ' + traceback.format_exc())
    try:
        if at_end:
            tl.moveToEnd()
        else:
            tl.markerPosition = max(0, pos - sum(1 for i, _k in known if i < pos))
    except Exception:
        _dbg('marqueur EXCEPTION: ' + traceback.format_exc())
    for g in expanded:
        try:
            if g.isValid:
                g.isCollapsed = True
        except Exception:
            pass


# --- Dogbone auto (cases a cocher de Tenons CNC / Entaille CNC) -------------
# ToolkitCNC appelle body_keys AVANT de creer les coupes (les references de
# corps ne survivent pas toujours a une Combiner), puis auto_dogbones apres.
# Seuls les coins interieurs encore sans dogbone sont traites.

def get_auto(tool):
    """tool : 'entaille' ou 'tenon'. Etat memorise de la case Dogbone auto."""
    return bool(load_prefs().get('auto_' + tool, False))


def set_auto(tool, on):
    save_prefs({'auto_' + tool: bool(on)})


def body_keys(bodies):
    keys = []
    for b in bodies or []:
        try:
            k = _native_key(_body_context(b)[0])
            if k and k not in keys:
                keys.append(k)
        except Exception:
            pass
    return keys


def auto_dogbones(design, keys):
    """Dogbones sur les corps (comp_id, body_name) donnes, aux reglages du
    panneau Dogbone CNC. Retourne le dict de create_dogbones."""
    comps = {}
    try:
        for c in design.allComponents:
            comps[c.id] = c
    except Exception:
        pass
    bodies = []
    for cid, name in keys or []:
        comp = comps.get(cid)
        b = comp.bRepBodies.itemByName(name) if comp is not None else None
        if b is not None:
            bodies.append(b)
    if not bodies:
        return {'error': None, 'n_corners': 0, 'n_bodies': 0, 'messages': []}
    p = load_prefs()
    return create_dogbones(design, bodies, float(p['diam_mm']), float(p['jeu_mm']),
                           bool(p.get('cnc_only', True)))


# --- Recreation apres mise a jour des coupes ----------------------------------
# Les dogbones sont figes : si Entaille CNC / Mettre a jour CNC recree les
# coupes d'un corps, ses dogbones restent a l'ancienne place. Ces fonctions
# sont appelees par ces outils (via _find_module), dans cet ordre :
#   snap = snapshot_dogbones(design, bodies)
#   remove_dogbones(design, bodies)
#   ... recreation des coupes ...
#   restore_dogbones(design, snap)
# ou en une fois, quand les coupes sont deja a jour :
#   recreate_all_dogbones(design, bodies=None)

def _body_sig(body):
    """Empreinte du corps fini (encombrement, volume, surface), en cm. Prise
    juste apres la creation des dogbones : si elle change, le corps a bouge
    ou ses coupes ont change, et ses dogbones sont a refaire."""
    bb = body.boundingBox
    return [round(v, 5) for v in (bb.minPoint.x, bb.minPoint.y, bb.minPoint.z,
                                  bb.maxPoint.x, bb.maxPoint.y, bb.maxPoint.z,
                                  body.volume, body.area)]


def _sig_changed(old, new):
    if not old or len(old) != len(new):
        return True
    for i, (a, b) in enumerate(zip(old, new)):
        tol = 1e-3 if i < 6 else max(1e-3, abs(a) * 1e-5)
        if abs(a - b) > tol:
            return True
    return False


def snapshot_dogbones(design, bodies=None):
    """Memorise quels corps ont des dogbones et avec quels reglages, AVANT
    remove_dogbones (qui efface les attributs). bodies : BRepBody (proxies
    acceptes) ou None pour tout le document. Retourne une liste de dict
    {'comp_id', 'body_name', 'params'} (un par corps)."""
    natives = None
    if bodies is not None:
        natives = set()
        for b in bodies:
            try:
                natives.add(_native_key(_body_context(b)[0]))
            except Exception:
                pass
    out = {}
    try:
        attrs = design.findAttributes(ATTR_GROUP, 'link')
    except Exception:
        attrs = []
    broken_links = set()
    for a in attrs:
        sk = adsk.fusion.Sketch.cast(a.parent)
        if sk is None:
            continue
        try:
            if sk.timelineObject.healthState != adsk.fusion.FeatureHealthStates.HealthyFeatureHealthState:
                broken_links.add(a.value)
        except Exception:
            pass
    for a in attrs:
        cf = adsk.fusion.CombineFeature.cast(a.parent) or adsk.fusion.ExtrudeFeature.cast(a.parent)
        if cf is None:
            continue
        try:
            bn = cf.attributes.itemByName(ATTR_GROUP, 'body_name')
            key = (cf.parentComponent.id, bn.value if bn else None)
            if key[1] is None or (natives is not None and key not in natives):
                continue
            pa = cf.attributes.itemByName(ATTR_GROUP, 'params')
            params = json.loads(pa.value) if pa else {}
            sa = cf.attributes.itemByName(ATTR_GROUP, 'sig')
            sig = json.loads(sa.value) if sa else None
            is_sk = adsk.fusion.ExtrudeFeature.cast(cf) is not None
            ok_sk = is_sk
            if is_sk:
                try:
                    ok_sk = (a.value not in broken_links and cf.timelineObject.healthState
                             == adsk.fusion.FeatureHealthStates.HealthyFeatureHealthState)
                except Exception:
                    ok_sk = False
            prev = out.get(key)
            if prev is not None:
                sig = None
                # le corps ne suit tout seul que si TOUS ses dogbones sont en esquisse saine
                ok_sk = ok_sk and prev.get('sketch_ok', False)
            out[key] = {'comp_id': key[0], 'body_name': key[1], 'params': params,
                        'sig': sig, 'sketch_ok': ok_sk}
        except Exception:
            _dbg('snapshot EXCEPTION: ' + traceback.format_exc())
    return list(out.values())


def restore_dogbones(design, snap):
    """Recree les dogbones memorises par snapshot_dogbones (a appeler apres
    remove_dogbones et la recreation des coupes). Retourne
    (n_ok, n_total, errors) : corps traites, corps attendus, messages."""
    errors = []
    if not snap:
        return 0, 0, errors
    comps = {}
    try:
        for c in design.allComponents:
            comps[c.id] = c
    except Exception:
        pass
    groups = {}
    for e in snap:
        comp = comps.get(e['comp_id'])
        body = comp.bRepBodies.itemByName(e['body_name']) if comp is not None else None
        if body is None:
            errors.append('Corps "%s" introuvable : dogbones non recrees.' % e['body_name'])
            continue
        p = e.get('params') or {}
        key = (float(p.get('diam_mm', DEFAULT_PREFS['diam_mm'])),
               float(p.get('jeu_mm', DEFAULT_PREFS['jeu_mm'])),
               bool(p.get('cnc_only', True)), p.get('manual_cuts'))
        groups.setdefault(key, []).append(body)
    n_ok = 0
    for (diam, jeu, cnc, manual), bodies in groups.items():
        try:
            res = create_dogbones(design, bodies, diam, jeu, cnc, manual)
            n_ok += res.get('n_bodies', 0)
            errors.extend(res.get('messages') or [])
        except Exception:
            errors.append(traceback.format_exc().strip().splitlines()[-1])
            _dbg('restore EXCEPTION: ' + traceback.format_exc())
    _dbg('restore: %d/%d corps' % (n_ok, len(snap)))
    return n_ok, len(snap), errors


def recreate_all_dogbones(design, bodies=None, force=False):
    """Retire puis recree les dogbones (des corps donnes, ou de tout le
    document), aux reglages d'origine, UNIQUEMENT pour les corps dont
    l'empreinte a change depuis la creation (force=True : tous). Pour Mettre
    a jour CNC, apres la recreation des coupes. Retourne
    (n_ok, n_total, errors) : corps refaits, corps a refaire, messages."""
    snap = snapshot_dogbones(design, bodies)
    if not snap:
        return 0, 0, []
    comps = {}
    try:
        for c in design.allComponents:
            comps[c.id] = c
    except Exception:
        pass
    stale = []
    for e in snap:
        changed = True
        if not force and e.get('sketch_ok'):
            changed = False  # dogbones en esquisse saines : ils suivent le corps
        elif not force and e.get('sig'):
            try:
                comp = comps.get(e['comp_id'])
                body = comp.bRepBodies.itemByName(e['body_name']) if comp else None
                if body is not None:
                    changed = _sig_changed(e['sig'], _body_sig(body))
            except Exception:
                _dbg('sig compare EXCEPTION: ' + traceback.format_exc())
        if changed:
            stale.append(e)
    _dbg('recreate_all: %d/%d corps modifies' % (len(stale), len(snap)))
    if not stale:
        return 0, 0, []
    remove_dogbones(design, keys=set((e['comp_id'], e['body_name']) for e in stale))
    return restore_dogbones(design, stale)


# --- Panneau de la palette CNC Toolkit ---------------------------------------
# ToolkitCNC.py transmet simplement tous les messages 'dogbone_*' a
# palette_message() : toute la logique du panneau vit ici, pour ne toucher
# le lanceur (partage avec les autres outils) que de quelques lignes.

_panel_open = False
_panel_palette = None
_panel_sel = []            # corps / occurrences accumules (clic = ajoute, re-clic = retire)
_panel_params = dict(DEFAULT_PREFS)
_panel_all = False
_panel_filters_saved = None
_panel_sel_handler = None
_panel_busy = False
_panel_last_event = None
_panel_pick = False        # mode "Selectionner" actif (bouton du panneau)
_panel_snapshot = set()    # cles de ui.activeSelections a la derniere lecture
_panel_empty_since = None  # selection de Fusion vide depuis (time.time())
_panel_echo = None         # (cles, heure) de la derniere selection videe par nous


def _send(action, payload):
    try:
        if _panel_palette is not None:
            _panel_palette.sendInfoToHTML(action, json.dumps(payload))
    except Exception:
        pass


def _restrict_selection():
    """Priorise corps + composants pendant que le panneau est ouvert (meme
    principe que les panneaux Tenons/Entaille), etat exact restaure a la
    fermeture."""
    global _panel_filters_saved
    try:
        sfs = _ui.activeWorkspace.selectionFilterSettings
        saved = {}
        for cat in sfs.availableFilters:
            try:
                saved[cat] = sfs.isFilterEnabled(cat)
                sfs.setFilterEnabled(cat, cat in ('BodySelectionCategory', 'ComponentInstanceSelectionCategory'))
            except Exception:
                pass
        # Panneau rouvert sans fermeture (rechargement de la palette...) :
        # on garde l'etat d'ORIGINE de l'utilisateur, jamais l'etat restreint.
        if _panel_filters_saved is None:
            _panel_filters_saved = saved
    except Exception:
        _panel_filters_saved = None


def _restore_selection():
    global _panel_filters_saved
    if not _panel_filters_saved:
        return
    try:
        sfs = _ui.activeWorkspace.selectionFilterSettings
        for cat, was in _panel_filters_saved.items():
            try:
                sfs.setFilterEnabled(cat, was)
            except Exception:
                pass
    except Exception:
        pass
    _panel_filters_saved = None


def _entity_label(e):
    try:
        o = adsk.fusion.Occurrence.cast(e)
        if o is not None:
            return o.name
        b = adsk.fusion.BRepBody.cast(e)
        if b is not None:
            return (b.assemblyContext.name + '/' if b.assemblyContext else '') + b.name
    except Exception:
        pass
    return '?'


def _sel_key(e):
    """Cle stable d'un corps ou d'une occurrence (les entityToken ne sont
    pas canoniques : deux lectures du meme corps peuvent differer)."""
    try:
        o = adsk.fusion.Occurrence.cast(e)
        if o is not None:
            return ('occ', o.fullPathName)
        b = adsk.fusion.BRepBody.cast(e)
        if b is not None:
            occ = b.assemblyContext
            nat = b.nativeObject if occ else b
            return ('body', occ.fullPathName if occ else '', nat.parentComponent.id, nat.name)
    except Exception:
        pass
    return None


def _same_entity(a, b):
    ka = _sel_key(a)
    return ka is not None and ka == _sel_key(b)


def _highlight_selection(keep_busy=False):
    """Remet TOUTE la liste du panneau en surbrillance dans la vue 3D."""
    global _panel_busy
    _panel_busy = True
    try:
        sels = _ui.activeSelections
        sels.clear()
        for e in _panel_sel:
            try:
                if e is not None and e.isValid:
                    sels.add(e)
            except Exception:
                pass
    except Exception:
        pass
    finally:
        _panel_busy = keep_busy


def _panel_bodies(design):
    if _panel_all:
        return collect_bodies(design, None)
    return collect_bodies(design, [e for e in _panel_sel if e is not None and e.isValid])


def _panel_refresh():
    """Recalcule la detection et le preview, et met a jour le panneau."""
    if not _panel_open:
        return
    try:
        design = adsk.fusion.Design.cast(_app.activeProduct)
        if design is None:
            return
        p = _panel_params
        n_sel = len(_panel_sel)
        if not _panel_all and n_sel == 0:
            clear_preview()
            _send('dogbone_selection', {'all': False, 'n_sel': 0, 'labels': [],
                                        'n_corners': 0, 'n_bodies': 0})
            return
        bodies = drop_pattern_copies(design, _panel_bodies(design))
        an = analyse(design, bodies, float(p['diam_mm']), float(p['jeu_mm']), bool(p['cnc_only']),
                     bool(p.get('manual_cuts', True)))
        draw_preview(design, an)
        if not _panel_all:
            _draw_selected(design, bodies)
        sm = summary(an)
        _send('dogbone_selection', {'all': _panel_all, 'n_sel': n_sel,
                                    'labels': [_entity_label(e) for e in _panel_sel][:8],
                                    'n_corners': sm['n_corners'], 'n_bodies': sm['n_bodies'],
                                    'n_scanned': len(bodies)})
    except Exception:
        _dbg('panel_refresh EXCEPTION: ' + traceback.format_exc())


def _entity_for_panel(e):
    """Corps ou occurrence a retenir pour une entite cliquee (une face ou
    une arete cliquee - autre filtre laisse actif par un autre panneau -
    donne son corps)."""
    e = getattr(e, 'entity', e)
    if adsk.fusion.BRepBody.cast(e) is not None or adsk.fusion.Occurrence.cast(e) is not None:
        return e
    for cls in (adsk.fusion.BRepFace, adsk.fusion.BRepEdge):
        x = cls.cast(e)
        if x is not None:
            return x.body
    return None


def _read_active():
    out = []
    seen = set()
    try:
        sels = _ui.activeSelections
        for i in range(sels.count):
            e = _entity_for_panel(sels.item(i).entity)
            k = _sel_key(e) if e is not None else None
            if k is not None and k not in seen:
                seen.add(k)
                out.append((k, e))
    except Exception:
        pass
    return out


def _sel_tick():
    """Compare la selection de Fusion a la derniere lecture et met a jour la
    liste du panneau. Appele en boucle par la palette (message
    'dogbone_tick', ~2,5 fois/s) tant que le mode "Selectionner" est actif,
    et aussi par activeSelectionChanged : ce dernier n'arrivait jamais chez
    l'utilisateur (journal vide le 2026-10-06), la lecture periodique ne depend
    plus de lui. La boucle est cote page HTML et pas dans un thread Python :
    elle repasse par le meme chemin que les boutons, qui marchent.

    Un clic simple de Fusion REMPLACE sa selection (journal du 2026-10-06 :
    toujours "1 dans Fusion"), et remettre toute la liste en surbrillance
    se faisait annuler au tick suivant, ce qui retirait le corps d'avant.
    On ne la remet donc plus en surbrillance : les corps retenus sont
    montres en bleu transparent par le preview.

    Regles (prev = selection de Fusion a la lecture precedente) :
    - clic simple sur un corps deja retenu = retire (bascule) ;
    - toute autre entite nouvelle (clic, ctrl-clic, fenetre) = ajoutee ;
    - entite qui disparait d'une selection multiple (ctrl-clic) = retiree ;
    - selection videe : retiree seulement si la liste du panneau est
      exactement ce que Fusion montrait, sinon (clic dans le vide apres
      des clics simples) la liste est gardee. Le vide doit durer 0,3 s :
      Fusion peut passer par une selection vide en remplacant la sienne.

    Depuis le retour de l'utilisateur (2026-10-06, 20:36) : apres chaque clic
    traite, on VIDE la selection de Fusion. Le bleu opaque de Fusion ne
    cache donc plus le preview, et un re-clic sur un corps retenu le retire
    aussitot (Fusion repart de vide : le clic est vu comme nouveau). Si
    Fusion remet le meme corps juste apres notre vidage, on revide sans
    rebasculer (meme genre d'annulation que pour la surbrillance)."""
    global _panel_sel, _panel_all, _panel_busy, _panel_snapshot, _panel_empty_since, _panel_echo
    if not (_panel_open and _panel_pick) or _panel_busy:
        return
    _panel_busy = True
    try:
        cur = _read_active()
        keys = set(k for k, _ in cur)
        if keys and _panel_echo and keys == _panel_echo[0] and time.time() - _panel_echo[1] < 0.6:
            _ui.activeSelections.clear()
            return
        prev = _panel_snapshot
        if keys:
            _panel_empty_since = None
        if keys == prev:
            return
        if not keys:
            now = time.time()
            if _panel_empty_since is None:
                _panel_empty_since = now
            if now - _panel_empty_since < 0.3:
                return
        _panel_empty_since = None
        _panel_snapshot = keys
        sel_keys = set(_sel_key(x) for x in _panel_sel)
        new = [(k, e) for k, e in cur if k not in prev]
        if new:
            if len(keys) == 1 and new[0][0] in sel_keys:
                _panel_sel = [x for x in _panel_sel if _sel_key(x) != new[0][0]]
            else:
                _panel_sel = _panel_sel + [e for k, e in new if k not in sel_keys]
        elif keys:
            gone = prev - keys
            _panel_sel = [x for x in _panel_sel if _sel_key(x) not in gone]
        elif sel_keys and sel_keys <= prev:
            _panel_sel = []
        changed = set(_sel_key(x) for x in _panel_sel) != sel_keys
        if keys:
            _ui.activeSelections.clear()
            _panel_snapshot = set()
            _panel_echo = (keys, time.time())
        _dbg('selection: %d dans Fusion, %d dans le panneau' % (len(keys), len(_panel_sel)))
        if changed:
            if _panel_all:
                _panel_all = False
                _send('dogbone_all', {'all': False})
            _panel_busy = False
            _panel_refresh()
            _panel_busy = True
    except Exception:
        _dbg('selection EXCEPTION: ' + traceback.format_exc())
    finally:
        _panel_busy = False


class _PanelSelectionHandler(adsk.core.ActiveSelectionEventHandler):
    def __init__(self):
        super().__init__()

    def notify(self, args):
        _sel_tick()


def _pick_start():
    """Bouton "Selectionner" : (re)branche les ecouteurs a chaque fois,
    comme le panneau Jonction (un handler branche au demarrage peut ne
    plus rien recevoir apres des rechargements d'add-ins)."""
    global _panel_pick, _panel_sel_handler, _panel_snapshot
    _pick_stop(notify=False)
    _restrict_selection()
    try:
        _panel_sel_handler = _PanelSelectionHandler()
        _ui.activeSelectionChanged.add(_panel_sel_handler)
        _handlers.append(_panel_sel_handler)
    except Exception:
        _dbg('pick handler EXCEPTION: ' + traceback.format_exc())
    _panel_snapshot = set(k for k, _ in _read_active())
    _panel_pick = True
    _dbg('mode selection ON (%d deja dans le panneau)' % len(_panel_sel))
    _send('dogbone_pick', {'on': True})


def _pick_stop(notify=True):
    global _panel_pick, _panel_sel_handler
    was = _panel_pick
    _panel_pick = False
    if _panel_sel_handler is not None:
        try:
            _ui.activeSelectionChanged.remove(_panel_sel_handler)
        except Exception:
            pass
        _panel_sel_handler = None
    if was:
        _dbg('mode selection OFF (%d corps/composants)' % len(_panel_sel))
    if notify:
        _send('dogbone_pick', {'on': False})


def _panel_open_fn():
    global _panel_open, _panel_sel, _panel_all, _panel_params
    _pick_stop(notify=False)
    _panel_open = True
    _panel_sel = []
    _panel_all = False
    _panel_params = load_prefs()
    try:
        _ui.activeSelections.clear()
    except Exception:
        pass
    _restrict_selection()
    _send('dogbone_init', _panel_params)
    _panel_refresh()


def _panel_close_fn():
    global _panel_open, _panel_sel, _panel_all
    was_open = _panel_open
    _pick_stop(notify=False)
    _panel_open = False
    _panel_sel = []
    _panel_all = False
    clear_preview()
    if not was_open:
        return
    try:
        _ui.activeSelections.clear()
    except Exception:
        pass
    _restore_selection()
    _send('dogbone_force_reset', {})


def _panel_params_from(data):
    p = dict(_panel_params)
    for k in ('diam_mm', 'jeu_mm'):
        try:
            v = float(data.get(k, p[k]))
            if v >= 0:
                p[k] = v
        except Exception:
            pass
    if 'cnc_only' in data:
        p['cnc_only'] = bool(data['cnc_only'])
    if 'manual_cuts' in data:
        p['manual_cuts'] = bool(data['manual_cuts'])
    if p['diam_mm'] <= 0:
        p['diam_mm'] = DEFAULT_PREFS['diam_mm']
    return p


def _panel_create():
    global _panel_sel, _panel_busy
    design = adsk.fusion.Design.cast(_app.activeProduct)
    p = _panel_params
    save_prefs(p)
    if not _panel_all and not _panel_sel:
        _send('dogbone_result', {'error': 'Selectionnez des corps ou cochez "Tout le modele".'})
        return
    _panel_busy = True
    try:
        with cnc_progress.Barre('Dogbone CNC', 'Creation des dogbones...'):
            res = create_dogbones(design, _panel_bodies(design), float(p['diam_mm']),
                                  float(p['jeu_mm']), bool(p['cnc_only']),
                                  bool(p.get('manual_cuts', True)))
    except Exception:
        res = {'error': traceback.format_exc().strip().splitlines()[-1], 'messages': []}
        _dbg('panel_create EXCEPTION: ' + traceback.format_exc())
    finally:
        _panel_busy = False
    _send('dogbone_result', res)
    if not res.get('error'):
        _panel_reset()
    _panel_refresh()


def _panel_reset():
    """Retour a l'etape 0 apres Creer / Retirer (demande de l'utilisateur) :
    plus de corps retenus, mode Selectionner arrete, rien de selectionne."""
    global _panel_sel, _panel_all, _panel_snapshot, _panel_echo
    _pick_stop()
    _panel_sel = []
    _panel_all = False
    _panel_snapshot = set()
    _panel_echo = None
    try:
        _ui.activeSelections.clear()
    except Exception:
        pass
    _send('dogbone_all', {'all': False})


def _panel_remove():
    global _panel_busy
    design = adsk.fusion.Design.cast(_app.activeProduct)
    if not _panel_all and not _panel_sel:
        _send('dogbone_result', {'error': 'Selectionnez des corps ou cochez "Tout le modele".'})
        return
    _panel_busy = True
    try:
        with cnc_progress.Barre('Dogbone CNC', 'Retrait des dogbones...'):
            n = remove_dogbones(design, None if _panel_all else _panel_bodies(design))
        _send('dogbone_result', {'error': None, 'removed': n, 'messages': []})
        _panel_reset()
    except Exception:
        _send('dogbone_result', {'error': traceback.format_exc().strip().splitlines()[-1]})
    finally:
        _panel_busy = False
    _panel_refresh()


def palette_message(palette, action, data):
    """Point d'entree unique appele par ToolkitCNC.HTMLEventHandler pour
    tous les messages 'dogbone_*' de palette.html."""
    global _panel_palette, _panel_params, _panel_all, _panel_sel, _panel_snapshot
    _panel_palette = palette
    try:
        if action == 'dogbone_open':
            _panel_open_fn()
        elif action == 'dogbone_close':
            _panel_close_fn()
        elif action == 'dogbone_params':
            _panel_params = _panel_params_from(data)
            _panel_refresh()
        elif action == 'dogbone_all':
            _panel_all = bool(data.get('all'))
            _panel_refresh()
        elif action == 'dogbone_deselect':
            _panel_sel = []
            _panel_all = False
            try:
                _ui.activeSelections.clear()
            except Exception:
                pass
            _panel_snapshot = set()
            _send('dogbone_all', {'all': False})
            _panel_refresh()
        elif action == 'dogbone_create':
            _panel_params = _panel_params_from(data)
            _panel_create()
        elif action == 'dogbone_remove':
            _panel_remove()
        elif action == 'dogbone_tick':
            _sel_tick()
        elif action == 'dogbone_pick':
            if data.get('on'):
                _pick_start()
            else:
                _pick_stop()
    except Exception:
        _dbg('palette_message EXCEPTION: ' + traceback.format_exc())
        _send('dogbone_result', {'error': traceback.format_exc().strip().splitlines()[-1]})


# --- Commande native (repli : recherche Fusion / palette) -------------------

def _read_inputs(inputs):
    sel = inputs.itemById('selection')
    ents = [sel.selection(i).entity for i in range(sel.selectionCount)] if sel else []
    tout = inputs.itemById('tout').value
    diam = inputs.itemById('diam').value * 10.0
    jeu = inputs.itemById('jeu').value * 10.0
    cnc = inputs.itemById('cnc_only').value
    man = inputs.itemById('manual_cuts')
    man = man.value if man else True
    return ents, tout, diam, jeu, cnc, man


class _CreatedHandler(adsk.core.CommandCreatedEventHandler):
    def notify(self, args):
        try:
            cmd = args.command
            inputs = cmd.commandInputs
            p = load_prefs()
            sel = inputs.addSelectionInput('selection', 'Corps / composants',
                                           'Corps ou composants a traiter')
            sel.addSelectionFilter('SolidBodies')
            sel.addSelectionFilter('Occurrences')
            sel.setSelectionLimits(0, 0)
            inputs.addBoolValueInput('tout', 'Tout le modele', True, '', False)
            inputs.addValueInput('diam', 'Diametre de fraise', 'mm',
                                 adsk.core.ValueInput.createByReal(p['diam_mm'] / 10.0))
            inputs.addValueInput('jeu', 'Jeu (rayon)', 'mm',
                                 adsk.core.ValueInput.createByReal(p['jeu_mm'] / 10.0))
            inputs.addBoolValueInput('cnc_only', 'Coupes CNC seulement', True, '', bool(p['cnc_only']))
            inputs.addBoolValueInput('manual_cuts', '+ entailles faites a la main', True, '',
                                     bool(p.get('manual_cuts', True)))
            for cls, ev in ((_ExecuteHandler, cmd.execute),
                            (_PreviewHandler, cmd.executePreview),
                            (_DestroyHandler, cmd.destroy)):
                h = cls()
                ev.add(h)
                _handlers.append(h)
        except Exception:
            _ui.messageBox('Dogbone CNC :\n' + traceback.format_exc())


class _PreviewHandler(adsk.core.CommandEventHandler):
    def notify(self, args):
        try:
            design = adsk.fusion.Design.cast(_app.activeProduct)
            ents, tout, diam, jeu, cnc, man = _read_inputs(args.command.commandInputs)
            if not ents and not tout:
                clear_preview()
                return
            bodies = drop_pattern_copies(design, collect_bodies(design, None if tout else ents))
            draw_preview(design, analyse(design, bodies, diam, jeu, cnc, man))
        except Exception:
            _dbg('preview EXCEPTION: ' + traceback.format_exc())


class _ExecuteHandler(adsk.core.CommandEventHandler):
    def notify(self, args):
        try:
            design = adsk.fusion.Design.cast(_app.activeProduct)
            ents, tout, diam, jeu, cnc, man = _read_inputs(args.command.commandInputs)
            save_prefs({'diam_mm': diam, 'jeu_mm': jeu, 'cnc_only': cnc, 'manual_cuts': man})
            bodies = collect_bodies(design, None if tout else ents)
            res = create_dogbones(design, bodies, diam, jeu, cnc, man)
            msg = '%d dogbone(s) sur %d corps.' % (res['n_corners'], res['n_bodies'])
            if res['messages']:
                msg += '\n\n' + '\n'.join(res['messages'])
            _ui.messageBox(msg, COMMAND_NAME)
        except Exception:
            _ui.messageBox('Dogbone CNC :\n' + traceback.format_exc())


class _DestroyHandler(adsk.core.CommandEventHandler):
    def notify(self, args):
        clear_preview()


def run(context):
    global _app, _ui
    try:
        _app = adsk.core.Application.get()
        _ui = _app.userInterface
        old = _ui.commandDefinitions.itemById(CMD_ID)
        if old:
            old.deleteMe()
        cmd_def = _ui.commandDefinitions.addButtonDefinition(CMD_ID, COMMAND_NAME, COMMAND_DESC, '')
        h = _CreatedHandler()
        cmd_def.commandCreated.add(h)
        _handlers.append(h)
    except Exception:
        if _ui:
            _ui.messageBox('Dogbone CNC - Erreur au demarrage :\n' + traceback.format_exc())


def stop(context):
    global _panel_sel_handler
    try:
        _panel_close_fn()
        _pick_stop(notify=False)
        cd = _ui.commandDefinitions.itemById(CMD_ID)
        if cd:
            cd.deleteMe()
        _handlers.clear()
    except Exception:
        pass
