# ---------------------------------------------------------------------------
# Historique des actions CNC Toolkit (demande de Maxence, 2026-11-01).
#
# PRINCIPE : chaque outil du Toolkit enregistre deja son travail dans UN
# groupe de chronologie replie ("Tenon CNC", "Mortaise CNC", "Entaille CNC",
# "Jonction 3", "Dogbone CNC", "Marge CNC", "Gravure CNC", "Reseau CNC"...).
# Aucun fichier JSON ni attribut supplementaire : l'historique est LU dans la
# chronologie du document actif, donc toujours exact (meme apres un undo, une
# suppression a la main ou une ouverture sur un autre PC).
#
# Actions (palette, panneau "Historique") :
#   - lister()      : actions regroupees par type, avec le nombre de corps
#   - apercu(id)    : selection native des corps + cadre orange (255,90,0)
#                     trait 4 en CustomGraphics (jamais de vraie matiere)
#   - modifier(id)  : deplie le groupe et place la chronologie juste apres
#                     lui ; l'utilisateur edite la fonction (double-clic)
#   - fin()         : remet la chronologie a la fin
#   - supprimer(id) : supprime le groupe ET son contenu (confirmation dans
#                     la palette)
# L'identifiant d'une action est (nom, index de debut) ; il est re-verifie a
# chaque appel car la chronologie peut avoir change entre-temps.
# ---------------------------------------------------------------------------
import adsk.core, adsk.fusion
import json, traceback, unicodedata

_cg = None  # groupe CustomGraphics de l'apercu
SUPPR_RESEAU = True  # valide le 2026-11-02 sur copie FS210 : 4 reseaux, 0 erreur

# (cle, libelle FR, prefixes de nom de groupe sans accent, minuscules)
TYPES = [
    ('tenon', 'Tenons', ('tenon',)),
    ('mortaise', 'Mortaises', ('mortaise',)),
    ('entaille', 'Entailles', ('entaille',)),
    ('jonction', 'Jonctions', ('jonction',)),
    ('dogbone', 'Dogbones', ('dogbone',)),
    ('marge', 'Marges', ('marge', 'modif marge')),
    ('gravure', 'Gravures', ('gravure',)),
    ('reseau', 'Reseaux', ('reseau', 'nouveau corps')),
    ('traverse', 'Traverses', ('traverse',)),
]
# Types dont la fonction peut etre editee directement dans la chronologie
MODIFIABLES = {'tenon', 'mortaise', 'entaille', 'jonction', 'dogbone', 'marge', 'gravure', 'reseau', 'traverse'}


def _sans_accent(s):
    return ''.join(c for c in unicodedata.normalize('NFD', s or '')
                   if unicodedata.category(c) != 'Mn').lower().strip()


def _type_de(nom):
    n = _sans_accent(nom)
    for cle, _lib, prefs in TYPES:
        for p in prefs:
            if n.startswith(p):
                return cle
    return None


def _design():
    app = adsk.core.Application.get()
    d = app.activeProduct
    return d if isinstance(d, adsk.fusion.Design) else adsk.fusion.Design.cast(d)


def _corps_du_groupe(tl, g):
    """Corps valides produits par les fonctions du groupe (sans doublon)."""
    vus, res = set(), []
    for j in range(g.count):
        try:
            ent = g.item(j).entity
        except Exception:
            continue
        bodies = getattr(ent, 'bodies', None)
        if bodies is None:
            continue
        try:
            for k in range(bodies.count):
                b = bodies.item(k)
                if b.isValid and b.entityToken not in vus:
                    vus.add(b.entityToken)
                    res.append(b)
        except Exception:
            pass
    return res


def _debut(g):
    """Identifiant stable du groupe : jeton de sa 1re fonction. Ni g.index
    (leve une erreur des que le groupe est deplie) ni l'index de ses
    fonctions (invalide tant qu'il est replie) ne sont utilisables - constate
    en test."""
    try:
        return g.item(0).entity.entityToken
    except Exception:
        return ''


def _trouver(tl, nom, debut):
    """Retrouve le groupe (nom, index de debut) ; None s'il a disparu."""
    for i in range(tl.timelineGroups.count):
        g = tl.timelineGroups.item(i)
        if g.name == nom and _debut(g) == debut:
            return g
    return None


def lister():
    """{'ok', 'groupes': [{'cle','titre','actions':[...]}], 'marqueur_fin'}"""
    design = _design()
    if design is None:
        return {'ok': False, 'raison': 'pas_de_design', 'groupes': []}
    tl = design.timeline
    par_type = {cle: [] for cle, _l, _p in TYPES}
    for i in range(tl.timelineGroups.count):
        g = tl.timelineGroups.item(i)
        cle = _type_de(g.name)
        if cle is None:
            continue
        corps = _corps_du_groupe(tl, g)
        par_type[cle].append({
            'nom': g.name, 'debut': _debut(g), 'ordre': i,
            'corps': len(corps),
            'noms': [b.name for b in corps[:4]],
            'modifiable': cle in MODIFIABLES,
            'supprime': bool(g.isSuppressed) if hasattr(g, 'isSuppressed') else False,
        })
    groupes = []
    for cle, lib, _p in TYPES:
        acts = sorted(par_type[cle], key=lambda a: a['ordre'], reverse=True)  # recentes d'abord
        if acts:
            groupes.append({'cle': cle, 'titre': lib, 'actions': acts})
    return {'ok': True, 'groupes': groupes,
            'a_la_fin': tl.markerPosition == tl.count}


def effacer_apercu():
    global _cg
    try:
        if _cg is not None:
            _cg.deleteMe()
    except Exception:
        pass
    _cg = None


def _cadre(b):
    """12 aretes de la boite englobante en coordonnees monde (liste de
    points a plat, longueurs de bandes) ou None."""
    bb = b.boundingBox
    mn, mx = bb.minPoint, bb.maxPoint
    pts = [(x, y, z) for x in (mn.x, mx.x) for y in (mn.y, mx.y) for z in (mn.z, mx.z)]
    tr = None
    try:
        if b.assemblyContext is not None:
            tr = b.assemblyContext.transform2
    except Exception:
        tr = None
    if tr is not None:
        out = []
        for (x, y, z) in pts:
            p = adsk.core.Point3D.create(x, y, z)
            p.transformBy(tr)
            out.append((p.x, p.y, p.z))
        pts = out
    # indices des sommets : bit0=z, bit1=y, bit2=x
    aretes = [(0, 1), (2, 3), (4, 5), (6, 7), (0, 2), (1, 3), (4, 6), (5, 7),
              (0, 4), (1, 5), (2, 6), (3, 7)]
    flat, strips = [], []
    for a, c in aretes:
        flat.extend(pts[a]); flat.extend(pts[c]); strips.append(2)
    return flat, strips


def apercu(nom, debut):
    """Selectionne les corps de l'action et dessine leur cadre orange."""
    effacer_apercu()
    global _cg
    app = adsk.core.Application.get()
    design = _design()
    tl = design.timeline
    g = _trouver(tl, nom, debut)
    if g is None:
        return {'ok': False, 'raison': 'introuvable'}
    corps = _corps_du_groupe(tl, g)
    sels = app.userInterface.activeSelections
    sels.clear()
    n_sel = 0
    for b in corps:
        try:
            sels.add(b)
            n_sel += 1
        except Exception:
            pass
    flat, strips = [], []
    for b in corps:
        try:
            f, s = _cadre(b)
            flat.extend(f); strips.extend(s)
        except Exception:
            pass
    if flat:
        try:
            _cg = design.rootComponent.customGraphicsGroups.add()
            coords = adsk.fusion.CustomGraphicsCoordinates.create(flat)
            lignes = _cg.addLines(coords, [], True, strips)
            lignes.color = adsk.fusion.CustomGraphicsSolidColorEffect.create(
                adsk.core.Color.create(255, 90, 0, 255))
            lignes.weight = 4.0
        except Exception:
            effacer_apercu()
    return {'ok': True, 'corps': len(corps), 'selectionnes': n_sel}


def _module(sous_nom):
    import sys
    for k in list(sys.modules):
        if sous_nom in k:
            return sys.modules[k]
    return None


def _rouvrir_dans_outil(g):
    """Rouvre la fenetre de l'outil sur cette action si l'outil le permet.
    Renvoie (nom de l'outil ou None, message d'echec ou None).
    Reseau CNC : ReseauTrajectoireCNC._info_reseau + _demarrer_edition (comme
    un double-clic sur le reseau). Jonction CNC : JonctionCNC.edit_groups
    (reglages memorises a la creation ; les anciennes jonctions n'en ont pas)."""
    try:
        nm = _sans_accent(g.name)
        if nm.startswith('reseau'):
            m = _module('ReseauTrajectoireCNC')
            if m is not None and hasattr(m, '_info_reseau') and hasattr(m, '_demarrer_edition'):
                info = m._info_reseau(g)
                if info:
                    m._demarrer_edition(info)
                    return 'Reseau CNC', None
        elif nm.startswith('jonction'):
            return _rouvrir_jonctions([g])
        elif nm.startswith('traverse'):
            m = _module('TraverseCNC')
            if m is None or not hasattr(m, 'edit_group'):
                return None, 'Traverse de renfort CNC n\'est pas actif (ou pas a jour) : relance l\'add-in.'
            ok, msg = m.edit_group(g)
            return ('Traverse CNC' if ok else None), (None if ok else msg)
    except Exception as e:
        return None, str(e)[:200]
    return None, None


def _rouvrir_jonctions(groupes):
    jm = _module('JonctionCNC')
    if jm is None or not hasattr(jm, 'edit_groups'):
        return None, 'Jonction CNC n\'est pas actif (ou pas a jour) : relance l\'add-in.'
    ok, msg = jm.edit_groups(groupes)
    return ('Jonction CNC' if ok else None), (None if ok else msg)


def modifier_type(cle):
    """« Modifier toutes » : toutes les jonctions du document qui ont des
    reglages memorises sont rouvertes ensemble (une ligne par coupe)."""
    if cle != 'jonction':
        return {'ok': False, 'erreur': 'Non disponible pour ce type.'}
    design = _design()
    tl = design.timeline
    jm = _module('JonctionCNC')
    if jm is None or not hasattr(jm, '_entrees_groupe'):
        return {'ok': False, 'erreur': 'Jonction CNC n\'est pas actif (ou pas a jour) : relance l\'add-in.'}
    effacer_apercu()
    groupes = []
    for i in range(tl.timelineGroups.count):
        g = tl.timelineGroups.item(i)
        if _type_de(g.name) == 'jonction' and jm._entrees_groupe(g):
            groupes.append(g)
    if not groupes:
        return {'ok': False, 'erreur': 'Aucune jonction avec reglages memorises (creees avant cette version).'}
    outil, msg = _rouvrir_jonctions(groupes)
    if outil:
        return {'ok': True, 'outil': outil, 'n': len(groupes)}
    return {'ok': False, 'erreur': msg or 'Echec.'}


def modifier(nom, debut):
    """Deplie le groupe et place la chronologie juste apres lui."""
    design = _design()
    tl = design.timeline
    g = _trouver(tl, nom, debut)
    if g is None:
        return {'ok': False, 'raison': 'introuvable'}
    effacer_apercu()
    # Outil qui sait rouvrir sa propre fenetre sur cette action : on lui
    # laisse la main (Reseau CNC : boite d'origine + reglages du chemin).
    ouvert, info = _rouvrir_dans_outil(g)
    if ouvert:
        return {'ok': True, 'outil': ouvert}
    try:
        g.isCollapsed = False
    except Exception:
        pass
    # groupe deplie : les index de ses fonctions sont valides
    tl.markerPosition = g.item(g.count - 1).index + 1  # juste apres le groupe
    return {'ok': True, 'info': info}


def fin():
    _design().timeline.moveToEnd()
    return {'ok': True}


def _en_erreur(tl):
    """{jeton: [index, nom, message]} des fonctions de la chronologie en erreur."""
    res = {}
    for k in range(tl.count):
        o = tl.item(k)
        try:
            msg = o.errorOrWarningMessage or ''
            if int(o.healthState) in (1, 2) or msg:
                res[o.entity.entityToken] = [k, o.name, msg[:80]]
        except Exception:
            pass
    return res


def _supprimer_groupe(tl, nom, debut):
    """Supprime un groupe en plusieurs tentatives. (ok, erreur)."""
    err = None
    # 1) suppression directe
    g = _trouver(tl, nom, debut)
    if g is None:
        return True, None
    try:
        if g.deleteMe(True):
            return True, None
    except Exception as e:
        err = str(e)[:200]
    # 2) chronologie reculee au debut du groupe (rien apres n'est calcule)
    try:
        g = _trouver(tl, nom, debut)
        if g is None:
            return True, None
        g.isCollapsed = False
        tl.markerPosition = g.item(0).index
        g = _trouver(tl, nom, debut)
        ok = bool(g.deleteMe(True)) if g is not None else True
        tl.moveToEnd()
        if ok:
            return True, None
    except Exception as e:
        err = str(e)[:200]
        try:
            tl.moveToEnd()
        except Exception:
            pass
    # 3) fonctions du groupe de la derniere a la premiere (ne sert qu'APRES la
    # purge : plus aucune dependance, verifie sur copie : 7/7 supprimees)
    try:
        g = _trouver(tl, nom, debut)
        if g is None:
            return True, None
        toks = [g.item(i).entity.entityToken for i in range(g.count)]
        g.isCollapsed = False
        pb = None
        for tok in reversed(toks):
            ent = adsk.core.Application.get().activeProduct.findEntityByToken(tok)
            if ent:
                try:
                    ent[0].deleteMe()
                except Exception as e:
                    pb = str(e)[:200]
        if _trouver(tl, nom, debut) is None:
            return True, None
        err = pb or err
    except Exception as e:
        err = str(e)[:200]
    return False, err


def _supprimer_reseau(design, tl, g, nom, debut):
    """Suppression d'un reseau (2026-11-02), comme l'a demande Maxence :
    1) Purger CNC sur les corps du reseau (PurgeCNC.purge retire les trous de
    mortaise, jeux, dogbones... que ces copies ont faits ; un seul Ctrl+Z) ;
    2) suppression du groupe du reseau ; 3) les fonctions qui s'appuyaient sur
    ses copies et passent en erreur (ex. Extrusion sur une face de copie) sont
    supprimees aussi (choix de Maxence), sans toucher a ce qui etait deja en
    erreur avant. Jamais de suppression de fonction une a une dans le reseau."""
    pm = _module('PurgeCNC')
    if pm is None or not hasattr(pm, 'purge'):
        return {'ok': False, 'erreur': 'Purger CNC n\'est pas actif : demarre l\'add-in PurgeCNC (Maj+S).'}
    corps = _corps_du_groupe(tl, g)
    if not corps:
        return {'ok': False, 'erreur': 'Reseau sans corps : rien a purger.'}
    base = _en_erreur(tl)
    cp = _module('cnc_progress')
    try:
        if cp is not None and hasattr(cp, 'Barre'):
            with cp.Barre('Historique CNC', 'Suppression du reseau...', total=6):
                r = pm.purge(design, corps)
        else:
            r = pm.purge(design, corps)
    except Exception as e:
        return {'ok': False, 'erreur': 'Purge : ' + str(e)[:300]}
    ok, err = _supprimer_groupe(tl, nom, debut)
    supprimees = []
    if ok:
        for _tour in range(3):
            nouveaux = [(t, v) for t, v in _en_erreur(tl).items() if t not in base]
            if not nouveaux:
                break
            for t, v in sorted(nouveaux, key=lambda x: -x[1][0]):
                try:
                    ent = design.findEntityByToken(t)
                    if ent and ent[0].deleteMe():
                        supprimees.append(v[1])
                except Exception:
                    pass
    res = {'ok': ok, 'purge': r.get('n_features', 0), 'dogbones': r.get('n_dogbones', 0),
           'dependants': supprimees}
    if not ok:
        res['erreur'] = ('Coupes purgees, mais le reseau n\'a pas pu etre supprime : ' + (err or '')
                         + ' (Ctrl+Z annule tout).')
    return res


def supprimer(nom, debut):
    """Supprime le groupe et tout son contenu."""
    design = _design()
    tl = design.timeline
    g = _trouver(tl, nom, debut)
    if g is None:
        return {'ok': False, 'raison': 'introuvable'}
    effacer_apercu()
    adsk.core.Application.get().userInterface.activeSelections.clear()
    # Reseau CNC : voir _supprimer_reseau (Purger CNC puis suppression du
    # groupe). Tant que SUPPR_RESEAU est False (pas valide sur une copie),
    # on refuse : le premier essai (2026-11-02) avait casse la chronologie.
    nm = _sans_accent(g.name)
    if nm.startswith('reseau') and SUPPR_RESEAU:
        return _supprimer_reseau(design, tl, g, nom, debut)
    if nm.startswith('reseau') or nm.startswith('nouveau corps'):
        return {'ok': False, 'erreur': 'Suppression des reseaux desactivee : supprime-le dans la chronologie Fusion (clic droit > Supprimer).'}
    n_dogbones = 0
    # True = supprime aussi les fonctions du groupe (isDeletable reste False
    # pour un groupe replie, mais deleteMe(True) fonctionne)
    erreurs = []
    ok = False
    try:
        ok = bool(g.deleteMe(True))
    except Exception as e:
        erreurs.append('deleteMe: ' + str(e)[:200])
    res = {'ok': ok, 'dogbones': n_dogbones}
    if erreurs and not ok:
        res['erreur'] = ' | '.join(erreurs)[:400]
    return res



def dispatch(action, data):
    """Appele par ToolkitCNC (messages 'historique_*' de la palette).
    Renvoie (nom_message, dict) a renvoyer a la page."""
    try:
        try:
            return _dispatch(action, data)
        except Exception:
            r = {'ok': False, 'erreur': traceback.format_exc()[-300:]}
            etat = lister()
            etat['retour'] = dict(r, action=action)
            return 'historique_etat', etat
    except Exception:
        return 'historique_etat', {'ok': False, 'raison': 'erreur', 'detail': traceback.format_exc(), 'groupes': []}


def _dispatch(action, data):
    try:
        if action == 'historique_apercu':
            r = apercu(data.get('nom', ''), str(data.get('debut', '')))
        elif action == 'historique_modifier':
            r = modifier(data.get('nom', ''), str(data.get('debut', '')))
        elif action == 'historique_modifier_type':
            r = modifier_type(str(data.get('cle', '')))
        elif action == 'historique_fin':
            r = fin()
        elif action == 'historique_supprimer':
            r = supprimer(data.get('nom', ''), str(data.get('debut', '')))
        elif action == 'historique_close':
            effacer_apercu()
            r = {'ok': True}
        else:  # historique_open / historique_liste
            r = {'ok': True}
        if action in ('historique_apercu', 'historique_close'):
            # pas de re-liste : on garde l'etat de la page
            return 'historique_retour', dict(r, action=action)
        etat = lister()
        etat['retour'] = dict(r, action=action)
        return 'historique_etat', etat
    except Exception:
        raise
