"""Raccourcis clavier des outils CNC Toolkit (2026-10-12).

Fusion n'offre aucune API pour attribuer un raccourci a une commande : ce
module les gere lui-meme. Les combinaisons sont enregistrees aupres de
Windows (RegisterHotKey) depuis un petit fil d'arriere-plan, UNIQUEMENT
pendant que Fusion est la fenetre au premier plan : dans les autres
applications, les touches restent libres. Quand une combinaison est
pressee, un evenement personnalise Fusion ramene l'appel sur le thread
principal (seul autorise a toucher l'API) et ToolkitCNC lance l'outil.

Reglages : raccourcis_clavier.json, a cote de ce fichier, par poste.
"""
import os, json, time, threading, sys

import adsk.core

FICHIER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'raccourcis_clavier.json')
EVENT_ID = 'ToolkitCNC_RaccourciClavier'
ETAT = '__etat__'  # additionalInfo envoye quand l'etat d'enregistrement change

MOD_ALT, MOD_CTRL, MOD_SHIFT, MOD_NOREPEAT = 0x1, 0x2, 0x4, 0x4000
WM_HOTKEY = 0x0312

# Combinaisons deja prises par Fusion ou par Windows, ou qui empechent de
# taper un caractere (Ctrl+Alt = AltGr sur clavier AZERTY : euro, @, #...).
RESERVES = {
    'Ctrl+Z': 'Annuler (Fusion)', 'Ctrl+Y': 'Retablir (Fusion)',
    'Ctrl+C': 'Copier (Fusion)', 'Ctrl+V': 'Coller (Fusion)', 'Ctrl+X': 'Couper (Fusion)',
    'Ctrl+S': 'Enregistrer (Fusion)', 'Ctrl+Shift+S': 'Enregistrer sous (Fusion)',
    'Ctrl+N': 'Nouveau document (Fusion)', 'Ctrl+O': 'Ouvrir (Fusion)',
    'Ctrl+P': 'Imprimer (Fusion)', 'Ctrl+W': 'Fermer le document (Fusion)',
    'Ctrl+A': 'Tout selectionner', 'Ctrl+F': 'Rechercher', 'Ctrl+Shift+Z': 'Retablir',
    'Alt+F4': 'Fermer la fenetre (Windows)', 'F1': 'Aide (Fusion)',
}
ALTGR = set('E234567890')


def _nom_touche(vk):
    if 0x41 <= vk <= 0x5A or 0x30 <= vk <= 0x39:
        return chr(vk)
    if 0x70 <= vk <= 0x7B:
        return 'F%d' % (vk - 0x6F)
    return None


def _vk_touche(nom):
    if len(nom) == 1 and (nom.isdigit() or 'A' <= nom <= 'Z'):
        return ord(nom)
    if nom.startswith('F') and nom[1:].isdigit() and 1 <= int(nom[1:]) <= 12:
        return 0x6F + int(nom[1:])
    return None


def normaliser(combo):
    """'shift+ctrl+t' -> 'Ctrl+Shift+T' ; None si illisible."""
    if not combo:
        return None
    parts = [p.strip() for p in str(combo).split('+') if p.strip()]
    if not parts:
        return None
    mods = {p.lower() for p in parts[:-1]}
    if not mods <= {'ctrl', 'alt', 'shift'}:
        return None
    touche = parts[-1].upper()
    if _vk_touche(touche) is None:
        return None
    ordre = [m for m in ('Ctrl', 'Alt', 'Shift') if m.lower() in mods]
    return '+'.join(ordre + [touche])


def analyser(combo):
    """'Ctrl+Shift+T' -> (modificateurs Windows, code de touche)."""
    parts = combo.split('+')
    mods = 0
    for p in parts[:-1]:
        mods |= {'Ctrl': MOD_CTRL, 'Alt': MOD_ALT, 'Shift': MOD_SHIFT}[p]
    return mods, _vk_touche(parts[-1])


def charger():
    try:
        with open(FICHIER, 'r', encoding='utf-8') as f:
            d = json.load(f)
        brut = d.get('raccourcis', {}) if isinstance(d, dict) else {}
    except Exception:
        return {}
    out = {}
    for cmd, combo in brut.items():
        c = normaliser(combo)
        if c:
            out[cmd] = c
    return out


def _sauver(raccourcis):
    tmp = FICHIER + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump({'version': 1, 'raccourcis': raccourcis}, f, indent=2, ensure_ascii=False)
    os.replace(tmp, FICHIER)


def verifier(combo, cmd, raccourcis, noms):
    """Message d'erreur (str) si la combinaison ne peut pas etre attribuee a
    cmd, sinon None. noms : cmd -> nom affiche, pour citer l'outil en
    conflit."""
    c = normaliser(combo)
    if c is None:
        return 'Combinaison non prise en charge (lettre, chiffre ou F1 a F12, avec Ctrl, Alt ou Maj).'
    parts = c.split('+')
    mods, touche = parts[:-1], parts[-1]
    if not touche.startswith('F') or len(touche) == 1:
        if 'Ctrl' not in mods and 'Alt' not in mods:
            return 'Ajoute Ctrl ou Alt : une lettre ou un chiffre seul empecherait de taper du texte dans Fusion.'
    if c in RESERVES:
        return '%s est deja utilise : %s.' % (c, RESERVES[c])
    if 'Ctrl' in mods and 'Alt' in mods and 'Shift' not in mods and touche in ALTGR:
        return '%s = AltGr+%s sur clavier AZERTY (caractere special) : choisis une autre touche.' % (c, touche)
    for autre, ac in raccourcis.items():
        if autre != cmd and ac == c:
            return '%s est deja attribue a "%s".' % (c, noms.get(autre, autre))
    return None


class _Fil(threading.Thread):
    """Enregistre les combinaisons aupres de Windows tant que Fusion est au
    premier plan et relaie WM_HOTKEY vers Fusion (evenement personnalise)."""

    def __init__(self, app):
        super().__init__(name='ToolkitCNC_Raccourcis', daemon=True)
        self.app = app
        self.arret = threading.Event()
        self.verrou = threading.Lock()
        self.raccourcis = charger()
        self.sale = True
        self.pause_jusqua = 0.0
        self.echecs = set()  # cmd dont la combinaison est prise par une autre application

    def recharger(self, raccourcis):
        with self.verrou:
            self.raccourcis = dict(raccourcis)
            self.sale = True

    def run(self):
        import ctypes
        from ctypes import wintypes as wt
        u = ctypes.WinDLL('user32', use_last_error=True)
        u.RegisterHotKey.argtypes = [wt.HWND, ctypes.c_int, wt.UINT, wt.UINT]
        u.UnregisterHotKey.argtypes = [wt.HWND, ctypes.c_int]
        u.PeekMessageW.argtypes = [ctypes.POINTER(wt.MSG), wt.HWND, wt.UINT, wt.UINT, wt.UINT]
        u.MsgWaitForMultipleObjects.argtypes = [wt.DWORD, ctypes.c_void_p, wt.BOOL, wt.DWORD, wt.DWORD]
        u.GetForegroundWindow.restype = wt.HWND
        u.GetWindowThreadProcessId.argtypes = [wt.HWND, ctypes.POINTER(wt.DWORD)]
        pid = os.getpid()
        msg = wt.MSG()
        u.PeekMessageW(ctypes.byref(msg), None, 0, 0, 0)  # cree la file de messages du fil
        actifs = {}  # id -> cmd
        enregistre = False

        def tout_retirer():
            for i in list(actifs):
                u.UnregisterHotKey(None, i)
            actifs.clear()

        while not self.arret.is_set():
            u.MsgWaitForMultipleObjects(0, None, False, 100, 0x04FF)
            while u.PeekMessageW(ctypes.byref(msg), None, 0, 0, 1):
                if msg.message == WM_HOTKEY and msg.wParam in actifs:
                    try:
                        self.app.fireCustomEvent(EVENT_ID, actifs[msg.wParam])
                    except Exception:
                        pass
            fg = u.GetForegroundWindow()
            proc = wt.DWORD(0)
            if fg:
                u.GetWindowThreadProcessId(fg, ctypes.byref(proc))
            voulu = bool(fg) and proc.value == pid and time.time() >= self.pause_jusqua
            with self.verrou:
                sale = self.sale
                self.sale = False
                raccourcis = dict(self.raccourcis)
            if not sale and voulu == enregistre:
                continue
            tout_retirer()
            enregistre = voulu
            if not voulu:
                continue
            echecs = set()
            for n, (cmd, combo) in enumerate(sorted(raccourcis.items()), start=1):
                mods, vk = analyser(combo)
                if u.RegisterHotKey(None, n, mods | MOD_NOREPEAT, vk):
                    actifs[n] = cmd
                else:
                    echecs.add(cmd)
            if echecs != self.echecs:
                self.echecs = echecs
                try:
                    self.app.fireCustomEvent(EVENT_ID, ETAT)
                except Exception:
                    pass
        tout_retirer()


_fil = None
_evt = None
_handler = None


class _Handler(adsk.core.CustomEventHandler):
    def __init__(self, rappel):
        super().__init__()
        self.rappel = rappel

    def notify(self, args):
        try:
            self.rappel(args.additionalInfo)
        except Exception:
            pass


def demarrer(app, rappel):
    """rappel(cmd) est appele sur le thread principal de Fusion quand un
    raccourci est presse (ou avec ETAT quand une combinaison n'a pas pu etre
    enregistree)."""
    global _fil, _evt, _handler
    arreter(app)
    if sys.platform != 'win32':
        return
    try:
        app.unregisterCustomEvent(EVENT_ID)
    except Exception:
        pass
    _evt = app.registerCustomEvent(EVENT_ID)
    _handler = _Handler(rappel)
    _evt.add(_handler)
    _fil = _Fil(app)
    _fil.start()


def arreter(app):
    global _fil, _evt, _handler
    if _fil is not None:
        _fil.arret.set()
        _fil.join(1.0)
        _fil = None
    if _evt is not None:
        try:
            _evt.remove(_handler)
        except Exception:
            pass
        try:
            app.unregisterCustomEvent(EVENT_ID)
        except Exception:
            pass
        _evt = None
        _handler = None


def pause(active):
    """Suspend les raccourcis pendant que l'utilisateur saisit une nouvelle
    combinaison dans la palette (sinon Windows l'intercepterait). Reprise
    automatique apres 30 s si la palette est fermee en pleine saisie."""
    if _fil is not None:
        _fil.pause_jusqua = time.time() + 30 if active else 0.0


def attribuer(cmd, combo, noms):
    """Attribue (combo) ou retire (combo vide) le raccourci de cmd.
    Renvoie un message d'erreur, ou None si c'est enregistre."""
    raccourcis = charger()
    if combo:
        err = verifier(combo, cmd, raccourcis, noms)
        if err:
            return err
        raccourcis[cmd] = normaliser(combo)
    else:
        raccourcis.pop(cmd, None)
    _sauver(raccourcis)
    if _fil is not None:
        _fil.recharger(raccourcis)
    return None


def etat():
    """{'raccourcis': {cmd: combo}, 'echecs': [cmd...], 'actif': bool}"""
    return {
        'raccourcis': charger(),
        'echecs': sorted(_fil.echecs) if _fil is not None else [],
        'actif': _fil is not None,
    }
