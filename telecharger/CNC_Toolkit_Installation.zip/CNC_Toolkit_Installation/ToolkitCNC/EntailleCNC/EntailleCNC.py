import adsk.core
import adsk.fusion
import traceback
import os
import json
import sys

# Barre de chargement commune du Toolkit (ToolkitCNC/cnc_progress.py)
_TK_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _TK_DIR not in sys.path:
    sys.path.append(_TK_DIR)
import cnc_progress

_app              = None
_ui               = None
_cmd_def_create   = None
_cmd_def_edit     = None
_panel_ctrl       = None
_custom_feat_def  = None
_compute_handler  = None
_marking_handler  = None

_create_created   = None
_create_execute   = None
_create_destroy   = None
_edit_created     = None
_edit_execute     = None
_edit_destroy     = None

# Nom de la CF ciblee par le clic droit
_cf_cible_name = None

# ---------------------------------------------------------------------------
# Entaille CNC (ex "Entaille Automatique", renomme a la demande de
# l'utilisateur pour rester coherent avec le reste de la suite CNC Toolkit :
# TenonCNC, MortaiseCNC, MargeCNC, ...).
#
# Entailles a MI-BOIS entre deux corps (ou un corps cible + plusieurs corps
# de decoupe) : les corps doivent deja etre modelises en INTERPENETRATION
# dans Fusion, positionnes comme s'ils etaient assembles (chaque panneau
# empietant sur l'autre a l'endroit du croisement) - cette zone de
# recouvrement vient entierement du positionnement choisi par l'utilisateur
# dans son modele, PAS d'un calcul fait ici.
#
# PRINCIPE DU "RETRAIT DE PROFONDEUR" (redefini le 2026-10-01 suite a un
# retour utilisateur apres premier test live - voir aussi le "premier jet"
# precedent dans l'historique de session, qui appliquait un petit jeu de
# fond symetrique sur les DEUX corps : ce n'etait pas le comportement
# voulu) : PAR DEFAUT (retrait = 0), toute la profondeur du recouvrement
# est retiree du corps CIBLE uniquement - le corps outil n'est PAS entaille
# du tout (il s'insere simplement dans l'entaille de la cible, cas le plus
# courant : rainure/dado). Si un retrait de profondeur > 0 est renseigne,
# cette profondeur est RETRANCHEE a la cible (son entaille devient moins
# profonde d'autant) et REPORTEE A L'IDENTIQUE sur chaque corps outil (qui
# recoit alors sa propre entaille, de cette meme profondeur, a l'endroit du
# croisement) - jusqu'a un mi-bois symetrique classique si le retrait vaut
# la moitie de l'epaisseur du recouvrement.
#
# Mecanisme (verifie en direct, methode tres simple - aucune copie de
# corps necessaire) :
#   1) Decoupe de la cible par TOUS les corps outils, recouvrement COMPLET
#      (un corps utilise comme OUTIL dans une decoupe n'est jamais modifie
#      par l'operation, donc aucune copie n'est necessaire pour cette
#      etape - seule la cible change).
#   2) Si retrait > 0 : la face de FOND nouvellement creee sur la cible est
#      decalee de +retrait (OffsetFacesFeature, sens qui REND de la matiere
#      - verifie en direct : la cavite devient moins profonde d'exactement
#      cette valeur).
#   3) Decoupe de CHAQUE corps outil en utilisant la cible dans son etat
#      FINAL (apres l'eventuel decalage de l'etape 2) comme outil : comme
#      la cible a "repris" exactement <retrait> de profondeur de matiere a
#      l'etape 2, cette decoupe retire du corps outil PRECISEMENT cette
#      meme profondeur, a l'endroit du croisement - aucun calcul
#      supplementaire necessaire, c'est une consequence geometrique directe
#      de l'etape 2. A retrait=0, cette decoupe est un no-op verifie (les
#      deux corps sont exactement coincidents a cet endroit, volume retire
#      nul) donc elle est simplement omise.
#
# CORRECTIONS apportees par rapport a l'ancienne version "Entaille
# Automatique" (bugs probables derriere le "pas au point" signale par
# l'utilisateur) :
#
#   1) Decoupe reciproque : l'ancienne version decoupait chaque corps outil
#      en utilisant le corps CIBLE DEJA ENTAILLE (modifie par la 1ere
#      decoupe, SANS tenir compte du retrait de profondeur) comme outil -
#      elle retirait donc TOUJOURS le recouvrement complet du cote outil
#      (jamais "tout sur la cible" par defaut), sans lien reglable avec le
#      champ retrait. Le mecanisme ci-dessus restaure un lien direct et
#      reglable entre le retrait de profondeur et ce qui est retire de
#      chaque cote.
#
#   2) Separation fond/parois laterales : l'ancienne version comparait le
#      nombre de faces par aire AVANT/APRES la decoupe pour deviner quelles
#      faces etaient "nouvelles" puis un seuil d'aire (epaisseur^2, en
#      supposant une entaille de section CARREE) pour deviner lesquelles
#      etaient le "fond" - ambigu et fragile des que plusieurs faces du
#      corps partagent une aire proche, ou que la section de l'entaille
#      n'est pas carree (cas courant : panneau large x epaisseur). On
#      utilise maintenant Feature.faces (les faces REELLEMENT creees par
#      CHAQUE operation de decoupe, directement fournies par l'API Fusion -
#      aucune ambiguite possible) puis on les classe par ORIENTATION DE
#      NORMALE par rapport a l'axe d'epaisseur du corps : fond = normale
#      parallele a cet axe, parois laterales = le reste.
#
#   3) Jeu lateral -> Marge Auto : le champ "Jeu lateral (mm)" manuel est
#      remplace par une case a cocher "Marge Auto", exactement le meme
#      principe que l'option du meme nom dans Tenons CNC - si cochee, le
#      jeu CONFIGURE DANS MARGE CNC (son propre reglage, pas un champ ici)
#      est applique automatiquement sur les parois laterales de chaque
#      entaille (cote cible, et cote outils uniquement si retrait > 0,
#      puisque sinon l'outil n'est pas entaille), via
#      MargeCNC.apply_jeu_to_tokens. Avantage : la taille du jeu se regle a
#      un seul endroit (Marge CNC), et peut ensuite etre ajustee en 1 clic
#      pour tout le projet via l'outil "Modif Marge" deja existant - aucune
#      logique de jeu n'est dupliquee ici.
#
# Architecture (comme TenonCNC.py) : create_entaille_core et
# compute_entaille_preview sont des fonctions PURES (aucune dependance a
# une boite de dialogue/CommandInputs), appelees a la fois par la boite de
# dialogue native (CreateExecuteHandler, toujours disponible telle quelle)
# et par le panneau integre CNC Toolkit (ToolkitCNC._entaille_*).
#
# CORRECTION D'AXE (2026-10-02, retour utilisateur) : le retrait de
# profondeur (et la mesure du recouvrement D qui le bride) se mesuraient a
# tort le long de l'axe d'EPAISSEUR du corps (sa plus petite dimension,
# celle utilisee par Marge CNC pour le jeu lateral) - correct pour une
# simple rainure peu profonde dans l'epanteur d'une planche, mais PAS pour
# le cas vise par Entaille CNC : un assemblage a mi-bois entre 2 PANNEAUX
# qui se croisent sur leur LARGEUR (comme 2 cloisons qui se croisent, cf.
# add-in "Tab & Slot" - l'entaille entame la largeur de chaque panneau, pas
# son epaisseur qui reste entiere de part et d'autre de la fente). On
# utilise donc maintenant _true_largeur (la 2e dimension du corps, entre
# epaisseur et longueur - voir _true_axis_dims) comme axe de reference pour
# _measure_overlap_depth, _classify_fond_lateral et le bridage dans
# create_entaille_core. _classify_fond_lateral continue a servir Marge Auto
# exactement pareil (fond/parois laterales de l'entaille), seul l'axe de
# reference change.
#
# RETRAIT PAR DEFAUT PROPORTIONNEL (meme date, meme retour utilisateur) :
# la valeur de retrait proposee par defaut (avant toute saisie manuelle,
# voir compute_entaille_preview -> 'retrait_defaut_mm' et son utilisation
# cote palette.html) n'est plus fixee a 0 dans tous les cas, mais calculee
# au prorata de la largeur relative de la cible et de l'outil :
#   retrait_defaut = D * largeur_outil / (largeur_cible + largeur_outil)
# Si les 2 corps ont la meme largeur -> 50/50 (mi-bois symetrique
# classique, cas confirme explicitement par l'utilisateur). Si l'outil est
# beaucoup plus fin que la cible -> le retrait par defaut tend vers 0 (quasi
# tout reste sur la cible, pour ne pas fragiliser inutilement un outil fin)
# - et inversement. Ce calcul ne fait que PROPOSER une valeur de depart cote
# UI (champ "Auto") ; create_entaille_core lui-meme reste inchange, il
# applique simplement le depth_cm qu'on lui donne (toujours bride au
# recouvrement reellement disponible).
# ---------------------------------------------------------------------------

CUSTOM_FEAT_ID  = 'Autodesk.EntailleCNC'
CMD_CREATE_ID   = 'EntailleCNCCmd'
CMD_EDIT_ID     = 'EntailleCNCEditCmd'
PARAM_DEPTH     = 'retrait_profondeur'
PARAM_MARGE_AUTO = 'marge_auto'
SETTINGS_FILE   = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'settings.json')
DEBUG_LOG       = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'entaille_debug.log')


def _dbg(msg):
    try:
        import time
        with open(DEBUG_LOG, 'a', encoding='utf-8') as f:
            f.write(time.strftime('%H:%M:%S') + ' ' + str(msg) + '\n')
    except Exception:
        pass


def _find_module(short_name):
    """Retrouve un module d'add-in deja charge par Fusion dans cette
    session (meme technique que TenonCNC.py/ToolkitCNC.py) - utilise pour
    appeler MargeCNC.apply_jeu_to_tokens sans dependre d'un import direct
    (l'add-in cible peut etre inactif)."""
    mod = sys.modules.get(short_name)
    if mod is not None:
        return mod
    suffix = short_name + '_py'
    for k, m in list(sys.modules.items()):
        if k.endswith(suffix):
            return m
    return None


def _load_settings():
    try:
        if os.path.exists(SETTINGS_FILE):
            with open(SETTINGS_FILE, 'r', encoding='utf-8') as f:
                d = json.load(f)
            return {
                'depth_cm': max(0.0, float(d.get('depth_cm', 0.0))),
                'marge_auto': bool(d.get('marge_auto', False)),
            }
    except Exception:
        pass
    return {'depth_cm': 0.0, 'marge_auto': False}


def _save_settings(depth_cm, marge_auto):
    try:
        with open(SETTINGS_FILE, 'w', encoding='utf-8') as f:
            json.dump({'depth_cm': depth_cm, 'marge_auto': bool(marge_auto)}, f)
    except Exception:
        pass


def find_cf_by_name(design, name):
    timeline = design.timeline
    for i in range(timeline.count):
        cf = adsk.fusion.CustomFeature.cast(timeline.item(i).entity)
        if cf and cf.name == name:
            return cf
    return None


# ================================================================
# GEOMETRIE PURE (voir notes en tete de fichier)
# ================================================================

def _get_normal(face):
    """Normale au centre parametrique de la face (fiable meme si
    face.geometry.normal n'est pas dans le meme sens que la normale reelle
    du B-Rep) - meme technique que MargeCNC._get_normal/ToolkitCNC."""
    try:
        ev = face.evaluator
        pr = ev.parametricRange()
        cu = (pr.minPoint.x + pr.maxPoint.x) / 2
        cv = (pr.minPoint.y + pr.maxPoint.y) / 2
        ok, n = ev.getNormalAtParameter(adsk.core.Point2D.create(cu, cv))
        return n if ok else None
    except Exception:
        return None


def _true_thickness(body, fallback, tol_dot=0.05):
    """Normale et epaisseur REELLE d'un corps-panneau, a partir de ses deux
    plus grandes faces planes (normales opposees) - reste correct meme sur
    un panneau incline. Meme technique que MargeCNC._true_thickness."""
    try:
        planar = [f for f in body.faces if isinstance(f.geometry, adsk.core.Plane)]
    except Exception:
        return None, fallback
    if len(planar) < 2:
        return None, fallback
    try:
        planar.sort(key=lambda f: -f.area)
    except Exception:
        return None, fallback
    f1, f2 = planar[0], planar[1]
    try:
        p1 = adsk.core.Plane.cast(f1.geometry)
        p2 = adsk.core.Plane.cast(f2.geometry)
        if p1 is None or p2 is None:
            return None, fallback
        dot = p1.normal.dotProduct(p2.normal)
        if abs(abs(dot) - 1.0) > tol_dot:
            return None, fallback
        vec = p1.origin.vectorTo(p2.origin)
        dist = abs(vec.dotProduct(p1.normal))
        if dist <= 1e-4:
            return None, fallback
        return p1.normal, dist
    except Exception:
        return None, fallback


def get_epaisseur(body):
    """Epaisseur approximative d'un corps (repli bounding box, utilise
    uniquement si _true_thickness n'aboutit pas)."""
    bb = body.boundingBox
    return min(
        bb.maxPoint.x - bb.minPoint.x,
        bb.maxPoint.y - bb.minPoint.y,
        bb.maxPoint.z - bb.minPoint.z
    )


def get_largeur_fallback(body):
    """Largeur approximative d'un corps (repli bounding box : la dimension
    du MILIEU parmi les 3 - utilise uniquement si _true_largeur n'aboutit
    pas, voir _true_axis_dims)."""
    bb = body.boundingBox
    dims = sorted([
        bb.maxPoint.x - bb.minPoint.x,
        bb.maxPoint.y - bb.minPoint.y,
        bb.maxPoint.z - bb.minPoint.z,
    ])
    return dims[1] if len(dims) >= 2 else dims[0]


def _true_axis_dims(body):
    """Generalisation de _true_thickness : retourne jusqu'a 3 paires
    (normal, distance) pour les 3 dimensions principales d'un corps-panneau
    rectangulaire (epaisseur, largeur, longueur), triees par distance
    CROISSANTE (la plus petite = epaisseur en premier). Methode : a chaque
    etape, prend la plus grande face plane RESTANTE et sa face opposee
    (normales anti-paralleles, meme tolerance que _true_thickness) pour
    determiner un axe et sa dimension, puis retire toutes les faces de
    cette meme orientation avant de cherche l'axe suivant - reste correct
    sur un panneau incline, comme _true_thickness (dont le 1er resultat de
    cette liste est l'equivalent exact)."""
    try:
        remaining = [f for f in body.faces if isinstance(f.geometry, adsk.core.Plane)]
    except Exception:
        return []
    axes = []
    for _ in range(3):
        if len(remaining) < 2:
            break
        try:
            remaining.sort(key=lambda f: -f.area)
        except Exception:
            break
        f1 = remaining[0]
        try:
            p1 = adsk.core.Plane.cast(f1.geometry)
        except Exception:
            p1 = None
        if p1 is None:
            remaining = remaining[1:]
            continue
        f2 = None
        for f in remaining[1:]:
            try:
                p2 = adsk.core.Plane.cast(f.geometry)
                if p2 is None:
                    continue
                dot = p1.normal.dotProduct(p2.normal)
                if abs(abs(dot) - 1.0) <= 0.05:
                    f2 = f
                    break
            except Exception:
                continue
        if f2 is not None:
            try:
                p2 = adsk.core.Plane.cast(f2.geometry)
                vec = p1.origin.vectorTo(p2.origin)
                dist = abs(vec.dotProduct(p1.normal))
                if dist > 1e-4:
                    axes.append((p1.normal, dist))
            except Exception:
                pass
        # Retire TOUTES les faces partageant cette orientation (meme axe,
        # dans un sens ou dans l'autre) avant de chercher l'axe suivant.
        new_remaining = []
        for f in remaining:
            try:
                pf = adsk.core.Plane.cast(f.geometry)
                if pf is not None and abs(abs(pf.normal.dotProduct(p1.normal)) - 1.0) <= 0.05:
                    continue
            except Exception:
                pass
            new_remaining.append(f)
        remaining = new_remaining
    axes.sort(key=lambda a: a[1])
    return axes


def _true_largeur(body, fallback=None):
    """Normale et dimension de la LARGEUR d'un corps-panneau (2e dimension,
    entre l'epaisseur et la longueur - voir _true_axis_dims) : c'est l'axe
    de reference pour le retrait de profondeur d'Entaille CNC depuis la
    correction du 2026-10-02 (voir le gros commentaire en tete de fichier -
    un assemblage a mi-bois entre 2 panneaux qui se croisent entame leur
    LARGEUR, pas leur epaisseur)."""
    axes = _true_axis_dims(body)
    if len(axes) >= 2:
        return axes[1]
    return None, fallback


def _default_retrait_cm(largeur_cible_cm, largeur_outil_cm, overlap_cm):
    """Retrait par defaut PROPORTIONNEL a la largeur relative de la cible
    et de l'outil (choix explicite de l'utilisateur) :
        retrait = overlap * largeur_outil / (largeur_cible + largeur_outil)
    Largeurs egales -> 50/50 (mi-bois symetrique classique). Outil beaucoup
    plus fin que la cible -> retrait proche de 0 (quasi tout reste sur la
    cible, pour ne pas fragiliser inutilement un outil fin), et
    inversement. Ne fait que proposer une valeur de depart (reglable
    ensuite manuellement cote UI) - n'a aucun effet sur create_entaille_core
    lui-meme, qui applique simplement le depth_cm qu'on lui fournit."""
    largeur_cible_cm = largeur_cible_cm or 0.0
    largeur_outil_cm = largeur_outil_cm or 0.0
    total = largeur_cible_cm + largeur_outil_cm
    if total <= 1e-6 or overlap_cm is None:
        return 0.0
    return overlap_cm * (largeur_outil_cm / total)


def _face_plane_key_set(body):
    """Releve le plan (point + normale) de chaque face PLANE de body, A
    L'INSTANT OU ELLE EST APPELEE (donc typiquement juste AVANT une decoupe
    precise) - sert a reperer ensuite, parmi les faces rendues par
    Feature.faces apres cette decoupe, lesquelles sont des faces DEJA
    EXISTANTES simplement rognees/redimensionnees par la decoupe (ex. la
    face du dessus, celle du dessous, ou l'extremite "bout" de la piece),
    par opposition a une face VERITABLEMENT NOUVELLE creee par la cavite de
    l'entaille elle-meme - voir _face_matches_existing_plane et
    _classify_fond_lateral (correctif du 2026-10-07, bug remonte par
    Maxence : "en bout de piece", Modif Marge selectionnait a tort la face
    du dessus, celle du dessous ET l'extremite, en plus de la seule paroi
    laterale legitime de l'entaille)."""
    planes = []
    try:
        faces = body.faces
    except Exception:
        return planes
    for f in faces:
        try:
            if isinstance(f.geometry, adsk.core.Plane):
                pl = f.geometry
                planes.append((pl.origin, pl.normal))
        except Exception:
            continue
    return planes


def _face_matches_existing_plane(face, existing_planes):
    """True si face est une face PLANE dont le plan (position + normale)
    correspond a l'un de ceux releves AVANT la decoupe par
    _face_plane_key_set - c'est-a-dire une face qui EXISTAIT DEJA (meme
    simplement rognee par la decoupe), PAS une face nouvellement creee par
    la cavite de l'entaille. Voir _classify_fond_lateral."""
    if not existing_planes:
        return False
    try:
        if not isinstance(face.geometry, adsk.core.Plane):
            return False
        n = face.geometry.normal
        o = face.geometry.origin
    except Exception:
        return False
    for (eo, en) in existing_planes:
        try:
            if abs(n.dotProduct(en)) < 0.999:
                continue
            dx, dy, dz = o.x - eo.x, o.y - eo.y, o.z - eo.z
            dist = abs(dx * en.x + dy * en.y + dz * en.z)
            if dist < 1e-4:
                return True
        except Exception:
            continue
    return False


def _classify_fond_lateral(body, new_faces, main_normal=None, existing_planes=None):
    """Parmi les faces nouvellement creees par une decoupe (new_faces,
    issues de Feature.faces - voir note en tete de fichier), separe le
    fond (normale parallele a l'axe de LARGEUR du corps - la decoupe
    entame sa largeur, voir le commentaire de correction d'axe en tete de
    fichier) des parois laterales (le reste). Retourne
    (fond_faces, lateral_faces).

    main_normal : axe de largeur a utiliser, calcule par l'APPELANT AVANT
    toute decoupe (voir create_entaille_core). CORRECTIF (bug remonte par
    Maxence le 2026-10-03 : retrait de profondeur sans aucun effet, cible
    ET outil entierement sectionnes en 2 malgre un retrait > 0) : cette
    fonction recalculait auparavant elle-meme cet axe, a CHAQUE appel, sur
    le corps DEJA COUPE (body, qui vient de recevoir la decoupe dont
    new_faces est issue) - correct dans le cas general, mais DES QUE le
    recouvrement couvre exactement toute la largeur de la cible (cas
    frequent, pas un cas limite rare : ex. un poteau qui traverse tout un
    panneau), la decoupe de BASE (avant meme tout retrait) scinde deja le
    corps en plusieurs coquilles disjointes - ce qui change radicalement
    quelles faces planes sont les plus grandes et fait retomber
    l'heuristique de detection d'axe (_true_axis_dims, "plus grande face
    plane restante") sur un axe DIFFERENT de celui mesure avant la
    decoupe. Resultat observe : aucune face n'etait alors classee "fond",
    la face d'offset qui applique le retrait (etape 2 de
    create_entaille_core) n'etait donc JAMAIS creee, et la profondeur
    demandee restait entierement sans effet, quelle que soit sa valeur -
    confirme en direct. Si main_normal est fourni (cas normal, voir
    create_entaille_core), on l'utilise TEL QUEL plutot que de
    recalculer ; sinon (appel direct sans cet argument) on retombe sur
    l'ancien comportement, en dernier recours.

    existing_planes (optionnel, voir _face_plane_key_set) : plans releves
    sur body JUSTE AVANT cette decoupe precise. CORRECTIF (bug remonte par
    Maxence le 2026-10-07, "en bout de piece") : quand la cible ou l'outil
    se termine pile a l'endroit de l'entaille (plus de matiere au-dela), la
    decoupe rogne EN PLUS la face du dessus, celle du dessous et/ou
    l'extremite ("bout") de la piece - Feature.faces les inclut alors dans
    new_faces au meme titre que la ou les VRAIES parois de l'entaille.
    Comme aucune de ces faces rognees n'est parallele a main_normal (leur
    normale suit l'epaisseur ou la longueur de la piece, jamais sa
    largeur), l'ancienne classification les rangeait a tort parmi les
    parois "laterales" - exactement les faces que Maxence a vu
    selectionnees en trop par Modif Marge. On les exclut desormais
    ENTIEREMENT (ni fond, ni laterale) des qu'elles correspondent a un plan
    deja present sur le corps avant la decoupe : seule une face VRAIMENT
    NOUVELLE (qui n'existait sous aucune forme auparavant) peut etre fond
    ou laterale."""
    if main_normal is None:
        try:
            largeur_bbox = get_largeur_fallback(body)
        except Exception:
            largeur_bbox = 1.0
        main_normal, _largeur = _true_largeur(body, largeur_bbox)
    fond, lateral = [], []
    for f in new_faces:
        try:
            if existing_planes and _face_matches_existing_plane(f, existing_planes):
                # Face PRE-EXISTANTE simplement rognee par cette decoupe
                # (face du dessus/dessous, ou extremite "bout") - jamais
                # une paroi de l'entaille elle-meme, voir docstring.
                continue
            n = _get_normal(f) if isinstance(f.geometry, adsk.core.Plane) else None
            is_fond = False
            if n is not None and main_normal is not None:
                try:
                    is_fond = abs(n.dotProduct(main_normal)) > 0.9
                except Exception:
                    is_fond = False
            (fond if is_fond else lateral).append(f)
        except Exception:
            lateral.append(f)
    return fond, lateral


def _apply_marge(lateral_faces, body, marge_batch):
    """ACCUMULE (depuis l'optimisation de vitesse du 2026-10-04 - demande
    explicite de Maxence : "Optimise la vitesse de creation des entailles
    au maximum du possible") les face_tokens lateraux de CETTE entaille
    (deja classes par _classify_fond_lateral, fond exclu) dans
    marge_batch - une liste PARTAGEE pour tout l'appel create_entaille_core
    / create_entaille_core_multi en cours, voir _flush_marge_batch.

    Avant cette optimisation, chaque appel declenchait IMMEDIATEMENT une
    lecture+ecriture complete de mortaise_face_map.json (voir l'ancien
    MargeCNC.record_face_tokens) ET la creation d'une OffsetFacesFeature
    Fusion distincte (MargeCNC.apply_jeu_to_tokens) - soit jusqu'a 2 appels
    (cote cible + cote outil) PAR CORPS traite. Pour un enfourchement a 20
    montants (create_entaille_core_multi), ca faisait jusqu'a 40 allers-
    retours disque complets ET jusqu'a 40 features Fusion distinctes rien
    que pour la marge - l'essentiel du temps de creation observe. Toutes
    ces operations ne dependent d'aucun etat intermediaire (le jeu cm est
    le meme pour tout le document, les face_tokens sont independants les
    uns des autres) : les regrouper en UN SEUL aller-retour disque et UNE
    SEULE feature d'offset a la toute fin (_flush_marge_batch) est
    strictement equivalent en resultat, juste bien plus rapide.

    body (le corps - cible ou outil - auquel appartiennent lateral_faces) :
    fournit le 'female_token' (meme convention que TenonCNC/MortaiseCNC)
    necessaire a Modif Marge pour retrouver et reappliquer ce jeu plus
    tard (voir l'historique de ce correctif, 2026-10-04 plus tot)."""
    if not lateral_faces or body is None:
        return
    toks = []
    for f in lateral_faces:
        try:
            toks.append(f.entityToken)
        except Exception:
            pass
    if not toks:
        return
    try:
        female_token = body.entityToken
    except Exception:
        return
    if female_token:
        marge_batch.append({'female_token': female_token, 'face_tokens': toks})


def _flush_marge_batch(design, root, marge_batch, messages):
    """Applique en UN SEUL coup (une seule ecriture mortaise_face_map.json
    via MargeCNC.record_face_tokens_batch, et un seul appel a
    MargeCNC.apply_jeu_to_tokens - qui regroupe lui-meme deja par
    composant, voir _create_offset_by_component) tous les enregistrements
    accumules par _apply_marge pendant l'appel create_entaille_core /
    create_entaille_core_multi en cours - voir la docstring de _apply_marge
    pour le detail de l'optimisation. Ne fait rien si marge_auto n'etait
    pas actif ou si aucune entaille n'a produit de parois laterales."""
    if not marge_batch:
        return
    try:
        MargeCNC = _find_module('MargeCNC')
        if MargeCNC is None:
            messages.append('MargeAuto : add-in "Marge CNC" inactif - aucun jeu applique.')
            return
        jeu_cm, jeu_actif, _exclure_fond = MargeCNC.load_settings()
        if not jeu_actif:
            messages.append('MargeAuto : "Appliquer le jeu" est desactive dans Marge CNC.')
            return
        try:
            MargeCNC.record_face_tokens_batch(marge_batch)
        except Exception:
            pass
        feat, n_faces = MargeCNC.apply_jeu_to_tokens(
            design, root, marge_batch, jeu_cm, False)
        if feat:
            messages.append(
                f'MargeAuto : jeu applique sur {n_faces} face(s) au total '
                f'({len(marge_batch)} entaille(s)).')
    except Exception:
        messages.append('MargeAuto : erreur - ' + traceback.format_exc().strip().splitlines()[-1])


def _measure_overlap_depth(target_body, tool_body, axis_normal):
    """Mesure NON DESTRUCTIVE (TemporaryBRepManager, aucune feature/corps
    reel cree) de la profondeur du recouvrement entre target_body et
    tool_body le long de axis_normal - utilise pour brider le retrait de
    profondeur demande a une valeur geometriquement disponible (jamais
    plus que ce que le recouvrement contient reellement)."""
    tbm = adsk.fusion.TemporaryBRepManager.get()
    try:
        c = tbm.copy(target_body)
        t = tbm.copy(tool_body)
        if not tbm.booleanOperation(c, t, adsk.fusion.BooleanTypes.IntersectionBooleanType):
            return None
        if c.faces.count == 0:
            return None
        bb = c.boundingBox
        mn, mx = bb.minPoint, bb.maxPoint
        corners = [
            (mn.x, mn.y, mn.z), (mx.x, mn.y, mn.z), (mn.x, mx.y, mn.z), (mn.x, mn.y, mx.z),
            (mx.x, mx.y, mn.z), (mx.x, mn.y, mx.z), (mn.x, mx.y, mx.z), (mx.x, mx.y, mx.z),
        ]
        vals = [axis_normal.x * cx + axis_normal.y * cy + axis_normal.z * cz
                for cx, cy, cz in corners]
        return max(vals) - min(vals)
    except Exception:
        return None


def _draw_split_wireframe(root, preview_body, target_body, main_normal, retrait_cm, target_ref_point):
    """Dessine le fil de fer d'apercu de compute_entaille_preview EN DEUX
    COULEURS refletant le retrait de profondeur ACTUEL (purement visuel,
    CustomGraphics - aucune modification du document) :
      - ORANGE = portion du recouvrement REELLEMENT retiree de la cible
        (sa cavite finale).
      - BLEU = portion "retrait" : matiere CONSERVEE sur la cible et
        retiree a la place sur chaque corps outil (meme principe "handover"
        que create_entaille_core).
    Corrige le defaut signale par l'utilisateur ("je ne vois pas le preview
    se deplacer quand je change le retrait") : avant cette fonction, le fil
    de fer dessinait toujours la zone de recouvrement COMPLETE, sans tenir
    compte du retrait.

    Methode : determine d'abord de quel COTE de la zone de recouvrement se
    trouve le "fond" (le cote ou la matiere de la cible est PRESERVEE,
    "exterieur" - voir _pick_fond_side pour le detail et l'historique du
    bug ainsi corrige) via la distance au point de reference GLOBAL de la
    cible (target_ref_point, calcule UNE SEULE FOIS par l'appelant). La
    zone de recouvrement est ensuite tranchee en 2 sous-volumes a la
    distance retrait_cm de ce cote "fond" (intersection avec une boite
    temporaire orientee le long de main_normal, via
    MeasureManager.getOrientedBoundingBox pour rester correct meme sur un
    panneau incline).

    Retourne le CustomGraphicsGroup cree, ou None si le calcul echoue
    (geometrie degeneree, etc. - l'appelant degrade alors au fil de fer
    simple, une seule couleur, zone complete)."""
    app = adsk.core.Application.get()
    tbm = adsk.fusion.TemporaryBRepManager.get()

    seed = adsk.core.Vector3D.create(1, 0, 0)
    if abs(main_normal.dotProduct(seed)) > 0.95:
        seed = adsk.core.Vector3D.create(0, 1, 0)
    width_dir = main_normal.crossProduct(seed)
    if width_dir.length < 1e-6:
        return None
    width_dir.normalize()
    obb = app.measureManager.getOrientedBoundingBox(preview_body, main_normal, width_dir)
    if obb is None:
        return None

    length_dir = obb.lengthDirection
    D_obb = obb.length
    center = obb.centerPoint
    half = D_obb / 2.0
    s_min_pt = adsk.core.Point3D.create(
        center.x - length_dir.x * half, center.y - length_dir.y * half, center.z - length_dir.z * half)
    s_max_pt = adsk.core.Point3D.create(
        center.x + length_dir.x * half, center.y + length_dir.y * half, center.z + length_dir.z * half)
    fond_side = _pick_fond_side(s_min_pt, s_max_pt, target_ref_point)

    retrait_cm = max(0.0, min(retrait_cm, D_obb))

    def midpoint(p1, p2):
        return adsk.core.Point3D.create((p1.x + p2.x) / 2, (p1.y + p2.y) / 2, (p1.z + p2.z) / 2)

    def shift(pt, dist):
        return adsk.core.Point3D.create(
            pt.x + length_dir.x * dist, pt.y + length_dir.y * dist, pt.z + length_dir.z * dist)

    if fond_side == 'min':
        split_pt = shift(s_min_pt, retrait_cm)
        retrait_center, retrait_len = midpoint(s_min_pt, split_pt), retrait_cm
        cible_center, cible_len = midpoint(split_pt, s_max_pt), D_obb - retrait_cm
    else:
        split_pt = shift(s_max_pt, -retrait_cm)
        retrait_center, retrait_len = midpoint(split_pt, s_max_pt), retrait_cm
        cible_center, cible_len = midpoint(s_min_pt, split_pt), D_obb - retrait_cm

    def make_box(center_pt, length):
        if length <= 1e-4:
            return None
        return adsk.core.OrientedBoundingBox3D.create(
            center_pt, length_dir, width_dir, length, obb.width * 1.1, obb.height * 1.1)

    zones = []
    for center_pt, length, color in (
        (cible_center, cible_len, (255, 90, 0)),     # orange = cible (cavite reelle)
        (retrait_center, retrait_len, (90, 160, 255)),  # bleu = retrait (outil)
    ):
        box = make_box(center_pt, length)
        if box is None:
            continue
        try:
            body = tbm.copy(preview_body)
            tmp_box = tbm.createBox(box)
            if (tbm.booleanOperation(body, tmp_box, adsk.fusion.BooleanTypes.IntersectionBooleanType)
                    and body.faces.count > 0):
                zones.append((body, color))
        except Exception:
            continue

    if not zones:
        return None

    cg_group = root.customGraphicsGroups.add()
    any_drawn = False
    for body, (r, g, b) in zones:
        coords_flat = []
        strip_lengths = []
        for edge in body.edges:
            try:
                sp = edge.startVertex.geometry
                ep = edge.endVertex.geometry
            except Exception:
                continue
            coords_flat += [sp.x, sp.y, sp.z, ep.x, ep.y, ep.z]
            strip_lengths.append(2)
        if not coords_flat:
            continue
        coords = adsk.fusion.CustomGraphicsCoordinates.create(coords_flat)
        lines = cg_group.addLines(coords, [], True, strip_lengths)
        try:
            lines.color = adsk.fusion.CustomGraphicsSolidColorEffect.create(
                adsk.core.Color.create(r, g, b, 255))
            lines.weight = 4.0
        except Exception:
            pass
        any_drawn = True
    if not any_drawn:
        try:
            cg_group.deleteMe()
        except Exception:
            pass
        return None
    return cg_group


def _pick_width_dir(main_normal):
    """Choisit un axe perpendiculaire a main_normal (peu importe lequel,
    seule son orientation compte pour orienter une boite englobante) - meme
    technique que _draw_split_wireframe, factorisee ici pour etre partagee
    avec _clip_tool_to_cible_zone."""
    seed = adsk.core.Vector3D.create(1, 0, 0)
    if abs(main_normal.dotProduct(seed)) > 0.95:
        seed = adsk.core.Vector3D.create(0, 1, 0)
    width_dir = main_normal.crossProduct(seed)
    if width_dir.length < 1e-6:
        return None
    width_dir.normalize()
    return width_dir


def _entaille_ref_point(target_body, tool_bodies):
    """Calcule le point de reference GLOBAL et FIXE utilise par
    _pick_fond_side (voir sa docstring) - le centre de la boite englobante
    de TOUS les corps impliques (cible + outils), PAS seulement de la
    cible.

    CORRECTIF du 2026-10-dd (retour utilisateur "l'entaille est toujours du
    mauvais cote" + "mortaise toujours presente", apparu avec
    create_entaille_core_multi/l'inversion cible/outil pour les
    assemblages "enfourchement") : tant que la cible etait LA GRANDE piece
    (ex. la traverse courbe) et les outils les petits montants, le centre
    de la boite englobante de la seule cible etait deja une reference
    globale pertinente (les montants, petits, ne la deplacaient presque
    pas). Mais des que les roles sont inverses pour l'enfourchement
    (chaque MONTANT individuel devient la cible, dans une boucle
    create_entaille_core_multi, face a UNE traverse-outil partagee), une
    boite englobante calculee sur le SEUL montant (petit, local) ne porte
    plus aucune information sur "quel cote fait face a l'interieur/
    l'exterieur de l'ensemble" - elle est quasiment centree sur le montant
    lui-meme, rendant le choix de _pick_fond_side essentiellement
    arbitraire et INCOHERENT d'un montant a l'autre (exactement le
    symptome remonte : le cote qui recoit le retrait - donc la cavite
    profonde qui finit de l'autre cote - varie sans logique visible, et
    peut fermer un cote de l'entaille qui aurait du rester ouvert sur le
    bord du montant, creant une poche fermee/"mortaise" a la place d'une
    entaille ouverte).

    En prenant la boite englobante de TOUS les corps (cible + outils), le
    ou les gros corps (ex. la traverse, commune a tous les montants dans
    create_entaille_core_multi) continue de dominer ce centre, quel que
    soit celui des deux qui joue le role de "cible" - restaure une
    reference globale coherente sur tout l'ensemble, identique dans les 2
    sens cible/outil (et donc un comportement STRICTEMENT identique a
    avant quand c'est la cible qui est la grosse piece, puisque les
    petits outils ne deplacent alors quasiment pas ce centre - aucune
    regression)."""
    try:
        pts = [target_body.boundingBox.minPoint, target_body.boundingBox.maxPoint]
        for tb in tool_bodies:
            if tb is None:
                continue
            bb = tb.boundingBox
            pts.append(bb.minPoint)
            pts.append(bb.maxPoint)
        minx = min(p.x for p in pts)
        maxx = max(p.x for p in pts)
        miny = min(p.y for p in pts)
        maxy = max(p.y for p in pts)
        minz = min(p.z for p in pts)
        maxz = max(p.z for p in pts)
        return adsk.core.Point3D.create((minx + maxx) / 2, (miny + maxy) / 2, (minz + maxz) / 2)
    except Exception:
        return None


def _pick_fond_side(s_min, s_max, target_ref_point):
    """Determine de quel cote (min ou max) de la zone de recouvrement
    placer le "fond" (la matiere PRESERVEE sur la cible - le retrait le
    plus faible, "cote exterieur") plutot que la cavite profonde ("cote
    interieur") - utilise a la fois par _clip_tool_to_cible_zone (decoupe
    reelle) et _draw_split_wireframe (apercu).

    CORRIGE UN BUG REEL (remonte par Maxence le 2026-10-07 : "l'entaille
    est inversee sur ce type d'assemblage - elle se retrouve a l'exterieur
    alors qu'elle devrait etre a l'interieur"), expose par le passage a un
    axe de largeur PAR OUTIL (voir _compute_tool_axes). L'ancienne
    detection (BRepBody.pointContainment juste au-dela de chaque
    extremite de la zone de recouvrement, sur le corps cible) est en
    realite deja AMBIGUE des que l'outil est nettement plus etroit que la
    cible - cas le PLUS COURANT (un montant fin traversant une large
    traverse) : les DEUX sondes tombent alors a l'interieur de la cible
    (il reste de la matiere des deux cotes a la fois), et le code
    retombait sur un choix par defaut arbitraire ('min'). Tant qu'un SEUL
    axe global etait utilise pour tous les outils (avant le passage a un
    axe par outil), ce choix par defaut restait au moins COHERENT (meme
    cote physique pour tous les montants, vu le meme axe/la meme
    orientation de reference a chaque fois) ; des que chaque outil
    utilise son propre axe local, le signe de cet axe (_true_axis_dims
    prend la normale de "la plus grande face plane restante", dont le
    sens n'est pas garanti coherent d'un corps a l'autre) n'a aucune
    raison de pointer du meme cote physique pour deux montants differents
    - d'ou le defaut 'min' qui tombait tantot a l'interieur, tantot a
    l'exterieur selon le montant : exactement le symptome observe
    (correct sur certains montants, inverse sur d'autres).

    Plutot que de deviner localement (fragile), on compare la distance de
    chaque extremite REELLE (s_min, s_max - deux points 3D, donc
    INDEPENDANTS du signe de l'axe utilise pour les calculer) a un point
    de reference FIXE et GLOBAL pour toute la cible (le centre de sa
    boite englobante, calcule UNE SEULE FOIS avant toute decoupe et
    transmis par l'appelant - voir create_entaille_core/
    compute_entaille_preview) : le cote le plus ELOIGNE de ce centre est
    l'"exterieur" (ou la matiere est preservee) ; le plus PROCHE est
    l'"interieur" (ou la cavite profonde est creusee) - un choix coherent
    tout du long d'une cible courbe, quel que soit le signe de l'axe
    local de chaque outil."""
    try:
        d_min = s_min.distanceTo(target_ref_point)
        d_max = s_max.distanceTo(target_ref_point)
    except Exception:
        return 'min'
    return 'min' if d_min >= d_max else 'max'


def _insert_real_body(design, root, temp_body):
    """Insere un corps TRANSITOIRE (TemporaryBRepManager) comme corps REEL
    persistant dans le document, pour pouvoir l'utiliser comme outil d'une
    CombineFeature reelle (impossible directement avec un corps transitoire).
    Passe par une BaseFeature dediee (edit/add/finishEdit), seule methode
    documentee pour creer un corps a partir de geometrie transitoire en
    modelisation PARAMETRIQUE (avec timeline - le cas de tous les documents
    de Maxence).

    IMPORTANT (confirme en direct par script, piege non documente) : la
    reference BRepBody retournee DIRECTEMENT par BRepBodies.add() est
    instable - l'utiliser immediatement comme outil d'une CombineFeature
    echoue SYSTEMATIQUEMENT avec l'erreur Fusion "ALL_TOOL_BODY_REFERENCE_
    LOST", meme sur un corps parfaitement valide (isValid=True) et
    correctement forme (confirme avec une simple boite). Il faut forcer un
    recalcul complet (Design.computeAll + adsk.doEvents) PUIS retrouver le
    corps via BaseFeature.bodies (jamais la reference d'origine) pour
    obtenir une reference exploitable par la suite - sans ce detour,
    n'importe quelle tentative plante.

    Retourne le BRepBody reel (ou None en cas d'echec - l'appelant doit
    alors se replier sur un comportement degrade)."""
    try:
        base_feat = root.features.baseFeatures.add()
        base_feat.startEdit()
        try:
            root.bRepBodies.add(temp_body, base_feat)
        finally:
            base_feat.finishEdit()
        try:
            design.computeAll()
        except Exception:
            pass
        try:
            adsk.doEvents()
        except Exception:
            pass
        if base_feat.bodies.count > 0:
            return base_feat.bodies.item(0)
    except Exception:
        pass
    return None


def _insert_real_bodies(design, root, temp_bodies):
    """Variante GROUPEE de _insert_real_body : insere PLUSIEURS corps
    transitoires dans UNE SEULE BaseFeature (une seule entree d'historique/
    Ctrl+Z pour TOUS les corps, au lieu d'une par corps) - demande de
    Maxence ("je voudrais pouvoir selectionner plusieurs outils en meme
    temps" a mecaniquement multiplie le nombre d'etapes Ctrl+Z necessaires
    pour annuler une seule operation d'entaille, puisque l'ancien code
    appelait _insert_real_body UNE FOIS PAR outil de decoupe). Confirme en
    direct (3 corps transitoires distincts inseres ensemble) : une seule
    BaseFeature suffit, et BaseFeature.bodies conserve l'ORDRE d'insertion -
    donc le resultat ci-dessous est toujours dans le MEME ORDRE que
    temp_bodies.

    Retourne une liste de la MEME LONGUEUR que temp_bodies, avec le
    BRepBody reel insere a chaque position, ou None a cette position si cet
    insertion precise a echoue (l'appelant doit alors se replier sur le
    corps original pour CETTE entree uniquement, les autres restant
    inchangees) - ou une liste de None partout si la BaseFeature elle-meme
    n'a pas pu etre creee/editee."""
    n = len(temp_bodies)
    if n == 0:
        return []
    try:
        base_feat = root.features.baseFeatures.add()
        base_feat.startEdit()
    except Exception:
        return [None] * n
    added_flags = []
    try:
        for tb in temp_bodies:
            ok = False
            try:
                root.bRepBodies.add(tb, base_feat)
                ok = True
            except Exception:
                ok = False
            added_flags.append(ok)
    finally:
        try:
            base_feat.finishEdit()
        except Exception:
            pass
    try:
        design.computeAll()
    except Exception:
        pass
    try:
        adsk.doEvents()
    except Exception:
        pass
    try:
        count = base_feat.bodies.count
    except Exception:
        count = 0
    results = []
    idx = 0
    for ok in added_flags:
        if ok and idx < count:
            try:
                results.append(base_feat.bodies.item(idx))
            except Exception:
                results.append(None)
            idx += 1
        else:
            results.append(None)
    return results


def _clip_tool_to_cible_zone(target_body, tool_body, main_normal, depth_cm, target_ref_point):
    """Calcule la portion de tool_body a utiliser pour couper target_body
    afin que la cavite resultante n'entame que (recouvrement - depth_cm) de
    la largeur de la cible, en laissant physiquement intacte la marge de
    retrait (depth_cm) du cote du "fond" - meme principe geometrique que
    _draw_split_wireframe (determination du cote "fond" via
    _pick_fond_side, tranchage par boite orientee via
    getOrientedBoundingBox), mais appliqué ICI au corps OUTIL lui-meme (pas
    seulement a un apercu) pour servir de veritable outil de decoupe.

    CORRIGE UN BUG REEL (remonte par Maxence le 2026-10-03, pas un cas
    limite rare) : l'ancienne version coupait la cible avec le corps outil
    COMPLET (recouvrement entier), puis tentait de "redonner" la marge de
    retrait apres coup en reculant la face de fond (OffsetFacesFeature).
    Des que le recouvrement couvre exactement toute la largeur de la cible
    (frequent : ex. un poteau qui traverse tout un panneau, ou 2 planches
    de meme largeur qui se croisent completement), la decoupe de base
    sectionnait DEJA la cible en 2 corps disjoints AVANT meme la tentative
    de decalage - aucune face de fond n'existait alors a reculer (le cote
    "fond" n'ayant par definition aucune face nouvelle quand rien ne reste
    au-dela du recouvrement), et le retrait demande restait entierement
    sans effet, quelle que soit sa valeur (confirme en direct : corps
    totalement sectionnes, 4 corps au lieu de 2). En decoupant directement
    avec une version RECORTEE de l'outil (ne couvrant jamais que la portion
    a reellement retirer), la marge de retrait est TOUJOURS physiquement
    presente des la decoupe elle-meme - plus besoin d'un decalage de face
    a posteriori, qui disparait donc de create_entaille_core.

    Retourne un corps TRANSITOIRE (TemporaryBRepManager) pret a etre
    insere via _insert_real_body, ou None si le calcul echoue (fond
    indetermine de maniere non ambigue hors du cas D==largeur, geometrie
    degeneree, etc.) - l'appelant se replie alors sur le corps outil complet
    (comportement degrade, equivalent a l'ancien, mais jamais pire)."""
    app = adsk.core.Application.get()
    tbm = adsk.fusion.TemporaryBRepManager.get()
    width_dir = _pick_width_dir(main_normal)
    if width_dir is None:
        return None
    try:
        preview_body = tbm.copy(target_body)
        tool_copy = tbm.copy(tool_body)
        if not tbm.booleanOperation(preview_body, tool_copy, adsk.fusion.BooleanTypes.IntersectionBooleanType):
            return None
        if preview_body.faces.count == 0:
            return None
        obb = app.measureManager.getOrientedBoundingBox(preview_body, main_normal, width_dir)
        if obb is None:
            return None
    except Exception:
        return None

    length_dir = obb.lengthDirection
    D_obb = obb.length
    center = obb.centerPoint
    half = D_obb / 2.0
    s_min = adsk.core.Point3D.create(
        center.x - length_dir.x * half, center.y - length_dir.y * half, center.z - length_dir.z * half)
    s_max = adsk.core.Point3D.create(
        center.x + length_dir.x * half, center.y + length_dir.y * half, center.z + length_dir.z * half)
    fond_side = _pick_fond_side(s_min, s_max, target_ref_point)

    cible_len = D_obb - depth_cm
    if cible_len <= 1e-4:
        return None  # rien a retirer cote cible (tout le retrait revient a l'outil)

    def shift(pt, dist):
        return adsk.core.Point3D.create(
            pt.x + length_dir.x * dist, pt.y + length_dir.y * dist, pt.z + length_dir.z * dist)

    def midpoint(p1, p2):
        return adsk.core.Point3D.create((p1.x + p2.x) / 2, (p1.y + p2.y) / 2, (p1.z + p2.z) / 2)

    if fond_side == 'min':
        split_pt = shift(s_min, depth_cm)
        cible_center = midpoint(split_pt, s_max)
    else:
        split_pt = shift(s_max, -depth_cm)
        cible_center = midpoint(s_min, split_pt)

    try:
        clip_box_def = adsk.core.OrientedBoundingBox3D.create(
            cible_center, length_dir, width_dir, cible_len, obb.width * 1.2, obb.height * 1.2)
        tool_clip = tbm.copy(tool_body)
        clip_box_body = tbm.createBox(clip_box_def)
        if not tbm.booleanOperation(tool_clip, clip_box_body, adsk.fusion.BooleanTypes.IntersectionBooleanType):
            return None
        if tool_clip.faces.count == 0:
            return None
        return tool_clip
    except Exception:
        return None


def _compute_tool_axes(target_body, tool_bodies):
    """Calcule l'axe de largeur a utiliser PAR OUTIL, plutot qu'un axe
    UNIQUE calcule une seule fois pour toute la cible (ancien
    comportement). CORRIGE UN BUG REEL (remonte par Maxence le 2026-10-07 :
    "les entailles dans les coins ne se font pas bien du tout" sur une
    cible COURBE - une rambarde courbee a laquelle sont fixes des montants
    verticaux tout le long, y compris dans la partie courbe/les coins).

    Chaque montant (corps outil) est pose perpendiculairement a la
    tangente LOCALE du rail a son emplacement precis : son propre axe de
    largeur (_true_largeur applique au corps outil lui-meme - fiable,
    c'est un simple panneau rectangulaire) suit donc correctement la
    courbe de la cible, alors qu'un axe UNIQUE mesure sur toute la cible
    (via sa plus grande face plane, _true_largeur(target_body, ...)) ne
    vaut que pour la portion DROITE de la cible d'ou cette face provient -
    jusqu'a totalement PERPENDICULAIRE (produit scalaire mesure = 0.0 en
    direct) a l'axe correct pour les montants poses sur l'autre brin d'une
    cible en U/L, et intermediaire (ni juste ni franchement faux) dans les
    coins eux-memes. Confirme en direct sur la reproduction de test
    fournie par Maxence (TENON CNC, rail courbe + 20 montants) avant ce
    correctif : axe global de la cible (0,-1,0), axe local des montants du
    brin perpendiculaire (1,0,0)/(-1,0,0).

    Utilisee a la fois par create_entaille_core (decoupe reelle) et
    compute_entaille_preview (apercu) - les DEUX DOIVENT utiliser
    exactement le meme calcul pour que l'apercu reste fidele au resultat
    reel (voir docstring de compute_entaille_preview).

    Retourne (tool_axes, main_normal_fallback, largeur_cible_fallback) ou
    tool_axes est un dict {tool.entityToken: (main_normal, largeur_outil_cm)}.
    Repli sur l'axe GLOBAL de la cible (comportement identique a l'ancien
    code) si l'axe local d'un outil precis n'a pas pu etre determine (corps
    outil non rectangulaire, geometrie degeneree, etc.)."""
    main_normal_fallback, largeur_cible_fallback = _true_largeur(
        target_body, get_largeur_fallback(target_body))
    tool_axes = {}
    for tb in tool_bodies:
        try:
            n, lg = _true_largeur(tb, get_largeur_fallback(tb))
        except Exception:
            n, lg = None, None
        if n is None:
            n, lg = main_normal_fallback, largeur_cible_fallback
        try:
            tool_axes[tb.entityToken] = (n, lg)
        except Exception:
            pass
    return tool_axes, main_normal_fallback, largeur_cible_fallback


def _resolve_axis_and_depth(target_body, tool_bodies, depth_cm, axis_override):
    """Factorise la resolution de l'axe de largeur par outil (voir
    _compute_tool_axes/axis_override) ET le bridage du retrait de
    profondeur demande a la plus petite profondeur de recouvrement
    reellement disponible - logique auparavant ecrite UNE SEULE FOIS en
    tete de create_entaille_core.

    Factorisee ici (optimisation du 2026-10-06, suite au retour utilisateur
    "ca plante vers la 30e/40e entaille sur un lot de 50-70") pour etre
    appelee DEUX FOIS avec les memes arguments : une fois par
    create_entaille_core_multi (pour pre-calculer, pour TOUTES les cibles
    d'un coup, les corps outils recortes a inserer en UNE SEULE fois - voir
    son usage), et une fois par create_entaille_core lui-meme (pour la
    decoupe reelle). Il est ESSENTIEL que les deux appels produisent
    EXACTEMENT le meme resultat pour la meme cible (meme axe par outil,
    meme retrait effectif apres bridage) - sans quoi les corps recortes
    precalcules ne correspondraient plus a ce que create_entaille_core
    utilise reellement au moment de la decoupe. D'ou cette factorisation en
    UNE SEULE fonction PURE (aucun effet de bord, aucun message ajoute -
    chaque appelant decide lui-meme s'il doit logger le bridage), plutot
    qu'une reimplementation separee qui risquerait de diverger avec le
    temps.

    Retourne (tool_axes, main_normal_fallback, largeur_cible_fallback,
    target_ref_point, effective_depth_cm, was_clamped, d_max_overlap_cm) -
    was_clamped indique si effective_depth_cm a ete reduit par rapport au
    depth_cm demande (recouvrement insuffisant), d_max_overlap_cm est la
    plus petite profondeur de recouvrement mesuree (None si non mesurable),
    utile pour le message d'avertissement cote appelant."""
    if axis_override is not None:
        tool_axes = {}
        main_normal_fallback, largeur_cible_fallback = axis_override
    else:
        tool_axes, main_normal_fallback, largeur_cible_fallback = _compute_tool_axes(target_body, tool_bodies)

    target_ref_point = _entaille_ref_point(target_body, tool_bodies)

    def _axis_for(tb):
        try:
            return tool_axes.get(tb.entityToken, (main_normal_fallback, largeur_cible_fallback))
        except Exception:
            return main_normal_fallback, largeur_cible_fallback

    effective_depth_cm = max(0.0, depth_cm)
    was_clamped = False
    d_max = None
    if effective_depth_cm > 0.0:
        depths = []
        for tb in tool_bodies:
            n, _lg = _axis_for(tb)
            if n is None:
                continue
            d = _measure_overlap_depth(target_body, tb, n)
            if d is not None:
                depths.append(d)
        if depths:
            d_max = min(depths)
            if effective_depth_cm > d_max - 1e-5:
                effective_depth_cm = max(0.0, d_max - 0.001)
                was_clamped = True

    return (tool_axes, main_normal_fallback, largeur_cible_fallback, target_ref_point,
            effective_depth_cm, was_clamped, d_max)


# ================================================================
# ENTAILLES EN ESQUISSE (demande de Maxence, 2026-10-07 : "si je bouge un
# corps plus tot dans l'historique, tout doit suivre, comme les mortaises")
#
# La partie figee d'une entaille etait l'outil RECOUPE (BaseFeature) qui
# creuse la cible quand il y a un retrait de profondeur. On le remplace,
# quand la geometrie s'y prete, par une esquisse posee sur la face de la
# cible par ou l'entaille debouche : la section du corps outil dans ce plan
# (projectCutEdges, liee a l'outil) est extrudee en coupe sur la profondeur
# de la cavite. Si l'outil ou la cible bouge plus tot dans l'historique,
# l'esquisse suit. Le volume retire est compare a la cavite calculee ; s'il
# differe, tout est annule et l'ancien mode fige prend le relais pour CETTE
# entaille uniquement. _SKETCH_MODE = False revient entierement a l'ancien
# mode.
# ================================================================

_SKETCH_MODE = True
_SK_VOL_TOL = 1e-3   # tolerance relative sur le volume retire


def _vertex_range(body, n):
    vals = []
    for v in body.vertices:
        p = v.geometry
        vals.append(p.x * n.x + p.y * n.y + p.z * n.z)
    if not vals:
        return None
    return min(vals), max(vals)


def _sketch_cut_target(design, root, target_body, tool_body, clipped, main_normal):
    """Coupe target_body par la cavite 'clipped' (corps transitoire, voir
    _clip_tool_to_cible_zone) avec une esquisse + extrusion parametriques.
    Retourne l'ExtrudeFeature, ou None (rien n'est laisse dans le document)
    si la geometrie ne s'y prete pas."""
    if main_normal is None or clipped is None:
        return None
    try:
        if target_body.assemblyContext is not None or tool_body.assemblyContext is not None:
            return None
    except Exception:
        return None
    tbm = adsk.fusion.TemporaryBRepManager.get()
    try:
        cavity = tbm.copy(target_body)
        if not tbm.booleanOperation(cavity, tbm.copy(clipped),
                                    adsk.fusion.BooleanTypes.IntersectionBooleanType):
            return None
        expected = cavity.volume
    except Exception:
        return None
    if expected < 1e-6:
        _dbg('esquisse refusee : cavite vide')
        return None
    n = main_normal.copy()
    n.normalize()
    rng = _vertex_range(cavity, n)
    if rng is None:
        return None
    depth = rng[1] - rng[0]
    if depth < 1e-4:
        _dbg('esquisse refusee : profondeur nulle')
        return None
    # Face d'ouverture : face plane de la cible, normale sortante le long de
    # l'axe, posee sur une extremite de la cavite.
    face = None
    best_area = -1.0
    for f in target_body.faces:
        try:
            if not isinstance(f.geometry, adsk.core.Plane):
                continue
            ok, fn = f.evaluator.getNormalAtPoint(f.pointOnFace)
            if not ok:
                continue
            fn.normalize()
            d = fn.dotProduct(n)
            if abs(d) < 0.999:
                continue
            p = f.pointOnFace
            u = p.x * n.x + p.y * n.y + p.z * n.z
            if d > 0 and abs(u - rng[1]) > 1e-4:
                continue
            if d < 0 and abs(u - rng[0]) > 1e-4:
                continue
            # la cavite doit toucher cette face (une face de la cavite dans ce plan)
            touch = False
            for cf in cavity.faces:
                if not isinstance(cf.geometry, adsk.core.Plane):
                    continue
                cp = cf.pointOnFace
                if abs(cp.x * n.x + cp.y * n.y + cp.z * n.z - u) < 1e-4:
                    cpl = adsk.core.Plane.cast(cf.geometry)
                    if abs(abs(cpl.normal.dotProduct(n)) - 1.0) < 1e-3:
                        touch = True
                        break
            if not touch:
                continue
            if f.area > best_area:
                face, best_area = f, f.area
                face_out = fn
        except Exception:
            continue
    if face is None:
        _dbg('esquisse refusee : pas de face plane d ouverture (%s)' % target_body.name)
        return None

    sk = None
    ext = None
    try:
        vol_before = target_body.volume
        sk = root.sketches.add(face)
        sk.name = 'Entaille (esquisse)'
        sk.projectCutEdges(tool_body)
        profs = adsk.core.ObjectCollection.create()
        for pr in sk.profiles:
            try:
                c = pr.areaProperties(adsk.fusion.CalculationAccuracy.LowCalculationAccuracy).centroid
                w = sk.sketchToModelSpace(c)
                probe = adsk.core.Point3D.create(w.x - face_out.x * 1e-3,
                                                 w.y - face_out.y * 1e-3,
                                                 w.z - face_out.z * 1e-3)
                if cavity.pointContainment(probe) == adsk.fusion.PointContainment.PointInsidePointContainment:
                    profs.add(pr)
            except Exception:
                continue
        if profs.count == 0:
            raise RuntimeError('aucun profil')
        efs = root.features.extrudeFeatures
        directions = [adsk.fusion.ExtentDirections.NegativeExtentDirection,
                      adsk.fusion.ExtentDirections.PositiveExtentDirection]
        try:
            # cote matiere = oppose a la normale sortante : on essaie d'abord
            # le bon sens (evite une extrusion annulee puis refaite)
            skn = sk.xDirection.crossProduct(sk.yDirection)
            if skn.dotProduct(face_out) < 0:
                directions.reverse()
        except Exception:
            pass
        for direction in directions:
            ei = efs.createInput(profs, adsk.fusion.FeatureOperations.CutFeatureOperation)
            ei.setOneSideExtent(adsk.fusion.DistanceExtentDefinition.create(
                adsk.core.ValueInput.createByReal(depth)), direction)
            ei.participantBodies = [target_body]
            ext = efs.add(ei)
            removed = vol_before - sum(b.volume for b in ext.bodies)
            if abs(removed - expected) <= max(1e-4, expected * _SK_VOL_TOL):
                break
            _dbg('esquisse : volume retire %.5f au lieu de %.5f' % (removed, expected))
            ext.deleteMe()
            ext = None
        if ext is None:
            raise RuntimeError('volume different')
        ext.name = 'Entaille'
        try:
            ext.attributes.add(_LOT_GROUP, 'mode', 'esquisse')
            sk.attributes.add(_LOT_GROUP, 'mode', 'esquisse')
        except Exception:
            pass
        return ext
    except Exception:
        _dbg('esquisse refusee : ' + traceback.format_exc().strip().splitlines()[-1])
        try:
            if ext is not None and ext.isValid:
                ext.deleteMe()
        except Exception:
            pass
        try:
            if sk is not None and sk.isValid:
                sk.deleteMe()
        except Exception:
            pass
        return None


def create_entaille_core(design, target_body, tool_bodies, depth_cm, marge_auto, axis_override=None,
                          _marge_batch=None, precomputed_real_bodies=None,
                          precomputed_resolved=None, precomputed_clips=None,
                          _deferred=None, _count_target=True):
    """Coeur pur de la creation d'entaille(s) a mi-bois entre target_body
    et chaque corps de tool_bodies - voir le gros commentaire en tete de
    fichier pour le detail du principe (retrait de profondeur = profondeur
    reportee de la cible vers chaque outil, 0 = tout sur la cible).

    axis_override (optionnel) : tuple (main_normal, largeur_cm) - voir
    create_entaille_core_multi. Quand fourni, court-circuite
    _compute_tool_axes (qui calcule normalement l'axe de largeur a partir
    de CHAQUE OUTIL - correctif du bug "entailles fausses dans les coins
    d'une cible courbe", voir _compute_tool_axes) : TOUS les outils
    utilisent alors ce MEME axe. Necessaire quand c'est l'OUTIL qui est le
    corps complexe/courbe (ex. la traverse, utilisee comme outil partage
    dans create_entaille_core_multi) et la CIBLE le corps simple/local (un
    montant) - dans ce cas, calculer l'axe a partir de l'outil (courbe)
    reproduit exactement le meme bug que ci-dessus, juste les roles
    inverses ; calculer l'axe a partir de la cible (simple, locale a ce
    croisement) le resout, exactement comme avant pour chaque outil
    simple/local.

    _marge_batch (optionnel, usage interne) : voir _apply_marge/
    _flush_marge_batch (optimisation de vitesse du 2026-10-04). Quand
    fourni par l'appelant (create_entaille_core_multi, pour regrouper la
    marge de TOUTES les cibles en une seule fois), les enregistrements de
    marge de CET appel y sont simplement ajoutes et c'est l'APPELANT qui
    doit ensuite appeler _flush_marge_batch - cette fonction ne les
    applique PAS elle-meme dans ce cas. Quand omis (appel direct, ex.
    CreateExecuteHandler), cette fonction gere sa propre liste locale et
    l'applique elle-meme avant de retourner - comportement STRICTEMENT
    IDENTIQUE a avant cette optimisation.

    precomputed_real_bodies (optionnel, usage interne, voir
    create_entaille_core_multi - optimisation du 2026-10-06) : dict
    {(target.entityToken, tool.entityToken): real_body|None} precalcule par
    l'appelant pour TOUT un lot de cibles a la fois, via UN SEUL
    design.computeAll() pour tout le lot au lieu d'un par cible. Quand
    fourni et qu'une entree existe pour un couple (cible, outil) donne,
    elle est utilisee directement (aucune insertion individuelle). Quand
    omis, ou qu'aucune entree ne correspond a un couple precis, repli sur
    le comportement de l'optimisation precedente (recortage + insertion
    groupee, mais limitee a CETTE cible) - voir PHASE A ci-dessous.

    precomputed_resolved (optionnel, usage interne) : resultat deja calcule de
    _resolve_axis_and_depth pour CETTE cible (meme tuple de 7 elements) par
    create_entaille_core_multi dans son pre-calcul groupe - evite de refaire
    pour chaque cible les memes _true_largeur + _measure_overlap_depth (copies
    + booleenne temporaires par outil). Omis -> calcul normal.

    _deferred (optionnel, usage interne, vitesse 2026-10-11) : liste. Quand
    l'esquisse d'un outil est refusee, au lieu d'inserer tout de suite son
    corps fige (un design.computeAll() complet par entaille refusee, 70 %
    du temps mesure sur 60 entailles), l'outil est mis de cote dans cette
    liste et saute ici (ni coupe de la cible, ni coupe reciproque, ni
    marge) ; l'appelant les insere ensuite TOUS en une fois via
    _flush_deferred_sketch. _count_target=False : la cible a deja ete
    comptee par un premier appel (n_cotes).

    Retourne {'error': str|None, 'n_cotes_ok': int, 'n_cotes_total': int,
              'messages': [str, ...]}."""
    messages = []
    if target_body is None:
        return {'error': 'aucun corps cible', 'n_cotes_ok': 0, 'n_cotes_total': 0, 'messages': []}
    tool_bodies = [tb for tb in tool_bodies if tb is not None]
    if not tool_bodies:
        return {'error': 'aucun corps de decoupe', 'n_cotes_ok': 0, 'n_cotes_total': 0, 'messages': []}

    depth_cm = max(0.0, depth_cm)  # le retrait est toujours >= 0 (voir principe en tete de fichier)

    owns_marge_batch = _marge_batch is None
    marge_batch = [] if owns_marge_batch else _marge_batch

    root = design.rootComponent
    combine_feats = root.features.combineFeatures
    n_total = 1 + len(tool_bodies)
    n_ok = 0

    # --- Axe de largeur par outil + retrait bride au recouvrement reellement
    # disponible : factorise dans _resolve_axis_and_depth (voir sa
    # docstring) depuis le 2026-10-06, car create_entaille_core_multi doit
    # desormais pouvoir reproduire EXACTEMENT ce meme calcul en amont (pour
    # son pre-calcul groupe des corps recortes, voir plus bas et son propre
    # commentaire) - une seule fonction partagee plutot que deux copies
    # risquant de diverger. Comportement inchange ici : meme axe par outil,
    # meme retrait effectif qu'avant cette factorisation. ---
    requested_depth_cm = depth_cm
    (tool_axes, main_normal_fallback, _largeur_cible_fallback, target_ref_point,
     depth_cm, _was_clamped, _d_max) = (
        precomputed_resolved if precomputed_resolved is not None
        else _resolve_axis_and_depth(target_body, tool_bodies, depth_cm, axis_override))
    if _was_clamped:
        messages.append(
            'Retrait de profondeur (%.2f mm) superieur ou egal au recouvrement '
            'disponible (%.2f mm) - limite a %.2f mm.' % (
                requested_depth_cm * 10, _d_max * 10, depth_cm * 10))

    def _axis_for(tb):
        try:
            return tool_axes.get(tb.entityToken, (main_normal_fallback, _largeur_cible_fallback))
        except Exception:
            return main_normal_fallback, _largeur_cible_fallback

    # --- 1) Decoupe de la cible, OUTIL PAR OUTIL (et non plus tous les
    # outils groupes en une seule Combine partagee) : necessaire pour
    # appliquer a chacun son propre axe local, aussi bien lors du recortage
    # (_clip_tool_to_cible_zone) que de la classification fond/laterale qui
    # en decoule (_classify_fond_lateral) - deux montants a des endroits
    # differents d'une cible courbe n'ont pas le meme axe, donc pas la
    # meme face de "fond". Ce decoupage par outil produit plus d'entrees
    # d'historique qu'avant (une Combine, et au besoin une BaseFeature, par
    # outil plutot que 1-2 entrees au total) - devenu acceptable depuis
    # l'ajout du groupement automatique en un seul groupe nomme 'Entaille
    # CNC' dans l'historique (voir ToolkitCNC._entaille_create /
    # EntailleCNC.CreateExecuteHandler), qui reste supprimable en un seul
    # geste quel que soit le nombre d'entrees qu'il contient.
    #
    # --- PHASE A (recortage, SANS decoupe) : optimisation du 2026-10-05
    # (retour utilisateur : "quand je cree beaucoup d'entailles avec
    # beaucoup d'outils et de cibles, ca fige et mon Fusion crash").
    # AVANT ce correctif, chaque outil appelait sa PROPRE
    # _insert_real_bodies([clipped]) l'un apres l'autre - donc son PROPRE
    # design.computeAll() COMPLET a chaque fois (voir la docstring de
    # _insert_real_body sur ce point, et de _insert_real_bodies sur le
    # regroupement qu'elle permet mais qui n'etait jusqu'ici jamais
    # exploite a cet appel). Avec M outils par cible et N cibles, ca
    # faisait jusqu'a N*M recalculs COMPLETS du document, un cout qui
    # grandit en plus avec la taille de l'historique deja construite par
    # les entailles precedentes - coherent avec un gel progressif puis un
    # crash. On recorte desormais TOUS les outils de CETTE cible d'abord
    # (purement en memoire transitoire, aucun recalcul), puis on les
    # insere TOUS ENSEMBLE en UN SEUL appel groupe (_insert_real_bodies,
    # donc UN SEUL design.computeAll() par cible au lieu d'un par outil) -
    # la decoupe reelle (phase B ci-dessous) n'utilise alors plus que des
    # corps deja inseres, sans plus jamais appeler _insert_real_bodies dans
    # sa boucle. Comportement et resultat final STRICTEMENT IDENTIQUES
    # (memes corps crees, memes messages d'echec/repli sur le recouvrement
    # complet) - seul le NOMBRE de recalculs complets change.
    #
    # --- precomputed_real_bodies (optionnel, usage interne) : optimisation
    # du 2026-10-06, suite au retour utilisateur confirmant qu'un lot de
    # 50-70 cibles plantait encore vers la 30e/40e malgre le correctif du
    # 2026-10-05 ci-dessus (qui ramenait le nombre de recalculs complets a
    # UN PAR CIBLE au lieu d'un par outil - insuffisant quand le nombre de
    # CIBLES lui-meme est grand : 50-70 cibles restent 50-70 recalculs
    # complets d'affilee, dont le cout grandit avec la taille croissante de
    # l'historique). create_entaille_core_multi peut desormais
    # pre-calculer, pour TOUTES ses cibles a la fois, TOUS les corps
    # recortes necessaires, et les inserer en UN SEUL appel groupe (donc UN
    # SEUL design.computeAll() pour l'ENSEMBLE du lot, quel que soit le
    # nombre de cibles/outils) AVANT d'appeler create_entaille_core pour
    # chaque cible - voir son commentaire pour le detail. Quand ce
    # dictionnaire {(target.entityToken, tool.entityToken): real_body|None}
    # contient une entree pour un couple (cible, outil) donne, on l'utilise
    # directement ICI SANS refaire de recortage/insertion individuelle pour
    # ce couple. Quand il n'en contient PAS (cle absente - cas normal de
    # l'appel standalone CreateExecuteHandler, ou repli de securite), le
    # comportement EXACT d'avant cette optimisation reprend pour ce couple
    # precis : recortage + insertion groupee (mais seulement pour CETTE
    # cible, voir plus haut) via clip_pairs ci-dessous. ---
    real_body_by_tool_token = {}
    clip_pairs = []  # [(tb, corps_transitoire_recorte), ...] - repli, recortage reussi uniquement
    clip_transients = {}  # mode esquisse : {outil.entityToken: corps transitoire recorte}
    for tb in tool_bodies:
        main_normal, _lg = _axis_for(tb)
        if not (depth_cm > 1e-6 and main_normal is not None):
            continue
        key = None
        if precomputed_real_bodies is not None or precomputed_clips is not None:
            try:
                key = (target_body.entityToken, tb.entityToken)
            except Exception:
                key = None
        if key is not None and precomputed_real_bodies is not None and key in precomputed_real_bodies:
            real_body = precomputed_real_bodies[key]
            if real_body is None:
                messages.append(
                    'Retrait de profondeur : impossible de limiter la decoupe sur '
                    f'"{tb.name}" - recouvrement complet applique a la place.')
            else:
                try:
                    real_body_by_tool_token[tb.entityToken] = real_body
                except Exception:
                    pass
            continue  # deja traite via le pre-calcul groupe - pas de repli individuel
        clipped = None
        if precomputed_clips is not None and key is not None and key in precomputed_clips:
            clipped = precomputed_clips[key]
        else:
            try:
                clipped = _clip_tool_to_cible_zone(target_body, tb, main_normal, depth_cm, target_ref_point)
            except Exception:
                clipped = None
        if clipped is None:
            messages.append(
                'Retrait de profondeur : impossible a appliquer geometriquement sur '
                f'"{tb.name}" - recouvrement complet applique a la place.')
        elif _SKETCH_MODE:
            try:
                clip_transients[tb.entityToken] = clipped
            except Exception:
                clip_pairs.append((tb, clipped))
        else:
            clip_pairs.append((tb, clipped))

    if clip_pairs:
        inserted = _insert_real_bodies(design, root, [c for _, c in clip_pairs])
        for (tb, _c), real_body in zip(clip_pairs, inserted):
            if real_body is None:
                messages.append(
                    'Retrait de profondeur : impossible de limiter la decoupe sur '
                    f'"{tb.name}" - recouvrement complet applique a la place.')
            else:
                try:
                    real_body_by_tool_token[tb.entityToken] = real_body
                except Exception:
                    pass

    # --- PHASE B (decoupe reelle) : utilise simplement le corps deja
    # insere en phase A quand disponible (used_clip), sinon se replie sur
    # le corps outil complet (recouvrement entier) - EXACTEMENT le meme
    # repli qu'avant ce correctif. ---
    cible_ok = False
    deferred_tokens = set()
    for tb in tool_bodies:
        try:
            main_normal, _lg = _axis_for(tb)
            new_faces = []
            used_clip = False
            # Releve AVANT cette decoupe precise (voir _face_plane_key_set/
            # _classify_fond_lateral, correctif du 2026-10-07 : "en bout de
            # piece", la decoupe rogne aussi la face du dessus, celle du
            # dessous et/ou l'extremite - il faut les reperer pour les
            # exclure, meme si Feature.faces les inclut dans new_faces).
            existing_planes = _face_plane_key_set(target_body)
            try:
                real_body = real_body_by_tool_token.get(tb.entityToken)
            except Exception:
                real_body = None
            try:
                clipped = clip_transients.get(tb.entityToken)
            except Exception:
                clipped = None
            if clipped is not None:
                sk_feat = _sketch_cut_target(design, root, target_body, tb, clipped, main_normal)
                if sk_feat is not None:
                    new_faces = list(sk_feat.faces)
                    used_clip = True
                elif _deferred is not None:
                    # repli fige groupe plus tard (voir _flush_deferred_sketch)
                    _deferred.append({'target': target_body, 'tool': tb, 'clipped': clipped,
                                      'depth_cm': requested_depth_cm, 'axis_override': axis_override,
                                      'resolved': (tool_axes, main_normal_fallback,
                                                   _largeur_cible_fallback, target_ref_point,
                                                   depth_cm, False, _d_max),
                                      'entry_of': id(deferred_tokens)})
                    deferred_tokens.add(tb.entityToken)
                    continue
                else:
                    # repli fige pour CETTE entaille (ancien mode)
                    ins = _insert_real_bodies(design, root, [clipped])
                    real_body = ins[0] if ins else None
                    if real_body is None:
                        messages.append(
                            'Retrait de profondeur : impossible de limiter la decoupe sur '
                            f'"{tb.name}" - recouvrement complet applique a la place.')
            if real_body is not None and not used_clip:
                col = adsk.core.ObjectCollection.create()
                col.add(real_body)
                ci = combine_feats.createInput(target_body, col)
                ci.operation = adsk.fusion.FeatureOperations.CutFeatureOperation
                ci.isKeepToolBodies = False
                feat = combine_feats.add(ci)
                new_faces = list(feat.faces)
                used_clip = True
            if not used_clip:
                col = adsk.core.ObjectCollection.create()
                col.add(tb)
                ci = combine_feats.createInput(target_body, col)
                ci.operation = adsk.fusion.FeatureOperations.CutFeatureOperation
                # Le corps outil ORIGINAL doit survivre (reutilise a l'etape 3).
                ci.isKeepToolBodies = True
                feat = combine_feats.add(ci)
                new_faces = list(feat.faces)
            cible_ok = True
            _, lateral = _classify_fond_lateral(target_body, new_faces, main_normal,
                                                 existing_planes=existing_planes)
            if marge_auto:
                _apply_marge(lateral, target_body, marge_batch)
        except Exception:
            messages.append(f'Echec de la decoupe du corps cible (outil "{tb.name}") : '
                             + traceback.format_exc().strip().splitlines()[-1])
    all_deferred = bool(deferred_tokens) and len(deferred_tokens) == len(tool_bodies)
    if _deferred is not None:
        for e in _deferred:
            if e.get('entry_of') == id(deferred_tokens):
                e['target_counted'] = cible_ok
                e.pop('entry_of', None)
    n_total -= len(deferred_tokens)
    if cible_ok:
        n_ok += 1
    elif all_deferred:
        n_total -= 1  # cible comptee par l'appel differe
    else:
        messages.append("Echec de la decoupe du corps cible : aucun outil n'a pu etre applique.")
    if not _count_target:
        n_total -= 1
        if cible_ok:
            n_ok -= 1

    # --- 3) Decoupe de CHAQUE corps outil, en utilisant la cible dans son
    # etat FINAL (apres l'eventuel retrait de l'etape 1) comme outil :
    # puisque la cible a "repris" exactement <depth_cm> de profondeur de
    # matiere a l'etape 1, cette decoupe retire du corps outil PRECISEMENT
    # cette meme profondeur, a l'endroit du croisement - verifie en direct.
    # A depth_cm=0, les deux corps sont exactement coincidents a cet
    # endroit (aucune matiere a retirer) : on saute carrement cette
    # decoupe pour ne pas encombrer l'historique d'une feature sans effet
    # (comportement par defaut verifie en direct : "tout sur la cible").
    # Axe LOCAL de CET outil desormais (meme correctif que l'etape 1). ---
    if depth_cm > 0.0:
        for tb in tool_bodies:
            try:
                if tb.entityToken in deferred_tokens:
                    continue  # coupe reciproque faite par l'appel differe
            except Exception:
                pass
            try:
                main_normal, _lg = _axis_for(tb)
                existing_planes_tb = _face_plane_key_set(tb)
                col = adsk.core.ObjectCollection.create()
                col.add(target_body)
                ci = combine_feats.createInput(tb, col)
                ci.operation = adsk.fusion.FeatureOperations.CutFeatureOperation
                ci.isKeepToolBodies = True
                feat = combine_feats.add(ci)
                n_ok += 1
                _, lateral_t = _classify_fond_lateral(tb, list(feat.faces), main_normal,
                                                       existing_planes=existing_planes_tb)
                if marge_auto:
                    _apply_marge(lateral_t, tb, marge_batch)
            except Exception:
                messages.append('Echec de la decoupe reciproque sur un corps de decoupe : '
                                 + traceback.format_exc().strip().splitlines()[-1])
    else:
        n_ok += len(tool_bodies) - len(deferred_tokens)  # comportement par defaut voulu : pas de decoupe cote outil

    if owns_marge_batch:
        _flush_marge_batch(design, root, marge_batch, messages)

    return {'error': None, 'n_cotes_ok': n_ok, 'n_cotes_total': n_total, 'messages': messages}


def _flush_deferred_sketch(design, root, deferred, marge_auto, marge_batch, messages):
    """Entailles dont l'esquisse a ete refusee (voir _deferred dans
    create_entaille_core) : leurs corps recoupes sont inseres TOUS dans une
    seule BaseFeature (un seul design.computeAll() au lieu d'un par
    entaille), puis chaque entaille est coupee comme dans l'ancien mode fige.
    Retourne (n_ok, n_total)."""
    if not deferred:
        return 0, 0
    cnc_progress.etape('Entaille : coupes figees (%d)...' % len(deferred))
    inserted = _insert_real_bodies(design, root, [e['clipped'] for e in deferred])
    n_ok = n_total = 0
    for e, rb in zip(deferred, inserted):
        try:
            key = (e['target'].entityToken, e['tool'].entityToken)
        except Exception:
            key = None
        pre = {key: rb} if key is not None else None
        r = create_entaille_core(design, e['target'], [e['tool']], e['depth_cm'], marge_auto,
                                  axis_override=e['axis_override'], _marge_batch=marge_batch,
                                  precomputed_real_bodies=pre, precomputed_resolved=e['resolved'],
                                  _count_target=not e.get('target_counted', False))
        if r.get('error'):
            messages.append('Entaille "%s" x "%s" : %s' % (
                _safe_name(e['target']), _safe_name(e['tool']), r['error']))
            continue
        n_ok += r.get('n_cotes_ok', 0)
        n_total += r.get('n_cotes_total', 0)
        for m in r.get('messages', []):
            if m not in messages:
                messages.append(m)
    return n_ok, n_total


def create_entaille_core_multi(design, target_bodies, tool_bodies, depth_cm, marge_auto):
    """Generalisation de create_entaille_core a PLUSIEURS cibles a la fois
    (retour utilisateur du 2026-10-03, apres les 2 corrections d'axe/cote
    precedentes) : pour un assemblage "enfourchement" ou la TRAVERSE doit
    rentrer DANS chaque MONTANT (et non l'inverse - cas d'une traverse
    partagee qui croise de nombreux montants), c'est logiquement chaque
    MONTANT qui doit jouer le role de cible (il recoit la cavite complete
    a retrait=0, exactement comme avant) et la traverse qui joue le role
    de l'unique outil, commun a toutes ces cibles. L'ancienne UI/API ne
    permettait qu'UNE SEULE cible a la fois (create_entaille_core), ce qui
    obligeait a repeter l'operation a la main une fois par montant.

    Boucle simplement create_entaille_core UNE FOIS PAR CIBLE, contre le(s)
    MEME(S) corps outil(s) partage(s) - aucune modification du coeur de
    calcul deja verifie en direct (axe par outil, cote fond/exterieur) :
    chaque passage est independant et traite sa cible comme avant. A
    retrait=0 (cas par defaut), l'outil partage n'est jamais modifie entre
    deux cibles (voir le principe en tete de fichier - l'outil n'est pas
    entaille du tout), donc l'ordre des cibles n'a aucune importance. A
    retrait>0, l'outil accumule une entaille reciproque A CHAQUE croisement
    (un par cible), ce qui est exactement le comportement mi-bois voulu a
    chaque montant.

    Avec une seule cible (target_bodies de longueur 1), comportement
    STRICTEMENT IDENTIQUE a create_entaille_core (aucune regression sur le
    cas d'usage existant "1 traverse cible + N montants outils") - cette
    fonction ne fait qu'agreger les compteurs/messages de chaque passage.

    Retourne {'error': str|None, 'n_cotes_ok': int, 'n_cotes_total': int,
              'messages': [str, ...]} (meme forme que create_entaille_core,
              sommee sur toutes les cibles)."""
    target_bodies = [tb for tb in (target_bodies or []) if tb is not None]
    if not target_bodies:
        return {'error': 'aucun corps cible', 'n_cotes_ok': 0, 'n_cotes_total': 0, 'messages': []}
    n_ok_total = 0
    n_total_total = 0
    messages = []
    root = design.rootComponent
    # Optimisation de vitesse du 2026-10-04 (demande explicite de Maxence) :
    # UNE SEULE liste de marge, partagee par TOUTES les cibles de cet appel
    # - voir _apply_marge/_flush_marge_batch. Chaque create_entaille_core
    # ci-dessous y accumule ses enregistrements SANS les appliquer lui-meme
    # (on lui passe _marge_batch) ; _flush_marge_batch n'est appele qu'UNE
    # FOIS, apres la boucle, pour TOUTES les cibles a la fois - au lieu de
    # jusqu'a 2 allers-retours disque + 1 feature d'offset Fusion PAR
    # CIBLE.
    marge_batch = []
    # --- Axe de largeur : voir axis_override / docstring de
    # create_entaille_core (retour utilisateur du 2026-10-dd, "les entailles
    # se font mal dans les arrondis" - REAPPARITION du tout premier bug
    # corrige dans cette session, roles inverses). Avec UNE SEULE cible
    # (len==1 - l'usage HISTORIQUE "1 traverse cible courbe + N montants
    # outils"), on NE CHANGE RIEN : create_entaille_core calcule deja l'axe
    # par outil (chaque montant, simple/local) via _compute_tool_axes,
    # c'est deja correct, memes les corners - comportement IDENTIQUE a
    # avant. Avec PLUSIEURS cibles (len>1 - l'usage "enfourchement" : N
    # montants cibles, simples/locaux, face a UNE traverse-outil COURBE
    # partagee), calculer l'axe a partir de l'outil (la traverse, courbe)
    # reproduirait exactement le bug d'origine (un seul axe global faux
    # dans les coins) - on utilise donc l'axe propre de CHAQUE cible (le
    # montant, simple, local a ce croisement precis) a la place, via
    # axis_override. ---
    use_axis_override = len(target_bodies) > 1

    # --- Pre-calcul GROUPE de TOUS les corps outils recortes, pour TOUTES
    # les cibles a la fois, en UNE SEULE insertion/UN SEUL
    # design.computeAll() pour l'ENSEMBLE du lot - optimisation du
    # 2026-10-06, suite au retour utilisateur confirmant qu'un lot de 50-70
    # cibles plantait encore vers la 30e/40e malgre le regroupement PAR
    # CIBLE du 2026-10-05 (voir le commentaire PHASE A dans
    # create_entaille_core) : avec 50-70 cibles, meme "un seul recalcul par
    # cible" reste 50-70 recalculs COMPLETS d'affilee, dont le cout grandit
    # avec la taille croissante de l'historique deja construite par les
    # entailles precedentes - confirme par Maxence ("ca commence a
    # planter vers la 30e/40e").
    #
    # On utilise _resolve_axis_and_depth (FACTORISEE - voir sa docstring)
    # pour calculer, pour CHAQUE cible, EXACTEMENT le meme axe par outil et
    # le meme retrait effectif (apres bridage au recouvrement disponible)
    # que ce que create_entaille_core recalculera lui-meme independamment
    # pour cette meme cible au moment de la decoupe reelle - c'est ESSENTIEL
    # pour que les corps recortes ici correspondent exactement a ce qui
    # sera reellement utilise. Tous les recortages (_clip_tool_to_cible_zone)
    # de TOUTES les cibles sont ainsi accumules PUREMENT EN MEMOIRE
    # TRANSITOIRE (aucun recalcul), puis inseres TOUS ENSEMBLE en un seul
    # appel _insert_real_bodies - UN SEUL design.computeAll() pour tout le
    # lot, que ce soit 2 cibles ou 70. create_entaille_core (ci-dessous)
    # utilise alors directement ces corps deja inseres (precomputed_real_bodies)
    # et ne fait plus JAMAIS sa propre insertion individuelle dans le cas
    # normal - son repli (recortage/insertion par cible) ne sert plus que
    # de filet de securite si une cible precise manquait au pre-calcul.
    # Comportement et resultat final STRICTEMENT IDENTIQUES a avant (memes
    # corps crees, memes messages) - seul le NOMBRE de recalculs complets
    # change (1 au lieu de N, au lieu de N*M avant le 2026-10-05). ---
    precomputed_real_bodies = {}
    precomputed_clips = {}
    resolved_by_target = {}  # {cible.entityToken: tuple de _resolve_axis_and_depth}
    if depth_cm > 1e-6:
        clip_entries = []  # [((cible.entityToken, outil.entityToken), corps_transitoire), ...]
        cnc_progress.etape('Entaille : calcul des coupes...', 0, len(target_bodies))
        for tb_cible in target_bodies:
            cnc_progress.avance()
            axis_override_c = None
            if use_axis_override:
                try:
                    n, lg = _true_largeur(tb_cible, get_largeur_fallback(tb_cible))
                    if n is not None:
                        axis_override_c = (n, lg)
                except Exception:
                    axis_override_c = None
            try:
                resolved_c = _resolve_axis_and_depth(
                    tb_cible, tool_bodies, depth_cm, axis_override_c)
                (tool_axes_c, main_normal_fallback_c, largeur_fallback_c, target_ref_point_c,
                 eff_depth_c, _clamped_c, _dmax_c) = resolved_c
            except Exception:
                continue
            try:
                target_token = tb_cible.entityToken
            except Exception:
                target_token = None
            if target_token is not None:
                resolved_by_target[target_token] = resolved_c
            if eff_depth_c <= 1e-6:
                continue
            if target_token is None:
                continue
            for tb in tool_bodies:
                try:
                    main_normal_c, _lg_c = tool_axes_c.get(
                        tb.entityToken, (main_normal_fallback_c, largeur_fallback_c))
                except Exception:
                    main_normal_c = main_normal_fallback_c
                if main_normal_c is None:
                    continue
                try:
                    clipped = _clip_tool_to_cible_zone(
                        tb_cible, tb, main_normal_c, eff_depth_c, target_ref_point_c)
                except Exception:
                    clipped = None
                if clipped is None:
                    continue
                try:
                    tool_token = tb.entityToken
                except Exception:
                    tool_token = None
                if tool_token is not None:
                    clip_entries.append(((target_token, tool_token), clipped))
        if clip_entries and _SKETCH_MODE:
            precomputed_clips = dict(clip_entries)  # esquisse d'abord, repli fige au cas par cas
        elif clip_entries:
            cnc_progress.etape('Entaille : insertion dans le modele...')
            inserted = _insert_real_bodies(design, root, [c for _, c in clip_entries])
            for (key, _c), real_body in zip(clip_entries, inserted):
                precomputed_real_bodies[key] = real_body  # peut etre None (echec d'insertion pour CE couple)

    deferred = []  # esquisses refusees : repli fige groupe (_flush_deferred_sketch)
    cnc_progress.etape('Entaille : decoupe des pieces...', 0, len(target_bodies))
    for tb_cible in target_bodies:
        cnc_progress.avance()
        axis_override = None
        if use_axis_override:
            try:
                n, lg = _true_largeur(tb_cible, get_largeur_fallback(tb_cible))
                if n is not None:
                    axis_override = (n, lg)
            except Exception:
                axis_override = None
        try:
            resolved_pre = resolved_by_target.get(tb_cible.entityToken)
        except Exception:
            resolved_pre = None
        r = create_entaille_core(design, tb_cible, tool_bodies, depth_cm, marge_auto,
                                  axis_override=axis_override, _marge_batch=marge_batch,
                                  precomputed_real_bodies=precomputed_real_bodies,
                                  precomputed_resolved=resolved_pre,
                                  precomputed_clips=precomputed_clips,
                                  _deferred=deferred)
        if r.get('error'):
            # Une cible en echec ne doit pas bloquer les autres - chaque
            # passage est independant - mais on garde une trace du nom de
            # la cible concernee dans le message pour pouvoir identifier
            # laquelle a echoue.
            try:
                nom = tb_cible.name
            except Exception:
                nom = '?'
            messages.append('Cible "%s" : %s' % (nom, r['error']))
            continue
        n_ok_total += r.get('n_cotes_ok', 0)
        n_total_total += r.get('n_cotes_total', 0)
        messages.extend(r.get('messages', []))
    _d_ok, _d_tot = _flush_deferred_sketch(design, root, deferred, marge_auto, marge_batch, messages)
    n_ok_total += _d_ok
    n_total_total += _d_tot
    cnc_progress.etape('Jeux de fonctionnement...')
    _flush_marge_batch(design, root, marge_batch, messages)
    return {'error': None, 'n_cotes_ok': n_ok_total, 'n_cotes_total': n_total_total, 'messages': messages}


_preview_cg_groups = []  # liste de CustomGraphicsGroup, UN par outil en
                          # recouvrement (bug remonte par Maxence : avant
                          # ce correctif, un SEUL groupe partage entre tous
                          # les outils - voir compute_entaille_preview)


def _clear_preview_graphics():
    """Supprime TOUS les groupes de graphiques legers affiches (s'il y en
    a - un par outil desormais, voir compute_entaille_preview), meme
    mecanisme que TenonCNC._clear_preview_graphics (CustomGraphics, aucune
    modification du document)."""
    global _preview_cg_groups
    for g in (_preview_cg_groups or []):
        try:
            if g is not None:
                g.deleteMe()
        except Exception:
            pass
    _preview_cg_groups = []


def compute_entaille_preview(design, target_body, tool_bodies, depth_cm=0.0, _accumulate=False, axis_override=None):
    """Calcule l'apercu de la zone de recouvrement entre target_body et
    tool_bodies, SANS modifier le document (uniquement en memoire
    temporaire, via TemporaryBRepManager - aucune feature/corps reel
    cree). Dessine un fil de fer leger (CustomGraphics, meme technique que
    TenonCNC._draw_tenon_preview_graphics) representant la zone qui sera
    decoupee.

    Approximation assumee : la zone affichee est l'INTERSECTION geometrique
    de target_body et tool_bodies - une bonne approximation visuelle de la
    cavite qui sera creusee dans le corps cible, mais pas necessairement
    identique a ce qui sera retire de chaque corps outil (qui depend de la
    decoupe reciproque reelle, voir create_entaille_core) - suffisant pour
    un apercu live.

    depth_cm est le retrait de profondeur actuellement affiche dans le
    panneau (avant creation reelle) : cette fonction applique EXACTEMENT le
    meme bridage que create_entaille_core (voir _measure_overlap_depth,
    desormais le long de l'axe de LARGEUR - voir le commentaire de
    correction d'axe en tete de fichier) afin que le schema 2D cote
    palette.html affiche fidelement ce qui sera reellement cree, y compris
    quand le retrait demande est trop grand.

    Retourne {'ok': bool, 'reason': str|None, 'largeur_mm': float|None,
              'overlap_mm': float|None, 'retrait_mm': float|None,
              'cible_mm': float|None, 'retrait_clamped': bool,
              'retrait_defaut_mm': float|None} -
    largeur_mm = largeur de la cible (axe de reference, voir
    _true_largeur) ; overlap_mm = profondeur totale de recouvrement (D, la
    plus petite parmi tous les corps outils) ; retrait_mm = retrait
    reellement applique (apres bridage eventuel) ; cible_mm = overlap_mm -
    retrait_mm (profondeur reellement retiree du corps cible) ;
    retrait_defaut_mm = la valeur de retrait PROPOSEE par defaut avant toute
    saisie manuelle (voir _default_retrait_cm - proportionnelle a la
    largeur relative cible/outil).

    _accumulate (usage interne, voir compute_entaille_preview_multi) : si
    True, ne nettoie PAS les groupes de graphiques d'apercu existants au
    debut (l'appelant l'a deja fait une seule fois pour toutes les cibles)
    et AJOUTE les nouveaux groupes a _preview_cg_groups au lieu de les
    remplacer - permet d'empiler l'apercu de plusieurs cibles dans la
    meme vue 3D sans que chaque cible efface le fil de fer de la
    precedente."""
    global _preview_cg_groups
    if not _accumulate:
        _clear_preview_graphics()
    empty = {'ok': False, 'reason': None, 'largeur_mm': None,
             'largeur_outil_mm': None,
             'overlap_mm': None, 'retrait_mm': None, 'cible_mm': None,
             'retrait_clamped': False, 'retrait_defaut_mm': None}
    if target_body is None or not tool_bodies:
        return dict(empty)
    tbm = adsk.fusion.TemporaryBRepManager.get()
    try:
        # --- Recouvrement INDIVIDUEL par outil (correctif du bug remonte
        # par Maxence : "quand je selectionne plusieurs outils ... le
        # preview 3D disparait sur tout les outils au lieu de s'afficher
        # sur chaque outil"). AVANT ce correctif, une SEULE intersection
        # etait calculee en cumulant TOUS les corps outils sur le MEME
        # preview_body (cible ∩ outil1 ∩ outil2 ∩ ...) : des que 2 outils
        # occupent des zones differentes de la cible (cas normal - chaque
        # entaille est a un endroit different), cette intersection globale
        # devient vide, et plus AUCUN fil de fer n'etait affiche, pour
        # aucun outil. Chaque outil calcule desormais sa PROPRE zone de
        # recouvrement (cible ∩ outil_i), independamment des autres. ---
        per_tool_preview = []  # [(tool_body, preview_body_i), ...]
        for tb in tool_bodies:
            try:
                pb = tbm.copy(target_body)
                tool_copy = tbm.copy(tb)
                if (tbm.booleanOperation(pb, tool_copy,
                                          adsk.fusion.BooleanTypes.IntersectionBooleanType)
                        and pb.faces.count > 0):
                    per_tool_preview.append((tb, pb))
            except Exception:
                continue
        if not per_tool_preview:
            r = dict(empty)
            r['reason'] = 'aucun_recouvrement'
            return r

        largeur_mm = None
        largeur_cible_cm = None
        main_normal_fallback = None
        try:
            main_normal_fallback, largeur_cible_cm = _true_largeur(target_body, get_largeur_fallback(target_body))
            largeur_mm = round(largeur_cible_cm * 10, 3)
        except Exception:
            pass

        # --- Axe de largeur PAR OUTIL (voir _compute_tool_axes / le meme
        # correctif applique a create_entaille_core - EXACTEMENT le meme
        # calcul, pour que l'apercu reste fidele a ce qui sera reellement
        # cree) : chaque outil utilise sa propre largeur locale plutot
        # qu'un axe global unique calcule sur toute la cible, qui ne vaut
        # pas dans les coins/sur l'autre brin d'une cible courbe. SAUF si
        # axis_override est fourni (voir create_entaille_core et
        # compute_entaille_preview_multi) : meme bascule que cote creation,
        # necessaire quand c'est l'OUTIL partage qui est le corps
        # courbe/complexe (ex. la traverse dans le cas "enfourchement" a
        # plusieurs cibles) - l'axe doit alors venir de la cible (simple,
        # locale), pas de l'outil. ---
        if axis_override is not None:
            # Ecrase main_normal_fallback/largeur_cible_cm (calcules juste
            # au-dessus a partir de la SEULE cible, ligne ~1374) - ce sont
            # EUX que _axis_for utilise comme repli (voir plus bas), pas
            # les valeurs de retour (ignorees via _mnf/_lcf) de
            # _compute_tool_axes.
            tool_axes = {}
            main_normal_fallback, largeur_cible_cm = axis_override
        else:
            tool_axes, _mnf, _lcf = _compute_tool_axes(target_body, tool_bodies)

        # --- Meme point de reference GLOBAL et FIXE que create_entaille_core
        # (voir _entaille_ref_point/_pick_fond_side) - indispensable pour que
        # l'apercu reste fidele au cote reellement choisi lors de la
        # creation. ---
        target_ref_point = _entaille_ref_point(target_body, tool_bodies)

        def _axis_for(tb):
            try:
                return tool_axes.get(tb.entityToken, (main_normal_fallback, largeur_cible_cm))
            except Exception:
                return main_normal_fallback, largeur_cible_cm

        # --- Profondeur de recouvrement reelle (D, mm) et retrait bride -
        # EXACTEMENT le meme calcul que le bridage de securite dans
        # create_entaille_core (desormais par outil, voir le commentaire
        # la-bas), pour que le schema 2D soit fidele a ce qui sera
        # reellement cree. ---
        overlap_mm = None
        d_max = None
        retrait_cm = max(0.0, float(depth_cm or 0.0))
        retrait_clamped = False
        depths = []
        for tb in tool_bodies:
            n, _lg = _axis_for(tb)
            if n is None:
                continue
            d = _measure_overlap_depth(target_body, tb, n)
            if d is not None:
                depths.append(d)
        if depths:
            d_max = min(depths)
            overlap_mm = round(d_max * 10, 3)
            if retrait_cm > d_max - 1e-5:
                retrait_cm = max(0.0, d_max - 0.001)
                retrait_clamped = True
        retrait_mm = round(retrait_cm * 10, 3)
        cible_mm = round(overlap_mm - retrait_mm, 3) if overlap_mm is not None else None

        # --- Fil de fer d'apercu : UN DESSIN SEPARE PAR OUTIL (chacun sa
        # propre zone de recouvrement calculee ci-dessus), chacun EN DEUX
        # COULEURS si possible (orange = portion reellement retiree de la
        # cible, bleu = portion "retrait" conservee sur la cible et
        # retiree a la place sur l'outil - voir _draw_split_wireframe),
        # pour que le preview 3D bouge reellement quand on change le
        # retrait (retour utilisateur : "je ne vois pas le preview se
        # deplacer"). Degrade, INDEPENDAMMENT pour chaque outil, au fil de
        # fer simple (une seule couleur, zone de recouvrement complete de
        # cet outil) si l'axe de largeur ou le cote "fond" n'ont pas pu
        # etre determines pour celui-ci. ---
        root = design.rootComponent
        groups = []
        for tb, pb in per_tool_preview:
            cg_group = None
            main_normal, _lg = _axis_for(tb)
            if main_normal is not None:
                try:
                    cg_group = _draw_split_wireframe(root, pb, target_body, main_normal, retrait_cm, target_ref_point)
                except Exception:
                    cg_group = None
            if cg_group is None:
                coords_flat = []
                strip_lengths = []
                for edge in pb.edges:
                    try:
                        sp = edge.startVertex.geometry
                        ep = edge.endVertex.geometry
                    except Exception:
                        continue
                    coords_flat += [sp.x, sp.y, sp.z, ep.x, ep.y, ep.z]
                    strip_lengths.append(2)
                if coords_flat:
                    cg_group = root.customGraphicsGroups.add()
                    coords = adsk.fusion.CustomGraphicsCoordinates.create(coords_flat)
                    lines = cg_group.addLines(coords, [], True, strip_lengths)
                    try:
                        lines.color = adsk.fusion.CustomGraphicsSolidColorEffect.create(
                            adsk.core.Color.create(255, 90, 0, 255))
                        lines.weight = 4.0
                    except Exception:
                        pass
            if cg_group is not None:
                groups.append(cg_group)
        if _accumulate:
            _preview_cg_groups.extend(groups)
        else:
            _preview_cg_groups = groups

        # --- Retrait propose par defaut (voir _default_retrait_cm) : au
        # prorata de la largeur de la cible et de la PLUS PETITE largeur
        # parmi les corps outils (le plus "fragile", meme logique
        # prudente que le bridage ci-dessus qui prend le plus petit
        # recouvrement). Purement indicatif pour l'UI (champ "Auto" cote
        # palette.html) - n'affecte ni le bridage ci-dessus ni
        # create_entaille_core. largeur_outil_mm (ajoute le 2026-10-04,
        # retour utilisateur "bouton 1/2 Cible et 1/2 Outil") : la largeur
        # de l'outil le plus etroit, exposee separement pour que le
        # panneau puisse calculer "1/2 Outil" (moitie de CETTE largeur) en
        # plus de "1/2 Cible" (moitie de largeur_mm, deja expose) et de
        # "Auto" (retrait_defaut_mm). ---
        retrait_defaut_mm = None
        largeur_outil_mm = None
        tool_largeurs = []
        for tb in tool_bodies:
            try:
                _n, lg = _true_largeur(tb, get_largeur_fallback(tb))
                if lg is not None:
                    tool_largeurs.append(lg)
            except Exception:
                continue
        if tool_largeurs:
            largeur_outil_cm = min(tool_largeurs)
            largeur_outil_mm = round(largeur_outil_cm * 10, 3)
            if d_max is not None and largeur_cible_cm is not None:
                retrait_defaut_mm = round(
                    _default_retrait_cm(largeur_cible_cm, largeur_outil_cm, d_max) * 10, 3)

        return {'ok': True, 'reason': None, 'largeur_mm': largeur_mm,
                'largeur_outil_mm': largeur_outil_mm,
                'overlap_mm': overlap_mm, 'retrait_mm': retrait_mm,
                'cible_mm': cible_mm, 'retrait_clamped': retrait_clamped,
                'retrait_defaut_mm': retrait_defaut_mm}
    except Exception:
        _dbg('ERREUR compute_entaille_preview: ' + traceback.format_exc())
        _clear_preview_graphics()
        r = dict(empty)
        r['reason'] = 'calcul_impossible'
        return r


def compute_entaille_preview_multi(design, target_bodies, tool_bodies, depth_cm=0.0):
    """Generalisation de compute_entaille_preview a PLUSIEURS cibles a la
    fois - voir create_entaille_core_multi (meme retour utilisateur du
    2026-10-03) dont ceci est le pendant "apercu live" cote panneau.

    Calcule l'apercu de CHAQUE cible independamment (un fil de fer 3D par
    cible, empile dans la meme vue - voir le parametre _accumulate de
    compute_entaille_preview), puis agrege les quelques chiffres affiches
    dans le schema 2D du panneau (largeur/overlap/retrait/cible_mm) sur la
    paire cible/outil la PLUS CONTRAIGNANTE (le plus petit recouvrement
    parmi toutes les cibles) - purement indicatif, meme logique prudente
    que le bridage deja utilise entre plusieurs outils d'une seule cible ;
    la creation reelle (create_entaille_core_multi) recalcule de toute
    facon son propre bridage exact, independamment pour chaque cible.

    Avec une seule cible, comportement STRICTEMENT IDENTIQUE a
    compute_entaille_preview (aucune regression).

    Retourne le meme dict que compute_entaille_preview, plus
    'n_cibles_ok'/'n_cibles_total' (nombre de cibles en recouvrement
    valide / nombre total de cibles selectionnees - permet au panneau
    d'afficher par exemple "18/20 montants en recouvrement" si certains ne
    touchent pas la traverse)."""
    _clear_preview_graphics()
    empty = {'ok': False, 'reason': None, 'largeur_mm': None,
             'largeur_outil_mm': None,
             'overlap_mm': None, 'retrait_mm': None, 'cible_mm': None,
             'retrait_clamped': False, 'retrait_defaut_mm': None,
             'n_cibles_ok': 0, 'n_cibles_total': 0}
    target_bodies = [tb for tb in (target_bodies or []) if tb is not None]
    if not target_bodies or not tool_bodies:
        return dict(empty)
    # --- Axe de largeur : meme bascule que create_entaille_core_multi (voir
    # son commentaire) - avec plusieurs cibles, l'axe doit venir de CHAQUE
    # cible (simple/locale, ex. un montant) plutot que de l'outil partage
    # (potentiellement courbe, ex. la traverse), sous peine de reproduire le
    # tout premier bug "entailles fausses dans les coins" avec les roles
    # inverses. Avec une seule cible, inchange (aucune regression). ---
    use_axis_override = len(target_bodies) > 1
    results = []
    cnc_progress.etape('Entaille : decoupe des pieces...', 0, len(target_bodies))
    for tb_cible in target_bodies:
        cnc_progress.avance()
        axis_override = None
        if use_axis_override:
            try:
                n, lg = _true_largeur(tb_cible, get_largeur_fallback(tb_cible))
                if n is not None:
                    axis_override = (n, lg)
            except Exception:
                axis_override = None
        try:
            r = compute_entaille_preview(design, tb_cible, tool_bodies, depth_cm, _accumulate=True, axis_override=axis_override)
        except Exception:
            r = dict(empty)
        results.append(r)
    valid = [r for r in results if r.get('ok') and r.get('overlap_mm') is not None]
    out = dict(empty)
    out['n_cibles_total'] = len(target_bodies)
    out['n_cibles_ok'] = len(valid)
    if not valid:
        out['reason'] = results[0].get('reason') if results else 'aucun_recouvrement'
        return out
    out['ok'] = True
    worst = min(valid, key=lambda r: r['overlap_mm'])
    out['largeur_mm'] = worst['largeur_mm']
    out['largeur_outil_mm'] = worst.get('largeur_outil_mm')
    out['overlap_mm'] = worst['overlap_mm']
    out['retrait_mm'] = worst['retrait_mm']
    out['cible_mm'] = worst['cible_mm']
    out['retrait_clamped'] = any(r.get('retrait_clamped') for r in valid)
    defauts = [r['retrait_defaut_mm'] for r in valid if r.get('retrait_defaut_mm') is not None]
    out['retrait_defaut_mm'] = min(defauts) if defauts else None
    return out


# ================================================================
# MODE "SELECTION UNIQUE" (demande de Maxence, 2026-10-06)
#
# Au lieu de choisir separement la/les cible(s) et le/les outil(s), on
# selectionne TOUS les corps d'un coup : chaque couple de corps qui se
# recouvre (volume commun non nul) devient une paire a entailler, et le
# sens de l'entaille est deduit de la geometrie du recouvrement.
#
# Principe de detection (voir _auto_classify_pair) : pour chaque corps, et
# le long de chacun de ses 3 axes principaux (_true_axis_dims), on regarde
# si le recouvrement touche ses deux bords ('full'), un seul ('lo'/'hi')
# ou aucun ('int') :
#   - INSERTION : un corps est recouvert sur toute son epaisseur et toute
#     sa largeur et n'entre que par un bout (ex. une etagere qui s'arrete
#     dans l'epaisseur d'un montant) -> toute l'entaille va dans l'autre
#     corps, le corps insere n'est pas touche.
#   - MI-BOIS : le long d'un axe commun aux 2 corps, le recouvrement touche
#     un bord de l'un et/ou de l'autre -> chaque corps s'ouvre du cote du
#     bord touche (ex. un 100 a ras du bord bas d'un 200 et qui monte
#     jusqu'a son milieu : le 200 s'ouvre par le bas, le 100 par le haut).
#     Partage de profondeur : meme regle proportionnelle que le mode
#     cible/outils (_default_retrait_cm), ou 50/50 en mode 'moitie'.
#   - AMBIGU : les 2 corps sont entierement croises (meme largeur) ou se
#     chevauchent en mi-bois d'angle -> sens par defaut, inversable paire
#     par paire depuis l'apercu (choix de Maxence : c'est l'apercu qui
#     valide le sens avant creation).
#   - Recouvrement qui ne touche aucun bord -> paire ignoree et signalee
#     (c'est une mortaise, pas une entaille).
#
# La creation reutilise TEL QUEL create_entaille_core (paire par paire,
# cible = 1er corps de la paire, outil = 2e) : le sens est impose en
# remplacant le point de reference de _pick_fond_side par un point place
# loin du cote ou la cible doit s'ouvrir (le cote "fond", qui garde la
# matiere de la cible et recoit l'entaille de l'outil, est toujours le
# plus eloigne de ce point).
# ================================================================

_AUTO_TOL_CM = 0.1         # 1 mm : tolerance "a ras d'un bord" (marge d'erreur demandee
                           # par Maxence : un corps a quelques dixiemes du bord compte
                           # comme a ras, et la fine paroi restante est retiree, voir
                           # _auto_skin_bodies)
_AUTO_SKIN_MIN_CM = 0.001  # en dessous de 0.01 mm, pas de paroi a retirer
_AUTO_MIN_VOL_CM3 = 1e-3   # 1 mm3 : en dessous, simple contact ignore
_AUTO_FAR_CM = 1000.0


def _auto_norm_axis(v):
    """Copie normalisee de v, orientee pour que sa plus grande composante
    soit positive (sens deterministe d'un corps a l'autre)."""
    v = v.copy()
    v.normalize()
    comps = [v.x, v.y, v.z]
    i = max(range(3), key=lambda k: abs(comps[k]))
    if comps[i] < 0:
        v.scaleBy(-1)
    return v


def _auto_extent(entity, axis):
    """(min, max) de entity (corps reel ou transitoire) le long de axis."""
    try:
        wd = _pick_width_dir(axis)
        if wd is None:
            return None
        obb = adsk.core.Application.get().measureManager.getOrientedBoundingBox(entity, axis, wd)
        if obb is None:
            return None
        c = obb.centerPoint
        cp = c.x * axis.x + c.y * axis.y + c.z * axis.z
        half = obb.length / 2.0
        return (cp - half, cp + half)
    except Exception:
        return None


def _auto_body_axes(body):
    """Les 3 axes principaux normalises du corps (epaisseur en premier), ou
    None si le corps n'est pas un panneau analysable."""
    try:
        dims = _true_axis_dims(body)
    except Exception:
        return None
    axes = [_auto_norm_axis(n) for n, _d in dims]
    if len(axes) == 2:
        axes.append(_auto_norm_axis(axes[0].crossProduct(axes[1])))
    if len(axes) < 3:
        return None
    return axes


def _auto_is_curved(body):
    """True si le corps a au moins une face non plane (ex. traverse
    cintree) : ses axes globaux (_true_axis_dims) ne valent alors pas dans
    les arrondis, on lui prete ceux de l'autre corps de la paire."""
    try:
        for f in body.faces:
            if not isinstance(f.geometry, adsk.core.Plane):
                return True
    except Exception:
        return True
    return False


def _auto_local_extent(body, ov, axis):
    """(min, max) de body le long de axis, mais LOCALEMENT a travers la
    zone de recouvrement ov : body est d'abord coupe par une "tranche"
    infinie le long de axis dont la section est celle du recouvrement
    (reduite a 80 %). Correct sur un corps droit comme sur une traverse
    cintree (on ne mesure que la portion qui traverse le croisement, pas
    toute la traverse). Si la tranche traverse le corps a plusieurs
    endroits (ex. traverse en U), seul le morceau qui contient le
    recouvrement est garde."""
    try:
        wd = _pick_width_dir(axis)
        if wd is None:
            return None
        obb = adsk.core.Application.get().measureManager.getOrientedBoundingBox(ov, axis, wd)
        if obb is None:
            return None
        tbm = adsk.fusion.TemporaryBRepManager.get()
        slab_def = adsk.core.OrientedBoundingBox3D.create(
            obb.centerPoint, obb.lengthDirection, obb.widthDirection,
            2 * _AUTO_FAR_CM, max(obb.width * 0.8, 1e-3), max(obb.height * 0.8, 1e-3))
        part = tbm.copy(body)
        if not tbm.booleanOperation(part, tbm.createBox(slab_def),
                                    adsk.fusion.BooleanTypes.IntersectionBooleanType):
            return None
        if part.faces.count == 0:
            return None
        ov_rng = _auto_extent(ov, axis)
        try:
            n_lumps = part.lumps.count
        except Exception:
            n_lumps = 1
        if n_lumps <= 1 or ov_rng is None:
            return _auto_extent(part, axis)
        oc = (ov_rng[0] + ov_rng[1]) / 2.0
        best = None
        for lump in part.lumps:
            vals = []
            for f in lump.faces:
                for v in f.vertices:
                    g = v.geometry
                    vals.append(g.x * axis.x + g.y * axis.y + g.z * axis.z)
            if not vals:
                continue
            rng = (min(vals), max(vals))
            if rng[0] - _AUTO_TOL_CM <= oc <= rng[1] + _AUTO_TOL_CM:
                if best is None or (rng[1] - rng[0]) > (best[1] - best[0]):
                    best = rng
        return best if best is not None else _auto_extent(part, axis)
    except Exception:
        return None


def _auto_status(body_rng, ov_rng):
    if body_rng is None or ov_rng is None:
        return 'int'
    lo = abs(ov_rng[0] - body_rng[0]) <= _AUTO_TOL_CM
    hi = abs(ov_rng[1] - body_rng[1]) <= _AUTO_TOL_CM
    if lo and hi:
        return 'full'
    if lo:
        return 'lo'
    if hi:
        return 'hi'
    return 'int'


def _auto_opposite(side):
    return 'lo' if side == 'hi' else 'hi'


def _auto_classify_pair(A, B, axes_a, axes_b, ov):
    """Classe une paire en recouvrement - voir l'en-tete de section.
    Retourne un dict avec kind = 'insertion' | 'mibois' | 'skip'."""
    def skip(reason):
        return {'kind': 'skip', 'a': A, 'b': B, 'reason': reason}

    cache = {}

    def ext(which, ax):
        key = (which, round(ax.x, 4), round(ax.y, 4), round(ax.z, 4))
        if key not in cache:
            if which == 'ov':
                cache[key] = _auto_extent(ov, ax)
            else:
                cache[key] = _auto_local_extent(A if which == 'A' else B, ov, ax)
        return cache[key]

    # Traverse cintree (ou corps non analysable) : on lui prete le repere
    # de l'autre corps, trie par epaisseur LOCALE (la plus petite en
    # premier) - meme principe que le correctif "entailles dans les coins"
    # du mode cible/outils (l'axe vient toujours du corps droit/local).
    if axes_a is not None and _auto_is_curved(A):
        axes_a = None
    if axes_b is not None and _auto_is_curved(B):
        axes_b = None
    if axes_a is None and axes_b is None:
        return skip('deux corps cintres ou non analysables')

    def local_sorted(which, axes):
        def size(ax):
            r = ext(which, ax)
            return (r[1] - r[0]) if r else 1e9
        return sorted(axes, key=size)

    if axes_a is None:
        axes_a = local_sorted('A', axes_b)
    if axes_b is None:
        axes_b = local_sorted('B', axes_a)

    def statuses(which, axes):
        return [(ax, _auto_status(ext(which, ax), ext('ov', ax))) for ax in axes]

    st_a = statuses('A', axes_a)
    st_b = statuses('B', axes_b)

    def inserted(st):
        s = [x for _ax, x in st]
        return s.count('full') == 2 and any(x in ('lo', 'hi') for x in s)

    ins_a, ins_b = inserted(st_a), inserted(st_b)

    # Un corps qui traverse TOUTE l'epaisseur de l'autre (son bout a ras de
    # la face opposee, ex. traverse qui s'arrete au nu exterieur du montant
    # d'extremite) n'est pas une insertion mais un croisement : mi-bois,
    # comme tous les autres croisements (retour de Maxence : sinon tout le
    # recouvrement partait dans le montant, sans tenir compte de la
    # profondeur saisie).
    def crosses_host(st_ins, which_host):
        k = next((ax for ax, s in st_ins if s in ('lo', 'hi')), None)
        if k is None:
            return False
        return _auto_status(ext(which_host, k), ext('ov', k)) == 'full'

    if ins_a and crosses_host(st_a, 'B'):
        ins_a = False
    if ins_b and crosses_host(st_b, 'A'):
        ins_b = False

    if ins_a != ins_b:
        host, ins, st_ins = (B, A, st_a) if ins_a else (A, B, st_b)
        k = next(ax for ax, s in st_ins if s in ('lo', 'hi'))
        ro = ext('ov', k)
        return {'kind': 'insertion', 'a': host, 'b': ins, 'axis': k, 'ov': ov, 'ambiguous': False,
                'D': (ro[1] - ro[0]) if ro else None}

    # Axes communs aux 2 corps (paralleles), statuts recalcules le long du
    # MEME vecteur pour que 'lo'/'hi' designent le meme cote physique.
    cands = []
    for ax in axes_a:
        if not any(abs(abs(ax.dotProduct(bx)) - 1.0) <= 0.05 for bx in axes_b):
            continue
        ra, rb, ro = ext('A', ax), ext('B', ax), ext('ov', ax)
        sa, sb = _auto_status(ra, ro), _auto_status(rb, ro)
        if sa == 'int' or sb == 'int':
            continue
        cands.append((ax, sa, sb, ra, rb, ro))
    if not cands:
        return skip('le recouvrement ne touche aucun bord (mortaise, pas une entaille)')

    try:
        cross = axes_a[0].crossProduct(axes_b[0])
        cross_ok = cross.length > 1e-3
        if cross_ok:
            cross.normalize()
    except Exception:
        cross_ok = False

    def prefer(lst):
        if cross_ok:
            for c in lst:
                if abs(abs(c[0].dotProduct(cross)) - 1.0) <= 0.05:
                    return c
        if ins_a and ins_b:
            # mi-bois d'angle : on partage le long de l'epaisseur commune
            for c in lst:
                if abs(abs(c[0].dotProduct(axes_a[0])) - 1.0) <= 0.05:
                    return c
        return lst[0]

    determined = [c for c in cands if not (c[1] == 'full' and c[2] == 'full')]
    if ins_a and ins_b:
        determined = []
    ambiguous = False
    if determined:
        ax, sa, sb, ra, rb, ro = prefer(determined)
        if sa in ('lo', 'hi') and sb in ('lo', 'hi') and sa == sb:
            open_a, ambiguous = sa, True
        elif sa in ('lo', 'hi'):
            open_a = sa
        else:
            open_a = _auto_opposite(sb)
    else:
        fulls = [c for c in cands if c[1] == 'full' and c[2] == 'full'] or cands
        ax, sa, sb, ra, rb, ro = prefer(fulls)
        open_a, ambiguous = 'hi', True

    return {'kind': 'mibois', 'a': A, 'b': B, 'axis': ax, 'ov': ov, 'ambiguous': ambiguous,
            'open_a': open_a, 'D': ro[1] - ro[0], 'wA': ra[1] - ra[0], 'wB': rb[1] - rb[0]}


def _auto_skin_bodies(p, plan):
    """Fines parois a retirer pour une paire (demande de Maxence : un corps
    a quelques dixiemes de mm d'un bord laissait une petite face au bout de
    l'entaille). Pour chaque corps entaille, la cavite est une partie du
    recouvrement ; si, dans une direction ou elle doit deboucher (les 2
    directions perpendiculaires a l'axe de partage, et le cote d'ouverture
    le long de cet axe), il reste moins de _AUTO_TOL_CM de matiere jusqu'au
    bord du corps, cette paroi est decoupee aussi. Retourne une liste de
    (corps reel, corps transitoire a soustraire)."""
    out = []
    ov = p['ov']
    ax = plan['axis']
    try:
        wd = _pick_width_dir(ax)
        obb = adsk.core.Application.get().measureManager.getOrientedBoundingBox(ov, ax, wd)
        if obb is None:
            return out
        hd = ax.crossProduct(wd)
        hd.normalize()
        c = obb.centerPoint
        cu = c.x * ax.x + c.y * ax.y + c.z * ax.z
        cv = c.x * wd.x + c.y * wd.y + c.z * wd.z
        cw = c.x * hd.x + c.y * hd.y + c.z * hd.z
        o_u = (cu - obb.length / 2, cu + obb.length / 2)
        o_v = (cv - obb.width / 2, cv + obb.width / 2)
        o_w = (cw - obb.height / 2, cw + obb.height / 2)
    except Exception:
        return out

    if p['kind'] == 'insertion':
        if plan['target'] is not p['a']:
            return out  # insertion inversee : pas de correction
        cavities = [(plan['target'], o_u, ('lo', 'hi'))]
    else:
        D = o_u[1] - o_u[0]
        lt = max(0.0, D - plan['depth'])
        open_t = plan['open']
        if open_t == 'hi':
            cu_t, cu_o = (o_u[1] - lt, o_u[1]), (o_u[0], o_u[0] + plan['depth'])
        else:
            cu_t, cu_o = (o_u[0], o_u[0] + lt), (o_u[1] - plan['depth'], o_u[1])
        cavities = []
        if lt > 1e-6:
            cavities.append((plan['target'], cu_t, (open_t,)))
        if plan['depth'] > 1e-6:
            cavities.append((plan['tool'], cu_o, (_auto_opposite(open_t),)))

    tbm = adsk.fusion.TemporaryBRepManager.get()

    def box(u, v, w):
        mu, mv, mw = (u[0] + u[1]) / 2, (v[0] + v[1]) / 2, (w[0] + w[1]) / 2
        ctr = adsk.core.Point3D.create(ax.x * mu + wd.x * mv + hd.x * mw,
                                       ax.y * mu + wd.y * mv + hd.y * mw,
                                       ax.z * mu + wd.z * mv + hd.z * mw)
        return tbm.createBox(adsk.core.OrientedBoundingBox3D.create(
            ctr, ax, wd, u[1] - u[0], v[1] - v[0], w[1] - w[0]))

    for body, cu_rng, u_sides in cavities:
        rngs = {'u': cu_rng, 'v': o_v, 'w': o_w}
        dirs = {'u': ax, 'v': wd, 'w': hd}
        for key, sides in (('u', u_sides), ('v', ('lo', 'hi')), ('w', ('lo', 'hi'))):
            br = _auto_local_extent(body, ov, dirs[key])
            if br is None:
                continue
            ov_rng = {'u': o_u, 'v': o_v, 'w': o_w}[key]
            for side in sides:
                gap = (ov_rng[0] - br[0]) if side == 'lo' else (br[1] - ov_rng[1])
                if not (_AUTO_SKIN_MIN_CM < gap <= _AUTO_TOL_CM + 1e-6):
                    continue
                margin = 0.05
                if side == 'lo':
                    seg = (br[0] - margin, ov_rng[0] + 1e-4)
                else:
                    seg = (ov_rng[1] - 1e-4, br[1] + margin)
                r = dict(rngs)
                r[key] = seg
                try:
                    skin = box(r['u'], r['v'], r['w'])
                    if not tbm.booleanOperation(skin, tbm.copy(body),
                                                adsk.fusion.BooleanTypes.IntersectionBooleanType):
                        continue
                    if skin.faces.count == 0 or skin.volume < 1e-6:
                        continue
                    out.append((body, skin))
                except Exception:
                    continue
    return out


def analyse_auto_pairs(bodies):
    """Detecte toutes les paires en recouvrement parmi bodies (calcul
    temporaire uniquement, rien n'est cree dans le document). Retourne
    (pairs, skipped) - voir _auto_classify_pair."""
    tbm = adsk.fusion.TemporaryBRepManager.get()
    bodies = [b for b in (bodies or []) if b is not None]
    axes = []
    for b in bodies:
        try:
            axes.append(_auto_body_axes(b))
        except Exception:
            axes.append(None)
    pairs, skipped = [], []
    n = len(bodies)
    for i in range(n):
        for j in range(i + 1, n):
            A, B = bodies[i], bodies[j]
            try:
                if not A.boundingBox.intersects(B.boundingBox):
                    continue
            except Exception:
                pass
            try:
                ov = tbm.copy(A)
                if not tbm.booleanOperation(ov, tbm.copy(B), adsk.fusion.BooleanTypes.IntersectionBooleanType):
                    continue
                if ov.faces.count == 0:
                    continue
                try:
                    if ov.volume < _AUTO_MIN_VOL_CM3:
                        continue
                except Exception:
                    pass
            except Exception:
                continue
            try:
                p = _auto_classify_pair(A, B, axes[i], axes[j], ov)
            except Exception:
                _dbg('ERREUR _auto_classify_pair: ' + traceback.format_exc())
                p = {'kind': 'skip', 'a': A, 'b': B, 'reason': 'analyse impossible'}
            if p['kind'] == 'skip':
                skipped.append(p)
            else:
                pairs.append(p)
    _auto_canonical_roles(pairs, bodies)
    return pairs, skipped


def _auto_canonical_roles(pairs, bodies):
    """Meme sens pour toutes les entailles (demande de Maxence) : le role
    orange/bleu d'un mi-bois ne depend plus de l'ordre de clic. Le corps
    orange (1er corps, recoit le reste de la profondeur) est celui qui
    participe au plus grand nombre de paires (la traverse commune a tous
    les montants), puis le plus gros volume, puis le 1er clique. Le sens
    physique deduit du recouvrement ne change pas : si les roles sont
    permutes, le 1er corps s'ouvre du cote oppose a l'ancien. Une paire
    ambigue s'ouvre toujours vers le cote 'hi' de l'axe normalise (meme
    direction du monde pour toutes). Les insertions gardent leur role
    (impose par la geometrie)."""
    def key_of(b):
        try:
            return b.entityToken
        except Exception:
            return id(b)
    degree, order, vol = {}, {}, {}
    for i, b in enumerate(bodies):
        k = key_of(b)
        order.setdefault(k, i)
        try:
            vol[k] = b.volume
        except Exception:
            vol[k] = 0.0
    for p in pairs:
        for b in (p['a'], p['b']):
            k = key_of(b)
            degree[k] = degree.get(k, 0) + 1

    def rank(b):
        k = key_of(b)
        return (-degree.get(k, 0), -round(vol.get(k, 0.0), 3), order.get(k, 0))

    for p in pairs:
        if p['kind'] != 'mibois':
            continue
        if rank(p['b']) < rank(p['a']):
            p['a'], p['b'] = p['b'], p['a']
            p['wA'], p['wB'] = p['wB'], p['wA']
            if not p.get('ambiguous'):
                p['open_a'] = _auto_opposite(p['open_a'])
        if p.get('ambiguous'):
            p['open_a'] = 'hi'


def _auto_pair_plan(p, flipped, mode):
    """Traduit une paire analysee (+ inversion eventuelle + mode de
    partage) en parametres pour create_entaille_core : cible, outil, axe,
    retrait (cm) et point de reference imposant le sens."""
    if p['kind'] == 'insertion':
        tgt, tool = (p['b'], p['a']) if flipped else (p['a'], p['b'])
        return {'target': tgt, 'tool': tool, 'axis': p['axis'], 'depth': 0.0, 'ref': None}
    open_a = _auto_opposite(p['open_a']) if flipped else p['open_a']
    D = p['D']
    if isinstance(mode, (int, float)) and not isinstance(mode, bool):
        # Profondeur MANUELLE (cm) dans le 2e corps (bleu), bridee au
        # recouvrement disponible - le 1er corps (orange) recoit le reste.
        depth = max(0.0, min(float(mode), D - 0.001))
    elif mode == 'moitie':
        depth = D / 2.0
    else:
        depth = _default_retrait_cm(p['wA'], p['wB'], D)
    ax = p['axis']
    sign = 1.0 if open_a == 'hi' else -1.0
    try:
        bb = p['ov'].boundingBox
        c = adsk.core.Point3D.create((bb.minPoint.x + bb.maxPoint.x) / 2,
                                     (bb.minPoint.y + bb.maxPoint.y) / 2,
                                     (bb.minPoint.z + bb.maxPoint.z) / 2)
        ref = adsk.core.Point3D.create(c.x + ax.x * sign * _AUTO_FAR_CM,
                                       c.y + ax.y * sign * _AUTO_FAR_CM,
                                       c.z + ax.z * sign * _AUTO_FAR_CM)
    except Exception:
        ref = None
    return {'target': p['a'], 'tool': p['b'], 'axis': ax, 'depth': depth, 'ref': ref,
            'open': open_a}


def _draw_simple_wireframe(root, body, rgb, weight=4.0):
    coords_flat, strip_lengths = [], []
    for edge in body.edges:
        try:
            sp = edge.startVertex.geometry
            ep = edge.endVertex.geometry
        except Exception:
            continue
        coords_flat += [sp.x, sp.y, sp.z, ep.x, ep.y, ep.z]
        strip_lengths.append(2)
    if not coords_flat:
        return None
    g = root.customGraphicsGroups.add()
    lines = g.addLines(adsk.fusion.CustomGraphicsCoordinates.create(coords_flat), [], True, strip_lengths)
    try:
        lines.color = adsk.fusion.CustomGraphicsSolidColorEffect.create(
            adsk.core.Color.create(rgb[0], rgb[1], rgb[2], 255))
        lines.weight = weight
    except Exception:
        pass
    return g


def _safe_name(b):
    try:
        return b.name
    except Exception:
        return '?'


def draw_auto_preview(design, pairs, skipped, flips, mode, focus=None):
    """Dessine l'apercu 3D de toutes les paires (orange = entaille dans le
    1er corps, bleu = entaille dans le 2e - meme code couleur que le mode
    cible/outils) et retourne le resume a afficher dans le panneau. La
    paire 'focus' (index) est en plus surlignee en vert."""
    global _preview_cg_groups
    _clear_preview_graphics()
    root = design.rootComponent
    groups, rows = [], []
    for idx, p in enumerate(pairs):
        flipped = idx in flips
        plan = _auto_pair_plan(p, flipped, mode)
        g = None
        try:
            if plan['depth'] > 1e-6 and plan['ref'] is not None:
                g = _draw_split_wireframe(root, p['ov'], plan['target'], plan['axis'],
                                          plan['depth'], plan['ref'])
            if g is None:
                g = _draw_simple_wireframe(root, p['ov'], (255, 90, 0))
        except Exception:
            g = None
        if g is not None:
            groups.append(g)
        if focus == idx:
            try:
                hg = _draw_simple_wireframe(root, p['ov'], (0, 200, 90), 8.0)
                if hg is not None:
                    groups.append(hg)
            except Exception:
                pass
        D = p.get('D')
        rows.append({
            'i': idx,
            'a': _safe_name(plan['target']),
            'b': _safe_name(plan['tool']),
            'kind': p['kind'],
            'ambigu': bool(p.get('ambiguous')),
            'inverse': flipped,
            'focus': focus == idx,
            'overlap_mm': round(D * 10, 1) if D is not None else None,
            'cible_mm': round((D - plan['depth']) * 10, 1) if D is not None else None,
            'outil_mm': round(plan['depth'] * 10, 1),
        })
    _preview_cg_groups = groups
    return {
        'ok': bool(pairs),
        'pairs': rows,
        'skipped': [{'a': _safe_name(s['a']), 'b': _safe_name(s['b']), 'reason': s['reason']}
                    for s in skipped],
    }


def create_entaille_auto(design, pairs, flips, mode, marge_auto):
    """Creation reelle de toutes les paires (mode selection unique) : un
    appel create_entaille_core par paire, avec pre-calcul groupe de TOUS
    les outils recortes en UNE SEULE insertion (un seul computeAll pour le
    lot, meme optimisation que create_entaille_core_multi), et une seule
    application de MargeAuto a la fin."""
    messages = []
    if not pairs:
        return {'error': 'aucune paire en recouvrement', 'n_cotes_ok': 0, 'n_cotes_total': 0, 'messages': []}
    root = design.rootComponent
    marge_batch = []
    plans = [_auto_pair_plan(p, idx in flips, mode) for idx, p in enumerate(pairs)]

    resolved = []
    clip_entries = []
    cnc_progress.etape('Entaille : calcul des coupes...', 0, len(plans))
    for idx, plan in enumerate(plans):
        cnc_progress.avance()
        tgt, tool, ax = plan['target'], plan['tool'], plan['axis']
        rng = _auto_extent(tgt, ax)
        axis_override = (ax, (rng[1] - rng[0]) if rng else None)
        try:
            res = list(_resolve_axis_and_depth(tgt, [tool], plan['depth'], axis_override))
            if plan['ref'] is not None:
                res[3] = plan['ref']
            res = tuple(res)
        except Exception:
            res = None
        resolved.append((axis_override, res))
        if res is None or res[4] <= 1e-6:
            continue
        try:
            clipped = _clip_tool_to_cible_zone(tgt, tool, ax, res[4], res[3])
        except Exception:
            clipped = None
        if clipped is not None:
            clip_entries.append((idx, clipped))

    skin_entries = []
    for idx, plan in enumerate(plans):
        try:
            skin_entries.extend(_auto_skin_bodies(pairs[idx], plan))
        except Exception:
            _dbg('ERREUR _auto_skin_bodies: ' + traceback.format_exc())

    real_by_idx = {}
    clip_by_idx = {}
    real_skins = []
    if _SKETCH_MODE:
        clip_by_idx = dict(clip_entries)  # esquisse d'abord, repli fige au cas par cas
        clip_entries = []
    if clip_entries or skin_entries:
        cnc_progress.etape('Entaille : insertion dans le modele...')
        inserted = _insert_real_bodies(design, root, [c for _i, c in clip_entries]
                                       + [sk for _b, sk in skin_entries])
        for (idx, _c), rb in zip(clip_entries, inserted[:len(clip_entries)]):
            if rb is not None:
                real_by_idx[idx] = rb
        for (body, _sk), rb in zip(skin_entries, inserted[len(clip_entries):]):
            if rb is not None:
                real_skins.append((body, rb))

    n_ok = n_total = 0
    deferred = []  # esquisses refusees : repli fige groupe (_flush_deferred_sketch)
    cnc_progress.etape('Entaille : decoupe des pieces...', 0, len(plans))
    for idx, plan in enumerate(plans):
        cnc_progress.avance()
        tgt, tool = plan['target'], plan['tool']
        axis_override, res = resolved[idx]
        pre = None
        pre_clips = None
        if idx in real_by_idx:
            try:
                pre = {(tgt.entityToken, tool.entityToken): real_by_idx[idx]}
            except Exception:
                pre = None
        if idx in clip_by_idx:
            try:
                pre_clips = {(tgt.entityToken, tool.entityToken): clip_by_idx[idx]}
            except Exception:
                pre_clips = None
        r = create_entaille_core(design, tgt, [tool], plan['depth'], marge_auto,
                                  axis_override=axis_override, _marge_batch=marge_batch,
                                  precomputed_real_bodies=pre, precomputed_resolved=res,
                                  precomputed_clips=pre_clips, _deferred=deferred)
        label = '%s x %s' % (_safe_name(tgt), _safe_name(tool))
        if r.get('error'):
            messages.append('Paire "%s" : %s' % (label, r['error']))
            continue
        n_ok += r.get('n_cotes_ok', 0)
        n_total += r.get('n_cotes_total', 0)
        messages.extend(r.get('messages', []))
    _d_ok, _d_tot = _flush_deferred_sketch(design, root, deferred, marge_auto, marge_batch, messages)
    n_ok += _d_ok
    n_total += _d_tot
    # Fines parois en bout d'entaille (voir _auto_skin_bodies)
    for body, rb in real_skins:
        try:
            col = adsk.core.ObjectCollection.create()
            col.add(rb)
            ci = root.features.combineFeatures.createInput(body, col)
            ci.operation = adsk.fusion.FeatureOperations.CutFeatureOperation
            ci.isKeepToolBodies = False
            root.features.combineFeatures.add(ci)
        except Exception:
            messages.append('Paroi fine non retiree sur "%s" : ' % _safe_name(body)
                            + traceback.format_exc().strip().splitlines()[-1])
            try:
                rb.deleteMe()
            except Exception:
                pass
    _flush_marge_batch(design, root, marge_batch, messages)
    return {'error': None, 'n_cotes_ok': n_ok, 'n_cotes_total': n_total, 'messages': messages,
            'n_paires': len(pairs)}


# ================================================================
# SUIVI DES ENTAILLES (demande de Maxence, 2026-10-06)
#
# Les entailles sont decoupees avec des corps figes (BaseFeature) : si un
# corps est deplace PLUS TOT dans l'historique, ses entailles restent a
# l'ancienne place. Chaque creation (mode cible/outils ou selection
# unique) est donc memorisee comme un "lot" :
#   - attribut du design ('EntailleCNC', 'lot_<id>') : JSON avec le mode,
#     les corps (composant + occurrence + nom), les reglages, les paires
#     inversees et la boite englobante de chaque corps juste apres la
#     creation ;
#   - attribut ('EntailleCNC', 'lot') = <id> sur chaque fonction creee,
#     pour pouvoir la supprimer.
# entailles_stale() compare les boites englobantes actuelles (fin
# d'historique) a celles memorisees ; recreate_entailles() supprime les
# fonctions d'un lot puis le recree avec les memes reglages a la fin de
# l'historique (dogbones des corps touches retires puis remis si
# DogboneCNC le permet).
# ================================================================

_LOT_GROUP = 'EntailleCNC'
_LOT_MOVE_TOL_CM = 0.01   # 0.1 mm


def _lot_body_ref(b):
    try:
        native = b.nativeObject or b
    except Exception:
        native = b
    occ = None
    try:
        occ = b.assemblyContext
    except Exception:
        occ = None
    return {'comp': native.parentComponent.id, 'name': native.name,
            'occ': occ.fullPathName if occ is not None else ''}


def _lot_ref_key(ref):
    return '%s|%s|%s' % (ref.get('occ', ''), ref.get('comp', ''), ref.get('name', ''))


def _lot_resolve(design, ref):
    try:
        comp = design.allComponents.itemById(ref['comp'])
        if comp is None:
            return None
        nb = comp.bRepBodies.itemByName(ref['name'])
        if nb is None:
            return None
        if not ref.get('occ'):
            return nb
        for occ in design.rootComponent.allOccurrences:
            if occ.fullPathName == ref['occ']:
                return nb.createForAssemblyContext(occ)
    except Exception:
        pass
    return None


def _lot_bbox(b):
    bb = b.boundingBox
    return [round(v, 4) for v in (bb.minPoint.x, bb.minPoint.y, bb.minPoint.z,
                                  bb.maxPoint.x, bb.maxPoint.y, bb.maxPoint.z)]


def _lot_new_id():
    import uuid
    return uuid.uuid4().hex[:12]


def _lot_read_all(design):
    lots = []
    try:
        attrs = design.attributes
        for i in range(attrs.count):
            a = attrs.item(i)
            if a.groupName == _LOT_GROUP and a.name.startswith('lot_'):
                try:
                    lots.append(json.loads(a.value))
                except Exception:
                    pass
    except Exception:
        pass
    return lots


def _lot_write(design, lot):
    design.attributes.add(_LOT_GROUP, 'lot_' + lot['id'], json.dumps(lot))


def _lot_delete_record(design, lot_id):
    try:
        a = design.attributes.itemByName(_LOT_GROUP, 'lot_' + lot_id)
        if a is not None:
            a.deleteMe()
    except Exception:
        pass


def _lot_features(design, lot_id):
    """Fonctions de l'historique taguees avec ce lot, de la plus recente a
    la plus ancienne."""
    out = []
    try:
        for a in design.findAttributes(_LOT_GROUP, 'lot'):
            if a.value != lot_id:
                continue
            ent = a.parent
            try:
                idx = ent.timelineObject.index
            except Exception:
                idx = -1
            out.append((idx, ent))
    except Exception:
        pass
    out.sort(key=lambda t: -t[0])
    return out


def _lot_tag_range(design, lot_id, start_index, end_index):
    tl = design.timeline
    n = 0
    for i in range(start_index, end_index + 1):
        try:
            ent = tl.item(i).entity
            ent.attributes.add(_LOT_GROUP, 'lot', lot_id)
            n += 1
        except Exception:
            pass
    return n


def record_lot(design, kind, start_index, end_index, bodies=None, targets=None, tools=None,
               pairs=None, flips=None, mode=None, depth_cm=None, marge_auto=False):
    """Memorise une creation d'entailles (appele par ToolkitCNC juste apres
    create_entaille_auto / create_entaille_core_multi). kind = 'unique' ou
    'classique'. Retourne l'id du lot, ou None si rien n'a ete cree."""
    if end_index < start_index:
        return None
    lot_id = _lot_new_id()
    if _lot_tag_range(design, lot_id, start_index, end_index) == 0:
        return None
    lot = {'id': lot_id, 'kind': kind, 'marge_auto': bool(marge_auto)}
    # Lot sans aucune BaseFeature (entailles en esquisse ou Combiner avec les
    # vrais corps) : il suit les corps tout seul, Mettre a jour ne le refait
    # que s'il passe en erreur.
    lot['parametric'] = not any(
        adsk.fusion.BaseFeature.cast(ent) is not None
        for _i, ent in _lot_features(design, lot_id))
    if kind == 'unique':
        all_bodies = list(bodies or [])
        lot['bodies'] = [_lot_body_ref(b) for b in all_bodies]
        lot['mode'] = mode
        flipped = []
        for idx, p in enumerate(pairs or []):
            if idx in (flips or set()):
                flipped.append(sorted([_lot_ref_key(_lot_body_ref(p['a'])),
                                       _lot_ref_key(_lot_body_ref(p['b']))]))
        lot['flipped'] = flipped
    else:
        all_bodies = list(targets or []) + list(tools or [])
        lot['targets'] = [_lot_body_ref(b) for b in (targets or [])]
        lot['tools'] = [_lot_body_ref(b) for b in (tools or [])]
        lot['depth_cm'] = depth_cm
    lot['sig'] = {}
    for b in all_bodies:
        try:
            lot['sig'][_lot_ref_key(_lot_body_ref(b))] = _lot_bbox(b)
        except Exception:
            pass
    _lot_write(design, lot)
    return lot_id


def _lot_refs(lot):
    if lot.get('kind') == 'unique':
        return list(lot.get('bodies', []))
    return list(lot.get('targets', [])) + list(lot.get('tools', []))


def entailles_stale(design):
    """Lots dont au moins un corps a bouge (ou change de taille) depuis la
    creation. Les lots dont toutes les fonctions ont ete supprimees a la
    main sont oublies au passage. Retourne une liste de
    {'id', 'kind', 'moved': [noms], 'missing': [noms]}."""
    out = []
    for lot in _lot_read_all(design):
        feats = _lot_features(design, lot['id'])
        if not feats:
            _lot_delete_record(design, lot['id'])
            continue
        if lot.get('parametric'):
            broken = []
            for _i, ent in feats:
                try:
                    hs = ent.timelineObject.healthState
                except Exception:
                    continue
                if hs == adsk.fusion.FeatureHealthStates.ErrorFeatureHealthState or (
                        hs != adsk.fusion.FeatureHealthStates.HealthyFeatureHealthState
                        and adsk.fusion.Sketch.cast(ent) is not None):
                    broken.append(getattr(ent, 'name', '?'))
            if broken:
                out.append({'id': lot['id'], 'kind': lot.get('kind'), 'moved': broken, 'missing': []})
            continue
        moved, missing = [], []
        for ref in _lot_refs(lot):
            b = _lot_resolve(design, ref)
            if b is None:
                missing.append(ref.get('name', '?'))
                continue
            old = lot.get('sig', {}).get(_lot_ref_key(ref))
            try:
                cur = _lot_bbox(b)
            except Exception:
                continue
            if old is None or any(abs(x - y) > _LOT_MOVE_TOL_CM for x, y in zip(old, cur)):
                moved.append(ref.get('name', '?'))
        if moved or missing:
            out.append({'id': lot['id'], 'kind': lot.get('kind'), 'moved': moved, 'missing': missing})
    return out


def _find_addin_module(short_name):
    mod = sys.modules.get(short_name)
    if mod is not None:
        return mod
    for k, m in list(sys.modules.items()):
        if k.endswith(short_name + '_py'):
            return m
    return None


def _lot_delete_features(design, lot_id):
    """Supprime toutes les fonctions d'un lot : d'abord les groupes de
    timeline qui ne contiennent QUE des fonctions de ce lot (supprimes avec
    leur contenu), puis les fonctions restantes une par une, de la plus
    recente a la plus ancienne (references relues apres chaque
    suppression). Retourne (n_supprimees, erreurs)."""
    errs = []
    n = 0

    def tagged(ent):
        try:
            a = ent.attributes.itemByName(_LOT_GROUP, 'lot')
            return a is not None and a.value == lot_id
        except Exception:
            return False

    tl = design.timeline
    for gi in range(tl.timelineGroups.count - 1, -1, -1):
        try:
            g = tl.timelineGroups.item(gi)
            items = [g.item(k) for k in range(g.count)]
            if items and all(tagged(it.entity) for it in items):
                n += len(items)
                g.deleteMe(True)
        except Exception:
            errs.append(traceback.format_exc().strip().splitlines()[-1])
    for _guard in range(500):
        feats = _lot_features(design, lot_id)
        if not feats:
            break
        _idx, ent = feats[0]
        try:
            ent.deleteMe()
            n += 1
        except Exception:
            errs.append('%s : %s' % (getattr(ent, 'name', '?'),
                                     traceback.format_exc().strip().splitlines()[-1]))
            try:
                ent.attributes.itemByName(_LOT_GROUP, 'lot').deleteMe()
            except Exception:
                break
    return n, errs


def recreate_entailles(design, lot_ids=None, force=False, group=True, allow_mid=False):
    """Recree les lots d'entailles dont un corps a bouge (ou ceux de lot_ids,
    ou tous si force=True), avec leurs reglages d'origine, a la fin de
    l'historique. Retourne (n_ok, n_total, errors)."""
    errors = []
    tl = design.timeline
    if tl.markerPosition != tl.count and not allow_mid:
        return 0, 0, ["placez le marqueur de l'historique a la fin avant la mise a jour"]
    lots = {l['id']: l for l in _lot_read_all(design)}
    if force:
        todo = list(lots.keys())
    elif lot_ids is not None:
        todo = [i for i in lot_ids if i in lots]
    else:
        todo = [s['id'] for s in entailles_stale(design)]
    if not todo:
        return 0, 0, []

    Dog = _find_addin_module('DogboneCNC')
    n_ok = 0
    cnc_progress.etape('Entailles : mise a jour...', 0, len(todo))
    for lot_id in todo:
        cnc_progress.avance()
        lot = lots[lot_id]
        refs = _lot_refs(lot)
        bodies = [_lot_resolve(design, r) for r in refs]
        if any(b is None for b in bodies):
            errors.append('entailles de %s : corps introuvable (renomme ou supprime ?)'
                          % ', '.join(r.get('name', '?') for r, b in zip(refs, bodies) if b is None))
            continue
        snap = None
        try:
            if Dog is not None and hasattr(Dog, 'snapshot_dogbones') and hasattr(Dog, 'remove_dogbones'):
                snap = Dog.snapshot_dogbones(design, bodies)
                Dog.remove_dogbones(design, bodies)
        except Exception:
            errors.append('dogbones : ' + traceback.format_exc().strip().splitlines()[-1])
            snap = None
        _nd, _derrs = _lot_delete_features(design, lot_id)
        errors.extend('suppression : ' + e for e in _derrs)
        bodies = [_lot_resolve(design, r) for r in refs]
        start = tl.markerPosition
        try:
            if lot.get('kind') == 'unique':
                pairs, _sk = analyse_auto_pairs(bodies)
                stored = set(tuple(x) for x in lot.get('flipped', []))
                flips = set()
                for idx, p in enumerate(pairs):
                    key = tuple(sorted([_lot_ref_key(_lot_body_ref(p['a'])),
                                        _lot_ref_key(_lot_body_ref(p['b']))]))
                    if key in stored:
                        flips.add(idx)
                res = create_entaille_auto(design, pairs, flips, lot.get('mode') or 'auto',
                                           lot.get('marge_auto', False))
            else:
                nt = len(lot.get('targets', []))
                res = create_entaille_core_multi(design, bodies[:nt], bodies[nt:],
                                                 lot.get('depth_cm') or 0.0, lot.get('marge_auto', False))
        except Exception:
            res = {'error': traceback.format_exc().strip().splitlines()[-1]}
        end = tl.markerPosition - 1
        if res.get('error'):
            errors.append('entailles : ' + str(res['error']))
        else:
            n_ok += 1
        errors.extend(res.get('messages') or [])
        if end >= start:
            _lot_tag_range(design, lot_id, start, end)
            if group and end > start:
                try:
                    g = tl.timelineGroups.add(start, end)
                    g.name = 'Entaille CNC'
                    g.isCollapsed = True
                except Exception:
                    pass
        lot['sig'] = {}
        for r in refs:
            b = _lot_resolve(design, r)
            if b is not None:
                try:
                    lot['sig'][_lot_ref_key(r)] = _lot_bbox(b)
                except Exception:
                    pass
        _lot_write(design, lot)
        try:
            if snap is not None and hasattr(Dog, 'restore_dogbones'):
                Dog.restore_dogbones(design, snap)
        except Exception:
            errors.append('dogbones : ' + traceback.format_exc().strip().splitlines()[-1])
    return n_ok, len(todo), errors


def recreate_all_entailles(design):
    """Point d'entree de Mettre a jour CNC (MiseAJourCNC.py) : recree les
    lots dont un corps a bouge, sans groupe propre (Mettre a jour CNC
    regroupe tout). Les dogbones sont refaits ensuite par MiseAJourCNC."""
    # Mettre a jour CNC recule le marqueur juste avant une eventuelle
    # fonction Organiser : on recree alors a cet endroit.
    return recreate_entailles(design, group=False, allow_mid=True)


# ================================================================
# MARKING MENU : ajoute "Modifier Entaille" au clic droit
# sur une custom feature Entaille
# ================================================================
class MarkingMenuHandler(adsk.core.MarkingMenuEventHandler):
    def __init__(self): super().__init__()

    def notify(self, args):
        global _cf_cible_name
        try:
            eventArgs = adsk.core.MarkingMenuEventArgs.cast(args)
            entities = eventArgs.selectedEntities
            cf_found = None
            for e in entities:
                cf = adsk.fusion.CustomFeature.cast(e)
                if cf and cf.definition and cf.definition.id == CUSTOM_FEAT_ID:
                    cf_found = cf
                    break
            if cf_found is None:
                return
            _cf_cible_name = cf_found.name
            linear = eventArgs.linearMarkingMenu
            linear.controls.addCommand(_cmd_def_edit)
        except Exception:
            pass


# ================================================================
# COMMANDE CREATION (boite de dialogue native - toujours disponible via
# la recherche de commande Fusion, en plus du panneau CNC Toolkit)
# ================================================================
class CreateCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        global _create_execute, _create_destroy
        try:
            cmd    = adsk.core.CommandCreatedEventArgs.cast(args).command
            _create_execute = CreateExecuteHandler()
            _create_destroy = GenericDestroyHandler()
            cmd.execute.add(_create_execute)
            cmd.destroy.add(_create_destroy)
            inputs = cmd.commandInputs
            sel_t = inputs.addSelectionInput(
                'targetBody', '1. Corps a couper',
                'Selectionnez le corps qui recevra les entailles'
            )
            sel_t.addSelectionFilter('Bodies')
            sel_t.setSelectionLimits(1, 1)
            sel_o = inputs.addSelectionInput(
                'toolBodies', '2. Corps de decoupe',
                'Selectionnez le ou les corps formant les entailles'
            )
            sel_o.addSelectionFilter('Bodies')
            sel_o.setSelectionLimits(1, 0)
            s = _load_settings()
            inputs.addValueInput(PARAM_DEPTH, 'Retrait profondeur', 'mm',
                adsk.core.ValueInput.createByReal(s['depth_cm']))
            inputs.addBoolValueInput(PARAM_MARGE_AUTO, 'Marge Auto', True, '', s['marge_auto'])
        except Exception:
            _ui.messageBox('Erreur creation dialogue:\n' + traceback.format_exc())


class CreateExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            inputs    = adsk.core.CommandEventArgs.cast(args).firingEvent.sender.commandInputs
            si_target = inputs.itemById('targetBody')
            si_tools  = inputs.itemById('toolBodies')
            si_depth  = inputs.itemById(PARAM_DEPTH)
            si_marge  = inputs.itemById(PARAM_MARGE_AUTO)
            depth_cm  = si_depth.value
            marge_auto = bool(si_marge.value) if si_marge else False
            if si_target.selectionCount < 1 or si_tools.selectionCount < 1:
                _ui.messageBox('Selectionnez un corps cible et un corps de decoupe.')
                return
            _save_settings(depth_cm, marge_auto)
            design = adsk.fusion.Design.cast(_app.activeProduct)
            target_body = adsk.fusion.BRepBody.cast(si_target.selection(0).entity)
            tool_bodies = [
                adsk.fusion.BRepBody.cast(si_tools.selection(i).entity)
                for i in range(si_tools.selectionCount)
            ]
            # Groupe de timeline unique pour TOUTE cette creation (entaille(s)
            # + MargeAuto le cas echeant, tout gere a l'interieur de
            # create_entaille_core) - demande explicite de Maxence (meme
            # mecanisme que Tenon CNC) : un seul groupe nomme par
            # utilisation, supprimable d'un coup (clic droit > Supprimer,
            # avec son contenu) dans l'historique, plutot que de devoir
            # faire Ctrl+Z plusieurs fois (Ctrl+Z reste multi-etapes quel
            # que soit le regroupement en features/groupes - limite de
            # Fusion, voir TenonCNC.py).
            tl = design.timeline
            _start_index = tl.markerPosition
            result = create_entaille_core(design, target_body, tool_bodies, depth_cm, marge_auto)
            _end_index = tl.markerPosition - 1
            if _end_index > _start_index:
                try:
                    _grp = tl.timelineGroups.add(_start_index, _end_index)
                    if _grp:
                        _grp.name = 'Entaille CNC'
                        _grp.isCollapsed = True
                except Exception:
                    pass
            if result['error']:
                _ui.messageBox('Erreur : ' + result['error'])
                return

            root = design.rootComponent
            cf_input = root.features.customFeatures.createInput(_custom_feat_def)
            cf_input.addCustomParameter(PARAM_DEPTH, 'Retrait',
                adsk.core.ValueInput.createByReal(depth_cm), 'mm', True)
            # NOTE : la custom feature n'encapsule ici que l'operation sur le
            # corps CIBLE (premiere decoupe) pour que "Modifier Entaille"
            # reste simple a editer - la decoupe reciproque sur les corps
            # outils reste visible/editable comme des features Combine/
            # OffsetFaces classiques dans la timeline, juste apres.
            _ui.messageBox(
                f"{result['n_cotes_ok']}/{result['n_cotes_total']} cote(s) traite(s)."
                + (('\n' + '\n'.join(result['messages'])) if result['messages'] else ''),
                'Entaille CNC')
            _app.activeViewport.fit()
        except Exception:
            _ui.messageBox('Erreur execution creation:\n' + traceback.format_exc())


class EditCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        global _edit_execute, _edit_destroy
        try:
            cmd    = adsk.core.CommandCreatedEventArgs.cast(args).command
            _edit_execute = EditExecuteHandler()
            _edit_destroy = GenericDestroyHandler()
            cmd.execute.add(_edit_execute)
            cmd.destroy.add(_edit_destroy)
            inputs = cmd.commandInputs
            design   = adsk.fusion.Design.cast(_app.activeProduct)
            cf_cible = find_cf_by_name(design, _cf_cible_name) if _cf_cible_name else None
            if cf_cible is None:
                _ui.messageBox('Aucune feature Entaille ciblee.')
                return
            cur_depth = _load_settings()['depth_cm']
            try:
                p = cf_cible.parameters.itemById(PARAM_DEPTH)
                if p: cur_depth = p.value
            except Exception:
                pass
            inputs.addValueInput(PARAM_DEPTH, 'Retrait profondeur', 'mm',
                adsk.core.ValueInput.createByReal(cur_depth))
            flag = inputs.addStringValueInput('_cf_name', '', cf_cible.name)
            flag.isVisible = False
            inputs.addTextBoxCommandInput('info', '',
                f'Edition : <b>{cf_cible.name}</b>\n'
                'La marge laterale (si MargeAuto etait active) se modifie '
                'via l\'outil "Modif Marge" de CNC Toolkit. Attention : si le '
                'retrait d\'origine etait > 0 (entaille aussi presente cote '
                'outil), changer sa valeur ici ne met PAS a jour la decoupe '
                'du corps outil - supprimer et recreer l\'entaille dans ce cas.',
                3, True)
        except Exception:
            _ui.messageBox('Erreur edition dialogue:\n' + traceback.format_exc())


class EditExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        global _cf_cible_name
        try:
            inputs    = adsk.core.CommandEventArgs.cast(args).firingEvent.sender.commandInputs
            si_depth  = inputs.itemById(PARAM_DEPTH)
            cf_name   = inputs.itemById('_cf_name')
            depth_cm  = si_depth.value
            design   = adsk.fusion.Design.cast(_app.activeProduct)
            cf_cible = find_cf_by_name(design, cf_name.value) if cf_name else None
            if cf_cible is None:
                _ui.messageBox('Feature introuvable.')
                return
            try:
                param_depth = cf_cible.parameters.itemById(PARAM_DEPTH)
            except Exception:
                param_depth = None
            old_depth = param_depth.value if param_depth else depth_cm

            # OPTIMISATION : rollback juste avant la CF pour ne recalculer
            # que celle-ci (meme technique que l'ancienne version).
            timeline = design.timeline
            marker_original = timeline.markerPosition
            cf_index = None
            for i in range(timeline.count):
                item = timeline.item(i)
                cf_check = adsk.fusion.CustomFeature.cast(item.entity)
                if cf_check and cf_check.name == cf_cible.name:
                    cf_index = item.index
                    break
            if cf_index is not None:
                timeline.markerPosition = cf_index
            try:
                for f in list(cf_cible.features):
                    of = adsk.fusion.OffsetFacesFeature.cast(f)
                    if not of:
                        continue
                    try:
                        of.distance.value = depth_cm
                    except Exception:
                        try:
                            of.distance.expression = f'{round(depth_cm*10,4)} mm'
                        except Exception:
                            continue
                if param_depth:
                    param_depth.value = depth_cm
            finally:
                timeline.markerPosition = marker_original

            _save_settings(depth_cm, _load_settings()['marge_auto'])
            _cf_cible_name = None
        except Exception:
            _ui.messageBox('Erreur execution edition:\n' + traceback.format_exc())


class MyComputeHandler(adsk.fusion.CustomFeatureEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            eventArgs = adsk.fusion.CustomFeatureEventArgs.cast(args)
            cf = eventArgs.customFeature
            if cf is None:
                return
            try:
                param_depth = cf.parameters.itemById(PARAM_DEPTH)
            except Exception:
                param_depth = None
            if param_depth is None:
                return
            depths = []
            for f in list(cf.features):
                of = adsk.fusion.OffsetFacesFeature.cast(f)
                if not of:
                    continue
                try:
                    depths.append(of.distance.value)
                except Exception:
                    continue
            if depths:
                avg_depth = sum(depths) / len(depths)
                if abs(avg_depth - param_depth.value) > 1e-6:
                    param_depth.value = avg_depth
        except Exception:
            pass


class GenericDestroyHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args): pass


# ================================================================
def run(context):
    global _app, _ui, _cmd_def_create, _cmd_def_edit, _panel_ctrl
    global _create_created, _edit_created
    global _custom_feat_def, _compute_handler, _marking_handler
    try:
        _app = adsk.core.Application.get()
        _ui  = _app.userInterface

        panel = _ui.allToolbarPanels.itemById('SolidModifyPanel')
        if panel:
            c = panel.controls.itemById(CMD_CREATE_ID)
            if c: c.deleteMe()
        for cid in [CMD_CREATE_ID, CMD_EDIT_ID]:
            old = _ui.commandDefinitions.itemById(cid)
            if old: old.deleteMe()

        _cmd_def_create = _ui.commandDefinitions.addButtonDefinition(
            CMD_CREATE_ID, 'Entaille CNC',
            'Cree une entaille a mi-bois entre deux corps', ''
        )
        _create_created = CreateCreatedHandler()
        _cmd_def_create.commandCreated.add(_create_created)

        _cmd_def_edit = _ui.commandDefinitions.addButtonDefinition(
            CMD_EDIT_ID, 'Modifier Entaille',
            'Modifier le retrait de cette entaille', ''
        )
        _edit_created = EditCreatedHandler()
        _cmd_def_edit.commandCreated.add(_edit_created)

        addin_dir = os.path.dirname(os.path.abspath(__file__))
        _custom_feat_def = adsk.fusion.CustomFeatureDefinition.create(
            CUSTOM_FEAT_ID, 'Entaille', addin_dir
        )
        _custom_feat_def.editCommandId = CMD_EDIT_ID
        _compute_handler = MyComputeHandler()
        _custom_feat_def.customFeatureCompute.add(_compute_handler)

        _marking_handler = MarkingMenuHandler()
        _ui.markingMenuDisplaying.add(_marking_handler)

        # Bouton de ruban non ajoute : CNC Toolkit retrouve et execute
        # _cmd_def_create directement depuis sa palette (panneau integre,
        # voir ToolkitCNC.py/palette.html) - meme principe que les autres
        # add-ins de la suite.
    except Exception:
        if _ui:
            _ui.messageBox('Erreur run:\n' + traceback.format_exc())


def stop(context):
    global _cmd_def_create, _cmd_def_edit, _panel_ctrl
    global _custom_feat_def, _compute_handler, _marking_handler
    global _create_created, _create_execute, _create_destroy
    global _edit_created, _edit_execute, _edit_destroy
    try:
        _clear_preview_graphics()
        if _marking_handler:
            _ui.markingMenuDisplaying.remove(_marking_handler)
        if _panel_ctrl:     _panel_ctrl.deleteMe()
        if _cmd_def_create: _cmd_def_create.deleteMe()
        if _cmd_def_edit:   _cmd_def_edit.deleteMe()
        _cmd_def_create = _cmd_def_edit = _panel_ctrl = None
        _custom_feat_def = _compute_handler = _marking_handler = None
        _create_created = _create_execute = _create_destroy = None
        _edit_created   = _edit_execute   = _edit_destroy   = None
    except Exception:
        pass
