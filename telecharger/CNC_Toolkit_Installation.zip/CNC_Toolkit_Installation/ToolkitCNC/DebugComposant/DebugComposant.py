# Debug composant - Add-in Fusion
# Remplace les numeros de piece en double par le nom actuel de chaque composant,
# pour que la liste de pieces des dessins affiche des references uniques et justes.

import adsk.core, adsk.fusion, traceback, html, os, sys

# Barre de chargement commune du Toolkit (ToolkitCNC/cnc_progress.py)
_TK_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _TK_DIR not in sys.path:
    sys.path.append(_TK_DIR)
import cnc_progress

CMD_ID   = "DebugComposantCmd"
CMD_NAME = "Debug composant"
CMD_DESC = ("Remplace les numéros de pièce en double par le nom actuel de chaque composant "
            "(utile quand la liste de pièces du dessin n'affiche pas les bons noms).")
PANEL_ID = "SolidModifyPanel"

_app = None
_ui = None
_handlers = []


# ---------------------------------------------------------------- logique

def _design():
    return adsk.fusion.Design.cast(_app.activeProduct) if _app else None


# VITESSE : dans un document enregistre, chaque lecture de Component.partNumber
# coute ~0,35 s et chaque ecriture ~0,27 s (mesure 2026-11-19, 104 composants
# = 36 s par passe de lecture). On lit donc nom + numero UNE seule fois par
# ouverture de la commande (releve mis en cache), et l'aperçu, la case a cocher
# et l'execution travaillent sur ce releve sans rappeler l'API.
_releve_cache = {"design": None, "lignes": None}


def _composants_locaux(design):
    """Composants modifiables : on ignore ceux qui viennent d'un autre fichier (liés)."""
    res = []
    for c in design.allComponents:
        try:
            if c.parentDesign != design:
                continue
        except Exception:
            pass
        res.append(c)
    return res


def _releve(design, rafraichir=False):
    """Liste de [composant, nom, numero] lue une seule fois (lecture partNumber lente)."""
    if (not rafraichir and _releve_cache["lignes"] is not None
            and _releve_cache["design"] == design):
        return _releve_cache["lignes"]
    comps = _composants_locaux(design)
    lignes = []
    with cnc_progress.Barre(CMD_NAME, "Lecture des numéros de pièce...", total=len(comps)) as pg:
        for c in comps:
            lignes.append([c, c.name, c.partNumber])
            pg.avance()
    _releve_cache["design"] = design
    _releve_cache["lignes"] = lignes
    return lignes


def _oublier_releve():
    _releve_cache["design"] = None
    _releve_cache["lignes"] = None


def _analyse(design, tout):
    """Retourne (cibles, doublons, nb_diff) : lignes du releve a corriger,
    groupes de numeros en double, nombre de numeros differents du nom."""
    lignes = _releve(design)
    groupes = {}
    for ln in lignes:
        groupes.setdefault(ln[2], []).append(ln)
    doublons = {pn: ls for pn, ls in groupes.items() if len(ls) > 1}
    cibles = []
    nb_diff = 0
    for ln in lignes:
        if ln[2] == ln[1]:
            continue
        nb_diff += 1
        if tout or ln[2] in doublons:
            cibles.append(ln)
    cibles.sort(key=lambda ln: ln[1].lower())
    return cibles, doublons, nb_diff


def _corriger(cibles):
    # Ecriture : 1,7 a 5 s PAR composant sur un gros assemblage enregistre
    # (CLINT 01, mesure 2026-11-19), temps interne a Fusion que l'API ne permet
    # pas de grouper. La barre montre l'avancement au lieu d'un Fusion fige.
    ok, erreurs = 0, []
    with cnc_progress.Barre(CMD_NAME, "Correction des numéros de pièce...", total=len(cibles)) as pg:
        for ln in cibles:
            c, nom = ln[0], ln[1]
            try:
                # Ecriture directe du nom : meme resultat que l'ancien "vider puis
                # relire puis ecrire" (verifie : vider ne reprend pas le nom dans
                # Fusion), sans la relecture lente ni la seconde ecriture.
                c.partNumber = nom
                ln[2] = nom
                ok += 1
            except Exception as e:
                erreurs.append("%s (%s)" % (nom, e))
            pg.avance()
    return ok, erreurs


def _apercu_html(design, tout):
    if not design:
        return "<b>Aucun design actif.</b> Ouvrez un design (pas un dessin)."
    cibles, doublons, nb_diff = _analyse(design, tout)
    nb_doublons = sum(len(cs) for cs in doublons.values())
    lignes = ["<b>%d</b> composant(s) ont un numéro de pièce différent de leur nom, "
              "dont <b>%d</b> en double.<br>" % (nb_diff, nb_doublons)]
    if not cibles:
        lignes.append("<br><b>Rien à corriger.</b>")
        return "".join(lignes)
    lignes.append("<br><b>%d</b> composant(s) seront corrigés :<br>" % len(cibles))
    MAX = 40
    for ln in cibles[:MAX]:
        lignes.append("&nbsp;• %s &nbsp;<i>(%s)</i><br>" % (html.escape(ln[1]), html.escape(ln[2])))
    if len(cibles) > MAX:
        lignes.append("&nbsp;… et %d autre(s)<br>" % (len(cibles) - MAX))
    return "".join(lignes)


# ---------------------------------------------------------------- handlers

class _CreatedHandler(adsk.core.CommandCreatedEventHandler):
    def notify(self, args):
        try:
            cmd = args.command
            cmd.okButtonText = "Corriger"
            inputs = cmd.commandInputs
            inputs.addBoolValueInput("tout", "Tous les composants (pas seulement les doublons)", True, "", True)
            _oublier_releve()  # releve frais a chaque ouverture de la commande
            tb = inputs.addTextBoxCommandInput("apercu", "", _apercu_html(_design(), True), 14, True)
            tb.isFullWidth = True

            h_exec = _ExecuteHandler(); cmd.execute.add(h_exec); _handlers.append(h_exec)
            h_chg = _InputChangedHandler(); cmd.inputChanged.add(h_chg); _handlers.append(h_chg)
        except Exception:
            _ui.messageBox("Erreur :\n" + traceback.format_exc())


class _InputChangedHandler(adsk.core.InputChangedEventHandler):
    def notify(self, args):
        try:
            if args.input.id == "tout":
                inputs = args.inputs
                tout = adsk.core.BoolValueCommandInput.cast(inputs.itemById("tout")).value
                adsk.core.TextBoxCommandInput.cast(inputs.itemById("apercu")).formattedText = _apercu_html(_design(), tout)
        except Exception:
            _ui.messageBox("Erreur :\n" + traceback.format_exc())


class _ExecuteHandler(adsk.core.CommandEventHandler):
    def notify(self, args):
        try:
            design = _design()
            if not design:
                _ui.messageBox("Aucun design actif. Ouvrez le design (pas le dessin) puis relancez.", CMD_NAME)
                return
            tout = adsk.core.BoolValueCommandInput.cast(args.command.commandInputs.itemById("tout")).value
            cibles, _, _ = _analyse(design, tout)
            if not cibles:
                _oublier_releve()
                _ui.messageBox("Rien à corriger : aucun numéro de pièce en double.", CMD_NAME)
                return
            ok, erreurs = _corriger(cibles)
            _oublier_releve()
            msg = "%d composant(s) corrigé(s) : numéro de pièce = nom du composant." % ok
            if erreurs:
                msg += "\n\nNon modifiés :\n" + "\n".join(erreurs[:20])
            msg += ("\n\nPensez à enregistrer le design, puis à mettre à jour le dessin "
                    "(ou à réinsérer la liste de pièces).")
            _ui.messageBox(msg, CMD_NAME)
        except Exception:
            _ui.messageBox("Erreur :\n" + traceback.format_exc())


# ---------------------------------------------------------------- run / stop

def run(context):
    global _app, _ui
    try:
        _app = adsk.core.Application.get()
        _ui = _app.userInterface

        cd = _ui.commandDefinitions.itemById(CMD_ID)
        if cd:
            cd.deleteMe()
        cd = _ui.commandDefinitions.addButtonDefinition(CMD_ID, CMD_NAME, CMD_DESC, "./resources")
        h = _CreatedHandler(); cd.commandCreated.add(h); _handlers.append(h)

        # Bouton de ruban (PANEL_ID) RETIRE : devenu inutile depuis la
        # creation de CNC Toolkit, qui retrouve et execute cette
        # CommandDefinition directement depuis sa palette.
    except Exception:
        if _ui:
            _ui.messageBox("Échec du démarrage de Debug composant :\n" + traceback.format_exc())


def stop(context):
    try:
        panel = _ui.allToolbarPanels.itemById(PANEL_ID)
        if panel:
            ctrl = panel.controls.itemById(CMD_ID)
            if ctrl:
                ctrl.deleteMe()
        cd = _ui.commandDefinitions.itemById(CMD_ID)
        if cd:
            cd.deleteMe()
        _handlers.clear()
        _oublier_releve()
    except Exception:
        if _ui:
            _ui.messageBox("Échec de l'arrêt de Debug composant :\n" + traceback.format_exc())
