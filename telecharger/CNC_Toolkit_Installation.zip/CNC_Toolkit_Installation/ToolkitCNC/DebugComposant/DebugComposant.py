# Debug composant - Add-in Fusion
# Remplace les numeros de piece en double par le nom actuel de chaque composant,
# pour que la liste de pieces des dessins affiche des references uniques et justes.

import adsk.core, adsk.fusion, traceback, html

CMD_ID   = "DebugComposantCmd"
CMD_NAME = "Debug composant"
CMD_DESC = ("Remplace les numéros de pièce en double par le nom actuel de chaque composant "
            "(utile quand la liste de pièces du dessin n'affiche pas les bons noms).")
PANEL_ID = "SolidModifyPanel"

_app = None
_ui = None
_handlers = []


# ---------------------------------------------------------------- logique

def _design():
    return adsk.fusion.Design.cast(_app.activeProduct) if _app else None


def _composants_locaux(design):
    """Composants modifiables : on ignore ceux qui viennent d'un autre fichier (liés)."""
    res = []
    for c in design.allComponents:
        try:
            if c.parentDesign != design:
                continue
        except Exception:
            pass
        res.append(c)
    return res


def _analyse(design, tout):
    """Retourne (cibles, doublons) : composants a corriger et groupes de numeros en double."""
    comps = _composants_locaux(design)
    groupes = {}
    for c in comps:
        groupes.setdefault(c.partNumber, []).append(c)
    doublons = {pn: cs for pn, cs in groupes.items() if len(cs) > 1}
    cibles = []
    for c in comps:
        if c.partNumber == c.name:
            continue
        if tout or c.partNumber in doublons:
            cibles.append(c)
    cibles.sort(key=lambda c: c.name.lower())
    return cibles, doublons


def _corriger(cibles):
    ok, erreurs = 0, []
    for c in cibles:
        try:
            # Vide = Fusion reprend le nom du composant ; sinon on l'ecrit explicitement.
            c.partNumber = ""
            if c.partNumber != c.name:
                c.partNumber = c.name
            ok += 1
        except Exception as e:
            erreurs.append("%s (%s)" % (c.name, e))
    return ok, erreurs


def _apercu_html(design, tout):
    if not design:
        return "<b>Aucun design actif.</b> Ouvrez un design (pas un dessin)."
    cibles, doublons = _analyse(design, tout)
    nb_doublons = sum(len(cs) for cs in doublons.values())
    nb_diff = sum(1 for c in _composants_locaux(design) if c.partNumber != c.name)
    lignes = ["<b>%d</b> composant(s) ont un numéro de pièce différent de leur nom, "
              "dont <b>%d</b> en double.<br>" % (nb_diff, nb_doublons)]
    if not cibles:
        lignes.append("<br><b>Rien à corriger.</b>")
        return "".join(lignes)
    lignes.append("<br><b>%d</b> composant(s) seront corrigés :<br>" % len(cibles))
    MAX = 40
    for c in cibles[:MAX]:
        lignes.append("&nbsp;• %s &nbsp;<i>(%s)</i><br>" % (html.escape(c.name), html.escape(c.partNumber)))
    if len(cibles) > MAX:
        lignes.append("&nbsp;… et %d autre(s)<br>" % (len(cibles) - MAX))
    return "".join(lignes)


# ---------------------------------------------------------------- handlers

class _CreatedHandler(adsk.core.CommandCreatedEventHandler):
    def notify(self, args):
        try:
            cmd = args.command
            cmd.okButtonText = "Corriger"
            inputs = cmd.commandInputs
            inputs.addBoolValueInput("tout", "Tous les composants (pas seulement les doublons)", True, "", True)
            tb = inputs.addTextBoxCommandInput("apercu", "", _apercu_html(_design(), True), 14, True)
            tb.isFullWidth = True

            h_exec = _ExecuteHandler(); cmd.execute.add(h_exec); _handlers.append(h_exec)
            h_chg = _InputChangedHandler(); cmd.inputChanged.add(h_chg); _handlers.append(h_chg)
        except Exception:
            _ui.messageBox("Erreur :\n" + traceback.format_exc())


class _InputChangedHandler(adsk.core.InputChangedEventHandler):
    def notify(self, args):
        try:
            if args.input.id == "tout":
                inputs = args.inputs
                tout = adsk.core.BoolValueCommandInput.cast(inputs.itemById("tout")).value
                adsk.core.TextBoxCommandInput.cast(inputs.itemById("apercu")).formattedText = _apercu_html(_design(), tout)
        except Exception:
            _ui.messageBox("Erreur :\n" + traceback.format_exc())


class _ExecuteHandler(adsk.core.CommandEventHandler):
    def notify(self, args):
        try:
            design = _design()
            if not design:
                _ui.messageBox("Aucun design actif. Ouvrez le design (pas le dessin) puis relancez.", CMD_NAME)
                return
            tout = adsk.core.BoolValueCommandInput.cast(args.command.commandInputs.itemById("tout")).value
            cibles, _ = _analyse(design, tout)
            if not cibles:
                _ui.messageBox("Rien à corriger : aucun numéro de pièce en double.", CMD_NAME)
                return
            ok, erreurs = _corriger(cibles)
            msg = "%d composant(s) corrigé(s) : numéro de pièce = nom du composant." % ok
            if erreurs:
                msg += "\n\nNon modifiés :\n" + "\n".join(erreurs[:20])
            msg += ("\n\nPensez à enregistrer le design, puis à mettre à jour le dessin "
                    "(ou à réinsérer la liste de pièces).")
            _ui.messageBox(msg, CMD_NAME)
        except Exception:
            _ui.messageBox("Erreur :\n" + traceback.format_exc())


# ---------------------------------------------------------------- run / stop

def run(context):
    global _app, _ui
    try:
        _app = adsk.core.Application.get()
        _ui = _app.userInterface

        cd = _ui.commandDefinitions.itemById(CMD_ID)
        if cd:
            cd.deleteMe()
        cd = _ui.commandDefinitions.addButtonDefinition(CMD_ID, CMD_NAME, CMD_DESC, "./resources")
        h = _CreatedHandler(); cd.commandCreated.add(h); _handlers.append(h)

        # Bouton de ruban (PANEL_ID) RETIRE : devenu inutile depuis la
        # creation de CNC Toolkit, qui retrouve et execute cette
        # CommandDefinition directement depuis sa palette.
    except Exception:
        if _ui:
            _ui.messageBox("Échec du démarrage de Debug composant :\n" + traceback.format_exc())


def stop(context):
    try:
        panel = _ui.allToolbarPanels.itemById(PANEL_ID)
        if panel:
            ctrl = panel.controls.itemById(CMD_ID)
            if ctrl:
                ctrl.deleteMe()
        cd = _ui.commandDefinitions.itemById(CMD_ID)
        if cd:
            cd.deleteMe()
        _handlers.clear()
    except Exception:
        if _ui:
            _ui.messageBox("Échec de l'arrêt de Debug composant :\n" + traceback.format_exc())
