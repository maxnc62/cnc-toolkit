import adsk.core
import adsk.fusion
import traceback
import os
import sys
import json
import math
import time

# Apercu fluide partage (cnc_apercu_fluide.py a la racine de ToolkitCNC) : pastilles glissees par la souris.
try:
    _RACINE_TK = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if _RACINE_TK not in sys.path:
        sys.path.insert(0, _RACINE_TK)
    import cnc_apercu_fluide as _caf
except Exception:
    _caf = None

# ---------------------------------------------------------------------------
# Traverses de dossier CNC (2026-11-07)
#
# Traverses de renfort d'un dossier, en enfourchement avec les montants (outil Montants de dossier CNC). L'utilisateur
# choisit la face de la base (dalle) et l'arete du haut du dossier : cela definit un AXE VERTICAL sur lequel les
# traverses sont reparties comme Reseau CNC (poignee centrale = quantite, poignees des bouts = marges, symetrie,
# jusqu'au bout). Chaque traverse est une plaque horizontale dont les dimensions sont DETECTEES :
#   - longueur : le dossier a cette altitude (son sommet arrondi raccourcit la traverse) ;
#   - profondeur : la forme des montants a cette altitude (leur courbe exterieure est suivie).
# Resultat : un corps par traverse (esquisse + extrusion), groupe replie « Traverses dossier CNC », puis l'outil
# Entaille CNC creuse l'enfourchement (a mi-bois) entre chaque traverse et les montants.
# Fenetre « TRAVERSE » en bas a gauche : modele ReseauTrajectoireCNC (_png_ligne / _ov_*).
# ---------------------------------------------------------------------------

_app = None
_ui = None
_handlers = []

CMD_ID = 'TraversesDossierCNCCmd'
COMMAND_NAME = 'Traverses de dossier CNC'
COMMAND_DESC = 'Cree des traverses de renfort en enfourchement avec les montants d\'un dossier, longueur et profondeur detectees'
PANEL_ID = 'SolidCreatePanel'
GROUPE_NOM = 'Traverses dossier CNC'
NB_MAX = 50
ATTR_G, ATTR_N = 'TraversesDossierCNC', 'edit'

_ADDIN_DIR = os.path.dirname(os.path.abspath(__file__))
PREFS_FILE = os.path.join(_ADDIN_DIR, 'traverses_prefs.json')

ORANGE = (255, 90, 0, 255)
ROUGE = (220, 30, 30, 255)

DEFAULT_PREFS = {'epaisseur_mm': 18.0, 'n': 3, 'm1': 50.0, 'm2': 50.0, 'sym': True, 'retr': 0.0,
                 'prof_auto': True, 'prof_mm': 100.0, 'entaille': True, 'marge_auto': True,
                 'cv_mode': 'manuelle', 'cv_w': 12.0, 'cv_h': 70.0, 'cv_a': 100.0, 'cv_b': 60.0, 'param': True}
CLES = ('c', 'n', 'm1', 'm2', 'sym', 'fin_m', 'retr', 'prof_auto', 'prof_mm', 'entaille', 'marge_auto',
        'cv_mode', 'cv_w', 'cv_h', 'cv_a', 'cv_b', 'param')
SEL_IDS = ('face', 'arete')

_s = {}                    # reglages du jeu de traverses ACTIF (toujours l'un des dicts de _jeux, ou le modele)
_jeux = []                 # un jeu de reglages par dossier (face + arete) : une fenetre TRAVERSE chacun
_act = {'i': 0}
_cur = {'calc': None, 'ep': 1.8, 'ep_nom': None}
_en_cours = {'v': False}   # evite la reentrance des evenements provoques par nos ecritures
_drag = {'k': None}
_sel_fig = {'e': None}   # champs de selection figes pendant le glisser d'une poignee
_souris = {'pos': None, 'vp': None, 't': 0.0}
_bloc = {'t': 0.0, 'sel': None}
_bar = {'on': False, 'tm': 0.0}
_edition = {'v': None}     # modification demandee par l'historique : {blob, anciens}
_cache_traj = {}
_cache_ent = {}
_cache_faces = {}
_cf = {'ignores': set()}
_pastilles = {}
_qd = {'on': False}
ID_APERCU = 'TraversesDossierCNC_apercu'
ID_PASTILLE = 'TraversesDossierCNC_pastille%d'
ACTION_ID = 'TraversesDossierCNC_action'
REDRAW_ID = 'TraversesDossierCNC_redraw'
_action = {'evt': None, 'h': None}
_redraw = {'evt': None, 'h': None, 'on': False}


def _tt(s):
    """Texte dans la langue choisie (cnc_i18n est charge par ToolkitCNC)."""
    try:
        m = sys.modules.get('cnc_i18n')
        return m.t(s) if m is not None else s
    except Exception:
        return s


def _log(msg):
    try:
        with open(os.path.join(_ADDIN_DIR, 'traverses_journal.txt'), 'a', encoding='utf-8') as f:
            f.write(time.strftime('%H:%M:%S ') + msg + '\n')
    except Exception:
        pass


def load_prefs():
    p = dict(DEFAULT_PREFS)
    try:
        with open(PREFS_FILE, 'r', encoding='utf-8') as f:
            p.update(json.load(f))
    except Exception:
        pass
    return p


def save_prefs(p):
    try:
        with open(PREFS_FILE, 'w', encoding='utf-8') as f:
            json.dump(p, f)
    except Exception:
        pass


def _nouveau(p=None):
    p = p or load_prefs()
    return {'c': [], 'n': max(1, min(NB_MAX, int(p['n']))), 'm1': float(p['m1']), 'm2': float(p['m2']),
            'sym': bool(p['sym']), 'fin_m': None, 'retr': float(p['retr']), 'prof_auto': bool(p['prof_auto']),
            'prof_mm': float(p['prof_mm']), 'entaille': bool(p['entaille']), 'marge_auto': bool(p['marge_auto']),
            'cv_mode': p['cv_mode'] if p['cv_mode'] in CV_MODES else 'manuelle', 'cv_w': float(p['cv_w']),
            'cv_h': float(p['cv_h']), 'cv_a': float(p['cv_a']), 'cv_b': float(p['cv_b']),
            'param': bool(p.get('param', True))}


def _design():
    return adsk.fusion.Design.cast(_app.activeProduct)


def _face_monde(f):
    """(centre, normale unitaire, origine du plan) d'une face PLANE dans l'espace du document.
    La geometrie d'une face d'un composant est lue sur l'objet natif puis transformee
    (la lire sur le proxy donnait un centrage faux, retour du 2026-11-03)."""
    n = f.nativeObject if getattr(f, 'assemblyContext', None) is not None else f
    if isinstance(n, adsk.fusion.Profile):
        M = n.parentSketch.transform           # esquisse -> document : plan et normale de la face d'esquisse
        po = adsk.core.Point3D.create(0.0, 0.0, 0.0)
        po.transformBy(M)
        pv = adsk.core.Vector3D.create(0.0, 0.0, 1.0)
        pv.transformBy(M)
        c = _monde(f, p=po)
        return c, _v_norm(_monde(f, v=pv)), c
    g = n.geometry
    if not isinstance(g, adsk.core.Plane):
        return None
    c = _monde(f, p=n.centroid)
    nv = _v_norm(_monde(f, v=g.normal))
    o = _monde(f, p=g.origin)
    return c, nv, o


def _dist_rayon(o, d, f):
    """Distance de o a la face f le long de d (plan : exacte ; autre surface : approchee par la boite)."""
    i = None
    try:
        i = _face_monde(f)
    except Exception:
        pass
    if i is not None:
        _c, n, po = i
        den = _v_dot(n, d)
        if abs(den) < 1e-9:
            return None
        t = _v_dot(_v_sub(po, (o.x, o.y, o.z)), n) / den
        return t if t > 0 else None
    bb = f.boundingBox
    ts = []
    for x in (bb.minPoint.x, bb.maxPoint.x):
        for y in (bb.minPoint.y, bb.maxPoint.y):
            for z in (bb.minPoint.z, bb.maxPoint.z):
                ts.append((x - o.x) * d[0] + (y - o.y) * d[1] + (z - o.z) * d[2])
    t = min(ts)
    return t if max(ts) > 0 else None


def _ents(design, tokens):
    res = []
    for tok in tokens:
        e = _cache_ent.get(tok)
        if e is None or not getattr(e, 'isValid', True):
            e = None
            try:
                r = design.findEntityByToken(tok)
                if r:
                    e = r[0]
                    _cache_ent[tok] = e
            except Exception:
                pass
        if e is not None:
            res.append(e)
    return res


def _monde(ent, p=None, v=None):
    """Point (p) ou vecteur (v) natif d'une entite d'un composant -> espace du document."""
    ctx = getattr(ent, 'assemblyContext', None)
    if p is not None:
        q = p.copy()
        if ctx is not None:
            q.transformBy(ctx.transform2)
        return (q.x, q.y, q.z)
    w = v.copy()
    if ctx is not None:
        w.transformBy(ctx.transform2)
    return (w.x, w.y, w.z)


def _courbe_monde(ent):
    n = ent.nativeObject if getattr(ent, 'assemblyContext', None) is not None else ent
    if isinstance(n, adsk.fusion.BRepEdge):
        g = n.geometry.copy()
    elif isinstance(n, adsk.fusion.SketchCurve):
        g = n.worldGeometry.copy()
    else:
        return None
    ctx = getattr(ent, 'assemblyContext', None)
    if ctx is not None:
        g.transformBy(ctx.transform2)
    return g


def _echantillonner(ent, n=120):
    c = _courbe_monde(ent)
    if c is None:
        return []
    if isinstance(c, adsk.core.Line3D):
        a, b = c.startPoint, c.endPoint
        return [(a.x, a.y, a.z), (b.x, b.y, b.z)]
    ev = c.evaluator
    ok, p0, p1 = ev.getParameterExtents()
    pts = []
    for k in range(n + 1):
        ok, p = ev.getPointAtParameter(p0 + (p1 - p0) * k / n)
        if ok:
            pts.append((p.x, p.y, p.z))
    return pts


def _d3(a, b):
    return math.sqrt((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 + (a[2] - b[2]) ** 2)


class _Trajet:
    """Chemin echantillonne par abscisse curviligne (fraction 0..1)."""

    def __init__(self, ents):
        segs = [s for s in (_echantillonner(e) for e in ents) if len(s) >= 2]
        if not segs:
            raise ValueError('chemin vide')
        chain = segs.pop(0)
        while segs:
            best = None
            for i, s in enumerate(segs):
                for d, mode, rev in ((_d3(chain[-1], s[0]), 'a', False), (_d3(chain[-1], s[-1]), 'a', True),
                                     (_d3(s[-1], chain[0]), 'p', False), (_d3(s[0], chain[0]), 'p', True)):
                    if best is None or d < best[0]:
                        best = (d, i, mode, rev)
            _d, i, mode, rev = best
            s = segs.pop(i)
            seg = s[::-1] if rev else s
            chain = chain + seg[1:] if mode == 'a' else seg[:-1] + chain
        self.pts = chain
        self.cum = [0.0]
        for i in range(1, len(chain)):
            self.cum.append(self.cum[-1] + _d3(chain[i - 1], chain[i]))
        self.longueur = self.cum[-1]
        if self.longueur < 1e-9:
            raise ValueError('chemin nul')

    def at(self, f):
        """(point, tangente) en flottants a la fraction f."""
        f = max(0.0, min(1.0, f))
        s = f * self.longueur
        lo, hi = 0, len(self.cum) - 1
        while hi - lo > 1:
            m = (lo + hi) // 2
            if self.cum[m] <= s:
                lo = m
            else:
                hi = m
        a, b = self.pts[lo], self.pts[lo + 1]
        L = self.cum[lo + 1] - self.cum[lo] or 1.0
        u = (s - self.cum[lo]) / L
        p = tuple(a[k] + (b[k] - a[k]) * u for k in range(3))
        t = tuple((b[k] - a[k]) / L for k in range(3))
        return p, t

    def frac_point(self, q):
        """Fraction du chemin au point le plus proche de q (point clique), affinee sur le segment."""
        pts = self.pts
        best = min(range(len(pts)), key=lambda i: _d3(pts[i], q))
        sb, db = self.cum[best], _d3(pts[best], q)
        for j in (best - 1, best):
            if 0 <= j < len(pts) - 1:
                a, b = pts[j], pts[j + 1]
                e = _v_sub(b, a)
                e2 = _v_dot(e, e)
                if e2 < 1e-18:
                    continue
                u = max(0.0, min(1.0, _v_dot(_v_sub(q, a), e) / e2))
                dd = _d3(_v_add(a, _v_mul(e, u)), q)
                if dd < db:
                    db, sb = dd, self.cum[j] + u * (self.cum[j + 1] - self.cum[j])
        return sb / self.longueur

    def proche_3d(self, q):
        best = min(range(len(self.pts)), key=lambda i: _d3(self.pts[i], q))
        return self.cum[best] / self.longueur


def _traj(ents_tokens, design):
    cle = tuple(ents_tokens)
    if cle not in _cache_traj:
        if len(_cache_traj) > 40:
            _cache_traj.clear()
        try:
            _cache_traj[cle] = _Trajet(_ents(design, ents_tokens))
        except ValueError:
            for tok in ents_tokens:              # entite perdue (chronologie reculee, recalcul) : on relit les jetons
                _cache_ent.pop(tok, None)
            try:
                _cache_traj[cle] = _Trajet(_ents(design, ents_tokens))
            except ValueError:
                _log('chemin introuvable : %d jeton(s), resolus=%d' % (len(ents_tokens), len(_ents(design, ents_tokens))))
                raise
    return _cache_traj[cle]


def _v_sub(a, b): return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def _v_add(a, b): return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def _v_mul(a, k): return (a[0] * k, a[1] * k, a[2] * k)


def _v_dot(a, b): return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def _v_cross(a, b): return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def _v_norm(a):
    n = math.sqrt(_v_dot(a, a))
    return (a[0] / n, a[1] / n, a[2] / n) if n > 1e-12 else (0.0, 0.0, 0.0)


def _vers_haut():
    try:
        o = _app.preferences.generalPreferences.defaultModelingOrientation
        if o == adsk.core.DefaultModelingOrientations.YUpModelingOrientation:
            return (0.0, 1.0, 0.0)
    except Exception:
        pass
    return (0.0, 0.0, 1.0)


def _rayon(design, o, dv):
    """[(face, distance)] des faces touchees par le rayon parti de o (Point3D) dans la direction dv. Distance
    exacte lue sur les points d'impact de Fusion (faces courbes, splines comprises) ; l'ancienne approximation
    par la boite d'une face courbe donnait des largeurs fausses (FS210, 2026-11-05). None si echec."""
    hp = adsk.core.ObjectCollection.create()
    try:
        faces = design.rootComponent.findBRepUsingRay(o, adsk.core.Vector3D.create(dv[0], dv[1], dv[2]),
                                                      adsk.fusion.BRepEntityTypes.BRepFaceEntityType, -1.0, True, hp)
    except Exception:
        return None
    if faces is None:
        return None
    exact = hp.count == faces.count
    out = []
    for i in range(faces.count):
        f = faces.item(i)
        if _cf['ignores']:
            try:
                if f.body.entityToken in _cf['ignores']:
                    continue                 # recalcul automatique : les anciennes traverses ne comptent pas
            except Exception:
                pass
        if exact:
            h = hp.item(i)
            t = (h.x - o.x) * dv[0] + (h.y - o.y) * dv[1] + (h.z - o.z) * dv[2]
            t = t if t > 0 else None
        else:
            t = _dist_rayon(o, dv, f)
        out.append((f, t))
    return out


def _sortie_corps(design, body, q, dv, tmax):
    """Distance de q (dans body) a la vraie sortie de body le long de dv : premier impact apres lequel le point
    est hors du corps. Les faces traversees sans sortir (mortaise, autre corps, face interne) sont ignorees."""
    hits = _rayon(design, adsk.core.Point3D.create(*q), dv)
    if hits is None:
        return None
    ts = [t for _f, t in hits if t is not None and 1e-4 < t <= tmax]
    for t in sorted(set(round(x, 5) for x in ts)):
        pt = adsk.core.Point3D.create(*_v_add(q, _v_mul(dv, t + 0.03)))
        try:
            if body.pointContainment(pt) == adsk.fusion.PointContainment.PointOutsidePointContainment:
                return t
        except Exception:
            return None
    return None


_dv = {'ents': [], 'h': None, 'c': None, 'r': 0.0, 't': 0.0}


def _dv_point():
    app = adsk.core.Application.get()
    des = adsk.fusion.Design.cast(app.activeProduct)
    if des is None:
        return None
    if time.time() - _dv['t'] > 1.0:
        _dv['t'] = time.time()
        bb = des.rootComponent.boundingBox
        if bb is None:
            _dv['c'] = None
        else:
            a, b = bb.minPoint, bb.maxPoint
            _dv['c'] = ((a.x + b.x) / 2.0, (a.y + b.y) / 2.0, (a.z + b.z) / 2.0)
            _dv['r'] = a.distanceTo(b) / 2.0
    c = _dv['c']
    if c is None:
        return None
    cam = app.activeViewport.camera
    e, t = cam.eye, cam.target
    d = (e.x - t.x, e.y - t.y, e.z - t.z)
    lg = math.sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2])
    if lg < 1e-9:
        return None
    d = (d[0] / lg, d[1] / lg, d[2] / lg)
    ec = (e.x - c[0]) * d[0] + (e.y - c[1]) * d[1] + (e.z - c[2]) * d[2]
    # juste devant le modele, mais jamais derriere la camera (perspective tres zoomee)
    s = min(_dv['r'] * 1.2 + 1.0, ec * 0.5) if ec > 0 else 0.0
    p = adsk.core.Point3D.create(c[0] + d[0] * s, c[1] + d[1] * s, c[2] + d[2] * s)
    occ = des.activeOccurrence
    if occ is not None:
        inv = occ.transform2.copy()
        inv.invert()
        p.transformBy(inv)
    return p


def _dv_appliquer(ents):
    p = _dv_point()
    if p is None:
        return
    m = adsk.core.Matrix3D.create()
    m.translation = adsk.core.Vector3D.create(p.x, p.y, p.z)
    for x in ents:
        x.transform = m


class _DvCamHandler(adsk.core.CameraEventHandler):
    def notify(self, args):
        try:
            ents = [x for x in _dv['ents'] if x.isValid]
            _dv['ents'] = ents
            if ents:
                _dv_appliquer(ents)
        except Exception:
            pass


def _dv_poser(ps):
    """A appeler apres chaque ps.viewPlacement = ... d'une fenetre du bas a gauche."""
    try:
        _dv['t'] = 0.0
        _dv_appliquer([ps])
        _dv['ents'] = [x for x in _dv['ents'] if x.isValid] + [ps]
        if _dv['h'] is None:
            h = _DvCamHandler()
            adsk.core.Application.get().cameraChanged.add(h)
            _dv['h'] = h
    except Exception:
        pass


def _dv_arreter():
    try:
        if _dv['h'] is not None:
            adsk.core.Application.get().cameraChanged.remove(_dv['h'])
    except Exception:
        pass
    _dv['h'] = None
    _dv['ents'] = []


def _balayer(ident):
    """Supprime TOUS les groupes graphiques portant cet id (composant actif et racine) :
    un groupe orphelin (rechargement du module, erreur...) restait affiche a l'ecran."""
    try:
        design = _design()
        comps = {design.rootComponent.entityToken: design.rootComponent}
        ac = design.activeComponent
        comps[ac.entityToken] = ac
        for comp in comps.values():
            gs = comp.customGraphicsGroups
            for i in range(gs.count - 1, -1, -1):
                try:
                    g = gs.item(i)
                    if g.id == ident:
                        g.deleteMe()
                except Exception:
                    pass
    except Exception:
        pass


def _supprimer_groupes(grps):
    for g in list(grps.values()):
        try:
            if g.isValid:
                g.deleteMe()
        except Exception:
            pass


def _ecran(tr, vp):
    """Points du chemin projetes a l'ecran (gardes tant que la camera ne bouge pas)."""
    try:
        cam = vp.camera
        cle = (id(tr), tuple(round(v, 4) for v in cam.eye.asArray() + cam.target.asArray() + cam.upVector.asArray()),
               round(cam.viewExtents, 4), vp.width, vp.height)
    except Exception:
        cle = None
    c = getattr(tr, '_scr', None)
    if c is None or cle is None or c[0] != cle:
        res = []
        P3 = adsk.core.Point3D.create
        for p in tr.pts:
            q = vp.modelToViewSpace(P3(p[0], p[1], p[2]))
            res.append((q.x, q.y))
        tr._scr = (cle, res)
    return tr._scr[1]


def _frac_souris(tr, vp, m):
    """Fraction du chemin dont le point est le plus proche de la souris, a l'ecran."""
    ecr = _ecran(tr, vp)
    best = min(range(len(ecr)), key=lambda i: (ecr[i][0] - m.x) ** 2 + (ecr[i][1] - m.y) ** 2)
    sb = tr.cum[best]
    db = (ecr[best][0] - m.x) ** 2 + (ecr[best][1] - m.y) ** 2
    for j in (best - 1, best):
        if 0 <= j < len(ecr) - 1:
            ax, ay = ecr[j]
            ex, ey = ecr[j + 1][0] - ax, ecr[j + 1][1] - ay
            e2 = ex * ex + ey * ey
            if e2 < 1e-12:
                continue
            u = max(0.0, min(1.0, ((m.x - ax) * ex + (m.y - ay) * ey) / e2))
            dd = (ax + u * ex - m.x) ** 2 + (ay + u * ey - m.y) ** 2
            if dd < db:
                db, sb = dd, tr.cum[j] + u * (tr.cum[j + 1] - tr.cum[j])
    return sb / tr.longueur


class _CameraHandler(adsk.core.CameraEventHandler):
    """La vue tourne : les pastilles sont recalees devant la camera (elles passent devant les corps)."""
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            for g in list(_pastilles.values()):
                g.recaler(args.viewport)
        except Exception:
            pass


_camera = {'h': None}


def _camera_suivre(oui):
    try:
        if oui and _camera['h'] is None and _caf is not None:
            _camera['h'] = _CameraHandler()
            _app.cameraChanged.add(_camera['h'])
        elif not oui and _camera['h'] is not None:
            _app.cameraChanged.remove(_camera['h'])
            _camera['h'] = None
    except Exception:
        _log('camera : ' + traceback.format_exc()[-200:])


def _pastilles_effacer():
    for g in list(_pastilles.values()):
        g.effacer()
    _pastilles.clear()
    if _caf is not None:
        for k in (0, 1, 2):
            _caf.balayer(ID_PASTILLE % k)


def _ep_noms(design):
    """Noms proposes : CP10 / CP15 / CP18 puis les autres parametres CPxx du projet."""
    noms = list(NC_CP)
    try:
        ups = design.userParameters
        for i in range(ups.count):
            n = ups.item(i).name
            if n.upper().startswith('CP') and n not in noms:
                noms.append(n)
    except Exception:
        pass
    return noms


def _ep_cm_nom(design, nom):
    p = design.allParameters.itemByName(nom)
    return p.value if p is not None else NC_CP.get(nom, 1.8)


def _ep_remplir(dd, design, defaut_cm):
    """Liste deroulante des epaisseurs (CPxx du projet + « Autre... ») ; renvoie True si une valeur est choisie."""
    trouve = False
    for n in _ep_noms(design):
        cm = _ep_cm_nom(design, n)
        sel = (not trouve) and abs(cm - defaut_cm) < 1e-4
        trouve = trouve or sel
        dd.listItems.add('%s (%s mm)' % (n, ('%.2f' % (cm * 10.0)).rstrip('0').rstrip('.')), sel, '')
    dd.listItems.add('Autre...', not trouve, '')
    return trouve


def _ep_choisir(inputs, cm):
    """Selectionne la ligne dont la valeur est cm, sinon « Autre... » avec la valeur saisie."""
    dd = inputs.itemById('ep_dd')
    design = _design()
    noms = _ep_noms(design)
    for i, n in enumerate(noms):
        if abs(_ep_cm_nom(design, n) - cm) < 1e-4:
            dd.listItems.item(i).isSelected = True
            inputs.itemById('ep_autre').isVisible = False
            return
    dd.listItems.item(dd.listItems.count - 1).isSelected = True
    a = inputs.itemById('ep_autre')
    a.value = cm
    a.isVisible = True


def _ep_cm(inputs):
    try:
        dd = inputs.itemById('ep_dd')
        if dd is not None:
            if dd.selectedItem.index == dd.listItems.count - 1:
                return max(0.01, inputs.itemById('ep_autre').value)
            design = _design()
            return max(0.01, _ep_cm_nom(design, _ep_noms(design)[dd.selectedItem.index]))
        return max(0.01, inputs.itemById('epaisseur').value)
    except Exception:
        return max(0.01, load_prefs()['epaisseur_mm'] / 10.0)


def _cp_nom_valeur(design, ep_cm, prefere=None):
    """Audit des parametres (2026-11-16) : une epaisseur deja enregistree est reutilisee, jamais recreee. Ordre :
    le parametre attendu (prefere, puis CPxx, xx = mm) s'il a cette valeur, sinon tout autre parametre CP* de meme
    valeur ; a defaut, nom a creer CPxx (CP18, CP12_5). Si ce nom est deja pris par une AUTRE valeur (CP18 passe a
    18,3 mm), un 0 est ajoute (CP18_0 = 18,0 mm) : on ne reprend jamais une valeur fausse."""
    nom = 'CP' + ('%g' % round(ep_cm * 10.0, 2)).replace('.', '_')
    cands = []
    try:
        ups = design.userParameters
        for i in range(ups.count):
            q = ups.item(i)
            if q.name.upper().startswith('CP') and abs(q.value - ep_cm) < 1e-4:
                cands.append(q.name)
    except Exception:
        pass
    for n in (prefere, nom):
        if n and n in cands:
            return n
    if cands:
        return cands[0]
    while design.allParameters.itemByName(nom) is not None:
        nom += '0' if '_' in nom else '_0'
    return nom


def _ep_parametre(design, inputs, ep_cm):
    """Le parametre d'epaisseur existe dans le projet : CP10 / CP15 / CP18 crees s'ils manquent, ou CPxx
    pour une epaisseur libre (comme Reseau CNC). Renvoie son nom."""
    nom = None
    try:
        dd = inputs.itemById('ep_dd')
        if dd is not None and dd.selectedItem.index < dd.listItems.count - 1:
            nom = _ep_noms(design)[dd.selectedItem.index]
    except Exception:
        nom = None
    if nom is None or design.allParameters.itemByName(nom) is None:
        nom = _cp_nom_valeur(design, ep_cm, nom)       # meme valeur deja en parametre : reutilisee
    if design.allParameters.itemByName(nom) is None:
        design.userParameters.add(nom, adsk.core.ValueInput.createByReal(ep_cm), 'mm', 'Epaisseur contreplaque')
    return nom


class _PreSelectHandler(adsk.core.SelectionEventHandler):
    """Rien n'est preselectionnable sous une poignee (ni pendant son glisser) : on attrape la poignee,
    pas la face ou l'arete qui est derriere."""
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            ent = args.selection.entity
            if isinstance(ent, adsk.fusion.Profile):
                if not _modes['esq']:
                    args.isSelectable = False
                    return
            elif isinstance(ent, adsk.fusion.BRepFace):
                if _modes['esq']:
                    args.isSelectable = False
                    return
            if _drag.get('maison') or _qd.get('on'):
                args.isSelectable = False
                return
            vp, pos = _souris.get('vp'), _souris.get('pos')
            if _caf is None or vp is None or pos is None or not _pastilles:
                return
            r = 16.0 * _dpr()
            for g in _pastilles.values():
                if g.p is None:
                    continue
                q = vp.modelToViewSpace(adsk.core.Point3D.create(*g.p))
                if math.hypot(q.x - pos.x, q.y - pos.y) <= r:
                    args.isSelectable = False
                    return
        except Exception:
            pass


def _supprimer_anciens(design, tokens):
    """Supprime les entrees de l'ancienne traverse (groupe deplie, de la derniere a la premiere)."""
    r = design.findEntityByToken(tokens[0]) if tokens else None
    if r:
        try:
            g = r[0].timelineObject.parentGroup
            if g is not None and g.isCollapsed:
                g.isCollapsed = False
        except Exception:
            pass
    ok = True
    for tok in reversed(tokens):
        try:
            r = design.findEntityByToken(tok)
            if r:
                r[0].deleteMe()
        except Exception:
            ok = False
            _log('suppression ancien erreur ' + traceback.format_exc()[-300:])
    return ok


_resel = {'ins': None}
_modes = {'esq': True}          # base = face d'esquisse (sinon face du corps) : l'autre sorte n'est pas preselectionnable


def _remettre_selection():
    """Modification depuis l'historique : la selection chargee a l'ouverture est parfois perdue ; on la remet une
    fois la fenetre ouverte."""
    ins = _resel['ins']
    _resel['ins'] = None
    if ins is None or not _s['c']:
        return
    try:
        cnt = [ins.itemById(k).selectionCount for k in SEL_IDS]
        _log('resel : selections %s' % cnt)
        if all(cnt):
            return
        _en_cours['v'] = True
        try:
            _charger_selection(ins)
            _rafraichir(ins, True)
        finally:
            _en_cours['v'] = False
    except Exception:
        _log('resel erreur ' + traceback.format_exc()[-300:])


class _ActionHandler(adsk.core.CustomEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            if getattr(args, 'additionalInfo', '') == '@resel':
                _remettre_selection()
                return
            cd = _ui.commandDefinitions.itemById(CMD_ID)
            deja = False
            try:
                deja = (_ui.activeCommand == CMD_ID)
            except Exception:
                pass
            if time.time() - _action.get('t', 0.0) < 5.0:
                deja = True
            _log('action : evenement recu' + (' (fenetre deja ouverte)' if deja else ', ouverture de la fenetre'))
            if cd is not None and not deja:
                cd.execute()
        except Exception:
            _log('action erreur ' + traceback.format_exc()[-300:])


def _differer(info='go'):
    """Ouvre la commande hors du gestionnaire de la palette (evenement personnalise, comme Reseau CNC)."""
    try:
        if _action['evt'] is None:
            try:
                _app.unregisterCustomEvent(ACTION_ID)
            except Exception:
                pass
            _action['evt'] = _app.registerCustomEvent(ACTION_ID)
            _action['h'] = _ActionHandler()
            _action['evt'].add(_action['h'])
        if not _app.fireCustomEvent(ACTION_ID, info):
            if info != 'go':
                _log('differer %s : evenement non confirme' % info)
                return
            # evenement non confirme : ouverture directe ; si l'evenement arrive quand meme, le gestionnaire voit la
            # fenetre deja ouverte et ne relance pas (deux executions fermeraient la fenetre aussitot)
            _log('differer : evenement non confirme, ouverture directe')
            _action['t'] = time.time()
            _ui.commandDefinitions.itemById(CMD_ID).execute()
    except Exception:
        _log('differer : ' + traceback.format_exc()[-200:])
        _ui.commandDefinitions.itemById(CMD_ID).execute()


def _rafraichir_vue():
    try:
        _app.activeViewport.refresh()
    except Exception:
        pass


def _nom_libre(comp, base):
    noms = set(comp.bRepBodies.item(i).name for i in range(comp.bRepBodies.count))
    k = 1
    while '%s %d' % (base, k) in noms:
        k += 1
    return '%s %d' % (base, k)


_GLYPHES = {
    'C': '111100100100111', 'H': '101101111101101', 'E': '111100111100111', 'M': '101111111101101',
    'T': '111010010010010', 'O': '111101101101111', 'U': '101101101101111',
    'S': '111100111001111', 'I': '111010010010111', 'N': '111101101101101', ' ': '000000000000000',
    '0': '111101101101111', '1': '010110010010111', '2': '111001111100111', '3': '111001111001111',
    '4': '101101111001001', '5': '111100111001111', '6': '111100111101111', '7': '111001001001001',
    '8': '111101111101111', '9': '111101111001111',
    'A': '010101111101101', 'B': '110101110101110', 'D': '110101101101110', 'F': '111100110100100',
    'G': '011100101101011', 'J': '001001001101010', 'K': '101101110101101', 'L': '100100100100111',
    'P': '110101110100100', 'Q': '010101101111011', 'R': '110101110101101', 'V': '101101101101010',
    'W': '101101111111101', 'X': '101101010101101', 'Y': '101101010010010', 'Z': '111001010100111',
    "'": '010010000000000', '.': '000000000000010', ',': '000000000010100', '-': '000000111000000',
    ':': '000010000010000', '%': '101001010100101', '/': '001001010100100'}


NC_CP = {'CP10': 1.0, 'CP15': 1.5, 'CP18': 1.8}      # epaisseurs de contreplaque (cm), comme Reseau CNC
_png_cache = {}
_dpr_cache = {}


# --- Axe vertical (face de la base + arete du haut du dossier) -------------------------------------------------

class _AxeV:
    """Axe vertical de la base de la face choisie jusqu'a l'arete du haut du dossier (meme interface que _Trajet)."""

    def __init__(self, p0, p1):
        self.pts = [tuple(p0), tuple(p1)]
        self.longueur = _d3(p0, p1)
        self.cum = [0.0, self.longueur]

    def at(self, f):
        f = max(0.0, min(1.0, f))
        p = tuple(self.pts[0][k] + (self.pts[1][k] - self.pts[0][k]) * f for k in range(3))
        t = tuple((self.pts[1][k] - self.pts[0][k]) / (self.longueur or 1.0) for k in range(3))
        return p, t

    def frac_point(self, q):
        d = _v_sub(self.pts[1], self.pts[0])
        return max(0.0, min(1.0, _v_dot(_v_sub(q, self.pts[0]), d) / ((self.longueur ** 2) or 1.0)))

    def proche_3d(self, q):
        return self.frac_point(q)


class _Chaine(_Trajet):
    """Courbe du dossier (face arriere) : segments echantillonnes, assembles bout a bout."""

    def __init__(self, segs):
        segs = [list(s) for s in segs if len(s) >= 2]
        if not segs:
            raise ValueError('chaine vide')
        chain = segs.pop(0)
        while segs:
            best = None
            for i, s in enumerate(segs):
                for d, mode, rev in ((_d3(chain[-1], s[0]), 'a', False), (_d3(chain[-1], s[-1]), 'a', True),
                                     (_d3(s[-1], chain[0]), 'p', False), (_d3(s[0], chain[0]), 'p', True)):
                    if best is None or d < best[0]:
                        best = (d, i, mode, rev)
            _d, i, mode, rev = best
            s = segs.pop(i)
            seg = s[::-1] if rev else s
            chain = chain + seg[1:] if mode == 'a' else seg[:-1] + chain
        self.pts = chain
        self.cum = [0.0]
        for i in range(1, len(chain)):
            self.cum.append(self.cum[-1] + _d3(chain[i - 1], chain[i]))
        self.longueur = self.cum[-1]
        if self.longueur < 1e-9:
            raise ValueError('chaine nulle')


# --- Detection : dossier, montants, profil -----------------------------------------------------------------

NHW = 28                    # echantillons de profondeur par montant (sur sa hauteur)
_prof = {'cle': None, 'd': None, 'err': None}
_prof_multi = {}
_prof_err = {}


def _prof_inv():
    _prof['cle'] = None
    _prof['err'] = None
    _prof_multi.clear()
    _prof_err.clear()


class _Echec(Exception):
    def __init__(self, code):
        super().__init__(code)
        self.code = code


def _corps_actifs(design):
    """Corps du composant actif (espace du document)."""
    try:
        occ = design.activeOccurrence
        coll = occ.bRepBodies if occ is not None else design.rootComponent.bRepBodies
    except Exception:
        coll = design.rootComponent.bRepBodies
    return [coll.item(i) for i in range(coll.count)]


def _est_montant(b):
    try:
        if b.attributes.itemByName('MontantsDossierCNC', 'edit') is not None:
            return True
    except Exception:
        pass
    n = (b.name or '').lower()
    return n.startswith('montant') or n.startswith('upright')


def _pt_sommet(v):
    n = v.nativeObject if getattr(v, 'assemblyContext', None) is not None else v
    return _monde(v, p=n.geometry)


def _loc(a, t, u, ea, th, up):
    """Coordonnees locales (a, t, u) -> point du document."""
    return tuple(ea[k] * a + th[k] * t + up[k] * u for k in range(3))


def _dans(body, q):
    try:
        return body.pointContainment(adsk.core.Point3D.create(*q)) != adsk.fusion.PointContainment.PointOutsidePointContainment
    except Exception:
        return False


def _cadre_montant(design, b, ply, up):
    """Repere d'un montant : epaisseur th, sens vers l'arriere ar, pied F (contre le dossier), grille des profondeurs."""
    best = None
    for f in b.faces:
        try:
            i = _face_monde(f)
        except Exception:
            i = None
        if i is None:
            continue
        n = i[1]
        if abs(_v_dot(n, up)) > 0.2:
            continue
        if best is None or f.area > best[0]:
            best = (f.area, n)
    if best is None:
        return None
    th = best[1]
    th = _v_norm(_v_sub(th, _v_mul(up, _v_dot(th, up))))
    ea = _v_norm(_v_cross(th, up))
    tmin = umin = 1e9
    tmax = umax = -1e9
    pts_ = []
    for v in b.vertices:
        p = _pt_sommet(v)
        pts_.append(p)
        t_, u_ = _v_dot(p, th), _v_dot(p, up)
        tmin, tmax = min(tmin, t_), max(tmax, t_)
        umin, umax = min(umin, u_), max(umax, u_)
    tm = (tmin + tmax) / 2.0
    # face avant du montant : la grande face perpendiculaire a la largeur qui touche le dossier (les tenons du dos
    # depassent de cette face dans le dossier : ils ne comptent pas)
    cands = []
    for f in b.faces:
        try:
            i = _face_monde(f)
        except Exception:
            i = None
        if i is not None and abs(_v_dot(i[1], ea)) > 0.99:
            cands.append((f.area, i[0], i[1]))
    cands.sort(key=lambda x: -x[0])
    front = None
    for _ar, c, n in cands[:4]:
        i1 = _dans(ply, _v_add(c, _v_mul(n, 0.25)))
        i2 = _dans(ply, _v_sub(c, _v_mul(n, 0.25)))
        if i1 != i2:
            front = (c, _v_mul(n, -1.0) if i1 else n)
            break
    if front is None:
        return None
    ar = front[1]
    af = _v_dot(front[0], ar)
    F = _v_add(_v_add(_v_mul(ar, af), _v_mul(th, tm)), _v_mul(up, umin))
    amax = max(_v_dot(p, ar) for p in pts_)
    u = {'b': b, 'ar': ar, 'th': th, 'F': F, 'z0': umin, 'z1': umax, 'W0': amax - af, 'ep': tmax - tmin}
    hs, ws = [], []
    for j in range(NHW):
        h = umin + 0.05 + (umax - umin - 0.1) * j / (NHW - 1.0)
        hs.append(h)
        ws.append(_w_exact(design, u, h))
    u['hs'], u['ws'] = hs, ws
    return u


def _w_exact(design, u, h):
    """Profondeur (cm) du montant a l'altitude h : du dossier jusqu'a son bord arriere. None s'il n'y a pas de matiere."""
    q = _v_add(_v_add(u['F'], _v_mul(u['ar'], 0.1)), _v_mul(_vers_haut(), h - u['z0']))
    if not _dans(u['b'], q):
        return None
    ex = _sortie_corps(design, u['b'], q, u['ar'], 500.0)
    return None if ex is None else ex + 0.1


def _w_montant(design, u, z, e, exact):
    """Profondeur du montant sur l'epaisseur de la traverse (la plus grande des trois mesures : de la matiere plutot que du vide)."""
    ws = []
    for h in (z - e + 0.05, z, z + e - 0.05):
        if h > u['z1'] - 0.02 or h < u['z0'] + 0.02:
            return None
        w = _w_exact(design, u, h) if exact else _interp(u['hs'], u['ws'], h)
        if w is None:
            return None
        ws.append(w)
    return max(ws)


def _chaine_dossier(design, ply, ups, up, zs):
    """Courbe de la face arriere du dossier, a la base (altitude zs) : section du dossier juste au-dessus de la dalle,
    arete la plus proche des pieds des montants."""
    tbm = adsk.fusion.TemporaryBRepManager.get()
    P3, V3 = adsk.core.Point3D.create, adsk.core.Vector3D.create
    pl = adsk.core.Plane.create(P3(*_v_mul(up, zs + 1.0)), V3(*up))
    try:
        w = tbm.planeIntersection(ply, pl)
    except Exception:
        bb = ply.boundingBox
        _log('section du dossier impossible : zs=%.3f corps=%s hauteurs %.2f..%.2f' % (
            zs, getattr(ply, 'name', '?'), _v_dot((bb.minPoint.x, bb.minPoint.y, bb.minPoint.z), up),
            _v_dot((bb.maxPoint.x, bb.maxPoint.y, bb.maxPoint.z), up)))
        raise _Echec('DOSSIER')
    segs = []
    for wi in range(w.wires.count):
        wire = w.wires.item(wi)
        for ei in range(wire.edges.count):
            pts = _echantillonner(wire.edges.item(ei), 80)
            if len(pts) >= 2:
                segs.append(pts)
    if not segs:
        raise _Echec('DOSSIER')

    def dseg(p, seg):
        best = 1e18
        for i in range(len(seg) - 1):
            a, b = seg[i], seg[i + 1]
            ab = _v_sub(b, a)
            n2 = _v_dot(ab, ab)
            t = 0.0 if n2 < 1e-12 else max(0.0, min(1.0, _v_dot(_v_sub(p, a), ab) / n2))
            best = min(best, _d3(p, _v_add(a, _v_mul(ab, t))))
        return best

    def dist(seg):
        tot = 0.0
        for u in ups:
            tot = max(tot, dseg(_v_add(u['F'], _v_mul(up, 1.0)), seg))
        return tot
    ds = [(dist(s), i) for i, s in enumerate(segs)]
    dmin = min(d for d, _i in ds)
    choisis = [segs[i] for d, i in ds if d < max(1.0, dmin + 0.5)]
    ch = _Chaine(choisis)
    ch.pts = [_v_sub(p, up) for p in ch.pts]                # ramenee a la base
    return ch


def _rep(g, s_):
    """(point sur la face arriere du dossier, direction vers l'arriere) a l'abscisse s_ (cm) de la courbe."""
    ch, up = g['ch'], g['up']
    p, tg = ch.at(s_ / ch.longueur)
    th = _v_sub(tg, _v_mul(up, _v_dot(tg, up)))
    if _v_dot(th, th) < 1e-12:
        th = tg
    a = _v_mul(_v_norm(_v_cross(_v_norm(th), up)), g['sg'])
    return p, a


def _geom(design, s):
    """Axe vertical + profil du dossier + montants, mesures une fois (tant que la selection ne change pas) ; un echec
    est garde aussi (pas de remesure a chaque mouvement de souris)."""
    cle = tuple(s['c'])
    if cle in _prof_multi:
        return _prof_multi[cle]
    if cle in _prof_err:
        raise _Echec(_prof_err[cle])
    try:
        return _geom_mesure(design, s, cle)
    except _Echec as ex:
        _prof_err[cle] = ex.code
        raise


def _geom_mesure(design, s, cle):
    es = _ents(design, s['c'])
    if len(es) < 2:
        raise _Echec('CHEMIN')
    face, edge = es[0], es[1]
    up = _vers_haut()
    fm = _face_monde(face)
    if fm is None:
        raise _Echec('CHEMIN')
    zf = _v_dot(fm[2], up)
    pts = _echantillonner(edge, 160)
    if not pts:
        raise _Echec('CHEMIN')
    top = max(pts, key=lambda p: _v_dot(p, up))
    zt = _v_dot(top, up)
    _log('geom : base %s zf=%.2f, arete du haut zt=%.2f (corps %s)' % (type(face).__name__, zf, zt, getattr(edge.body, 'name', '?')))
    if zt - zf < 2.0:
        raise _Echec('AXE')
    ply = edge.body
    ax = _AxeV(_v_sub(top, _v_mul(up, zt - zf)), top)
    ups = []
    for b in _corps_actifs(design):
        if _est_montant(b):
            u = _cadre_montant(design, b, ply, up)
            if u is not None:
                ups.append(u)
    if not ups:
        raise _Echec('MONT')
    mesures = []
    for u in ups:                       # dessus de la dalle sous le pied du montant (un tenon peut la traverser)
        q = _v_add(_v_add(u['F'], _v_mul(u['ar'], 0.3)), _v_mul(up, 0.05))
        if _dans(ply, q):
            ex = _sortie_corps(design, ply, q, up, 50.0)
            if ex is not None:
                mesures.append(_v_dot(q, up) + ex)
    # dossier et dalle en deux corps : l'arete est sur le dossier seul, rien a mesurer, la face choisie donne le dessus de la dalle
    zs = min(mesures) if mesures else zf
    _log('geom : dessus de la dalle zs=%.2f (%s)' % (zs, 'mesure' if mesures else 'face choisie'))
    ch = _chaine_dossier(design, ply, ups, up, zs)
    g = {'up': up, 'zf': zf, 'zt': zt, 'zs': zs, 'ax': ax, 'ply': ply, 'ch': ch, 'ups': ups, 'sg': 1.0}
    # sens vers l'arriere : celui des montants
    tot = 0.0
    for u in ups:
        f = ch.frac_point(u['F'])
        u['s'] = f * ch.longueur
        _p, a = _rep(g, u['s'])
        tot += _v_dot(a, u['ar'])
    g['sg'] = 1.0 if tot >= 0 else -1.0
    ups.sort(key=lambda u: u['s'])
    # hauteur du dossier le long de la courbe (au-dessus de la base)
    Ls = ch.longueur
    M = max(10, int(Ls / 1.0))
    ss, Hs = [], []
    for k in range(M + 1):
        s_ = Ls * k / M
        p, a = _rep(g, s_)
        q = _v_add(_v_sub(p, _v_mul(a, 0.3)), _v_mul(up, 0.3))
        h = 0.0
        if _dans(ply, q):
            ex = _sortie_corps(design, ply, q, up, 2000.0)
            if ex is not None:
                h = ex + 0.3
        ss.append(s_)
        Hs.append(h)
    g['ss'], g['Hs'] = ss, Hs
    if len(_prof_multi) > 12:
        _prof_multi.clear()
    _prof_multi[cle] = g
    return g


# --- Calcul des traverses ----------------------------------------------------------------------------------

def _positions(Lt, n, e, m1, m2):
    """Altitudes relatives (cm) des centres des traverses sur l'axe, entre les marges (mm) du bas et du haut."""
    x0 = m1 / 10.0 + e
    x1 = Lt - m2 / 10.0 - e
    if x1 < x0 - 1e-6:
        return [], (x0, x1)
    if n == 1:
        return [(x0 + x1) / 2.0], (x0, x1)
    sp = (x1 - x0) / (n - 1)
    return [x0 + i * sp for i in range(n)], (x0, x1)


def _etendue(ss, Hs, need):
    """Partie du dossier assez haute (>= need) : (debut, fin) en abscisse, autour du point le plus haut. None si aucune."""
    im = max(range(len(Hs)), key=lambda i: Hs[i])
    if Hs[im] < need:
        return None
    i = im
    while i > 0 and Hs[i - 1] >= need:
        i -= 1
    j = im
    while j < len(Hs) - 1 and Hs[j + 1] >= need:
        j += 1
    sa = ss[0]
    if i > 0:
        d = (Hs[i] - Hs[i - 1]) or 1.0
        sa = ss[i - 1] + (ss[i] - ss[i - 1]) * (need - Hs[i - 1]) / d
    sb = ss[-1]
    if j < len(Hs) - 1:
        d = (Hs[j] - Hs[j + 1]) or 1.0
        sb = ss[j + 1] - (ss[j + 1] - ss[j]) * (need - Hs[j + 1]) / d
    return sa, sb


def _pchip(xs, ys):
    """Interpolation cubique monotone (Fritsch-Carlson) : courbe lisse par les profondeurs des montants, prolongee
    en ligne droite au-dela des montants extremes (la courbe se poursuit jusqu'au bout du dossier)."""
    import bisect
    n = len(xs)
    if n == 1:
        return lambda x: ys[0]
    h = [xs[i + 1] - xs[i] for i in range(n - 1)]
    d = [(ys[i + 1] - ys[i]) / (h[i] or 1e-9) for i in range(n - 1)]
    m = [0.0] * n
    if n == 2:
        m = [d[0], d[0]]
    else:
        for i in range(1, n - 1):
            if d[i - 1] * d[i] > 0:
                w1, w2 = 2 * h[i] + h[i - 1], h[i] + 2 * h[i - 1]
                m[i] = (w1 + w2) / (w1 / d[i - 1] + w2 / d[i])

        def fin(h0, h1, d0, d1):
            v = ((2 * h0 + h1) * d0 - h0 * d1) / (h0 + h1)
            if v * d0 <= 0:
                return 0.0
            if d0 * d1 <= 0 and abs(v) > 3 * abs(d0):
                return 3 * d0
            return v
        m[0] = fin(h[0], h[1], d[0], d[1])
        m[-1] = fin(h[-1], h[-2], d[-1], d[-2])

    def f(x):
        if x <= xs[0]:
            return ys[0] + m[0] * (x - xs[0])
        if x >= xs[-1]:
            return ys[-1] + m[-1] * (x - xs[-1])
        i = max(0, min(n - 2, bisect.bisect_right(xs, x) - 1))
        t = (x - xs[i]) / h[i]
        return ((2 * t ** 3 - 3 * t ** 2 + 1) * ys[i] + (t ** 3 - 2 * t ** 2 + t) * h[i] * m[i]
                + (-2 * t ** 3 + 3 * t ** 2) * ys[i + 1] + (t ** 3 - t ** 2) * h[i] * m[i + 1])
    return f


def _spline_nat(xs, ys):
    """Spline cubique naturelle (C2) par les profondeurs des montants : courbe lisse, sans paliers ni bosses entre
    les montants, prolongee en ligne droite au-dela des montants extremes."""
    import bisect
    pts = sorted(zip(xs, ys))
    X, Y = [], []
    for x, y in pts:
        if X and x - X[-1] < 1e-3:
            Y[-1] = (Y[-1] + y) / 2.0
        else:
            X.append(x)
            Y.append(y)
    n = len(X)
    if n == 1:
        return lambda x: Y[0]
    if n == 2:
        k = (Y[1] - Y[0]) / (X[1] - X[0])
        return lambda x: Y[0] + k * (x - X[0])
    h = [X[i + 1] - X[i] for i in range(n - 1)]
    al = [0.0] * n
    for i in range(1, n - 1):
        al[i] = 3.0 * ((Y[i + 1] - Y[i]) / h[i] - (Y[i] - Y[i - 1]) / h[i - 1])
    l, mu, z = [1.0] * n, [0.0] * n, [0.0] * n
    for i in range(1, n - 1):
        l[i] = 2.0 * (X[i + 1] - X[i - 1]) - h[i - 1] * mu[i - 1]
        mu[i] = h[i] / l[i]
        z[i] = (al[i] - h[i - 1] * z[i - 1]) / l[i]
    c, b, d = [0.0] * n, [0.0] * (n - 1), [0.0] * (n - 1)
    for j in range(n - 2, -1, -1):
        c[j] = z[j] - mu[j] * c[j + 1]
        b[j] = (Y[j + 1] - Y[j]) / h[j] - h[j] * (c[j + 1] + 2.0 * c[j]) / 3.0
        d[j] = (c[j + 1] - c[j]) / (3.0 * h[j])
    kb = b[-1] + 2 * c[-2] * h[-1] + 3 * d[-1] * h[-1] ** 2

    def f(x):
        if x <= X[0]:
            return Y[0] + b[0] * (x - X[0])
        if x >= X[-1]:
            return Y[-1] + kb * (x - X[-1])
        i = max(0, min(n - 2, bisect.bisect_right(X, x) - 1))
        t = x - X[i]
        return Y[i] + b[i] * t + c[i] * t * t + d[i] * t ** 3
    return f


CV_MODES = ('aucune', 'auto', 'manuelle')


def _conge(s, Lg, D):
    """(A, B) cm : demi-axes du conge asymetrique (quart d'ellipse) de chaque bout, comme les montants :
    A le long de la traverse, B dans sa profondeur. (0, 0) si aucun conge."""
    m = s.get('cv_mode', 'aucune')
    if m == 'auto':
        A, B = Lg * s['cv_w'] / 100.0, D * s['cv_h'] / 100.0
    elif m == 'manuelle':
        A, B = s['cv_a'] / 10.0, s['cv_b'] / 10.0
    else:
        return 0.0, 0.0
    A, B = max(0.0, min(Lg / 2.0, A)), max(0.0, min(D, B))
    if A < 0.05 or B < 0.05:
        return 0.0, 0.0
    return A, B


def _coupe(t, A, B, D):
    """Profondeur maximale a la distance t du bout : l'ellipse du conge (centre en (A, D - B))."""
    if A <= 0.0 or t >= A:
        return 1e9
    u = (A - max(t, 0.0)) / A
    return (D - B) + B * (1.0 - u * u) ** 0.5


def _une_traverse(design, s, g, z, e, ep, exact):
    """Contour (plan) de la traverse centree a l'altitude z : longueur = dossier assez haut, profondeur = montants."""
    c = {'ok': False, 'msg': 'ERR', 'z': z, 'e': e}
    up, zs = g['up'], g['zs']
    run = _etendue(g['ss'], g['Hs'], z - e - zs)
    if run is None:
        c['msg'] = 'HAUT'
        return c
    r = s['retr'] / 10.0
    sa, sb = run[0] + r, run[1] - r
    if sb - sa < 1.0:
        c['msg'] = 'LONG'
        return c
    vals = []
    for u in g['ups']:
        w = _w_montant(design, u, z, e, exact)
        if w is not None:
            vals.append((u['s'], w, u))
    if s['prof_auto'] and not vals:
        c['msg'] = 'LARG'
        return c

    if s['prof_auto']:
        # profondeur constante = celle du montant du milieu (le plus proche du milieu de la traverse)
        mid = (sa + sb) / 2.0
        Wm = max(1.0, min(vals, key=lambda v: abs(v[0] - mid))[1])

    def base(sx):
        return Wm if s['prof_auto'] else s['prof_mm'] / 10.0
    Lg = sb - sa
    Da, Db = base(sa), base(sb)
    Aa, Ba = _conge(s, Lg, Da)
    Ab, Bb = _conge(s, Lg, Db)

    def prof(sx):
        return min(base(sx), _coupe(sx - sa, Aa, Ba, Da), _coupe(sb - sx, Ab, Bb, Db))
    m = max(8, int(Lg / (0.8 if exact else 1.5)) + 1)
    lift = _v_mul(up, z - zs)
    front, rear = [], []
    for k in range(m + 1):
        sx = sa + Lg * (1.0 - math.cos(math.pi * k / m)) / 2.0      # points plus serres aux bouts (conge)
        p, a = _rep(g, sx)
        d = prof(sx)
        f0 = _v_add(p, lift)
        front.append(f0)
        rear.append(_v_add(f0, _v_mul(a, d)))
    pairs = [(u, w) for (s_u, w, u) in vals if sa - 0.05 <= s_u <= sb + 0.05]
    c.update(ok=True, msg='OK', front=front, rear=rear, sa=sa, sb=sb, Lg=sb - sa, pairs=pairs,
             D=max(_d3(front[i], rear[i]) for i in range(len(front))),
             centre=tuple((front[len(front) // 2][k] + rear[len(rear) // 2][k]) / 2.0 for k in range(3)))
    return c


def _calc(design, s, ep, exact=False):
    """Calcul de toutes les traverses : dict 'ok', 'msg', 'inst' (une par traverse), 'L' (axe), 'poig'."""
    r = {'ok': False, 'msg': 'CHEMIN', 'inst': [], 'nok': 0, 'ntot': 0, 'L': 0.0}
    if not s['c']:
        return r
    try:
        g = _geom(design, s)
        Lt = g['ax'].longueur
        e = ep / 2.0
        xs, poig = _positions(Lt, int(s['n']), e, s['m1'], s['m2'])
        r.update(L=Lt, xs=xs, poig=poig, tr=g['ax'], g=g)
        if not xs:
            r['msg'] = 'HORS'
            return r
        insts = [_une_traverse(design, s, g, g['zf'] + x, e, ep, exact) for x in xs]
        if len(xs) > 1 and (xs[1] - xs[0]) < ep - 1e-4:
            for c in insts:
                if c['ok']:
                    c.update(ok=False, msg='CHEV')
        r.update(inst=insts, ntot=len(insts), nok=sum(1 for c in insts if c['ok']))
        r['ok'] = r['nok'] > 0
        r['msg'] = 'OK' if r['ok'] else insts[0]['msg']
    except _Echec as ex:
        r.update(ok=False, msg=ex.code)
    except Exception:
        _log('calc erreur ' + traceback.format_exc()[-500:])
        r.update(ok=False, msg='ERR')
    return r


MESSAGES = {
    'CHEMIN': "Selectionnez la face de la base, puis l'arete du haut du dossier.",
    'AXE': "L'arete du dossier doit etre au-dessus de la face de la base.",
    'DOSSIER': "Dossier introuvable : choisissez l'arete du haut du dossier.",
    'MONT': "Aucun montant trouve : creez d'abord les montants du dossier.",
    'HAUT': "Traverse plus haute que le dossier : changez les marges.",
    'LONG': "Dossier trop court a cette hauteur.",
    'LARG': "Aucun montant a cette hauteur : saisissez une profondeur.",
    'HORS': "Traverses hors de l'axe : reduisez les marges ou l'epaisseur.",
    'CHEV': "Traverses qui se chevauchent : reduisez le nombre.",
    'ERR': "Calcul impossible pour ces traverses."}


# --- Apercu 3D (CustomGraphics) ------------------------------------------------------------------------

_apercu = {'g': [], 'sig': None}


def _lignes_traverse(c):
    """Aretes (paires de points monde) de la traverse : contour haut et bas, aretes verticales."""
    up = _vers_haut()
    e = c['e']
    boucle = list(c['front']) + list(reversed(c['rear']))
    out = []
    for sg in (-e, e):
        d = _v_mul(up, sg)
        for i in range(len(boucle)):
            a, b = boucle[i], boucle[(i + 1) % len(boucle)]
            out += list(_v_add(a, d)) + list(_v_add(b, d))
    pas = max(1, len(boucle) // 10)
    for i in range(0, len(boucle), pas):
        out += list(_v_add(boucle[i], _v_mul(up, -e))) + list(_v_add(boucle[i], _v_mul(up, e)))
    return out


def _interp(xs, vs, x):
    """Valeur interpolee en x ; None si l'un des deux echantillons voisins manque."""
    if x <= xs[0]:
        return vs[0]
    if x >= xs[-1]:
        return vs[-1]
    lo, hi = 0, len(xs) - 1
    while hi - lo > 1:
        m = (lo + hi) // 2
        if xs[m] <= x:
            lo = m
        else:
            hi = m
    a, b = vs[lo], vs[hi]
    if a is None or b is None:
        return a if b is None else b
    u = (x - xs[lo]) / (xs[hi] - xs[lo])
    return a + (b - a) * u


def _apercu_effacer():
    for g in _apercu['g']:
        try:
            if g.isValid:
                g.deleteMe()
        except Exception:
            pass
    _apercu['g'] = []
    _apercu['sig'] = None
    _balayer(ID_APERCU)


def _apercu_maj(calc, force=False):
    """Un groupe orange (montants valides) et un groupe rouge (invalides), recrees quand la forme change ; le nouveau
    groupe est cree AVANT la suppression de l'ancien (jamais d'image vide)."""
    try:
        if calc is None:
            _apercu_effacer()
            return
        ok_l, ko_l = [], []
        for c in calc['inst']:
            if c.get('front'):
                (ok_l if c['ok'] else ko_l).extend(_lignes_traverse(c))
        sig = (tuple(round(v, 3) for v in ok_l), tuple(round(v, 3) for v in ko_l))
        ok = _apercu['sig'] == sig and not force
        if ok:
            try:
                ok = all(g.isValid for g in _apercu['g'])
            except Exception:
                ok = False
        if ok:
            return
        root = _design().rootComponent
        nouveaux = []
        for pts, col in ((ok_l, ORANGE), (ko_l, ROUGE)):
            if not pts:
                continue
            g = root.customGraphicsGroups.add()
            g.id = ID_APERCU
            ln = g.addLines(adsk.fusion.CustomGraphicsCoordinates.create(pts), [], False)
            ln.weight = 2
            ln.color = adsk.fusion.CustomGraphicsSolidColorEffect.create(adsk.core.Color.create(*col))
            ln.isSelectable = False
            nouveaux.append(g)
        anciens = _apercu['g']
        _apercu['g'] = nouveaux
        _apercu['sig'] = sig
        for g in anciens:
            try:
                if g.isValid:
                    g.deleteMe()
            except Exception:
                pass
    except Exception:
        _log('apercu erreur ' + traceback.format_exc()[-400:])


class _RedrawHandler(adsk.core.CustomEventHandler):
    """Redessin differe : un groupe cree PENDANT un clic de souris disparait (Fusion traite le clic ensuite)."""
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            if not _redraw['on']:
                return
            _ov['sig'] = None
            _ov_maj()
            _apercu_maj(_tous_calculs(), force=True)
            _rafraichir_vue()
        except Exception:
            _log('redraw erreur ' + traceback.format_exc()[-300:])


def _redessiner_differe():
    try:
        for essai in (0, 1):
            if _redraw['evt'] is None:
                try:
                    _app.unregisterCustomEvent(REDRAW_ID)
                except Exception:
                    pass
                _redraw['evt'] = _app.registerCustomEvent(REDRAW_ID)
                _redraw['h'] = _RedrawHandler()
                _redraw['evt'].add(_redraw['h'])
            if _app.fireCustomEvent(REDRAW_ID, ''):
                break
            _redraw['evt'] = None          # evenement mort (add-in relance depuis un script) : on le reenregistre
    except Exception:
        _log('redessiner differe : ' + traceback.format_exc()[-200:])


# --- Fenetre « MONTANTS » en bas a gauche (modele : ReseauTrajectoireCNC) -------------------------------------

OV_W, OV_H = 468, 28
OV_GAP = 6                        # espace entre deux fenetres (une par dossier)
OV_X, OV_Y = 16, 60
OV_M0, OV_M1 = 74, 96            # bouton moins
OV_B0, OV_B1 = 102, 262          # barre de quantite
OV_P0, OV_P1 = 268, 290          # bouton plus
OV_S0, OV_S1 = 338, 366          # symetrie
OV_E0, OV_E1 = 372, 400          # jusqu'au bout
OV_T0, OV_T1 = 406, 434          # enfourchement (Entaille CNC)
OV_EXP = 1.6                     # barre non lineaire : 1 a 20 sur les 3 premiers quarts, puis jusqu'au maximum
_ov = {'g': None, 'sig': None, 'on': None, 'row': 0}
_tip = {'g': None, 'cle': None}


def _q_de_t(t, qm=NB_MAX):
    t = max(0.0, min(1.0, t))
    if t <= 0.75:
        q = 1 + 19.0 * t / 0.75
    else:
        q = 20 + (max(qm, 21) - 20) * (((t - 0.75) / 0.25) ** OV_EXP)
    return max(1, min(qm, int(round(q))))


def _t_de_q(q, qm=NB_MAX):
    qm = max(21, qm)
    if q <= 20:
        return 0.75 * (max(1, q) - 1) / 19.0
    return 0.75 + 0.25 * (min(1.0, (q - 20) / float(qm - 20)) ** (1.0 / OV_EXP))


def _ecrire_png(cle, px, w, h):
    import zlib, struct, tempfile
    raw = bytearray()
    for y in range(h):
        raw.append(0)
        for x in range(w):
            raw += bytes(px[y][x])

    def chunk(tt, dd):
        c = struct.pack('>I', len(dd)) + tt + dd
        return c + struct.pack('>I', zlib.crc32(tt + dd) & 0xffffffff)

    png = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 6, 0, 0, 0)) + \
        chunk(b'IDAT', zlib.compress(bytes(raw))) + chunk(b'IEND', b'')
    chemin = os.path.join(tempfile.gettempdir(), 'traverses_dossier_cnc_%s.png' % cle)
    with open(chemin, 'wb') as f:
        f.write(png)
    _png_cache[cle] = chemin
    return chemin


def _dpr():
    """Fusion dessine les images des graphiques colles a la vue agrandies du facteur d'echelle de l'ecran."""
    if 'k' not in _dpr_cache:
        k = 1.0
        try:
            import ctypes
            k = max(1.0, ctypes.windll.user32.GetDpiForSystem() / 96.0)
        except Exception:
            pass
        _dpr_cache['k'] = k
    return _dpr_cache['k']


def _texte_px(px, txt, x0, y0, couleur):
    """Capitales sans accent, police 3x5 agrandie x2, pas de 8 px."""
    import unicodedata
    txt = ''.join(c for c in unicodedata.normalize('NFD', txt) if unicodedata.category(c) != 'Mn').upper()
    for n, c in enumerate(txt):
        g = _GLYPHES.get(c, _GLYPHES[' '])
        for gy in range(5):
            for gx in range(3):
                if g[gy * 3 + gx] == '1':
                    for dy in range(2):
                        for dx in range(2):
                            xx, yy = x0 + n * 8 + gx * 2 + dx, y0 + gy * 2 + dy
                            if 0 <= yy < len(px) and 0 <= xx < len(px[0]):
                                px[yy][xx] = couleur


def _png_ligne(q, t, sym, fin, enf=True, actif=True, num=0):
    """Ligne « TRAVERSE » : nom, - barre +, quantite, symetrie, jusqu'au bout, enfourchement. Active (cadre bleu)."""
    nom = _tt('TRAVERSE')
    cle = 'l4_%d_%d_%d_%d_%d_%s_%d_%d' % (q, int(t * 1000), sym, fin, enf, nom, actif, num)
    if cle in _png_cache and os.path.isfile(_png_cache[cle]):
        return _png_cache[cle]
    w, h = OV_W, OV_H
    BLEU = (20, 130, 215, 255)
    cadre = BLEU if actif else (95, 95, 95, 255)
    px = [[(40, 40, 40, 255) if actif else (32, 32, 32, 255)] * w for _ in range(h)]
    for x in range(w):
        for y in (0, 1, h - 1, h - 2):
            px[y][x] = cadre
    for y in range(h):
        for x in (0, 1, w - 1, w - 2):
            px[y][x] = cadre
    if num:
        _texte_px(px, str(num), OV_T1 + 10, (h - 10) // 2, (255, 200, 60, 255) if actif else (150, 150, 150, 255))
    yc = h // 2
    _texte_px(px, nom, 8, (h - 10) // 2, (235, 235, 235, 255))
    _texte_px(px, str(q), OV_P1 + 8, (h - 10) // 2, (255, 200, 60, 255))

    def bouton(x0, x1, actif):
        fond = (110, 55, 0, 255) if actif else (62, 62, 62, 255)
        bord = (255, 170, 60, 255) if actif else (125, 125, 125, 255)
        for x in range(x0, x1):
            for y in range(yc - 11, yc + 11):
                px[y][x] = bord if (x in (x0, x1 - 1) or y in (yc - 11, yc + 10)) else fond
        return (255, 140, 0, 255) if actif else (150, 150, 150, 255), (255, 225, 175, 255) if actif else (190, 190, 190, 255)

    plein, clair = bouton(OV_M0, OV_M1, False)
    xm = (OV_M0 + OV_M1) // 2
    for x in range(xm - 5, xm + 5):
        for y in (yc - 1, yc):
            px[y][x] = clair
    plein, clair = bouton(OV_P0, OV_P1, False)
    xp = (OV_P0 + OV_P1) // 2
    for x in range(xp - 5, xp + 5):
        for y in (yc - 1, yc):
            px[y][x] = clair
    for y in range(yc - 5, yc + 5):
        for x in (xp - 1, xp):
            px[y][x] = clair
    # symetrie : deux triangles en miroir
    plein, clair = bouton(OV_S0, OV_S1, sym)
    cx, ht = (OV_S0 + OV_S1) // 2, 15
    for r in range(ht):
        wd = 1 + (r * 8) // (ht - 1)
        y = yc - 7 + r
        for dx in range(1, wd + 1):
            px[y][cx + dx] = plein
            if dx == wd or dx == 1 or r == ht - 1:
                px[y][cx - dx] = clair
    # jusqu'au bout : fleche vers une barre
    plein, clair = bouton(OV_E0, OV_E1, fin)
    x_a, x_b = OV_E0 + 6, OV_E1 - 8
    for x in range(x_a, x_b):
        for y in (yc - 1, yc):
            px[y][x] = plein
    for k in range(6):
        for y in range(yc - 5 + k, yc + 5 - k + 1):
            if 0 <= y < h:
                px[y][x_b - 6 + k + 1 + 2] = plein
    for y in range(yc - 6, yc + 7):
        for x in (OV_E1 - 7, OV_E1 - 6):
            px[y][x] = clair
    # enfourchement : une traverse et un montant qui se croisent (mi-bois)
    plein, clair = bouton(OV_T0, OV_T1, enf)
    xh = (OV_T0 + OV_T1) // 2
    for x in range(xh - 9, xh + 10):
        for y in (yc - 3, yc + 2):
            px[y][x] = clair                                  # traverse (horizontale)
    for y in range(yc - 9, yc + 10):
        for x in (xh - 3, xh + 2):
            px[y][x] = clair                                  # montant (vertical)
    for x in range(xh - 2, xh + 2):
        for y in range(yc - 2, yc + 2):
            px[y][x] = plein                                  # croisement
    # barre de quantite
    kx = OV_B0 + int(round(t * (OV_B1 - OV_B0)))
    for x in range(OV_B0, OV_B1 + 1):
        for y in (yc - 1, yc, yc + 1):
            px[y][x] = BLEU if x <= kx else (150, 150, 150, 255)
    for x in range(kx - 3, kx + 4):
        for y in range(yc - 9, yc + 9):
            px[y][x] = (255, 255, 255, 255) if (x in (kx - 3, kx + 3) or y in (yc - 9, yc + 8)) else BLEU
    return _ecrire_png(cle, px, w, h)


def _png_info(txt):
    """Infobulle claire, comme les bulles natives de Fusion."""
    cle = 'tip_%s' % abs(hash(txt))
    w = len(txt) * 8 + 12
    h = 24
    if cle in _png_cache and os.path.isfile(_png_cache[cle]):
        return _png_cache[cle], w, h
    px = [[(246, 246, 246, 255)] * w for _ in range(h)]
    for x in range(w):
        for y in (0, h - 1):
            px[y][x] = (110, 110, 110, 255)
    for y in range(h):
        for x in (0, w - 1):
            px[y][x] = (110, 110, 110, 255)
    _texte_px(px, txt, 6, 7, (20, 20, 20, 255))
    return _ecrire_png(cle, px, w, h), w, h


def _vp_larg():
    try:
        v = _app.activeViewport
        return (int(v.width), int(v.height))
    except Exception:
        return None


def _est_fin(s=None):
    s = _s if s is None else s
    return s['m1'] < 0.05 and s['m2'] < 0.05


def _ov_etat(s=None):
    s = _s if s is None else s
    return (int(s['n']), _t_de_q(int(s['n'])), bool(s['sym']), _est_fin(s), bool(s['entaille']))


def _lignes_jeux():
    """Les jeux dessines : un par dossier (ou le modele seul tant que rien n'est choisi)."""
    return list(_jeux) if _jeux else ([_s] if _s.get('c') else [])


def _ov_y(r):
    return OV_Y + r * (OV_H * _dpr() + OV_GAP)


def _ov_effacer():
    g = _ov['g']
    _ov['g'] = None
    _ov['sig'] = None
    _tip_effacer()
    try:
        if g is not None and g.isValid:
            g.deleteMe()
    except Exception:
        pass


def _ov_maj():
    """Dessine (ou met a jour) les fenetres « TRAVERSE » (une par dossier ; composant actif : sinon elles sont grisees)."""
    try:
        jx = _lignes_jeux()
        if not jx:
            _ov_effacer()
            return
        sts = [_ov_etat(j) for j in jx]
        ia = _act['i'] if _jeux else 0
        sig = (tuple(sts), ia, _vp_larg(), _tt('TRAVERSE'))
        if sig == _ov['sig'] and _ov['g'] is not None and _ov['g'].isValid:
            return
        _ov_effacer()
        design = _design()
        g = design.activeComponent.customGraphicsGroups.add()
        k = _dpr()
        multi = len(jx) > 1
        for r, st in enumerate(sts):
            png = _png_ligne(st[0], st[1], st[2], st[3], st[4], r == ia, (r + 1) if multi else 0)
            ps = g.addPointSet(adsk.fusion.CustomGraphicsCoordinates.create([0.0, 0.0, 0.0]), [0],
                               adsk.fusion.CustomGraphicsPointTypes.UserDefinedCustomGraphicsPointType, png)
            ps.isSelectable = False
            ps.viewPlacement = adsk.fusion.CustomGraphicsViewPlacement.create(
                adsk.core.Point3D.create(0, 0, 0), adsk.fusion.ViewCorners.lowerLeftViewCorner,
                adsk.core.Point2D.create(OV_X + OV_W * k / 2.0, _ov_y(r) + OV_H * k / 2.0))
            _dv_poser(ps)
        _ov['g'] = g
        _ov['sig'] = sig
    except Exception:
        _log('overlay erreur ' + traceback.format_exc()[-400:])


def _ov_assurer():
    """Fenetre effacee par un cycle Fusion : redessinee aussitot."""
    try:
        ok = _ov['g'] is not None and _ov['g'].isValid
    except Exception:
        ok = False
    if not ok and _lignes_jeux():
        _ov['sig'] = None
        _ov_maj()


def _ov_zone(vp, pos):
    """Zone de la fenetre sous le curseur : 'moins', 'plus', 'barre', 'sym', 'fin', 'enf', 'ligne' ou None."""
    nb = len(_lignes_jeux())
    if _ov['g'] is None or not nb:
        return None
    k = _dpr()
    h = vp.height * k
    r = int(round((h - pos.y - _ov_y(0) - OV_H * k / 2.0) / (OV_H * k + OV_GAP)))
    if r < 0 or r >= nb:
        return None
    yc = h - (_ov_y(r) + OV_H * k / 2.0)
    if abs(pos.y - yc) > OV_H * k / 2.0:
        return None
    _ov['row'] = r
    x = (pos.x - OV_X) / k
    if x < 0 or x > OV_W:
        return None
    if OV_M0 <= x <= OV_M1:
        return 'moins'
    if OV_P0 <= x <= OV_P1:
        return 'plus'
    if OV_B0 - 6 <= x <= OV_B1 + 6:
        return 'barre'
    if OV_S0 <= x <= OV_S1:
        return 'sym'
    if OV_E0 <= x <= OV_E1:
        return 'fin'
    if OV_T0 <= x <= OV_T1:
        return 'enf'
    return 'ligne'


def _tip_effacer():
    g = _tip['g']
    _tip['g'] = None
    _tip['cle'] = None
    try:
        if g is not None and g.isValid:
            g.deleteMe()
            _rafraichir_vue()
    except Exception:
        pass


def _texte_aide(zone):
    return {'moins': "Une traverse de moins", 'plus': "Une traverse de plus",
            'sym': "Symetrie : memes marges en bas et en haut",
            'fin': "Jusqu'au bout de l'axe",
            'enf': ("Enfourchement avec les montants : actif - clic : desactiver" if (_lignes_jeux()[_ov['row']] if _ov['row'] < len(_lignes_jeux()) else _s)['entaille']
                    else "Enfourchement avec les montants : inactif - clic : activer")}.get(zone)


_ZONE_X = {'moins': OV_M0, 'plus': OV_P0, 'sym': OV_S0, 'fin': OV_E0, 'enf': OV_T0}


def _tip_maj(vp, pos):
    """Infobulle (graphique colle a la vue) a droite de la ligne, au survol d'une icone."""
    z = _ov_zone(vp, pos) if _ov['g'] is not None else None
    txt = _texte_aide(z) if z in _ZONE_X else None
    cle = None if txt is None else (z, txt)
    if cle == _tip['cle'] and (cle is None or (_tip['g'] is not None and _tip['g'].isValid)):
        return
    _tip_effacer()
    if txt is None:
        return
    design = _design()
    png, w, h = _png_info(_tt(txt))
    g = design.activeComponent.customGraphicsGroups.add()
    k = _dpr()
    gauche = OV_X + (OV_W + 8) * k
    haut = _ov_y(_ov['row']) + (OV_H * k - h * k) / 2.0 - 8
    ps = g.addPointSet(adsk.fusion.CustomGraphicsCoordinates.create([0.0, 0.0, 0.0]), [0],
                       adsk.fusion.CustomGraphicsPointTypes.UserDefinedCustomGraphicsPointType, png)
    ps.isSelectable = False
    ps.viewPlacement = adsk.fusion.CustomGraphicsViewPlacement.create(
        adsk.core.Point3D.create(0, 0, 0), adsk.fusion.ViewCorners.lowerLeftViewCorner,
        adsk.core.Point2D.create(gauche + w * k / 2.0, haut + 8 + h * k / 2.0))
    _dv_poser(ps)
    _tip['g'] = g
    _tip['cle'] = cle
    _rafraichir_vue()


# --- Poignees (pastilles) : marges du debut et de la fin, quantite au centre ---------------------------------

def _poignees():
    """[(k, trajet, fraction)] : 1 = premier montant (marge du debut), 2 = dernier montant (marge de la fin)."""
    if not _s['c']:
        return []
    tr = _geom(_design(), _s)['ax']
    Lt = tr.longueur
    xs, (a, b) = _positions(Lt, int(_s['n']), _cur['ep'] / 2.0, _s['m1'], _s['m2'])
    return [(1, tr, max(0.0, min(1.0, a / Lt))), (2, tr, max(0.0, min(1.0, b / Lt)))]


def _poignee_set(k, f, tr):
    """La pastille k est amenee a la fraction f du chemin : marge correspondante (la symetrie lie les deux marges)."""
    Lt = tr.longueur
    x = f * Lt
    e = _cur['ep'] / 2.0
    if k == 1:
        m = round(max(0.0, min(x - e, Lt - 2.0 * e - (0.0 if _s['sym'] else _s['m2'] / 10.0))) * 10.0, 1)
        _s['m1'] = m
        if _s['sym']:
            _s['m2'] = m
    else:
        m = round(max(0.0, min(Lt - x - e, Lt - 2.0 * e - (0.0 if _s['sym'] else _s['m1'] / 10.0))) * 10.0, 1)
        _s['m2'] = m
        if _s['sym']:
            _s['m1'] = m
    if _s['sym']:                                    # les deux marges egales ne doivent pas se croiser
        _s['m1'] = _s['m2'] = min(_s['m1'], max(0.0, (Lt - 2.0 * e) * 5.0 - 0.1))


def _qp_pos():
    if _caf is None or not _s['c']:
        return None
    hs = _poignees()
    if not hs:
        return None
    tr = hs[0][1]
    fs = [h[2] for h in hs]
    f = sum(fs) / len(fs)
    if abs(fs[-1] - fs[0]) < 0.04:
        f = fs[0] + (0.08 if fs[0] < 0.5 else -0.08)
    return tr, max(0.0, min(1.0, f))


def _maj_pastilles():
    """Pastilles orange des bouts et pastille bleue de quantite (recreees si Fusion les a annulees)."""
    if _caf is None:
        return
    try:
        hs = _poignees()
    except Exception:
        _log('pastilles : ' + traceback.format_exc()[-200:])
        hs = []
    qp = None
    try:
        qp = _qp_pos()
    except Exception:
        pass
    ks = set(h[0] for h in hs)
    if qp is not None:
        ks.add(0)
    for k in list(_pastilles):
        if k not in ks:
            g = _pastilles.pop(k, None)
            if g is not None:
                g.effacer()
    for k, tr, f in hs:
        try:
            g = _pastilles.get(k)
            if g is None:
                g = _pastilles[k] = _caf.Poignee(ID_PASTILLE % k)
                _camera_suivre(True)
            g.placer(tr.at(f)[0])
        except Exception:
            _log('pastille %d : %s' % (k, traceback.format_exc()[-200:]))
    if qp is not None and not _qd.get('on'):
        try:
            g = _pastilles.get(0)
            if g is None:
                g = _pastilles[0] = _caf.Poignee(ID_PASTILLE % 0, 'quantite')
                _camera_suivre(True)
            g.placer(qp[0].at(qp[1])[0])
        except Exception:
            _log('pastille quantite : ' + traceback.format_exc()[-200:])


def _pastille_touchee(vp, pos):
    """Numero de la pastille attrapee : sur la pastille, sinon sur le chemin (saut au point clique, vers la plus
    proche des deux pastilles des bouts)."""
    if not _s['c']:
        return None, None
    r = 14.0 * _dpr()
    hs = _poignees()
    best = None
    for k, tr, f in hs:
        q = vp.modelToViewSpace(adsk.core.Point3D.create(*tr.at(f)[0]))
        d = math.hypot(q.x - pos.x, q.y - pos.y)
        if d <= r and (best is None or d < best[0]):
            best = (d, k)
    if best is not None:
        return best[1], None
    if hs:
        tr = hs[0][1]
        ecr = _ecran(tr, vp)
        for j in range(len(ecr) - 1):
            ax, ay = ecr[j]
            ex, ey = ecr[j + 1][0] - ax, ecr[j + 1][1] - ay
            e2 = ex * ex + ey * ey
            u = 0.0 if e2 < 1e-12 else max(0.0, min(1.0, ((pos.x - ax) * ex + (pos.y - ay) * ey) / e2))
            d = math.hypot(ax + u * ex - pos.x, ay + u * ey - pos.y)
            if d <= r * 0.75 and (best is None or d < best[0]):
                fc = (tr.cum[j] + u * (tr.cum[j + 1] - tr.cum[j])) / tr.longueur
                kk = min(hs, key=lambda h: abs(h[2] - fc))[0]
                best = (d, kk, fc)
    return (best[1], best[2]) if best is not None else (None, None)


def _qd_debut(ins, vp, pos):
    g = _pastilles.get(0)
    if g is None or g.p is None:
        return False
    q = vp.modelToViewSpace(adsk.core.Point3D.create(*g.p))
    if math.hypot(q.x - pos.x, q.y - pos.y) > 14.0 * _dpr():
        return False
    qp = _qp_pos()
    if qp is None:
        return False
    tr, fm = qp
    p, tg = tr.at(fm)
    sens = 1.0
    try:                               # droite de l'ecran = plus de montants, quel que soit le sens du chemin
        a = vp.modelToViewSpace(adsk.core.Point3D.create(*p))
        b = vp.modelToViewSpace(adsk.core.Point3D.create(*_v_add(p, _v_mul(tg, tr.longueur * 0.01))))
        if b.x - a.x < 0:
            sens = -1.0
    except Exception:
        pass
    _cur['ep'] = _ep_cm(ins)
    _qd.clear()
    _qd.update(on=True, tr=tr, fm=fm, sens=sens, t0=_t_de_q(int(_s['n'])), tm=0.0)
    _souris.update(pos=pos, vp=vp, t=time.perf_counter())
    return True


def _qd_glisser(vp):
    t0 = time.perf_counter()
    if not _qd.get('on') or t0 - _qd.get('tm', 0.0) < 0.012:
        return
    _qd['tm'] = t0
    try:
        tr = _qd['tr']
        f = _frac_souris(tr, vp, _souris['pos'])
        q = _q_de_t(_qd['t0'] + _qd['sens'] * (f - _qd['fm']) / 0.5)
        g = _pastilles.get(0)
        if g is not None:
            g.placer(tr.at(f)[0])
        if q != int(_s['n']):
            _s['n'] = q
            _rafraichir_rapide()
        vp.refresh()
    except Exception:
        _log('poignee quantite : ' + traceback.format_exc()[-300:])


def _qd_fin(ins):
    _qd['on'] = False
    _sel_rendre(ins)
    _qd.pop('tr', None)
    _bloc['t'] = time.time()
    _appliquer(lambda: _sync_champs(ins), ins, True)
    _redessiner_differe()


def _glisser_souris(vp):
    """Pendant le glisser d'une pastille, l'aperçu suit la SOURIS (aucun cycle de calcul de Fusion)."""
    t0 = time.perf_counter()
    if _en_cours['v'] or t0 - _drag.get('tm', 0.0) < 0.008:
        return
    _drag['tm'] = t0
    k = _drag['k']
    hs = _poignees()
    tr = next((h[1] for h in hs if h[0] == k), None)
    if tr is None:
        return
    _poignee_set(k, _frac_souris(tr, vp, _souris['pos']), tr)
    _rafraichir_rapide()
    for kk, trk, fk in _poignees():
        g = _pastilles.get(kk)
        if g is not None:
            g.placer(trk.at(fk)[0])
    q = _qp_pos()
    g0 = _pastilles.get(0)
    if q is not None and g0 is not None:
        g0.placer(q[0].at(q[1])[0])
    vp.refresh()


def _clic_simple(pos):
    pd = _drag.get('pd')
    if pd is None or pos is None:
        return False
    return time.perf_counter() - _drag.get('td', 0.0) < 0.4 and math.hypot(pos.x - pd[0], pos.y - pd[1]) < 5.0 * _dpr()


def _sel_figer(ins):
    """Debut du glisser d'une poignee : pas de rectangle de selection de Fusion (meme technique que Traverse CNC :
    champs remplis declares pleins, champ actif sans focus s'il n'a pas exactement 1 element)."""
    if _caf is None:
        return
    avant = _en_cours['v']
    _en_cours['v'] = True
    try:
        _sel_fig['e'] = _caf.selections_figer(ins, 'glisser')
    except Exception:
        _sel_fig['e'] = None
    finally:
        _en_cours['v'] = avant


def _sel_rendre(ins):
    etat, _sel_fig['e'] = _sel_fig['e'], None
    if _caf is None or etat is None:
        return
    avant = _en_cours['v']
    _en_cours['v'] = True
    try:
        _caf.selections_rendre(etat)
    except Exception:
        pass
    finally:
        _en_cours['v'] = avant


def _fin_maison(ins):
    _drag['k'] = None
    _sel_rendre(ins)
    if _drag.get('maison'):
        _drag['maison'] = False
        _drag['pris'] = False
        _bloc['t'] = time.time()
    _appliquer(lambda: _sync_champs(ins), ins, True)
    _redessiner_differe()


# --- Selection ------------------------------------------------------------------------------------------

def _selections(sel):
    return [sel.selection(i).entity for i in range(sel.selectionCount)]


def _bloquer_selection(inputs):
    _bloc['t'] = time.time()
    _bloc['sel'] = {iid: [e.entityToken for e in _selections(inputs.itemById(iid))] for iid in SEL_IDS}


def _restaurer_selection(inputs, iid):
    """Un clic sur une fenetre ne doit rien selectionner derriere : on remet la selection d'avant."""
    if _bloc['sel'] is None or (time.time() - _bloc['t'] > 1.0 and not _drag.get('maison') and not _qd.get('on')):
        return False
    design = _design()
    for k in SEL_IDS:
        sel = inputs.itemById(k)
        voulus = _bloc['sel'].get(k, [])
        if [e.entityToken for e in _selections(sel)] == voulus:
            continue
        sel.clearSelection()
        for e in _ents(design, voulus):
            sel.addSelection(e)
    return True


def _charger_selection(inputs):
    design = _design()
    jx = _jeux or [_s]
    for ii, iid in enumerate(SEL_IDS):
        sel = inputs.itemById(iid)
        sel.clearSelection()
        for j in jx:
            if ii >= len(j['c']):
                continue
            tok = j['c'][ii]
            e = None
            try:
                _cache_ent.pop(tok, None)
                r = design.findEntityByToken(tok)
                e = r[0] if r else None
            except Exception:
                _log('charger %s : erreur %s' % (iid, traceback.format_exc()[-200:]))
            if iid == 'face' and e is not None:
                _modes['esq'] = isinstance(e, adsk.fusion.Profile)
            ok = None
            if e is not None:
                try:
                    ok = sel.addSelection(e)
                except Exception:
                    _log('charger %s : addSelection erreur %s' % (iid, traceback.format_exc()[-200:]))
            _log('charger %s : %s, ajout %s, selection %d' % (
                iid, type(e).__name__ if e is not None else 'INTROUVABLE', ok, sel.selectionCount))


def _centre_ent(e):
    try:
        if isinstance(e, adsk.fusion.Profile):
            return e.areaProperties().centroid
        if isinstance(e, adsk.fusion.BRepFace):
            return e.centroid
        if isinstance(e, adsk.fusion.BRepEdge):
            return e.pointOnEdge
    except Exception:
        pass
    return None


def _corps_de(e):
    try:
        return e.body.entityToken
    except Exception:
        return None


def _apparier(faces, aretes):
    """[(jeton face, jeton arete)] : chaque arete prend la face de son corps, sinon la face la plus proche."""
    paires = []
    for a in aretes:
        cand = [f for f in faces if _corps_de(f) is not None and _corps_de(f) == _corps_de(a)]
        if not cand:
            cand = list(faces)
        if not cand:
            continue
        if len(cand) > 1:
            pa = _centre_ent(a)
            if pa is not None:
                def dist(f):
                    pf = _centre_ent(f)
                    return 1e18 if pf is None else (pf.x - pa.x) ** 2 + (pf.y - pa.y) ** 2 + (pf.z - pa.z) ** 2
                cand.sort(key=dist)
        paires.append((cand[0].entityToken, a.entityToken))
    return paires


def _copie_jeu(src, c):
    j = dict(src)
    j['c'] = list(c)
    return j


def _lire_selection(inputs):
    """Un jeu de reglages par dossier (face + arete) : les jeux existants gardent leurs reglages, un nouveau dossier
    recoit une copie des reglages du jeu actif (et devient le jeu actif)."""
    global _s
    faces = _selections(inputs.itemById('face'))
    aretes = _selections(inputs.itemById('arete'))
    paires = _apparier(faces, aretes)
    nouveaux, ajoutes = [], []
    for ft, at in paires:
        c = [ft, at]
        j = next((x for x in _jeux if list(x['c']) == c), None)
        if j is None:
            j = next((x for x in nouveaux if list(x['c']) == c), None)
        if j is None:
            if not _jeux and not nouveaux and not _s.get('c'):
                j = _s                                   # le modele devient le premier jeu
                j['c'] = c
            else:
                j = _copie_jeu(_s, c)
            ajoutes.append(j)
        if all(j is not x for x in nouveaux):
            nouveaux.append(j)
    ancien = _s
    _jeux[:] = nouveaux
    _prof_inv()
    if not nouveaux:
        _s = _copie_jeu(ancien, [])
        _act['i'] = 0
        return
    if ajoutes:
        i = next(k for k, x in enumerate(nouveaux) if x is ajoutes[-1])
    else:
        i = next((k for k, x in enumerate(nouveaux) if x is ancien), 0)
    _act['i'] = i
    _s = nouveaux[i]


def _activer(i, inputs):
    """La fenetre cliquee devient la fenetre active : les champs de la boite montrent ses reglages."""
    global _s
    if not _jeux or i == _act['i'] or not (0 <= i < len(_jeux)):
        return
    _act['i'] = i
    _s = _jeux[i]
    _appliquer(lambda: _sync_champs(inputs), inputs, True)


# --- Rafraichissement -----------------------------------------------------------------------------------

def _resume(c):
    if not c['ok']:
        return _tt(MESSAGES.get(c['msg'], MESSAGES['ERR']))
    ls = [int(round(i['Lg'] * 10)) for i in c['inst'] if i['ok']]
    ds = [int(round(i['D'] * 10)) for i in c['inst'] if i['ok']]
    txt = _tt('Traverses : {0} sur {1}, longueur {2} mm, profondeur {3} mm.')
    rng = lambda v: str(min(v)) if min(v) == max(v) else '%d-%d' % (min(v), max(v))
    txt = txt.replace('{0}', str(c['nok'])).replace('{1}', str(c['ntot'])).replace('{2}', rng(ls)).replace('{3}', rng(ds))
    if c['nok'] < c['ntot']:
        bad = next(i for i in c['inst'] if not i['ok'])
        txt += ' ' + _tt(MESSAGES.get(bad['msg'], MESSAGES['ERR']))
    return txt


def _tous_calculs():
    """Calcul de tous les dossiers reunis (aperçu) ; None si rien a montrer."""
    cs = _cur.get('calcs') or []
    if not cs:
        return _cur['calc']
    return {'inst': [i for c in cs for i in c['inst']]}


def _rafraichir(inputs, poignees=False):
    design = _design()
    ep = _ep_cm(inputs)
    _cur['ep'] = ep
    jx = list(_jeux) if _jeux else [_s]
    cs = [_calc(design, j, ep) for j in jx]
    ia = _act['i'] if _jeux else 0
    c = cs[ia]
    _cur['calcs'] = cs
    _cur['calc'] = c
    txt = _resume(c)
    if len(jx) > 1:
        txt = _tt('Dossier {0} sur {1} : ').replace('{0}', str(ia + 1)).replace('{1}', str(len(jx))) + txt
        mauvais = [str(k + 1) for k, x in enumerate(cs) if not x['ok']]
        if mauvais:
            txt += ' ' + _tt('Dossiers invalides : {0}.').replace('{0}', ', '.join(mauvais))
    inputs.itemById('msg').text = txt
    if poignees:
        _maj_pastilles()
    _ov_maj()
    _apercu_maj(_tous_calculs())
    _rafraichir_vue()


def _rafraichir_rapide():
    """Pendant un glisser : calcul (profil interpole), aperçu et fenetre, rien d'autre."""
    c = _calc(_design(), _s, _cur['ep'])
    _cur['calc'] = c
    cs = _cur.get('calcs')
    if cs and _jeux and 0 <= _act['i'] < len(cs):
        cs[_act['i']] = c
    _apercu_maj(_tous_calculs())
    _ov_maj()
    _ov_assurer()


def _appliquer(fn, inputs, poignees=False):
    """Ecritures de champs sous garde (leurs evenements sont ignores), puis rafraichissement."""
    _en_cours['v'] = True
    try:
        fn()
        _rafraichir(inputs, poignees)
    finally:
        _en_cours['v'] = False


def _sync_champs(inputs):
    """Les champs de la boite suivent les reglages (modifies par la fenetre, les pastilles ou l'historique)."""
    inputs.itemById('nb').value = int(_s['n'])
    inputs.itemById('mode_crea').listItems.item(0 if _s.get('param', True) else 1).isSelected = True
    inputs.itemById('m1').value = _s['m1'] / 10.0
    inputs.itemById('m2').value = _s['m2'] / 10.0
    inputs.itemById('sym').value = bool(_s['sym'])
    inputs.itemById('retr').value = _s['retr'] / 10.0
    inputs.itemById('prof_auto').value = bool(_s['prof_auto'])
    inputs.itemById('prof').value = _s['prof_mm'] / 10.0
    inputs.itemById('prof').isEnabled = not _s['prof_auto']
    inputs.itemById('entaille').value = bool(_s['entaille'])
    inputs.itemById('marge_auto').value = bool(_s['marge_auto'])
    inputs.itemById('esq').value = bool(_modes['esq'])
    inputs.itemById('marge_auto').isEnabled = bool(_s['entaille'])
    inputs.itemById('cv_mode').listItems.item(CV_MODES.index(_s['cv_mode'])).isSelected = True
    inputs.itemById('cv_w').value = _s['cv_w']
    inputs.itemById('cv_h').value = _s['cv_h']
    inputs.itemById('cv_a').value = _s['cv_a'] / 10.0
    inputs.itemById('cv_b').value = _s['cv_b'] / 10.0
    auto, man = _s['cv_mode'] == 'auto', _s['cv_mode'] == 'manuelle'
    inputs.itemById('cv_w').isVisible = auto
    inputs.itemById('cv_h').isVisible = auto
    inputs.itemById('cv_a').isVisible = man
    inputs.itemById('cv_b').isVisible = man


def _rebloquer(inputs):
    try:
        _bloquer_selection(inputs)
    except Exception:
        pass


# --- Actions de la fenetre ------------------------------------------------------------------------------

def _set_n(inputs, n):
    n = max(1, min(NB_MAX, int(n)))
    if n == int(_s['n']):
        return
    _s['n'] = n
    _appliquer(lambda: _sync_champs(inputs), inputs, True)
    _rebloquer(inputs)


def _bascule_sym(inputs):
    _s['sym'] = not _s['sym']
    if _s['sym']:
        _s['m2'] = _s['m1']

    _appliquer(lambda: _sync_champs(inputs), inputs, True)
    _rebloquer(inputs)


def _bascule_fin(inputs):
    """Jusqu'au bout du chemin : marges a zero ; un second clic remet les marges d'avant."""
    if _est_fin():
        m = _s.get('fin_m') or [20.0, 20.0]
        _s['m1'], _s['m2'] = float(m[0]), float(m[1])
    else:
        _s['fin_m'] = [_s['m1'], _s['m2']]
        _s['m1'] = _s['m2'] = 0.0
    _appliquer(lambda: _sync_champs(inputs), inputs, True)
    _rebloquer(inputs)


def _bascule_enf(inputs):
    _s['entaille'] = not _s['entaille']
    _appliquer(lambda: _sync_champs(inputs), inputs, True)
    _rebloquer(inputs)


def _barre_vers(vp, pos):
    """Position de la souris sur la barre -> quantite (aperçu seul pendant le glisser)."""
    k = _dpr()
    x = (pos.x - OV_X) / k
    t = (x - OV_B0) / float(OV_B1 - OV_B0)
    q = _q_de_t(t)
    if q != int(_s['n']):
        _s['n'] = q
        _rafraichir_rapide()
        vp.refresh()


class _MouseHandler(adsk.core.MouseEventHandler):
    def __init__(self, nom): super().__init__(); self.nom = nom
    def notify(self, args):
        try:
            _souris.update(pos=args.viewportPosition, vp=args.viewport, t=time.perf_counter())
            if _bar['on'] and self.nom == 'mouseDrag':
                if time.perf_counter() - _bar['tm'] >= 0.012:
                    _bar['tm'] = time.perf_counter()
                    _barre_vers(args.viewport, args.viewportPosition)
            elif _qd.get('on') and self.nom == 'mouseDrag':
                _qd_glisser(args.viewport)
            elif _drag.get('maison') and _drag['k'] is not None and (self.nom == 'mouseDrag' or _drag.get('pris')):
                _glisser_souris(args.viewport)
            elif self.nom == 'mouseMove' and _drag['k'] is None:
                _tip_maj(args.viewport, args.viewportPosition)
        except Exception:
            pass


class _MouseDownHandler(adsk.core.MouseEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            ins = args.firingEvent.sender.commandInputs
            vp, pos = args.viewport, args.viewportPosition
            _tip_effacer()
            if _drag.get('pris') and _drag['k'] is not None:
                _bloquer_selection(ins)           # poignee attrapee par un clic : ce clic la pose
                _fin_maison(ins)
                return
            z = _ov_zone(vp, pos)
            if z is None:
                _bloc['sel'] = None
                if _caf is not None and args.button == adsk.core.MouseButtons.LeftMouseButton:
                    if _qd_debut(ins, vp, pos):
                        _bloquer_selection(ins)
                        _sel_figer(ins)            # pas de rectangle de selection pendant le glisser
                        return
                    k, f = _pastille_touchee(vp, pos)
                    if k is not None:
                        _bloquer_selection(ins)
                        _sel_figer(ins)            # pas de rectangle de selection pendant le glisser
                        _cur['ep'] = _ep_cm(ins)
                        if f is not None:
                            trk = next((h[1] for h in _poignees() if h[0] == k), None)
                            if trk is not None:
                                _poignee_set(k, f, trk)
                        _drag.update(k=k, maison=True, tm=0.0, pris=False, pd=(pos.x, pos.y), td=time.perf_counter())
                        _souris.update(pos=pos, vp=vp, t=time.perf_counter())
                        _glisser_souris(vp)
                return
            _bloquer_selection(ins)                # un clic sur la fenetre ne change jamais la selection Fusion
            try:
                self._clic(ins, vp, pos, z)
            finally:
                _redessiner_differe()
        except Exception:
            _log('mouseDown erreur ' + traceback.format_exc()[-400:])

    def _clic(self, ins, vp, pos, z):
        try:
            _cur['ep'] = _ep_cm(ins)
            if _jeux and _ov['row'] != _act['i']:
                _activer(_ov['row'], ins)
            if z == 'moins':
                _set_n(ins, int(_s['n']) - 1)
            elif z == 'plus':
                _set_n(ins, int(_s['n']) + 1)
            elif z == 'barre':
                _bar.update(on=True, tm=time.perf_counter())
                _barre_vers(vp, pos)
            elif z == 'sym':
                _bascule_sym(ins)
            elif z == 'fin':
                _bascule_fin(ins)
            elif z == 'enf':
                _bascule_enf(ins)
        except Exception:
            _log('clic fenetre erreur ' + traceback.format_exc()[-400:])


class _MouseUpHandler(adsk.core.MouseEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            ins = args.firingEvent.sender.commandInputs
            if _bar['on']:
                _bar['on'] = False
                _bloc['t'] = time.time()
                _appliquer(lambda: _sync_champs(ins), ins, True)
                _redessiner_differe()
                return
            if _qd.get('on'):
                _qd_fin(ins)
                return
            if _drag['k'] is not None:
                if _drag.get('maison') and not _drag.get('pris') and _clic_simple(args.viewportPosition):
                    _drag['pris'] = True
                    _bloc['t'] = time.time()
                    return
                if _drag.get('pris'):
                    return                         # attrapee : c'est le prochain clic qui la pose
                _fin_maison(ins)
        except Exception:
            _log('mouseUp erreur ' + traceback.format_exc()[-400:])


# --- Creation des corps ---------------------------------------------------------------------------------

def _blob(ep_cm):
    """Reglages ecrits sur ce que l'on cree : l'historique de CNC Toolkit rouvre la fenetre telle qu'elle etait."""
    return json.dumps({'v': 1, 's': {k: _s[k] for k in CLES}, 'ep': ep_cm, 'ep_nom': _cur.get('ep_nom')})


def _ep_choisir_nom(inputs, cm, nom):
    """Rouvre la fenetre sur le parametre CPxx utilise a la creation (sa valeur d'aujourd'hui), sinon sur l'epaisseur
    enregistree."""
    try:
        design = _design()
        noms = _ep_noms(design)
        if nom and nom in noms and design.allParameters.itemByName(nom) is not None:
            inputs.itemById('ep_dd').listItems.item(noms.index(nom)).isSelected = True
            inputs.itemById('ep_autre').isVisible = False
            return
    except Exception:
        _log('ep nom erreur ' + traceback.format_exc()[-200:])
    _ep_choisir(inputs, cm)


def _nom_traverse(comp):
    noms = set(comp.bRepBodies.item(i).name for i in range(comp.bRepBodies.count))
    base = _tt('Traverse dossier')
    k = 1
    while '%s %d' % (base, k) in noms:
        k += 1
    return '%s %d' % (base, k)


def _creer_corps(design, g, c, ep_cm, blob, face):
    """Une traverse : esquisse du contour (courbe avant, courbe arriere, deux bouts) sur un plan a son altitude,
    puis extrusion de l'epaisseur."""
    comp = design.activeComponent
    up = g['up']
    P3 = adsk.core.Point3D.create
    z = c['z']
    e = c['e']
    zb = z - e                                        # dessous de la traverse
    fn = _face_monde(face)
    sens = 1.0 if _v_dot(fn[1], up) >= 0 else -1.0   # sens de la normale de la face par rapport au haut
    planes = comp.constructionPlanes
    pi = planes.createInput()
    if isinstance(face, adsk.fusion.Profile):
        # face d'esquisse : son plan de reference peut etre une face du corps (il faudrait reculer la chronologie) ;
        # on part du plan d'origine perpendiculaire au haut, decale a l'altitude voulue
        axes = [(comp.yZConstructionPlane, (1.0, 0.0, 0.0)), (comp.xZConstructionPlane, (0.0, 1.0, 0.0)),
                (comp.xYConstructionPlane, (0.0, 0.0, 1.0))]
        pl0, n0 = max(axes, key=lambda q: abs(_v_dot(q[1], up)))
        sg0 = 1.0 if _v_dot(n0, up) >= 0 else -1.0
        pi.setByOffset(pl0, adsk.core.ValueInput.createByReal(zb * sg0))
        sens = sg0
    else:
        pi.setByOffset(face, adsk.core.ValueInput.createByReal((zb - g['zf']) * sens))
    plan = planes.add(pi)
    plan.name = 'Plan traverse'
    plan.isLightBulbOn = False
    sk = comp.sketches.add(plan)
    sk.name = 'Traverse dossier'

    def sp(p):
        return sk.modelToSketchSpace(P3(p[0], p[1], p[2]))

    def pas(lst, nmax=60):
        if len(lst) <= nmax:
            return list(lst)
        idx = sorted(set(int(round(i * (len(lst) - 1) / (nmax - 1.0))) for i in range(nmax)))
        return [lst[i] for i in idx]

    fr = pas(c['front'])
    re_ = pas(c['rear'])
    ptsf = adsk.core.ObjectCollection.create()
    for p in fr:
        q = sp(p)
        ptsf.add(P3(q.x, q.y, 0.0))
    ptsr = adsk.core.ObjectCollection.create()
    for p in re_:
        q = sp(p)
        ptsr.add(P3(q.x, q.y, 0.0))
    sf = sk.sketchCurves.sketchFittedSplines.add(ptsf)
    sr = sk.sketchCurves.sketchFittedSplines.add(ptsr)
    lines = sk.sketchCurves.sketchLines
    for pa, pb in ((sf.startSketchPoint, sr.startSketchPoint), (sf.endSketchPoint, sr.endSketchPoint)):
        if pa.geometry.distanceTo(pb.geometry) > 1e-4:
            lines.addByTwoPoints(pa, pb)
    if sk.profiles.count < 1:
        raise RuntimeError('contour de traverse non ferme')
    prof = sk.profiles.item(0)
    for i in range(sk.profiles.count):                 # le plus grand contour
        if sk.profiles.item(i).areaProperties().area > prof.areaProperties().area:
            prof = sk.profiles.item(i)
    ext = comp.features.extrudeFeatures
    ei = ext.createInput(prof, adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
    nom_ep = _cur.get('ep_nom')
    if nom_ep and design.allParameters.itemByName(nom_ep) is not None:       # epaisseur liee au parametre CPxx
        d = adsk.fusion.DistanceExtentDefinition.create(adsk.core.ValueInput.createByString(nom_ep))
    else:
        d = adsk.fusion.DistanceExtentDefinition.create(adsk.core.ValueInput.createByReal(ep_cm))
    ei.setOneSideExtent(d, adsk.fusion.ExtentDirections.PositiveExtentDirection if sens > 0
                        else adsk.fusion.ExtentDirections.NegativeExtentDirection)
    f = ext.add(ei)
    corps = f.bodies.item(0)
    corps.name = _nom_traverse(comp)
    for obj in (sk, f, corps):
        try:
            obj.attributes.add(ATTR_G, ATTR_N, blob)
        except Exception:
            _log('attribut erreur ' + traceback.format_exc()[-200:])
    return corps


def _rafraichir_modele(design):
    """Une occurrence deplacee a la main sans position capturee revient a sa place des qu'une operation entre dans la
    chronologie : on provoque ce recalcul (plan temporaire cree puis supprime) AVANT de mesurer, pour mesurer le modele
    tel qu'il restera."""
    try:
        comp = design.activeComponent
        pi = comp.constructionPlanes.createInput()
        pi.setByOffset(comp.xYConstructionPlane, adsk.core.ValueInput.createByReal(0.0))
        pl = comp.constructionPlanes.add(pi)
        pl.deleteMe()
    except Exception:
        _log('rafraichir : ' + traceback.format_exc()[-150:])
    _cache_ent.clear()
    _cache_traj.clear()
    try:
        _cache_faces.clear()
    except Exception:
        pass
    try:
        _prof_inv()
    except Exception:
        pass


# --- Mode « sans esquisse » : traverses en geometrie directe (2026-11-09) ----------------------------------------
# Chaque traverse est un solide temporaire (contour en B-splines qui passent par les points calcules, extrude de
# l'epaisseur), deja entaille a mi-bois, pose avec les outils des montants dans UNE fonction de base. Pas de plan,
# pas d'esquisse, pas d'extrusion ni de decoupe par traverse. Le bouton « Mettre a jour le dossier CNC » supprime et
# recree le tout avec les reglages memorises (chemins et corps choisis).

def _nurbs_pts(pts):
    """Courbe B-spline cubique (non rationnelle) qui passe par les points (interpolation, parametres par longueur de corde)."""
    P3 = adsk.core.Point3D.create
    n = len(pts)
    if n < 4:
        return [adsk.core.Line3D.create(P3(*pts[i]), P3(*pts[i + 1])) for i in range(n - 1)]
    # parametres
    t = [0.0]
    for i in range(1, n):
        t.append(t[-1] + max(1e-9, _d3(pts[i], pts[i - 1])))
    t = [x / t[-1] for x in t]
    p = 3
    # noeuds par moyenne (The NURBS Book 9.8)
    U = [0.0] * (p + 1)
    for j in range(1, n - p):
        U.append(sum(t[j:j + p]) / p)
    U += [1.0] * (p + 1)

    def base(i, k, u):
        # fonctions de base (Cox-de Boor), u dans [0,1]
        N = [0.0] * (p + 1)
        span = i
        left = [0.0] * (p + 1)
        right = [0.0] * (p + 1)
        N[0] = 1.0
        for j in range(1, p + 1):
            left[j] = u - U[span + 1 - j]
            right[j] = U[span + j] - u
            saved = 0.0
            for r in range(j):
                den = right[r + 1] + left[j - r]
                tmp = N[r] / den if den != 0 else 0.0
                N[r] = saved + right[r + 1] * tmp
                saved = left[j - r] * tmp
            N[j] = saved
        return N

    def span_de(u):
        if u >= U[n]:
            return n - 1
        lo, hi = p, n
        mid = (lo + hi) // 2
        while u < U[mid] or u >= U[mid + 1]:
            if u < U[mid]:
                hi = mid
            else:
                lo = mid
            mid = (lo + hi) // 2
        return mid
    # matrice bande (n x n) -> resolution dense simple (n <= ~120)
    A = [[0.0] * n for _ in range(n)]
    for k in range(n):
        sp = span_de(t[k])
        N = base(sp, p, t[k])
        for j in range(p + 1):
            A[k][sp - p + j] = N[j]
    # elimination de Gauss sans pivot (matrice bande totalement positive : pas besoin de pivot)
    B = [list(pts[k]) for k in range(n)]
    for col in range(n):
        d = A[col][col]
        for r in range(col + 1, min(n, col + p + 1)):
            f = A[r][col] / d
            if f != 0.0:
                for cc in range(col, min(n, col + p + 1)):
                    A[r][cc] -= f * A[col][cc]
                B[r] = [B[r][q] - f * B[col][q] for q in range(3)]
    X = [None] * n
    for r in range(n - 1, -1, -1):
        s_ = list(B[r])
        for cc in range(r + 1, min(n, r + p + 1)):
            if A[r][cc] != 0.0:
                s_ = [s_[q] - A[r][cc] * X[cc][q] for q in range(3)]
        X[r] = [s_[q] / A[r][r] for q in range(3)]
    cps = [P3(*x) for x in X]
    return [adsk.core.NurbsCurve3D.createNonRational(cps, p, U, False)]


def _prisme(courbes, up, h):
    """Solide temporaire : contour ferme (courbes 3D bout a bout, dans un plan perpendiculaire a up) extrude de h
    le long de up. Faces laterales = surfaces reglees (TemporaryBRepManager), assemblage par BRepBodyDefinition."""
    P3, V3 = adsk.core.Point3D.create, adsk.core.Vector3D.create
    tbm = adsk.fusion.TemporaryBRepManager.get()
    m = adsk.core.Matrix3D.create()
    m.translation = V3(up[0] * h, up[1] * h, up[2] * h)
    hauts = []
    for c in courbes:
        c2 = c.copy()
        c2.transformBy(m)
        hauts.append(c2)
    bd = adsk.fusion.BRepBodyDefinition.create()
    sh = bd.lumpDefinitions.add().shellDefinitions.add()
    k = len(courbes)

    def deb(c):
        ev = c.evaluator
        ok, a, b = ev.getEndPoints()
        return a, b
    vb, vt = [], []
    for i in range(k):
        a, _b = deb(courbes[i])
        vb.append(bd.createVertexDefinition(a))
        a2, _b2 = deb(hauts[i])
        vt.append(bd.createVertexDefinition(a2))
    eb = [bd.createEdgeDefinitionByCurve(vb[i], vb[(i + 1) % k], courbes[i]) for i in range(k)]
    et = [bd.createEdgeDefinitionByCurve(vt[i], vt[(i + 1) % k], hauts[i]) for i in range(k)]
    ev_ = []
    for i in range(k):
        a, _b = deb(courbes[i])
        a2, _b2 = deb(hauts[i])
        ev_.append(bd.createEdgeDefinitionByCurve(vb[i], vt[i], adsk.core.Line3D.create(a, a2)))
    a0, _ = deb(courbes[0])
    n = V3(*up)
    fb = sh.faceDefinitions.add(adsk.core.Plane.create(a0, n), True)
    lp = fb.loopDefinitions.add()
    for i in range(k):
        lp.bRepCoEdgeDefinitions.add(eb[i], True)
    a0t, _ = deb(hauts[0])
    ft = sh.faceDefinitions.add(adsk.core.Plane.create(a0t, n), False)
    lp = ft.loopDefinitions.add()
    for i in range(k):
        lp.bRepCoEdgeDefinitions.add(et[i], False)
    for i in range(k):
        w1, _m1 = tbm.createWireFromCurves([courbes[i]])
        w2, _m2 = tbm.createWireFromCurves([hauts[i]])
        rs = tbm.createRuledSurface(w1.wires.item(0), w2.wires.item(0))
        surf = rs.faces.item(0).geometry
        f = sh.faceDefinitions.add(surf, False)
        lp = f.loopDefinitions.add()
        lp.bRepCoEdgeDefinitions.add(eb[i], False)
        lp.bRepCoEdgeDefinitions.add(ev_[(i + 1) % k], False)
        lp.bRepCoEdgeDefinitions.add(et[i], True)
        lp.bRepCoEdgeDefinitions.add(ev_[i], True)
    bd.doFullHealing = True
    return bd.createBody()


def _pas(lst, nmax=60):
    if len(lst) <= nmax:
        return list(lst)
    idx = sorted(set(int(round(i * (len(lst) - 1) / (nmax - 1.0))) for i in range(nmax)))
    return [lst[i] for i in idx]


def _traverse_tmp(ci, up, ep):
    """Solide temporaire d'une traverse (coordonnees monde), dessous a z - ep/2."""
    P3 = adsk.core.Point3D.create
    e = ep / 2.0

    def bas(p):
        return (p[0] - up[0] * e, p[1] - up[1] * e, p[2] - up[2] * e)
    fr = [bas(p) for p in _pas(ci['front'])]
    re_ = [bas(p) for p in _pas(ci['rear'])]
    cs = _nurbs_pts(fr)
    if _d3(fr[-1], re_[-1]) > 1e-4:
        cs.append(adsk.core.Line3D.create(P3(*fr[-1]), P3(*re_[-1])))
    cs += _nurbs_pts(list(reversed(re_)))
    if _d3(re_[0], fr[0]) > 1e-4:
        cs.append(adsk.core.Line3D.create(P3(*re_[0]), P3(*fr[0])))
    b = _prisme(cs, up, ep)
    if b is None or b.volume <= 0:
        raise RuntimeError('traverse : solide direct impossible')
    return b


def _priorite_traverse(ci, u, w, up):
    """Le croisement (traverse ci, montant u de profondeur w) est-il un contact d'extremite ? Alors la traverse est
    prioritaire : le montant est coupe sur tout le volume de la traverse, la traverse n'est pas entaillee (le mi-bois
    ne convient pas : la moitie de la traverse partirait ou une languette resterait). Vrai quand la traverse
    commence ou finit dans l'epaisseur du montant, ou quand elle y est moins profonde que la moitie du montant."""
    try:
        tt = u['ep']
        s_u = u['s']
        if s_u - tt / 2.0 <= ci['sa'] + 1e-6 or s_u + tt / 2.0 >= ci['sb'] - 1e-6:
            return True
        z = ci['z']
        F = _v_add(u['F'], _v_mul(up, z - u['z0']))
        best = None
        for p, q in zip(ci['front'], ci['rear']):
            d = _v_sub(p, F)
            d = _v_sub(d, _v_mul(up, _v_dot(d, up)))
            n = _v_dot(d, d)
            if best is None or n < best[0]:
                best = (n, _d3(p, q))
        return best is not None and best[1] <= w / 2.0 + 0.05
    except Exception:
        return False


def _couper_priorites(design, comp, prio):
    """prio : [(montant cible, corps de traverse)]. Coupe chaque montant par les corps de traverse (outils gardes) :
    geometrie exacte de la traverse, aucun morceau parasite. Renvoie le nombre d'echecs."""
    echecs = 0
    cibles = []
    for cible, _t in prio:
        if all(cible.entityToken != x.entityToken for x in cibles):
            cibles.append(cible)
    for cible in cibles:
        coll = adsk.core.ObjectCollection.create()
        for c2, t in prio:
            if c2.entityToken == cible.entityToken:
                coll.add(t)
        try:
            cin = comp.features.combineFeatures.createInput(cible, coll)
            cin.operation = adsk.fusion.FeatureOperations.CutFeatureOperation
            cin.isKeepToolBodies = True
            comp.features.combineFeatures.add(cin)
        except Exception:
            _log('priorite traverse erreur ' + traceback.format_exc()[-300:])
            echecs += 1
    return echecs


def _residus(design, comp, ups, corps):
    """Apres les enfourchements : tout montant qui chevauche encore une traverse (extremites, coins arrondis, petits
    montants dont le haut est plus bas que la traverse...) est coupe par le corps de la traverse (prioritaire, outil
    garde) : geometrie exacte, donc ni vide ni morceau parasite. Renvoie le nombre de coupes en echec."""
    tbm = adsk.fusion.TemporaryBRepManager.get()
    prio = []
    vus = set()
    for u in ups:
        try:
            m = _natif(u['b'])
            if m.entityToken in vus:
                continue
            vus.add(m.entityToken)
            bm = m.boundingBox
            for t in corps:
                bt = t.boundingBox
                if (bm.maxPoint.x < bt.minPoint.x or bt.maxPoint.x < bm.minPoint.x or bm.maxPoint.y < bt.minPoint.y or
                        bt.maxPoint.y < bm.minPoint.y or bm.maxPoint.z < bt.minPoint.z or bt.maxPoint.z < bm.minPoint.z):
                    continue
                x = tbm.copy(m)
                tbm.booleanOperation(x, tbm.copy(t), adsk.fusion.BooleanTypes.IntersectionBooleanType)
                if x.volume > 0.005:
                    prio.append((m, t))
        except Exception:
            continue
    return _couper_priorites(design, comp, prio) if prio else 0


def _creer_tout_direct(design, c, a_faire, ep, blob):
    """Traverses + enfourchement sans esquisse : une fonction de base (traverses deja entaillees + outils des
    montants), puis une decoupe par montant. Renvoie la liste des corps."""
    comp = design.activeComponent
    up = c['g']['up']
    tbm = adsk.fusion.TemporaryBRepManager.get()
    DIFF = adsk.fusion.BooleanTypes.DifferenceBooleanType
    e = ep / 2.0
    inv = None
    try:
        occ = design.activeOccurrence
        if occ is not None:
            inv = occ.transform2.copy()
            inv.invert()
    except Exception:
        pass
    trav = []                 # (solide temporaire, calcul, boites de coupe de la traverse)
    outils = []               # (montant cible, boite temporaire, montant, bornes)
    prio_pairs = []           # (rang de la traverse, montant) : contacts d'extremite
    for ci in a_faire:
        b = _traverse_tmp(ci, up, ep)
        bxs = []
        if _s['entaille']:
            z = ci['z']
            for u, w in ci.get('pairs') or []:
                tt = u['ep']
                if _priorite_traverse(ci, u, w, up):
                    prio_pairs.append((len(trav), u))          # contact d'extremite : traverse prioritaire
                    continue
                bb = (w / 2.0, w / 2.0 + 40.0, -tt / 2.0 - 0.05, tt / 2.0 + 0.05, z - e, z + e)
                outils.append((_natif(u['b']), _boite_loc(tbm, u, *bb), u, bb))
                bb2 = (-40.0, w / 2.0, -tt / 2.0, tt / 2.0, z - e - 0.05, z + e + 0.05)
                tbm.booleanOperation(b, _boite_loc(tbm, u, *bb2), DIFF)
                bxs.append((u, bb2))
        trav.append((b, ci, bxs))
    pris = set(comp.bRepBodies.item(i).name for i in range(comp.bRepBodies.count))
    nb_ = _tt('Traverse dossier')
    noms = []
    k = 1
    while len(noms) < len(trav):                    # noms calcules d'avance (la fonction de base ne voit pas ses corps)
        if '%s %d' % (nb_, k) not in pris:
            noms.append('%s %d' % (nb_, k))
        k += 1
    if design.designType == adsk.fusion.DesignTypes.ParametricDesignType:
        bf = comp.features.baseFeatures.add()
        bf.startEdit()
        try:
            for (b, ci, bxs), nom in zip(trav, noms):
                if inv is not None:
                    tbm.transform(b, inv)
                ob = comp.bRepBodies.add(b, bf)
                ob.name = nom
            for cible, tmp, _u, _bb in outils:
                if inv is not None:
                    tbm.transform(tmp, inv)
                ob = comp.bRepBodies.add(tmp, bf)
                ob.name = 'Entaille traverse'
        finally:
            bf.finishEdit()
        corps = [bf.bodies.item(i) for i in range(len(trav))]
        outils_b = [(outils[i][0], bf.bodies.item(len(trav) + i)) for i in range(len(outils))]
        try:
            bf.attributes.add(ATTR_G, ATTR_N, blob)
        except Exception:
            _log('attribut erreur ' + traceback.format_exc()[-200:])
    else:
        bf = None
        corps = []
        for (b, ci, bxs), nom in zip(trav, noms):
            if inv is not None:
                tbm.transform(b, inv)
            ob = comp.bRepBodies.add(b)
            ob.name = nom
            corps.append(ob)
        outils_b = []
    for ob in corps:
        try:
            ob.attributes.add(ATTR_G, ATTR_N, blob)
        except Exception:
            pass
    _cur['paires'] = [(corps[i], trav[i][1]) for i in range(len(corps))]
    _cur['msg_enf'] = None
    prio = [(_natif(u['b']), corps[k]) for k, u in prio_pairs] if bf is not None else []
    if bf is not None and not outils_b:
        try:                    # une seule fonction : un repere pour former le groupe (Mettre a jour, Modifier)
            sk = comp.sketches.add(comp.xYConstructionPlane)
            sk.name = 'Repere ' + GROUPE_NOM
            q = sk.modelToSketchSpace(adsk.core.Point3D.create(*trav[0][1]['centre'])) if trav else None
            if q is not None:
                sk.sketchPoints.add(adsk.core.Point3D.create(q.x, q.y, 0.0))
            sk.isLightBulbOn = False
            sk.attributes.add(ATTR_G, ATTR_N, blob)
        except Exception:
            _log('repere erreur ' + traceback.format_exc()[-300:])
    if not outils_b:
        nbe = 0
        if _s['entaille'] and bf is not None:
            nbe = (_couper_priorites(design, comp, prio) if prio else 0) + _residus(design, comp, c['g']['ups'], corps)
        if nbe:
            _cur['msg_enf'] = 'Enfourchement : %d coupe(s) d\'extremite en echec.' % nbe
        if _s['entaille'] and bf is None and outils:
            _cur['msg_enf'] = "Enfourchement : conception parametrique (historique) requise."
        return corps
    cibles = []
    for cible, _ob in outils_b:
        if all(cible.entityToken != x.entityToken for x in cibles):
            cibles.append(cible)
    erreurs = []
    lot = []
    for cible in cibles:
        coll = adsk.core.ObjectCollection.create()
        for c2, ob in outils_b:
            if c2.entityToken == cible.entityToken:
                coll.add(ob)
        try:
            cin = comp.features.combineFeatures.createInput(cible, coll)
            cin.operation = adsk.fusion.FeatureOperations.CutFeatureOperation
            cin.isKeepToolBodies = False
            feat = comp.features.combineFeatures.add(cin)
            if _s.get('marge_auto'):
                toks = _parois(feat, [(bx[2], bx[3]) for bx in outils if bx[0].entityToken == cible.entityToken], inv)
                if toks:
                    lot.append({'female_token': cible.entityToken, 'face_tokens': toks})
        except Exception:
            _log('combine erreur ' + traceback.format_exc()[-400:])
            erreurs.append(traceback.format_exc().strip().splitlines()[-1])
    if _s.get('marge_auto'):
        for ob, (b, ci, bxs) in zip(corps, trav):        # parois des entailles des traverses (faces du corps)
            if bxs:
                try:
                    toks = _parois(ob, bxs, inv)
                    if toks:
                        lot.append({'female_token': ob.entityToken, 'face_tokens': toks})
                except Exception:
                    _log('parois traverse ' + traceback.format_exc()[-200:])
    msg_marge = _appliquer_marge(design, lot) if lot else None
    if prio:
        erreurs += ['coupe d\'extremite'] * _couper_priorites(design, comp, prio)
    erreurs += ['coupe d\'extremite'] * _residus(design, comp, c['g']['ups'], corps)
    if erreurs:
        _cur['msg_enf'] = 'Enfourchement : %d coupe(s) en echec (%s).' % (len(erreurs), erreurs[0][:200])
    else:
        _cur['msg_enf'] = msg_marge
    return corps


def _creer_tout(design, ep, blob):
    """Une traverse par altitude (mesures exactes). Renvoie la liste des corps crees ; _cur['paires'] garde, pour
    chacune, les montants qu'elle croise et leur profondeur."""
    _rafraichir_modele(design)
    c = _calc(design, _s, ep, exact=True)
    a_faire = [i for i in c['inst'] if i['ok']]
    if not _s.get('param', True):
        return _creer_tout_direct(design, c, a_faire, ep, blob)
    es = _ents(design, _s['c'])
    face = es[0]
    corps = []
    _cur['paires'] = []
    for ci in a_faire:
        b = _creer_corps(design, c['g'], ci, ep, blob, face)
        corps.append(b)
        _cur['paires'].append((b, ci))
    _cur['msg_enf'] = None
    if corps and _s['entaille']:
        try:
            _cur['msg_enf'] = _enfourchement(design, c['g'], ep)
        except Exception:
            _log('enfourchement erreur ' + traceback.format_exc()[-600:])
            _cur['msg_enf'] = 'Enfourchement impossible : ' + traceback.format_exc().strip().splitlines()[-1][:300]
    return corps


def _natif(b):
    try:
        return b.nativeObject if getattr(b, 'assemblyContext', None) is not None else b
    except Exception:
        return b


def _boite_loc(tbm, u, a0, a1, t0, t1, h0, h1):
    """Boite temporaire dans le repere du montant u : a vers l'arriere (depuis la face avant), t epaisseur, h altitude."""
    P3, V3 = adsk.core.Point3D.create, adsk.core.Vector3D.create
    up = _vers_haut()
    c = _v_add(_v_add(_v_add(u['F'], _v_mul(u['ar'], (a0 + a1) / 2.0)), _v_mul(u['th'], (t0 + t1) / 2.0)),
               _v_mul(up, (h0 + h1) / 2.0 - u['z0']))
    obb = adsk.core.OrientedBoundingBox3D.create(P3(*c), V3(*u['ar']), V3(*u['th']), a1 - a0, t1 - t0, h1 - h0)
    return tbm.createBox(obb)


def _find_module(nom):
    """Add-in deja charge par Fusion dans cette session (comme Entaille CNC)."""
    m = sys.modules.get(nom)
    if m is not None:
        return m
    for k, mm in list(sys.modules.items()):
        if k.endswith(nom + '_py'):
            return mm
    return None


def _parois(feat, bxs, inv):
    """Parois creees par la coupe : faces planes dont tous les sommets sont dans le volume d'une boite d'entaille
    (donc pas les grandes faces simplement trouees), sans le fond (normale le long de la profondeur du montant).
    Ce sont elles que Marge CNC decale (principe d'Entaille CNC). Pas de comparaison avec les plans d'avant la
    coupe : elle ecartait a tort les parois qui tombent sur un plan existant (traverse du haut et du bas)."""
    V3, P3 = adsk.core.Vector3D.create, adsk.core.Point3D.create
    tr = None
    if inv is not None:
        tr = inv.copy()
        tr.invert()
    up = _vers_haut()
    out = []
    for f in feat.faces:
        try:
            if not isinstance(f.geometry, adsk.core.Plane):
                continue
            n = V3(f.geometry.normal.x, f.geometry.normal.y, f.geometry.normal.z)
            if tr is not None:
                n.transformBy(tr)
            pts = []
            for v in f.vertices:
                q = P3(v.geometry.x, v.geometry.y, v.geometry.z)
                if tr is not None:
                    q.transformBy(tr)
                pts.append((q.x, q.y, q.z))
            if len(pts) < 3:
                continue
            for u, (a0, a1, t0, t1, h0, h1) in bxs:
                if abs(_v_dot((n.x, n.y, n.z), u['ar'])) > 0.9:
                    continue                                    # fond
                ok = True
                for q in pts:
                    d = _v_sub(q, u['F'])
                    a, t, h = _v_dot(d, u['ar']), _v_dot(d, u['th']), _v_dot(d, up) + u['z0']
                    if not (a0 - 0.1 <= a <= a1 + 0.1 and t0 - 0.1 <= t <= t1 + 0.1 and h0 - 0.1 <= h <= h1 + 0.1):
                        ok = False
                        break
                if ok:
                    out.append(f.entityToken)
                    break
        except Exception:
            continue
    return out


def _enfourchement(design, g, ep):
    """Enfourchement a mi-bois, par coupes exactes : a chaque croisement, le montant perd la moitie arriere de sa profondeur
    et la traverse la moitie avant (cote dossier : la traverse rentre dans le montant), sur l'epaisseur du montant. Les coupes font partie du groupe des
    traverses : le bouton Modifier les refait avec elles."""
    paires = _cur.get('paires') or []
    comp = design.activeComponent
    if design.designType != adsk.fusion.DesignTypes.ParametricDesignType:
        return "Enfourchement : conception parametrique (historique) requise."
    tbm = adsk.fusion.TemporaryBRepManager.get()
    e = ep / 2.0
    boites = []              # (cible, boite temporaire)
    prio = []                # (montant cible, corps de traverse) : contacts d'extremite
    up_ = g['up']
    for b, c in paires:
        z = c['z']
        for u, w in c.get('pairs') or []:
            tt = u['ep']
            if _priorite_traverse(c, u, w, up_):
                prio.append((_natif(u['b']), b))
                continue
            bb = (w / 2.0, w / 2.0 + 40.0, -tt / 2.0 - 0.05, tt / 2.0 + 0.05, z - e, z + e)
            boites.append((_natif(u['b']), _boite_loc(tbm, u, *bb), u, bb))
            bb = (-40.0, w / 2.0, -tt / 2.0, tt / 2.0, z - e - 0.05, z + e + 0.05)
            boites.append((_natif(b), _boite_loc(tbm, u, *bb), u, bb))
    corps_t = [b for b, _c in paires]
    if not boites:
        nbe = (_couper_priorites(design, comp, prio) if prio else 0) + _residus(design, comp, g['ups'], corps_t)
        if nbe:
            return 'Enfourchement : %d coupe(s) d\'extremite en echec.' % nbe
        return None
    occ = None
    try:
        occ = design.activeOccurrence
    except Exception:
        pass
    inv = None
    if occ is not None:
        inv = occ.transform2.copy()
        inv.invert()
    bf = comp.features.baseFeatures.add()
    bf.startEdit()
    try:
        for cible, tmp, _u, _bb in boites:
            if inv is not None:
                tbm.transform(tmp, inv)
            ob = comp.bRepBodies.add(tmp, bf)
            ob.name = 'Entaille traverse'
    finally:
        bf.finishEdit()
    outils = [(boites[i][0], bf.bodies.item(i)) for i in range(len(boites))]   # corps relus apres finishEdit
    cibles = []
    for cible, _ob in outils:
        if all(cible.entityToken != x.entityToken for x in cibles):
            cibles.append(cible)
    erreurs = []
    lot = []                 # parois a decaler (Marge CNC), comme Entaille CNC
    for cible in cibles:
        coll = adsk.core.ObjectCollection.create()
        for c2, ob in outils:
            if c2.entityToken == cible.entityToken:
                coll.add(ob)
        try:
            ci = comp.features.combineFeatures.createInput(cible, coll)
            ci.operation = adsk.fusion.FeatureOperations.CutFeatureOperation
            ci.isKeepToolBodies = False
            feat = comp.features.combineFeatures.add(ci)
            if _s.get('marge_auto'):
                toks = _parois(feat, [(bx[2], bx[3]) for bx in boites if bx[0].entityToken == cible.entityToken], inv)
                if toks:
                    lot.append({'female_token': cible.entityToken, 'face_tokens': toks})
        except Exception:
            _log('combine erreur ' + traceback.format_exc()[-400:])
            erreurs.append(traceback.format_exc().strip().splitlines()[-1])
    msg_marge = _appliquer_marge(design, lot) if lot else None
    if prio:
        erreurs += ['coupe d\'extremite'] * _couper_priorites(design, comp, prio)
    erreurs += ['coupe d\'extremite'] * _residus(design, comp, g['ups'], corps_t)
    if erreurs:
        return 'Enfourchement : %d coupe(s) en echec (%s).' % (len(erreurs), erreurs[0][:200])
    return msg_marge


def _appliquer_marge(design, lot):
    """Un seul decalage de faces pour toutes les coupes, avec le jeu regle dans Marge CNC (None si tout va bien)."""
    try:
        M = _find_module('MargeCNC')
        if M is None:
            return 'Marge automatique : add-in "Marge CNC" inactif, aucun jeu applique.'
        jeu, actif, _x = M.load_settings()
        if not actif:
            return 'Marge automatique : "Appliquer le jeu" est desactive dans Marge CNC.'
        try:
            M.record_face_tokens_batch(lot)
        except Exception:
            pass
        M.apply_jeu_to_tokens(design, design.rootComponent, lot, jeu, False)
        return None
    except Exception:
        _log('marge erreur ' + traceback.format_exc()[-400:])
        return 'Marge automatique : erreur - ' + traceback.format_exc().strip().splitlines()[-1][:200]


def _grouper(tl, debut, fin=None):
    """Une utilisation = un groupe replie (fin == debut : on renomme l'entree)."""
    try:
        if fin is None:
            fin = tl.markerPosition - 1
        if fin > debut:
            grp = tl.timelineGroups.add(debut, fin)
            grp.name = GROUPE_NOM
            grp.isCollapsed = True
            return True
        elif fin == debut:
            tl.item(debut).name = GROUPE_NOM
            return True
    except Exception:
        _log('groupement erreur ' + traceback.format_exc()[-300:])
    return False


# --- Mise a jour du dossier : montants remesures, traverses et entailles recreees -----------------------------------

MAJ_ID = 'TraversesDossierCNC_maj'


def _blob_groupe(g):
    for i in range(g.count):
        try:
            a = g.item(i).entity.attributes.itemByName(ATTR_G, ATTR_N)
            if a is not None:
                return json.loads(a.value)
        except Exception:
            continue
    return None


def _module_montants():
    for k, m in list(sys.modules.items()):
        if k.endswith('MontantsDossierCNC_py') and hasattr(m, 'maj_tous_montants'):
            return m
    for k, m in list(sys.modules.items()):
        if 'MontantsDossierCNC' in k and hasattr(m, 'maj_tous_montants'):
            return m
    return None


def _mod_addin(nom):
    """Module d'un add-in deja charge (Fusion le range sous une cle « ...<Nom>_py »)."""
    m = sys.modules.get(nom)
    if m is not None:
        return m
    for k, v in list(sys.modules.items()):
        if k.endswith(nom + '_py'):
            return v
    return None


def _cle_corps(b):
    try:
        n = b.nativeObject or b
    except Exception:
        n = b
    try:
        return [n.parentComponent.id, n.name]
    except Exception:
        return None


def _corps_par_cle(design, cle):
    try:
        comp = design.allComponents.itemById(cle[0])
        return comp.bRepBodies.itemByName(cle[1]) if comp is not None else None
    except Exception:
        return None


def _jeton_corps(design, tok):
    try:
        r = design.findEntityByToken(tok) if tok else None
        return adsk.fusion.BRepBody.cast(r[0]) if r else None
    except Exception:
        return None


def _prefixes_dossier():
    return tuple(set(['Montant', 'Traverse dossier', _tt('Montant'), _tt('Traverse dossier')]))


def _prep_cnc(design):
    """Avant la suppression des montants/traverses : releve les mortaises (Mortaise CNC) et les jeux (Marge CNC) qui
    portent sur ces corps (par NOM de corps : les jetons mourront avec les anciens corps), puis les supprime. Une
    mortaise gardee pendant la recreation faussait la mesure des montants (tenons perdus) et restait en erreur.
    Elles sont recreees par _post_cnc. Renvoie None si Mortaise CNC / Marge CNC ne sont pas actifs."""
    mort, marge = _mod_addin('MortaiseCNC'), _mod_addin('MargeCNC')
    if mort is None:
        return None
    pre = _prefixes_dossier()
    mem = {'pairs': [], 'runs': [], 'ok': False}
    try:
        design.timeline.moveToEnd()
        feats_m = []
        vus = set()
        doss = set()
        for feat, mtok, ftok in mort.find_all_mortaise_features(design):
            male, female = _jeton_corps(design, mtok), _jeton_corps(design, ftok)
            km, kf = (_cle_corps(male) if male is not None else None), (_cle_corps(female) if female is not None else None)
            # corps introuvable (jeton mort) : on retrouve le nom par l'empreinte de la derniere mise a jour
            try:
                a = feat.attributes.itemByName('MiseAJourCNC', 'sig')
                sig = json.loads(a.value) if a else None
            except Exception:
                sig = None
            if sig:
                km = km or sig.get('mk')
                kf = kf or sig.get('fk')
            if not km or not kf:
                continue
            if km[1].startswith(pre) or kf[1].startswith(pre):
                feats_m.append(feat)
                if (tuple(km), tuple(kf)) not in vus:
                    vus.add((tuple(km), tuple(kf)))
                    mem['pairs'].append((km, kf))
                doss.add(tuple(km))
                doss.add(tuple(kf))
        feats_g = []
        if marge is not None:
            for a in design.findAttributes('MargeCNC', 'jeu_cm'):
                feat = a.parent
                try:
                    if feat.attributes.itemByName('EntailleCNC', 'lot') is not None:
                        continue                              # jeu d'un lot d'entailles : recree avec le lot
                except Exception:
                    pass
                try:
                    sel = feat.attributes.itemByName('MargeCNC', 'selected_body_tokens')
                    fond = feat.attributes.itemByName('MargeCNC', 'exclure_fond')
                    cles = []
                    for t in ((sel.value if sel else '') or '').split(','):
                        b = _jeton_corps(design, t) if t else None
                        k = _cle_corps(b) if b is not None else None
                        if k:
                            cles.append(k)
                    if cles and any(tuple(k) in doss or k[1].startswith(pre) for k in cles):
                        mem['runs'].append({'jeu': float(a.value), 'cles': cles, 'fond': bool(fond and fond.value == '1')})
                        feats_g.append(feat)
                except Exception:
                    _log('prep marge : ' + traceback.format_exc()[-200:])
        marqueurs = []                                       # esquisses-marqueurs des groupes « Mortaise CNC » vides
        for feat in feats_m:
            try:
                grp = feat.timelineObject.parentGroup
                if grp is not None:
                    for i in range(grp.count):
                        e = grp.item(i).entity
                        if isinstance(e, adsk.fusion.Sketch) and e.name.startswith('_MortaiseCNC_marker') \
                                and all(e is not m for m in marqueurs):
                            marqueurs.append(e)
            except Exception:
                pass
        for feat in feats_g + feats_m:                       # jeux d'abord (ils dependent des parois des mortaises)
            try:
                feat.deleteMe()
            except Exception:
                _log('prep suppression : ' + traceback.format_exc()[-200:])
        for e in marqueurs:
            try:
                if e.isValid:
                    e.deleteMe()
            except Exception:
                pass
        design.timeline.moveToEnd()
        mem['ok'] = True
        _log('prep cnc : %d paire(s) mortaise, %d jeu(x)' % (len(mem['pairs']), len(mem['runs'])))
    except Exception:
        _log('prep cnc : ' + traceback.format_exc()[-400:])
    return mem


def _post_cnc(design, mem, bilan):
    """Apres la recreation des montants/traverses : mortaises puis jeux recrees sur les NOUVEAUX corps (retrouves par leur
    nom), puis « Mettre a jour CNC » pour le reste (dogbones, entailles...)."""
    if mem is None:
        return
    mort, marge, maj = _mod_addin('MortaiseCNC'), _mod_addin('MargeCNC'), _mod_addin('MiseAJourCNC')
    root = design.rootComponent
    tl = design.timeline
    try:
        tl.moveToEnd()
        if mem['pairs']:
            deb = tl.markerPosition
            marq = None
            try:
                marq = root.sketches.add(root.xYConstructionPlane)
                marq.name = '_MortaiseCNC_marker'
                marq.isVisible = False
            except Exception:
                marq = None
            nb = 0
            for km, kf in mem['pairs']:
                male, female = _corps_par_cle(design, km), _corps_par_cle(design, kf)
                if male is None or female is None:
                    bilan.append('Mortaise : corps %s / %s introuvable.' % (km[1], kf[1]))
                    continue
                try:
                    out = mort.creer_mortaises([male], [female], root)
                    nb += int(out[0])
                except Exception:
                    _log('post mortaise : ' + traceback.format_exc()[-300:])
            fin = tl.markerPosition - 1
            if nb == 0:
                try:
                    if marq is not None:
                        marq.deleteMe()
                except Exception:
                    pass
            elif fin > deb:
                try:
                    g = tl.timelineGroups.add(deb, fin)
                    g.name = 'Mortaise CNC'
                    g.isCollapsed = True
                except Exception:
                    _log('groupe mortaises : ' + traceback.format_exc()[-200:])
            bilan.append('%d mortaise(s) recreee(s).' % nb)
        nj = 0
        for run in mem['runs']:
            corps = [b for b in (_corps_par_cle(design, k) for k in run['cles']) if b is not None]
            if not corps:
                continue
            try:
                feat = marge.apply_jeu(design, root, set(b.entityToken for b in corps), corps, run['jeu'], True,
                                       run['fond'], skip_heuristique=True)[0]
                if feat:
                    nj += 1
            except Exception:
                _log('post jeu : ' + traceback.format_exc()[-300:])
        if mem['runs']:
            bilan.append('%d jeu(x) de fonctionnement recree(s).' % nj)
    except Exception:
        _log('post cnc : ' + traceback.format_exc()[-400:])
        bilan.append('Mortaises/jeux : ' + traceback.format_exc().strip().splitlines()[-1][:200])
    try:
        # dogbones (poses sur les cavites des mortaises) puis entailles (Entaille CNC) : recrees par les fonctions de
        # « Mettre a jour CNC » ; mortaises et jeux sont deja refaits ci-dessus
        tl.moveToEnd()
        if maj is not None:
            fkeys = set()
            for km, kf in mem['pairs']:
                f = _corps_par_cle(design, kf)
                k = maj._body_key(f) if f is not None else None
                if k:
                    fkeys.add(k)
            D = maj._find_module('DogboneCNC')
            if D is not None and hasattr(D, 'recreate_all_dogbones'):
                placer = maj._Placer(design)
                placer.hoist_keys = set()
                try:
                    n_ok, n_tot, errs = maj._update_dogbones(design, None, getattr(placer, 'reloc', None), placer,
                                                             fkeys, fkeys, set())
                    if n_tot:
                        bilan.append('%d/%d dogbone(s) recree(s).' % (n_ok, n_tot))
                    bilan.extend(list(errs or [])[:3])
                finally:
                    placer.to_work_end()
            E = maj._find_module('EntailleCNC')
            if E is not None and hasattr(E, 'recreate_all_entailles'):
                n_ok, n_tot, errs = maj._update_entailles(design, None)
                if n_tot:
                    bilan.append('%d/%d entaille(s) Entaille CNC recree(s).' % (n_ok, n_tot))
                bilan.extend(list(errs or [])[:3])
        tl.moveToEnd()
    except Exception:
        _log('post cnc dogbones : ' + traceback.format_exc()[-400:])
        bilan.append('Dogbones/entailles : ' + traceback.format_exc().strip().splitlines()[-1][:200])


def maj_dossier():
    """Supprime les traverses (et leurs entailles), remesure les montants, puis recree les traverses avec leurs reglages
    memorises. Renvoie un message de bilan."""
    design = _design()
    if design is None or design.designType != adsk.fusion.DesignTypes.ParametricDesignType:
        return 'Conception parametrique (historique) requise.'
    mont = _module_montants()
    tl = design.timeline
    info_cnc = _prep_cnc(design)
    tgs = tl.timelineGroups
    lots = []
    for i in range(tgs.count):
        g = tgs.item(i)
        b = _blob_groupe(g)
        if b is not None and (g.name or '').startswith(GROUPE_NOM):
            tok = None
            for k in range(g.count):
                try:
                    if g.item(k).entity.attributes.itemByName(ATTR_G, ATTR_N) is not None:
                        tok = g.item(k).entity.entityToken
                        break
                except Exception:
                    continue
            lots.append((tok, b))
    bilan = []
    if lots:
        tl.moveToEnd()
        for tok, b in lots:                           # groupes retrouves par une entite : le rang change a chaque suppression
            try:
                r = design.findEntityByToken(tok) if tok else None
                gg = r[0].timelineObject.parentGroup if r else None
                if gg is not None:
                    gg.deleteMe(True)
                else:
                    bilan.append('Traverses : ancien groupe introuvable.')
            except Exception:
                _log('suppression groupe maj : ' + traceback.format_exc()[-200:])
                bilan.append('Traverses : ancien groupe non supprime.')
    if mont is not None:
        nb, err = mont.maj_tous_montants()
        bilan.append('%d jeu(x) de montants mis a jour.' % nb)
        bilan += err
    else:
        bilan.append("Montants de dossier CNC n'est pas lance : montants non mis a jour.")
    for _tok, b in lots:
        try:
            _cache_traj.clear()
            _cache_ent.clear()
            _cache_faces.clear()
            _prof_inv()
            _s.clear()
            _s.update(_nouveau())
            _s.update({k: v for k, v in (b.get('s') or {}).items() if k in CLES})
            ep = float(b.get('ep', 1.8))
            nom = b.get('ep_nom')
            pr = design.allParameters.itemByName(nom) if nom else None
            if pr is not None:
                ep = pr.value
            else:
                nom = None
            _cur['ep'] = ep
            _cur['ep_nom'] = nom
            tl.moveToEnd()
            debut = tl.markerPosition
            corps = _creer_tout(design, ep, _blob(ep))
            if corps:
                fin = tl.markerPosition - 1
                if not _grouper(tl, debut, fin):
                    _groupage_apres.update(debut=debut, fin=fin, ed=True)
                bilan.append('%d traverse(s) recreee(s).' % len(corps))
                if _cur.get('msg_enf'):
                    bilan.append(_cur['msg_enf'])
            else:
                bilan.append('Aucune traverse valide pour un jeu.')
            tl.moveToEnd()
        except Exception:
            _log('maj dossier erreur ' + traceback.format_exc()[-500:])
            bilan.append('Traverses : ' + traceback.format_exc().strip().splitlines()[-1][:200])
    _post_cnc(design, info_cnc, bilan)
    _renommer_doublons(design, _tt('Montant'))
    _renommer_doublons(design, _tt('Traverse dossier'))
    try:
        # recalcul complet : apres les retours en arriere de la chronologie, certains corps restaient « fantomes »
        # (faces sans maillage d'affichage) et des fonctions en jaune jusqu'au prochain recalcul
        tl.moveToEnd()
        design.computeAll()
        sains = adsk.fusion.FeatureHealthStates.HealthyFeatureHealthState
        mal = [tl.item(i).name for i in range(tl.count) if not tl.item(i).isGroup and tl.item(i).healthState != sains]
        if mal:
            bilan.append('Entrees de la chronologie en alerte : ' + ', '.join(mal[:6]))
        _rafraichir_vue()
    except Exception:
        _log('recalcul final : ' + traceback.format_exc()[-300:])
    return '\n'.join(bilan)


class _MajExecHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            _ui.messageBox(maj_dossier(), 'Mettre a jour le dossier CNC')
        except Exception:
            _log('maj bouton erreur ' + traceback.format_exc()[-400:])
            _ui.messageBox('Mise a jour impossible : ' + traceback.format_exc().strip().splitlines()[-1][:300])


class _MajCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        h = _MajExecHandler()
        args.command.execute.add(h)
        _handlers.append(h)


# --- Evenements de la commande --------------------------------------------------------------------------

CHAMPS_AUTO = {'prof': 'prof_auto'}   # mesure -> case du mode automatique (saisie « A »)


def _saisie_auto(inp):
    """« A » (ou « a ») tape dans un champ de mesure qui a un mode automatique : le mode automatique est
    choisi (Maxence 2026-11-17). Le champ quitte le « A » et reprend sa valeur."""
    try:
        if str(inp.expression or '').strip().lower() not in ('a', 'auto'):
            return False
        inp.value = inp.value
        return True
    except Exception:
        return False


class _InputChangedHandler(adsk.core.InputChangedEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            inp = args.input
            ins = inp.parentCommand.commandInputs
            iid = inp.id
            if _en_cours['v']:
                return
            if iid in CHAMPS_AUTO and _saisie_auto(inp):
                # « A » dans la mesure : sa case automatique est cochee, traite comme un clic sur la case
                _en_cours['v'] = True
                try:
                    inp = ins.itemById(CHAMPS_AUTO[iid])
                    inp.value = True
                finally:
                    _en_cours['v'] = False
                iid = inp.id
            if iid in SEL_IDS and _restaurer_selection(ins, iid):
                return
            if iid in SEL_IDS:
                _en_cours['v'] = True
                try:
                    _lire_selection(ins)
                    if iid == 'face' and ins.itemById('face').selectionCount and not ins.itemById('arete').selectionCount:
                        ins.itemById('arete').hasFocus = True
                    _sync_champs(ins)
                    _rafraichir(ins, True)
                finally:
                    _en_cours['v'] = False
                return
            ok = True
            if iid == 'mode_crea':
                _s['param'] = (inp.selectedItem.index == 0) if inp.selectedItem else True
            elif iid == 'nb':
                _s['n'] = max(1, min(NB_MAX, int(inp.value)))
            elif iid == 'm1':
                _s['m1'] = max(0.0, inp.value * 10.0)
                if _s['sym']:
                    _s['m2'] = _s['m1']
            elif iid == 'm2':
                _s['m2'] = max(0.0, inp.value * 10.0)
                if _s['sym']:
                    _s['m1'] = _s['m2']
            elif iid == 'sym':
                _s['sym'] = bool(inp.value)
                if _s['sym']:
                    _s['m2'] = _s['m1']
            elif iid == 'retr':
                _s['retr'] = max(0.0, inp.value * 10.0)
            elif iid == 'prof_auto':
                _s['prof_auto'] = bool(inp.value)
            elif iid == 'prof':
                _s['prof_mm'] = max(1.0, inp.value * 10.0)
                _s['prof_auto'] = False
            elif iid == 'entaille':
                _s['entaille'] = bool(inp.value)
            elif iid == 'esq':
                _modes['esq'] = bool(inp.value)
                fs = ins.itemById('face')
                if any(isinstance(e, adsk.fusion.Profile) != _modes['esq'] for e in _selections(fs)):
                    fs.clearSelection()
                    _jeux.clear()
                    _s['c'] = []
                    _prof_inv()
            elif iid == 'marge_auto':
                _s['marge_auto'] = bool(inp.value)
            elif iid == 'cv_mode':
                _s['cv_mode'] = CV_MODES[inp.selectedItem.index if inp.selectedItem else 0]
            elif iid == 'cv_w':
                _s['cv_w'] = max(1.0, min(100.0, inp.value))
            elif iid == 'cv_h':
                _s['cv_h'] = max(1.0, min(100.0, inp.value))
            elif iid == 'cv_a':
                _s['cv_a'] = max(1.0, inp.value * 10.0)
            elif iid == 'cv_b':
                _s['cv_b'] = max(1.0, inp.value * 10.0)
            elif iid in ('ep_dd', 'ep_autre'):
                dd = ins.itemById('ep_dd')
                ins.itemById('ep_autre').isVisible = (dd.selectedItem.index == dd.listItems.count - 1)
            else:
                ok = False
            if ok:
                _appliquer(lambda: _sync_champs(ins), ins, True)
        except Exception:
            _log('inputChanged erreur ' + traceback.format_exc()[-600:])


class _PreviewHandler(adsk.core.CommandEventHandler):
    """executePreview : Fusion annule, a chaque changement, ce qui a ete cree pendant l'evenement precedent
    (y compris nos groupes graphiques) : fenetre, apercu et pastilles sont recrees s'ils ont disparu."""
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            if _cur['calc'] is not None:
                if not (_drag['k'] is not None and _ov['g'] is not None and _ov['g'].isValid):
                    _ov_maj()
                _apercu_maj(_tous_calculs())
                _maj_pastilles()
        except Exception:
            _log('preview erreur ' + traceback.format_exc()[-300:])


class _ValidateHandler(adsk.core.ValidateInputsEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            cs = _cur.get('calcs') or ([_cur['calc']] if _cur['calc'] else [])
            args.areInputsValid = bool(cs) and all(c and c['ok'] for c in cs)
        except Exception:
            args.areInputsValid = False


def _renommer_doublons(design, base):
    """Apres remplacement d'un groupe, Fusion a pu nommer les nouveaux corps « <base> n (1) » (les anciens existaient
    encore) : on leur rend leur nom simple quand il est libre."""
    import re as _re
    try:
        comp = design.activeComponent
        corps = [comp.bRepBodies.item(i) for i in range(comp.bRepBodies.count)]
        noms = set(b.name for b in corps)
        motif = _re.compile(r'^(' + _re.escape(base) + r' \d+) \(\d+\)$')
        for b in corps:
            m = motif.match(b.name or '')
            if m and m.group(1) not in noms:
                noms.discard(b.name)
                b.name = m.group(1)
                noms.add(b.name)
    except Exception:
        _log('renommer : ' + traceback.format_exc()[-200:])


def _supprimer_anciens_groupe(design, tokens):
    """Modification : l'ancien groupe est supprime avec tout son contenu (esquisses, plans, extrusions, decoupes) ;
    a defaut, entree par entree."""
    try:
        r = design.findEntityByToken(tokens[0]) if tokens else None
        g = r[0].timelineObject.parentGroup if r else None
        if g is not None:
            g.deleteMe(True)
            return True
    except Exception:
        _log('suppression ancien groupe : ' + traceback.format_exc()[-200:])
    return _supprimer_anciens(design, tokens)


def _basculer_jeu(jeu):
    global _s
    _s = jeu


class _ExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        ins = args.command.commandInputs
        _apercu_effacer()
        _ov_effacer()
        try:
            design = _design()
            ep = _ep_cm(ins)
            try:
                _cur['ep_nom'] = _ep_parametre(design, ins, ep)
            except Exception:
                _log('parametre epaisseur erreur ' + traceback.format_exc()[-300:])
            tl = None
            debut = 0
            try:
                tl = design.timeline
                debut = tl.markerPosition
            except Exception:
                pass
            ed = _edition['v']
            edite = ed is not None
            n = 0
            msgs = []
            for jeu in (list(_jeux) or [_s]):
                _basculer_jeu(jeu)
                ok_suppr = True
                if ed is not None and tl is not None:
                    # modification : seul le premier jeu remplace l'ancien groupe, supprime AVANT la creation (sinon les
                    # nouveaux corps naissent « Traverse dossier 1 (1) » et reprennent ce nom a chaque recalcul)
                    try:
                        _rafraichir_modele(design)
                        if any(i['ok'] for i in _calc(design, _s, ep, exact=True)['inst']):
                            _edition['v'] = None
                            ok_suppr = _supprimer_anciens_groupe(design, ed['anciens'])
                        else:
                            ed = None
                    except Exception:
                        _log('suppression avant creation : ' + traceback.format_exc()[-200:])
                debut = tl.markerPosition if tl is not None else 0
                corps = _creer_tout(design, ep, _blob(ep))
                nj = len(corps)
                n += nj
                if _cur.get('msg_enf'):
                    msgs.append(_cur['msg_enf'])
                if tl is None or not nj:
                    continue
                fin = tl.markerPosition - 1
                if not _grouper(tl, debut, fin):
                    _groupage_apres.update(debut=debut, fin=fin, ed=ed is not None)    # refait apres la commande
                if ed is not None:
                    tl.moveToEnd()
                    if not ok_suppr:
                        _ui.messageBox("Les anciennes traverses n'ont pas pu etre supprimees : d'autres fonctions de la "
                                       "chronologie utilisent leurs corps. Les nouvelles sont creees ; supprimez les "
                                       "anciennes a la main.", COMMAND_NAME)
                    ed = None
            if tl is not None and n and edite:
                try:
                    tl.moveToEnd()
                except Exception:
                    pass
                _renommer_doublons(design, _tt('Traverse dossier'))       # chronologie complete : tous les noms visibles
            _cur['msg_enf'] = '\n'.join(msgs) if msgs else None
            if n == 0:
                args.executeFailed = True
                args.executeFailedMessage = _tt('Aucune traverse valide.')
            else:
                if _cur.get('msg_enf'):
                    _ui.messageBox(_cur['msg_enf'], COMMAND_NAME)
                sp = {k: _s[k] for k in DEFAULT_PREFS if k in _s}
                sp['epaisseur_mm'] = round(ep * 10.0, 3)
                save_prefs(sp)
        except Exception as e:
            _log('execute erreur ' + traceback.format_exc()[-600:])
            args.executeFailed = True
            args.executeFailedMessage = 'Traverses impossibles : ' + str(e).splitlines()[-1][:300]


_groupage_apres = {}


class _DestroyHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        _redraw['on'] = False
        _apercu_effacer()          # toujours effacer overlay et apercus a la fermeture
        _ov_effacer()
        _drag['k'] = None
        _drag['maison'] = False
        _drag['pris'] = False
        _bar['on'] = False
        _qd['on'] = False
        _qd.pop('tr', None)
        _pastilles_effacer()
        _camera_suivre(False)
        _bloc['sel'] = None
        _cache_traj.clear()
        _cache_ent.clear()
        _cache_faces.clear()
        _prof_inv()
        _jeux.clear()
        _cur['calcs'] = []
        _rafraichir_vue()
        if _groupage_apres:
            # le groupement a echoue pendant la validation : refait juste apres la fin de la commande
            _differer_groupage()
        if _edition['v'] is not None:
            # modification annulee (ou echouee) : retour a la fin de la chronologie, rien n'a change
            _edition['v'] = None
            try:
                _design().timeline.moveToEnd()
            except Exception:
                pass


GROUPAGE_ID = 'TraversesDossierCNC_groupage'
_groupage = {'evt': None, 'h': None}


class _GroupageHandler(adsk.core.CustomEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            if not _groupage_apres:
                return
            d = dict(_groupage_apres)
            _groupage_apres.clear()
            tl = _design().timeline
            _grouper(tl, d['debut'], d['fin'])
            if d.get('ed'):
                tl.moveToEnd()
        except Exception:
            _log('groupage apres erreur ' + traceback.format_exc()[-300:])


def _differer_groupage():
    try:
        if _groupage['evt'] is None:
            try:
                _app.unregisterCustomEvent(GROUPAGE_ID)
            except Exception:
                pass
            _groupage['evt'] = _app.registerCustomEvent(GROUPAGE_ID)
            _groupage['h'] = _GroupageHandler()
            _groupage['evt'].add(_groupage['h'])
        if not _app.fireCustomEvent(GROUPAGE_ID, ''):
            _groupage['evt'] = None
            raise RuntimeError('evenement non livre')
    except Exception:
        _log('differer groupage : ' + traceback.format_exc()[-200:])


class _CreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        global _s
        try:
            cmd = args.command
            if _edition['v'] is None:
                _modes['esq'] = True               # nouvelle utilisation : base = face d'esquisse par defaut
            p = load_prefs()
            _jeux.clear()
            _act['i'] = 0
            _s = _nouveau(p)
            _cur.update(calc=None, calcs=[], ep=p['epaisseur_mm'] / 10.0)
            _cache_traj.clear()
            _cache_ent.clear()
            _cache_faces.clear()
            _prof_inv()
            _bloc['sel'] = None
            _ov_effacer()
            _apercu_effacer()
            ins = cmd.commandInputs
            ins.addTextBoxCommandInput('msg', '', '', 2, True)
            s = ins.addSelectionInput('face', 'Face de la base', 'Face de la base du dossier (la dalle sous les montants) ou face de l esquisse')
            s.addSelectionFilter('PlanarFaces')
            s.addSelectionFilter('Profiles')
            s.setSelectionLimits(0, 0)          # plusieurs dossiers : une fenetre TRAVERSE et un jeu de traverses chacun
            s = ins.addSelectionInput('arete', 'Arete du haut', 'Arete du haut du dossier')
            s.addSelectionFilter('Edges')
            s.setSelectionLimits(0, 0)
            dmc = ins.addDropDownCommandInput('mode_crea', 'Mode de creation', adsk.core.DropDownStyles.TextListDropDownStyle)
            dmc.listItems.add('Avec esquisse (parametrique)', bool(_s.get('param', True)), '')
            dmc.listItems.add('Sans esquisse (rapide)', not _s.get('param', True), '')
            dmc.tooltip = ('Avec esquisse : les pieces suivent le dossier et le parametre CP. Sans esquisse : creation tres '
                           'rapide, le bouton Mettre a jour le dossier CNC les recree.')
            gm = ins.addGroupCommandInput('grp_trav', 'Traverses')
            gm.isExpanded = True
            gc = gm.children
            gc.addBoolValueInput('esq', 'Base : face d’esquisse (au lieu d’une face du corps)', True, '', bool(_modes['esq']))
            gc.addIntegerSpinnerCommandInput('nb', 'Nombre de traverses', 1, NB_MAX, 1, int(_s['n']))
            gc.addValueInput('m1', 'Marge en bas', 'mm', adsk.core.ValueInput.createByReal(_s['m1'] / 10.0))
            gc.addValueInput('m2', 'Marge en haut', 'mm', adsk.core.ValueInput.createByReal(_s['m2'] / 10.0))
            gc.addBoolValueInput('sym', 'Symetrie (memes marges)', True, '', bool(_s['sym']))
            gd = ins.addGroupCommandInput('grp_dim', 'Dimensions')
            gd.isExpanded = True
            gdc = gd.children
            dd = gdc.addDropDownCommandInput('ep_dd', 'Epaisseur', adsk.core.DropDownStyles.TextListDropDownStyle)
            ok_cp = _ep_remplir(dd, _design(), p['epaisseur_mm'] / 10.0)
            ae = gdc.addValueInput('ep_autre', 'Epaisseur libre', 'mm', adsk.core.ValueInput.createByReal(p['epaisseur_mm'] / 10.0))
            ae.isVisible = not ok_cp
            gdc.addValueInput('retr', 'Retrait aux bouts du dossier', 'mm', adsk.core.ValueInput.createByReal(_s['retr'] / 10.0))
            gdc.addBoolValueInput('prof_auto', 'Profondeur detectee (montants)', True, '', bool(_s['prof_auto']))
            gdc.addValueInput('prof', 'Profondeur', 'mm', adsk.core.ValueInput.createByReal(_s['prof_mm'] / 10.0))
            gv = ins.addGroupCommandInput('grp_cv', 'Courbe des bouts (conge asymetrique)')
            gv.isExpanded = True
            gvc = gv.children
            dd = gvc.addDropDownCommandInput('cv_mode', 'Courbe', adsk.core.DropDownStyles.TextListDropDownStyle)
            for m, nom in zip(CV_MODES, ('Aucune', 'Automatique', 'Manuelle')):
                dd.listItems.add(nom, m == _s['cv_mode'], '')
            gvc.addValueInput('cv_w', 'Longueur de la courbe (% de la longueur)', '', adsk.core.ValueInput.createByReal(_s['cv_w']))
            gvc.addValueInput('cv_h', 'Profondeur de la courbe (% de la profondeur)', '', adsk.core.ValueInput.createByReal(_s['cv_h']))
            gvc.addValueInput('cv_a', 'Longueur de la courbe', 'mm', adsk.core.ValueInput.createByReal(_s['cv_a'] / 10.0))
            gvc.addValueInput('cv_b', 'Profondeur de la courbe', 'mm', adsk.core.ValueInput.createByReal(_s['cv_b'] / 10.0))
            ge = ins.addGroupCommandInput('grp_enf', 'Enfourchement')
            ge.isExpanded = True
            ge.children.addBoolValueInput('entaille', 'Enfourchement a mi-bois avec les montants', True, '', bool(_s['entaille']))
            ge.children.addBoolValueInput('marge_auto', 'Marge automatique (jeu de Marge CNC)', True, '', bool(_s['marge_auto']))
            for ev, h in ((cmd.inputChanged, _InputChangedHandler()),
                          (cmd.validateInputs, _ValidateHandler()),
                          (cmd.executePreview, _PreviewHandler()),
                          (cmd.execute, _ExecuteHandler()),
                          (cmd.destroy, _DestroyHandler()),
                          (cmd.mouseDown, _MouseDownHandler()),
                          (cmd.preSelect, _PreSelectHandler()),
                          (cmd.mouseUp, _MouseUpHandler()),
                          (cmd.mouseDrag, _MouseHandler('mouseDrag')),
                          (cmd.mouseMove, _MouseHandler('mouseMove'))):
                ev.add(h)
                _handlers.append(h)
            _redraw['evt'] = None            # evenements (re)enregistres depuis cette commande : ils survivent
            _redraw['on'] = True
            ed = _edition['v']
            if ed is not None:
                b = ed['blob']
                _s.update({k: v for k, v in (b.get('s') or {}).items() if k in CLES})
                if _s.get('c'):
                    _jeux[:] = [_s]
                try:
                    _ep_choisir_nom(ins, float(b['ep']), b.get('ep_nom'))
                except Exception:
                    _log('epaisseur edition erreur ' + traceback.format_exc()[-200:])

                def f():
                    _charger_selection(ins)
                    _sync_champs(ins)
                _appliquer(f, ins, True)
            else:
                _appliquer(lambda: _sync_champs(ins), ins, True)
            ins.itemById('face').hasFocus = not ed
            if ed:
                _resel['ins'] = ins
                _differer('@resel')
        except Exception:
            _log('cree erreur ' + traceback.format_exc()[-800:])
            _ui.messageBox('Erreur Traverses de dossier CNC:\n' + traceback.format_exc(), COMMAND_NAME)


# --- Modification depuis l'historique de CNC Toolkit (cnc_historique.modifier) --------------------------------

def edit_group(g):
    """Appele par cnc_historique : recule la chronologie au debut du groupe « Traverses dossier CNC » et rouvre la
    fenetre avec ses reglages ; a la validation les nouvelles traverses remplacent les anciennes. (ok, message)."""
    try:
        design = _design()
        if design is None or design.designType != adsk.fusion.DesignTypes.ParametricDesignType:
            return False, 'Conception parametrique (historique) requise.'
        ents = [g.item(i).entity for i in range(g.count)]
        blob = None
        for e in ents:
            try:
                a = e.attributes.itemByName(ATTR_G, ATTR_N)
                if a is not None:
                    blob = json.loads(a.value)
                    break
            except Exception:
                continue
        if blob is None:
            return False, 'Traverses creees avant la version modifiable : pas de reglages memorises.'
        tl = design.timeline
        idx = None
        for lire in (lambda: g.index, lambda: g.item(0).index):
            try:
                idx = lire()
                break
            except Exception:
                continue
        if idx is None:
            return False, 'Position du groupe introuvable.'
        _edition['v'] = {'blob': blob, 'anciens': [e.entityToken for e in ents]}
        try:
            _ui.activeSelections.clear()
        except Exception:
            pass
        tl.markerPosition = idx
        _differer()
        return True, None
    except Exception as e:
        _edition['v'] = None
        _log('edit_group erreur ' + traceback.format_exc()[-400:])
        return False, str(e)[:200]


def run(context):
    global _app, _ui
    try:
        _app = adsk.core.Application.get()
        _ui = _app.userInterface
        old = _ui.commandDefinitions.itemById(CMD_ID)
        if old:
            old.deleteMe()
        res = os.path.join(_ADDIN_DIR, 'resources')
        cmd_def = _ui.commandDefinitions.addButtonDefinition(CMD_ID, COMMAND_NAME, COMMAND_DESC,
                                                             res if os.path.isdir(res) else '')
        on_created = _CreatedHandler()
        cmd_def.commandCreated.add(on_created)
        _handlers.append(on_created)
        panel = _ui.allToolbarPanels.itemById(PANEL_ID)
        if panel and not panel.controls.itemById(CMD_ID):
            panel.controls.addCommand(cmd_def)
        oldm = _ui.commandDefinitions.itemById(MAJ_ID)
        if oldm:
            oldm.deleteMe()
        maj_def = _ui.commandDefinitions.addButtonDefinition(MAJ_ID, 'Mettre a jour le dossier CNC',
                                                             'Remesure les montants, recree les traverses et leurs entailles',
                                                             res if os.path.isdir(res) else '')
        on_maj = _MajCreatedHandler()
        maj_def.commandCreated.add(on_maj)
        _handlers.append(on_maj)
        if panel and not panel.controls.itemById(MAJ_ID):
            panel.controls.addCommand(maj_def)
        # evenements personnalises : enregistres a l'ouverture de la commande (voir _redessiner_differe / _differer)
    except Exception:
        if _ui:
            _ui.messageBox('Erreur au demarrage de Traverses de dossier CNC:\n' + traceback.format_exc())


def stop(context):
    _dv_arreter()
    try:
        for ev in (ACTION_ID, REDRAW_ID, GROUPAGE_ID):
            try:
                _app.unregisterCustomEvent(ev)
            except Exception:
                pass
        _action['evt'] = None
        _redraw['evt'] = None
        _groupage['evt'] = None
        _redraw['on'] = False
        _apercu_effacer()
        _ov_effacer()
        _pastilles_effacer()
        panel = _ui.allToolbarPanels.itemById(PANEL_ID)
        if panel:
            c = panel.controls.itemById(CMD_ID)
            if c:
                c.deleteMe()
        cd = _ui.commandDefinitions.itemById(CMD_ID)
        if cd:
            cd.deleteMe()
        if panel:
            cm = panel.controls.itemById(MAJ_ID)
            if cm:
                cm.deleteMe()
        cdm = _ui.commandDefinitions.itemById(MAJ_ID)
        if cdm:
            cdm.deleteMe()
    except Exception:
        pass
    _handlers.clear()
