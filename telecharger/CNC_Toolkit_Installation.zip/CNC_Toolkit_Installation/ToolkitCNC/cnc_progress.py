# ---------------------------------------------------------------------------
# Barre de chargement commune de CNC Toolkit (demande de Maxence le
# 2026-10-11) : "une petite barre de chargement au milieu de l'ecran quand
# j'utilise les outils gourmands, pour m'assurer que Fusion n'est pas en
# train de crasher".
#
# Fenetre de progression native de Fusion (centree, modale), choisie par
# Maxence apres deux essais (texte anime, puis palette HTML facon "LOADING"
# sombre - rejetee : "ca ouvre une fenetre identique a celle de CNC
# Toolkit", voir progress_bar/*.bak dans les fichiers du projet). Elle
# n'apparait qu'apres DELAI seconde : un outil qui finit vite n'affiche rien.
#
#   import cnc_progress
#   with cnc_progress.Barre('Calpinage CNC', 'Analyse des pieces...', total=len(corps)) as pg:
#       for b in corps:
#           pg.avance()                              # +1
#       pg.etape('Creation...', valeur=0, total=n)   # nouvelle phase
#
# Dans une fonction appelee pendant qu'une Barre est ouverte ailleurs (sans
# y avoir acces), cnc_progress.etape(...) / cnc_progress.avance() agissent sur
# la Barre ouverte, et ne font rien s'il n'y en a pas.
#
# Imbrication : une Barre ouverte alors qu'une autre est deja ouverte (ex.
# Mettre a jour CNC qui appelle la recreation des dogbones) ne cree pas de
# seconde fenetre : elle prend la main sur la fenetre existante le temps de
# son bloc, puis rend la main (texte et avancement de la barre parente).
# Fichier partage par tous les outils : le garder sans dependance.
# ---------------------------------------------------------------------------
import adsk.core
import time

DELAI = 1   # secondes (entier, exige par l'API) avant affichage

_dlg = None      # ProgressDialog affichee (une seule pour tout le Toolkit)
_pile = []       # Barres ouvertes, la derniere pilote la fenetre
_t_maj = 0.0


def occupe():
    """Vrai pendant qu'un outil travaille sous une Barre (lu par le lanceur
    ToolkitCNC.py pour ignorer les clics de sa palette pendant ce temps)."""
    return bool(_pile)


def _texte(b):
    if b.total > 1:
        return '%s  (%d / %d)' % (b.message, min(b.valeur, b.total), b.total)
    return b.message


def _appliquer(b, force=True):
    """Recopie l'etat de la Barre b dans la fenetre."""
    global _t_maj
    if _dlg is None:
        return
    now = time.time()
    if not force and now - _t_maj < 0.05:
        return
    _t_maj = now
    try:
        _dlg.maximumValue = max(1, b.total)
        _dlg.message = _texte(b)
        _dlg.progressValue = min(b.valeur, max(1, b.total))
    except Exception:
        pass


class Barre:
    def __init__(self, titre, message='', total=0, delai=DELAI):
        self.titre = titre
        self.message = message or 'Calcul en cours...'
        self.total = max(0, int(total))
        self.valeur = 0
        self.delai = delai
        self._ouverte = False

    # --- cycle de vie ---------------------------------------------------------
    def ouvrir(self):
        """Comme 'with', pour un bloc deja protege par un try/finally qui
        appelle fin()."""
        return self.__enter__()

    def __enter__(self):
        global _dlg
        _pile.append(self)
        self._ouverte = True
        if _dlg is None:
            try:
                ui = adsk.core.Application.get().userInterface
                d = ui.createProgressDialog()
                d.isCancelButtonShown = False
                d.isBackgroundTranslucent = False
                d.show(self.titre, _texte(self), 0, max(1, self.total), int(self.delai))
                _dlg = d
            except Exception:
                _dlg = None
        else:
            _appliquer(self)
        return self

    def __exit__(self, *exc):
        self.fin()
        return False

    def fin(self):
        """Ferme ce bloc (a appeler AVANT un messageBox de resultat) : la
        fenetre disparait si c'etait le dernier bloc ouvert."""
        global _dlg
        if not self._ouverte:
            return
        self._ouverte = False
        if self in _pile:
            _pile.remove(self)
        if _pile:
            _appliquer(_pile[-1])
        elif _dlg is not None:
            try:
                _dlg.hide()
                # Fermee avant son DELAI, la fenetre s'affichait quand meme a
                # la fin du delai et restait ouverte (hide() n'annule pas le
                # minuteur ; vue par Maxence sous la fenetre d'info de
                # Calpinage, 2026-10-12). reset() l'annule (mesure).
                _dlg.reset()
            except Exception:
                pass
            _dlg = None

    # --- mise a jour ----------------------------------------------------------
    def avance(self, n=1, message=None):
        self.valeur += n
        if message:
            self.message = message
        if _pile and _pile[-1] is self:
            _appliquer(self, force=bool(message))

    def etape(self, message, valeur=None, total=None):
        """Nouvelle phase : texte, et eventuellement nouvelle valeur/total."""
        if total is not None:
            self.total = max(0, int(total))
        if valeur is not None:
            self.valeur = valeur
        self.message = message
        if _pile and _pile[-1] is self:
            _appliquer(self)


def avance(n=1, message=None):
    """Avance la Barre ouverte (sans effet s'il n'y en a pas)."""
    if _pile:
        _pile[-1].avance(n, message)


def etape(message, valeur=None, total=None):
    """Nouvelle phase pour la Barre ouverte (sans effet s'il n'y en a pas)."""
    if _pile:
        _pile[-1].etape(message, valeur, total)


def fermer_tout():
    """Filet de securite (stop() d'un add-in) : ferme la fenetre quoi qu'il
    arrive."""
    global _dlg
    del _pile[:]
    if _dlg is not None:
        try:
            _dlg.hide()
            _dlg.reset()
        except Exception:
            pass
        _dlg = None
