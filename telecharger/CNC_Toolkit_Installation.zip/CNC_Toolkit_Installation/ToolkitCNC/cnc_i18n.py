# ---------------------------------------------------------------------------
# Langue de CNC Toolkit (FR / EN) - demande de l'utilisateur le 2026-10-13 :
# "une version anglaise de tout CNC Toolkit, avec deux petits drapeaux sur
# la fenetre CNC Toolkit pour changer".
#
# PRINCIPE : le code des outils reste ecrit en francais et n'est PAS
# duplique. Les textes sont traduits au moment ou ils partent vers l'ecran,
# a quelques points de passage de l'API Fusion (messageBox, noms et
# infobulles des champs de dialogue, listes deroulantes, boutons du ruban,
# fenetre de progression). installer() remplace ces methodes de adsk.core
# par une enveloppe qui appelle t() ; en francais (langue par defaut)
# l'enveloppe rend le texte tel quel. La palette HTML recoit le meme
# dictionnaire (payload()) et traduit sa page elle-meme (palette.html,
# bloc "Langue").
#
# Les textes lus en retour par le code (ListItem.name compare a 'Languette',
# 'Corps'...) sont remis en francais a la lecture, pour que le comportement
# des outils ne change jamais avec la langue.
#
# Dictionnaire : cnc_i18n_en.py (texte francais exact -> anglais). "{0}",
# "{1}"... = morceau variable (nombre, nom de piece). Un texte absent du
# dictionnaire reste en francais.
#
# Choix memorise dans cnc_langue.json (dossier ToolkitCNC).
# ---------------------------------------------------------------------------
import adsk.core
import os, re, json

_DIR = os.path.dirname(os.path.abspath(__file__))
FICHIER = os.path.join(_DIR, 'cnc_langue.json')
LANGUES = ('fr', 'en')

_lang = None
_exact = {}      # texte FR (sans espaces autour) -> EN
_motifs = []     # (regex, gabarit EN)
_rev = {}        # EN produit -> FR (lecture en retour par le code)
_charge = False


def _charger_dico():
    global _charge, _exact, _motifs
    if _charge:
        return
    try:
        import importlib, sys
        if _DIR not in sys.path:
            sys.path.append(_DIR)
        mod = sys.modules.get('cnc_i18n_en')
        if mod is None:
            import cnc_i18n_en as mod
        en = dict(mod.EN)
    except Exception:
        en = {}
    exact, motifs = {}, []
    for fr, tr in en.items():
        if not fr or not tr:
            continue
        k = fr.strip()
        v = tr.strip()
        if '{0}' in k:
            motifs.append((k, v))
        else:
            exact[k] = v
            # "Erreur xxx :" suivi d'un detail colle sur la meme ligne
            if k.endswith(':'):
                motifs.append((k + ' {0}', v + ' {0}'))
            # " corps selectionne(s)" colle derriere un nombre
            if fr.startswith(' ') and not fr.endswith(' '):
                motifs.append(('{0} ' + k, '{0} ' + v))
    comp = []
    for k, v in motifs:
        litteral = len(re.sub(r'\{\d+\}', '', k))
        rx = re.escape(k)
        rx = re.sub(r'\\\{(\d+)\\\}', lambda m: '(?P<g%s>.+?)' % m.group(1), rx)
        try:
            comp.append((litteral, re.compile('^' + rx + '$', re.S), v))
        except Exception:
            pass
    comp.sort(key=lambda x: -x[0])
    _exact = exact
    _motifs = [(r, v) for _, r, v in comp]
    _charge = True


def langue():
    global _lang
    if _lang is None:
        _lang = 'fr'
        try:
            with open(FICHIER, 'r', encoding='utf-8') as f:
                l = json.load(f).get('langue', 'fr')
            if l in LANGUES:
                _lang = l
        except Exception:
            pass
    return _lang


def definir_langue(l):
    global _lang
    if l not in LANGUES:
        return
    _lang = l
    try:
        with open(FICHIER, 'w', encoding='utf-8') as f:
            json.dump({'langue': l}, f)
    except Exception:
        pass
    rafraichir_ruban()


def _tr_ligne(s, prof):
    if not s or not s.strip():
        return s
    debut = s[:len(s) - len(s.lstrip())]
    fin = s[len(s.rstrip()):]
    c = s.strip()
    r = _exact.get(c)
    if r is None:
        for rx, v in _motifs:
            m = rx.match(c)
            if m:
                g = m.groupdict()
                vals = {}
                for k, x in g.items():
                    vals[k[1:]] = _t(x, prof + 1) if prof < 2 else x
                r = re.sub(r'\{(\d+)\}', lambda mm: vals.get(mm.group(1), mm.group(0)), v)
                break
    if r is None:
        return s
    return debut + r + fin


_SEP = re.compile(r'(<[^>]+>|\n|&nbsp;)')


def _t(s, prof=0):
    r = _tr_ligne(s, prof)
    if r is not s and r != s:
        return r
    # Texte compose : traduit morceau par morceau (lignes, balises HTML).
    if '\n' in s or '<' in s or '&nbsp;' in s:
        morceaux = _SEP.split(s)
        sortie = [m if (i % 2 == 1) else _tr_ligne(m, prof) for i, m in enumerate(morceaux)]
        return ''.join(sortie)
    return s


def t(s):
    """Texte s (francais) dans la langue choisie."""
    try:
        if not isinstance(s, str) or langue() == 'fr':
            return s
        _charger_dico()
        r = _t(s)
        if r != s:
            if len(_rev) > 5000:
                _rev.clear()
            _rev[r] = s
        return r
    except Exception:
        return s


_rev_dico = None


def fr(s):
    """Inverse de t() pour un texte relu par le code (ListItem.name...)."""
    global _rev_dico
    try:
        if not isinstance(s, str) or (langue() == 'fr' and not _rev):
            return s
        if s in _rev:
            return _rev[s]
        if _rev_dico is None:
            _charger_dico()
            _rev_dico = {v: k for k, v in _exact.items() if v != k}
        return _rev_dico.get(s, s)
    except Exception:
        return s


def payload():
    """Dictionnaire envoye a la palette HTML (palette.html, bloc Langue)."""
    try:
        import cnc_i18n_en as mod
        en = mod.EN
    except Exception:
        en = {}
    return {'langue': langue(), 'en': en}


# ---------------------------------------------------------------------------
# Points de passage de l'API Fusion
# ---------------------------------------------------------------------------
# Index (apres self) des arguments texte a traduire, par methode.
_ARGS_INPUTS = {
    'addTextBoxCommandInput': (1, 2),
    'addSelectionInput': (1, 2),
    'addStringValueInput': (1,),
}
_KW_TEXTE = ('name', 'formattedText', 'commandPrompt', 'text', 'title', 'tooltip', 'message')

# Boutons crees par les outils : id -> (nom FR, infobulle FR), pour
# renommer le ruban quand on change de langue.
_boutons = {}


def _enveloppe(orig, idx):
    def f(self, *args, **kw):
        try:
            if langue() != 'fr':
                args = list(args)
                for i in idx:
                    if i < len(args) and isinstance(args[i], str):
                        args[i] = t(args[i])
                for k in _KW_TEXTE:
                    if isinstance(kw.get(k), str):
                        kw[k] = t(kw[k])
        except Exception:
            pass
        return orig(self, *args, **kw)
    f._cnc_orig = orig
    return f


def _enveloppe_bouton(orig):
    def f(self, *args, **kw):
        try:
            a = list(args)
            if len(a) >= 2 and isinstance(a[0], str):
                _boutons[a[0]] = (a[1], a[2] if len(a) > 2 and isinstance(a[2], str) else '')
            if langue() != 'fr':
                for i in (1, 2):
                    if i < len(a) and isinstance(a[i], str):
                        a[i] = t(a[i])
            args = a
        except Exception:
            pass
        return orig(self, *args, **kw)
    f._cnc_orig = orig
    return f


class _Prop(property):
    """property qui garde la propriete d'origine (pour desinstaller)."""
    pass


def _patch_prop(cls, nom, ecrire=True, relire=False, rec=None):
    p = cls.__dict__.get(nom)
    if not isinstance(p, property):
        return
    fget, fset = p.fget, p.fset
    def g(self, _fget=fget):
        v = _fget(self)
        return fr(v)
    def s(self, v, _fset=fset):
        if isinstance(v, str):
            v = t(v)
        return _fset(self, v)
    np = _Prop(g if (relire and fget) else fget, s if (ecrire and fset) else fset, p.fdel, p.__doc__)
    np._cnc_orig = p
    setattr(cls, nom, np)
    rec.append((cls, nom, p))


def installer():
    """Pose les enveloppes de traduction (sans effet en double)."""
    desinstaller()
    rec = []
    core = adsk.core
    try:
        ci = core.CommandInputs
        for nom, val in list(ci.__dict__.items()):
            if nom.startswith('add') and callable(val):
                setattr(ci, nom, _enveloppe(val, _ARGS_INPUTS.get(nom, (1,))))
                rec.append((ci, nom, val))
    except Exception:
        pass
    for cls_nom, meth, idx in (
            ('UserInterface', 'messageBox', (0, 1)),
            ('UserInterface', 'inputBox', (0, 2)),
            ('ListItems', 'add', (0,)),
            ('ProgressDialog', 'show', (0, 1))):
        try:
            cls = getattr(core, cls_nom)
            val = cls.__dict__.get(meth)
            if val is not None:
                setattr(cls, meth, _enveloppe(val, idx))
                rec.append((cls, meth, val))
        except Exception:
            pass
    try:
        cls = core.CommandDefinitions
        val = cls.__dict__.get('addButtonDefinition')
        if val is not None:
            cls.addButtonDefinition = _enveloppe_bouton(val)
            rec.append((cls, 'addButtonDefinition', val))
    except Exception:
        pass
    # Proprietes texte ecrites par les outils (traduites a l'ecriture) et
    # relues par le code (remises en francais a la lecture).
    ecrites = ('tooltip', 'tooltipDescription', 'formattedText', 'text',
               'commandPrompt', 'okButtonText', 'cancelButtonText', 'message', 'title')
    classes = []
    for nom in dir(core):
        cls = getattr(core, nom, None)
        if isinstance(cls, type) and (nom.endswith('CommandInput') or nom in (
                'CommandInput', 'Command', 'ProgressDialog', 'FileDialog', 'FolderDialog', 'ListItem')):
            classes.append(cls)
    for cls in classes:
        for p in ecrites:
            if cls.__name__ == 'Command' and p not in ('okButtonText', 'cancelButtonText'):
                continue
            if p == 'message' and cls.__name__ != 'ProgressDialog':
                continue
            if p == 'title' and cls.__name__ not in ('ProgressDialog', 'FileDialog', 'FolderDialog'):
                continue
            try:
                _patch_prop(cls, p, ecrire=True, relire=False, rec=rec)
            except Exception:
                pass
        if cls.__name__ in ('ListItem', 'CommandInput'):
            try:
                _patch_prop(cls, 'name', ecrire=False, relire=True, rec=rec)
            except Exception:
                pass
    core._cnc_i18n_rec = rec


def desinstaller():
    core = adsk.core
    rec = getattr(core, '_cnc_i18n_rec', None)
    if not rec:
        return
    for cls, nom, val in reversed(rec):
        try:
            setattr(cls, nom, val)
        except Exception:
            pass
    core._cnc_i18n_rec = []


def rafraichir_ruban():
    """Renomme les boutons du ruban des outils dans la langue choisie."""
    try:
        ui = adsk.core.Application.get().userInterface
    except Exception:
        return
    for cid, (nom, info) in list(_boutons.items()):
        try:
            cd = ui.commandDefinitions.itemById(cid)
            if cd is None:
                continue
            try:
                cd.controlDefinition.name = t(nom)
            except Exception:
                pass
            if info:
                try:
                    cd.tooltip = t(info)
                except Exception:
                    pass
        except Exception:
            pass


def memoriser_boutons():
    """Releve les boutons des outils deja crees avant installer() (add-ins
    demarres avant CNC Toolkit), en francais, pour rafraichir_ruban()."""
    try:
        ui = adsk.core.Application.get().userInterface
        _charger_dico()
    except Exception:
        return
    for cid in IDS_BOUTONS:
        if cid in _boutons:
            continue
        try:
            cd = ui.commandDefinitions.itemById(cid)
            if cd is None:
                continue
            nom = fr(cd.name)
            info = fr(cd.tooltip or '')
            _boutons[cid] = (nom, info)
        except Exception:
            pass


IDS_BOUTONS = (
    'ToolkitCNC_LauncherCmd', 'ExtrusionCNCCmd', 'ReseauTrajectoireCNCCmd',
    'GravureCNCCmd', 'TenonCNCCmd', 'MortaiseCNCCmd', 'MargeCNCCmd',
    'ModifMargeCmd', 'MiseAJourCNCCmd', 'ChantInterieur_Cmd',
    'EntailleCNCCmd', 'EntailleCNCEditCmd', 'JonctionCNCCmd', 'DogboneCNCCmd',
    'CalpinageCNCCmd', 'SelectFaceCNC_Cmd', 'DebugComposantCmd', 'PurgeCNCCmd',
    'TenonPurgeCmd', 'TenonDeleteSelCmd', 'TenonRepairCmd',
)
