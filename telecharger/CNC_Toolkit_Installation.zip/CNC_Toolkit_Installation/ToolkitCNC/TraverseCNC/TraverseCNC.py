import adsk.core
import adsk.fusion
import traceback
import os
import sys
import json
import math
import time

# Apercu fluide partage (cnc_apercu_fluide.py a la racine de ToolkitCNC) : pastilles glissees par la
# souris, hors du cycle de commande Fusion (mesure du 2026-11-04 : 14 ms par image au lieu de 38 ms).
try:
    _RACINE_TK = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if _RACINE_TK not in sys.path:
        sys.path.insert(0, _RACINE_TK)
    import cnc_apercu_fluide as _caf
except Exception:
    _caf = None

# ---------------------------------------------------------------------------
# Traverse de renfort CNC (ebauche v0.1, 2026-11-03)
#
# Une traverse est une planche droite (section epaisseur x hauteur) tendue
# entre DEUX CHEMINS (aretes ou courbes d'esquisse) :
#   - chemin de debut + chemin de fin : un point glissant (fleche native,
#     comme Reseau CNC) place chaque extremite sur son chemin ;
#   - faces debut (2) / fin (2), optionnelles : le milieu des deux
#     faces centre l'extremite correspondante (decalage dans l'epaisseur) ;
#   - hauteur : automatique (rayon jusqu'au premier corps au-dessus ou en
#     dessous, selon la fleche haut / bas) ou saisie a la main.
# Plusieurs traverses : fenetre « NOMBRE DE TRAVERSES » (+ / -) en bas a
# gauche de la vue, une ligne « TRAVERSE n » par traverse (ligne active =
# cadre bleu). Modele des fenetres : ReseauTrajectoireCNC.py (_png_ligne...).
# Aperçus : CustomGraphics uniquement (orange (255,90,0), rouge si invalide).
# Resultat : un corps par traverse (BaseFeature en conception parametrique),
# groupe replie « Traverse CNC » dans la chronologie.
# ---------------------------------------------------------------------------

_app = None
_ui = None
_handlers = []

CMD_ID = 'TraverseCNCCmd'
COMMAND_NAME = 'Traverse de renfort CNC'
COMMAND_DESC = 'Cree des traverses de renfort entre deux chemins, centrees sur les corps du debut et de la fin'
PANEL_ID = 'SolidCreatePanel'
GROUPE_NOM = 'Traverse CNC'
NB_MAX = 20

_ADDIN_DIR = os.path.dirname(os.path.abspath(__file__))
PREFS_FILE = os.path.join(_ADDIN_DIR, 'traverse_prefs.json')
DEFAULT_PREFS = {'epaisseur_mm': 18.0, 'hauteur_mm': 100.0, 'haut': True, 'mode': 'libre', 'long_mm': 500.0}
# Modes (2026-11-05) : 'libre' = entre deux chemins (v0.x) ; 'perp' = un chemin, traverse perpendiculaire au
# chemin, horizontale, longueur jusqu'au premier corps en face (ou saisie) ; 'reseau' = reseau lineaire de
# traverses perpendiculaires sur un chemin (chemin entier avec marges, espacement ou etendue).
MODES = ('libre', 'perp', 'reseau')
R_TYPES = ('chemin', 'entre', 'espacement', 'etendue')
R_MARGES = ('chemin', 'entre')          # repartitions reglees par les deux marges (pastilles aux bouts)
R_ALIGNS = ('debut', 'centre', 'fin')
R_NMAX = 50
# Reglages communs a toutes les traverses : tenons aux deux bouts, decaisse central
CFG_DEFAUT = {'ten_deb': False, 'ten_fin': False, 'ten_haut': True, 'ten_bas': True, 'ten_n': 1,
              'ten_len_mm': 30.0, 'ten_h_auto': True, 'ten_h_mm': 18.0,
              'ten_edge_mm': 10.0, 'ten_centrer': True,
              'dec_on': False, 'dec_auto': True, 'dec_dist_mm': 100.0, 'dec_dist2_mm': 100.0, 'dec_h_mm': 20.0, 'dec_arc': True}
PREFS_VER = 4
_cfg = dict(CFG_DEFAUT)

ORANGE = (255, 90, 0, 255)
ROUGE = (220, 30, 30, 255)
CYAN = (0, 190, 255, 255)           # decaisse central
ORANGE_AUT = (255, 165, 45, 255)    # traverses non selectionnees : orange clair, trait fin (comme Reseau CNC)
CYAN_AUT = (120, 205, 235, 255)


def _tt(s):
    """Texte dans la langue choisie (cnc_i18n est charge par ToolkitCNC)."""
    try:
        m = sys.modules.get('cnc_i18n')
        return m.t(s) if m is not None else s
    except Exception:
        return s


def _log(msg):
    try:
        with open(os.path.join(_ADDIN_DIR, 'traverse_journal.txt'), 'a', encoding='utf-8') as f:
            f.write(time.strftime('%H:%M:%S ') + msg + '\n')
    except Exception:
        pass


def load_prefs():
    p = dict(DEFAULT_PREFS)
    p.update(CFG_DEFAUT)
    try:
        with open(PREFS_FILE, 'r', encoding='utf-8') as f:
            q = json.load(f)
        if q.get('ver', 0) < PREFS_VER:                 # anciens reglages de tenons (v0.3) : autre modele
            for k in list(q):
                if k.startswith('ten_'):
                    del q[k]
        p.update(q)
    except Exception:
        pass
    return p


def save_prefs(p):
    try:
        with open(PREFS_FILE, 'w', encoding='utf-8') as f:
            json.dump(p, f)
    except Exception:
        pass


# --- Etat : une entree par traverse -------------------------------------------

_trs = []                  # traverses
_cur = {'i': 0, 'calcs': []}
_en_cours = {'v': False}   # evite la reentrance des evenements provoques par nos ecritures
_drag = {'k': None}
_souris = {'pos': None, 'vp': None, 't': 0.0}
_cache_traj = {}
_bloc = {'t': 0.0, 'sel': None}
_edition = {'v': None}           # modification demandee par l'historique : {blob, anciens}
ATTR_G, ATTR_N = 'TraverseCNC', 'edit'
CLES_TR = ('c1', 'c2', 'fa', 'fv', 's1', 's2', 'haut', 'auto', 'h_mm',
           'mode', 'cote', 'l_auto', 'l_mm', 'r_n', 'r_type', 'r_dist', 'r_align', 'r_m1', 'r_m2')
ACTION_ID = 'TraverseCNC_action'
_action = {'evt': None, 'h': None}
SEL_IDS = ('chemin1', 'chemin2', 'faces_amont', 'faces_aval')
CLES_SEL = {'chemin1': 'c1', 'chemin2': 'c2', 'faces_amont': 'fa', 'faces_aval': 'fv'}


def _nouvelle(p=None):
    p = p or load_prefs()
    return {'c1': [], 'c2': [], 'fa': [], 'fv': [], 's1': 0.5, 's2': 0.5,
            'haut': bool(p['haut']), 'auto': True, 'h_mm': float(p['hauteur_mm']),
            'mode': p.get('mode') if p.get('mode') in MODES else 'libre', 'cote': False,
            'l_auto': True, 'l_mm': float(p.get('long_mm', 500.0)),
            'r_n': int(p.get('r_n', 3)), 'r_type': p.get('r_type', 'chemin') if p.get('r_type') in R_TYPES else 'chemin',
            'r_dist': float(p.get('r_dist', 300.0)), 'r_align': p.get('r_align', 'debut') if p.get('r_align') in R_ALIGNS else 'debut',
            'r_m1': float(p.get('r_m1', 0.0)), 'r_m2': float(p.get('r_m2', 0.0)),
            'sig': None, 'calc': None}


def _actif():
    if not _trs:
        _trs.append(_nouvelle())
    _cur['i'] = max(0, min(_cur['i'], len(_trs) - 1))
    return _trs[_cur['i']]


def _design():
    return adsk.fusion.Design.cast(_app.activeProduct)


_cf = {'def': None, 'h': None, 'ignores': set(), 'creation': False}   # fonction personnalisee (recalcul auto)
_cache_ent = {}            # jeton -> entite (findEntityByToken est lent : appele a chaque mouvement sinon)
_cache_faces = {}          # jetons des 2 faces -> (centre, normale) dans le monde


def _ents(design, tokens):
    res = []
    for tok in tokens:
        e = _cache_ent.get(tok)
        if e is None or not getattr(e, 'isValid', True):
            e = None
            try:
                r = design.findEntityByToken(tok)
                if r:
                    e = r[0]
                    _cache_ent[tok] = e
            except Exception:
                pass
        if e is not None:
            res.append(e)
    return res


def _monde(ent, p=None, v=None):
    """Point (p) ou vecteur (v) natif d'une entite d'un composant -> espace du document."""
    ctx = getattr(ent, 'assemblyContext', None)
    if p is not None:
        q = p.copy()
        if ctx is not None:
            q.transformBy(ctx.transform2)
        return (q.x, q.y, q.z)
    w = v.copy()
    if ctx is not None:
        w.transformBy(ctx.transform2)
    return (w.x, w.y, w.z)


def _face_monde(f):
    """(centre, normale unitaire, origine du plan) d'une face PLANE dans l'espace du document.
    La geometrie d'une face d'un composant est lue sur l'objet natif puis transformee
    (la lire sur le proxy donnait un centrage faux, retour du 2026-11-03)."""
    n = f.nativeObject if getattr(f, 'assemblyContext', None) is not None else f
    g = n.geometry
    if not isinstance(g, adsk.core.Plane):
        return None
    c = _monde(f, p=n.centroid)
    nv = _v_norm(_monde(f, v=g.normal))
    o = _monde(f, p=g.origin)
    return c, nv, o


# --- Geometrie ----------------------------------------------------------------

def _courbe_monde(ent):
    n = ent.nativeObject if getattr(ent, 'assemblyContext', None) is not None else ent
    if isinstance(n, adsk.fusion.BRepEdge):
        g = n.geometry.copy()
    elif isinstance(n, adsk.fusion.SketchCurve):
        g = n.worldGeometry.copy()
    else:
        return None
    ctx = getattr(ent, 'assemblyContext', None)
    if ctx is not None:
        g.transformBy(ctx.transform2)
    return g


def _echantillonner(ent, n=120):
    c = _courbe_monde(ent)
    if c is None:
        return []
    if isinstance(c, adsk.core.Line3D):
        a, b = c.startPoint, c.endPoint
        return [(a.x, a.y, a.z), (b.x, b.y, b.z)]
    ev = c.evaluator
    ok, p0, p1 = ev.getParameterExtents()
    pts = []
    for k in range(n + 1):
        ok, p = ev.getPointAtParameter(p0 + (p1 - p0) * k / n)
        if ok:
            pts.append((p.x, p.y, p.z))
    return pts


def _d3(a, b):
    return math.sqrt((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 + (a[2] - b[2]) ** 2)


class _Trajet:
    """Chemin echantillonne par abscisse curviligne (fraction 0..1)."""

    def __init__(self, ents):
        segs = [s for s in (_echantillonner(e) for e in ents) if len(s) >= 2]
        if not segs:
            raise ValueError('chemin vide')
        chain = segs.pop(0)
        while segs:
            best = None
            for i, s in enumerate(segs):
                for d, mode, rev in ((_d3(chain[-1], s[0]), 'a', False), (_d3(chain[-1], s[-1]), 'a', True),
                                     (_d3(s[-1], chain[0]), 'p', False), (_d3(s[0], chain[0]), 'p', True)):
                    if best is None or d < best[0]:
                        best = (d, i, mode, rev)
            _d, i, mode, rev = best
            s = segs.pop(i)
            seg = s[::-1] if rev else s
            chain = chain + seg[1:] if mode == 'a' else seg[:-1] + chain
        self.pts = chain
        self.cum = [0.0]
        for i in range(1, len(chain)):
            self.cum.append(self.cum[-1] + _d3(chain[i - 1], chain[i]))
        self.longueur = self.cum[-1]
        if self.longueur < 1e-9:
            raise ValueError('chemin nul')

    def at(self, f):
        """(point, tangente) en flottants a la fraction f."""
        f = max(0.0, min(1.0, f))
        s = f * self.longueur
        lo, hi = 0, len(self.cum) - 1
        while hi - lo > 1:
            m = (lo + hi) // 2
            if self.cum[m] <= s:
                lo = m
            else:
                hi = m
        a, b = self.pts[lo], self.pts[lo + 1]
        L = self.cum[lo + 1] - self.cum[lo] or 1.0
        u = (s - self.cum[lo]) / L
        p = tuple(a[k] + (b[k] - a[k]) * u for k in range(3))
        t = tuple((b[k] - a[k]) / L for k in range(3))
        return p, t

    def frac_point(self, q):
        """Fraction du chemin au point le plus proche de q (point clique), affinee sur le segment."""
        pts = self.pts
        best = min(range(len(pts)), key=lambda i: _d3(pts[i], q))
        sb, db = self.cum[best], _d3(pts[best], q)
        for j in (best - 1, best):
            if 0 <= j < len(pts) - 1:
                a, b = pts[j], pts[j + 1]
                e = _v_sub(b, a)
                e2 = _v_dot(e, e)
                if e2 < 1e-18:
                    continue
                u = max(0.0, min(1.0, _v_dot(_v_sub(q, a), e) / e2))
                dd = _d3(_v_add(a, _v_mul(e, u)), q)
                if dd < db:
                    db, sb = dd, self.cum[j] + u * (self.cum[j + 1] - self.cum[j])
        return sb / self.longueur

    def proche_3d(self, q):
        best = min(range(len(self.pts)), key=lambda i: _d3(self.pts[i], q))
        return self.cum[best] / self.longueur


def _traj(ents_tokens, design):
    cle = tuple(ents_tokens)
    if cle not in _cache_traj:
        if len(_cache_traj) > 40:
            _cache_traj.clear()
        try:
            _cache_traj[cle] = _Trajet(_ents(design, ents_tokens))
        except ValueError:
            for tok in ents_tokens:              # entite perdue (chronologie reculee, recalcul) : on relit les jetons
                _cache_ent.pop(tok, None)
            try:
                _cache_traj[cle] = _Trajet(_ents(design, ents_tokens))
            except ValueError:
                _log('chemin introuvable : %d jeton(s), resolus=%d' % (len(ents_tokens), len(_ents(design, ents_tokens))))
                raise
    return _cache_traj[cle]


def _v_sub(a, b): return (a[0] - b[0], a[1] - b[1], a[2] - b[2])
def _v_add(a, b): return (a[0] + b[0], a[1] + b[1], a[2] + b[2])
def _v_mul(a, k): return (a[0] * k, a[1] * k, a[2] * k)
def _v_dot(a, b): return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
def _v_cross(a, b): return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])
def _v_norm(a):
    n = math.sqrt(_v_dot(a, a))
    return (a[0] / n, a[1] / n, a[2] / n) if n > 1e-12 else (0.0, 0.0, 0.0)


def _vers_haut():
    try:
        o = _app.preferences.generalPreferences.defaultModelingOrientation
        if o == adsk.core.DefaultModelingOrientations.YUpModelingOrientation:
            return (0.0, 1.0, 0.0)
    except Exception:
        pass
    return (0.0, 0.0, 1.0)


def _centre_faces(faces):
    """(centre, normale) du couple de faces ; None si une face n'est pas plane."""
    cle = tuple(f.entityToken for f in faces)
    r = _cache_faces.get(cle)
    if r is None:
        i0, i1 = _face_monde(faces[0]), _face_monde(faces[1])
        if i0 is None or i1 is None:
            return None
        c0, c1 = i0[0], i1[0]
        r = (_v_mul(_v_add(c0, c1), 0.5), i0[1])
        _cache_faces[cle] = r
    return r


def _centrer(p, faces):
    """Deux faces : l'extremite est ramenee au milieu des deux faces (dans leur normale)."""
    if len(faces) != 2:
        return p
    r = _centre_faces(faces)
    if r is None:
        return p
    c, n = r
    return _v_add(p, _v_mul(n, _v_dot(_v_sub(c, p), n)))


def _dist_rayon(o, d, f):
    """Distance de o a la face f le long de d (plan : exacte ; autre surface : approchee par la boite)."""
    i = None
    try:
        i = _face_monde(f)
    except Exception:
        pass
    if i is not None:
        _c, n, po = i
        den = _v_dot(n, d)
        if abs(den) < 1e-9:
            return None
        t = _v_dot(_v_sub(po, (o.x, o.y, o.z)), n) / den
        return t if t > 0 else None
    bb = f.boundingBox
    ts = []
    for x in (bb.minPoint.x, bb.maxPoint.x):
        for y in (bb.minPoint.y, bb.maxPoint.y):
            for z in (bb.minPoint.z, bb.maxPoint.z):
                ts.append((x - o.x) * d[0] + (y - o.y) * d[1] + (z - o.z) * d[2])
    t = min(ts)
    return t if max(ts) > 0 else None


def _rayon(design, o, dv):
    """[(face, distance)] des faces touchees par le rayon parti de o (Point3D) dans la direction dv. Distance
    exacte lue sur les points d'impact de Fusion (faces courbes, splines comprises) ; l'ancienne approximation
    par la boite d'une face courbe donnait des largeurs fausses (FS210, 2026-11-05). None si echec."""
    hp = adsk.core.ObjectCollection.create()
    try:
        faces = design.rootComponent.findBRepUsingRay(o, adsk.core.Vector3D.create(dv[0], dv[1], dv[2]),
                                                      adsk.fusion.BRepEntityTypes.BRepFaceEntityType, -1.0, True, hp)
    except Exception:
        return None
    if faces is None:
        return None
    exact = hp.count == faces.count
    out = []
    for i in range(faces.count):
        f = faces.item(i)
        if _cf['ignores']:
            try:
                if f.body.entityToken in _cf['ignores']:
                    continue                 # recalcul automatique : les anciennes traverses ne comptent pas
            except Exception:
                pass
        if exact:
            h = hp.item(i)
            t = (h.x - o.x) * dv[0] + (h.y - o.y) * dv[1] + (h.z - o.z) * dv[2]
            t = t if t > 0 else None
        else:
            t = _dist_rayon(o, dv, f)
        out.append((f, t))
    return out


def _premier_corps(design, b, d, contient, diag):
    """(distance, corps) du premier corps rencontre depuis le point b dans la direction d.
    Sont ignores les corps qui contiennent le point de depart (celui sur lequel repose le chemin)."""
    P3 = adsk.core.Point3D.create
    o = P3(b[0], b[1], b[2])
    hits = _rayon(design, o, d)
    if hits is None:
        diag.append('rayon sans resultat')
        return None
    diag.append('%d faces' % len(hits))
    best = None
    for i, (f, dist) in enumerate(hits):
        if dist is None or dist < 1e-3:
            diag.append('  face %d : dist=%s' % (i, None if dist is None else round(dist, 3)))
            continue
        body = f.body
        k = (body.entityToken, round(b[0], 4), round(b[1], 4), round(b[2], 4))
        if k not in contient:
            contient[k] = body.pointContainment(o) != adsk.fusion.PointContainment.PointOutsidePointContainment
        diag.append('  face %d : dist=%.3f corps=%s contient=%s' % (i, dist, body.name, contient[k]))
        if contient[k] or (best is not None and dist >= best[0]):
            continue
        best = (dist, body)
    return best


def _hauteur_auto(design, bases, d, ignorer=None):
    """Distance jusqu'au premier corps rencontre en partant de plusieurs points de base ;
    le plus proche des impacts est retenu, un point sans impact est ignore."""
    best = None
    contient = {}
    diag = []
    for b in bases:
        r = _premier_corps(design, b, d, contient, diag)
        if r is not None and (best is None or r[0] < best):
            best = r[0]
    if best is None:
        _log('hauteur auto : aucun impact. direction=%s bases=%s\n%s' % (
            [round(x, 3) for x in d], [[round(x, 2) for x in b] for b in bases], '\n'.join(diag[:40])))
    return best


def _etendue_corps(body, o, ah, sens):
    """Plus grande distance, depuis o et le long de sens*ah, atteinte par les sommets du corps."""
    m = 0.0
    try:
        for v in body.vertices:
            g = v.geometry
            m = max(m, sens * _v_dot(_v_sub((g.x, g.y, g.z), o), ah))
    except Exception:
        pass
    return m


def _epaisseur_corps(design, o, dv):
    """Epaisseur (cm) du corps qui contient le point o, le long de dv : distance jusqu'a la face de sortie."""
    P3 = adsk.core.Point3D.create
    p = P3(o[0], o[1], o[2])
    hits = _rayon(design, p, dv)
    if hits is None:
        return None
    best = None
    for f, dist in hits:
        if dist is None or dist < 1e-4 or (best is not None and dist >= best):
            continue
        try:
            if f.body.pointContainment(p) == adsk.fusion.PointContainment.PointOutsidePointContainment:
                continue
        except Exception:
            continue
        best = dist
    return best


def _sortie_corps(design, body, q, dv, tmax):
    """Distance de q (dans body) a la vraie sortie de body le long de dv : premier impact apres lequel le point
    est hors du corps. Les faces traversees sans sortir (mortaise, autre corps, face interne) sont ignorees."""
    hits = _rayon(design, adsk.core.Point3D.create(*q), dv)
    if hits is None:
        return None
    ts = [t for _f, t in hits if t is not None and 1e-4 < t <= tmax]
    for t in sorted(set(round(x, 5) for x in ts)):
        pt = adsk.core.Point3D.create(*_v_add(q, _v_mul(dv, t + 0.03)))
        try:
            if body.pointContainment(pt) == adsk.fusion.PointContainment.PointOutsidePointContainment:
                return t
        except Exception:
            return None
    return None


def _largeur_platebande(design, o, ah, sens, d, dist, ep_haut, body=None, tmax=500.0):
    """Largeur de la plate-bande du corps du dessus au-dessus du bout o : depuis le bout, le long de la
    traverse (vers son milieu), distance jusqu'a la sortie de ce corps, mesuree au milieu de son epaisseur.
    Un cadre (plate-bande autour d'un vide) donne bien sa largeur, et chaque bout a la sienne. None si le
    corps du dessus ne passe pas au-dessus du bout."""
    dv = _v_mul(ah, sens)
    best = None
    for f in (0.5, 0.25, 0.75):                 # milieu de l'epaisseur, puis un peu plus haut / plus bas
        q = _v_add(_v_add(o, _v_mul(d, dist + max(0.01, (ep_haut or 0.2) * f))), _v_mul(dv, 0.01))
        w = _sortie_corps(design, body, q, dv, tmax) if body is not None else _epaisseur_corps(design, q, dv)
        if w is not None and w > 0.05:
            best = w + 0.01
            break
    return best


def _ctx_corps(design, p1, p2, ah, d):
    """Autour de chaque extremite : largeur du corps au-dessus (dist, le long de la traverse), epaisseur de
    ce corps (up) et du corps en dessous (dn). Valeurs en cm, None si introuvables."""
    contient, diag = {}, []
    out = {'dist': [None, None], 'up': [None, None], 'dn': [None, None]}
    nd = _v_mul(d, -1.0)
    eps = 0.002
    for k, (o, sens) in enumerate(((p1, 1.0), (p2, -1.0))):
        # le bout est souvent pile sur le bord exterieur de la forme : un rayon vertical parti de ce bord rate le
        # corps du dessus (vu sur FS210 : fin de chaque copie du reseau). On reessaie un peu vers l'interieur.
        r = None
        for inw in (0.0, 0.05, 0.2):
            r = _premier_corps(design, _v_add(o, _v_mul(ah, sens * inw)) if inw else o, d, contient, diag)
            if r is not None:
                break
        if r is not None:
            dist, body = r
            q = _v_add(o, _v_mul(d, dist + eps))
            e = _epaisseur_corps(design, q, d)
            out['up'][k] = (e + eps) if e else None
            w = _largeur_platebande(design, o, ah, sens, d, dist, e, body, _d3(p1, p2))   # plate-bande de ce bout
            if w is None:
                w = _etendue_corps(body, o, ah, sens)
            out['dist'][k] = w if w > 0 else None
        e = None
        for inw in (0.0, 0.05, 0.2):
            e = _epaisseur_corps(design, _v_add(_v_add(o, _v_mul(nd, eps)), _v_mul(ah, sens * inw)), nd)
            if e:
                break
        out['dn'][k] = (e + eps) if e else None
    return out


# --- Tenons (meme repartition que Tenons CNC : TenonCNC.compute_tenon_layout_1d) ----------

def _layout_1d(face_len, n, tlen, edge, centrer):
    """[(debut, largeur)] en cm le long du chant ; [] si le chant est trop court."""
    n = max(1, int(n))
    half = tlen / 2.0
    if centrer:
        if face_len <= n * tlen + 1e-6:
            return []
        gap = max(0.0, face_len - n * tlen) / (n + 1)
        centers = [gap + half + i * (tlen + gap) for i in range(n)]
    else:
        if face_len <= 2.0 * edge + tlen + 1e-6:
            return []
        c0, c1 = edge + half, face_len - edge - half
        if c0 >= c1 and n > 1:
            return []
        sp = (c1 - c0) / (n - 1) if n > 1 else 0.0
        centers = [c0 + i * sp for i in range(n)]
    return [(c - half, tlen) for c in centers]


def _coins(x0, x1, y0, y1, z0, z1):
    """8 coins d'une boite locale, dans l'ordre attendu par ARETES (x, puis z, puis y)."""
    return [(x, y, z) for x in (x0, x1) for z in (z0, z1) for y in (y0, y1)]


def _w(c, q):
    """Point local (x le long de la traverse, y vers la hauteur, z dans l'epaisseur) -> monde."""
    return tuple(c['p1'][i] + c['ah'][i] * q[0] + c['d'][i] * q[1] + c['lat'][i] * q[2] for i in range(3))


def _tenons_locaux(L, h, ep, cfg, dist, up, dn):
    """(boites locales, mise en page) des tenons de debut / fin. Chaque tenon est pose sur le champ
    superieur (y = h) et / ou inferieur (y = 0), centre dans la largeur du corps du bout (dist) ;
    sa hauteur est l'epaisseur du corps traverse (up / dn) ou la valeur saisie."""
    if not (cfg['ten_deb'] or cfg['ten_fin']) or not (cfg['ten_haut'] or cfg['ten_bas']):
        return [], None
    th = cfg['ten_h_mm'] / 10.0
    boites = []
    info = None
    e = ep / 2.0
    for k, flag in enumerate((cfg['ten_deb'], cfg['ten_fin'])):
        if not flag:
            continue
        seg = dist[k]
        # regle de Maxence (2026-11-05, 2e version) : tenon centre sur la plate-bande, le reste en plat de chaque
        # cote. Il ne grandit pas avec la plate-bande (coin, forme qui s'elargit) : au plus la longueur saisie
        # (30 mm) ; sur une plate-bande etroite il fait 5/12 de sa largeur (60 -> 25) pour ne pas la fragiliser.
        # Avec n tenons : meme regle par tenon, plats egaux entre eux.
        n = max(1, int(cfg['ten_n']))
        wd = min(cfg['ten_len_mm'] / 10.0, seg * 5.0 / (12.0 * n)) if seg else 0.0
        gap = (seg - n * wd) / (n + 1) if seg else 0.0
        lay = [(gap + i * (wd + gap), wd) for i in range(n)] if wd > 0.05 else []
        hu = up[k] if (cfg['ten_h_auto'] and up[k]) else th
        hd = dn[k] if (cfg['ten_h_auto'] and dn[k]) else th
        if info is None:
            info = {'face_len': seg, 'segs': lay, 'th': hu if cfg['ten_haut'] else hd, 'hu': hu, 'hd': hd}
        x0 = 0.0 if k == 0 else L - seg
        for st, wd in lay:
            if cfg['ten_haut']:
                boites.append((x0 + st, x0 + st + wd, h, h + hu, -e, e))
            if cfg['ten_bas']:
                boites.append((x0 + st, x0 + st + wd, -hd, 0.0, -e, e))
    return boites, info


# --- Decaisse central avec arcs ------------------------------------------------------------

def _decaisse(L, h, d1, d2, hd, arc=True):
    """Profil du decaisse du cote du corps au-dessus (y = h). arc : plancher a la profondeur R raccorde a
    chaque bout par un quart de cercle de rayon R (R = hauteur du decaisse, reduit s'il n'y a pas la
    place) ; sinon fond plat a parois droites. None si impossible."""
    if arc:
        R = min(hd, (L - d1 - d2) / 2.0, h * 0.9)
    else:
        R = min(hd, h * 0.9)
        if L - d1 - d2 < 0.5:
            return None
    if R < 0.2:
        return None
    if not arc:
        return {'R': R, 'arc': False, 'x1': d1, 'x2': L - d2, 'd1': d1, 'd2': d2,
                'pts': [(d1, h), (d1, h - R), (L - d2, h - R), (L - d2, h)], 'corners': [0, 1, 2, 3]}
    cx1, cx2 = d1 + R, L - d2 - R
    pts = []
    n = 10
    for k in range(n + 1):          # arc gauche : (d1, h) -> (d1 + R, h - R)
        a = math.pi + (math.pi / 2.0) * k / n
        pts.append((cx1 + R * math.cos(a), h + R * math.sin(a)))
    for k in range(n + 1):          # arc droit : (L - d2 - R, h - R) -> (L - d2, h)
        a = 1.5 * math.pi + (math.pi / 2.0) * k / n
        pts.append((cx2 + R * math.cos(a), h + R * math.sin(a)))
    return {'R': R, 'arc': True, 'cx1': cx1, 'cx2': cx2, 'x1': cx1, 'x2': cx2, 'd1': d1, 'd2': d2, 'pts': pts,
            'corners': [0, n, n + 1, 2 * n + 1]}


def _cfg_sig():
    return tuple(sorted(_cfg.items()))


def _geo(design, st, t, p1, p2, ep_cm, rapide, cfg, r):
    """Geometrie d'une traverse tendue de p1 a p2 (tous les modes) : complete r. st garde la derniere hauteur
    automatique et la mesure des corps des bouts ('h_auto', 'ctx') : la traverse elle-meme, ou une copie du
    reseau."""
    a = _v_sub(p2, p1)
    L = math.sqrt(_v_dot(a, a))
    up = _vers_haut()
    lat = _v_cross(a, up)
    if L < 1e-3:
        r['msg'] = 'LONG'
        return r
    if math.sqrt(_v_dot(lat, lat)) < 1e-6 * L:
        r['msg'] = 'ORIENT'
        return r
    ah = _v_norm(a)
    lat = _v_norm(lat)
    hd = _v_norm(_v_cross(lat, ah))
    if _v_dot(hd, up) < 0:
        hd = _v_mul(hd, -1)
    sg = 1.0 if t['haut'] else -1.0
    d = _v_mul(hd, sg)
    if t['auto'] and rapide and st.get('h_auto') is not None:
        h = st['h_auto']             # glisser d'une poignee : on garde la hauteur trouvee, recalculee au relachement
    elif t['auto']:
        bases = [_v_add(_v_mul(p1, 1.0 - u), _v_mul(p2, u)) for u in (0.0, 0.25, 0.5, 0.75, 1.0)]
        h = _hauteur_auto(design, bases, d)
        if h is None:
            h = st.get('h_auto')         # mesure ratee : on garde la derniere bonne (l'aperçu ne disparait plus)
        else:
            st['h_auto'] = h
    else:
        h = t['h_mm'] / 10.0
    if h is None or h <= 1e-3:
        r['msg'] = 'HAUT'
        return r
    r.update(ok=True, msg='OK', L=L, h=h, p1=p1, p2=p2, ah=ah, lat=lat, d=d)
    r['coins'] = [_w(r, q) for q in _coins(0.0, L, 0.0, h, -ep_cm / 2.0, ep_cm / 2.0)]
    r['centre'] = _w(r, (L / 2.0, h / 2.0, 0.0))
    r['tenons'], r['tenon_info'], r['cut'] = [], None, None
    ten = (cfg['ten_deb'] or cfg['ten_fin']) and (cfg['ten_haut'] or cfg['ten_bas'])
    if cfg['dec_on'] or ten:
        if not (rapide and st.get('ctx') is not None):
            nv = _ctx_corps(design, p1, p2, ah, d)
            old = st.get('ctx')
            pos = st.get('ctx_pos')
            if old and not (pos and _d3(pos[0], p1) < 0.5 and _d3(pos[1], p2) < 0.5):
                old = None                   # la traverse (ou la copie) a bouge : l'ancienne mesure ne vaut plus ici
            st['ctx_pos'] = (p1, p2)
            if old:                          # une mesure ratee au meme endroit garde la derniere bonne
                for kk in nv:
                    for j in (0, 1):
                        if nv[kk][j] is None:
                            nv[kk][j] = old[kk][j]
            st['ctx'] = nv
        cx = st['ctx']
        dm = [cfg['dec_dist_mm'] / 10.0, cfg.get('dec_dist2_mm', cfg['dec_dist_mm']) / 10.0]   # cotes manuelles debut / fin
        dist = [cx['dist'][j] if (cfg['dec_auto'] and cx['dist'][j] and 0.5 < cx['dist'][j] < L * 0.45) else dm[j]
                for j in (0, 1)]
        r['pb'] = dist
        if ten:
            boites, info = _tenons_locaux(L, h, ep_cm, cfg, dist, cx['up'], cx['dn'])
            r['tenons'], r['tenon_info'] = boites, info
            if not boites:
                r.update(ok=False, msg='TENON')
        if r['ok'] and cfg['dec_on']:
            cut = _decaisse(L, h, dist[0], dist[1], cfg['dec_h_mm'] / 10.0, cfg['dec_arc'])
            if cut is None:
                r.update(ok=False, msg='DEC')
            else:
                r['cut'] = cut
    return r


def _longueur_auto(design, p1, a, d):
    """Distance de p1 au premier corps rencontre dans la direction a (mode perpendiculaire). Rayons partis un peu
    au-dessus (ou en dessous) du chemin, dans le sens de la hauteur : le chemin est en general l'arete d'un corps
    sur lequel la traverse repose. Le plus proche des impacts est retenu."""
    bases = [_v_add(p1, _v_mul(d, off)) for off in (0.3, 1.5)]
    return _hauteur_auto(design, bases, a)


_cache_forme = {}          # jetons du chemin -> polylignes (monde) de la forme qui le porte


def _poly_native(n, ctx, nb=24):
    """Points (monde) d'une courbe native (arete ou courbe d'esquisse) d'un composant de contexte ctx."""
    try:
        if isinstance(n, adsk.fusion.BRepEdge):
            g = n.geometry.copy()
        else:
            g = n.worldGeometry.copy()
        if ctx is not None:
            g.transformBy(ctx.transform2)
        if isinstance(g, adsk.core.Line3D):
            a, b = g.startPoint, g.endPoint
            return [(a.x, a.y, a.z), (b.x, b.y, b.z)]
        ev = g.evaluator
        ok, p0, p1 = ev.getParameterExtents()
        if not ok:
            return []
        out = []
        for k in range(nb + 1):
            ok, q = ev.getPointAtParameter(p0 + (p1 - p0) * k / nb)
            if ok:
                out.append((q.x, q.y, q.z))
        return out
    except Exception:
        return []


def _forme(design, tokens):
    """Contour de la forme qui porte le chemin : toutes les aretes du corps (chemin = arete) ou les courbes
    de l'esquisse reliees au chemin (chemin = courbe d'esquisse). Liste de polylignes, en cache."""
    cle = tuple(tokens)
    if cle in _cache_forme:
        return _cache_forme[cle]
    polys = []
    try:
        ents = _ents(design, tokens)
        e = ents[0] if ents else None
        ctx = getattr(e, 'assemblyContext', None) if e is not None else None
        n = e.nativeObject if (e is not None and ctx is not None) else e
        if isinstance(n, adsk.fusion.BRepEdge):
            for ed in n.body.edges:
                pl = _poly_native(ed, ctx)
                if len(pl) >= 2:
                    polys.append(pl)
        elif n is not None and hasattr(n, 'parentSketch'):
            courbes = []
            for c in n.parentSketch.sketchCurves:
                if getattr(c, 'isConstruction', False):
                    continue
                pl = _poly_native(c, ctx)
                if len(pl) >= 2:
                    courbes.append((c.entityToken == n.entityToken, pl))
            # seulement les courbes reliees au chemin (bouts communs) : une autre forme de l'esquisse ne compte pas
            def k3(q):
                return (round(q[0], 2), round(q[1], 2), round(q[2], 2))
            bouts = {}
            for i, (_sel, pl) in enumerate(courbes):
                for q in (pl[0], pl[-1]):
                    bouts.setdefault(k3(q), []).append(i)
            vus = set(i for i, (sel, _pl) in enumerate(courbes) if sel)
            pile = list(vus)
            while pile:
                i = pile.pop()
                pl = courbes[i][1]
                for q in (pl[0], pl[-1]):
                    for j in bouts.get(k3(q), []):
                        if j not in vus:
                            vus.add(j)
                            pile.append(j)
            polys = [courbes[i][1] for i in sorted(vus)]
    except Exception:
        _log('forme : ' + traceback.format_exc()[-300:])
    if len(_cache_forme) > 20:
        _cache_forme.clear()
    _cache_forme[cle] = polys
    return polys


def _longueur_forme(design, tokens, p1, a):
    """Distance (vue de dessus) de p1 a l'arete la plus eloignee de la forme, dans l'axe a : la traverse va
    jusqu'au bord oppose de la forme (pas un evidement interieur), quelle que soit la forme (droites, arcs,
    splines). None si la forme n'est pas traversee dans ce sens."""
    up = _vers_haut()
    b = _v_cross(up, a)
    best = None
    for pl in _forme(design, tokens):
        prev = None
        for q in pl:
            w = _v_sub(q, p1)
            x, y = _v_dot(w, a), _v_dot(w, b)
            if prev is not None:
                x0, y0 = prev
                if (y0 <= 0.0 <= y or y <= 0.0 <= y0) and abs(y - y0) > 1e-12:
                    xi = x0 + (x - x0) * (0.0 - y0) / (y - y0)
                    if xi > 0.05 and (best is None or xi > best):
                        best = xi
            prev = (x, y)
    return best


def _perp(design, st, t, tr, s, ep_cm, rapide, cfg, fa, fv):
    """Traverse perpendiculaire au chemin tr a la fraction s, horizontale, du cote choisi (t['cote'])."""
    r = {'ok': False, 'msg': 'ORIENT', 'L': 0.0, 'h': 0.0, 'nfa': len(t['fa']), 'nfv': len(t['fv'])}
    p0, tg = tr.at(s)
    up = _vers_haut()
    th = _v_sub(tg, _v_mul(up, _v_dot(tg, up)))
    if math.sqrt(_v_dot(th, th)) < 1e-6:
        return r                                    # chemin vertical : pas de perpendiculaire horizontale unique
    a = _v_norm(_v_cross(_v_norm(th), up))
    if t.get('cote'):
        a = _v_mul(a, -1.0)
    p1 = _centrer(p0, fa)
    r['dec1'] = _d3(p1, p0) * 10.0
    d = _v_mul(up, 1.0 if t['haut'] else -1.0)
    r['axe_pv'] = (p1, _v_mul(a, 20.0))
    if t.get('l_auto', True):
        L = _longueur_forme(design, t['c1'], p0, a)     # bord oppose de la forme du chemin (suit le glisser)
        if L is not None:
            L -= _v_dot(_v_sub(p1, p0), a)              # debut recentre par les faces : la fin reste sur le bord
            st['L_auto_c'] = L
        elif rapide and st.get('L_auto_c') is not None:
            L = st['L_auto_c']
        else:
            L = _longueur_auto(design, p1, a, d)
            if L is None:
                L = st.get('L_auto_c')
            else:
                st['L_auto_c'] = L
        if L is None:
            r['msg'] = 'LONGA'
            return r
    else:
        L = max(0.01, t.get('l_mm', 500.0) / 10.0)
    p2b = _v_add(p1, _v_mul(a, L))
    p2 = _centrer(p2b, fv)
    r['dec2'] = _d3(p2, p2b) * 10.0
    r['msg'] = 'LONG'
    return _geo(design, st, t, p1, p2, ep_cm, rapide, cfg, r)


def _cote_auto(design, t):
    """Nouveau chemin (1 chemin / reseau) : la traverse part du cote ou un corps est en face (le plus proche
    si les deux cotes en ont un). Rien ne change si aucun cote n'en a."""
    try:
        tr = _traj(t['c1'], design)
        p0, tg = tr.at(t['s1'] if t.get('mode') == 'perp' else 0.5)
        up = _vers_haut()
        th = _v_sub(tg, _v_mul(up, _v_dot(tg, up)))
        if math.sqrt(_v_dot(th, th)) < 1e-6:
            return
        a = _v_norm(_v_cross(_v_norm(th), up))
        d = _v_mul(up, 1.0 if t['haut'] else -1.0)
        p1 = _centrer(p0, _ents(design, t['fa']))
        res = []
        for cote in (False, True):
            L = _longueur_forme(design, t['c1'], p0, _v_mul(a, -1.0) if cote else a)
            if L is not None:
                res.append((-L, cote))               # forme : vers son bord le plus eloigne
        if not res:
            for cote in (False, True):
                L = _longueur_auto(design, p1, _v_mul(a, -1.0) if cote else a, d)
                if L is not None:
                    res.append((L, cote))
        if res:
            t['cote'] = min(res)[1]
            _vider_caches(t)
    except Exception:
        _log('cote auto : ' + traceback.format_exc()[-200:])


def _reseau_pos(t, Ltot, ep_cm):
    """Abscisses (cm, le long du chemin) des copies du reseau, et abscisses des deux poignees.
    'chemin' : de bout en bout, la premiere et la derniere a fleur des marges (traverse entiere sur le chemin) ;
    'espacement' / 'etendue' : depuis le point de la poignee (t['s1']), aligne au debut, au centre ou a la fin."""
    n = max(1, int(t.get('r_n', 1)))
    e = ep_cm / 2.0
    if t.get('r_type') == 'entre':
        # demande de Maxence (2026-11-05) : les deux bouts du chemin portent en general d'autres corps (pas des
        # traverses) ; les n traverses partagent l'intervalle entre les marges en n + 1 parts egales, symetriques
        # autour du centre. Calcule sur la longueur du chemin : elles suivent si le chemin change.
        x0 = t.get('r_m1', 0.0) / 10.0
        x1 = Ltot - t.get('r_m2', 0.0) / 10.0
        sp = (x1 - x0) / (n + 1)
        return [x0 + (i + 1) * sp for i in range(n)], (x0 + e, x1 - e)
    if t.get('r_type') == 'chemin':
        x0 = t.get('r_m1', 0.0) / 10.0 + e
        x1 = Ltot - t.get('r_m2', 0.0) / 10.0 - e
        if n == 1:
            return [(x0 + x1) / 2.0], (x0, x1)
        sp = (x1 - x0) / (n - 1)
        return [x0 + i * sp for i in range(n)], (x0, x1)
    A = max(0.0, min(1.0, t.get('s1', 0.5))) * Ltot
    D = max(0.0, t.get('r_dist', 300.0) / 10.0)
    if t.get('r_type') == 'etendue':
        E = D
        sp = E / (n - 1) if n > 1 else 0.0
    else:
        sp = D
        E = sp * (n - 1)
    al = t.get('r_align', 'debut')
    if al == 'fin':
        xs = [A - i * sp for i in range(n)]
        return xs, (A, A - E)
    if al == 'centre':
        xs = [A - E / 2.0 + i * sp for i in range(n)]
        return xs, (A, A + E / 2.0)
    return [A + i * sp for i in range(n)], (A, A + E)


def _reseau(design, t, ep_cm, rapide, cfg, fa, fv):
    tr = _traj(t['c1'], design)
    Ltot = tr.longueur
    xs, _poig = _reseau_pos(t, Ltot, ep_cm)
    insts = t.setdefault('_inst', [])
    while len(insts) < len(xs):
        insts.append({})
    del insts[len(xs):]
    e = ep_cm / 2.0
    out = []
    for j, x in enumerate(xs):
        hors = x < e - 1e-4 or x > Ltot - e + 1e-4
        c = _perp(design, insts[j], t, tr, max(0.0, min(Ltot, x)) / Ltot, ep_cm, rapide, cfg, fa, fv)
        if hors and c.get('coins'):
            c.update(ok=False, msg='HORS')
        out.append(c)
    rep = next((c for c in out if c['ok']), out[0])
    r = dict(rep)
    r.update(inst=out, nok=sum(1 for c in out if c['ok']), ntot=len(out), ok=any(c['ok'] for c in out))
    if not r['ok']:
        r['msg'] = rep['msg']
    r['tr1'] = tr
    return r


def _calc(design, t, ep_cm, rapide=False):
    """Geometrie d'une traverse (ou d'un reseau) : dict 'ok', 'msg' et, si ok, les 8 coins, longueur, hauteur,
    tenons, decaisse... ; un reseau a en plus 'inst' (une entree par copie)."""
    mode = t.get('mode', 'libre')
    sig = (mode, tuple(t['c1']), tuple(t['c2']), tuple(t['fa']), tuple(t['fv']), round(t['s1'], 5), round(t['s2'], 5),
           t['haut'], t['auto'], round(t['h_mm'], 3), round(ep_cm, 4), rapide, _cfg_sig(),
           bool(t.get('cote')), bool(t.get('l_auto', True)), round(t.get('l_mm', 0.0), 3), int(t.get('r_n', 1)),
           t.get('r_type'), round(t.get('r_dist', 0.0), 3), t.get('r_align'), round(t.get('r_m1', 0.0), 3),
           round(t.get('r_m2', 0.0), 3))
    if t['sig'] == sig and t['calc'] is not None:
        return t['calc']
    cfg = dict(_cfg)
    r = {'ok': False, 'msg': 'CHEMINS' if mode == 'libre' else 'CHEMIN', 'L': 0.0, 'h': 0.0,
         'nfa': len(t['fa']), 'nfv': len(t['fv'])}
    try:
        fa, fv = _ents(design, t['fa']), _ents(design, t['fv'])
        if mode != 'libre':
            if t['c1']:
                if len(fa) not in (0, 2) or len(fv) not in (0, 2):
                    r['msg'] = 'FACES'
                elif mode == 'perp':
                    r = _perp(design, t, t, _traj(t['c1'], design), t['s1'], ep_cm, rapide, cfg, fa, fv)
                else:
                    r = _reseau(design, t, ep_cm, rapide, cfg, fa, fv)
        elif t['c1'] and t['c2']:
            tr1, tr2 = _traj(t['c1'], design), _traj(t['c2'], design)
            r['tr1'], r['tr2'] = tr1, tr2
            if len(fa) not in (0, 2) or len(fv) not in (0, 2):
                r['msg'] = 'FACES'
            else:
                p1b, p2b = tr1.at(t['s1'])[0], tr2.at(t['s2'])[0]
                p1 = _centrer(p1b, fa)
                p2 = _centrer(p2b, fv)
                r['dec1'], r['dec2'] = _d3(p1, p1b) * 10.0, _d3(p2, p2b) * 10.0
                r = _geo(design, t, t, p1, p2, ep_cm, rapide, cfg, r)
    except Exception:
        _log('calc erreur ' + traceback.format_exc()[-500:])
        r['msg'] = 'ERR'
        r['ok'] = False
    t['sig'], t['calc'] = sig, r
    return r


def _instances(calcs):
    """[(indice de la traverse, calcul)] : une entree par traverse, une par copie pour un reseau."""
    out = []
    for i, c in enumerate(calcs):
        if c.get('inst') is not None:
            out += [(i, ci) for ci in c['inst']]
        else:
            out.append((i, c))
    return out


# --- Apercu 3D (CustomGraphics) -----------------------------------------------

ID_APERCU = 'TraverseCNC_apercu'
ID_OV = 'TraverseCNC_overlay'
_apercu = {'t': []}          # une entree par traverse : {'cle', 'grps': {nom: groupe}, 'm': {nom: matrice}}
ARETES = [(0, 1), (2, 3), (4, 5), (6, 7), (0, 2), (1, 3), (4, 6), (5, 7), (0, 4), (1, 5), (2, 6), (3, 7)]


def _balayer(ident):
    """Supprime TOUS les groupes graphiques portant cet id (composant actif et racine) :
    un groupe orphelin (rechargement du module, erreur...) restait affiche a l'ecran."""
    try:
        design = _design()
        comps = {design.rootComponent.entityToken: design.rootComponent}
        ac = design.activeComponent
        comps[ac.entityToken] = ac
        for comp in comps.values():
            gs = comp.customGraphicsGroups
            for i in range(gs.count - 1, -1, -1):
                try:
                    g = gs.item(i)
                    if g.id == ident:
                        g.deleteMe()
                except Exception:
                    pass
    except Exception:
        pass


def _supprimer_groupes(grps):
    for g in list(grps.values()):
        try:
            if g.isValid:
                g.deleteMe()
        except Exception:
            pass


def _apercu_effacer():
    ents = _apercu['t']
    _apercu['t'] = []
    for e in ents:
        _supprimer_groupes(e['grps'])
    _balayer(ID_APERCU)


def _boite_pts(coins):
    pts = []
    for i, j in ARETES:
        pts += list(coins[i]) + list(coins[j])
    return pts


def _demi_ep(c):
    """Demi-epaisseur de la traverse, lue sur ses coins (coins 0 et 2 : z -ep/2 et +ep/2)."""
    return _d3(c['coins'][0], c['coins'][2]) / 2.0


def _mat(o, ex, ey, ez):
    """Matrice monde : colonnes ex, ey, ez (echelle comprise) et origine o."""
    m = adsk.core.Matrix3D.create()
    m.setWithArray([ex[0], ey[0], ez[0], o[0], ex[1], ey[1], ez[1], o[1], ex[2], ey[2], ez[2], o[2], 0.0, 0.0, 0.0, 1.0])
    return m


def _poly_pts(pts2, e, dx=0.0):
    """Lignes (paires de points) d'une polyligne (x, y) sur les deux faces z = -e / +e."""
    out = []
    for z in (-e, e):
        for (ax, ay), (bx, by) in zip(pts2[:-1], pts2[1:]):
            out += [ax + dx, ay, z, bx + dx, by, z]
    return out


_BOX_UNITE = _boite_pts(_coins(0.0, 1.0, 0.0, 1.0, -0.5, 0.5))
# meme boite sans les deux grandes aretes du dessus (cote decaisse) : avec un decaisse, elles traversent le vide
_BOX_SANS_HAUT = []
for _i, _j in ARETES:
    if (_i, _j) not in ((1, 5), (3, 7)):
        _c = _coins(0.0, 1.0, 0.0, 1.0, -0.5, 0.5)
        _BOX_SANS_HAUT += list(_c[_i]) + list(_c[_j])


def _apercu_pieces(c, sel=True):
    """(cle, {nom: (points locaux, couleur)}, {nom: Matrice3D}) d'une traverse.
    Les groupes graphiques gardent une geometrie FIXE ; on ne fait que changer leur matrice quand la traverse
    bouge (comme les copies orange de Reseau CNC) : seul ce mecanisme s'affiche pendant le glissé de la fleche
    (reecrire les coordonnees d'une ligne existante n'est pas redessine par Fusion - verifie sur capture).
    Boite : cube unite mis a l'echelle ; tenons / extremites du decaisse : repere de chaque bout ; fond du
    decaisse : segment unite mis a l'echelle."""
    geoms, mats = {}, {}
    ok = c['ok']
    if ok or (c.get('coins') and c['msg'] in ('TENON', 'DEC', 'HORS')):
        L, h = c['L'], c['h']
        e = _demi_ep(c)
        ah, d, lat, p1, p2 = c['ah'], c['d'], c['lat'], c['p1'], c['p2']
        geoms['box'] = (_BOX_UNITE, ORANGE if ok else ROUGE)
        mats['box'] = _mat(p1, _v_mul(ah, L), _v_mul(d, h), _v_mul(lat, 2.0 * e))
        un = (_v_mul(ah, 1.0), d, lat)
        if ok:
            tb = c.get('tenons') or []

            def _tp(debut):
                out = []
                for b in tb:
                    if debut and b[0] < L / 2.0:
                        out += _boite_pts(_coins(*b))
                    elif not debut and b[0] >= L / 2.0:
                        out += _boite_pts(_coins(b[0] - L, b[1] - L, b[2], b[3], b[4], b[5]))
                return out
            if any(b[0] < L / 2.0 for b in tb):
                geoms['ten_deb'] = (lambda: _tp(True), ORANGE)
                mats['ten_deb'] = _mat(p1, *un)
            if any(b[0] >= L / 2.0 for b in tb):
                geoms['ten_fin'] = (lambda: _tp(False), ORANGE)
                mats['ten_fin'] = _mat(p2, *un)
            cut = c.get('cut')
            if cut:
                nl = len(cut['pts']) // 2
                pl, pr = cut['pts'][:nl], cut['pts'][nl:]
                cl, cr = cut['corners'][:2], cut['corners'][2:]
                def _gl():
                    g = _poly_pts(pl, e)
                    for k in cl:
                        g += [pl[k][0], pl[k][1], -e, pl[k][0], pl[k][1], e]
                    return g

                def _gr():
                    g = _poly_pts(pr, e, -L)
                    for k in cr:
                        k2 = k - nl
                        g += [pr[k2][0] - L, pr[k2][1], -e, pr[k2][0] - L, pr[k2][1], e]
                    return g
                geoms['box'] = (_BOX_SANS_HAUT, ORANGE)      # dessus de la traverse seulement hors decaisse
                d1x, d2x = pl[0][0], pr[-1][0] - L
                geoms['haut_l'] = ([0.0, h, -e, d1x, h, -e, 0.0, h, e, d1x, h, e], ORANGE)
                mats['haut_l'] = _mat(p1, *un)
                geoms['haut_r'] = ([d2x, h, -e, 0.0, h, -e, d2x, h, e, 0.0, h, e], ORANGE)
                mats['haut_r'] = _mat(p2, *un)
                geoms['dec_l'] = (_gl, CYAN)
                mats['dec_l'] = _mat(p1, *un)
                geoms['dec_r'] = (_gr, CYAN)
                mats['dec_r'] = _mat(p2, *un)
                yf = h - cut['R']
                x1, x2 = cut['x1'], cut['x2']
                geoms['dec_f'] = ([0.0, 0.0, -e, 1.0, 0.0, -e, 0.0, 0.0, e, 1.0, 0.0, e], CYAN)
                o = _v_add(_v_add(p1, _v_mul(ah, x1)), _v_mul(d, yf))
                mats['dec_f'] = _mat(o, _v_mul(ah, max(1e-6, x2 - x1)), d, lat)
    elif 'tr1' in c and 'tr2' in c and c['msg'] in ('HAUT', 'FACES', 'LONG'):
        a, b = c['tr1'].at(0.5)[0], c['tr2'].at(0.5)[0]
        v = _v_sub(b, a)
        if _v_dot(v, v) > 1e-12:
            u = _v_norm(v)
            w = _v_cross(u, (0.0, 0.0, 1.0))
            if _v_dot(w, w) < 1e-9:
                w = _v_cross(u, (0.0, 1.0, 0.0))
            w = _v_norm(w)
            geoms['axe'] = ([0.0, 0.0, 0.0, 1.0, 0.0, 0.0], ROUGE)
            mats['axe'] = _mat(a, v, w, _v_cross(u, w))
    elif c.get('axe_pv') and c['msg'] in ('LONGA', 'HAUT', 'FACES', 'LONG'):
        a, v = c['axe_pv']                      # 1 chemin : direction de la traverse en rouge (aucun corps en face...)
        u = _v_norm(v)
        w = _v_cross(u, (0.0, 0.0, 1.0))
        if _v_dot(w, w) < 1e-9:
            w = _v_cross(u, (0.0, 1.0, 0.0))
        w = _v_norm(w)
        geoms['axe'] = ([0.0, 0.0, 0.0, 1.0, 0.0, 0.0], ROUGE)
        mats['axe'] = _mat(a, v, w, _v_cross(u, w))

    if not sel:
        corr = {ORANGE: ORANGE_AUT, CYAN: CYAN_AUT}
        geoms = {nm: (pts, corr.get(col, col)) for nm, (pts, col) in geoms.items()}

    def r3(v): return tuple(round(x, 3) for x in v)
    cle = (sel, ok, c['msg'] if not ok else '', tuple(sorted(geoms)),
           round(c.get('h', 0.0), 3), round(_demi_ep(c), 4) if c.get('coins') else 0,
           tuple((round(b[0] if b[0] < c['L'] / 2.0 else b[0] - c['L'], 3), round(b[1] - b[0], 3), round(b[2], 3), round(b[3], 3))
                 for b in (c.get('tenons') or [])) if ok else (),
           (round(c['cut']['R'], 3), round(c['cut']['d1'], 3), round(c['cut']['d2'], 3), c['cut']['arc']) if (ok and c.get('cut')) else None)
    return cle, geoms, mats


def _apercu_maj(calcs, force=False, live=False, ctx=''):
    """Apercu : un jeu de groupes par traverse. Seule la matrice des groupes change quand la traverse bouge ;
    les groupes ne sont recrees que si la forme change (tenons, decaisse, hauteur...) ou si 'force' (nouveau
    groupe cree AVANT la suppression de l'ancien : jamais d'image vide)."""
    try:
        ents = _apercu['t']
        recree = False
        flat = _instances(calcs)               # un reseau : une entree par copie
        while len(ents) > len(flat):
            _supprimer_groupes(ents.pop()['grps'])
        root = _design().rootComponent
        for i, (it, c) in enumerate(flat):
            sel = (it == _cur['i']) or len(calcs) == 1
            cle, geoms, mats = _apercu_pieces(c, sel)
            e = ents[i] if i < len(ents) else None
            ok = e is not None and e['cle'] == cle and not force
            if ok:
                try:
                    ok = all(g.isValid for g in e['grps'].values())
                except Exception:
                    ok = False
                if not ok:
                    _log('apercu : groupe perdu (cree dans « %s »), recreation dans « %s »' % (e.get('ctx'), ctx))
            if ok:
                for nm, g in e['grps'].items():
                    m = mats[nm]
                    a = tuple(m.asArray())
                    if a != e['m'].get(nm):
                        g.transform = m
                        e['m'][nm] = a
                continue
            nouveaux, marr = {}, {}
            for nm, (pts, col) in geoms.items():
                if callable(pts):
                    pts = pts()
                g = root.customGraphicsGroups.add()
                g.id = ID_APERCU
                ln = g.addLines(adsk.fusion.CustomGraphicsCoordinates.create(pts), [], False)
                ln.weight = 2 if sel else 1              # traits fins (demande du 2026-11-04)
                ln.color = adsk.fusion.CustomGraphicsSolidColorEffect.create(adsk.core.Color.create(*col))
                ln.isSelectable = False
                g.transform = mats[nm]
                nouveaux[nm] = g
                marr[nm] = tuple(mats[nm].asArray())
            neuf = {'cle': cle, 'grps': nouveaux, 'm': marr, 'ctx': ctx}
            recree = True
            if e is not None:
                _supprimer_groupes(e['grps'])
                ents[i] = neuf
            else:
                ents.append(neuf)
        if recree and ctx == 'preview':
            # des groupes crees pendant l'apercu sont annules par Fusion au cycle suivant : on les recree aussi, hors
            # apercu, par evenement personnalise (au plus 4 fois / s), comme le redessin differe des clics
            mt = time.perf_counter()
            if mt - _apercu.get('tev', 0.0) > 0.25:
                _apercu['tev'] = mt
                _redraw['legere'] = True
                _redessiner_differe()
    except Exception:
        _log('apercu erreur ' + traceback.format_exc()[-400:])


# Redessin differe : un groupe cree ou modifie PENDANT un clic de souris (mouseDown sur une icone de la barre)
# disparaissait (Fusion traite le clic ensuite) ; on redessine une fois le gestionnaire termine, par
# evenement personnalise comme Reseau CNC.
REDRAW_ID = 'TraverseCNC_redraw'
_redraw = {'evt': None, 'h': None, 'on': False}


class _RedrawHandler(adsk.core.CustomEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            if not _redraw['on']:
                return
            calcs = _cur['calcs']
            if calcs:
                if not _redraw.get('legere'):
                    _ov['sig'] = None
                _redraw['legere'] = False
                _ov_maj(calcs)
                _apercu_maj(calcs, force=True, ctx='evenement')
                _rafraichir_vue()
        except Exception:
            _log('redraw erreur ' + traceback.format_exc()[-300:])


def _redessiner_differe():
    try:
        for essai in (0, 1):
            if _redraw['evt'] is None:
                try:
                    _app.unregisterCustomEvent(REDRAW_ID)
                except Exception:
                    pass
                _redraw['evt'] = _app.registerCustomEvent(REDRAW_ID)
                _redraw['h'] = _RedrawHandler()
                _redraw['evt'].add(_redraw['h'])
            if _app.fireCustomEvent(REDRAW_ID, ''):
                break
            # evenement mort (add-in relance depuis un script) : on le reenregistre depuis la commande
            _redraw['evt'] = None
    except Exception:
        _log('redessiner differe : ' + traceback.format_exc()[-200:])


# --- Fenetres en bas a gauche (modele : ReseauTrajectoireCNC) -----------------

OV_W, OV_H = 556, 28
OV_X, OV_Y, OV_GAP = 16, 60, 6
OV_MOINS, OV_PLUS = (176, 198), (232, 254)      # entete : une traverse de moins / de plus
OV_HT = (244, 324)                               # bouton hauteur (auto / manuelle)
OV_ARROW = (406, 434)                            # fleche haut / bas
OV_TEN = (440, 466)                              # icone tenons (actif / inactif)
OV_DEC = (470, 496)                              # icone decaisse central
OV_FIN = (292, 392)                              # ligne decaisse : finition arc / droit
OV_CROIX = (524, 552)                            # supprimer la traverse
OV_MODES = {'libre': (268, 356), 'perp': (362, 450), 'reseau': (456, 552)}   # entete : mode de la traverse active
OV_LB = (104, 236)                               # 1 chemin / reseau : longueur auto / manuelle
OV_COTE = (336, 398)                             # 1 chemin / reseau : cote de la traverse
OV_RTYPE = (262, 382)                            # ligne reseau : chemin entier / espacement / etendue
OV_RALIGN = (388, 456)                           # ligne reseau : debut / centre / fin
MODE_TXT = {'libre': '2 chemins', 'perp': '1 chemin', 'reseau': 'Reseau'}
RTYPE_TXT = {'chemin': 'Chemin entier', 'entre': 'Entre bouts', 'espacement': 'Espacement', 'etendue': 'Etendue'}
RALIGN_TXT = {'debut': 'Debut', 'centre': 'Centre', 'fin': 'Fin'}
_ov = {'g': None, 'sig': None}
_png_cache = {}
_dpr_cache = {}

_GLYPHES = {
    'C': '111100100100111', 'H': '101101111101101', 'E': '111100111100111', 'M': '101111111101101',
    'T': '111010010010010', 'O': '111101101101111', 'U': '101101101101111',
    'S': '111100111001111', 'I': '111010010010111', 'N': '111101101101101', ' ': '000000000000000',
    '0': '111101101101111', '1': '010110010010111', '2': '111001111100111', '3': '111001111001111',
    '4': '101101111001001', '5': '111100111001111', '6': '111100111101111', '7': '111001001001001',
    '8': '111101111101111', '9': '111101111001111',
    'A': '010101111101101', 'B': '110101110101110', 'D': '110101101101110', 'F': '111100110100100',
    'G': '011100101101011', 'J': '001001001101010', 'K': '101101110101101', 'L': '100100100100111',
    'P': '110101110100100', 'Q': '010101101111011', 'R': '110101110101101', 'V': '101101101101010',
    'W': '101101111111101', 'X': '101101010101101', 'Y': '101101010010010', 'Z': '111001010100111',
    "'": '010010000000000', '.': '000000000000010', ',': '000000000010100', '-': '000000111000000',
    ':': '000010000010000', '%': '101001010100101', '/': '001001010100100'}


def _dpr():
    if 'k' not in _dpr_cache:
        k = 1.0
        try:
            import ctypes
            k = max(1.0, ctypes.windll.user32.GetDpiForSystem() / 96.0)
        except Exception:
            pass
        _dpr_cache['k'] = k
    return _dpr_cache['k']


def _ecrire_png(cle, px, w, h):
    import zlib, struct, tempfile
    raw = bytearray()
    for y in range(h):
        raw.append(0)
        for x in range(w):
            raw += bytes(px[y][x])

    def chunk(tt, dd):
        c = struct.pack('>I', len(dd)) + tt + dd
        return c + struct.pack('>I', zlib.crc32(tt + dd) & 0xffffffff)

    png = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 6, 0, 0, 0)) + \
        chunk(b'IDAT', zlib.compress(bytes(raw))) + chunk(b'IEND', b'')
    chemin = os.path.join(tempfile.gettempdir(), 'traverse_cnc_%s.png' % cle)
    with open(chemin, 'wb') as f:
        f.write(png)
    _png_cache[cle] = chemin
    return chemin


def _texte_px(px, txt, x0, y0, couleur):
    """Capitales sans accent, police 3x5 agrandie x2, pas de 8 px."""
    import unicodedata
    txt = ''.join(c for c in unicodedata.normalize('NFD', txt) if unicodedata.category(c) != 'Mn').upper()
    for n, c in enumerate(txt):
        g = _GLYPHES.get(c, _GLYPHES[' '])
        for gy in range(5):
            for gx in range(3):
                if g[gy * 3 + gx] == '1':
                    for dy in range(2):
                        for dx in range(2):
                            px[y0 + gy * 2 + dy][x0 + n * 8 + gx * 2 + dx] = couleur


def _cadre(px, w, h, couleur):
    for x in range(w):
        for y in (0, 1, h - 1, h - 2):
            px[y][x] = couleur
    for y in range(h):
        for x in (0, 1, w - 1, w - 2):
            px[y][x] = couleur


def _bouton(px, yc, x0, x1, actif):
    fond = (110, 55, 0, 255) if actif else (62, 62, 62, 255)
    bord = (255, 170, 60, 255) if actif else (125, 125, 125, 255)
    for x in range(x0, x1):
        for y in range(yc - 11, yc + 11):
            px[y][x] = bord if (x in (x0, x1 - 1) or y in (yc - 11, yc + 10)) else fond
    return (255, 140, 0, 255) if actif else (150, 150, 150, 255), (255, 225, 175, 255) if actif else (190, 190, 190, 255)


def _png_entete(n):
    mode = _actif().get('mode', 'libre')
    cle = 'tete_%d_%s_%s' % (n, mode, '_'.join(_tt(MODE_TXT[m]) for m in MODES) + _tt('Nombre de traverses'))
    if cle in _png_cache and os.path.isfile(_png_cache[cle]):
        return _png_cache[cle]
    w, h = OV_W, OV_H
    px = [[(40, 40, 40, 255)] * w for _ in range(h)]
    _cadre(px, w, h, (110, 110, 110, 255))
    yc = h // 2
    _texte_px(px, _tt('Nombre de traverses'), 8, (h - 10) // 2, (235, 235, 235, 255))
    for (b0, b1, plus) in ((OV_MOINS[0], OV_MOINS[1], False), (OV_PLUS[0], OV_PLUS[1], True)):
        plein, clair = _bouton(px, yc, b0, b1, False)
        xm = (b0 + b1) // 2
        for x in range(xm - 5, xm + 5):
            for y in (yc - 1, yc):
                px[y][x] = clair
        if plus:
            for y in range(yc - 5, yc + 5):
                for x in (xm - 1, xm):
                    px[y][x] = clair
    _texte_px(px, str(n), OV_MOINS[1] + 6, (h - 10) // 2, (255, 200, 60, 255))
    for m in MODES:
        b0, b1 = OV_MODES[m]
        plein, clair = _bouton(px, yc, b0, b1, m == mode)
        _texte_c(px, _tt(MODE_TXT[m]), (b0 + b1) / 2.0, yc, clair)
    return _ecrire_png(cle, px, w, h)


def _png_ligne(i, sel, c):
    """Ligne « TRAVERSE i » : etat, hauteur, faces, fleche haut / bas, croix."""
    haut, auto, hmm = c['haut'], c['auto'], int(round(c['hmm']))
    ten_on, dec_on = bool(_cfg['ten_deb'] or _cfg['ten_fin']), bool(_cfg['dec_on'])
    mode = c.get('mode', 'libre')
    cle = 'tr%d_%d_%d_%d_%d_%d_%d_%d_%d_%d%d_%s_%s_%d%d%d_%s' % (i, sel, haut, auto, hmm if (c['ok'] and auto) is False else int(round(c['h'] * 10)),
                                                    c['ok'], int(round(c['L'] * 10)), c['nfa'] * 10 + c['nfv'], len(c['msg']),
                                                    ten_on, dec_on, _tt('Traverse') + _tt('Invalide'), mode, bool(c.get('cote')),
                                                    bool(c.get('l_auto')), int(round(c.get('l_mm', 0))), _tt('Reseau'))
    if cle in _png_cache and os.path.isfile(_png_cache[cle]):
        return _png_cache[cle]
    w, h = OV_W, OV_H
    px = [[(40, 40, 40, 255)] * w for _ in range(h)]
    _cadre(px, w, h, (20, 130, 215, 255) if sel else (110, 110, 110, 255))
    yc = h // 2
    y0 = (h - 10) // 2
    gris = (140, 140, 140, 255)
    _texte_px(px, '%s %d' % (_tt('Reseau' if mode == 'reseau' else 'Traverse'), i + 1), 8, y0, (235, 235, 235, 255) if sel else gris)
    if mode != 'libre':
        # longueur : bouton orange quand automatique (jusqu'au premier corps en face)
        plein, clair = _bouton(px, yc, OV_LB[0], OV_LB[1], bool(c.get('l_auto')))
        if c['ok']:
            _texte_px(px, 'L %d' % int(round(c['L'] * 10)), OV_LB[0] + 8, y0, clair)
        elif c.get('l_auto') and c['msg'] == 'LONGA':
            _texte_px(px, 'L AUTO', OV_LB[0] + 8, y0, ROUGE)
        else:
            _texte_px(px, _tt('Invalide'), OV_LB[0] + 8, y0, ROUGE)
    elif c['ok']:
        _texte_px(px, 'L %d' % int(round(c['L'] * 10)), 112, y0, (255, 200, 60, 255) if sel else gris)
    else:
        _texte_px(px, _tt('Invalide'), 112, y0, ROUGE)
    # hauteur : orange quand automatique
    plein, clair = _bouton(px, yc, OV_HT[0], OV_HT[1], auto)
    hv = int(round(c['h'] * 10)) if (auto and c['ok']) else hmm
    _texte_px(px, ('H AUTO' if auto and not c['ok'] else 'H %d' % hv) if not auto else ('H %d' % hv if c['ok'] else 'H AUTO'),
              OV_HT[0] + 8, y0, clair)
    if mode == 'libre':
        _texte_px(px, 'F %d/%d' % (c['nfa'], c['nfv']), 336, y0, (255, 200, 60, 255) if sel else gris)
    else:
        # cote de la traverse : fleche horizontale (a droite du chemin / a gauche)
        plein, clair = _bouton(px, yc, OV_COTE[0], OV_COTE[1], False)
        xs = (OV_COTE[0] + OV_COTE[1]) // 2
        sx = -1 if c.get('cote') else 1
        for x in range(xs - 12, xs + 13):
            for y in (yc - 1, yc):
                px[y][x] = clair
        for k in range(7):
            xx = xs + sx * (12 - k)
            for y in range(yc - 1 - k, yc + k + 1):
                px[y][xx] = clair
    # fleche vers le haut ou vers le bas
    plein, clair = _bouton(px, yc, OV_ARROW[0], OV_ARROW[1], False)
    xs = (OV_ARROW[0] + OV_ARROW[1]) // 2
    sg = -1 if haut else 1
    for y in range(yc - 7, yc + 8):
        for x in (xs - 1, xs):
            px[y][x] = clair
    for k in range(6):
        yy = yc + sg * (7 - k)
        for x in range(xs - 1 - k, xs + k + 1):
            px[yy][x] = clair
    # icones tenons et decaisse
    plein, clair = _bouton(px, yc, OV_TEN[0], OV_TEN[1], ten_on)
    xm = (OV_TEN[0] + OV_TEN[1]) // 2
    for y in range(yc - 3, yc + 3):
        for x in range(xm - 8, xm + 8):
            px[y][x] = clair
    for y in list(range(yc - 8, yc - 3)) + list(range(yc + 3, yc + 8)):
        for x in range(xm - 3, xm + 3):
            px[y][x] = clair
    plein, clair = _bouton(px, yc, OV_DEC[0], OV_DEC[1], dec_on)
    fond = (110, 55, 0, 255) if dec_on else (62, 62, 62, 255)
    xm = (OV_DEC[0] + OV_DEC[1]) // 2
    for y in range(yc - 6, yc + 6):
        for x in range(xm - 9, xm + 9):
            px[y][x] = clair
    for dx in range(-5, 6):
        prof = int(round(5.0 * math.sqrt(max(0.0, 1.0 - (dx / 5.5) ** 2))))
        for j in range(prof):
            px[yc - 6 + j][xm + dx] = fond
    # croix de suppression
    plein, clair = _bouton(px, yc, OV_CROIX[0], OV_CROIX[1], False)
    xc = (OV_CROIX[0] + OV_CROIX[1]) // 2
    for d in range(-5, 6):
        for e in (0, 1):
            px[yc + d][xc + d - 1 + e] = (190, 190, 190, 255)
            px[yc + d][xc - d - 1 + e] = (190, 190, 190, 255)
    return _ecrire_png(cle, px, w, h)


def _png_dec():
    """Ligne de reglage du decaisse : hauteur (- / +) et finition (arc de cercle / droit)."""
    hmm = int(round(_cfg['dec_h_mm']))
    arc = bool(_cfg['dec_arc'])
    cle = 'dec_%d_%d_%s' % (hmm, arc, _tt('Decaisse'))
    if cle in _png_cache and os.path.isfile(_png_cache[cle]):
        return _png_cache[cle]
    w, h = OV_W, OV_H
    px = [[(40, 40, 40, 255)] * w for _ in range(h)]
    _cadre(px, w, h, (0, 150, 200, 255))
    yc = h // 2
    _texte_px(px, _tt('Decaisse'), 8, (h - 10) // 2, (235, 235, 235, 255))
    for (b0, b1, plus) in ((OV_MOINS[0], OV_MOINS[1], False), (OV_PLUS[0], OV_PLUS[1], True)):
        plein, clair = _bouton(px, yc, b0, b1, False)
        xm = (b0 + b1) // 2
        for x in range(xm - 5, xm + 5):
            for y in (yc - 1, yc):
                px[y][x] = clair
        if plus:
            for y in range(yc - 5, yc + 5):
                for x in (xm - 1, xm):
                    px[y][x] = clair
    _texte_px(px, str(hmm), OV_MOINS[1] + 4, (h - 10) // 2, (255, 200, 60, 255))
    _texte_px(px, 'MM', OV_PLUS[1] + 8, (h - 10) // 2, (140, 140, 140, 255))
    plein, clair = _bouton(px, yc, OV_FIN[0], OV_FIN[1], arc)
    _texte_px(px, _tt('Arc') if arc else _tt('Droit'), OV_FIN[0] + 10, (h - 10) // 2, clair)
    return _ecrire_png(cle, px, w, h)


def _png_res(t, c):
    """Ligne de reglage du reseau de la traverse active : nombre (- / +), repartition, alignement, distance."""
    n = int(t['r_n'])
    typ, al = t['r_type'], t['r_align']
    nok, ntot = c.get('nok', 0), c.get('ntot', 0)
    cle = 'res_%d_%s_%s_%d_%d_%d_%d_%d_%s' % (n, typ, al, int(round(t['r_dist'])), int(round(t['r_m1'])), int(round(t['r_m2'])),
                                            nok, ntot, _tt('Nombre de copies') + _tt(RTYPE_TXT[typ]) + _tt(RALIGN_TXT[al]))
    if cle in _png_cache and os.path.isfile(_png_cache[cle]):
        return _png_cache[cle]
    w, h = OV_W, OV_H
    px = [[(40, 40, 40, 255)] * w for _ in range(h)]
    _cadre(px, w, h, (20, 130, 215, 255))
    yc = h // 2
    y0 = (h - 10) // 2
    _texte_px(px, _tt('Nombre de copies'), 8, y0, (235, 235, 235, 255))
    for (b0, b1, plus) in ((OV_MOINS[0], OV_MOINS[1], False), (OV_PLUS[0], OV_PLUS[1], True)):
        plein, clair = _bouton(px, yc, b0, b1, False)
        xm = (b0 + b1) // 2
        for x in range(xm - 5, xm + 5):
            for y in (yc - 1, yc):
                px[y][x] = clair
        if plus:
            for y in range(yc - 5, yc + 5):
                for x in (xm - 1, xm):
                    px[y][x] = clair
    _texte_c(px, str(n), (OV_MOINS[1] + OV_PLUS[0]) / 2.0, yc, ROUGE if nok < ntot else (255, 200, 60, 255))
    plein, clair = _bouton(px, yc, OV_RTYPE[0], OV_RTYPE[1], True)
    _texte_c(px, _tt(RTYPE_TXT[typ]), (OV_RTYPE[0] + OV_RTYPE[1]) / 2.0, yc, clair)
    gris = (140, 140, 140, 255)
    if typ in R_MARGES:
        _texte_px(px, 'M %d/%d' % (int(round(t['r_m1'])), int(round(t['r_m2']))), OV_RALIGN[0] + 4, y0, gris)
    else:
        plein, clair = _bouton(px, yc, OV_RALIGN[0], OV_RALIGN[1], False)
        _texte_c(px, _tt(RALIGN_TXT[al]), (OV_RALIGN[0] + OV_RALIGN[1]) / 2.0, yc, clair)
        _texte_px(px, 'D %d' % int(round(t['r_dist'])), OV_RALIGN[1] + 8, y0, (255, 200, 60, 255))
    return _ecrire_png(cle, px, w, h)


def _png_info(txt):
    cle = 'tip_%d' % (abs(hash(txt)) % 10 ** 10)
    w, h = len(txt) * 8 + 12, 24
    if cle in _png_cache and os.path.isfile(_png_cache[cle]):
        return _png_cache[cle], w, h
    px = [[(246, 246, 246, 255)] * w for _ in range(h)]
    for x in range(w):
        for y in (0, h - 1):
            px[y][x] = (110, 110, 110, 255)
    for y in range(h):
        for x in (0, w - 1):
            px[y][x] = (110, 110, 110, 255)
    _texte_px(px, txt, 6, 7, (20, 20, 20, 255))
    return _ecrire_png(cle, px, w, h), w, h


def _ov_effacer():
    g = _ov['g']
    _ov['g'] = None
    _ov['sig'] = None
    _tip_effacer()
    try:
        if g is not None and g.isValid:
            g.deleteMe()
    except Exception:
        pass
    _balayer(ID_OV)         # et tout groupe fenetre orphelin (deuxieme « NOMBRE DE TRAVERSES », retour du 2026-11-03)


def _infos(calcs):
    out = []
    for t, c in zip(_trs, calcs):
        d = dict(c)
        d.update(haut=t['haut'], auto=t['auto'], hmm=t['h_mm'], mode=t.get('mode', 'libre'), cote=t.get('cote'),
                 l_auto=t.get('l_auto', True), l_mm=t.get('l_mm', 0.0))
        out.append(d)
    return out


def _extras():
    """Lignes de reglage sous les traverses : reseau de la traverse active, decaisse."""
    out = []
    if _trs and _actif().get('mode') == 'reseau':
        out.append('res')
    if _cfg['dec_on']:
        out.append('dec')
    return out


def _nrangs():
    return len(_trs) + 1 + len(_extras())


OV_SEP = 14                     # espace entre les reglages (en haut) et les lignes des traverses


def _yc(r):
    """Centre (pixels ecran, depuis le bas) de la ligne de rang logique r (0 = entete, 1..n = traverses,
    puis lignes de reglage). Affichage : entete, reglages (copies, decaisse), espace, puis les traverses."""
    k = _dpr()
    n, ne = len(_trs), len(_extras())
    nr = 1 + n + ne
    if r == 0:
        slot = 0
    elif r <= n:
        slot = 1 + ne + (r - 1)
    else:
        slot = 1 + (r - 1 - n)
    y = OV_Y + (nr - 1 - slot) * (OV_H * k + OV_GAP) + OV_H * k / 2.0
    if slot <= ne:
        y += OV_SEP * k
    return y



# --- Fenetres du bas a gauche toujours devant le modele (2026-11-05) ----------
# Une image posee en viewPlacement garde la profondeur de son point 3D : a
# l'origine, tout corps plus proche de la camera passait devant. On la decale
# vers la camera, juste devant la sphere englobante du modele, et on suit la
# camera (orbite, zoom) pour qu'elle reste toujours devant.
_dv = {'ents': [], 'h': None, 'c': None, 'r': 0.0, 't': 0.0}


def _dv_point():
    app = adsk.core.Application.get()
    des = adsk.fusion.Design.cast(app.activeProduct)
    if des is None:
        return None
    if time.time() - _dv['t'] > 1.0:
        _dv['t'] = time.time()
        bb = des.rootComponent.boundingBox
        if bb is None:
            _dv['c'] = None
        else:
            a, b = bb.minPoint, bb.maxPoint
            _dv['c'] = ((a.x + b.x) / 2.0, (a.y + b.y) / 2.0, (a.z + b.z) / 2.0)
            _dv['r'] = a.distanceTo(b) / 2.0
    c = _dv['c']
    if c is None:
        return None
    cam = app.activeViewport.camera
    e, t = cam.eye, cam.target
    d = (e.x - t.x, e.y - t.y, e.z - t.z)
    lg = math.sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2])
    if lg < 1e-9:
        return None
    d = (d[0] / lg, d[1] / lg, d[2] / lg)
    ec = (e.x - c[0]) * d[0] + (e.y - c[1]) * d[1] + (e.z - c[2]) * d[2]
    # juste devant le modele, mais jamais derriere la camera (perspective tres zoomee)
    s = min(_dv['r'] * 1.2 + 1.0, ec * 0.5) if ec > 0 else 0.0
    p = adsk.core.Point3D.create(c[0] + d[0] * s, c[1] + d[1] * s, c[2] + d[2] * s)
    occ = des.activeOccurrence
    if occ is not None:
        inv = occ.transform2.copy()
        inv.invert()
        p.transformBy(inv)
    return p


def _dv_appliquer(ents):
    p = _dv_point()
    if p is None:
        return
    m = adsk.core.Matrix3D.create()
    m.translation = adsk.core.Vector3D.create(p.x, p.y, p.z)
    for x in ents:
        x.transform = m


class _DvCamHandler(adsk.core.CameraEventHandler):
    def notify(self, args):
        try:
            ents = [x for x in _dv['ents'] if x.isValid]
            _dv['ents'] = ents
            if ents:
                _dv_appliquer(ents)
        except Exception:
            pass


def _dv_poser(ps):
    """A appeler apres chaque ps.viewPlacement = ... d'une fenetre du bas a gauche."""
    try:
        _dv['t'] = 0.0
        _dv_appliquer([ps])
        _dv['ents'] = [x for x in _dv['ents'] if x.isValid] + [ps]
        if _dv['h'] is None:
            h = _DvCamHandler()
            adsk.core.Application.get().cameraChanged.add(h)
            _dv['h'] = h
    except Exception:
        pass


def _dv_arreter():
    try:
        if _dv['h'] is not None:
            adsk.core.Application.get().cameraChanged.remove(_dv['h'])
    except Exception:
        pass
    _dv['h'] = None
    _dv['ents'] = []


def _ov_maj(calcs):
    try:
        infos = _infos(calcs)
        n = len(infos)
        sel = _cur['i']
        sig = (n, sel, bool(_cfg['ten_deb'] or _cfg['ten_fin']), bool(_cfg['dec_on']), round(_cfg['dec_h_mm'], 2), bool(_cfg['dec_arc']),
               tuple((d['ok'], round(d['L'], 3), round(d['h'], 3), d['haut'], d['auto'], round(d['hmm'], 2),
                      d['nfa'], d['nfv'], d['msg'], d['mode'], bool(d['cote']), bool(d['l_auto']), round(d['l_mm'], 2),
                      d.get('nok'), d.get('ntot')) for d in infos),
               tuple((t['r_n'], t['r_type'], t['r_align'], round(t['r_dist'], 1), round(t['r_m1'], 1), round(t['r_m2'], 1))
                     for t in _trs))
        if sig == _ov['sig'] and _ov['g'] is not None and _ov['g'].isValid:
            return False
        _ov_effacer()
        design = _design()
        g = design.activeComponent.customGraphicsGroups.add()      # composant actif : sinon grise
        g.id = ID_OV
        _ov['g'] = g            # affecte tout de suite : une erreur plus loin ne laisse plus d'orphelin
        k = _dpr()
        lignes = [_png_entete(n)] + [_png_ligne(i, i == sel, d) for i, d in enumerate(infos)]
        for x in _extras():
            lignes.append(_png_res(_actif(), calcs[sel]) if x == 'res' else _png_dec())
        for r, png in enumerate(lignes):
            ps = g.addPointSet(adsk.fusion.CustomGraphicsCoordinates.create([0.0, 0.0, 0.0]), [0],
                               adsk.fusion.CustomGraphicsPointTypes.UserDefinedCustomGraphicsPointType, png)
            ps.isSelectable = False
            ps.viewPlacement = adsk.fusion.CustomGraphicsViewPlacement.create(
                adsk.core.Point3D.create(0, 0, 0), adsk.fusion.ViewCorners.lowerLeftViewCorner,
                adsk.core.Point2D.create(OV_X + OV_W * k / 2.0, _yc(r)))
            _dv_poser(ps)
        _ov['sig'] = sig
        return True
    except Exception:
        _log('overlay erreur ' + traceback.format_exc()[-400:])
        return False


def _rang(vp, pos):
    """0 = entete, 1.. = traverses ; None si le curseur n'est sur aucune ligne."""
    if _ov['g'] is None:
        return None
    k = _dpr()
    h = vp.height * k
    nr = _nrangs()
    for r in range(nr):
        yc = h - _yc(r)
        if OV_X <= pos.x <= OV_X + OV_W * k and abs(pos.y - yc) <= OV_H * k / 2.0:
            return r
    return None


def _dans(pos, zone):
    k = _dpr()
    return OV_X + zone[0] * k <= pos.x <= OV_X + zone[1] * k


# Infobulles claires a droite de la ligne
_tip = {'g': None, 'cle': None}


def _tip_effacer():
    g = _tip['g']
    _tip['g'] = None
    _tip['cle'] = None
    try:
        if g is not None and g.isValid:
            g.deleteMe()
            _rafraichir_vue()
    except Exception:
        pass


def _rafraichir_vue():
    try:
        _app.activeViewport.refresh()
    except Exception:
        pass


def _tip_cible(vp, pos):
    r = _rang(vp, pos)
    if r is None:
        return None
    if r == 0:
        if _dans(pos, OV_MOINS):
            return ('m', 0, OV_MOINS[0], _tt('Une traverse de moins'))
        if _dans(pos, OV_PLUS):
            return ('p', 0, OV_PLUS[0], _tt('Une traverse de plus'))
        for m, txt in (('libre', 'Traverse entre deux chemins'), ('perp', 'Traverse perpendiculaire a un chemin'),
                       ('reseau', 'Reseau lineaire de traverses sur un chemin')):
            if _dans(pos, OV_MODES[m]):
                return ('mode_' + m, 0, OV_MODES[m][0], _tt(txt))
        return None
    ex = _extras()
    if r - 1 >= len(_trs) and ex[r - 1 - len(_trs)] == 'res':     # ligne de reglage du reseau
        t = _actif()
        if _dans(pos, OV_MOINS):
            return ('rm', r, OV_MOINS[0], _tt('Une copie de moins'))
        if _dans(pos, OV_PLUS):
            return ('rp', r, OV_PLUS[0], _tt('Une copie de plus'))
        if _dans(pos, OV_RTYPE):
            return ('rt', r, OV_RTYPE[0], _tt({'chemin': 'Reparties sur tout le chemin - clic : entre les bouts',
                                                'entre': 'Reparties entre les bouts, sans traverse aux extremites - clic : espacement',
                                                'espacement': 'Espacement entre copies - clic : etendue',
                                                'etendue': 'Etendue totale - clic : tout le chemin'}[t['r_type']]))
        if _dans(pos, OV_RALIGN) and t['r_type'] not in R_MARGES:
            return ('ra', r, OV_RALIGN[0], _tt({'debut': 'Depuis la pastille - clic : centre',
                                                 'centre': 'Centre sur la pastille - clic : jusqu\'a la pastille',
                                                 'fin': 'Jusqu\'a la pastille - clic : depuis la pastille'}[t['r_align']]))
        return None
    if r - 1 >= len(_trs):          # ligne de reglage du decaisse
        if _dans(pos, OV_MOINS):
            return ('dm', r, OV_MOINS[0], _tt('Decaisse moins haut'))
        if _dans(pos, OV_PLUS):
            return ('dp', r, OV_PLUS[0], _tt('Decaisse plus haut'))
        if _dans(pos, OV_FIN):
            return ('df', r, OV_FIN[0], _tt('Finition en arc de cercle - clic : droite') if _cfg['dec_arc'] else _tt('Finition droite - clic : arc de cercle'))
        return None
    t = _trs[r - 1]
    if _dans(pos, OV_TEN):
        return ('t', r, OV_TEN[0], _tt('Tenons actifs - clic : desactiver') if (_cfg['ten_deb'] or _cfg['ten_fin']) else _tt('Tenons - clic : activer'))
    if _dans(pos, OV_DEC):
        return ('d', r, OV_DEC[0], _tt('Decaisse actif - clic : desactiver') if _cfg['dec_on'] else _tt('Decaisse central - clic : activer'))
    if _dans(pos, OV_CROIX):
        return ('x', r, OV_CROIX[0], _tt('Supprimer cette traverse'))
    if _dans(pos, OV_ARROW):
        return ('a', r, OV_ARROW[0], _tt('Vers le haut - clic : vers le bas') if t['haut'] else _tt('Vers le bas - clic : vers le haut'))
    if _dans(pos, OV_HT):
        return ('h', r, OV_HT[0], _tt('Hauteur automatique - clic : manuelle') if t['auto'] else _tt('Hauteur manuelle - clic : automatique'))
    if t.get('mode', 'libre') != 'libre':
        if _dans(pos, OV_LB):
            return ('l', r, OV_LB[0], _tt('Longueur automatique - clic : manuelle') if t.get('l_auto', True) else _tt('Longueur manuelle - clic : automatique'))
        if _dans(pos, OV_COTE):
            return ('c', r, OV_COTE[0], _tt('Cote de la traverse - clic : inverser'))
    return None


def _tip_maj(vp, pos):
    c = _tip_cible(vp, pos) if _ov['g'] is not None else None
    cle = None if c is None else (c[0], c[1], c[3])
    if cle == _tip['cle'] and (cle is None or (_tip['g'] is not None and _tip['g'].isValid)):
        return
    _tip_effacer()
    if c is None:
        return
    png, w, h = _png_info(c[3])
    g = _design().activeComponent.customGraphicsGroups.add()
    g.id = ID_OV + '_tip'
    k = _dpr()
    gauche = OV_X + (OV_W + 8) * k
    haut = _yc(c[1]) - h * k / 2.0 - 8
    ps = g.addPointSet(adsk.fusion.CustomGraphicsCoordinates.create([0.0, 0.0, 0.0]), [0],
                       adsk.fusion.CustomGraphicsPointTypes.UserDefinedCustomGraphicsPointType, png)
    ps.isSelectable = False
    ps.viewPlacement = adsk.fusion.CustomGraphicsViewPlacement.create(
        adsk.core.Point3D.create(0, 0, 0), adsk.fusion.ViewCorners.lowerLeftViewCorner,
        adsk.core.Point2D.create(gauche + w * k / 2.0, haut + 8 + h * k / 2.0))
    _dv_poser(ps)
    _tip['g'] = g
    _tip['cle'] = cle
    _rafraichir_vue()


# --- Vignette sombre des tenons (meme dessin que la fenetre noire de Tenons CNC) -------------

TV_W, TV_H = 300, 150


def _trait(px, x0, y0, x1, y1, couleur, ep=1):
    h, w = len(px), len(px[0])
    x0, y0, x1, y1 = int(round(x0)), int(round(y0)), int(round(x1)), int(round(y1))
    dx, dy = abs(x1 - x0), -abs(y1 - y0)
    sx, sy = (1 if x0 < x1 else -1), (1 if y0 < y1 else -1)
    err = dx + dy
    while True:
        for a in range(ep):
            for b in range(ep):
                if 0 <= y0 + b < h and 0 <= x0 + a < w:
                    px[y0 + b][x0 + a] = couleur
        if x0 == x1 and y0 == y1:
            break
        e2 = 2 * err
        if e2 >= dy:
            err += dy
            x0 += sx
        if e2 <= dx:
            err += dx
            y0 += sy


def _rect_px(px, x0, y0, x1, y1, fond, bord, ep=1):
    h, w = len(px), len(px[0])
    for y in range(max(0, int(y0)), min(h, int(y1) + 1)):
        for x in range(max(0, int(x0)), min(w, int(x1) + 1)):
            px[y][x] = fond
    for a, b, c2, d2 in ((x0, y0, x1, y0), (x1, y0, x1, y1), (x1, y1, x0, y1), (x0, y1, x0, y0)):
        _trait(px, a, b, c2, d2, bord, ep)


def _texte_c(px, txt, cx, cy, couleur):
    w = len(txt) * 8
    _texte_px(px, txt, max(2, min(len(px[0]) - w - 2, int(cx - w / 2.0))), max(2, min(len(px) - 12, int(cy - 5))), couleur)


def _mm(cm):
    return ('%.1f' % (cm * 10.0)).rstrip('0').rstrip('.')


def _cote(px, x0, x1, y, label):
    gris = (154, 154, 160, 255)
    _trait(px, x0, y - 4, x0, y + 4, gris)
    _trait(px, x1, y - 4, x1, y + 4, gris)
    _trait(px, x0, y, x1, y, gris)
    _texte_c(px, label, (x0 + x1) / 2.0, y - 11, (201, 201, 204, 255))


VUE_W, VUE_H = 360, 172
C_FOND, C_BARRE, C_BORD = (21, 22, 26, 255), (42, 44, 51, 255), (74, 76, 85, 255)
C_TEN, C_TEN_F, C_GRIS, C_CLAIR = (255, 140, 0, 255), (96, 60, 18, 255), (154, 154, 160, 255), (201, 201, 204, 255)


def _png_vue(c):
    """Vignette unique en haut de la fenetre : la traverse de profil (longueur, hauteur, tenons, decaisse)
    avec toutes les cotes. Meme palette sombre que la fenetre de Tenons CNC."""
    w, h = VUE_W, VUE_H
    ok_geo = bool(c and c.get('coins'))
    if not ok_geo:
        cle = 'vue_vide_%s_%s' % (c['msg'] if c else '', _tt('Traverse'))
    else:
        cle = 'vue_%s_%s_%s_%s_%s_%s_%s' % (
            _mm(c['L']), _mm(c['h']), _mm(_demi_ep(c) * 2.0), c['msg'],
            '_'.join('%s,%s,%s' % (_mm(b[0]), _mm(b[1]), _mm(b[3] - b[2])) for b in (c.get('tenons') or [])),
            ('%s,%s,%s,%d' % (_mm(c['cut']['d1']), _mm(c['cut']['d2']), _mm(c['cut']['R']), c['cut']['arc'])) if c.get('cut') else '-',
            _cfg['dec_on'])
    if cle in _png_cache and os.path.isfile(_png_cache[cle]):
        return _png_cache[cle]
    px = [[C_FOND] * w for _ in range(h)]
    if not ok_geo:
        _rect_px(px, 22, 70, 296, 100, C_BARRE, (61, 63, 71, 255))
        txt = _tt({'FACES': '2 FACES OU AUCUNE', 'LONG': 'EXTREMITES CONFONDUES', 'HAUT': 'AUCUN CORPS : SAISISSEZ H',
                   'ORIENT': 'TRAVERSE VERTICALE', 'CHEMINS': 'SELECTIONNEZ LES DEUX CHEMINS',
                   'CHEMIN': 'SELECTIONNEZ UN CHEMIN', 'LONGA': 'AUCUN CORPS EN FACE : SAISISSEZ L'}.get(
                       c['msg'] if c else 'CHEMINS', 'TRAVERSE IMPOSSIBLE'))
        _texte_c(px, txt, w / 2.0, 140, C_GRIS)
        return _ecrire_png(cle, px, w, h)
    L, H = c['L'], c['h']
    ep = _demi_ep(c) * 2.0
    tenons = c.get('tenons') or []
    hu = max([b[3] - b[2] for b in tenons if b[2] >= H - 1e-6] or [0.0])
    hd = max([b[3] - b[2] for b in tenons if b[3] <= 1e-6] or [0.0])
    x0, x1 = 22.0, 296.0
    sx = (x1 - x0) / L
    htot = H + hu + hd
    sy = min(76.0 / htot, sx * 4.0)
    y_haut = 64.0 + (76.0 - htot * sy) / 2.0
    ytop = y_haut + hu * sy
    ybot = ytop + H * sy

    def X(v): return x0 + v * sx
    def Y(v): return ybot - v * sy
    _rect_px(px, x0, ytop, x1, ybot, C_BARRE, C_BORD)
    for b in tenons:
        ya, yb = Y(b[3]), Y(b[2])
        _rect_px(px, X(b[0]), ya, max(X(b[0]) + 2, X(b[1])), yb, C_TEN_F, C_TEN)
    cut = c.get('cut')
    if cut:
        pp = [(X(a), Y(b)) for a, b in cut['pts']]
        for xi in range(int(round(pp[0][0])), int(round(pp[-1][0])) + 1):
            yp = None
            for (ax, ay), (bx, by) in zip(pp[:-1], pp[1:]):
                if abs(bx - ax) > 1e-9 and min(ax, bx) - 0.5 <= xi <= max(ax, bx) + 0.5:
                    u = max(0.0, min(1.0, (xi - ax) / (bx - ax)))
                    yp = ay + u * (by - ay)
                    break
            if yp is not None:
                for yy in range(int(round(ytop)), int(round(yp)) + 1):     # le trait du dessus disparait au-dessus du decaisse
                    if 0 <= yy < h and 0 <= xi < w:
                        px[yy][xi] = C_FOND
        for (ax, ay), (bx, by) in zip(pp[:-1], pp[1:]):
            _trait(px, ax, ay, bx, by, (0, 190, 255, 255), 2)
    if cut:                         # profondeur du decaisse
        xm = X(L / 2.0)
        yf = Y(H - cut['R'])
        _trait(px, xm, ytop, xm, yf, (0, 190, 255, 255))
        _trait(px, xm - 3, yf, xm + 3, yf, (0, 190, 255, 255))
        _texte_px(px, _mm(cut['R']), int(xm) + 6, int(yf) + 4, (0, 190, 255, 255))
    # cotes : longueur, hauteur, epaisseur
    _cote(px, x0, x1, 18, 'L ' + _mm(L) + ' MM')
    xv = x1 + 14
    _trait(px, xv, ytop, xv, ybot, C_GRIS)
    _trait(px, xv - 4, ytop, xv + 4, ytop, C_GRIS)
    _trait(px, xv - 4, ybot, xv + 4, ybot, C_GRIS)
    _texte_px(px, 'H ' + _mm(H), int(xv) + 8, int((ytop + ybot) / 2.0) - 12, C_CLAIR)
    _texte_px(px, 'EP ' + _mm(ep), int(xv) + 8, int((ytop + ybot) / 2.0) + 2, C_CLAIR)
    # cotes du decaisse sous la traverse
    yb = ybot + hd * sy + 16
    if cut:
        xs = [0.0, cut['d1'], L - cut['d2'], L]
        for a, b in zip(xs[:-1], xs[1:]):
            lab = _mm(b - a)
            if X(b) - X(a) >= len(lab) * 8 + 6:
                _cote(px, X(a), X(b), yb, lab)
            else:
                _trait(px, X(a), yb - 4, X(a), yb + 4, C_GRIS)
                _trait(px, X(b), yb - 4, X(b), yb + 4, C_GRIS)
                _trait(px, X(a), yb, X(b), yb, C_GRIS)
    # cotes des tenons (debut) au-dessus
    hautes = [b for b in tenons if b[2] >= H - 1e-6]
    if hautes:
        b0 = min(hautes, key=lambda b: b[0])
        yc = y_haut - 14
        _cote(px, X(b0[0]), max(X(b0[0]) + 2, X(b0[1])), yc, _mm(b0[1] - b0[0]))
        if b0[0] > 1e-6:
            _trait(px, x0, yc - 4, x0, yc + 4, C_GRIS)
            _trait(px, x0, yc, X(b0[0]), yc, C_GRIS)
        _texte_px(px, _mm(b0[0]), int(x0) + 2, int(yc) + 6, C_GRIS) if X(b0[0]) - x0 >= len(_mm(b0[0])) * 8 + 4 else None
        _texte_px(px, 'H ' + _mm(b0[3] - b0[2]), int(max(X(b0[0]) + 2, X(b0[1]))) + 8, int(yc) - 5, C_TEN)
    ligne = 160
    if c['msg'] in ('TENON', 'DEC', 'HORS'):
        _texte_c(px, _tt({'TENON': 'TENONS IMPOSSIBLES', 'DEC': 'DECAISSE IMPOSSIBLE', 'HORS': 'HORS DU CHEMIN'}[c['msg']]),
                 w / 2.0, min(ligne, h - 8), ROUGE)
    return _ecrire_png(cle, px, w, h)


# --- Selection : lecture / chargement / blocage des clics sur les fenetres ------

def _selections(sel):
    return [sel.selection(i).entity for i in range(sel.selectionCount)]


def _bloquer_selection(inputs):
    _bloc['t'] = time.time()
    _bloc['sel'] = {iid: [e.entityToken for e in _selections(inputs.itemById(iid))] for iid in SEL_IDS}


def _restaurer_selection(inputs, iid):
    """Un clic sur une fenetre ne doit rien selectionner derriere : on remet la selection d'avant."""
    if _bloc['sel'] is None or (time.time() - _bloc['t'] > 1.0 and not _drag.get('maison') and not _qd.get('on')):
        return False
    design = _design()
    for k in SEL_IDS:
        sel = inputs.itemById(k)
        voulus = _bloc['sel'].get(k, [])
        if [e.entityToken for e in _selections(sel)] == voulus:
            continue
        sel.clearSelection()
        for e in _ents(design, voulus):
            sel.addSelection(e)
    return True


def _charger_selection(inputs):
    """Remplit les champs de selection avec ceux de la traverse active."""
    t = _actif()
    design = _design()
    for iid, cle in CLES_SEL.items():
        sel = inputs.itemById(iid)
        sel.clearSelection()
        for e in _ents(design, t[cle]):
            sel.addSelection(e)


def _lire_selection(inputs, iid):
    t = _actif()
    cle = CLES_SEL[iid]
    avant = list(t[cle])
    t[cle] = [e.entityToken for e in _selections(inputs.itemById(iid))]
    if iid in ('chemin1', 'chemin2') and t[cle] != avant:
        k = '1' if iid == 'chemin1' else '2'
        t['s' + k] = 0.5
        if t[cle]:
            try:
                # la fleche apparait la ou l'on a clique sur le chemin
                sel = inputs.itemById(iid)
                pt = sel.selection(sel.selectionCount - 1).point
                if pt is not None:
                    t['s' + k] = _traj(t[cle], _design()).frac_point((pt.x, pt.y, pt.z))
            except Exception:
                _log('point de clic indisponible ' + traceback.format_exc()[-200:])
            if k == '1' and t.get('mode', 'libre') != 'libre' and t.get('l_auto', True):
                _cote_auto(_design(), t)
    # champ suivant : on enchaine chemin 1 -> chemin 2 -> faces amont -> faces aval
    # chemin 2 choisi : on reste sur ce champ (aretes / courbes seulement), pour qu'attraper une poignee ne
    # selectionne pas une face ; les faces de centrage se choisissent en cliquant leur champ (2026-11-04)
    suivant = {'chemin1': 'chemin2' if t.get('mode', 'libre') == 'libre' else None, 'faces_amont': 'faces_aval'}.get(iid)
    plein = len(t[cle]) >= (2 if iid.startswith('faces') else 1)
    if suivant and plein and len(avant) < len(t[cle]):
        try:
            inputs.itemById(suivant).hasFocus = True
        except Exception:
            pass


# --- Poignees (fleches natives sur les chemins) --------------------------------

_pastilles = {}
ID_PASTILLE = 'TraverseCNC_pastille%d'


def _ep_courante():
    return _cur.get('ep') or load_prefs()['epaisseur_mm'] / 10.0


def _poignees(t, design):
    """[(k, trajet, fraction)] des pastilles de la traverse t. 2 chemins : une par extremite ; 1 chemin : une ;
    reseau : marges du debut et de la fin (chemin entier) ou point de depart + distance (espacement / etendue)."""
    mode = t.get('mode', 'libre')
    if mode == 'libre':
        return [(k, _traj(t['c%d' % k], design), t['s%d' % k]) for k in (1, 2) if t['c%d' % k]]
    if not t['c1']:
        return []
    tr = _traj(t['c1'], design)
    if mode == 'perp':
        return [(1, tr, t['s1'])]
    Lt = tr.longueur
    xs, (a, b) = _reseau_pos(t, Lt, _ep_courante())
    out = [(1, tr, max(0.0, min(1.0, a / Lt)))]
    if t['r_type'] in R_MARGES or int(t['r_n']) > 1:
        out.append((2, tr, max(0.0, min(1.0, b / Lt))))
    return out


def _poignee_set(t, k, f, tr):
    """La pastille k est amenee a la fraction f du chemin : reglage correspondant de la traverse."""
    mode = t.get('mode', 'libre')
    if mode != 'reseau':
        t['s%d' % k] = f
        return
    Lt = tr.longueur
    x = f * Lt
    e = _ep_courante() / 2.0
    if t['r_type'] in R_MARGES:
        if k == 1:
            t['r_m1'] = round(max(0.0, min(x - e, Lt - 2.0 * e - t['r_m2'] / 10.0)) * 10.0, 1)
        else:
            t['r_m2'] = round(max(0.0, min(Lt - x - e, Lt - 2.0 * e - t['r_m1'] / 10.0)) * 10.0, 1)
        return
    if k == 1:
        t['s1'] = f
        return
    A = t['s1'] * Lt
    E = {'debut': x - A, 'fin': A - x, 'centre': 2.0 * (x - A)}[t['r_align']]
    E = max(0.0, E)
    n = max(1, int(t['r_n']))
    t['r_dist'] = round((E / (n - 1) if (t['r_type'] == 'espacement' and n > 1) else E) * 10.0, 1)


def _maj_pastilles():
    """Pastilles orange de la traverse active (remplacent la fleche native : les tirer ne relance pas le cycle
    de Fusion). Recreees si Fusion les a annulees (appel aussi depuis executePreview)."""
    if _caf is None:
        return
    t = _actif()
    design = _design()
    try:
        hs = _poignees(t, design)
    except Exception:
        _log('pastilles : ' + traceback.format_exc()[-200:])
        hs = []
    qp = None
    try:
        qp = _qp_pos(t, design)
    except Exception:
        pass
    ks = set(h[0] for h in hs)
    if qp is not None:
        ks.add(0)
    for k in list(_pastilles):
        if k not in ks:
            g = _pastilles.pop(k, None)
            if g is not None:
                g.effacer()
    for k, tr, f in hs:
        try:
            g = _pastilles.get(k)
            if g is None:
                g = _pastilles[k] = _caf.Poignee(ID_PASTILLE % k)
                _camera_suivre(True)
            g.placer(tr.at(f)[0])
        except Exception:
            _log('pastille %d : %s' % (k, traceback.format_exc()[-200:]))
    if qp is not None and not _qd.get('on'):
        try:
            g = _pastilles.get(0)
            if g is None:
                g = _pastilles[0] = _caf.Poignee(ID_PASTILLE % 0, 'quantite')
                _camera_suivre(True)
            g.placer(qp[0].at(qp[1])[0])
        except Exception:
            _log('pastille quantite : ' + traceback.format_exc()[-200:])


# --- Poignee de quantite du reseau (comme Reseau CNC, 2026-11-05) ---------------------------------
# Pastille bleue « - + » entre les deux pastilles du reseau. Glissee le long du chemin : vers la droite de
# l'ecran le nombre de traverses augmente, vers la gauche il diminue, avec la meme courbe que Reseau CNC
# (1 a 20 sur les 3/4 de la demi-longueur, puis jusqu'au maximum). Relachee, elle revient au milieu.

_qd = {'on': False}
Q_EXP = 1.6


def _q_de_t(u, qm=R_NMAX):
    u = max(0.0, min(1.0, u))
    if u <= 0.75:
        q = 1 + 19.0 * u / 0.75
    else:
        q = 20 + (max(qm, 21) - 20) * (((u - 0.75) / 0.25) ** Q_EXP)
    return max(1, min(qm, int(round(q))))


def _q_t(q, qm=R_NMAX):
    qm = max(21, qm)
    if q <= 20:
        return 0.75 * (max(1, q) - 1) / 19.0
    return 0.75 + 0.25 * (min(1.0, (q - 20) / float(qm - 20)) ** (1.0 / Q_EXP))


def _qp_pos(t, design):
    """(trajet, fraction) de la poignee de quantite : au milieu des pastilles du reseau actif."""
    if _caf is None or t.get('mode') != 'reseau' or not t['c1']:
        return None
    hs = _poignees(t, design)
    if not hs:
        return None
    tr = hs[0][1]
    fs = [h[2] for h in hs]
    f = sum(fs) / len(fs)
    if len(fs) == 1 or abs(fs[-1] - fs[0]) < 0.04:
        f = fs[0] + (0.08 if fs[0] < 0.5 else -0.08)
    return tr, max(0.0, min(1.0, f))


def _qd_debut(ins, vp, pos):
    g = _pastilles.get(0)
    if g is None or g.p is None:
        return False
    q = vp.modelToViewSpace(adsk.core.Point3D.create(*g.p))
    if math.hypot(q.x - pos.x, q.y - pos.y) > 14.0 * _dpr():
        return False
    t = _actif()
    qp = _qp_pos(t, _design())
    if qp is None:
        return False
    tr, fm = qp
    p, tg = tr.at(fm)
    sens = 1.0
    try:                               # droite de l'ecran = plus de traverses, quel que soit le sens du chemin
        a = vp.modelToViewSpace(adsk.core.Point3D.create(*p))
        b = vp.modelToViewSpace(adsk.core.Point3D.create(*_v_add(p, _v_mul(tg, tr.longueur * 0.01))))
        if b.x - a.x < 0:
            sens = -1.0
    except Exception:
        pass
    _cur['ep'] = _ep_cm(ins)
    _qd.clear()
    _qd.update(on=True, tr=tr, fm=fm, sens=sens, t0=_q_t(int(t['r_n'])), tm=0.0)
    _souris.update(pos=pos, vp=vp, t=time.perf_counter())
    return True


def _qd_glisser(vp):
    t0 = time.perf_counter()
    if not _qd.get('on') or t0 - _qd.get('tm', 0.0) < 0.012:
        return
    _qd['tm'] = t0
    try:
        t = _actif()
        design = _design()
        tr = _qd['tr']
        f = _frac_souris(tr, vp, _souris['pos'])
        q = _q_de_t(_qd['t0'] + _qd['sens'] * (f - _qd['fm']) / 0.5)
        g = _pastilles.get(0)
        if g is not None:
            g.placer(tr.at(f)[0])
        if q != int(t['r_n']):
            t['r_n'] = q
            i = _cur['i']
            calcs = list(_cur['calcs'])
            if i < len(calcs):
                calcs[i] = _calc(design, t, _cur['ep'], rapide=True)
                _cur['calcs'] = calcs
                _apercu_maj(calcs, live=True)
                _ov_maj(calcs)                   # nombre de copies a jour dans la fenetre
            for kk, trk, fk in _poignees(t, design):
                gk = _pastilles.get(kk)
                if gk is not None:
                    gk.placer(trk.at(fk)[0])
        vp.refresh()
    except Exception:
        _log('poignee quantite : ' + traceback.format_exc()[-300:])


def _qd_fin(ins):
    _qd['on'] = False
    _qd.pop('tr', None)
    _bloc['t'] = time.time()
    _appliquer(lambda: _sync_champs(ins), ins, True)       # champ « nombre », pastilles a leur place
    _apercu_maj(_cur['calcs'], force=True)
    _rafraichir_vue()
    _redessiner_differe()


class _CameraHandler(adsk.core.CameraEventHandler):
    """La vue tourne : les pastilles sont recalees devant la camera (elles passent devant les corps)."""
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            for g in list(_pastilles.values()):
                g.recaler(args.viewport)
        except Exception:
            pass


_camera = {'h': None}


def _camera_suivre(oui):
    try:
        if oui and _camera['h'] is None and _caf is not None:
            _camera['h'] = _CameraHandler()
            _app.cameraChanged.add(_camera['h'])
        elif not oui and _camera['h'] is not None:
            _app.cameraChanged.remove(_camera['h'])
            _camera['h'] = None
    except Exception:
        _log('camera : ' + traceback.format_exc()[-200:])


def _pastilles_effacer():
    for g in list(_pastilles.values()):
        g.effacer()
    _pastilles.clear()
    if _caf is not None:
        for k in (0, 1, 2):
            _caf.balayer(ID_PASTILLE % k)



def _pastille_touchee(vp, pos):
    """Numero de la pastille attrapee : sur la pastille, sinon sur son chemin (saut au point clique ; sur un
    chemin qui porte deux pastilles, la plus proche du point clique)."""
    t = _actif()
    design = _design()
    r = 14.0 * _dpr()
    hs = _poignees(t, design)
    best = None
    for k, tr, f in hs:
        p = tr.at(f)[0]
        q = vp.modelToViewSpace(adsk.core.Point3D.create(*p))
        d = math.hypot(q.x - pos.x, q.y - pos.y)
        if d <= r and (best is None or d < best[0]):
            best = (d, k)
    if best is not None:
        return best[1], None
    vus = set()
    for k, tr, f in hs:
        if id(tr) in vus:
            continue
        vus.add(id(tr))
        ecr = _ecran(tr, vp)
        for j in range(len(ecr) - 1):
            ax, ay = ecr[j]
            ex, ey = ecr[j + 1][0] - ax, ecr[j + 1][1] - ay
            e2 = ex * ex + ey * ey
            u = 0.0 if e2 < 1e-12 else max(0.0, min(1.0, ((pos.x - ax) * ex + (pos.y - ay) * ey) / e2))
            d = math.hypot(ax + u * ex - pos.x, ay + u * ey - pos.y)
            if d <= r * 0.75 and (best is None or d < best[0]):
                fc = (tr.cum[j] + u * (tr.cum[j + 1] - tr.cum[j])) / tr.longueur
                kk = min((h for h in hs if h[1] is tr), key=lambda h: abs(h[2] - fc))[0]
                best = (d, kk, fc)
    return (best[1], best[2]) if best is not None else (None, None)


def _placer_poignees(inputs):
    t = _actif()
    if _caf is not None or t.get('mode', 'libre') != 'libre':
        for k in (1, 2):
            try:
                inputs.itemById('poignee%d' % k).isVisible = False
            except Exception:
                pass
        _maj_pastilles()
        return
    design = _design()
    for k in (1, 2):
        ph = inputs.itemById('poignee%d' % k)
        try:
            if not t['c%d' % k]:
                ph.isVisible = False
                continue
            tr = _traj(t['c%d' % k], design)
            p, tg = tr.at(t['s%d' % k])
            ph.isVisible = True
            ph.setManipulator(adsk.core.Point3D.create(*p), adsk.core.Vector3D.create(*tg))
            ph.value = 0.0
        except Exception:
            ph.isVisible = False


def _ecran(tr, vp):
    """Points du chemin projetes a l'ecran (gardes tant que la camera ne bouge pas)."""
    try:
        cam = vp.camera
        cle = (id(tr), tuple(round(v, 4) for v in cam.eye.asArray() + cam.target.asArray() + cam.upVector.asArray()),
               round(cam.viewExtents, 4), vp.width, vp.height)
    except Exception:
        cle = None
    c = getattr(tr, '_scr', None)
    if c is None or cle is None or c[0] != cle:
        res = []
        P3 = adsk.core.Point3D.create
        for p in tr.pts:
            q = vp.modelToViewSpace(P3(p[0], p[1], p[2]))
            res.append((q.x, q.y))
        tr._scr = (cle, res)
    return tr._scr[1]


def _frac_souris(tr, vp, m):
    """Fraction du chemin dont le point est le plus proche de la souris, a l'ecran."""
    ecr = _ecran(tr, vp)
    best = min(range(len(ecr)), key=lambda i: (ecr[i][0] - m.x) ** 2 + (ecr[i][1] - m.y) ** 2)
    sb = tr.cum[best]
    db = (ecr[best][0] - m.x) ** 2 + (ecr[best][1] - m.y) ** 2
    for j in (best - 1, best):
        if 0 <= j < len(ecr) - 1:
            ax, ay = ecr[j]
            ex, ey = ecr[j + 1][0] - ax, ecr[j + 1][1] - ay
            e2 = ex * ex + ey * ey
            if e2 < 1e-12:
                continue
            u = max(0.0, min(1.0, ((m.x - ax) * ex + (m.y - ay) * ey) / e2))
            dd = (ax + u * ex - m.x) ** 2 + (ay + u * ey - m.y) ** 2
            if dd < db:
                db, sb = dd, tr.cum[j] + u * (tr.cum[j + 1] - tr.cum[j])
    return sb / tr.longueur


def _poignee_tiree(inputs, k):
    t = _actif()
    design = _design()
    tr = _traj(t['c%d' % k], design)
    ph = inputs.itemById('poignee%d' % k)
    recent = _souris['pos'] is not None and time.perf_counter() - _souris['t'] <= 0.5
    if recent:
        f = _frac_souris(tr, _souris['vp'], _souris['pos'])
    else:
        p, tg = tr.at(t['s%d' % k])
        q = _v_add(p, _v_mul(tg, ph.value))
        f = tr.proche_3d(q)
    t['s%d' % k] = f
    p, tg = tr.at(f)
    ph.setManipulator(adsk.core.Point3D.create(*p), adsk.core.Vector3D.create(*tg))     # la fleche suit le curseur
    ph.value = 0.0
    _drag['k'] = k


# --- Rafraichissement global ---------------------------------------------------

MESSAGES = {
    'CHEMINS': "Selectionnez le chemin de debut et le chemin de fin de la traverse.",
    'FACES': "Selectionnez 2 faces au debut et 2 faces a la fin, ou aucune.",
    'LONG': "Les deux extremites sont confondues.",
    'ORIENT': "Traverse verticale : non geree.",
    'HAUT': "Aucun corps trouve dans ce sens : saisissez une hauteur.",
    'TENON': "Tenons impossibles : chant trop court pour ces reglages.",
    'DEC': "Decaisse impossible : distance ou hauteur trop grande pour cette traverse.",
    'CHEMIN': "Selectionnez le chemin : la traverse sera perpendiculaire a ce chemin.",
    'LONGA': "Aucun corps en face : inversez le cote ou saisissez une longueur.",
    'HORS': "Traverse hors du chemin : reduisez la distance ou le nombre.",
    'ERR': "Calcul impossible pour cette traverse."}


NC_CP = {'CP10': 1.0, 'CP15': 1.5, 'CP18': 1.8}      # epaisseurs de contreplaque (cm), comme Reseau CNC


def _ep_noms(design):
    """Noms proposes : CP10 / CP15 / CP18 puis les autres parametres CPxx du projet."""
    noms = list(NC_CP)
    try:
        ups = design.userParameters
        for i in range(ups.count):
            n = ups.item(i).name
            if n.upper().startswith('CP') and n not in noms:
                noms.append(n)
    except Exception:
        pass
    return noms


def _ep_cm_nom(design, nom):
    p = design.allParameters.itemByName(nom)
    return p.value if p is not None else NC_CP.get(nom, 1.8)


def _ep_remplir(dd, design, defaut_cm):
    """Liste deroulante des epaisseurs (CPxx du projet + « Autre... ») ; renvoie True si une valeur est choisie."""
    trouve = False
    for n in _ep_noms(design):
        cm = _ep_cm_nom(design, n)
        sel = (not trouve) and abs(cm - defaut_cm) < 1e-4
        trouve = trouve or sel
        dd.listItems.add('%s (%s mm)' % (n, ('%.2f' % (cm * 10.0)).rstrip('0').rstrip('.')), sel, '')
    dd.listItems.add('Autre...', not trouve, '')
    return trouve


def _ep_choisir(inputs, cm):
    """Selectionne la ligne dont la valeur est cm, sinon « Autre... » avec la valeur saisie."""
    dd = inputs.itemById('ep_dd')
    design = _design()
    noms = _ep_noms(design)
    for i, n in enumerate(noms):
        if abs(_ep_cm_nom(design, n) - cm) < 1e-4:
            dd.listItems.item(i).isSelected = True
            inputs.itemById('ep_autre').isVisible = False
            return
    dd.listItems.item(dd.listItems.count - 1).isSelected = True
    a = inputs.itemById('ep_autre')
    a.value = cm
    a.isVisible = True


def _ep_cm(inputs):
    try:
        dd = inputs.itemById('ep_dd')
        if dd is not None:
            if dd.selectedItem.index == dd.listItems.count - 1:
                return max(0.01, inputs.itemById('ep_autre').value)
            design = _design()
            return max(0.01, _ep_cm_nom(design, _ep_noms(design)[dd.selectedItem.index]))
        return max(0.01, inputs.itemById('epaisseur').value)
    except Exception:
        return max(0.01, load_prefs()['epaisseur_mm'] / 10.0)


def _ep_parametre(design, inputs, ep_cm):
    """Le parametre d'epaisseur existe dans le projet : CP10 / CP15 / CP18 crees s'ils manquent, ou CPxx
    pour une epaisseur libre (comme Reseau CNC). Renvoie son nom."""
    nom = None
    try:
        dd = inputs.itemById('ep_dd')
        if dd is not None and dd.selectedItem.index < dd.listItems.count - 1:
            nom = _ep_noms(design)[dd.selectedItem.index]
    except Exception:
        nom = None
    if nom is None:
        nom = 'CP' + ('%g' % round(ep_cm * 10.0, 2)).replace('.', '_')
    if design.allParameters.itemByName(nom) is None:
        design.userParameters.add(nom, adsk.core.ValueInput.createByReal(ep_cm), 'mm', 'Epaisseur contreplaque')
    return nom


CFG_CHAMPS = {'ten_deb': ('b', 'ten_deb'), 'ten_fin': ('b', 'ten_fin'), 'ten_haut': ('b', 'ten_haut'),
              'ten_bas': ('b', 'ten_bas'), 'ten_h_auto': ('b', 'ten_h_auto'), 'dec_fin': ('dd', 'dec_arc'),
              'ten_n': ('i', 'ten_n'),
              'ten_len': ('mm', 'ten_len_mm'), 'ten_h': ('mm', 'ten_h_mm'), 'ten_edge': ('mm', 'ten_edge_mm'),
              'ten_centrer': ('b', 'ten_centrer'), 'dec_on': ('b', 'dec_on'), 'dec_auto': ('b', 'dec_auto'),
              'dec_dist': ('mm', 'dec_dist_mm'), 'dec_dist2': ('mm', 'dec_dist2_mm'), 'dec_h': ('mm', 'dec_h_mm')}


def _lire_cfg(inputs):
    """Champs de la boite -> reglages communs (tenons, decaisse)."""
    for iid, (genre, cle) in CFG_CHAMPS.items():
        inp = inputs.itemById(iid)
        if inp is None:
            continue
        if genre == 'b':
            _cfg[cle] = bool(inp.value)
        elif genre == 'dd':
            _cfg[cle] = inp.selectedItem is None or inp.selectedItem.index == 0
        elif genre == 'i':
            _cfg[cle] = int(inp.value)
        else:
            _cfg[cle] = max(0.0, inp.value * 10.0)


def _champs_cfg(inputs):
    """Reglages communs -> champs ; activation selon les cases cochees."""
    for iid, (genre, cle) in CFG_CHAMPS.items():
        inp = inputs.itemById(iid)
        if inp is None:
            continue
        if genre == 'dd':
            inp.listItems.item(0 if _cfg[cle] else 1).isSelected = True
            continue
        inp.value = _cfg[cle] if genre in ('b', 'i') else _cfg[cle] / 10.0
    ten = _cfg['ten_deb'] or _cfg['ten_fin']
    for iid in ('ten_haut', 'ten_bas', 'ten_h_auto', 'ten_n', 'ten_len', 'ten_h', 'ten_edge', 'ten_centrer'):
        inputs.itemById(iid).isEnabled = ten
    inputs.itemById('ten_h').isEnabled = ten and not _cfg['ten_h_auto']
    inputs.itemById('ten_edge').isEnabled = ten and not _cfg['ten_centrer']
    for iid in ('dec_auto', 'dec_dist', 'dec_dist2', 'dec_h', 'dec_fin'):
        inputs.itemById(iid).isEnabled = _cfg['dec_on']
    inputs.itemById('dec_dist').isEnabled = _cfg['dec_on'] and not _cfg['dec_auto']
    inputs.itemById('dec_dist2').isEnabled = _cfg['dec_on'] and not _cfg['dec_auto']


def _maj_vignette(inputs, c):
    """Vignette unique en haut de la fenetre (mise a jour au rafraichissement complet, pas pendant le glisser)."""
    img = inputs.itemById('vue')
    if img is None:
        return
    try:
        img.imageFile = _png_vue(c)
    except Exception:
        _log('vignette erreur ' + traceback.format_exc()[-300:])


def _sync_mode(inputs, t):
    """Champs propres au mode de la traverse active (visibles / actifs) et leurs valeurs."""
    mode = t.get('mode', 'libre')
    try:
        dd = inputs.itemById('mode')
        if dd is not None:
            dd.listItems.item(MODES.index(mode)).isSelected = True
        inputs.itemById('chemin2').isVisible = mode == 'libre'
        for iid in ('l_auto', 'longueur', 'cote'):
            inputs.itemById(iid).isVisible = mode != 'libre'
        inputs.itemById('l_auto').value = bool(t.get('l_auto', True))
        inputs.itemById('longueur').value = t.get('l_mm', 500.0) / 10.0
        inputs.itemById('longueur').isEnabled = not t.get('l_auto', True)
        inputs.itemById('cote').value = bool(t.get('cote'))
        g = inputs.itemById('grp_res')
        g.isVisible = mode == 'reseau'
        if mode == 'reseau':
            g.isExpanded = True
        inputs.itemById('r_n').value = int(t['r_n'])
        inputs.itemById('r_type').listItems.item(R_TYPES.index(t['r_type'])).isSelected = True
        inputs.itemById('r_align').listItems.item(R_ALIGNS.index(t['r_align'])).isSelected = True
        inputs.itemById('r_dist').value = t['r_dist'] / 10.0
        inputs.itemById('r_m1').value = t['r_m1'] / 10.0
        inputs.itemById('r_m2').value = t['r_m2'] / 10.0
        chemin = t['r_type'] in R_MARGES
        for iid in ('r_dist', 'r_align'):
            inputs.itemById(iid).isVisible = not chemin      # seulement les reglages utiles a la repartition
        for iid in ('r_m1', 'r_m2'):
            inputs.itemById(iid).isVisible = chemin
    except Exception:
        _log('sync mode : ' + traceback.format_exc()[-300:])


def _sync_champs(inputs):
    """Les champs de la boite suivent la traverse active."""
    t = _actif()
    _sync_mode(inputs, t)
    inputs.itemById('nb').value = len(_trs)
    inputs.itemById('haut').value = bool(t['haut'])
    inputs.itemById('hauteur_auto').value = bool(t['auto'])
    inputs.itemById('hauteur').value = t['h_mm'] / 10.0
    inputs.itemById('hauteur').isEnabled = not t['auto']


def _rafraichir(inputs, poignees=False):
    design = _design()
    ep = _ep_cm(inputs)
    _cur['ep'] = ep
    calcs = [_calc(design, t, ep) for t in _trs]
    _cur['calcs'] = calcs
    c = calcs[_cur['i']]
    if c.get('inst') is not None and c['ok']:
        txt = _tt('Reseau {0} : {1} traverse(s) sur {2}, longueur {3} mm, hauteur {4} mm.').replace('{0}', str(_cur['i'] + 1)) \
            .replace('{1}', str(c['nok'])).replace('{2}', str(c['ntot'])) \
            .replace('{3}', str(int(round(c['L'] * 10)))).replace('{4}', str(int(round(c['h'] * 10))))
        if c['nok'] < c['ntot']:
            txt += ' ' + _tt(MESSAGES['HORS'])
    elif c['ok']:
        txt = _tt('Traverse {0} : longueur {1} mm, hauteur {2} mm.').replace('{0}', str(_cur['i'] + 1)) \
            .replace('{1}', str(int(round(c['L'] * 10)))).replace('{2}', str(int(round(c['h'] * 10))))
        if c['nfa'] == 2 or c['nfv'] == 2:
            txt += ' ' + _tt('Centrage : debut {0} mm, fin {1} mm.').replace('{0}', '%.1f' % c.get('dec1', 0.0)) \
                .replace('{1}', '%.1f' % c.get('dec2', 0.0))
        if c.get('cut'):
            txt += ' ' + _tt('Plate-bande : debut {0} mm, fin {1} mm.').replace('{0}', '%d' % round(c['cut']['d1'] * 10)) \
                .replace('{1}', '%d' % round(c['cut']['d2'] * 10))
    else:
        txt = _tt(MESSAGES.get(c['msg'], MESSAGES['ERR']))
    inputs.itemById('msg').text = txt
    _maj_vignette(inputs, c)
    if poignees:
        _placer_poignees(inputs)
    force = bool(_ov_maj(calcs))
    _apercu_maj(calcs, force)
    _rafraichir_vue()


def _rafraichir_rapide(inputs):
    """Pendant le glisser d'une fleche : seule la traverse active est recalculee (hauteur
    automatique conservee), son aperçu est mis a jour en place, ni fenetres ni texte ni
    autre calcul : c'est le relachement qui fait le rafraichissement complet."""
    design = _design()
    ep = _ep_cm(inputs)
    _cur['ep'] = ep
    i = _cur['i']
    calcs = list(_cur['calcs'])
    while len(calcs) < len(_trs):
        calcs.append(_calc(design, _trs[len(calcs)], ep))
    calcs[i] = _calc(design, _trs[i], ep, rapide=True)
    _cur['calcs'] = calcs
    _apercu_maj(calcs, live=True)


def _appliquer(fn, inputs, poignees=False):
    """Ecritures de champs sous garde (leurs evenements sont ignores), puis rafraichissement."""
    _en_cours['v'] = True
    try:
        fn()
        _rafraichir(inputs, poignees)
    finally:
        _en_cours['v'] = False


def _rebloquer(inputs):
    """La selection a restaurer apres un clic sur une fenetre est celle d'APRES l'operation
    (sinon la selection de l'ancienne traverse revenait dans les champs)."""
    try:
        _bloquer_selection(inputs)
    except Exception:
        pass


def _set_nb(inputs, n):
    n = max(1, min(NB_MAX, int(n)))
    if n == len(_trs):
        return

    ajout = n > len(_trs)

    def f():
        modele = _actif() if _trs else None
        while len(_trs) < n:
            t = _nouvelle()
            if modele is not None:
                t.update({k: modele[k] for k in ('mode', 'cote', 'l_auto', 'l_mm', 'r_n', 'r_type', 'r_dist', 'r_align',
                                                 'r_m1', 'r_m2', 'haut', 'auto', 'h_mm')})
            _trs.append(t)
        del _trs[n:]
        _cur['i'] = n - 1 if ajout else min(_cur['i'], n - 1)       # la traverse ajoutee devient la traverse active
        _charger_selection(inputs)
        _sync_champs(inputs)
    _appliquer(f, inputs, True)
    _rebloquer(inputs)
    if ajout:
        try:
            inputs.itemById('chemin1').hasFocus = True              # chemin de debut pret a etre choisi
        except Exception:
            pass


def _choisir(inputs, i):
    if i == _cur['i']:
        return

    def f():
        _cur['i'] = i
        _charger_selection(inputs)
        _sync_champs(inputs)
    _appliquer(f, inputs, True)
    _rebloquer(inputs)


def _supprimer(inputs, i):
    def f():
        if len(_trs) > 1:
            del _trs[i]
            _cur['i'] = max(0, min(_cur['i'] if _cur['i'] < i else _cur['i'] - (1 if _cur['i'] > i else 0), len(_trs) - 1))
        else:
            _trs[0] = _nouvelle()
        _charger_selection(inputs)
        _sync_champs(inputs)
    _appliquer(f, inputs, True)
    _rebloquer(inputs)


def _bascule_ten(inputs):
    def f():
        on = not (_cfg['ten_deb'] or _cfg['ten_fin'])
        _cfg['ten_deb'] = _cfg['ten_fin'] = on
        _champs_cfg(inputs)
        if on:
            inputs.itemById('grp_ten').isExpanded = True
    _appliquer(f, inputs)
    _rebloquer(inputs)


def _bascule_dec(inputs):
    def f():
        _cfg['dec_on'] = not _cfg['dec_on']
        _champs_cfg(inputs)
        if _cfg['dec_on']:
            inputs.itemById('grp_dec').isExpanded = True
    _appliquer(f, inputs)
    _rebloquer(inputs)


def _reglage_dec(inputs, genre):
    def f():
        if genre == 'dm':
            _cfg['dec_h_mm'] = max(5.0, _cfg['dec_h_mm'] - 5.0)
        elif genre == 'dp':
            _cfg['dec_h_mm'] = min(500.0, _cfg['dec_h_mm'] + 5.0)
        else:
            _cfg['dec_arc'] = not _cfg['dec_arc']
        _champs_cfg(inputs)
    _appliquer(f, inputs)
    _rebloquer(inputs)


def _vider_caches(t):
    """Mesures automatiques (hauteur, longueur, corps des bouts) a refaire."""
    t['h_auto'] = None
    t['ctx'] = None
    t['L_auto_c'] = None
    t['_inst'] = []
    t['sig'] = None


def _set_mode(inputs, m):
    t = _actif()
    if t.get('mode', 'libre') == m:
        return

    def f():
        t['mode'] = m
        _vider_caches(t)
        if m != 'libre' and t['c1'] and t.get('l_auto', True):
            _cote_auto(_design(), t)
        _sync_champs(inputs)
    _appliquer(f, inputs, True)
    _rebloquer(inputs)
    if not t['c1'] or (m == 'libre' and not t['c2']):
        try:
            inputs.itemById('chemin1' if not t['c1'] else 'chemin2').hasFocus = True
        except Exception:
            pass


def _bascule_long(inputs, i):
    def f():
        t = _trs[i]
        c = _cur['calcs'][i] if i < len(_cur['calcs']) else None
        if t.get('l_auto', True) and c is not None and c['ok']:
            t['l_mm'] = round(c['L'] * 10.0, 1)          # passage en manuel : on part de la longueur trouvee
        t['l_auto'] = not t.get('l_auto', True)
        _vider_caches(t)
        if i == _cur['i']:
            _sync_champs(inputs)
    _appliquer(f, inputs, True)
    _rebloquer(inputs)


def _bascule_cote(inputs, i):
    def f():
        t = _trs[i]
        t['cote'] = not t.get('cote')
        _vider_caches(t)
        if i == _cur['i']:
            _sync_champs(inputs)
    _appliquer(f, inputs, True)
    _rebloquer(inputs)


def _reglage_res(inputs, genre):
    t = _actif()

    def f():
        if genre == 'rm':
            t['r_n'] = max(1, int(t['r_n']) - 1)
        elif genre == 'rp':
            t['r_n'] = min(R_NMAX, int(t['r_n']) + 1)
        elif genre == 'ra':
            t['r_align'] = R_ALIGNS[(R_ALIGNS.index(t['r_align']) + 1) % len(R_ALIGNS)]
        else:
            nv = R_TYPES[(R_TYPES.index(t['r_type']) + 1) % len(R_TYPES)]
            _changer_type(t, nv)
        _sync_champs(inputs)
    _appliquer(f, inputs, True)
    _rebloquer(inputs)


def _changer_type(t, nv):
    """Changement de repartition sans saut : les copies gardent leur place (depart, espacement ou etendue
    repris des positions actuelles)."""
    try:
        if t['c1']:
            Lt = _traj(t['c1'], _design()).longueur
            xs, _p = _reseau_pos(t, Lt, _ep_courante())
            if nv not in R_MARGES and xs:
                t['s1'] = max(0.0, min(1.0, xs[0] / Lt))
                t['r_align'] = 'debut'
                E = abs(xs[-1] - xs[0])
                n = len(xs)
                t['r_dist'] = round((E / (n - 1) if (nv == 'espacement' and n > 1) else E) * 10.0, 1) or t['r_dist']
    except Exception:
        _log('changer type : ' + traceback.format_exc()[-200:])
    t['r_type'] = nv


def _bascule_haut(inputs, i):
    def f():
        _trs[i]['haut'] = not _trs[i]['haut']
        _vider_caches(_trs[i])
        if i == _cur['i']:
            _sync_champs(inputs)
    _appliquer(f, inputs)


def _bascule_auto(inputs, i):
    def f():
        _trs[i]['auto'] = not _trs[i]['auto']
        if i == _cur['i']:
            _sync_champs(inputs)
    _appliquer(f, inputs)


# --- Creation ------------------------------------------------------------------

GROUPE_TL = GROUPE_NOM


def _nom_libre(comp, base):
    noms = set(comp.bRepBodies.item(i).name for i in range(comp.bRepBodies.count))
    k = 1
    while '%s %d' % (base, k) in noms:
        k += 1
    return '%s %d' % (base, k)


def _boite_tbm(tbm, c, x0, x1, y0, y1, z0, z1):
    """Boite temporaire pour des bornes locales (x le long de la traverse, y en hauteur, z en epaisseur)."""
    P3, V3 = adsk.core.Point3D.create, adsk.core.Vector3D.create
    ctr = _w(c, ((x0 + x1) / 2.0, (y0 + y1) / 2.0, (z0 + z1) / 2.0))
    obb = adsk.core.OrientedBoundingBox3D.create(P3(*ctr), V3(*c['ah']), V3(*c['lat']), x1 - x0, z1 - z0, y1 - y0)
    return tbm.createBox(obb)


def _corps_temporaire(c, ep_cm):
    """Corps de la traverse : boite, plus les tenons de bout, moins le decaisse (pave + deux cylindres)."""
    tbm = adsk.fusion.TemporaryBRepManager.get()
    P3 = adsk.core.Point3D.create
    UN, DIFF = adsk.fusion.BooleanTypes.UnionBooleanType, adsk.fusion.BooleanTypes.DifferenceBooleanType
    e = ep_cm / 2.0
    corps = _boite_tbm(tbm, c, 0.0, c['L'], 0.0, c['h'], -e, e)
    for b in c.get('tenons') or []:
        tbm.booleanOperation(corps, _boite_tbm(tbm, c, *b), UN)
    cut = c.get('cut')
    if cut:
        R, h = cut['R'], c['h']
        m = 0.5                                              # depassement de l'outil (cm)
        outil = _boite_tbm(tbm, c, cut['x1'], cut['x2'], h - R, h + m, -e - m, e + m)
        if cut['arc']:
            for cx in (cut['cx1'], cut['cx2']):
                cyl = tbm.createCylinderOrCone(P3(*_w(c, (cx, h, -e - m))), R, P3(*_w(c, (cx, h, e + m))), R)
                tbm.booleanOperation(outil, cyl, UN)
        tbm.booleanOperation(corps, outil, DIFF)
    return corps


def _blob(ep_cm):
    """Reglages de TOUTES les traverses de la fenetre, ecrits sur ce que l'on cree : l'historique de
    CNC Toolkit peut ainsi rouvrir la fenetre telle qu'elle etait."""
    return json.dumps({'v': 1, 'trs': [{k: t[k] for k in CLES_TR} for t in _trs], 'cfg': dict(_cfg),
                       'ep': ep_cm, 'i': _cur['i']})


def _creer_corps(design, c, ep_cm, blob=None, repere=True, idx=None):
    tmp = _corps_temporaire(c, ep_cm)
    comp = design.activeComponent
    param = design.designType == adsk.fusion.DesignTypes.ParametricDesignType
    if param:
        bf = comp.features.baseFeatures.add()
        bf.startEdit()
        try:
            corps = comp.bRepBodies.add(tmp, bf)
        finally:
            bf.finishEdit()
    else:
        bf = None
        corps = comp.bRepBodies.add(tmp)
    corps.name = _nom_libre(comp, _tt('Traverse'))
    if blob:
        for obj in (bf, corps):
            try:
                if obj is not None:
                    obj.attributes.add(ATTR_G, ATTR_N, blob)
            except Exception:
                _log('attribut erreur ' + traceback.format_exc()[-200:])
    if idx is not None and bf is not None:
        try:
            bf.attributes.add(ATTR_G, 'idx', idx)              # traverse : copie, pour le recalcul automatique
        except Exception:
            pass
    if param and repere:
        # 2e entree de chronologie : Fusion ne cree un groupe qu'a partir de 2 entrees, et l'historique
        # de CNC Toolkit ne liste que les groupes. Esquisse masquee avec un point au centre de la traverse
        # (un point de construction est refuse en conception parametrique : « Environment is not supported »).
        try:
            sk = comp.sketches.add(comp.xYConstructionPlane)
            sk.name = 'Repere ' + corps.name if repere is True else 'Repere ' + GROUPE_NOM
            q = sk.modelToSketchSpace(adsk.core.Point3D.create(*c['centre']))
            sk.sketchPoints.add(adsk.core.Point3D.create(q.x, q.y, 0.0))
            sk.isLightBulbOn = False
            if blob:
                sk.attributes.add(ATTR_G, ATTR_N, blob)
        except Exception:
            _log('repere erreur ' + traceback.format_exc()[-300:])
    return corps, bf


# --- Recalcul automatique (fonction personnalisee Fusion) ----------------------------------------------
# Demande de Maxence (2026-11-05) : les traverses restent parametriques ; si le chemin (ou les faces) change,
# elles suivent toutes seules. Les fonctions de base d'une utilisation sont regroupees dans une fonction
# personnalisee « Traverse CNC » dependant des chemins et des faces choisis ; quand Fusion la recalcule, chaque
# corps est recalcule avec les reglages memorises (blob) et remplace en place (updateBody : les fonctions
# qui l'utilisent ensuite suivent). API en preversion chez Autodesk : en cas d'echec, creation classique.

CF_ID = 'TraverseCNC_auto'


def _png_icone(path, n):
    import zlib
    import struct
    raw = b''
    for y in range(n):
        ligne = b''
        for x in range(n):
            dans = n // 3 <= y < 2 * n // 3 or (x < n // 6 or x >= n - n // 6)
            ligne += bytes(ORANGE) if dans else b'\x00\x00\x00\x00'
        raw += b'\x00' + ligne

    def ch(t, d):
        return struct.pack('>I', len(d)) + t + d + struct.pack('>I', zlib.crc32(t + d) & 0xffffffff)
    with open(path, 'wb') as f:
        f.write(b'\x89PNG\r\n\x1a\n' + ch(b'IHDR', struct.pack('>IIBBBBB', n, n, 8, 6, 0, 0, 0)) +
                ch(b'IDAT', zlib.compress(raw)) + ch(b'IEND', b''))


def _cf_definir():
    try:
        d = os.path.join(_ADDIN_DIR, 'resources_cf')
        os.makedirs(d, exist_ok=True)
        for n in (16, 32, 64):
            for nom, m in (('%dx%d.png' % (n, n), n), ('%dx%d@2x.png' % (n, n), 2 * n)):
                if not os.path.isfile(os.path.join(d, nom)):
                    _png_icone(os.path.join(d, nom), m)
        cdef = adsk.fusion.CustomFeatureDefinition.create(CF_ID, GROUPE_NOM, d)
        cdef.editCommandId = CMD_ID
        h = _CfCompute()
        cdef.customFeatureCompute.add(h)
        _cf['def'], _cf['h'] = cdef, h
    except Exception:
        _cf['def'] = None
        _log('fonction personnalisee indisponible : ' + traceback.format_exc()[-300:])


def _faces_mesurees(design, insts, nmax=24):
    """Faces des corps au-dessus (ou en dessous) des bouts des traverses : celles qui donnent la hauteur et la
    plate-bande. Dependances de la fonction personnalisee : si ce corps bouge (hauteur du caisson...), Fusion
    recalcule les traverses (verifie : une arete ou une face declenche le recalcul, un corps non)."""
    out, vus = [], set()
    P3 = adsk.core.Point3D.create
    for ci in insts:
        for o in (ci['p1'], ci['p2'], ci.get('centre')):
            if o is None or len(out) >= nmax:
                continue
            if o is ci.get('centre'):
                o = _v_sub(o, _v_mul(ci['d'], ci['h'] / 2.0))      # milieu, au pied de la traverse
            q = P3(o[0], o[1], o[2])
            hits = _rayon(design, q, ci['d'])
            best = None
            for f, t in hits or []:
                if t is None or t < 1e-3 or (best is not None and t >= best[0]):
                    continue
                try:
                    if f.body.pointContainment(q) != adsk.fusion.PointContainment.PointOutsidePointContainment:
                        continue
                except Exception:
                    continue
                best = (t, f)
            if best is not None:
                try:
                    tok = best[1].entityToken
                except Exception:
                    continue
                if tok not in vus:
                    vus.add(tok)
                    out.append(best[1])
    return out


def _cf_creer(design, bfs, trs, blob, faces=()):
    """Fonction personnalisee autour des fonctions de base bfs ; None si impossible (creation classique)."""
    if _cf['def'] is None or not bfs:
        return None
    try:
        comp = design.activeComponent
        ci = comp.features.customFeatures.createInput(_cf['def'])
        ci.setStartAndEndFeatures(bfs[0], bfs[-1])
        jetons = []
        for t in trs:
            for k in ('c1', 'c2', 'fa', 'fv'):
                for tok in t.get(k) or []:
                    if tok not in jetons:
                        jetons.append(tok)
        deps = {}
        for k, tok in enumerate(jetons):
            e = _ents(design, [tok])
            if e:
                try:
                    ci.addDependency('d%d' % k, e[0])
                    deps[tok] = 'd%d' % k
                except Exception:
                    _log('dependance refusee : ' + traceback.format_exc()[-150:])
        try:
            for k, f in enumerate(faces):
                ci.addDependency('m%d' % k, f)
        except Exception:
            _log('dependances des corps mesures : ' + traceback.format_exc()[-200:])
        _cf['creation'] = True
        try:
            cf = comp.features.customFeatures.add(ci)
        finally:
            _cf['creation'] = False
        cf.attributes.add(ATTR_G, ATTR_N, blob)
        cf.attributes.add(ATTR_G, 'deps', json.dumps(deps))
        return cf
    except Exception:
        _cf['creation'] = False
        _log('fonction personnalisee : creation impossible ' + traceback.format_exc()[-400:])
        return None


def _cf_recalculer(cf):
    design = cf.parentComponent.parentDesign
    a = cf.attributes.itemByName(ATTR_G, ATTR_N)
    if a is None:
        return
    blob = json.loads(a.value)
    da = cf.attributes.itemByName(ATTR_G, 'deps')
    deps = json.loads(da.value) if da is not None else {}
    bfs = {}
    ign = set()
    for f in cf.features:
        try:
            if f.objectType != adsk.fusion.BaseFeature.classType():
                continue
            bf = adsk.fusion.BaseFeature.cast(f)
            ia = bf.attributes.itemByName(ATTR_G, 'idx')
            if ia is not None:
                bfs[ia.value] = bf
            bf.startEdit()                   # pendant le recalcul, les corps ne sont lisibles qu'en edition
            try:
                for i in range(bf.bodies.count):
                    ign.add(bf.bodies.item(i).entityToken)
            finally:
                bf.finishEdit()
        except Exception:
            continue
    for tok, did in deps.items():                  # entites a jour (le chemin a pu changer) sous leurs anciens jetons
        try:
            dp = cf.dependencies.itemById(did)
            if dp is not None and dp.entity is not None:
                _cache_ent[tok] = dp.entity
        except Exception:
            pass
    for c in (_cache_traj, _cache_forme, _cache_faces):
        c.clear()
    p = load_prefs()
    trs = []
    for d in blob.get('trs', []):
        t = _nouvelle(p)
        t.update({k: d[k] for k in CLES_TR if k in d})
        trs.append(t)
    ep = float(blob.get('ep', 1.8))
    sauve = dict(_cfg)
    _cfg.update({k: v for k, v in (blob.get('cfg') or {}).items() if k in CFG_DEFAUT})
    _cf['ignores'] = ign
    n = 0
    try:
        for i, t in enumerate(trs):
            c = _calc(design, t, ep)
            for j, ci in enumerate(c['inst'] if c.get('inst') is not None else [c]):
                bf = bfs.get('%d:%d' % (i, j))
                if bf is None or not ci['ok']:
                    _log('recalcul automatique %d:%d : %s (corps garde tel quel)' % (i, j, ci['msg']))
                    continue
                tmp = _corps_temporaire(ci, ep)
                bf.startEdit()
                try:
                    if bf.bodies.count and bf.updateBody(bf.bodies.item(0), tmp):
                        n += 1
                finally:
                    bf.finishEdit()
    finally:
        _cf['ignores'] = set()
        _cfg.clear()
        _cfg.update(sauve)
        for c in (_cache_traj, _cache_forme, _cache_faces, _cache_ent):
            c.clear()
    _log('recalcul automatique : %d corps sur %d' % (n, len(bfs)))


class _CfCompute(adsk.fusion.CustomFeatureEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        if _cf['creation']:
            return
        try:
            _cf_recalculer(args.customFeature)
        except Exception:
            _log('recalcul automatique erreur ' + traceback.format_exc()[-500:])


def _cf_edition():
    """La commande est lancee par Fusion pour modifier une fonction « Traverse CNC » (fonction personnalisee
    selectionnee) : meme modification que depuis l'historique (reglages memorises, remplacement a la validation)."""
    try:
        sel = _ui.activeSelections
        cf = None
        for i in range(sel.count):
            e = adsk.fusion.CustomFeature.cast(sel.item(i).entity)
            if e is not None and e.definition is not None and e.definition.id == CF_ID:
                cf = e
                break
        if cf is None:
            return
        a = cf.attributes.itemByName(ATTR_G, ATTR_N)
        if a is None:
            return
        g = None
        try:
            g = cf.timelineObject.parentGroup
        except Exception:
            pass
        ents = [g.item(i).entity for i in range(g.count)] if g is not None else [cf]
        _edition['v'] = {'blob': json.loads(a.value), 'anciens': [e.entityToken for e in ents]}
        try:
            tl = _design().timeline
            idx = g.item(0).index if g is not None else cf.timelineObject.index
            if tl.markerPosition != idx:
                tl.markerPosition = idx
        except Exception:
            _log('edition fonction : marqueur ' + traceback.format_exc()[-200:])
    except Exception:
        _edition['v'] = None
        _log('edition fonction ' + traceback.format_exc()[-300:])


def _creer_tout(design, ep, blob):
    """Corps de toutes les traverses de _trs (une fonction de base par corps), puis la fonction personnalisee
    qui les recalcule, puis un repere (2e entree : le groupe « Traverse CNC » de l'historique). Nombre de corps."""
    param = design.designType == adsk.fusion.DesignTypes.ParametricDesignType
    a_faire = []
    for i, t in enumerate(_trs):
        c = _calc(design, t, ep)
        for j, ci in enumerate(c['inst'] if c.get('inst') is not None else [c]):     # reseau : un corps par copie
            if ci['ok']:
                a_faire.append(('%d:%d' % (i, j), ci))
    faces = []
    if param:
        try:
            faces = _faces_mesurees(design, [ci for _k, ci in a_faire])     # avant les corps : rayons sans traverses
        except Exception:
            _log('faces mesurees : ' + traceback.format_exc()[-200:])
    bfs, centres = [], []
    for k, ci in a_faire:
        _corps, bf = _creer_corps(design, ci, ep, blob, repere=False, idx=k)
        if bf is not None:
            bfs.append(bf)
        centres.append(ci['centre'])
    if param and bfs:
        _cf_creer(design, bfs, _trs, blob, faces)
        try:
            comp = design.activeComponent
            sk = comp.sketches.add(comp.xYConstructionPlane)
            sk.name = 'Repere ' + GROUPE_NOM
            q = sk.modelToSketchSpace(adsk.core.Point3D.create(*centres[0]))
            sk.sketchPoints.add(adsk.core.Point3D.create(q.x, q.y, 0.0))
            sk.isLightBulbOn = False
            sk.attributes.add(ATTR_G, ATTR_N, blob)
        except Exception:
            _log('repere erreur ' + traceback.format_exc()[-300:])
    return len(centres)


def _grouper(tl, debut, fin=None):
    """Une utilisation = un groupe replie (fin == debut : on renomme l'entree)."""
    try:
        if fin is None:
            fin = tl.markerPosition - 1
        if fin > debut:
            grp = tl.timelineGroups.add(debut, fin)
            grp.name = GROUPE_TL
            grp.isCollapsed = True
        elif fin == debut:
            tl.item(debut).name = GROUPE_TL
    except Exception:
        _log('groupement erreur ' + traceback.format_exc()[-300:])


# --- Evenements de la commande --------------------------------------------------

def _glisser_souris(vp):
    """Pendant le glisser d'une fleche, l'aperçu suit la SOURIS a la cadence des evenements souris (et non a celle
    du cycle de calcul de Fusion, ~40 ms par changement de la fleche) : seule la matrice des groupes change."""
    t0 = time.perf_counter()
    if _en_cours['v'] or t0 - _drag.get('tm', 0.0) < 0.008 or _cur.get('ep') is None:
        return
    _drag['tm'] = t0
    k = _drag['k']
    t = _actif()
    design = _design()
    tr = next((h[1] for h in _poignees(t, design) if h[0] == k), None)
    if tr is None:
        return
    _poignee_set(t, k, _frac_souris(tr, vp, _souris['pos']), tr)
    i = _cur['i']
    calcs = list(_cur['calcs'])
    if i >= len(calcs):
        return
    calcs[i] = _calc(design, _trs[i], _cur['ep'], rapide=True)
    _cur['calcs'] = calcs
    _apercu_maj(calcs, live=True)
    if _drag.get('maison'):
        # glisser maison (pastille) : aucun cycle Fusion, donc on demande le redessin (~6 ms mesures)
        for kk, trk, fk in _poignees(t, design):
            g = _pastilles.get(kk)
            if g is not None:
                g.placer(trk.at(fk)[0])
        vp.refresh()
    _perf['mm'] += 1
    _perf['c'] += time.perf_counter() - t0


class _MouseHandler(adsk.core.MouseEventHandler):
    def __init__(self, nom): super().__init__(); self.nom = nom
    def notify(self, args):
        try:
            _souris.update(pos=args.viewportPosition, vp=args.viewport, t=time.perf_counter())
            if _qd.get('on') and self.nom == 'mouseDrag':
                _qd_glisser(args.viewport)
            elif _drag.get('maison') and _drag['k'] is not None and (self.nom == 'mouseDrag' or _drag.get('pris')):
                _glisser_souris(args.viewport)     # glisser bouton enfonce, ou poignee attrapee par un clic
            elif self.nom == 'mouseMove':
                if _drag['k'] is None:
                    _tip_maj(args.viewport, args.viewportPosition)
        except Exception:
            pass


class _PreSelectHandler(adsk.core.SelectionEventHandler):
    """Rien n'est preselectionnable sous une poignee (ni pendant son glisser) : on attrape la poignee,
    pas la face ou l'arete qui est derriere."""
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            if _drag.get('maison') or _qd.get('on'):
                args.isSelectable = False
                return
            vp, pos = _souris.get('vp'), _souris.get('pos')
            if _caf is None or vp is None or pos is None or not _pastilles:
                return
            r = 16.0 * _dpr()
            for g in _pastilles.values():
                if g.p is None:
                    continue
                q = vp.modelToViewSpace(adsk.core.Point3D.create(*g.p))
                if math.hypot(q.x - pos.x, q.y - pos.y) <= r:
                    args.isSelectable = False
                    return
        except Exception:
            pass


class _MouseDownHandler(adsk.core.MouseEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            ins = args.firingEvent.sender.commandInputs
            vp, pos = args.viewport, args.viewportPosition
            _tip_effacer()
            if _drag.get('pris') and _drag['k'] is not None:
                # poignee attrapee par un clic : ce clic la pose (aucun rectangle de selection)
                _bloquer_selection(ins)
                _fin_maison(ins)
                return
            r = _rang(vp, pos)
            if r is None:
                _bloc['sel'] = None
                if _caf is not None and args.button == adsk.core.MouseButtons.LeftMouseButton:
                    if _qd_debut(ins, vp, pos):
                        _bloquer_selection(ins)
                        return
                    k, f = _pastille_touchee(vp, pos)
                    if k is not None:
                        _bloquer_selection(ins)
                        _cur['ep'] = _ep_cm(ins)
                        if f is not None:
                            tt = _actif()
                            trk = next((h[1] for h in _poignees(tt, _design()) if h[0] == k), None)
                            if trk is not None:
                                _poignee_set(tt, k, f, trk)
                        _drag.update(k=k, maison=True, tm=0.0, pris=False, pd=(pos.x, pos.y), td=time.perf_counter())
                        _souris.update(pos=pos, vp=vp, t=time.perf_counter())
                        _glisser_souris(vp)
                return
            _bloquer_selection(ins)
            try:
                self._clic(ins, vp, pos, r)
            finally:
                _redessiner_differe()
        except Exception:
            _log('mouseDown erreur ' + traceback.format_exc()[-400:])

    def _clic(self, ins, vp, pos, r):
        try:
            if r == 0:
                if _dans(pos, OV_MOINS):
                    _set_nb(ins, len(_trs) - 1)
                elif _dans(pos, OV_PLUS):
                    _set_nb(ins, len(_trs) + 1)
                else:
                    for m in MODES:
                        if _dans(pos, OV_MODES[m]):
                            _set_mode(ins, m)
                return
            i = r - 1
            if i >= len(_trs):
                c = _tip_cible(vp, pos)
                if c is not None:
                    if c[0] in ('rm', 'rp', 'rt', 'ra'):
                        _reglage_res(ins, c[0])
                    else:
                        _reglage_dec(ins, c[0])
                return
            if _trs[i].get('mode', 'libre') != 'libre' and (_dans(pos, OV_LB) or _dans(pos, OV_COTE)):
                if i != _cur['i']:
                    _choisir(ins, i)
                _bascule_long(ins, i) if _dans(pos, OV_LB) else _bascule_cote(ins, i)
                return
            if _dans(pos, OV_TEN):
                _bascule_ten(ins)
            elif _dans(pos, OV_DEC):
                _bascule_dec(ins)
            elif _dans(pos, OV_CROIX):
                _supprimer(ins, i)
            elif _dans(pos, OV_ARROW):
                _bascule_haut(ins, i)
            elif _dans(pos, OV_HT):
                _bascule_auto(ins, i)
            else:
                _choisir(ins, i)
        except Exception:
            _log('mouseDown erreur ' + traceback.format_exc()[-400:])


_perf = {'mm': 0, 'c': 0.0, 'n': 0, 'm': 0, 'a': 0.0, 'b': 0.0, 'p': 0.0, 'np': 0, 'gap': 0.0, 'dernier': 0.0}


def _perf_bilan():
    n, m, npv = _perf['n'], _perf['m'], _perf['np']
    if _perf['mm'] or n:
        _log('perf souris : %d mouvements suivis, %.2f ms chacun' % (_perf['mm'], 1000 * _perf['c'] / max(1, _perf['mm'])))
    if n:
        _log('perf glisser : %d evenements (ecart moyen %.1f ms), poignee %.2f ms, recalcul+apercu %.2f ms (x%d), preview %.2f ms (x%d)' % (
            n, 1000 * _perf['gap'] / max(1, n - 1), 1000 * _perf['a'] / n, 1000 * _perf['b'] / max(1, m), m,
            1000 * _perf['p'] / max(1, npv), npv))
    _perf.update(mm=0, c=0.0, n=0, m=0, a=0.0, b=0.0, p=0.0, np=0, gap=0.0, dernier=0.0)


def _clic_simple(pos):
    """Appui puis relachement rapide, sans bouger : la poignee est attrapee (elle suit la souris sans bouton,
    donc sans le rectangle de selection de Fusion) jusqu'au clic suivant."""
    pd = _drag.get('pd')
    if pd is None or pos is None:
        return False
    return time.perf_counter() - _drag.get('td', 0.0) < 0.4 and math.hypot(pos.x - pd[0], pos.y - pd[1]) < 5.0 * _dpr()


def _fin_maison(ins):
    _drag['k'] = None
    if _drag.get('maison'):
        _drag['maison'] = False
        _drag['pris'] = False
        _bloc['t'] = time.time()           # la selection faite par le relachement est encore annulee
    _perf_bilan()
    _appliquer(lambda: _sync_champs(ins), ins, True)       # pastilles sur leur chemin, champs (reseau) a jour
    _apercu_maj(_cur['calcs'], force=True)    # image finale propre (le glisser n'a ecrit que des coordonnees)
    _rafraichir_vue()
    _redessiner_differe()


class _MouseUpHandler(adsk.core.MouseEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            if _qd.get('on'):
                _qd_fin(args.firingEvent.sender.commandInputs)
                return
            if _drag['k'] is not None:
                if _drag.get('maison') and not _drag.get('pris') and _clic_simple(args.viewportPosition):
                    _drag['pris'] = True
                    _bloc['t'] = time.time()
                    return
                if _drag.get('pris'):
                    return                         # attrapee : c'est le prochain clic qui la pose
                _fin_maison(args.firingEvent.sender.commandInputs)
        except Exception:
            _log('mouseUp erreur ' + traceback.format_exc()[-400:])


class _InputChangedHandler(adsk.core.InputChangedEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            inp = args.input
            ins = inp.parentCommand.commandInputs
            iid = inp.id
            if _en_cours['v']:
                return
            if iid in SEL_IDS and _restaurer_selection(ins, iid):
                return
            t = _actif()
            if iid in SEL_IDS:
                _en_cours['v'] = True
                try:
                    _lire_selection(ins, iid)
                    _rafraichir(ins, True)
                finally:
                    _en_cours['v'] = False
            elif iid in ('poignee1', 'poignee2'):
                _en_cours['v'] = True
                try:
                    t0 = time.perf_counter()
                    _poignee_tiree(ins, int(iid[-1]))
                    mt = time.perf_counter()
                    _perf['n'] += 1
                    _perf['a'] += mt - t0
                    if _perf['dernier']:
                        _perf['gap'] += t0 - _perf['dernier']
                    _perf['dernier'] = mt
                    if mt - _drag.get('t', 0.0) >= 0.016:       # ~60 images / s max : le reste est rattrape au relachement
                        _drag['t'] = mt
                        _rafraichir_rapide(ins)
                        _perf['b'] += time.perf_counter() - mt
                        _perf['m'] += 1
                finally:
                    _en_cours['v'] = False
            elif iid == 'nb':
                _set_nb(ins, inp.value)
            elif iid == 'haut':
                t['haut'] = bool(inp.value)
                _vider_caches(t)
                _appliquer(lambda: None, ins)
            elif iid == 'mode':
                m = MODES[max(0, min(len(MODES) - 1, inp.selectedItem.index if inp.selectedItem else 0))]
                _set_mode(ins, m)
            elif iid in ('l_auto', 'longueur', 'cote', 'r_n', 'r_type', 'r_dist', 'r_align', 'r_m1', 'r_m2'):
                if iid == 'l_auto':
                    if bool(inp.value) != bool(t.get('l_auto', True)):
                        _bascule_long(ins, _cur['i'])
                    return
                if iid == 'cote':
                    if bool(inp.value) != bool(t.get('cote')):
                        _bascule_cote(ins, _cur['i'])
                    return
                if iid == 'longueur':
                    t['l_mm'] = max(1.0, inp.value * 10.0)
                    t['l_auto'] = False
                elif iid == 'r_n':
                    t['r_n'] = max(1, min(R_NMAX, int(inp.value)))
                elif iid == 'r_type':
                    _changer_type(t, R_TYPES[inp.selectedItem.index if inp.selectedItem else 0])
                elif iid == 'r_align':
                    t['r_align'] = R_ALIGNS[inp.selectedItem.index if inp.selectedItem else 0]
                else:
                    t[iid] = max(0.0, inp.value * 10.0)
                _vider_caches(t) if iid == 'longueur' else None
                _appliquer(lambda: _sync_champs(ins), ins, True)
            elif iid == 'hauteur_auto':
                t['auto'] = bool(inp.value)

                def f():
                    ins.itemById('hauteur').isEnabled = not t['auto']
                _appliquer(f, ins)
            elif iid == 'hauteur':
                t['h_mm'] = max(0.1, inp.value * 10.0)
                t['auto'] = False

                def f():
                    ins.itemById('hauteur_auto').value = False
                    ins.itemById('hauteur').isEnabled = True
                _appliquer(f, ins)
            elif iid in ('ep_dd', 'ep_autre'):
                def f():
                    dd = ins.itemById('ep_dd')
                    ins.itemById('ep_autre').isVisible = (dd.selectedItem.index == dd.listItems.count - 1)
                _appliquer(f, ins)
            elif iid in CFG_CHAMPS:
                _lire_cfg(ins)
                _appliquer(lambda: _champs_cfg(ins), ins)
        except Exception:
            _log('inputChanged erreur ' + traceback.format_exc()[-600:])


class _PreviewHandler(adsk.core.CommandEventHandler):
    """executePreview : Fusion annule a chaque changement de reglage ce qui a ete cree pendant l'evenement
    precedent (y compris nos groupes graphiques : journal « groupe perdu » x610) puis relance ce gestionnaire.
    Comme Reseau CNC, on s'y assure que fenetres et apercu sont presents (recrees s'ils ont ete annules ;
    sinon seule la matrice est mise a jour)."""
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            t0 = time.perf_counter()
            calcs = _cur['calcs']
            if calcs:
                if not (_drag['k'] is not None and _ov['g'] is not None and _ov['g'].isValid):
                    _ov_maj(calcs)           # pendant le glisser, les fenetres n'ont pas change : seulement si perdues
                _apercu_maj(calcs, ctx='preview')
                _maj_pastilles()
            if _drag['k'] is not None:
                _perf['p'] += time.perf_counter() - t0
                _perf['np'] += 1
        except Exception:
            _log('preview erreur ' + traceback.format_exc()[-300:])


class _ValidateHandler(adsk.core.ValidateInputsEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            args.areInputsValid = any(c['ok'] for c in _cur['calcs'])
        except Exception:
            args.areInputsValid = False


class _ExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        ins = args.command.commandInputs
        _apercu_effacer()
        _ov_effacer()
        try:
            design = _design()
            _lire_cfg(ins)
            ep = _ep_cm(ins)
            try:
                _ep_parametre(design, ins, ep)
            except Exception:
                _log('parametre epaisseur erreur ' + traceback.format_exc()[-300:])
            tl = None
            debut = 0
            try:
                tl = design.timeline
                debut = tl.markerPosition
            except Exception:
                pass
            blob = _blob(ep)
            n = _creer_tout(design, ep, blob)
            ed = _edition['v']
            if tl is not None and n:
                fin = tl.markerPosition - 1
                ok_suppr = True
                if ed is not None:
                    # modification : les nouvelles entrees sont avant les anciennes, qui disparaissent
                    # avant le groupement (comme Reseau CNC)
                    _edition['v'] = None
                    ok_suppr = _supprimer_anciens(design, ed['anciens'])
                _grouper(tl, debut, fin)
                if ed is not None:
                    tl.moveToEnd()
                    if not ok_suppr:
                        _ui.messageBox("L'ancienne traverse n'a pas pu etre supprimee : d'autres fonctions de la chronologie "
                                       "utilisent ses corps. La nouvelle est creee ; supprimez l'ancienne a la main.", COMMAND_NAME)
            if n == 0:
                args.executeFailed = True
                args.executeFailedMessage = _tt('Aucune traverse valide.')
            else:
                t0 = _trs[0]
                ta = _actif()
                sp = {'epaisseur_mm': round(ep * 10.0, 3), 'hauteur_mm': t0['h_mm'], 'haut': t0['haut'],
                      'mode': ta.get('mode', 'libre'), 'long_mm': ta.get('l_mm', 500.0), 'r_n': ta['r_n'],
                      'r_type': ta['r_type'], 'r_dist': ta['r_dist'], 'r_align': ta['r_align'],
                      'r_m1': ta['r_m1'], 'r_m2': ta['r_m2']}
                sp.update(_cfg)
                sp['ver'] = PREFS_VER
                save_prefs(sp)
        except Exception as e:
            _log('execute erreur ' + traceback.format_exc()[-600:])
            args.executeFailed = True
            args.executeFailedMessage = 'Traverse impossible : ' + str(e).splitlines()[-1][:300]


class _DestroyHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        _redraw['on'] = False
        _apercu_effacer()          # toujours effacer overlay et apercus a la fermeture
        _ov_effacer()
        _drag['k'] = None
        _drag['maison'] = False
        _drag['pris'] = False
        _qd['on'] = False
        _qd.pop('tr', None)
        _pastilles_effacer()
        _camera_suivre(False)
        _bloc['sel'] = None
        _cache_traj.clear()
        _cache_ent.clear()
        _cache_faces.clear()
        _cache_forme.clear()
        _rafraichir_vue()
        if _edition['v'] is not None:
            # modification annulee (ou echouee) : retour a la fin de la chronologie, rien n'a change
            _edition['v'] = None
            try:
                _design().timeline.moveToEnd()
            except Exception:
                pass


class _CreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            cmd = args.command
            if _edition['v'] is None:
                _cf_edition()                     # « Modifier la fonction » sur la fonction personnalisee
            p = load_prefs()
            _trs.clear()
            _trs.append(_nouvelle(p))
            _cur.update(i=0, calcs=[])
            _cache_traj.clear()
            _cache_forme.clear()
            _cache_ent.clear()
            _cache_faces.clear()
            _bloc['sel'] = None
            _ov_effacer()
            _apercu_effacer()
            ins = cmd.commandInputs
            im = ins.addImageCommandInput('vue', '', _png_vue(None))
            im.isFullWidth = True
            # Boite compacte (2026-11-05) : message sous la vignette, mode et nombre en tete, puis des groupes
            ins.addTextBoxCommandInput('msg', '', '', 2, True)
            dd = ins.addDropDownCommandInput('mode', 'Mode', adsk.core.DropDownStyles.TextListDropDownStyle)
            for m, nom in zip(MODES, ('Entre deux chemins', 'Perpendiculaire a un chemin', 'Reseau lineaire sur un chemin')):
                dd.listItems.add(nom, m == _trs[0]['mode'], '')
            ins.addIntegerSpinnerCommandInput('nb', 'Nombre de traverses', 1, NB_MAX, 1, 1)
            gs = ins.addGroupCommandInput('grp_sel', 'Chemins et centrage')
            gs.isExpanded = True
            gsc = gs.children
            s = gsc.addSelectionInput('chemin1', 'Chemin de debut', 'Arete ou courbe d\'esquisse ou commence la traverse')
            s.addSelectionFilter('Edges'); s.addSelectionFilter('SketchCurves'); s.setSelectionLimits(0, 1)
            s = gsc.addSelectionInput('chemin2', 'Chemin de fin', 'Arete ou courbe d\'esquisse ou finit la traverse')
            s.addSelectionFilter('Edges'); s.addSelectionFilter('SketchCurves'); s.setSelectionLimits(0, 1)
            s = gsc.addSelectionInput('faces_amont', 'Centrer le debut', 'Les deux faces du corps du debut : elles centrent le debut de la traverse')
            s.addSelectionFilter('PlanarFaces'); s.setSelectionLimits(0, 2)
            s = gsc.addSelectionInput('faces_aval', 'Centrer la fin', 'Les deux faces du corps de la fin : elles centrent la fin de la traverse')
            s.addSelectionFilter('PlanarFaces'); s.setSelectionLimits(0, 2)
            ph = ins.addDistanceValueCommandInput('poignee1', 'Ajuster le debut', adsk.core.ValueInput.createByReal(0.0))
            ph.tooltip = 'Fleche posee sur le chemin de debut : tire-la pour placer le debut de la traverse.'
            ph.isVisible = False
            ph = ins.addDistanceValueCommandInput('poignee2', 'Ajuster la fin', adsk.core.ValueInput.createByReal(0.0))
            ph.tooltip = 'Fleche posee sur le chemin de fin : tire-la pour placer la fin de la traverse.'
            ph.isVisible = False
            gm = ins.addGroupCommandInput('grp_dim', 'Dimensions')
            gm.isExpanded = True
            gmc = gm.children
            dd = gmc.addDropDownCommandInput('ep_dd', 'Epaisseur', adsk.core.DropDownStyles.TextListDropDownStyle)
            ok_cp = _ep_remplir(dd, _design(), p['epaisseur_mm'] / 10.0)
            ae = gmc.addValueInput('ep_autre', 'Epaisseur libre', 'mm', adsk.core.ValueInput.createByReal(p['epaisseur_mm'] / 10.0))
            ae.isVisible = not ok_cp
            gmc.addBoolValueInput('hauteur_auto', 'Hauteur auto', True, '', True)
            gmc.addValueInput('hauteur', 'Hauteur', 'mm', adsk.core.ValueInput.createByReal(p['hauteur_mm'] / 10.0))
            gmc.addBoolValueInput('haut', 'Vers le haut', True, '', bool(p['haut']))
            gmc.addBoolValueInput('l_auto', 'Longueur auto (bord oppose)', True, '', True)
            gmc.addValueInput('longueur', 'Longueur', 'mm', adsk.core.ValueInput.createByReal(_trs[0]['l_mm'] / 10.0))
            gmc.addBoolValueInput('cote', 'Inverser le cote', True, '', False)
            gr = ins.addGroupCommandInput('grp_res', 'Reseau lineaire')
            gr.isExpanded = True
            grc = gr.children
            grc.addIntegerSpinnerCommandInput('r_n', 'Nombre de copies', 1, R_NMAX, 1, int(_trs[0]['r_n']))
            dd = grc.addDropDownCommandInput('r_type', 'Repartition', adsk.core.DropDownStyles.TextListDropDownStyle)
            for m, nom in zip(R_TYPES, ('Sur tout le chemin', 'Entre les bouts', 'Espacement', 'Etendue')):
                dd.listItems.add(nom, m == _trs[0]['r_type'], '')
            grc.addValueInput('r_dist', 'Distance', 'mm', adsk.core.ValueInput.createByReal(_trs[0]['r_dist'] / 10.0))
            dd = grc.addDropDownCommandInput('r_align', 'Alignement', adsk.core.DropDownStyles.TextListDropDownStyle)
            for m, nom in zip(R_ALIGNS, ('Depuis la pastille', 'Centre sur la pastille', "Jusqu'a la pastille")):
                dd.listItems.add(nom, m == _trs[0]['r_align'], '')
            grc.addValueInput('r_m1', 'Marge au debut', 'mm', adsk.core.ValueInput.createByReal(_trs[0]['r_m1'] / 10.0))
            grc.addValueInput('r_m2', 'Marge a la fin', 'mm', adsk.core.ValueInput.createByReal(_trs[0]['r_m2'] / 10.0))
            _cfg.clear()
            _cfg.update({k: p[k] for k in CFG_DEFAUT})
            gt = ins.addGroupCommandInput('grp_ten', 'Tenons aux bouts')
            gt.isExpanded = False
            gc = gt.children
            gc.addBoolValueInput('ten_deb', 'Tenons au debut', True, '', _cfg['ten_deb'])
            gc.addBoolValueInput('ten_fin', 'Tenons a la fin', True, '', _cfg['ten_fin'])
            gc.addBoolValueInput('ten_haut', 'Sur le champ superieur', True, '', _cfg['ten_haut'])
            gc.addBoolValueInput('ten_bas', 'Sur le champ inferieur', True, '', _cfg['ten_bas'])
            gc.addBoolValueInput('ten_h_auto', 'Hauteur automatique (epaisseur des corps)', True, '', _cfg['ten_h_auto'])
            gc.addIntegerSpinnerCommandInput('ten_n', 'Nombre de tenons', 1, 10, 1, int(_cfg['ten_n']))
            gc.addValueInput('ten_len', 'Longueur tenon', 'mm', adsk.core.ValueInput.createByReal(_cfg['ten_len_mm'] / 10.0))
            gc.addValueInput('ten_h', 'Hauteur tenon', 'mm', adsk.core.ValueInput.createByReal(_cfg['ten_h_mm'] / 10.0))
            gc.addValueInput('ten_edge', 'Distance du bord', 'mm', adsk.core.ValueInput.createByReal(_cfg['ten_edge_mm'] / 10.0)).isVisible = False
            gc.addBoolValueInput('ten_centrer', 'Centrer', True, '', _cfg['ten_centrer']).isVisible = False
            gc.addTextBoxCommandInput('ten_regle', '', 'Tenon centre sur la plate-bande, plat de chaque cote : au plus la longueur saisie, 5/12 de la plate-bande si elle est etroite (60 -> 25 mm).', 2, True)
            gd = ins.addGroupCommandInput('grp_dec', 'Decaisse central')
            gd.isExpanded = False
            gdc = gd.children
            gdc.addBoolValueInput('dec_on', 'Decaisse', True, '', _cfg['dec_on'])
            gdc.addBoolValueInput('dec_auto', 'Plate-bande detectee (corps du dessus)', True, '', _cfg['dec_auto'])
            gdc.addValueInput('dec_dist', 'Plate-bande au debut', 'mm', adsk.core.ValueInput.createByReal(_cfg['dec_dist_mm'] / 10.0))
            gdc.addValueInput('dec_dist2', 'Plate-bande a la fin', 'mm', adsk.core.ValueInput.createByReal(_cfg['dec_dist2_mm'] / 10.0))
            dd = gdc.addDropDownCommandInput('dec_fin', 'Finition', adsk.core.DropDownStyles.TextListDropDownStyle)
            dd.listItems.add('Arc de cercle', bool(_cfg['dec_arc']))
            dd.listItems.add('Droite', not _cfg['dec_arc'])
            gdc.addValueInput('dec_h', 'Hauteur du decaisse', 'mm', adsk.core.ValueInput.createByReal(_cfg['dec_h_mm'] / 10.0))
            for ev, h in ((cmd.inputChanged, _InputChangedHandler()),
                          (cmd.validateInputs, _ValidateHandler()),
                          (cmd.executePreview, _PreviewHandler()),
                          (cmd.execute, _ExecuteHandler()),
                          (cmd.destroy, _DestroyHandler()),
                          (cmd.mouseDown, _MouseDownHandler()),
                          (cmd.preSelect, _PreSelectHandler()),
                          (cmd.mouseUp, _MouseUpHandler()),
                          (cmd.mouseDrag, _MouseHandler('mouseDrag')),
                          (cmd.mouseMove, _MouseHandler('mouseMove'))):
                ev.add(h)
                _handlers.append(h)
            _redraw['on'] = True
            ed = _edition['v']
            if ed is not None:
                b = ed['blob']
                _trs.clear()
                for d in b.get('trs', []):
                    t = _nouvelle(p)
                    t.update({k: d[k] for k in CLES_TR if k in d})
                    _trs.append(t)
                if not _trs:
                    _trs.append(_nouvelle(p))
                _cfg.update({k: v for k, v in (b.get('cfg') or {}).items() if k in CFG_DEFAUT})
                _cur['i'] = max(0, min(int(b.get('i', 0)), len(_trs) - 1))
                try:
                    _ep_choisir(ins, float(b['ep']))
                except Exception:
                    _log('epaisseur edition erreur ' + traceback.format_exc()[-200:])

                def f():
                    _charger_selection(ins)
                    _sync_champs(ins)
                    _champs_cfg(ins)
                _appliquer(f, ins, True)
            else:
                _appliquer(lambda: (_sync_champs(ins), _champs_cfg(ins)), ins, True)
            ins.itemById('chemin1').hasFocus = not ed
        except Exception:
            _log('cree erreur ' + traceback.format_exc()[-800:])
            _ui.messageBox('Erreur Traverse de renfort CNC:\n' + traceback.format_exc(), COMMAND_NAME)


# --- Modification depuis l'historique de CNC Toolkit (cnc_historique.modifier) -----------------

def _supprimer_anciens(design, tokens):
    """Supprime les entrees de l'ancienne traverse (groupe deplie, de la derniere a la premiere)."""
    r = design.findEntityByToken(tokens[0]) if tokens else None
    if r:
        try:
            g = r[0].timelineObject.parentGroup
            if g is not None and g.isCollapsed:
                g.isCollapsed = False
        except Exception:
            pass
    ok = True
    for tok in reversed(tokens):
        try:
            r = design.findEntityByToken(tok)
            if r:
                r[0].deleteMe()
        except Exception:
            ok = False
            _log('suppression ancien erreur ' + traceback.format_exc()[-300:])
    return ok


class _ActionHandler(adsk.core.CustomEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            cd = _ui.commandDefinitions.itemById(CMD_ID)
            if cd is not None:
                cd.execute()
        except Exception:
            _log('action erreur ' + traceback.format_exc()[-300:])


def _differer():
    """Ouvre la commande hors du gestionnaire de la palette (evenement personnalise, comme Reseau CNC)."""
    try:
        if _action['evt'] is None:
            try:
                _app.unregisterCustomEvent(ACTION_ID)
            except Exception:
                pass
            _action['evt'] = _app.registerCustomEvent(ACTION_ID)
            _action['h'] = _ActionHandler()
            _action['evt'].add(_action['h'])
        if not _app.fireCustomEvent(ACTION_ID, ''):
            raise RuntimeError('evenement non livre')
    except Exception:
        _log('differer : ' + traceback.format_exc()[-200:])
        _ui.commandDefinitions.itemById(CMD_ID).execute()


def edit_group(g):
    """Appele par cnc_historique : recule la chronologie au debut du groupe « Traverse CNC » et rouvre la
    fenetre avec ses reglages ; a la validation les nouvelles traverses remplacent les anciennes.
    Renvoie (ok, message)."""
    try:
        design = _design()
        if design is None or design.designType != adsk.fusion.DesignTypes.ParametricDesignType:
            return False, 'Conception parametrique (historique) requise.'
        ents = [g.item(i).entity for i in range(g.count)]
        blob = None
        for e in ents:
            try:
                a = e.attributes.itemByName(ATTR_G, ATTR_N)
                if a is not None:
                    blob = json.loads(a.value)
                    break
            except Exception:
                continue
        if blob is None:
            return False, 'Traverse creee avant la version modifiable : pas de reglages memorises.'
        tl = design.timeline
        idx = None
        for lire in (lambda: g.index, lambda: g.item(0).index):
            try:
                idx = lire()
                break
            except Exception:
                continue
        if idx is None:
            return False, 'Position du groupe introuvable.'
        _edition['v'] = {'blob': blob, 'anciens': [e.entityToken for e in ents]}
        try:
            _ui.activeSelections.clear()
        except Exception:
            pass
        tl.markerPosition = idx
        _differer()
        return True, None
    except Exception as e:
        _edition['v'] = None
        _log('edit_group erreur ' + traceback.format_exc()[-400:])
        return False, str(e)[:200]


def _enregistrer_evenements():
    """Evenements personnalises (modification depuis l'historique, redessin differe), enregistres au demarrage."""
    for ident, cle, cls in ((ACTION_ID, _action, _ActionHandler), (REDRAW_ID, _redraw, _RedrawHandler)):
        try:
            try:
                _app.unregisterCustomEvent(ident)
            except Exception:
                pass
            cle['evt'] = _app.registerCustomEvent(ident)
            cle['h'] = cls()
            cle['evt'].add(cle['h'])
        except Exception:
            _log('evenement %s : %s' % (ident, traceback.format_exc()[-200:]))


def run(context):
    global _app, _ui
    try:
        _app = adsk.core.Application.get()
        _ui = _app.userInterface
        old = _ui.commandDefinitions.itemById(CMD_ID)
        if old:
            old.deleteMe()
        res = os.path.join(_ADDIN_DIR, 'resources')
        cmd_def = _ui.commandDefinitions.addButtonDefinition(CMD_ID, COMMAND_NAME, COMMAND_DESC,
                                                             res if os.path.isdir(res) else '')
        on_created = _CreatedHandler()
        cmd_def.commandCreated.add(on_created)
        _handlers.append(on_created)
        panel = _ui.allToolbarPanels.itemById(PANEL_ID)
        if panel and not panel.controls.itemById(CMD_ID):
            panel.controls.addCommand(cmd_def)
        _enregistrer_evenements()
        _cf_definir()
    except Exception:
        if _ui:
            _ui.messageBox('Erreur au demarrage de Traverse de renfort CNC:\n' + traceback.format_exc())


def stop(context):
    _dv_arreter()
    try:
        if _cf['def'] is not None and _cf['h'] is not None:
            _cf['def'].customFeatureCompute.remove(_cf['h'])
    except Exception:
        pass
    _cf['def'] = _cf['h'] = None
    try:
        for ev in (ACTION_ID, REDRAW_ID):
            try:
                _app.unregisterCustomEvent(ev)
            except Exception:
                pass
        _action['evt'] = None
        _redraw['evt'] = None
        _redraw['on'] = False
        _apercu_effacer()
        _ov_effacer()
        panel = _ui.allToolbarPanels.itemById(PANEL_ID)
        if panel:
            c = panel.controls.itemById(CMD_ID)
            if c:
                c.deleteMe()
        cd = _ui.commandDefinitions.itemById(CMD_ID)
        if cd:
            cd.deleteMe()
    except Exception:
        pass
    _handlers.clear()
