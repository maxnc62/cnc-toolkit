import adsk.core, adsk.fusion, traceback, os, sys, time, json

# Barre de chargement commune du Toolkit (ToolkitCNC/cnc_progress.py)
_TK_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _TK_DIR not in sys.path:
    sys.path.append(_TK_DIR)
import cnc_progress

_app = None
_ui = None
_handlers = []

CMD_ID = 'MiseAJourCNCCmd'
COMMAND_NAME = 'Mettre a jour CNC'
COMMAND_DESC = ("Recree en 1 clic les mortaises (Mortaise CNC) et le jeu de "
                "fonctionnement (Marge CNC) a la position actuelle des corps, "
                "apres un changement de parametre qui les a deplaces.")
PANEL_IDS = ['SolidModifyPanel', 'SolidCreatePanel', 'SketchCreatePanel', 'ToolsPanel']

_ADDIN_DIR = os.path.dirname(os.path.abspath(__file__))
DEBUG_LOG = os.path.join(_ADDIN_DIR, 'maj_debug.log')


def _dbg(msg):
    try:
        with open(DEBUG_LOG, 'a', encoding='utf-8') as f:
            f.write(time.strftime('%H:%M:%S') + ' ' + str(msg) + '\n')
    except Exception:
        pass


def _find_module(short_name):
    """Retrouve un module d'add-in deja charge dans cette session Fusion,
    quel que soit la maniere dont il a ete charge.

    Quand Fusion charge lui-meme un add-in au demarrage (son comportement
    normal), il n'utilise PAS la cle 'MortaiseCNC'/'MargeCNC' telle quelle
    dans sys.modules : il l'enregistre sous une cle "mangled" du style
    "__main__C%3A%2FUsers%2F...%2FAddIns%2FMortaiseCNC%2FMortaiseCNC_py"
    (chemin complet du fichier, encode, avec le nom de fichier termine en
    "_py"). sys.modules.get('MortaiseCNC') renvoie alors None MEME SI
    l'add-in est bel et bien actif - ce qui declenchait a tort le message
    "Mortaise CNC et/ou Marge CNC ne sont pas actifs" alors que Scripts et
    complements les montre bien actifs. On cherche donc, en repli, une cle
    qui se termine par '<NomAddin>_py' (chargement natif Fusion), en plus
    de la cle exacte (rechargement manuel via importlib, utilise pendant le
    developpement)."""
    mod = sys.modules.get(short_name)
    if mod is not None:
        return mod
    suffix = short_name + '_py'
    for k, m in list(sys.modules.items()):
        if k.endswith(suffix):
            return m
    return None


def _get_modules():
    """Recupere les modules Mortaise CNC / Marge CNC deja charges par
    Fusion dans cette session (doivent etre actifs)."""
    return _find_module('MortaiseCNC'), _find_module('MargeCNC')


def _revive_body(design, body, name):
    """Le corps male/femelle releve avant la recreation des tenons peut
    devenir invalide (son Combiner 'Tenon' a ete supprime puis recree) :
    on le retrouve alors par son nom, seulement s'il est unique."""
    try:
        if body is not None and body.isValid:
            return body
    except Exception:
        pass
    if not name:
        return None
    root = design.rootComponent
    comps = {root.entityToken: root}
    for occ in root.allOccurrences:
        comps.setdefault(occ.component.entityToken, occ.component)
    matches = [b for c in comps.values() for b in c.bRepBodies if b.name == name]
    return matches[0] if len(matches) == 1 else None


def _entity_token(item):
    try:
        e = item.entity
        return e.entityToken if e is not None else None
    except Exception:
        return None


def _timeline_tokens(tl):
    """entityToken de toutes les fonctions deja dans la chronologie (y
    compris dans les groupes), pour reconnaitre ensuite les nouvelles."""
    toks = set()
    for i in range(tl.count):
        it = tl.item(i)
        try:
            if it.isGroup:
                g = adsk.fusion.TimelineGroup.cast(it)
                for k in range(g.count):
                    t = _entity_token(g.item(k))
                    if t:
                        toks.add(t)
                continue
        except Exception:
            pass
        t = _entity_token(it)
        if t:
            toks.add(t)
    return toks


def _new_tail(tl, old_tokens):
    """Remonte depuis le marqueur tant que les elements sont nouveaux.
    Retourne (index du premier nouvel element, groupes nouveaux)."""
    i = tl.markerPosition - 1
    groups = []
    while i >= 0:
        it = tl.item(i)
        if it.isGroup:
            g = adsk.fusion.TimelineGroup.cast(it)
            toks = [_entity_token(g.item(k)) for k in range(g.count)]
            if not toks or any(t is None or t in old_tokens for t in toks):
                break
            groups.append(g)
        else:
            t = _entity_token(it)
            if t is None or t in old_tokens:
                break
        i -= 1
    return i + 1, groups


def _group_new_items(tl, old_tokens):
    start, groups = _new_tail(tl, old_tokens)
    if groups:
        # Fusion n'imbrique pas les groupes : on defait ceux que la mise a
        # jour vient de creer (ex. "Dogbone CNC") pour tout regrouper.
        for g in groups:
            try:
                g.deleteMe(False)
            except Exception:
                _dbg('degroupage EXCEPTION: ' + traceback.format_exc())
        start, groups = _new_tail(tl, old_tokens)
    end = tl.markerPosition - 1
    _dbg(f'groupe Mise a jour CNC : elements {start}..{end}')
    if end > start and not groups:
        grp = tl.timelineGroups.add(start, end)
        if grp:
            grp.name = 'Mise a jour CNC'
            grp.isCollapsed = True
    elif end == start:
        tl.item(end).entity.name = 'Mise a jour CNC'


# --- Mise a jour selective des mortaises et des jeux (2026-10-11) ------------
# Demande de l'utilisateur : ne recalculer que ce qui a bouge. Tenons, entailles et
# dogbones le faisaient deja (chacun compare l'empreinte de ses corps) ; les
# mortaises et les jeux etaient, eux, TOUS supprimes et recrees a chaque
# fois. Chaque feature Mortaise CNC garde maintenant l'encombrement de ses
# corps male/femelle ('MiseAJourCNC', 'sig') pris a la fin de la derniere
# mise a jour : une paire est refaite seulement si l'un des deux a bouge ou
# change de taille (ou sans empreinte : 1re mise a jour, ancien document).
_SIG_GROUP = 'MiseAJourCNC'
_SIG_TOL_CM = 0.01   # 0.1 mm, meme tolerance qu'Entaille CNC


def _bbox_sig(body):
    bb = body.boundingBox
    return [round(v, 4) for v in (bb.minPoint.x, bb.minPoint.y, bb.minPoint.z,
                                  bb.maxPoint.x, bb.maxPoint.y, bb.maxPoint.z)]


def _sig_moved(old, cur):
    if not old or len(old) != len(cur):
        return True
    return any(abs(a - b) > _SIG_TOL_CM for a, b in zip(old, cur))


def _feat_in_error(feat):
    try:
        return feat.timelineObject.healthState == adsk.fusion.FeatureHealthStates.ErrorFeatureHealthState
    except Exception:
        return False


def _read_sig(feat):
    try:
        a = feat.attributes.itemByName(_SIG_GROUP, 'sig')
        return json.loads(a.value) if a else None
    except Exception:
        return None


def _body_key(body):
    """Identite stable d'un corps (les entityToken d'un meme corps peuvent
    differer d'une lecture a l'autre, et un jeton peut donner le corps natif
    ou son proxy d'occurrence) : composant + nom. Deux occurrences d'un meme
    composant partagent la cle : on refait alors un peu plus, jamais moins."""
    try:
        native = body.nativeObject or body
    except Exception:
        native = body
    try:
        return (native.parentComponent.id, native.name)
    except Exception:
        return None


def _resolve_tok(design, tok):
    try:
        found = design.findEntityByToken(tok) if tok else None
        return found[0] if found else None
    except Exception:
        return None


def _write_mortaise_sigs(design, MortaiseCNC):
    """Empreinte male/femelle sur chaque feature Mortaise CNC, a la fin de la
    mise a jour (apres tenons/entailles, donc sur les corps finis)."""
    n = 0
    try:
        feats = MortaiseCNC.find_all_mortaise_features(design)
    except Exception:
        _dbg('empreintes mortaises : lecture EXCEPTION: ' + traceback.format_exc())
        return 0
    for feat, male_tok, female_tok in feats:
        male = _resolve_tok(design, male_tok)
        female = _resolve_tok(design, female_tok)
        if male is None or female is None:
            continue
        try:
            feat.attributes.add(_SIG_GROUP, 'sig', json.dumps(
                {'male': _bbox_sig(male), 'female': _bbox_sig(female)}))
            n += 1
        except Exception:
            _dbg('empreinte mortaise EXCEPTION: ' + traceback.format_exc())
    return n


def _get_tenon_module():
    """Tenon CNC est optionnel pour Mettre a jour CNC (contrairement a
    Mortaise/Marge) : si l'add-in n'est pas actif, on met simplement a jour
    les mortaises/jeux comme avant, sans bloquer ni avertir."""
    return _find_module('TenonCNC')


# --- Garde-fou Calpinage CNC (2026-10-10) ------------------------------------
# Calpinage CNC peut poser les vraies pieces a plat sur des panneaux (groupe
# d'historique "Calpinage CNC"). Cet outil travaille sur les pieces en
# position d'assemblage : on refuse tant que le calpinage est en place.
def _calpinage_en_place():
    try:
        design = adsk.fusion.Design.cast(adsk.core.Application.get().activeProduct)
        tl = design.timeline
        for i in range(tl.timelineGroups.count):
            n = tl.timelineGroups.item(i).name
            if n.startswith('Calpinage CNC') and 'copie' not in n:
                return True
    except Exception:
        pass
    return False


def _calpinage_refus(ui, titre):
    ui.messageBox("Les pieces sont posees a plat par Calpinage CNC.\n\n"
                  "Remets-les d'abord en assemblage : palette CNC Toolkit > "
                  "Calpinage CNC > Remettre en assemblage.", titre)


class ExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()

    def notify(self, args):
        if _calpinage_en_place():
            _calpinage_refus(_ui, COMMAND_NAME)
            return
        tl = None
        original_marker = None
        anchor_tok = None
        advanced = False
        barre = None   # barre de chargement (cnc_progress), fermee dans finally
        _t0 = time.time()
        _times = []

        def _lap(label, _last=[time.time()]):
            now = time.time()
            _times.append(f'{label} {now - _last[0]:.1f}s')
            _dbg(f'[temps] {label}: {now - _last[0]:.2f}s')
            _last[0] = now
        try:
            design = adsk.fusion.Design.cast(_app.activeProduct)
            if not design:
                _ui.messageBox("Aucun design actif.", COMMAND_NAME)
                return
            root = design.rootComponent

            MortaiseCNC, MargeCNC = _get_modules()
            if MortaiseCNC is None or MargeCNC is None:
                _ui.messageBox(
                    "Mortaise CNC et/ou Marge CNC ne sont pas actifs dans cette "
                    "session Fusion (a activer dans Utilitaires > Scripts et "
                    "complements).", COMMAND_NAME)
                return

            # --- 0. Avance temporairement la chronologie jusque juste avant
            # les features "Reorganiser" (imbrication/nesting CNC) ------------
            # design.findAttributes()/findEntityByToken() (utilises partout
            # ci-dessous, et par Mortaise/Marge/Tenon CNC eux-memes) ne
            # "voient" que ce qui est calcule JUSQU'AU marqueur de
            # chronologie courant. Si le marqueur est en retrait (usage
            # courant chez cet utilisateur - ex. pour visualiser le canape a
            # une etape intermediaire), tout ce qui a ete cree apres devient
            # invisible pour "Mettre a jour CNC" : mortaises/jeux/tenons
            # recents ignores silencieusement, "paire ignoree (corps
            # introuvable)", corps introuvables qui ne le sont pas vraiment,
            # etc. - exactement les symptomes rapportes.
            #
            # IMPORTANT - NE PAS avancer jusqu'a la toute fin (tl.count) :
            # constate en conditions reelles que ce document a des features
            # ArrangeFeature ("Reorganiser" - imbrication des pieces pour la
            # decoupe CNC) juste apres la position ou l'utilisateur laisse
            # habituellement le marqueur. Ces features dependent de la forme
            # finale de TOUS les corps et peuvent echouer a se recalculer
            # (constate : cascade d'erreurs "Invalid input points" / conges-
            # chanfreins casses / 0 mortaise-jeu recree au lieu de 27). On
            # avance donc seulement jusqu'a juste avant la PREMIERE
            # ArrangeFeature rencontree (ou jusqu'a la fin s'il n'y en a
            # aucune) : assez loin pour voir toutes les mortaises/jeux/tenons
            # CNC, jamais assez loin pour toucher a l'imbrication.
            #
            # On restaure la position d'origine du marqueur a la toute fin
            # (voir finally plus bas), que la mise a jour reussisse ou
            # echoue - en retrouvant la MEME feature (par entityToken, pas
            # par simple index) puisque des suppressions/creations de
            # features plus tot dans la chronologie peuvent decaler les
            # index.
            tl = design.timeline
            original_marker = tl.markerPosition
            safe_end = tl.count
            for i in range(tl.count):
                try:
                    if tl.item(i).entity.objectType == 'adsk::fusion::ArrangeFeature':
                        safe_end = i
                        break
                except Exception:
                    continue
            if original_marker < safe_end:
                try:
                    if original_marker > 0:
                        anchor_tok = tl.item(original_marker - 1).entity.entityToken
                except Exception:
                    anchor_tok = None
                    _dbg('lecture ancre chronologie EXCEPTION: ' + traceback.format_exc())
                _dbg(f'chronologie en retrait ({original_marker}/{tl.count}, limite sure={safe_end}) - avance temporairement')
                tl.markerPosition = safe_end
                advanced = True
            elif original_marker > safe_end:
                # Le marqueur est deja APRES la limite sure (l'utilisateur a
                # avance manuellement au-dela des ArrangeFeature) : on ne
                # recule pas de force, on laisse tel quel.
                _dbg(f'marqueur ({original_marker}) deja au-dela de la limite sure ({safe_end}) - inchange')

            _dbg('=== Mise a jour CNC : debut ===')
            _lap('preparation')

            # --- 1. Etat actuel : releve des jeux (Marge CNC) et des paires
            # mortaise (Mortaise CNC), AVANT toute suppression -----------------
            marge_runs = []
            try:
                attrs = design.findAttributes('MargeCNC', 'jeu_cm')
            except Exception:
                attrs = []
            for a in attrs:
                try:
                    feat = a.parent
                    # Jeu pose par Entaille CNC (MargeAuto) : il fait partie
                    # du lot d'entailles, qui le supprime et le recree lui-meme
                    # si un corps a bouge (etape 5). Le supprimer/reappliquer
                    # ici le sortait du lot : la recreation suivante du lot
                    # laissait alors ce jeu orphelin sur des faces disparues.
                    try:
                        if feat.attributes.itemByName('EntailleCNC', 'lot') is not None:
                            continue
                    except Exception:
                        pass
                    jeu = float(a.value)
                    sel_attr = None
                    try:
                        sel_attr = feat.attributes.itemByName('MargeCNC', 'selected_body_tokens')
                    except Exception:
                        pass
                    toks = [t for t in (sel_attr.value.split(',') if sel_attr and sel_attr.value else []) if t]
                    # exclure_fond : absent sur une feature creee avant l'ajout
                    # de cette option -> False (comportement d'origine).
                    fond_attr = None
                    try:
                        fond_attr = feat.attributes.itemByName('MargeCNC', 'exclure_fond')
                    except Exception:
                        pass
                    exclure_fond = bool(fond_attr and fond_attr.value == '1')
                    marge_runs.append((feat, jeu, toks, exclure_fond))
                except Exception:
                    _dbg('lecture attribut Marge CNC EXCEPTION: ' + traceback.format_exc())

            mortaise_feats = []
            try:
                mortaise_feats = MortaiseCNC.find_all_mortaise_features(design)
            except Exception:
                _dbg('find_all_mortaise_features EXCEPTION: ' + traceback.format_exc())

            # Une paire male/femelle = une recreation (plusieurs features
            # pour la meme paire etaient recreees autant de fois). Paire a
            # refaire si un corps a bouge depuis la derniere mise a jour,
            # si une de ses features est en erreur, ou sans empreinte.
            pairs_by_key = {}
            for feat, male_tok, female_tok in mortaise_feats:
                male = _resolve_tok(design, male_tok)
                female = _resolve_tok(design, female_tok)
                if male is not None and female is not None:
                    pkey = (_body_key(male), _body_key(female))
                else:
                    pkey = (male_tok, female_tok)
                p = pairs_by_key.get(pkey)
                if p is None:
                    p = {'feats': [], 'male': male, 'female': female, 'dirty': False, 'cur': None}
                    if male is None or female is None:
                        # Comme avant : supprimee, non recreee.
                        p['dirty'] = True
                        _dbg(f'paire ignoree (corps introuvable) male={male_tok} female={female_tok}')
                    else:
                        try:
                            p['cur'] = {'male': _bbox_sig(male), 'female': _bbox_sig(female)}
                        except Exception:
                            p['dirty'] = True
                    pairs_by_key[pkey] = p
                p['feats'].append(feat)
                if not p['dirty']:
                    old = _read_sig(feat)
                    if old is None or _feat_in_error(feat) \
                            or _sig_moved(old.get('male'), p['cur']['male']) \
                            or _sig_moved(old.get('female'), p['cur']['female']):
                        p['dirty'] = True

            dirty_bodies = set()
            mortaise_pairs = []
            mortaise_del = []
            n_mortaise_kept = 0
            for p in pairs_by_key.values():
                if not p['dirty']:
                    n_mortaise_kept += 1
                    continue
                mortaise_del.extend(p['feats'])
                male, female = p['male'], p['female']
                if male is not None and female is not None:
                    dirty_bodies.add(_body_key(male))
                    dirty_bodies.add(_body_key(female))
                    # Noms gardes pour re-resoudre les corps apres la
                    # recreation des tenons (voir _revive_body).
                    mortaise_pairs.append((male, female, male.name, female.name))

            # Jeux : a refaire si une mortaise de l'un de leurs corps est
            # refaite (ses parois disparaissent), ou si la feature est en
            # erreur. Puis, de proche en proche, tout jeu partageant un corps
            # avec un jeu refait : un jeu reapplique couvre TOUTES les
            # mortaises du corps, il doublerait sinon celui qu'on garderait.
            run_keys = []
            for feat, jeu, toks, _ef in marge_runs:
                keys = set()
                for t in toks:
                    b = _resolve_tok(design, t)
                    if b is not None:
                        keys.add(_body_key(b))
                run_keys.append(keys)
            # Jeu sans corps lisible (ancien MargeAuto) : on ne sait pas sur
            # quelle mortaise il porte, il suit donc l'ancien comportement
            # des qu'une mortaise est refaite.
            run_dirty = [_feat_in_error(r[0]) or bool(k & dirty_bodies)
                         or (not k and bool(mortaise_del))
                         for r, k in zip(marge_runs, run_keys)]
            changed = True
            while changed:
                changed = False
                touched = set()
                for d, k in zip(run_dirty, run_keys):
                    if d:
                        touched |= k
                for i, k in enumerate(run_keys):
                    if not run_dirty[i] and k & touched:
                        run_dirty[i] = True
                        changed = True
            n_marge_kept = sum(1 for d in run_dirty if not d)
            marge_runs = [r for r, d in zip(marge_runs, run_dirty) if d]
            _dbg(f'selectif : {len(mortaise_pairs)} paire(s) mortaise a refaire, {n_mortaise_kept} inchangee(s) ; '
                 f'{len(marge_runs)} jeu(x) a refaire, {n_marge_kept} inchange(s)')

            TenonCNC = _get_tenon_module()
            has_tenons = False
            if TenonCNC is not None:
                try:
                    has_tenons = len(design.findAttributes('TenonCNC', '')) > 0
                except Exception:
                    has_tenons = False
            EntailleCNC = _find_module('EntailleCNC')
            DogboneCNC = _find_module('DogboneCNC')
            recreate_entailles = getattr(EntailleCNC, 'recreate_all_entailles', None)
            recreate_dogbones = getattr(DogboneCNC, 'recreate_all_dogbones', None)

            if not mortaise_feats and not marge_runs and not has_tenons \
                    and recreate_entailles is None and recreate_dogbones is None:
                _ui.messageBox(
                    "Rien a mettre a jour : aucun tenon, mortaise ou jeu cree par "
                    "CNC Toolkit n'a ete trouve dans ce design.",
                    COMMAND_NAME)
                return

            start_index = tl.markerPosition
            old_tokens = _timeline_tokens(tl)
            barre = cnc_progress.Barre(
                COMMAND_NAME, 'Suppression des anciennes coupes...',
                total=4 + len(mortaise_pairs) + len(marge_runs)).ouvrir()

            # --- 2. Suppression : Marge CNC d'abord (depend des parois de
            # cavite creees par Mortaise CNC), puis Mortaise CNC ---------------
            n_del_marge = 0
            for feat, jeu, toks, _exclure_fond in marge_runs:
                try:
                    feat.deleteMe()
                    n_del_marge += 1
                except Exception:
                    _dbg('suppression feature Marge CNC EXCEPTION: ' + traceback.format_exc())

            n_del_mortaise = 0
            for feat in mortaise_del:
                try:
                    feat.deleteMe()
                    n_del_mortaise += 1
                except Exception:
                    _dbg('suppression feature Mortaise CNC EXCEPTION: ' + traceback.format_exc())

            _dbg(f'supprime : {n_del_marge} feature(s) Marge CNC, {n_del_mortaise} feature(s) Mortaise CNC')
            _lap('suppression jeux/mortaises')

            # --- 3. Tenons CNC AVANT les mortaises (2026-10-06) : une
            # mortaise est creusee a partir du corps male TEL QU'IL EST, tenon
            # compris. Recreer les mortaises d'abord les creusait a l'ancienne
            # position du tenon quand le corps avait ete deplace (Deplacer
            # insere plus tot dans la chronologie). Les tenons sont des
            # bossages figes (BaseFeature + Combiner) qui ne suivent pas le
            # corps tout seuls : TenonCNC.recreate_all_tenons les supprime et
            # les recree sur le chant retrouve par sa marque d'attribut.
            # (Un essai plus ancien de cet ordre n'avait rien change sur
            # F(5)/F(7) : ce blocage-la vient de mortaises orphelines non
            # taguees, pas de l'ordre.)
            barre.etape('Tenons...', 1)
            n_tenons_ok = n_tenons_total = n_tenons_sans_spec = 0
            tenon_errors = []
            if TenonCNC is not None:
                try:
                    n_tenons_ok, n_tenons_total, n_tenons_sans_spec, tenon_errors = \
                        TenonCNC.recreate_all_tenons(design)
                except Exception:
                    tenon_errors.append(traceback.format_exc().strip().splitlines()[-1])
                    _dbg('recreation tenons EXCEPTION: ' + traceback.format_exc())

            _lap('tenons')

            # --- 4. Recreation : Mortaise CNC (position actuelle des corps),
            # puis Marge CNC (jeu reapplique sur les nouvelles parois) ---------
            nb_ok_total = 0
            nb_skipped_total = 0
            mortaise_errors = []
            barre.etape('Mortaises...', 2)
            for male, female, male_name, female_name in mortaise_pairs:
                barre.avance()
                try:
                    male = _revive_body(design, male, male_name)
                    female = _revive_body(design, female, female_name)
                    if male is None or female is None:
                        nb_skipped_total += 1
                        _dbg(f'paire ignoree apres tenons (corps introuvable) {male_name} / {female_name}')
                        continue
                    nb_ok, nb_skipped, errors, _new_records = MortaiseCNC.creer_mortaises([male], [female], root)
                    nb_ok_total += nb_ok
                    nb_skipped_total += nb_skipped
                    mortaise_errors.extend(errors)
                except Exception:
                    mortaise_errors.append(traceback.format_exc().strip().splitlines()[-1])
                    _dbg('recreation mortaise EXCEPTION: ' + traceback.format_exc())

            _lap('mortaises')
            n_marge_reappliques = 0
            marge_errors = []
            barre.etape('Jeux de fonctionnement...')
            for _feat_old, jeu, toks, exclure_fond in marge_runs:
                barre.avance()
                try:
                    selected_bodies = []
                    female_tokens_filter = set()
                    for t in toks:
                        found = design.findEntityByToken(t)
                        body = adsk.fusion.BRepBody.cast(found[0]) if found else None
                        if body:
                            selected_bodies.append(body)
                            female_tokens_filter.add(t)
                    # skip_heuristique=True (ajoute le 2026-10-04, meme
                    # correctif que Modif Marge dans MargeCNC.py) : ce rejeu
                    # porte sur des face_tokens DEJA enregistres avec
                    # precision, la detection heuristique de secours
                    # (_chant_faces_heuristique) ne doit pas s'y ajouter -
                    # voir la docstring d'apply_jeu pour le detail du bug
                    # qu'elle cause sinon sur les entailles (face de fond
                    # rajoutee a tort).
                    feat, n_m, n_h, faces = MargeCNC.apply_jeu(
                        design, root, female_tokens_filter, selected_bodies, jeu, True, exclure_fond,
                        skip_heuristique=True)
                    if feat:
                        n_marge_reappliques += 1
                except Exception:
                    marge_errors.append(traceback.format_exc().strip().splitlines()[-1])
                    _dbg('reapplication marge EXCEPTION: ' + traceback.format_exc())

            # --- 5. Entailles puis dogbones (add-ins optionnels, fonctions
            # fournies par EntailleCNC / DogboneCNC ; ordre convenu entre
            # les add-ins : tenons -> mortaises -> jeux -> entailles ->
            # dogbones, les dogbones dependant des coupes precedentes).
            _lap('jeux')
            extra_lines = []
            extra_errors = []
            for _label, _fn in (('entaille(s)', recreate_entailles),
                                ('dogbone(s)', recreate_dogbones)):
                if _fn is None:
                    continue
                barre.avance(message='Recreation des %s...' % _label)
                try:
                    with cnc_progress.Barre(COMMAND_NAME, 'Recreation des %s...' % _label):
                        _n_ok, _n_tot, _errs = _fn(design)
                    _lap(_label)
                    if _n_tot:
                        extra_lines.append(f'{_n_ok}/{_n_tot} {_label} recree(s).')
                    extra_errors.extend(list(_errs or []))
                except Exception:
                    extra_errors.append(f'{_label} : ' + traceback.format_exc().strip().splitlines()[-1])
                    _dbg(f'recreation {_label} EXCEPTION: ' + traceback.format_exc())

            # Groupe "Mise a jour CNC" autour de tout ce que la mise a jour a
            # cree. L'index de depart ne peut pas etre lu avant : les
            # suppressions faites en route (tenons, entailles, dogbones...)
            # decalent la chronologie, et le groupe n'etait alors jamais cree
            # (constate 2026-10-06 : 120 fonctions d'entailles en vrac).
            try:
                _group_new_items(tl, old_tokens)
            except Exception:
                _dbg('groupe Mise a jour CNC EXCEPTION: ' + traceback.format_exc())
            _dbg(f'empreintes mortaises enregistrees : {_write_mortaise_sigs(design, MortaiseCNC)}')

            _app.activeViewport.fit()
            _dbg(f'[temps] TOTAL {time.time() - _t0:.1f}s : ' + ', '.join(_times))

            msg = (f'{nb_ok_total} mortaise(s) recreee(s), '
                   f'{n_marge_reappliques} jeu(x) reapplique(s).')
            if n_mortaise_kept or n_marge_kept:
                msg += (f'\n{n_mortaise_kept} mortaise(s) et {n_marge_kept} jeu(x) laisse(s) '
                        'tels quels (corps non deplaces).')
            if nb_skipped_total:
                msg += f'\n{nb_skipped_total} paire(s) ignoree(s) (corps disjoints ou introuvables).'
            if TenonCNC is not None and n_tenons_total:
                msg += f'\n{n_tenons_ok}/{n_tenons_total} tenon(s)/languette(s) repositionne(s).'
            if n_tenons_sans_spec:
                msg += (f'\n{n_tenons_sans_spec} tenon(s)/languette(s) crees avant le suivi des '
                        'parametres, non repositionnes (utilisez "Reparer anciens Tenons" '
                        'dans Tenons CNC une fois, puis relancez Mettre a jour CNC).')
            if extra_lines:
                msg += '\n' + '\n'.join(extra_lines)
            errs = mortaise_errors + marge_errors + tenon_errors + extra_errors
            if errs:
                msg += '\n\nErreurs :\n' + '\n'.join(errs[:10])
            msg += f'\n\nDuree : {time.time() - _t0:.0f} s'
            barre.fin()
            _ui.messageBox(msg, COMMAND_NAME)
            _dbg(f'=== Mise a jour CNC : fin - {msg} ===')
        except Exception:
            if barre is not None:
                barre.fin()
            _ui.messageBox('Erreur Mise a jour CNC:\n' + traceback.format_exc())
            _dbg('EXCEPTION top-level: ' + traceback.format_exc())
        finally:
            if barre is not None:
                barre.fin()
            # Restaure la position d'origine du marqueur de chronologie (voir
            # etape 0 ci-dessus), succes ou echec. Retrouve la MEME feature
            # par entityToken plutot que par index brut : des suppressions
            # de features situees avant l'ancienne position du marqueur
            # (rare, mais possible si une vieille mortaise/jeu y vivait)
            # decaleraient sinon le marqueur restaure sur la mauvaise
            # feature.
            try:
                # Seulement si on a nous-memes avance le marqueur (il etait en
                # retrait) : s'il etait deja a la fin, il doit y rester, APRES
                # les features que la mise a jour vient d'ajouter (avant, on le
                # remettait a son ancien index, donc en plein milieu).
                if advanced and tl is not None and original_marker is not None and tl.markerPosition != original_marker:
                    new_pos = original_marker
                    if anchor_tok is not None:
                        found_anchor = False
                        for i in range(tl.count):
                            try:
                                if tl.item(i).entity.entityToken == anchor_tok:
                                    new_pos = i + 1
                                    found_anchor = True
                                    break
                            except Exception:
                                continue
                        if not found_anchor:
                            new_pos = min(original_marker, tl.count)
                            _dbg('ancre chronologie introuvable apres mise a jour - restauration par index brut (approximatif)')
                    else:
                        new_pos = min(original_marker, tl.count)
                    tl.markerPosition = new_pos
                    _dbg(f'chronologie restauree a la position {new_pos} (origine {original_marker})')
            except Exception:
                _dbg('restauration position chronologie EXCEPTION: ' + traceback.format_exc())


class CreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self): super().__init__()

    def notify(self, args):
        try:
            cmd = args.command
            cmd.isRepeatable = False
            on_ex = ExecuteHandler()
            cmd.execute.add(on_ex)
            _handlers.append(on_ex)
        except Exception:
            _ui.messageBox(traceback.format_exc())


def run(context):
    global _app, _ui
    try:
        _app = adsk.core.Application.get()
        _ui = _app.userInterface

        for pid in PANEL_IDS:
            panel = _ui.allToolbarPanels.itemById(pid)
            if panel is None:
                continue
            c = panel.controls.itemById(CMD_ID)
            if c:
                c.deleteMe()
        old = _ui.commandDefinitions.itemById(CMD_ID)
        if old:
            old.deleteMe()

        cmd_def = _ui.commandDefinitions.addButtonDefinition(
            CMD_ID, COMMAND_NAME, COMMAND_DESC, '')
        on_created = CreatedHandler()
        cmd_def.commandCreated.add(on_created)
        _handlers.append(on_created)

        # Bouton de ruban RETIRE : devenu inutile depuis la creation de
        # CNC Toolkit, qui retrouve et execute cette CommandDefinition
        # directement depuis sa palette.
    except Exception:
        if _ui:
            _ui.messageBox('Erreur run Mise a jour CNC:\n' + traceback.format_exc())


def stop(context):
    try:
        for pid in PANEL_IDS:
            panel = _ui.allToolbarPanels.itemById(pid)
            if panel is None:
                continue
            ctrl = panel.controls.itemById(CMD_ID)
            if ctrl:
                ctrl.deleteMe()
        cd = _ui.commandDefinitions.itemById(CMD_ID)
        if cd:
            cd.deleteMe()
        _handlers.clear()
    except Exception:
        pass
