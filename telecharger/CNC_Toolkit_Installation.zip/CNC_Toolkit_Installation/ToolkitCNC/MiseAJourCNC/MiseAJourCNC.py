import adsk.core, adsk.fusion, traceback, os, sys, time, json

# Barre de chargement commune du Toolkit (ToolkitCNC/cnc_progress.py)
_TK_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _TK_DIR not in sys.path:
    sys.path.append(_TK_DIR)
import cnc_progress

_app = None
_ui = None
_handlers = []

CMD_ID = 'MiseAJourCNCCmd'
COMMAND_NAME = 'Mettre a jour CNC'
COMMAND_DESC = ("Recree en 1 clic les mortaises (Mortaise CNC) et le jeu de "
                "fonctionnement (Marge CNC) a la position actuelle des corps, "
                "apres un changement de parametre qui les a deplaces.")
PANEL_IDS = ['SolidModifyPanel', 'SolidCreatePanel', 'SketchCreatePanel', 'ToolsPanel']

_ADDIN_DIR = os.path.dirname(os.path.abspath(__file__))
DEBUG_LOG = os.path.join(_ADDIN_DIR, 'maj_debug.log')


def _dbg(msg):
    try:
        with open(DEBUG_LOG, 'a', encoding='utf-8') as f:
            f.write(time.strftime('%H:%M:%S') + ' ' + str(msg) + '\n')
    except Exception:
        pass


def _find_module(short_name):
    """Retrouve un module d'add-in deja charge dans cette session Fusion,
    quel que soit la maniere dont il a ete charge.

    Quand Fusion charge lui-meme un add-in au demarrage (son comportement
    normal), il n'utilise PAS la cle 'MortaiseCNC'/'MargeCNC' telle quelle
    dans sys.modules : il l'enregistre sous une cle "mangled" du style
    "__main__C%3A%2FUsers%2F...%2FAddIns%2FMortaiseCNC%2FMortaiseCNC_py"
    (chemin complet du fichier, encode, avec le nom de fichier termine en
    "_py"). sys.modules.get('MortaiseCNC') renvoie alors None MEME SI
    l'add-in est bel et bien actif - ce qui declenchait a tort le message
    "Mortaise CNC et/ou Marge CNC ne sont pas actifs" alors que Scripts et
    complements les montre bien actifs. On cherche donc, en repli, une cle
    qui se termine par '<NomAddin>_py' (chargement natif Fusion), en plus
    de la cle exacte (rechargement manuel via importlib, utilise pendant le
    developpement)."""
    mod = sys.modules.get(short_name)
    if mod is not None:
        return mod
    suffix = short_name + '_py'
    for k, m in list(sys.modules.items()):
        if k.endswith(suffix):
            return m
    return None


def _get_modules():
    """Recupere les modules Mortaise CNC / Marge CNC deja charges par
    Fusion dans cette session (doivent etre actifs)."""
    return _find_module('MortaiseCNC'), _find_module('MargeCNC')


def _revive_body(design, body, name):
    """Le corps male/femelle releve avant la recreation des tenons peut
    devenir invalide (son Combiner 'Tenon' a ete supprime puis recree) :
    on le retrouve alors par son nom, seulement s'il est unique."""
    try:
        if body is not None and body.isValid:
            return body
    except Exception:
        pass
    if not name:
        return None
    root = design.rootComponent
    comps = {root.entityToken: root}
    for occ in root.allOccurrences:
        comps.setdefault(occ.component.entityToken, occ.component)
    matches = [b for c in comps.values() for b in c.bRepBodies if b.name == name]
    return matches[0] if len(matches) == 1 else None


def _entity_token(item):
    try:
        e = item.entity
        return e.entityToken if e is not None else None
    except Exception:
        return None


def _timeline_tokens(tl):
    """entityToken de toutes les fonctions deja dans la chronologie (y
    compris dans les groupes), pour reconnaitre ensuite les nouvelles."""
    toks = set()
    for i in range(tl.count):
        it = tl.item(i)
        try:
            if it.isGroup:
                g = adsk.fusion.TimelineGroup.cast(it)
                for k in range(g.count):
                    t = _entity_token(g.item(k))
                    if t:
                        toks.add(t)
                continue
        except Exception:
            pass
        t = _entity_token(it)
        if t:
            toks.add(t)
    return toks


def _new_tail(tl, old_tokens):
    """Remonte depuis le marqueur tant que les elements sont nouveaux.
    Retourne (index du premier nouvel element, groupes nouveaux)."""
    i = tl.markerPosition - 1
    groups = []
    while i >= 0:
        it = tl.item(i)
        if it.isGroup:
            g = adsk.fusion.TimelineGroup.cast(it)
            toks = [_entity_token(g.item(k)) for k in range(g.count)]
            if not toks or any(t is None or t in old_tokens for t in toks):
                break
            groups.append(g)
        else:
            t = _entity_token(it)
            if t is None or t in old_tokens:
                break
        i -= 1
    return i + 1, groups


def _group_new_items(tl, old_tokens):
    start, groups = _new_tail(tl, old_tokens)
    if groups:
        # Fusion n'imbrique pas les groupes : on defait ceux que la mise a
        # jour vient de creer (ex. "Dogbone CNC") pour tout regrouper.
        for g in groups:
            try:
                g.deleteMe(False)
            except Exception:
                _dbg('degroupage EXCEPTION: ' + traceback.format_exc())
        start, groups = _new_tail(tl, old_tokens)
    end = tl.markerPosition - 1
    _dbg(f'groupe Mise a jour CNC : elements {start}..{end}')
    if end > start and not groups:
        grp = tl.timelineGroups.add(start, end)
        if grp:
            grp.name = 'Mise a jour CNC'
            grp.isCollapsed = True
    elif end == start:
        tl.item(end).entity.name = 'Mise a jour CNC'


# --- Selection de corps (2026-10-21) -----------------------------------------
# Demande de l'utilisateur : "que je puisse selectionner les corps a mettre a jour
# et uniquement les corps selectionnes". scope = ensemble de cles
# (id composant, nom du corps natif), ou None pour tout le document.
_SEL_ID = 'majCorps'
_ALL_ID = 'majTout'


def _scope_from_entities(entities):
    keys = set()

    def add_comp(comp, depth=0):
        for b in comp.bRepBodies:
            keys.add((comp.id, b.name))

    def add_occ(occ, depth=0):
        add_comp(occ.component)
        if depth < 8:
            for child in occ.childOccurrences:
                add_occ(child, depth + 1)

    for e in entities:
        try:
            b = adsk.fusion.BRepBody.cast(e)
            if b is not None:
                k = _body_key(b)
                if k:
                    keys.add(k)
                continue
            o = adsk.fusion.Occurrence.cast(e)
            if o is not None:
                add_occ(o)
        except Exception:
            _dbg('selection EXCEPTION: ' + traceback.format_exc())
    return keys


def _in_scope(scope, body):
    if scope is None:
        return True
    try:
        return _body_key(body) in scope
    except Exception:
        return False


# --- Recreation a la place d'origine dans la chronologie (2026-10-21) --------
# Demande de l'utilisateur : si Mortaise CNC (ou un autre outil) a cree sa coupe
# plus tot dans la chronologie, Mettre a jour CNC la recree au MEME endroit,
# pas en fin d'historique. Fusion cree toujours a la position du marqueur :
# avant de supprimer un element on memorise l'ordre des fonctions
# (snapshot), puis on place le marqueur juste apres le dernier element qui
# le precedait et qui existe encore (un groupe est pris en entier : le marqueur
# se met apres lui), on recree, et on revient a la limite sure. Plusieurs
# elements places apres la meme ancre gardent leur ordre (decalage cumule).
class _Placer:
    def __init__(self, design):
        self.design = design
        self.tl = design.timeline
        self.tail = self.tl.count - self.tl.markerPosition   # fonctions apres la limite sure
        self.offsets = {}
        self.cur = None      # (cle d'ancre, position du marqueur avant creation)
        self.n_placed = 0    # elements recrees ailleurs qu'en fin d'historique
        self.n_groups = 0
        self.reloc = set()   # corps dont une coupe a ete recreee apres un deplacement
        self.reloc_late = set()   # ... et dont la coupe est restee apres la copie du corps

    def work_end(self):
        """Position de travail : celle du marqueur au debut de la mise a jour
        (juste avant la 1re ArrangeFeature, ou la ou l'utilisateur l'avait mis
        s'il etait deja plus loin). Les fonctions qui la suivent ne bougent pas :
        on compte donc depuis la fin."""
        return max(0, self.tl.count - self.tail)

    def to_work_end(self):
        try:
            self.tl.markerPosition = self.work_end()
        except Exception:
            _dbg('retour fin de travail EXCEPTION: ' + traceback.format_exc())

    def snapshot(self):
        """Jetons (dans l'ordre) de toutes les fonctions, groupes depliés."""
        self.to_work_end()
        tl = self.tl
        out = []
        for i in range(tl.count):
            it = tl.item(i)
            try:
                if it.isGroup:
                    g = adsk.fusion.TimelineGroup.cast(it)
                    for k in range(g.count):
                        out.append(_entity_token(g.item(k)))
                    continue
            except Exception:
                pass
            out.append(_entity_token(it))
        return out

    def first_gone(self, snap):
        alive = _timeline_tokens(self.tl)
        for j, t in enumerate(snap):
            if t is not None and t not in alive:
                return j
        return None

    def _moves(self):
        """Deplacements (MoveFeature) du document : [(jeton, {cles de corps})].
        Lus une fois, marqueur en fin de travail (les fonctions apres le marqueur
        ne sont pas lisibles)."""
        if getattr(self, '_mv', None) is not None:
            return self._mv
        self.to_work_end()
        out = []
        tl = self.tl
        for i in range(tl.count):
            it = tl.item(i)
            try:
                items = [it]
                if it.isGroup:
                    g = adsk.fusion.TimelineGroup.cast(it)
                    items = [g.item(k) for k in range(g.count)]
                for o in items:
                    mf = adsk.fusion.MoveFeature.cast(o.entity)
                    if mf is None:
                        continue
                    keys = set()
                    # inputEntities exige de reculer l'historique ; bodies non.
                    for b in mf.bodies:
                        keys.add(_body_key(b))
                    out.append((mf, keys))   # entityToken indisponible pour un deplacement
            except Exception:
                pass
        self._mv = out
        return out

    def _after_moves(self, keys):
        """Position de marqueur (premiere position libre apres le dernier
        deplacement qui touche un de ces corps), ou None."""
        best = None
        for mf, mk in self._moves():
            if not (mk & keys):
                continue
            try:
                tlo = mf.timelineObject
                for _i in range(6):
                    g = getattr(tlo, 'parentGroup', None)
                    if g is None:
                        break
                    tlo = g
                best = (tlo, mf.name)
            except Exception:
                continue
        return best

    def _copy_ceiling(self, keys):
        """Premiere copie (Copier/Coller) d'un de ces corps : (objet d'historique
        de plus haut niveau, nom), ou None. Lue une fois, marqueur en fin de travail."""
        if getattr(self, '_cp', None) is None:
            self.to_work_end()
            out = []
            try:
                comps = list(self.design.allComponents)
            except Exception:
                comps = []
            for c in comps:
                try:
                    coll = c.features.copyPasteBodies
                    for i in range(coll.count):
                        f = coll.item(i)
                        try:
                            if f.isSuppressed or f.timelineObject.isRolledBack:
                                continue
                            sb = f.sourceBody
                            sb = [sb.item(q) for q in range(sb.count)] if hasattr(sb, 'count') else [sb]
                            ks = set(_body_key(b) for b in sb if b is not None)
                            tlo = f.timelineObject
                            for _i in range(6):
                                g = getattr(tlo, 'parentGroup', None)
                                if g is None:
                                    break
                                tlo = g
                            out.append((tlo, f.name, ks))
                        except Exception:
                            continue
                except Exception:
                    continue
            self._cp = out
        best = None
        for tlo, name, ks in self._cp:
            if not (ks & keys):
                continue
            try:
                idx = tlo.index
            except Exception:
                continue
            if best is None or idx < best[2]:
                best = (tlo, name, idx)
        return best

    def _hoist(self, mv, ks, cp):
        """Un Deplacer qui ne touche que les corps de cette coupe et qui vient
        apres la copie du corps coupe : on le remonte juste avant la copie, pour
        que la coupe (recreee apres lui) soit encore avant la copie et que celle-ci
        en herite. Retourne la nouvelle position de la copie, ou None."""
        try:
            mtlo, mname = mv
            mk = None
            for mf, k in self._moves():
                if mf.name == mname:
                    mk = k
                    break
            ci = cp[0].index
            if not mk or not (mk <= (ks | getattr(self, 'hoist_keys', set()))) or mtlo.isGroup or mtlo.index < ci:
                return None
            self.to_work_end()
            if not mtlo.canReorder(ci):
                _dbg(f'deplacement {mname} : impossible de le remonter avant la copie {cp[1]}')
                return None
            mtlo.reorder(ci)
            _dbg(f'placement : deplacement {mname} remonte avant la copie {cp[1]} (position {ci})')
            return cp[0].index
        except Exception:
            _dbg('remontee deplacement EXCEPTION: ' + traceback.format_exc())
            return None

    def go(self, snap, j, keys=None, ceil_keys=None, follow_reloc=False, force_ceiling=False):
        """Marqueur juste apres le dernier element precedant snap[j] qui existe
        encore (+ ce qui a deja ete place apres lui pendant cette mise a jour).
        keys : corps concernes (cle composant+nom) ; si l'un d'eux a ete
        deplace (Deplacer) apres cette place, la coupe doit venir apres ce
        deplacement, sinon elle serait calculee sur l'ancienne position."""
        tl = self.tl
        mv = None
        if j is not None and keys:
            try:
                mv = self._after_moves(set(k for k in keys if k))
            except Exception:
                mv = None
        ks = set(k for k in (keys or []) if k)
        cp = None
        if ceil_keys and j is not None:
            try:
                # lu ici : la 1re lecture remet le marqueur en fin de travail
                cp = self._copy_ceiling(set(k for k in ceil_keys if k))
            except Exception:
                cp = None
        if mv is not None and cp is not None:
            ni = self._hoist(mv, ks, cp)
            if ni is not None:
                cp = (cp[0], cp[1], ni)
        if follow_reloc and mv is None and j is not None and ks & self.reloc:
            # un corps de cet element a vu sa mortaise recreee apres un
            # deplacement : le jeu doit suivre la mortaise. Avant la copie du
            # corps si la mortaise y est restee, sinon en fin.
            if cp is not None and not (ks & self.reloc_late):
                force_ceiling = True
            else:
                j = None
        if j is None:
            self.to_work_end()
            self.cur = ('FIN', tl.markerPosition)
            return
        alive = _timeline_tokens(tl)
        k = j - 1
        while k >= 0 and (snap[k] is None or snap[k] not in alive):
            k -= 1
        if k < 0:
            key = 'DEBUT'
            tl.markerPosition = 0
        else:
            key = snap[k]
            ent = self.design.findEntityByToken(key)[0]
            tlo = ent.timelineObject
            for _i in range(6):
                g = getattr(tlo, 'parentGroup', None)
                if g is None:
                    break
                tlo = g
            tlo.rollTo(False)
        if mv is not None:
            mtlo, mtok = mv
            cur = tl.markerPosition
            try:
                mpos = mtlo.index + 1
            except Exception:
                mpos = None
            if mpos is not None and mpos > cur:
                mtlo.rollTo(False)
                key = ('MV', mtok)
                self.reloc |= ks
                if cp is not None and mpos > cp[2]:
                    self.reloc_late |= ks
                _dbg(f'placement : corps deplace apres la place d\'origine, recree apres le deplacement (position {mpos})')
        if mv is None and cp is not None:
            # Une copie du corps (Copier/Coller) faite avant cette place ne
            # recoit pas la coupe : on la recree avant la copie, qui en herite.
            try:
                eff = tl.markerPosition + (0 if (isinstance(key, tuple) and key[0] == 'CP') else self.offsets.get(key, 0))
                if eff > cp[2] or force_ceiling:
                    cp[0].rollTo(True)
                    key = ('CP', cp[1])
                    _dbg(f'placement : recree avant la copie {cp[1]} du corps (position {cp[2]})')
            except Exception:
                _dbg('plafond copie EXCEPTION: ' + traceback.format_exc())
        off = self.offsets.get(key, 0)
        if off and not (isinstance(key, tuple) and key[0] == 'CP'):
            # (avant une copie, le marqueur est deja apres ce qu'on y a insere)
            tl.markerPosition = min(tl.count, tl.markerPosition + off)
        self.cur = (key, tl.markerPosition)
        if tl.markerPosition < self.work_end():
            self.n_placed += 1

    def go_diff(self, snap):
        """Comme go, pour un element dont les fonctions viennent d'etre
        supprimees : la premiere fonction du snapshot qui a disparu."""
        self.go(snap, self.first_gone(snap))

    def _flat(self, top_index):
        tl = self.tl
        n = 0
        for i in range(top_index):
            it = tl.item(i)
            try:
                if it.isGroup:
                    n += adsk.fusion.TimelineGroup.cast(it).count
                    continue
            except Exception:
                pass
            n += 1
        return n

    def done(self):
        """Fin d'une recreation : memorise ce qui a ete insere, le regroupe, et
        revient a la limite sure."""
        tl = self.tl
        try:
            if self.cur is not None:
                key, start = self.cur
                end = tl.markerPosition
                n = end - start
                if n > 1:
                    items = [tl.item(i) for i in range(start, end)]
                    if not any(it.isGroup for it in items):
                        try:
                            grp = tl.timelineGroups.add(self._flat(start), self._flat(end) - 1)
                            grp.name = 'Mise a jour CNC'
                            grp.isCollapsed = True
                            self.n_groups += 1
                            end = tl.markerPosition
                            n = end - start
                        except Exception:
                            _dbg('groupe local EXCEPTION: ' + traceback.format_exc())
                if n > 0:
                    self.offsets[key] = self.offsets.get(key, 0) + n
        except Exception:
            _dbg('done EXCEPTION: ' + traceback.format_exc())
        finally:
            self.cur = None
            self.to_work_end()


class _Hooks:
    """Branche _Placer sur TenonCNC / EntailleCNC (set_place_hooks) : ils
    appellent before() avant de supprimer un element, after_delete(snap)
    juste apres (le marqueur est alors replace a l'ancienne place) et done()
    quand l'element est recree."""
    def __init__(self, placer):
        self.p = placer

    def before(self):
        return self.p.snapshot()

    def after_delete(self, snap):
        self.p.go_diff(snap)

    def done(self):
        self.p.done()


def _fresh_body(design, tok, name):
    """Corps retrouve apres un deplacement du marqueur : par jeton, sinon par
    nom (les references Python d'avant ne sont plus fiables)."""
    b = _resolve_tok(design, tok)
    try:
        if b is not None and b.name == name:
            return b
    except Exception:
        pass
    return _revive_body(design, None, name)


# --- Mise a jour selective des mortaises et des jeux (2026-10-11) ------------
# Demande de l'utilisateur : ne recalculer que ce qui a bouge. Tenons, entailles et
# dogbones le faisaient deja (chacun compare l'empreinte de ses corps) ; les
# mortaises et les jeux etaient, eux, TOUS supprimes et recrees a chaque
# fois. Chaque feature Mortaise CNC garde maintenant l'encombrement de ses
# corps male/femelle ('MiseAJourCNC', 'sig') pris a la fin de la derniere
# mise a jour : une paire est refaite seulement si l'un des deux a bouge ou
# change de taille (ou sans empreinte : 1re mise a jour, ancien document).
_SIG_GROUP = 'MiseAJourCNC'
_SIG_TOL_CM = 0.01   # 0.1 mm, meme tolerance qu'Entaille CNC


_bbox_cache = {}   # {jeton du corps : empreinte}, vide a chaque etat du document


def _bbox_sig(body):
    # Le meme corps femelle revient dans chaque paire (29 fois sur FS210 V1) :
    # son encombrement n'est lu qu'une fois par etat du document.
    try:
        tok = body.entityToken
    except Exception:
        tok = None
    if tok and tok in _bbox_cache:
        return list(_bbox_cache[tok])
    bb = body.boundingBox
    sig = [round(v, 4) for v in (bb.minPoint.x, bb.minPoint.y, bb.minPoint.z,
                                 bb.maxPoint.x, bb.maxPoint.y, bb.maxPoint.z)]
    if tok:
        _bbox_cache[tok] = sig
    return list(sig)


def _sig_moved(old, cur):
    if not old or len(old) != len(cur):
        return True
    return any(abs(a - b) > _SIG_TOL_CM for a, b in zip(old, cur))


def _feat_in_error(feat):
    try:
        return feat.timelineObject.healthState == adsk.fusion.FeatureHealthStates.ErrorFeatureHealthState
    except Exception:
        return False


def _read_sig(feat):
    try:
        a = feat.attributes.itemByName(_SIG_GROUP, 'sig')
        return json.loads(a.value) if a else None
    except Exception:
        return None


def _body_key(body):
    """Identite stable d'un corps (les entityToken d'un meme corps peuvent
    differer d'une lecture a l'autre, et un jeton peut donner le corps natif
    ou son proxy d'occurrence) : composant + nom. Deux occurrences d'un meme
    composant partagent la cle : on refait alors un peu plus, jamais moins."""
    try:
        native = body.nativeObject or body
    except Exception:
        native = body
    try:
        return (native.parentComponent.id, native.name)
    except Exception:
        return None


def _resolve_tok(design, tok):
    try:
        found = design.findEntityByToken(tok) if tok else None
        return found[0] if found else None
    except Exception:
        return None


def _resolve_named(design, key, found):
    """Les entityToken peuvent deriver apres la suppression d'un corps de la
    chronologie (un jeton designe alors un AUTRE corps). Si le corps trouve
    par jeton n'a pas la cle (composant, nom) notee a la derniere mise a
    jour, on le reprend par son nom. Retourne (corps, derive)."""
    if not key or found is None or tuple(key) == _body_key(found):
        return found, False
    try:
        comp = design.allComponents.itemById(key[0])
        nb = comp.bRepBodies.itemByName(key[1]) if comp is not None else None
        if nb is not None:
            return nb, True
    except Exception:
        pass
    return found, True


def _write_mortaise_sigs(design, MortaiseCNC):
    """Empreinte male/femelle sur chaque feature Mortaise CNC, a la fin de la
    mise a jour (apres tenons/entailles, donc sur les corps finis)."""
    n = 0
    try:
        feats = MortaiseCNC.find_all_mortaise_features(design)
    except Exception:
        _dbg('empreintes mortaises : lecture EXCEPTION: ' + traceback.format_exc())
        return 0
    for feat, male_tok, female_tok in feats:
        male = _resolve_tok(design, male_tok)
        female = _resolve_tok(design, female_tok)
        if male is None or female is None:
            continue
        try:
            feat.attributes.add(_SIG_GROUP, 'sig', json.dumps(
                {'male': _bbox_sig(male), 'female': _bbox_sig(female),
                 'mk': list(_body_key(male) or ()), 'fk': list(_body_key(female) or ())}))
            n += 1
        except Exception:
            _dbg('empreinte mortaise EXCEPTION: ' + traceback.format_exc())
    return n


# --- Dogbones : familles origine + copies (2026-10-20) -----------------------
# Dogbone CNC cree ses dogbones UNE fois sur le corps d'origine, avant le
# reseau / copier-coller (les copies les recoivent par le reseau), ou en fin
# d'historique quand une coupe a outils suit le reseau. Dans le premier cas
# la fonction ne porte que le nom de l'origine : recreate_all_dogbones ne
# regarde que l'empreinte de ce corps et ne voit jamais qu'une COPIE a change
# (coupe recreee apres le reseau). On compare donc l'empreinte de toute la
# famille (origine + copies) a celle notee a la fin de la derniere mise a jour.
_DOGSIG_ATTR = 'dogsig'


def _body_fam_key(body):
    k = _body_key(body)
    return '%s|%s' % k if k else None


def _read_dogsigs(design):
    try:
        a = design.attributes.itemByName(_SIG_GROUP, _DOGSIG_ATTR)
        return json.loads(a.value) if a else None
    except Exception:
        return None


def _dog_families(design, D, snap):
    """{token_origine: [corps...]} : chaque corps portant des dogbones et les
    copies de reseau / copier-coller de son origine."""
    comps = {c.id: c for c in design.allComponents}
    copy_src, _first = D._pattern_map(design)
    fams = {}
    seen = {}   # {origine : jetons deja ajoutes} (evite 900 lectures de jeton par famille)
    def add(root, b):
        lst = fams.setdefault(root, [])
        toks = seen.setdefault(root, set())
        t = b.entityToken
        if t not in toks:
            toks.add(t)
            lst.append(b)
    for e in snap:
        c = comps.get(e['comp_id'])
        b = c.bRepBodies.itemByName(e['body_name']) if c is not None else None
        if b is None:
            continue
        add(D._root_source(copy_src, D._body_token(b)), b)
    for tok, src in copy_src.items():
        root = D._root_source(copy_src, src)
        if root in fams:
            b = None
            try:
                for ent in design.findEntityByToken(tok):
                    b = adsk.fusion.BRepBody.cast(ent)
                    if b is not None:
                        break
            except Exception:
                b = None
            if b is not None:
                add(root, b)
    return fams


def _dog_changed(old, new):
    """Comme DogboneCNC._sig_changed, mais sans la position : un corps simplement
    deplace ou tourne (Deplacer) garde ses propres dogbones, qui sont dans sa matiere.
    Seuls comptent le volume et la surface (l'encombrement change avec une rotation)."""
    if not old or not new or len(old) != len(new) or len(old) < 8:
        return True
    for a, b in zip(old[6:], new[6:]):   # volume, surface : insensibles a un deplacement ou une rotation
        if abs(a - b) > max(1e-3, abs(a) * 1e-5):
            return True
    return False


def _fam_sigs(fams, D):
    out = {}
    for members in fams.values():
        for b in members:
            try:
                out[_body_fam_key(b)] = D._body_sig(b)
            except Exception:
                try:
                    out[_body_fam_key(b)] = D._body_sig(b.parentComponent.bRepBodies.itemByName(b.name))
                except Exception:
                    _dbg(f'empreinte dogbones de {getattr(b, "name", "?")} illisible : ' + traceback.format_exc().strip().splitlines()[-1])
    return out


def _orphan_dogbone_tools(design, D):
    """Outils de dogbone (BaseFeature / esquisse) dont la coupe n'existe pas :
    le cylindre reste visible dans le modele et le corps n'a pas ses
    dogbones. Retourne [(comp_id, body_name, params, [fonctions])]."""
    links = {}
    try:
        attrs = design.findAttributes(D.ATTR_GROUP, 'link')
    except Exception:
        return []
    for a in attrs:
        links.setdefault(a.value, []).append(a.parent)
    out = []
    for ents in links.values():
        if any(adsk.fusion.CombineFeature.cast(e) or adsk.fusion.ExtrudeFeature.cast(e) for e in ents):
            continue
        try:
            e0 = ents[0]
            bn = e0.attributes.itemByName(D.ATTR_GROUP, 'body_name')
            pa = e0.attributes.itemByName(D.ATTR_GROUP, 'params')
            out.append((e0.parentComponent.id, bn.value if bn else None,
                        json.loads(pa.value) if pa else {}, ents))
        except Exception:
            _dbg('orphelin dogbone EXCEPTION: ' + traceback.format_exc())
    return out


def _repair_orphan_dogbones(design, D, scope=None):
    """Supprime les outils orphelins puis recree les dogbones de leurs corps
    (sauf s'ils ont deja une coupe). Retourne (n_repares, erreurs)."""
    orphans = _orphan_dogbone_tools(design, D)
    if scope is not None:
        orphans = [o for o in orphans if (o[0], o[1]) in scope]
    if not orphans:
        return 0, []
    have = set((e['comp_id'], e['body_name']) for e in D.snapshot_dogbones(design, None))
    feats = [f for o in orphans for f in o[3]]
    _dbg(f'dogbones : {len(orphans)} outil(s) orphelin(s) supprime(s)')
    D._delete_features_batch(design, feats)
    todo, seen = [], set()
    for cid, name, params, _ in orphans:
        if name and (cid, name) not in have and (cid, name) not in seen:
            seen.add((cid, name))
            todo.append({'comp_id': cid, 'body_name': name, 'params': params})
    errs = []
    n = 0
    if todo:
        n, _tot, errs = D.restore_dogbones(design, todo)
    # Filet : un outil recree sans coupe ne doit jamais rester visible.
    left = _orphan_dogbone_tools(design, D)
    if scope is not None:
        left = [o for o in left if (o[0], o[1]) in scope]
    if left:
        D._delete_features_batch(design, [f for o in left for f in o[3]])
        errs.append('Dogbones non recrees sur : ' + ', '.join(str(o[1]) for o in left))
    return n, errs


def _update_entailles(design, scope=None):
    """Entailles a refaire. Sans selection : les lots dont un corps a bouge
    (comme recreate_all_entailles). Avec selection : les lots qui touchent un
    corps choisi (sauf les lots en esquisse, qui suivent les corps tout seuls
    tant qu'ils ne sont pas en erreur). Retourne (n_ok, n_total, erreurs)."""
    E = _find_module('EntailleCNC')
    fn = getattr(E, 'recreate_entailles', None)
    if scope is None or fn is None:
        return E.recreate_all_entailles(design)
    stale = set(s_['id'] for s_ in E.entailles_stale(design))
    ids = []
    for lot in E._lot_read_all(design):
        keys = set((r.get('comp'), r.get('name')) for r in E._lot_refs(lot))
        if keys & scope and (not lot.get('parametric') or lot['id'] in stale):
            ids.append(lot['id'])
    if not ids:
        return 0, 0, []
    return fn(design, lot_ids=ids, group=False, allow_mid=True)


class _DogFast:
    """Pendant les dogbones : _pattern_map (parcourt tous les corps, 0,2 s) n'est
    recalcule que si le marqueur ou le nombre de fonctions a change, et
    clear_preview ne rafraichit plus la vue quand il n'y a rien a effacer."""
    def __init__(self, design, D):
        self.design, self.D = design, D
        self.saved = {}

    def __enter__(self):
        D, design = self.D, self.design
        try:
            orig_pm, orig_cp = D._pattern_map, D.clear_preview
            memo = {}

            def pm(d, _o=orig_pm):
                tl = d.timeline
                k = (id(d), tl.markerPosition, tl.count)
                if k not in memo:
                    memo.clear()
                    memo[k] = _o(d)
                cs, fi = memo[k]
                return dict(cs), dict(fi)

            def cp(_o=orig_cp):
                if getattr(D, '_preview_cg', None) is not None:
                    _o()
            self.saved = {'_pattern_map': orig_pm, 'clear_preview': orig_cp}
            D._pattern_map, D.clear_preview = pm, cp
        except Exception:
            self.saved = {}
        return self

    def __exit__(self, *exc):
        for k, v in self.saved.items():
            try:
                setattr(self.D, k, v)
            except Exception:
                pass
        return False


def _update_dogbones(design, scope=None, force_keys=None, placer=None, female_keys=None, redone_keys=None, male_keys=None):
    D = _find_module('DogboneCNC')
    if D is None or not hasattr(D, '_pattern_map') or not hasattr(D, 'clear_preview'):
        return _update_dogbones_impl(design, scope, force_keys, placer, female_keys, redone_keys, male_keys)
    with _DogFast(design, D):
        return _update_dogbones_impl(design, scope, force_keys, placer, female_keys, redone_keys, male_keys)


def _update_dogbones_impl(design, scope=None, force_keys=None, placer=None, female_keys=None, redone_keys=None, male_keys=None):
    """Remplace DogboneCNC.recreate_all_dogbones : meme travail, mais une
    famille (origine + copies) est refaite des qu'un de ses corps a change
    depuis la derniere mise a jour, copies comprises. Retourne
    (n_ok, n_total, erreurs)."""
    D = _find_module('DogboneCNC')
    if D is None or not hasattr(D, 'snapshot_dogbones') or not hasattr(D, '_pattern_map'):
        fn = getattr(D, 'recreate_all_dogbones', None)
        return fn(design) if fn else (0, 0, [])
    _t = time.time()
    n_rep, rep_errs = _repair_orphan_dogbones(design, D, scope)
    _dbg(f'[temps] dogbones - reparation orphelins: {time.time() - _t:.1f}s')
    _t = time.time()
    snap = D.snapshot_dogbones(design, None)
    _dbg(f'[temps] dogbones - analyse: {time.time() - _t:.1f}s')
    if not snap:
        return n_rep, n_rep, rep_errs
    fams = _dog_families(design, D, snap)
    recorded = _read_dogsigs(design)
    comps = {c.id: c for c in design.allComponents}
    cur = _fam_sigs(fams, D)
    stale_roots = set()
    full_roots = set()   # familles a refaire en entier (origine + copies)
    chg = {}             # {origine : corps dont la forme propre a change}
    for root, members in fams.items():
        mine = chg.setdefault(root, set())
        if scope is not None:
            # Selection : toute famille dont un corps (origine ou copie) est choisi.
            # Exception : un corps choisi qui n'est que le male d'une mortaise
            # refaite garde ses dogbones (dans sa matiere) tant que sa forme
            # n'a pas change. La famille de la femelle, elle, est refaite.
            sel = [b for b in members if _in_scope(scope, b)]
            if any(redone_keys and _body_key(b) in redone_keys for b in members):
                full_roots.add(root)
            elif sel:
                for b in sel:
                    k = _body_key(b)
                    kf = _body_fam_key(b)
                    why = None
                    if not (male_keys and k in male_keys):
                        why = 'pas le male d\'une mortaise refaite'
                    elif recorded is None or kf not in recorded or cur.get(kf) is None:
                        why = 'sans empreinte de dogbones'
                    elif _dog_changed(recorded[kf], cur[kf]):
                        mine.add(kf)
                        _dbg(f'dogbones : {b.name} a refaire (selection : forme changee {recorded[kf]} -> {cur[kf]})')
                    if why:
                        _dbg(f'dogbones : famille de {b.name} a refaire (selection : {why})')
                        full_roots.add(root)
                        break
                if not full_roots & {root} and not mine:
                    _dbg(f'dogbones : famille de {sel[0].name} inchangee (male dont la forme n\'a pas change)')
            if root in full_roots or mine:
                stale_roots.add(root)
            continue
        if recorded is None:
            stale_roots.add(root)   # 1re mise a jour de ce document : on note l'etat
            full_roots.add(root)
            continue
        for b in members:
            k = _body_fam_key(b)
            if k not in recorded or cur.get(k) is None or _dog_changed(recorded[k], cur[k]):
                mine.add(k)
                _dbg(f'dogbones : {b.name} a refaire ({"corps nouveau" if k not in recorded else "empreinte courante illisible" if cur.get(k) is None else "forme changee " + str(recorded[k]) + " -> " + str(cur[k])})')
            if redone_keys and _body_key(b) in redone_keys:
                # coupe recreee dans ce corps (meme volume, autre place) : ses
                # anciens dogbones ne correspondent plus a la mortaise.
                full_roots.add(root)
                _dbg(f'dogbones : famille de {b.name} a refaire (mortaise recreee)')
        if mine or root in full_roots:
            stale_roots.add(root)
    # Les corps d'une famille (copies d'un reseau) portent chacun leurs dogbones :
    # un corps dont seule la forme propre a change (ex. deplace, ses rainures
    # sont alors dans le vide) est refait seul. Famille entiere si l'origine a
    # change, si c'est un corps femelle de mortaise, ou si un dogbone est mal place.
    origin_fk = {}
    for root, members in fams.items():
        oks = [_body_fam_key(b) for b in members if D._body_token(b) == root]
        if oks:
            origin_fk[root] = oks[0]
        if root in stale_roots and root not in full_roots:
            ok = oks
            if not ok or ok[0] in chg.get(root, ()):
                full_roots.add(root)
        if female_keys and any(_body_key(b) in female_keys for b in members):
            full_roots.add(root)
    # Origine de reseau dont les dogbones sont AVANT le reseau alors qu'une coupe
    # qui garde ses outils (mortaise) le suit : le male copie porte des rainures
    # qui laissent un arc de matiere dans chaque mortaise. A refaire en fin.
    misplaced = set()
    try:
        copy_src, first = D._pattern_map(design)
        key_pos = {}
        for a in design.findAttributes(D.ATTR_GROUP, 'body_name'):
            f = a.parent
            if adsk.fusion.CombineFeature.cast(f) is None and adsk.fusion.ExtrudeFeature.cast(f) is None:
                continue
            k = (f.parentComponent.id, a.value)
            pos = D._tl_pos(D._tl_anchor(f.timelineObject))
            if k not in key_pos or pos < key_pos[k]:
                key_pos[k] = pos
        for e in snap:
            c = comps.get(e['comp_id'])
            b = c.bRepBodies.itemByName(e['body_name']) if c is not None else None
            if b is None:
                continue
            tok = D._body_token(b)
            if tok in first and tok not in copy_src:
                pp = D._tl_pos(first[tok])
                k = (e['comp_id'], e['body_name'])
                if key_pos.get(k, 10 ** 9) < pp and D._tool_cut_after(design, pp):
                    misplaced.add(k)
                    _dbg(f'dogbones : {e["body_name"]} avant son reseau alors qu\'une mortaise le suit : a refaire en fin')
    except Exception:
        _dbg('dogbones mal places EXCEPTION: ' + traceback.format_exc())
    tok_root = {}
    for r, m in fams.items():
        for x in m:
            tok_root.setdefault(x.entityToken, r)
    for e in snap:
        if (e['comp_id'], e['body_name']) in misplaced:
            c = comps.get(e['comp_id'])
            b = c.bRepBodies.itemByName(e['body_name']) if c is not None else None
            if b is not None:
                full_roots.update([tok_root[b.entityToken]] if b.entityToken in tok_root else [])
    stale = []
    entry_root = {}
    for e in snap:
        c = comps.get(e['comp_id'])
        b = c.bRepBodies.itemByName(e['body_name']) if c is not None else None
        if b is None:
            continue
        root = tok_root.get(b.entityToken)
        efk = '%s|%s' % (e['comp_id'], e['body_name'])
        entry_root[efk] = root
        # Un dogbone en esquisse suit son corps tant que la coupe le precede ;
        # si la mortaise a ete recreee apres un deplacement (force_keys), il
        # la precede maintenant : on le refait avec les autres.
        forced = bool(force_keys) and (e['comp_id'], e['body_name']) in force_keys \
            and (not female_keys or (e['comp_id'], e['body_name']) in female_keys)
        if (e['comp_id'], e['body_name']) in misplaced:
            forced = True
        part_only = root in stale_roots and root not in full_roots
        if scope is not None and not forced and root in stale_roots:
            forced = _in_scope(scope, b) and (not part_only or efk in chg.get(root, ()))   # corps choisi : refait meme en esquisse
        # (l'origine suit toujours : une copie ne recoit ses coins que par elle)
        if part_only and not forced and efk not in chg.get(root, ()) and efk != origin_fk.get(root):
            continue
        if (root in stale_roots or forced) and (forced or not e.get('sketch_ok')):
            stale.append(e)
    _dbg(f'dogbones : {len(stale_roots)}/{len(fams)} famille(s) a refaire, {len(stale)}/{len(snap)} fonction(s)')
    if not stale:
        return n_rep, n_rep, rep_errs
    # Place d'origine de chaque dogbone (comme pour les mortaises) : un corps
    # dont les dogbones precedaient sa copie les retrouve avant la copie,
    # qui en herite, au lieu d'en fin d'historique.
    jmap, snap_all = {}, None
    if placer is not None:
        try:
            snap_all = placer.snapshot()
            pos = dict((t, i) for i, t in enumerate(snap_all) if t)
            for a in design.findAttributes(D.ATTR_GROUP, 'body_name'):
                try:
                    i = pos.get(a.parent.entityToken)
                    k = (a.parent.parentComponent.id, a.value)
                    if i is not None and (k not in jmap or i < jmap[k]):
                        jmap[k] = i
                except Exception:
                    continue
        except Exception:
            _dbg('place d\'origine dogbones EXCEPTION: ' + traceback.format_exc())
            snap_all = None
    _t = time.time()
    D.remove_dogbones(design, keys=set((e['comp_id'], e['body_name']) for e in stale))
    _dbg(f'[temps] dogbones - suppression: {time.time() - _t:.1f}s')
    _t = time.time()
    if snap_all is None:
        n_ok, n_tot, errs = D.restore_dogbones(design, stale)
    else:
        # Une place par ancre (dernier element survivant qui precedait le
        # dogbone) : tous les dogbones de la meme zone sont refaits en un seul
        # appel. Ceux qui ne se creent pas a leur place (corners pas encore
        # coupes) sont refaits en fin d'historique, jamais perdus.
        alive = _timeline_tokens(placer.tl)

        def _anchor(j):
            if j is None:
                return None
            k = j - 1
            while k >= 0 and (snap_all[k] is None or snap_all[k] not in alive):
                k -= 1
            return snap_all[k] if k >= 0 else 'DEBUT'
        clusters = {}
        late = []   # coupes recreees apres la copie : leurs coins restants, en fin
        # Seuls les corps femelles de mortaise (ex. Corps1, qui recoit les
        # coupes puis est copie) sont replaces avant leur copie. Tous les autres
        # (males, origines et copies de reseau) sont refaits ensemble, en un
        # seul appel, en fin d'historique : DogboneCNC choisit lui-meme leur
        # place et reporte les coins de l'origine sur les copies, ce qui exige
        # l'origine dans le meme appel (sinon aucun coin, dogbones perdus).
        stale_own = [e for e in stale if female_keys and (e['comp_id'], e['body_name']) in female_keys]
        together = [e for e in stale if e not in stale_own]
        for e in stale_own:
            k = (e['comp_id'], e['body_name'])
            j = jmap.get(k)
            is_male = False
            # mortaise recreee avant la copie (deplacement remonte) : ses coins
            # existent avant la copie, les dogbones aussi ; sinon coins tardifs en fin.
            fcp = bool(force_keys and k in force_keys and j is not None
                       and k not in getattr(placer, 'reloc_late', ()))
            if force_keys and k in force_keys and not fcp:
                late.append(e)
            c = clusters.setdefault((_anchor(j), is_male, fcp), [j, [], is_male, fcp])
            if j is not None and (c[0] is None or j < c[0]):
                c[0] = j
            c[1].append(e)
        n_ok = n_tot = 0
        errs = []
        deferred = []
        at_end = []   # entrees refaites en fin d'historique (apres leurs copies)
        for anc, (j, ents, is_male, fcp) in sorted(clusters.items(), key=lambda kv: (kv[1][0] is None, kv[1][0] or 0)):
            try:
                # Dogbones d'un corps copie : avant la copie (elle en herite),
                # sauf un male de mortaise (outil), qui reste ou il etait.
                placer.go(snap_all, j, None,
                          None if is_male or j is None else [(e['comp_id'], e['body_name']) for e in ents],
                          False, fcp)
                comps = {c.id: c for c in design.allComponents}
                here = [e for e in ents if comps.get(e['comp_id']) is not None
                        and comps[e['comp_id']].bRepBodies.itemByName(e['body_name']) is not None]
                deferred += [e for e in ents if e not in here]   # corps pas encore cree a cette place
                if here:
                    if j is None:
                        at_end += here
                    a, b, c = D.restore_dogbones(design, here)
                    n_ok += a
                    n_tot += b
                    errs += [m for m in c if j is None or not str(m).startswith('Aucun coin')]
                    if j is not None and a < len(here):
                        have = set()
                        for at in design.findAttributes(D.ATTR_GROUP, 'body_name'):
                            try:
                                have.add((at.parent.parentComponent.id, at.value))
                            except Exception:
                                pass
                        miss = [e for e in here if (e['comp_id'], e['body_name']) not in have]
                        if miss:
                            _dbg(f'dogbones : {len(miss)} corps sans coin a leur place d\'origine, refaits en fin')
                            deferred += miss
            except Exception:
                errs.append(traceback.format_exc().strip().splitlines()[-1])
                _dbg('placement dogbones EXCEPTION: ' + traceback.format_exc())
            finally:
                placer.done()
        if deferred:
            placer.to_work_end()
            at_end += deferred
            a, b, c = D.restore_dogbones(design, deferred)
            n_ok += a
            n_tot += b
            errs += list(c)
        if together:
            placer.to_work_end()
            a, b, c = D.restore_dogbones(design, together)
            n_ok += a
            n_tot += b
            errs += list(c)
        # Corps refaits seuls au sein de leur famille : s'ils n'ont pas retrouve
        # leurs dogbones (coins non detectes sans l'origine), on refait la famille.
        try:
            part_roots = stale_roots - full_roots
            part_entries = [e for e in together
                            if entry_root.get('%s|%s' % (e['comp_id'], e['body_name'])) in part_roots]
            if part_entries:
                have = set()
                for at in design.findAttributes(D.ATTR_GROUP, 'body_name'):
                    try:
                        have.add((at.parent.parentComponent.id, at.value))
                    except Exception:
                        pass
                miss = [e for e in part_entries if (e['comp_id'], e['body_name']) not in have]
                if miss:
                    roots_m = set(entry_root.get('%s|%s' % (e['comp_id'], e['body_name'])) for e in miss)
                    redo = [e for e in snap if entry_root.get('%s|%s' % (e['comp_id'], e['body_name'])) in roots_m]
                    _dbg(f'dogbones : {len(miss)} corps sans dogbones apres refonte seule : famille refaite ({len(redo)} fonction(s))')
                    D.remove_dogbones(design, keys=set((e['comp_id'], e['body_name']) for e in redo if e not in miss))
                    placer.to_work_end()
                    a, b, c = D.restore_dogbones(design, redo)
                    n_ok += a
                    errs += list(c)
        except Exception:
            _dbg('dogbones repli famille EXCEPTION: ' + traceback.format_exc())
        if late:
            # Une mortaise recreee apres un deplacement (donc apres la copie)
            # a ses propres coins : dogbones en fin, pour ces coins seulement.
            try:
                placer.to_work_end()
                a, b, c = D.restore_dogbones(design, late)
                errs += [m for m in c if not str(m).startswith('Aucun coin')]
            except Exception:
                _dbg('dogbones coins tardifs EXCEPTION: ' + traceback.format_exc())
        # Un corps dont les dogbones passent apres ses copies (corps deplace,
        # coins pas encore coupes avant) ne les transmet plus : les copies sans
        # dogbone propre recoivent les leurs, aux memes reglages.
        try:
            if at_end:
                comps2 = {c.id: c for c in design.allComponents}
                own = set((e['comp_id'], e['body_name']) for e in snap)
                extra = []
                for e in at_end:
                    cc = comps2.get(e['comp_id'])
                    bb = cc.bRepBodies.itemByName(e['body_name']) if cc is not None else None
                    if bb is None:
                        continue
                    root_t = D._root_source(D._pattern_map(design)[0], D._body_token(bb))
                    for m in fams.get(root_t, []):
                        k = _body_key(m)
                        if k and k not in own and all(k != (x['comp_id'], x['body_name']) for x in extra):
                            extra.append({'comp_id': k[0], 'body_name': k[1], 'params': e.get('params'),
                                          'sig': None, 'sketch_ok': False})
                if extra:
                    placer.to_work_end()
                    a, b, c = D.restore_dogbones(design, extra)
                    _dbg(f'dogbones : {a}/{len(extra)} copie(s) de corps refait(s) en fin ont recu leurs dogbones')
                    n_ok += a
                    errs += [m for m in c if not str(m).startswith('Aucun coin')]
        except Exception:
            _dbg('dogbones copies EXCEPTION: ' + traceback.format_exc())
    _dbg(f'[temps] dogbones - recreation: {time.time() - _t:.1f}s')
    return n_ok + n_rep, n_tot + n_rep, list(errs) + rep_errs


def _write_dogsigs(design):
    """Etat des familles de dogbones a la fin de la mise a jour."""
    D = _find_module('DogboneCNC')
    if D is None or not hasattr(D, 'snapshot_dogbones') or not hasattr(D, '_pattern_map'):
        return 0
    try:
        snap = D.snapshot_dogbones(design, None)
        sigs = _fam_sigs(_dog_families(design, D, snap), D) if snap else {}
        design.attributes.add(_SIG_GROUP, _DOGSIG_ATTR, json.dumps(sigs))
        return len(sigs)
    except Exception:
        _dbg('empreintes dogbones EXCEPTION: ' + traceback.format_exc())
        return 0


def _get_tenon_module():
    """Tenon CNC est optionnel pour Mettre a jour CNC (contrairement a
    Mortaise/Marge) : si l'add-in n'est pas actif, on met simplement a jour
    les mortaises/jeux comme avant, sans bloquer ni avertir."""
    return _find_module('TenonCNC')


# --- Garde-fou Calpinage CNC (2026-10-10) ------------------------------------
# Calpinage CNC peut poser les vraies pieces a plat sur des panneaux (groupe
# d'historique "Calpinage CNC"). Cet outil travaille sur les pieces en
# position d'assemblage : on refuse tant que le calpinage est en place.
def _calpinage_en_place():
    try:
        design = adsk.fusion.Design.cast(adsk.core.Application.get().activeProduct)
        tl = design.timeline
        for i in range(tl.timelineGroups.count):
            n = tl.timelineGroups.item(i).name
            if n.startswith('Calpinage CNC') and 'copie' not in n:
                return True
    except Exception:
        pass
    return False


def _calpinage_refus(ui, titre):
    ui.messageBox("Les pieces sont posees a plat par Calpinage CNC.\n\n"
                  "Remets-les d'abord en assemblage : palette CNC Toolkit > "
                  "Calpinage CNC > Remettre en assemblage.", titre)


class ExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()

    def notify(self, args):
        if _calpinage_en_place():
            _calpinage_refus(_ui, COMMAND_NAME)
            return
        scope = None   # None = tout le document ; sinon cles (composant, nom) des corps choisis
        try:
            inputs = args.command.commandInputs
            tout = adsk.core.BoolValueCommandInput.cast(inputs.itemById(_ALL_ID))
            sel = adsk.core.SelectionCommandInput.cast(inputs.itemById(_SEL_ID))
            if tout is not None and not tout.value and sel is not None:
                scope = _scope_from_entities([sel.selection(i).entity for i in range(sel.selectionCount)])
        except Exception:
            _dbg('lecture selection EXCEPTION: ' + traceback.format_exc())
            scope = None
        if scope is not None and not scope:
            _ui.messageBox("Aucun corps selectionne.", COMMAND_NAME)
            return
        if os.path.exists(os.path.join(_ADDIN_DIR, 'maj_profile.flag')):
            # Mesure : un fichier maj_profile.flag a cote de l'add-in ecrit dans
            # le journal les fonctions les plus longues de cette mise a jour.
            import cProfile, pstats, io
            pr = cProfile.Profile()
            pr.enable()
            try:
                self.run_update(scope)
            finally:
                pr.disable()
                try:
                    for mode, n in (('tottime', 35), ('cumulative', 40)):
                        st = io.StringIO()
                        pstats.Stats(pr, stream=st).sort_stats(mode).print_stats(n)
                        _dbg(f'[profil {mode}]')
                        for ln in st.getvalue().splitlines():
                            if ln.strip():
                                _dbg('   ' + ln[:230].replace('C:/Users/.../AppData/Roaming/Autodesk/Autodesk Fusion 360/API/AddIns/ToolkitCNC/', '').replace('C:\\Users\\...\\AppData\\Roaming\\Autodesk\\Autodesk Fusion 360\\API\\AddIns\\ToolkitCNC\\', ''))
                except Exception:
                    _dbg('profil EXCEPTION: ' + traceback.format_exc())
            return
        self.run_update(scope)

    def run_update(self, scope):
        """Mise a jour proprement dite. scope : None (tout le document) ou
        ensemble de cles (id composant, nom de corps)."""
        placer = None
        hooks = None
        tl = None
        original_marker = None
        anchor_tok = None
        advanced = False
        barre = None   # barre de chargement (cnc_progress), fermee dans finally
        _t0 = time.time()
        _times = []
        _bbox_cache.clear()
        # Barre ouverte tout de suite (delai 0) : l'analyse du document et
        # l'avance de la chronologie figeaient Fusion plusieurs secondes sans
        # rien afficher (l'utilisateur, 2026-10-21).
        try:
            barre = cnc_progress.Barre(COMMAND_NAME, 'Analyse du document...', total=0, delai=0).ouvrir()
            adsk.doEvents()
        except Exception:
            barre = None

        def _lap(label, _last=[time.time()]):
            now = time.time()
            _times.append(f'{label} {now - _last[0]:.1f}s')
            _dbg(f'[temps] {label}: {now - _last[0]:.2f}s')
            _last[0] = now
        try:
            design = adsk.fusion.Design.cast(_app.activeProduct)
            if not design:
                if barre is not None:
                    barre.fin()
                _ui.messageBox("Aucun design actif.", COMMAND_NAME)
                return
            root = design.rootComponent

            MortaiseCNC, MargeCNC = _get_modules()
            if MortaiseCNC is None or MargeCNC is None:
                if barre is not None:
                    barre.fin()
                _ui.messageBox(
                    "Mortaise CNC et/ou Marge CNC ne sont pas actifs dans cette "
                    "session Fusion (a activer dans Utilitaires > Scripts et "
                    "complements).", COMMAND_NAME)
                return

            # --- 0. Avance temporairement la chronologie jusque juste avant
            # les features "Reorganiser" (imbrication/nesting CNC) ------------
            # design.findAttributes()/findEntityByToken() (utilises partout
            # ci-dessous, et par Mortaise/Marge/Tenon CNC eux-memes) ne
            # "voient" que ce qui est calcule JUSQU'AU marqueur de
            # chronologie courant. Si le marqueur est en retrait (usage
            # courant chez cet utilisateur - ex. pour visualiser le canape a
            # une etape intermediaire), tout ce qui a ete cree apres devient
            # invisible pour "Mettre a jour CNC" : mortaises/jeux/tenons
            # recents ignores silencieusement, "paire ignoree (corps
            # introuvable)", corps introuvables qui ne le sont pas vraiment,
            # etc. - exactement les symptomes rapportes.
            #
            # IMPORTANT - NE PAS avancer jusqu'a la toute fin (tl.count) :
            # constate en conditions reelles que ce document a des features
            # ArrangeFeature ("Reorganiser" - imbrication des pieces pour la
            # decoupe CNC) juste apres la position ou l'utilisateur laisse
            # habituellement le marqueur. Ces features dependent de la forme
            # finale de TOUS les corps et peuvent echouer a se recalculer
            # (constate : cascade d'erreurs "Invalid input points" / conges-
            # chanfreins casses / 0 mortaise-jeu recree au lieu de 27). On
            # avance donc seulement jusqu'a juste avant la PREMIERE
            # ArrangeFeature rencontree (ou jusqu'a la fin s'il n'y en a
            # aucune) : assez loin pour voir toutes les mortaises/jeux/tenons
            # CNC, jamais assez loin pour toucher a l'imbrication.
            #
            # On restaure la position d'origine du marqueur a la toute fin
            # (voir finally plus bas), que la mise a jour reussisse ou
            # echoue - en retrouvant la MEME feature (par entityToken, pas
            # par simple index) puisque des suppressions/creations de
            # features plus tot dans la chronologie peuvent decaler les
            # index.
            tl = design.timeline
            original_marker = tl.markerPosition
            safe_end = tl.count
            for i in range(tl.count):
                try:
                    if tl.item(i).entity.objectType == 'adsk::fusion::ArrangeFeature':
                        safe_end = i
                        break
                except Exception:
                    continue
            if original_marker < safe_end:
                try:
                    if original_marker > 0:
                        anchor_tok = tl.item(original_marker - 1).entity.entityToken
                except Exception:
                    anchor_tok = None
                    _dbg('lecture ancre chronologie EXCEPTION: ' + traceback.format_exc())
                _dbg(f'chronologie en retrait ({original_marker}/{tl.count}, limite sure={safe_end}) - avance temporairement')
                tl.markerPosition = safe_end
                advanced = True
            elif original_marker > safe_end:
                # Le marqueur est deja APRES la limite sure (l'utilisateur a
                # avance manuellement au-dela des ArrangeFeature) : on ne
                # recule pas de force, on laisse tel quel.
                _dbg(f'marqueur ({original_marker}) deja au-dela de la limite sure ({safe_end}) - inchange')

            _dbg('=== Mise a jour CNC : debut ===')
            _lap('preparation')

            # --- 1. Etat actuel : releve des jeux (Marge CNC) et des paires
            # mortaise (Mortaise CNC), AVANT toute suppression -----------------
            marge_runs = []
            try:
                attrs = design.findAttributes('MargeCNC', 'jeu_cm')
            except Exception:
                attrs = []
            for a in attrs:
                try:
                    feat = a.parent
                    # Jeu pose par Entaille CNC (MargeAuto) : il fait partie
                    # du lot d'entailles, qui le supprime et le recree lui-meme
                    # si un corps a bouge (etape 5). Le supprimer/reappliquer
                    # ici le sortait du lot : la recreation suivante du lot
                    # laissait alors ce jeu orphelin sur des faces disparues.
                    try:
                        if feat.attributes.itemByName('EntailleCNC', 'lot') is not None:
                            continue
                    except Exception:
                        pass
                    jeu = float(a.value)
                    sel_attr = None
                    try:
                        sel_attr = feat.attributes.itemByName('MargeCNC', 'selected_body_tokens')
                    except Exception:
                        pass
                    toks = [t for t in (sel_attr.value.split(',') if sel_attr and sel_attr.value else []) if t]
                    # exclure_fond : absent sur une feature creee avant l'ajout
                    # de cette option -> False (comportement d'origine).
                    fond_attr = None
                    try:
                        fond_attr = feat.attributes.itemByName('MargeCNC', 'exclure_fond')
                    except Exception:
                        pass
                    exclure_fond = bool(fond_attr and fond_attr.value == '1')
                    marge_runs.append((feat, jeu, toks, exclure_fond))
                except Exception:
                    _dbg('lecture attribut Marge CNC EXCEPTION: ' + traceback.format_exc())

            mortaise_feats = []
            try:
                mortaise_feats = MortaiseCNC.find_all_mortaise_features(design)
            except Exception:
                _dbg('find_all_mortaise_features EXCEPTION: ' + traceback.format_exc())

            # Une paire male/femelle = une recreation (plusieurs features
            # pour la meme paire etaient recreees autant de fois). Sans
            # selection : paire a refaire si un corps a bouge depuis la
            # derniere mise a jour, si une de ses features est en erreur, ou
            # sans empreinte. Avec selection : toute paire dont le male ou la
            # femelle est selectionne.
            pairs_by_key = {}
            n_drift = 0
            for feat, male_tok, female_tok in mortaise_feats:
                male = _resolve_tok(design, male_tok)
                female = _resolve_tok(design, female_tok)
                old = _read_sig(feat)
                if old:
                    male, d1 = _resolve_named(design, old.get('mk'), male)
                    female, d2 = _resolve_named(design, old.get('fk'), female)
                    n_drift += int(d1 or d2)
                if male is not None and female is not None:
                    pkey = (_body_key(male), _body_key(female))
                else:
                    pkey = (male_tok, female_tok)
                p = pairs_by_key.get(pkey)
                if p is None:
                    p = {'feats': [], 'male': male, 'female': female, 'dirty': False, 'cur': None}
                    if male is None or female is None:
                        # Sans selection, comme avant : supprimee, non recreee.
                        p['dirty'] = scope is None
                        _dbg(f'paire ignoree (corps introuvable) male={male_tok} female={female_tok}')
                    else:
                        try:
                            p['cur'] = {'male': _bbox_sig(male), 'female': _bbox_sig(female)}
                            p['mname'], p['fname'] = male.name, female.name
                            p['mtok'], p['ftok'] = male.entityToken, female.entityToken
                        except Exception:
                            p['dirty'] = scope is None
                    pairs_by_key[pkey] = p
                p['feats'].append(feat)
                if not p['dirty'] and p['cur'] is not None:
                    why = None
                    if scope is not None:
                        if _in_scope(scope, p['male']) or _in_scope(scope, p['female']):
                            why = 'corps selectionne'
                    elif old is None:
                        why = 'sans empreinte'
                    elif _feat_in_error(feat):
                        why = 'fonction en erreur'
                    elif _sig_moved(old.get('male'), p['cur']['male']):
                        why = 'male deplace'
                    elif _sig_moved(old.get('female'), p['cur']['female']):
                        why = 'femelle deplace'
                    if why:
                        p['dirty'] = True
                        _dbg(f'mortaise a refaire ({why}) : {p["mname"]} / {p["fname"]}')

            dirty_bodies = set()
            mortaise_pairs = []
            mortaise_del = []
            n_mortaise_kept = 0
            for p in pairs_by_key.values():
                if not p['dirty']:
                    n_mortaise_kept += 1
                    continue
                mortaise_del.extend(p['feats'])
                male, female = p['male'], p['female']
                if male is not None and female is not None:
                    dirty_bodies.add(_body_key(male))
                    dirty_bodies.add(_body_key(female))
                    mortaise_pairs.append(p)

            # Jeux : a refaire si une mortaise de l'un de leurs corps est
            # refaite (ses parois disparaissent), si un de leurs corps est
            # selectionne, ou si la feature est en erreur. Puis, de proche en
            # proche, tout jeu partageant un corps avec un jeu refait : un jeu
            # reapplique couvre TOUTES les mortaises du corps, il doublerait
            # sinon celui qu'on garderait.
            run_keys = []
            for feat, jeu, toks, _ef in marge_runs:
                keys = set()
                for t in toks:
                    b = _resolve_tok(design, t)
                    if b is not None:
                        keys.add(_body_key(b))
                run_keys.append(keys)
            # Jeu sans corps lisible (ancien MargeAuto) : on ne sait pas sur
            # quelle mortaise il porte, il suit donc l'ancien comportement
            # des qu'une mortaise est refaite.
            run_dirty = [_feat_in_error(r[0]) or bool(k & dirty_bodies)
                         or (scope is not None and bool(k & scope))
                         or (not k and bool(mortaise_del))
                         for r, k in zip(marge_runs, run_keys)]
            changed = True
            while changed:
                changed = False
                touched = set()
                for d, k in zip(run_dirty, run_keys):
                    if d:
                        touched |= k
                for i, k in enumerate(run_keys):
                    if not run_dirty[i] and k & touched:
                        run_dirty[i] = True
                        changed = True
            n_marge_kept = sum(1 for d in run_dirty if not d)
            marge_runs = [r for r, d in zip(marge_runs, run_dirty) if d]
            if n_drift:
                _dbg(f'jetons de corps derives (resolus par nom) : {n_drift}')
            _dbg(f'selectif ({"tout le document" if scope is None else str(len(scope)) + " corps selectionne(s)"}) : '
                 f'{len(mortaise_pairs)} paire(s) mortaise a refaire, {n_mortaise_kept} inchangee(s) ; '
                 f'{len(marge_runs)} jeu(x) a refaire, {n_marge_kept} inchange(s)')

            TenonCNC = _get_tenon_module()
            has_tenons = False
            if TenonCNC is not None:
                try:
                    has_tenons = len(design.findAttributes('TenonCNC', '')) > 0
                except Exception:
                    has_tenons = False
            EntailleCNC = _find_module('EntailleCNC')
            DogboneCNC = _find_module('DogboneCNC')
            recreate_entailles = (lambda d: _update_entailles(d, scope)) \
                if getattr(EntailleCNC, 'recreate_all_entailles', None) else None
            recreate_dogbones = (lambda d: _update_dogbones(d, scope, getattr(placer, 'reloc', None), placer,
                                                 set(k[1] for k in pairs_by_key if isinstance(k[1], tuple)),
                                                 set(_body_key(p['female']) for p in mortaise_pairs),
                                                 set(_body_key(p['male']) for p in mortaise_pairs)
                                                 - set(k[1] for k in pairs_by_key if isinstance(k[1], tuple)))) \
                if getattr(DogboneCNC, 'recreate_all_dogbones', None) else None

            if not mortaise_feats and not marge_runs and not has_tenons \
                    and recreate_entailles is None and recreate_dogbones is None:
                if barre is not None:
                    barre.fin()
                _ui.messageBox(
                    "Rien a mettre a jour : aucun tenon, mortaise ou jeu cree par "
                    "CNC Toolkit n'a ete trouve dans ce design.",
                    COMMAND_NAME)
                return

            start_index = tl.markerPosition
            if barre is None:
                barre = cnc_progress.Barre(COMMAND_NAME, '').ouvrir()
            barre.etape('Suppression des anciennes coupes...', 0,
                        4 + len(mortaise_pairs) + len(marge_runs))

            # Ordre actuel des fonctions : sert a recreer chaque element a sa
            # place d'origine (voir _Placer).
            placer = _Placer(design)
            placer.hoist_keys = dirty_bodies   # un Deplacer commun a plusieurs males refaits peut etre remonte
            snap_all = placer.snapshot()
            tok_idx = {}
            for _i, _t in enumerate(snap_all):
                if _t:
                    tok_idx.setdefault(_t, _i)

            def _first_idx(feats):
                idx = [tok_idx.get(f.entityToken) for f in feats]
                idx = [i for i in idx if i is not None]
                return min(idx) if idx else None
            for p in mortaise_pairs:
                p['j'] = _first_idx(p['feats'])
            marge_j = [_first_idx([r[0]]) for r in marge_runs]
            hooks = _Hooks(placer)

            # --- 2. Suppression : Marge CNC d'abord (depend des parois de
            # cavite creees par Mortaise CNC), puis Mortaise CNC ---------------
            n_del_marge = 0
            n_del_mortaise = 0
            _batch = getattr(DogboneCNC, '_delete_features_batch', None)
            _feats_del = [r[0] for r in marge_runs] + list(mortaise_del)
            if _batch is not None and len(_feats_del) > 1:
                # Un seul recalcul pour toutes les suppressions (chaque deleteMe
                # recalcule sinon toute la suite : 0,2 s par fonction sur FS210 V1).
                try:
                    _batch(design, _feats_del)
                    n_del_marge, n_del_mortaise = len(marge_runs), len(mortaise_del)
                except Exception:
                    _dbg('suppression groupee EXCEPTION: ' + traceback.format_exc())
                placer.to_work_end()
            else:
                for feat, jeu, toks, _exclure_fond in marge_runs:
                    try:
                        feat.deleteMe()
                        n_del_marge += 1
                    except Exception:
                        _dbg('suppression feature Marge CNC EXCEPTION: ' + traceback.format_exc())
                for feat in mortaise_del:
                    try:
                        feat.deleteMe()
                        n_del_mortaise += 1
                    except Exception:
                        _dbg('suppression feature Mortaise CNC EXCEPTION: ' + traceback.format_exc())

            _dbg(f'supprime : {n_del_marge} feature(s) Marge CNC, {n_del_mortaise} feature(s) Mortaise CNC')
            _lap('suppression jeux/mortaises')

            # --- 3. Tenons CNC AVANT les mortaises (2026-10-06) : une
            # mortaise est creusee a partir du corps male TEL QU'IL EST, tenon
            # compris. Recreer les mortaises d'abord les creusait a l'ancienne
            # position du tenon quand le corps avait ete deplace (Deplacer
            # insere plus tot dans la chronologie). Les tenons sont des
            # bossages figes (BaseFeature + Combiner) qui ne suivent pas le
            # corps tout seuls : TenonCNC.recreate_all_tenons les supprime et
            # les recree sur le chant retrouve par sa marque d'attribut.
            # (Un essai plus ancien de cet ordre n'avait rien change sur
            # F(5)/F(7) : ce blocage-la vient de mortaises orphelines non
            # taguees, pas de l'ordre.)
            barre.etape('Tenons...', 1)
            n_tenons_ok = n_tenons_total = n_tenons_sans_spec = 0
            tenon_errors = []
            if TenonCNC is not None:
                try:
                    if hasattr(TenonCNC, 'set_place_hooks'):
                        TenonCNC.set_place_hooks(hooks)
                    if scope is None:
                        n_tenons_ok, n_tenons_total, n_tenons_sans_spec, tenon_errors = \
                            TenonCNC.recreate_all_tenons(design)
                    elif 'only_body_keys' in TenonCNC.recreate_all_tenons.__code__.co_varnames[
                            :TenonCNC.recreate_all_tenons.__code__.co_argcount]:
                        n_tenons_ok, n_tenons_total, n_tenons_sans_spec, tenon_errors = \
                            TenonCNC.recreate_all_tenons(design, only_body_keys=scope)
                    else:
                        tenon_errors.append('Tenons non mis a jour : rechargez Tenons CNC (version trop ancienne).')
                except Exception:
                    tenon_errors.append(traceback.format_exc().strip().splitlines()[-1])
                    _dbg('recreation tenons EXCEPTION: ' + traceback.format_exc())
                finally:
                    try:
                        if hasattr(TenonCNC, 'set_place_hooks'):
                            TenonCNC.set_place_hooks(None)
                    except Exception:
                        pass
                    placer.to_work_end()

            _lap('tenons')

            # --- 4. Recreation : Mortaise CNC (position actuelle des corps),
            # puis Marge CNC (jeu reapplique sur les nouvelles parois) ---------
            nb_ok_total = 0
            nb_skipped_total = 0
            mortaise_errors = []
            barre.etape('Mortaises...', 2)
            for p in mortaise_pairs:
                barre.avance()
                male_name, female_name = p['mname'], p['fname']
                try:
                    _m0 = _fresh_body(design, p['mtok'], male_name)
                    _f0 = _fresh_body(design, p['ftok'], female_name)
                    _pk = [_body_key(b) for b in (_m0, _f0) if b is not None]
                    _fk = [_body_key(_f0)] if _f0 is not None else None
                    try:
                        placer.go(snap_all, p.get('j'), _pk, _fk)
                        # le male doit exister a la place choisie (copie plus
                        # tot que lui : on retombe sur la place d'origine)
                        if _fk and placer.cur and isinstance(placer.cur[0], tuple) and placer.cur[0][0] == 'CP' and \
                                (_fresh_body(design, p['mtok'], male_name) is None or _fresh_body(design, p['ftok'], female_name) is None):
                            placer.cur = None
                            placer.to_work_end()
                            placer.go(snap_all, p.get('j'), _pk, None)
                    except Exception:
                        _dbg('placement mortaise EXCEPTION (recree en fin) : ' + traceback.format_exc())
                        placer.to_work_end()
                    male = _fresh_body(design, p['mtok'], male_name)
                    female = _fresh_body(design, p['ftok'], female_name)
                    if male is None or female is None:
                        nb_skipped_total += 1
                        _dbg(f'paire ignoree apres tenons (corps introuvable) {male_name} / {female_name}')
                        continue
                    nb_ok, nb_skipped, errors, _new_records = MortaiseCNC.creer_mortaises([male], [female], root)
                    nb_ok_total += nb_ok
                    nb_skipped_total += nb_skipped
                    mortaise_errors.extend(errors)
                except Exception:
                    mortaise_errors.append(traceback.format_exc().strip().splitlines()[-1])
                    _dbg('recreation mortaise EXCEPTION: ' + traceback.format_exc())
                finally:
                    placer.done()

            _lap('mortaises')
            n_marge_reappliques = 0
            marge_errors = []
            barre.etape('Jeux de fonctionnement...')
            for _mi, (_feat_old, jeu, toks, exclure_fond) in enumerate(marge_runs):
                barre.avance()
                try:
                    try:
                        _jk = [_body_key(b) for b in (_resolve_tok(design, t) for t in toks) if b is not None]
                        placer.go(snap_all, marge_j[_mi], _jk, _jk, True)
                        if placer.cur and isinstance(placer.cur[0], tuple) and placer.cur[0][0] == 'CP' and \
                                any(_resolve_tok(design, t) is None for t in toks):
                            placer.cur = None
                            placer.to_work_end()
                            placer.go(snap_all, marge_j[_mi], _jk, None, True)
                    except Exception:
                        _dbg('placement jeu EXCEPTION (recree en fin) : ' + traceback.format_exc())
                        placer.to_work_end()
                    selected_bodies = []
                    female_tokens_filter = set()
                    for t in toks:
                        found = design.findEntityByToken(t)
                        body = adsk.fusion.BRepBody.cast(found[0]) if found else None
                        if body:
                            selected_bodies.append(body)
                            female_tokens_filter.add(t)
                    # skip_heuristique=True (ajoute le 2026-10-04, meme
                    # correctif que Modif Marge dans MargeCNC.py) : ce rejeu
                    # porte sur des face_tokens DEJA enregistres avec
                    # precision, la detection heuristique de secours
                    # (_chant_faces_heuristique) ne doit pas s'y ajouter -
                    # voir la docstring d'apply_jeu pour le detail du bug
                    # qu'elle cause sinon sur les entailles (face de fond
                    # rajoutee a tort).
                    feat, n_m, n_h, faces = MargeCNC.apply_jeu(
                        design, root, female_tokens_filter, selected_bodies, jeu, True, exclure_fond,
                        skip_heuristique=True)
                    if feat:
                        n_marge_reappliques += 1
                except Exception:
                    marge_errors.append(traceback.format_exc().strip().splitlines()[-1])
                    _dbg('reapplication marge EXCEPTION: ' + traceback.format_exc())
                finally:
                    placer.done()

            # --- 5. Entailles puis dogbones (add-ins optionnels, fonctions
            # fournies par EntailleCNC / DogboneCNC ; ordre convenu entre
            # les add-ins : tenons -> mortaises -> jeux -> entailles ->
            # dogbones, les dogbones dependant des coupes precedentes).
            _lap('jeux')
            extra_lines = []
            extra_errors = []
            for _label, _fn in (('entaille(s)', recreate_entailles),
                                ('dogbone(s)', recreate_dogbones)):
                if _fn is None:
                    continue
                barre.avance(message='Recreation des %s...' % _label)
                try:
                    if _label.startswith('entaille') and hasattr(EntailleCNC, 'set_place_hooks'):
                        EntailleCNC.set_place_hooks(hooks)
                    with cnc_progress.Barre(COMMAND_NAME, 'Recreation des %s...' % _label):
                        _n_ok, _n_tot, _errs = _fn(design)
                    _lap(_label)
                    if _n_tot:
                        extra_lines.append(f'{_n_ok}/{_n_tot} {_label} recree(s).')
                    extra_errors.extend(list(_errs or []))
                except Exception:
                    extra_errors.append(f'{_label} : ' + traceback.format_exc().strip().splitlines()[-1])
                    _dbg(f'recreation {_label} EXCEPTION: ' + traceback.format_exc())
                finally:
                    try:
                        if _label.startswith('entaille') and hasattr(EntailleCNC, 'set_place_hooks'):
                            EntailleCNC.set_place_hooks(None)
                    except Exception:
                        pass
                    placer.to_work_end()

            _dbg(f'placement : {placer.n_placed} element(s) recree(s) a leur place d\'origine, {placer.n_groups} groupe(s)')
            _bbox_cache.clear()   # les corps ont change pendant la mise a jour
            _dbg(f'empreintes mortaises enregistrees : {_write_mortaise_sigs(design, MortaiseCNC)}')
            _dbg(f'empreintes dogbones enregistrees : {_write_dogsigs(design)}')

            _dbg(f'[temps] TOTAL {time.time() - _t0:.1f}s : ' + ', '.join(_times))

            msg = ('Tout le document.\n' if scope is None else f'{len(scope)} corps selectionne(s).\n')
            msg += (f'{nb_ok_total} mortaise(s) recreee(s), '
                    f'{n_marge_reappliques} jeu(x) reapplique(s).')
            if n_mortaise_kept or n_marge_kept:
                msg += (f'\n{n_mortaise_kept} mortaise(s) et {n_marge_kept} jeu(x) laisse(s) '
                        'tels quels' + (' (corps non selectionnes).' if scope is not None else ' (corps non deplaces).'))
            if nb_skipped_total:
                msg += f'\n{nb_skipped_total} paire(s) ignoree(s) (corps disjoints ou introuvables).'
            if TenonCNC is not None and n_tenons_total:
                msg += f'\n{n_tenons_ok}/{n_tenons_total} tenon(s)/languette(s) repositionne(s).'
            if n_tenons_sans_spec:
                msg += (f'\n{n_tenons_sans_spec} tenon(s)/languette(s) crees avant le suivi des '
                        'parametres, non repositionnes (utilisez "Reparer anciens Tenons" '
                        'dans Tenons CNC une fois, puis relancez Mettre a jour CNC).')
            if extra_lines:
                msg += '\n' + '\n'.join(extra_lines)
            errs = mortaise_errors + marge_errors + tenon_errors + extra_errors
            if errs:
                msg += '\n\nErreurs :\n' + '\n'.join(errs[:10])
            msg += f'\n\nDuree : {time.time() - _t0:.0f} s'
            barre.fin()
            _ui.messageBox(msg, COMMAND_NAME)
            _dbg(f'=== Mise a jour CNC : fin - {msg} ===')
        except Exception:
            if barre is not None:
                barre.fin()
            _ui.messageBox('Erreur Mise a jour CNC:\n' + traceback.format_exc())
            _dbg('EXCEPTION top-level: ' + traceback.format_exc())
        finally:
            if barre is not None:
                barre.fin()
            for _m in (_get_tenon_module(), _find_module('EntailleCNC')):
                try:
                    if _m is not None and hasattr(_m, 'set_place_hooks'):
                        _m.set_place_hooks(None)
                except Exception:
                    pass
            if placer is not None:
                placer.to_work_end()
            # Restaure la position d'origine du marqueur de chronologie (voir
            # etape 0 ci-dessus), succes ou echec. Retrouve la MEME feature
            # par entityToken plutot que par index brut : des suppressions
            # de features situees avant l'ancienne position du marqueur
            # (rare, mais possible si une vieille mortaise/jeu y vivait)
            # decaleraient sinon le marqueur restaure sur la mauvaise
            # feature.
            try:
                # Seulement si on a nous-memes avance le marqueur (il etait en
                # retrait) : s'il etait deja a la fin, il doit y rester, APRES
                # les features que la mise a jour vient d'ajouter (avant, on le
                # remettait a son ancien index, donc en plein milieu).
                if advanced and tl is not None and original_marker is not None and tl.markerPosition != original_marker:
                    new_pos = original_marker
                    if anchor_tok is not None:
                        found_anchor = False
                        for i in range(tl.count):
                            try:
                                if tl.item(i).entity.entityToken == anchor_tok:
                                    new_pos = i + 1
                                    found_anchor = True
                                    break
                            except Exception:
                                continue
                        if not found_anchor:
                            new_pos = min(original_marker, tl.count)
                            _dbg('ancre chronologie introuvable apres mise a jour - restauration par index brut (approximatif)')
                    else:
                        new_pos = min(original_marker, tl.count)
                    tl.markerPosition = new_pos
                    _dbg(f'chronologie restauree a la position {new_pos} (origine {original_marker})')
            except Exception:
                _dbg('restauration position chronologie EXCEPTION: ' + traceback.format_exc())


class ValidateHandler(adsk.core.ValidateInputsEventHandler):
    def __init__(self): super().__init__()

    def notify(self, args):
        try:
            inputs = args.inputs
            sel = adsk.core.SelectionCommandInput.cast(inputs.itemById(_SEL_ID))
            tout = adsk.core.BoolValueCommandInput.cast(inputs.itemById(_ALL_ID))
            args.areInputsValid = bool(tout.value or sel.selectionCount > 0)
        except Exception:
            args.areInputsValid = True


class CreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self): super().__init__()

    def notify(self, args):
        try:
            cmd = args.command
            cmd.isRepeatable = False
            cmd.okButtonText = 'Mettre a jour'
            # Corps deja selectionnes dans Fusion : repris dans la boite.
            pre = []
            try:
                acts = _ui.activeSelections
                for i in range(acts.count):
                    pre.append(acts.item(i).entity)
            except Exception:
                pre = []
            inputs = cmd.commandInputs
            sel = inputs.addSelectionInput(
                _SEL_ID, 'Corps a mettre a jour',
                'Selectionnez les corps (ou composants) a mettre a jour : seuls leurs tenons, '
                'mortaises, jeux, entailles et dogbones seront recalcules.')
            sel.addSelectionFilter(adsk.core.SelectionCommandInput.Bodies)
            sel.addSelectionFilter(adsk.core.SelectionCommandInput.Occurrences)
            sel.setSelectionLimits(0)
            for ent in pre:
                try:
                    if adsk.fusion.BRepBody.cast(ent) is not None or adsk.fusion.Occurrence.cast(ent) is not None:
                        sel.addSelection(ent)
                except Exception:
                    pass
            inputs.addBoolValueInput(_ALL_ID, 'Tout le document (ignore la selection)', True, '', False)
            on_ex = ExecuteHandler()
            cmd.execute.add(on_ex)
            _handlers.append(on_ex)
            on_val = ValidateHandler()
            cmd.validateInputs.add(on_val)
            _handlers.append(on_val)
        except Exception:
            _ui.messageBox(traceback.format_exc())


def run(context):
    global _app, _ui
    try:
        _app = adsk.core.Application.get()
        _ui = _app.userInterface

        for pid in PANEL_IDS:
            panel = _ui.allToolbarPanels.itemById(pid)
            if panel is None:
                continue
            c = panel.controls.itemById(CMD_ID)
            if c:
                c.deleteMe()
        old = _ui.commandDefinitions.itemById(CMD_ID)
        if old:
            old.deleteMe()

        cmd_def = _ui.commandDefinitions.addButtonDefinition(
            CMD_ID, COMMAND_NAME, COMMAND_DESC, '')
        on_created = CreatedHandler()
        cmd_def.commandCreated.add(on_created)
        _handlers.append(on_created)

        # Bouton de ruban RETIRE : devenu inutile depuis la creation de
        # CNC Toolkit, qui retrouve et execute cette CommandDefinition
        # directement depuis sa palette.
    except Exception:
        if _ui:
            _ui.messageBox('Erreur run Mise a jour CNC:\n' + traceback.format_exc())


def stop(context):
    try:
        for pid in PANEL_IDS:
            panel = _ui.allToolbarPanels.itemById(pid)
            if panel is None:
                continue
            ctrl = panel.controls.itemById(CMD_ID)
            if ctrl:
                ctrl.deleteMe()
        cd = _ui.commandDefinitions.itemById(CMD_ID)
        if cd:
            cd.deleteMe()
        _handlers.clear()
    except Exception:
        pass
