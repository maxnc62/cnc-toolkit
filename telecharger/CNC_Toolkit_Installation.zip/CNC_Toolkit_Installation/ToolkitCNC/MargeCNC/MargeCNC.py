import adsk.core
import adsk.fusion
import traceback
import os
import json
import sys
import time

# Barre de chargement commune du Toolkit (ToolkitCNC/cnc_progress.py)
_TK_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _TK_DIR not in sys.path:
    sys.path.append(_TK_DIR)
import cnc_progress

_app = None
_ui = None
_cmd_def = None
_panel_ctrl = None
_created_handler = None
_execute_handler = None
_changed_handler = None
_validate_handler = None
_select_evt_handler = None
_pending_faces = []

CMD_ID       = 'MargeCNCCmd'
EVT_ID       = 'MargeCNC_SelEvt'
COMMAND_NAME = 'Marge CNC'
COMMAND_DESC = ("Applique un jeu de fonctionnement sur les mortaises "
                "creees par Mortaise CNC (sans re-detection geometrique)")
PANEL_IDS    = ['SolidModifyPanel', 'SolidCreatePanel', 'SketchCreatePanel', 'ToolsPanel']

# --- Modif Marge : deuxieme commande de cet add-in (voir plus bas) --------
# Met a jour en 1 clic le jeu de TOUTES les marges deja creees dans le
# projet (manuelles ou via MargeAuto depuis Tenons CNC), sans avoir a
# relancer Marge CNC corps par corps.
_cmd_def2       = None
_panel_ctrl2    = None
_created_handler2 = None
_execute_handler2 = None

CMD_ID2       = 'ModifMargeCmd'
COMMAND_NAME2 = 'Modif Marge'
COMMAND_DESC2 = ("Modifie en 1 clic la taille (le jeu) de toutes les marges "
                 "deja creees dans ce projet, manuelles ou automatiques")

_ADDIN_DIR   = os.path.dirname(os.path.abspath(__file__))
_ADDINS_ROOT = os.path.dirname(_ADDIN_DIR)
# Fichier ecrit par Mortaise CNC : liste des parois de mortaise reellement
# creees (male_token / female_token / face_tokens). Marge CNC s'appuie
# UNIQUEMENT dessus - aucune detection geometrique de type "chant interieur"
# (taille/nombre de faces en contact) n'est necessaire, puisqu'on sait deja
# exactement ou sont les mortaises.
MORTAISE_FACE_MAP_FILE = os.path.join(_ADDINS_ROOT, 'MortaiseCNC', 'mortaise_face_map.json')
SETTINGS_FILE = os.path.join(_ADDIN_DIR, 'marge_settings.json')
DEBUG_LOG     = os.path.join(_ADDIN_DIR, 'marge_debug.log')


def _dbg(msg):
    try:
        with open(DEBUG_LOG, 'a', encoding='utf-8') as f:
            f.write(time.strftime('%H:%M:%S') + ' ' + str(msg) + '\n')
    except:
        pass


def load_settings():
    try:
        if os.path.exists(SETTINGS_FILE):
            with open(SETTINGS_FILE, 'r', encoding='utf-8') as f:
                d = json.load(f)
            return (float(d.get('jeu_cm', 0.02)), bool(d.get('jeu_actif', False)),
                    bool(d.get('exclure_fond', False)))
    except:
        pass
    return 0.02, False, False


def save_settings(jeu_cm, jeu_actif, exclure_fond):
    try:
        with open(SETTINGS_FILE, 'w', encoding='utf-8') as f:
            json.dump({'jeu_cm': jeu_cm, 'jeu_actif': jeu_actif, 'exclure_fond': exclure_fond}, f)
    except:
        pass


def _load_mortaise_records():
    try:
        with open(MORTAISE_FACE_MAP_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return []


def _dogbone_module():
    """Module DogboneCNC charge (apres un redemarrage de Fusion il vit sous
    une cle '__main__...DogboneCNC_py' et non 'DogboneCNC')."""
    import sys
    for k, m in list(sys.modules.items()):
        if (k == 'DogboneCNC' or k.endswith('DogboneCNC%2FDogboneCNC_py')) \
                and hasattr(m, 'snapshot_dogbones'):
            return m
    return None


def _dogbones_retirer(design):
    """Dogbones = coupes statiques : on les retire AVANT de decaler les
    parois, puis _dogbones_recreer les refait sur la nouvelle geometrie."""
    dog = _dogbone_module()
    if dog is None:
        return None, []
    try:
        snap = dog.snapshot_dogbones(design)
        if snap:
            dog.remove_dogbones(design)
        return dog, snap
    except Exception:
        _dbg('retrait dogbones EXCEPTION: ' + traceback.format_exc())
        return None, []


def _dogbones_recreer(design, dog, snap, errors):
    if dog is None or not snap:
        return
    try:
        _n_ok, _n_tot, errs = dog.restore_dogbones(design, snap)
        errors.extend(['Dogbone : ' + str(e) for e in (errs or [])])
    except Exception:
        errors.append('Dogbone : ' + traceback.format_exc().strip().splitlines()[-1])
        _dbg('recreation dogbones EXCEPTION: ' + traceback.format_exc())


def _save_mortaise_records(records):
    try:
        with open(MORTAISE_FACE_MAP_FILE, 'w', encoding='utf-8') as f:
            json.dump(records, f, indent=2)
    except Exception:
        pass


def _native_token(obj):
    """Normalise l'entityToken sur l'objet NATIVE (voir MortaiseCNC.py -
    meme raison : un objet obtenu par selection dans un contexte
    d'assemblage peut etre un PROXY dont l'entityToken differe de celui du
    meme objet natif obtenu en parcourant directement les features)."""
    try:
        native = obj.nativeObject
        if native is not None:
            obj = native
    except Exception:
        pass
    try:
        return obj.entityToken
    except Exception:
        return None


def _tenon_feature_face_tokens(body):
    """Tokens des faces du corps donne qui appartiennent a une feature
    nommee 'Tenon'/'Tenon (n)' (creee par Tenons CNC, en Join). Sert a les
    EXCLURE de _chant_faces_heuristique : sans ca, les parois laterales
    d'un tenon en bordure de corps (petites faces planes, non sur le bord
    de la bounding box globale) sont geometriquement indiscernables d'une
    vraie paroi d'entaille/mortaise pour cette heuristique, et se voient
    appliquer un jeu de fonctionnement a tort (alors qu'un tenon est de la
    matiere AJOUTEE, pas une cavite)."""
    toks = set()
    try:
        comp = body.parentComponent
        body_tok = _native_token(body)
        for feat in comp.features:
            try:
                if feat.name != 'Tenon' and not feat.name.startswith('Tenon ('):
                    continue
            except Exception:
                continue
            try:
                for f in feat.faces:
                    try:
                        if _native_token(f.body) == body_tok:
                            toks.add(f.entityToken)
                    except Exception:
                        pass
            except Exception:
                pass
    except Exception:
        pass
    return toks


def _get_normal(face):
    """Normale au centre parametrique de la face (fiable meme si
    face.geometry.normal n'est pas dans le meme sens que la normale
    reelle du B-Rep)."""
    try:
        ev = face.evaluator
        pr = ev.parametricRange()
        cu = (pr.minPoint.x + pr.maxPoint.x) / 2
        cv = (pr.minPoint.y + pr.maxPoint.y) / 2
        ok, n = ev.getNormalAtParameter(adsk.core.Point2D.create(cu, cv))
        return n if ok else None
    except Exception:
        return None


def _coplanar(face_a, face_b, na, tol_dot=0.001, tol_dist=0.05):
    """Vrai si face_a et face_b appartiennent au meme plan infini (memes
    normale et meme distance a l'origine, a tolerance pres - 0.05cm =
    0.5mm, assez large pour tolerer un leger decalage numerique residuel,
    par ex. si un jeu de fonctionnement a deja ete applique par erreur
    sur l'un des deux fragments avant ce correctif). Sert a regrouper les
    fragments d'une meme face reelle du corps (voir
    _chant_faces_heuristique)."""
    try:
        pa = adsk.core.Plane.cast(face_a.geometry)
        pb = adsk.core.Plane.cast(face_b.geometry)
    except Exception:
        return False
    if pa is None or pb is None:
        return False
    try:
        dot = pa.normal.dotProduct(pb.normal)
        if abs(abs(dot) - 1.0) > tol_dot:
            return False
        vec = pa.origin.vectorTo(pb.origin)
        return abs(vec.dotProduct(na)) <= tol_dist
    except Exception:
        return False


def _true_thickness(body, fallback, tol_dot=0.05):
    """Determine la normale et la valeur de l'epaisseur REELLE d'un corps-
    panneau a partir de ses deux plus grandes faces planes (normales
    opposees), plutot que des dimensions de sa bounding box - necessaire
    pour un corps dont les faces principales ne sont pas alignees avec
    les axes globaux (panneau incline/biseaute) : dans ce cas, la
    dimension de la bounding box dans l'axe le plus etroit peut largement
    SURESTIMER l'epaisseur reelle (jusqu'a plusieurs fois trop grande),
    ce qui gonfle a tort le seuil de taille utilise pour distinguer une
    petite paroi de chant d'une grande face de reference - laissant alors
    passer des fragments de bord exterieur bien plus grands que ce que ce
    seuil est censer tolerer.

    Retombe sur (None, fallback) si le corps n'a pas clairement deux
    grandes faces planes opposees (ex. moins de 2 faces planes, ou les
    deux plus grandes ne sont pas paralleles) - le code appelant utilise
    alors l'ancienne methode (axe de bounding box)."""
    try:
        planar = [f for f in body.faces if isinstance(f.geometry, adsk.core.Plane)]
    except Exception:
        return None, fallback
    if len(planar) < 2:
        return None, fallback
    try:
        planar.sort(key=lambda f: -f.area)
    except Exception:
        return None, fallback
    f1, f2 = planar[0], planar[1]
    try:
        p1 = adsk.core.Plane.cast(f1.geometry)
        p2 = adsk.core.Plane.cast(f2.geometry)
        if p1 is None or p2 is None:
            return None, fallback
        dot = p1.normal.dotProduct(p2.normal)
        if abs(abs(dot) - 1.0) > tol_dot:
            return None, fallback
        vec = p1.origin.vectorTo(p2.origin)
        dist = abs(vec.dotProduct(p1.normal))
        if dist <= 1e-4:
            return None, fallback
        return p1.normal, dist
    except Exception:
        return None, fallback


def _chant_faces_heuristique(body):
    """Detecte par heuristique les faces de "chant interieur" d'un corps -
    utilise en repli pour les entailles/rainures decoupees a la main dans
    Fusion (sans passer par Tenons CNC / Mortaise CNC, donc sans entree
    dans mortaise_face_map.json).

    Reprise de la meme heuristique que l'ancien add-in "Jeu de
    Fonctionnement" : parmi les faces planes du corps, on garde celles qui
    ne sont pas sur le bord de la bounding box (donc interieures - une
    paroi de cavite, pas une face exterieure du panneau) et qui restent
    petites (aire <= 4x l'epaisseur au carre) - ca cible les petites
    parois d'entaille sans jamais toucher les grandes faces de reference
    du panneau. L'epaisseur est calculee via _true_thickness (distance
    entre les deux plus grandes faces planes) plutot que depuis la
    bounding box, pour rester correcte meme sur un panneau incline (voir
    _true_thickness) - avec repli sur la plus petite dimension de la
    bounding box si cette methode ne s'applique pas.

    Corps de forme NON rectangulaire (bord exterieur qui n'est pas flush
    avec la bounding box globale, ex. bord biseaute/en escalier) : ce
    bord, meme s'il n'est pas "bord" au sens bounding box, reste une face
    EXTERIEURE du panneau - mais une entaille voisine peut le decouper en
    plusieurs morceaux, dont certains assez petits pour passer le filtre
    d'aire tout seuls. Pour eviter de les confondre avec une vraie paroi
    de chant, une face n'est retenue que si aucune autre face plane du
    MEME corps, coplanaire avec elle (meme plan infini), n'est elle-meme
    un bord ou une grande face : dans ce cas, elle est juste un fragment
    de ce meme bord exterieur, pas une paroi de cavite independante."""
    TOL = 0.001
    try:
        bb = body.boundingBox
        mn, mx = bb.minPoint, bb.maxPoint
    except Exception:
        return []
    sx, sy, sz = mx.x - mn.x, mx.y - mn.y, mx.z - mn.z
    th = min(("x", sx), ("y", sy), ("z", sz), key=lambda t: t[1])[0]
    ep_bbox = min(sx, sy, sz)
    main_normal, ep = _true_thickness(body, ep_bbox)
    aire_max = ep * ep * 4.0
    tenon_toks = _tenon_feature_face_tokens(body)

    # --- 1ere passe : releve de toutes les faces planes candidates (hors
    # epaisseur/tenon) avec leur statut "bord" (flush avec la bounding
    # box globale) - necessaire pour le regroupement en 2e passe. ---
    candidates = []
    try:
        for face in body.faces:
            if not isinstance(face.geometry, adsk.core.Plane):
                continue
            try:
                if face.entityToken in tenon_toks:
                    continue
            except Exception:
                pass
            n = _get_normal(face)
            if n is None:
                continue
            if main_normal is not None:
                try:
                    if abs(n.dotProduct(main_normal)) > 0.99:
                        continue
                except Exception:
                    if abs(getattr(n, th)) > 0.99:
                        continue
            elif abs(getattr(n, th)) > 0.99:
                continue
            try:
                fb = face.boundingBox
                fm, fx = fb.minPoint, fb.maxPoint
            except Exception:
                continue
            bord = False
            if abs(n.y) > 0.99:
                if n.y > 0 and abs(fx.y - mx.y) < TOL:
                    bord = True
                if n.y < 0 and abs(fm.y - mn.y) < TOL:
                    bord = True
            if abs(n.z) > 0.99:
                if n.z > 0 and abs(fx.z - mx.z) < TOL:
                    bord = True
                if n.z < 0 and abs(fm.z - mn.z) < TOL:
                    bord = True
            if th != "x" and abs(n.x) > 0.99:
                if n.x > 0 and abs(fx.x - mx.x) < TOL:
                    bord = True
                if n.x < 0 and abs(fm.x - mn.x) < TOL:
                    bord = True
            candidates.append((face, n, bord))
    except Exception:
        pass

    # --- 2e passe : exclut les fragments d'un bord exterieur non
    # rectangulaire (voir docstring). ---
    kept = []
    for face, n, bord in candidates:
        if bord or face.area > aire_max:
            continue
        fragment_of_exterior = False
        for other_face, _other_n, other_bord in candidates:
            if other_face is face:
                continue
            if not (other_bord or other_face.area > aire_max):
                continue
            if _coplanar(face, other_face, n):
                fragment_of_exterior = True
                break
        if fragment_of_exterior:
            continue
        kept.append(face)
    return kept


def _group_faces_by_shared_edges(items):
    """items : liste de (cle, face). Regroupe par COMPOSANTE CONNEXE selon
    les aretes partagees (meme entityToken d'arete) - deux parois qui
    partagent une arete appartiennent a la meme cavite (parois adjacentes
    d'un meme creux). Retourne une liste de groupes, chaque groupe etant
    une liste d'INDICES dans `items`.

    Utilise a la fois par _fond_indices_heuristique (entailles detectees a
    la main) et par _resolve_faces (mortaises enregistrees par Mortaise
    CNC) : un meme corps/enregistrement peut contenir PLUSIEURS cavites
    distinctes (ex: une rangee de N tenons decoupee en un seul Cut), et
    "exclure le fond" doit exclure UNE face par cavite - jamais une seule
    face au total pour tout le lot, sans quoi les fonds des autres cavites
    restent inclus a tort (jeu applique dessus - bug signale : "la
    detection exclure les fond de mortaise se fait mal")."""
    n = len(items)
    edge_map = {}
    for idx, (_key, f) in enumerate(items):
        try:
            for e in f.edges:
                edge_map.setdefault(e.entityToken, []).append(idx)
        except Exception:
            pass
    parent = list(range(n))
    def _find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    def _union(a, b):
        ra, rb = _find(a), _find(b)
        if ra != rb:
            parent[ra] = rb
    for idxs in edge_map.values():
        for i in range(1, len(idxs)):
            _union(idxs[0], idxs[i])
    groups = {}
    for i in range(n):
        groups.setdefault(_find(i), []).append(i)
    return list(groups.values())


def _fond_indices_heuristique(kept_faces):
    """Parmi les faces retenues par _chant_faces_heuristique pour UN corps,
    identifie celles qui sont le "fond" d'une cavite (mortaise/entaille) a
    exclure quand l'option "Exclure le fond de mortaise" est active.

    _chant_faces_heuristique ne renvoie qu'une liste PLATE de faces, sans
    distinguer a quelle cavite chacune appartient - un corps peut pourtant
    contenir plusieurs entailles independantes. On regroupe donc d'abord
    les faces par CAVITE (voir _group_faces_by_shared_edges).

    REGLE (precisee par l'utilisateur, l'ancienne heuristique "plus petite
    face du groupe" etait fausse) :
    - une mortaise EN BORD de corps (ouverte sur un cote, ex. un tenon qui
      rentre depuis le chant) n'a que 3 parois detectees : 2 parois
      laterales (le long de l'axe d'insertion, generalement etroites) et 1
      paroi de fond (perpendiculaire a l'axe d'insertion, generalement la
      PLUS GRANDE des trois si le tenon est plus long que profond) - c'est
      cette derniere, la plus grande, qu'il faut exclure.
    - une mortaise EN PLEIN CORPS (entouree de matiere de tous les cotes,
      4 parois) n'a PAS de paroi de fond distincte a exclure : l'utilisateur
      veut le jeu sur les 4 parois. Un groupe de 4 faces (ou tout autre
      taille que 3) n'est donc jamais touche ici.

    Retourne l'ensemble des INDICES (dans kept_faces) a exclure."""
    if len(kept_faces) < 2:
        return set()
    items = [(i, f) for i, f in enumerate(kept_faces)]
    idx_groups = _group_faces_by_shared_edges(items)
    fond_idx = set()
    for grp in idx_groups:
        if len(grp) != 3:
            continue
        try:
            largest = max(grp, key=lambda i: kept_faces[i].area)
            fond_idx.add(largest)
        except Exception:
            pass
    return fond_idx


def _resolve_faces(design, female_tokens_filter, exclure_fond=False):
    """Relit mortaise_face_map.json (ecrit par Mortaise CNC) et resout
    chaque token de face en objet BRepFace reel via design.findEntityByToken.
    Si female_tokens_filter est un set non vide, ne garde que les
    enregistrements dont le corps femelle est dedans (sinon, tout est pris).

    Nettoie aussi le fichier au passage : un enregistrement dont plus aucune
    face ne se resout (mortaise supprimee/modifiee depuis) est retire, pour
    que le fichier partage reste a jour au fil des sessions.

    exclure_fond : si True, EXCLUT de chaque CAVITE (pas de chaque
    enregistrement pris globalement - voir plus bas) sa paroi de fond,
    UNIQUEMENT quand cette cavite est une mortaise EN BORD de corps (3
    parois detectees : 2 parois laterales le long de l'axe d'insertion +
    1 paroi de fond perpendiculaire, generalement la PLUS GRANDE des trois
    - precise par l'utilisateur, l'ancienne heuristique "plus petite face"
    etait fausse). Une mortaise EN PLEIN CORPS (entouree de matiere de
    tous les cotes, 4 parois) n'a pas de fond distinct a exclure : le jeu
    doit s'appliquer sur les 4 parois - un groupe de taille differente de
    3 n'est donc jamais touche. Ca evite d'appliquer le jeu de
    fonctionnement sur le fond d'une mortaise en bord, la ou ca n'a
    generalement pas d'utilite (le jeu sert a faciliter l'insertion du
    tenon sur les cotes, pas a agrandir la profondeur).

    IMPORTANT : un seul enregistrement de mortaise_face_map.json peut
    couvrir PLUSIEURS cavites distinctes en une seule fois (ex. une rangee
    de N tenons decoupee en un seul Cut par Mortaise CNC - voir
    creer_mortaises) - prendre "la plus petite face de tout
    l'enregistrement" comme seul fond (ancien comportement) n'excluait
    alors qu'UN SEUL fond au lieu d'un par cavite, laissant le jeu
    s'appliquer a tort sur les fonds des autres cavites du meme
    enregistrement (bug signale : "la detection exclure les fond de
    mortaise se fait mal"). On regroupe donc d'abord les parois par
    cavite - via le champ 'cavities' deja calcule par Mortaise CNC a la
    creation (voir _group_by_shared_edges dans MortaiseCNC.py) quand il
    est present, sinon en reconstruisant les groupes par aretes partagees
    (repli pour les enregistrements crees avant l'ajout de ce champ) -
    puis on exclut, pour chaque cavite de 3 parois, la plus GRANDE des
    trois.

    Comparaison faite par cavite (pas globalement) : une grande mortaise
    ne doit pas faire exclure a tort la petite paroi laterale d'une AUTRE
    mortaise plus petite. Ne s'applique qu'aux mortaises enregistrees ici -
    pas aux entailles detectees par _chant_faces_heuristique (voir
    apply_jeu)."""
    records = _load_mortaise_records()
    faces = []
    seen_tokens = set()
    kept_records = []
    nb_dead = 0
    nb_fond_exclu = 0

    for rec in records:
        toks = rec.get('face_tokens', [])
        if female_tokens_filter and rec.get('female_token') not in female_tokens_filter:
            kept_records.append(rec)
            continue

        live_toks = []
        rec_faces = []
        tok_to_face = {}
        for tok in toks:
            try:
                found = design.findEntityByToken(tok)
            except Exception:
                found = None
            if not found:
                continue
            face = adsk.fusion.BRepFace.cast(found[0])
            if not face:
                continue
            live_toks.append(tok)
            rec_faces.append((tok, face))
            tok_to_face[tok] = face

        nb_dead += (len(toks) - len(live_toks))
        if live_toks:
            rec['face_tokens'] = live_toks
            kept_records.append(rec)
        # sinon : mortaise entierement disparue, on ne la garde pas

        fond_toks = set()
        if exclure_fond and len(rec_faces) >= 2:
            cavity_groups = []
            for grp_toks in (rec.get('cavities') or []):
                grp_faces = [(t, tok_to_face[t]) for t in grp_toks if t in tok_to_face]
                if grp_faces:
                    cavity_groups.append(grp_faces)
            if not cavity_groups:
                # Repli : enregistrement cree avant l'ajout du champ
                # 'cavities' (ou champ vide/invalide) - reconstruit les
                # groupes par aretes partagees, comme pour les entailles
                # detectees a la main (_fond_indices_heuristique).
                idx_groups = _group_faces_by_shared_edges(rec_faces)
                cavity_groups = [[rec_faces[i] for i in grp] for grp in idx_groups]
            for grp_faces in cavity_groups:
                if len(grp_faces) != 3:
                    continue
                try:
                    fond_tok, _fond_face = max(grp_faces, key=lambda t: t[1].area)
                    fond_toks.add(fond_tok)
                except Exception:
                    pass

        for tok, face in rec_faces:
            if tok in fond_toks:
                nb_fond_exclu += 1
                continue
            if tok not in seen_tokens:
                seen_tokens.add(tok)
                faces.append(face)

    if nb_dead or len(kept_records) != len(records):
        _save_mortaise_records(kept_records)
        _dbg(f'_resolve_faces: {nb_dead} token(s) mort(s) nettoyes, '
             f'{len(records) - len(kept_records)} enregistrement(s) obsolete(s) retire(s)')
    if nb_fond_exclu:
        _dbg(f'_resolve_faces: {nb_fond_exclu} fond(s) de mortaise exclu(s) (option active)')

    return faces


def _create_offset_by_component(faces, root, jeu):
    """Cree le(s) OffsetFacesFeatures necessaire(s) pour appliquer le jeu
    de fonctionnement sur `faces`, en les groupant D'ABORD par COMPOSANT
    PROPRIETAIRE REEL de chaque face.

    Necessaire (pas juste une precaution) : OffsetFacesFeatures doit etre
    cree via les features du composant qui possede REELLEMENT chaque face
    (ex. "DOS"), sinon Fusion leve "object is not in the assembly context
    of this component" - deja rencontre et corrige une premiere fois en
    prenant comp = faces[0].body.parentComponent au lieu de root en dur,
    MAIS ce correctif suppose que TOUTES les faces du lot appartiennent au
    MEME composant que la premiere. Faux des qu'un seul lot regroupe des
    mortaises touchant PLUSIEURS corps femelle vivant chacun dans son
    propre composant (ex. plusieurs panneaux convertis individuellement
    en composants, "Corps -> Composant") - constate en direct via
    MargeAuto (une mortaise creee automatiquement sur un corps dans un
    composant different du premier faisait echouer tout l'offset avec
    cette meme erreur). On cree donc UNE feature par composant concerne,
    plutot qu'une seule feature globale.

    Cle de regroupement = entityToken du composant (pas l'objet Python
    lui-meme) : deux acces successifs a "le meme" composant via l'API
    Fusion peuvent renvoyer des instances-wrapper differentes, dont
    l'egalite/hash par defaut n'est pas fiable pour grouper - le token,
    lui, est une chaine stable.

    Retourne la liste des features reellement creees (souvent une seule,
    parfois plusieurs - le groupement/renommage cote appelant s'appuie de
    toute facon sur le nombre d'entrees ajoutees a la chronologie, pas sur
    la longueur de cette liste)."""
    by_comp_tok = {}
    for f in faces:
        try:
            comp = f.body.parentComponent or root
        except Exception:
            comp = root
        try:
            ctok = comp.entityToken
        except Exception:
            ctok = None
        entry = by_comp_tok.setdefault(ctok, {'comp': comp, 'faces': []})
        entry['faces'].append(f)

    feats = []
    for entry in by_comp_tok.values():
        comp = entry['comp']
        comp_faces = entry['faces']
        try:
            off = comp.features.offsetFacesFeatures
            # Un offset positif deplace chaque face le long de sa propre
            # normale sortante (qui, pour une paroi de cavite, pointe vers
            # l'interieur de la mortaise) : ca fait donc grossir la
            # matiere et RETRECIR la mortaise. Pour un jeu de
            # fonctionnement, on veut l'inverse (agrandir la mortaise),
            # donc on applique la distance en negatif.
            oi = off.createInput(comp_faces, adsk.core.ValueInput.createByReal(-jeu))
            feat = off.add(oi)
        except Exception:
            _dbg('_create_offset_by_component EXCEPTION (composant '
                 f'{getattr(comp, "name", "?")}): ' + traceback.format_exc())
            continue
        if feat:
            feats.append(feat)
    return feats


def apply_jeu(design, root, female_tokens_filter, selected_bodies, jeu, jeu_actif,
              exclure_fond=False, skip_heuristique=False):
    """Coeur de Marge CNC (resolution des faces + creation de l'offset),
    factorise pour etre reutilisable tel quel par l'add-in 'Mise a jour
    CNC' (qui doit rejouer exactement le meme calcul, sans passer par la
    boite de dialogue). Retourne (feature_ou_None, n_mortaise, n_heuristique, faces).

    exclure_fond : voir _resolve_faces - exclut le fond (plus petite face)
    de chaque mortaise enregistree du calcul du jeu.

    skip_heuristique (ajoute le 2026-10-04, bug remonte par l'utilisateur :
    "modif marge avec les entailles... selectionne une face en trop, la
    petite ne devrait pas etre selectionnee") : quand True, saute
    ENTIEREMENT la detection heuristique ci-dessous (_chant_faces_heuristique
    / _fond_indices_heuristique) sur selected_bodies - celle-ci reste
    utilisee TELLE QUELLE par la boite de dialogue interactive "Marge CNC"
    (ExecuteHandler ci-dessous), ou elle sert a capter les parois d'une
    entaille decoupee A LA MAIN (sans passer par Tenons/Mortaise/Entaille
    CNC) sur un corps que l'utilisateur vient de selectionner explicitement -
    cas qu'il est impossible de deviner sans cette selection manuelle.

    Mais 'Modif Marge' et 'Mise a jour CNC' rejouent, eux, des entrees
    DEJA enregistrees avec precision (face_tokens exacts ecrits a la
    creation par MortaiseCNC.creer_mortaises OU, depuis le 2026-10-03, par
    EntailleCNC._apply_marge) : selected_bodies y contient alors le(s)
    meme(s) corps DEJA couverts par ces face_tokens precis, et relancer la
    detection heuristique dessus la fait retomber sur SA PROPRE regle
    "fond = la PLUS GRANDE des 3 parois" (_fond_indices_heuristique) -
    vraie pour une mortaise/tenon (fond generalement plus grand que les 2
    parois laterales etroites) mais FAUSSE pour une entaille a mi-bois
    (fond = la PLUS PETITE des 3, les 2 parois laterales etant au contraire
    les plus grandes - voir EntailleCNC._classify_fond_lateral) : la
    detection heuristique exclut alors a tort une paroi laterale (ou,
    quand exclure_fond est desactive sur cette entree comme c'est le cas
    pour EntailleCNC, n'exclut rien du tout et RAJOUTE le fond en plus des
    2 parois laterales deja resolues par _resolve_faces, d'ou la face en
    trop constatee). Sauter cette detection pour un rejeu automatise est
    toujours correct : les faces exactes sont deja dans face_tokens, aucune
    estimation n'est necessaire."""
    faces = _resolve_faces(design, female_tokens_filter, exclure_fond)
    n_mortaise = len(faces)

    seen_tokens = set()
    for f in faces:
        try:
            seen_tokens.add(f.entityToken)
        except Exception:
            pass
    n_heuristique = 0
    nb_fond_exclu_heur = 0
    if not skip_heuristique:
        for body in selected_bodies:
            body_faces = _chant_faces_heuristique(body)
            fond_idx = _fond_indices_heuristique(body_faces) if exclure_fond else set()
            for i, f in enumerate(body_faces):
                if i in fond_idx:
                    nb_fond_exclu_heur += 1
                    continue
                try:
                    tok = f.entityToken
                except Exception:
                    continue
                if tok in seen_tokens:
                    continue
                seen_tokens.add(tok)
                faces.append(f)
                n_heuristique += 1
    if nb_fond_exclu_heur:
        _dbg(f'apply_jeu: {nb_fond_exclu_heur} fond(s) exclu(s) via detection heuristique (option active)')

    if not faces or not (jeu_actif and jeu != 0):
        return None, n_mortaise, n_heuristique, faces

    cnc_progress.etape('Jeu de fonctionnement : decalage des faces...')
    feats = _create_offset_by_component(faces, root, jeu)
    toks = ','.join(b.entityToken for b in selected_bodies if b)
    for ft in feats:
        try:
            ft.attributes.add('MargeCNC', 'jeu_cm', str(jeu))
            ft.attributes.add('MargeCNC', 'exclure_fond', '1' if exclure_fond else '0')
            if toks:
                ft.attributes.add('MargeCNC', 'selected_body_tokens', toks)
        except Exception:
            pass
    # Un seul feat "representatif" est retourne (le dernier cree) : les
    # appelants (ExecuteHandler ici, Mise a jour CNC) ne s'en servent que
    # pour savoir SI quelque chose a ete cree et, le cas echeant,
    # renommer/grouper dans la timeline - logique deja basee sur la
    # position du marqueur de chronologie (tl.markerPosition), pas sur le
    # nombre exact de features, donc compatible avec plusieurs features
    # creees d'un coup (une par composant concerne).
    feat = feats[-1] if feats else None
    return feat, n_mortaise, n_heuristique, faces


def apply_jeu_to_tokens(design, root, records, jeu, exclure_fond=False):
    """Variante de apply_jeu qui opere sur une liste EXPLICITE
    d'enregistrements de mortaises tout juste creees (meme format que
    new_records retourne par MortaiseCNC.creer_mortaises : dicts avec
    'face_tokens' et 'cavities'), plutot que de relire tout
    mortaise_face_map.json filtre par corps femelle.

    Utilisee par TenonCNC (option "MargeAuto") juste apres la creation
    automatique d'une mortaise (MortaiseAuto) : applique le jeu
    UNIQUEMENT sur les parois de CETTE mortaise precise, jamais sur
    celles d'une mortaise plus ancienne du meme corps femelle -
    important car OffsetFacesFeature deplace les faces en place, donc
    repasser par apply_jeu (qui relit TOUT mortaise_face_map.json pour
    ce corps) reappliquerait le jeu une seconde fois sur des parois deja
    decalees par un tenon precedent, faussant la cote de jeu.

    Retourne (feature_ou_None, n_faces)."""
    faces = []
    seen_tokens = set()
    fond_toks = set()

    for rec in records:
        toks = rec.get('face_tokens') or []
        tok_to_face = {}
        for tok in toks:
            try:
                found = design.findEntityByToken(tok)
            except Exception:
                found = None
            if not found:
                continue
            face = adsk.fusion.BRepFace.cast(found[0])
            if face:
                tok_to_face[tok] = face

        if exclure_fond and tok_to_face:
            cavity_groups = []
            for grp_toks in (rec.get('cavities') or []):
                grp_faces = [(t, tok_to_face[t]) for t in grp_toks if t in tok_to_face]
                if grp_faces:
                    cavity_groups.append(grp_faces)
            if not cavity_groups:
                items = list(tok_to_face.items())
                idx_groups = _group_faces_by_shared_edges(items)
                cavity_groups = [[items[i] for i in grp] for grp in idx_groups]
            for grp_faces in cavity_groups:
                if len(grp_faces) != 3:
                    continue
                try:
                    fond_tok, _f = max(grp_faces, key=lambda t: t[1].area)
                    fond_toks.add(fond_tok)
                except Exception:
                    pass

        for tok, face in tok_to_face.items():
            if tok in fond_toks or tok in seen_tokens:
                continue
            seen_tokens.add(tok)
            faces.append(face)

    if not faces or jeu == 0:
        return None, len(faces)

    # Regroupe par composant proprietaire reel avant de creer l'offset
    # (voir _create_offset_by_component) : une seule mortaise "auto" peut
    # toucher un corps femelle qui vit dans un composant different de
    # celui du corps male, et new_records peut meme couvrir plusieurs
    # corps femelle distincts en un seul appel de MortaiseAuto - sans ce
    # regroupement, Fusion refuse la creation des que les faces ne sont
    # pas toutes dans le meme composant ("object is not in the assembly
    # context of this component", constate en direct).
    cnc_progress.etape('Jeu de fonctionnement : decalage des faces...')
    feats = _create_offset_by_component(faces, root, jeu)
    female_toks = set()
    for rec in records:
        ft = rec.get('female_token')
        if ft:
            female_toks.add(ft)
    for feat in feats:
        try:
            feat.attributes.add('MargeCNC', 'jeu_cm', str(jeu))
            feat.attributes.add('MargeCNC', 'exclure_fond', '1' if exclure_fond else '0')
            # Tague aussi les corps femelle concernes (meme convention que
            # apply_jeu/ExecuteHandler) : sert a ce que "Modif Marge"
            # (mise a jour groupee du jeu en fin de projet) retrouve et
            # recree cette feature comme les autres, de facon uniforme
            # qu'elle vienne d'une application manuelle ou de MargeAuto.
            if female_toks:
                feat.attributes.add('MargeCNC', 'selected_body_tokens', ','.join(female_toks))
            feat.attributes.add('MargeCNC', 'origine', 'auto')
        except Exception:
            pass
    feat = feats[-1] if feats else None
    return feat, len(faces)


def record_face_tokens(female_token, face_tokens):
    """Persiste un enregistrement {female_token, face_tokens} dans
    mortaise_face_map.json - ajoute le 2026-10-04 pour EntailleCNC (voir sa
    fonction _apply_marge), qui, contrairement a MortaiseCNC.creer_mortaises,
    n'ecrivait auparavant RIEN dans ce fichier : apply_jeu_to_tokens cree
    l'offset immediat mais ne persiste jamais les face_tokens utilises, donc
    un rejeu ulterieur (Modif Marge / Mise a jour CNC, via _resolve_faces)
    ne retrouvait aucune entree pour une entaille et retombait ENTIEREMENT
    sur la detection heuristique de secours (_chant_faces_heuristique,
    normalement reservee aux entailles decoupees a la main). Cette
    heuristique suppose "fond = la PLUS GRANDE des 3 parois"
    (_fond_indices_heuristique), vrai pour une mortaise/tenon mais FAUX
    pour une entaille a mi-bois (fond = la PLUS PETITE des 3 - voir
    EntailleCNC._classify_fond_lateral) : sans exclusion de fond active sur
    ces entrees (exclure_fond=False, convention EntailleCNC), elle rajoutait
    purement et simplement le fond en plus des 2 parois laterales deja
    voulues - bug remonte par l'utilisateur ("ca selectionne une face en trop sur
    chaque entaille... la petite ne devrait pas etre selectionnee").

    En persistant ici les tokens EXACTS des parois laterales (jamais le
    fond, deja exclu par EntailleCNC avant l'appel), _resolve_faces les
    retrouve ensuite avec precision, sans aucune estimation geometrique -
    exactement comme pour une mortaise enregistree par Mortaise CNC.

    female_token : token du corps cible/outil concerne (meme convention que
    MortaiseCNC/TenonCNC). face_tokens : UNIQUEMENT les parois laterales,
    jamais le fond."""
    if not female_token or not face_tokens:
        return
    try:
        records = _load_mortaise_records()
        records.append({'female_token': female_token, 'face_tokens': list(face_tokens)})
        _save_mortaise_records(records)
    except Exception:
        _dbg('record_face_tokens EXCEPTION: ' + traceback.format_exc())


def record_face_tokens_batch(records):
    """Variante BATCH de record_face_tokens : persiste PLUSIEURS
    enregistrements {female_token, face_tokens} en UNE SEULE lecture +
    UNE SEULE ecriture de mortaise_face_map.json, au lieu d'un aller-retour
    disque complet par enregistrement - ajoute le 2026-10-04 (demande
    explicite de l'utilisateur : "Optimise la vitesse de creation des entailles
    au maximum du possible"). Utilisee par EntailleCNC._flush_marge_batch :
    pour N cibles/montants traites en un seul clic "Creer" (voir
    create_entaille_core_multi), l'ancien chemin (record_face_tokens
    appele une fois par entaille et par cote, cible ET outil) faisait
    jusqu'a 2xN lectures+ecritures completes du fichier - devenu de plus en
    plus couteux a mesure que mortaise_face_map.json grossit au fil du
    projet (il est relu/reecrit en entier a chaque fois). Un seul
    aller-retour suffit : le resultat final (contenu du fichier) est
    strictement identique.

    records : liste de dicts {'female_token':..., 'face_tokens':[...]} -
    meme format qu'un seul appel de record_face_tokens, en lot. Les entrees
    sans female_token ou sans face_tokens sont silencieusement ignorees."""
    valid = [{'female_token': r.get('female_token'), 'face_tokens': list(r.get('face_tokens') or [])}
             for r in (records or [])
             if r.get('female_token') and r.get('face_tokens')]
    if not valid:
        return
    try:
        existing = _load_mortaise_records()
        existing.extend(valid)
        _save_mortaise_records(existing)
    except Exception:
        _dbg('record_face_tokens_batch EXCEPTION: ' + traceback.format_exc())


def _find_all_marge_runs(design):
    """Retrouve TOUTES les features de jeu (Marge CNC, manuelles ou
    auto/MargeAuto) presentes dans le design via leurs attributs, et
    retourne une liste de (feature, selected_body_tokens, exclure_fond).
    selected_body_tokens est une liste de tokens (vide = "toutes les
    mortaises connues", cas d'un Marge CNC lance sans selection).

    Factorise pour etre reutilise a la fois par ModifMargeCmd (ce
    fichier) et par Mise a jour CNC."""
    runs = []
    try:
        attrs = design.findAttributes('MargeCNC', 'jeu_cm')
    except Exception:
        attrs = []
    for a in attrs:
        try:
            feat = a.parent
            sel_attr = None
            try:
                sel_attr = feat.attributes.itemByName('MargeCNC', 'selected_body_tokens')
            except Exception:
                pass
            toks = [t for t in (sel_attr.value.split(',') if sel_attr and sel_attr.value else []) if t]
            fond_attr = None
            try:
                fond_attr = feat.attributes.itemByName('MargeCNC', 'exclure_fond')
            except Exception:
                pass
            exclure_fond = bool(fond_attr and fond_attr.value == '1')
            runs.append((feat, toks, exclure_fond))
        except Exception:
            _dbg('_find_all_marge_runs lecture attribut EXCEPTION: ' + traceback.format_exc())
    return runs


class SelectEventHandler(adsk.core.CustomEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        global _pending_faces
        try:
            sels = _ui.activeSelections
            sels.clear()
            for f in _pending_faces:
                try:
                    sels.add(f)
                except Exception:
                    pass
            _pending_faces = []
        except Exception:
            pass


class ValidateHandler(adsk.core.ValidateInputsEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            args.areInputsValid = True
        except Exception:
            args.areInputsValid = False


class ChangedHandler(adsk.core.InputChangedEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            inputs = args.inputs
            sel = inputs.itemById('femelles')
            lbl = inputs.itemById('lbl_sel')
            if lbl and sel:
                n = sel.selectionCount
                lbl.text = (f'{n} corps femelle(s) selectionne(s)' if n
                            else 'Aucun corps selectionne = toutes les mortaises connues')
        except Exception:
            pass


class ExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        global _pending_faces
        try:
            inputs = adsk.core.CommandEventArgs.cast(args).firingEvent.sender.commandInputs
            sel    = inputs.itemById('femelles')
            si_jon = inputs.itemById('jeu_actif')
            si_jeu = inputs.itemById('jeu')
            si_fond = inputs.itemById('exclure_fond')

            jeu_actif    = si_jon.value if si_jon else False
            jeu          = si_jeu.value if si_jeu else 0.02
            exclure_fond = si_fond.value if si_fond else False
            save_settings(jeu, jeu_actif, exclure_fond)

            design = adsk.fusion.Design.cast(_app.activeProduct)
            root   = design.rootComponent
            tl     = design.timeline
            start_index = tl.markerPosition

            female_tokens_filter = set()
            selected_bodies = []
            if sel and sel.selectionCount > 0:
                for i in range(sel.selectionCount):
                    body = adsk.fusion.BRepBody.cast(sel.selection(i).entity)
                    if body:
                        selected_bodies.append(body)
                        try:
                            # _native_token (pas body.entityToken directement) :
                            # un corps selectionne dans la boite de dialogue peut
                            # etre un PROXY d'assemblage dont l'entityToken differe
                            # de celui, NATIF, enregistre dans mortaise_face_map.json
                            # (voir _record_mortaise_faces dans MortaiseCNC.py, qui
                            # utilise female.entityToken sur le corps natif). Sans
                            # cette normalisation, le filtre par corps femelle ne
                            # matchait plus AUCUN enregistrement mortaise_face_map
                            # pour un corps selectionne ainsi, et Marge CNC retombait
                            # a tort sur l'heuristique geometrique seule - qui, elle,
                            # exclut les grandes parois laterales (aire > aire_max) :
                            # c'est ce qui faisait selectionner 6 chants sur 10 au
                            # lieu des 10 parois reellement enregistrees.
                            female_tokens_filter.add(_native_token(body))
                        except Exception:
                            pass

            _dbg(f'=== Execute Marge CNC : filtre={len(female_tokens_filter)} corps, '
                 f'jeu_actif={jeu_actif} jeu={jeu} ===')

            # Repli heuristique (voir apply_jeu / _chant_faces_heuristique) :
            # sur chaque corps EXPLICITEMENT selectionne (impossible a
            # deviner sans selection), on detecte en plus les parois
            # d'entaille qui ne sont pas dans mortaise_face_map.json - cas
            # des entailles/rainures decoupees a la main dans Fusion, sans
            # passer par Tenons CNC / Mortaise CNC.
            with cnc_progress.Barre('Marge CNC', 'Recherche des faces...'):
                feat, n_mortaise, n_heuristique, faces = apply_jeu(
                    design, root, female_tokens_filter, selected_bodies, jeu, jeu_actif, exclure_fond)

            _dbg(f'faces retenues: {n_mortaise} via mortaise_face_map, '
                 f'{n_heuristique} via detection heuristique (entailles manuelles)')

            # Rend la feature de jeu venant d'etre creee reconnaissable dans
            # la timeline comme venant de Marge CNC : sans ca, elle reste
            # une feature isolee "DecalerLesFacesXX", indistincte des
            # features natives. Seulement si une feature a reellement ete
            # creee (jeu_actif) : en mode apercu (selection seule), rien
            # n'est ajoute a la timeline.
            #
            # Fusion exige au moins 2 features pour former un groupe
            # (TimelineGroups.add leve une RuntimeError sinon) - et
            # apply_jeu ne cree jamais qu'UNE seule feature d'offset (qui
            # porte TOUTES les faces a la fois), donc un groupe est ici
            # quasiment toujours impossible. On se contente donc de
            # renommer la feature elle-meme ("Marge CNC" au lieu du nom
            # generique "DecalerLesFacesXX") - et on ne tente le
            # groupement que dans le cas, rare, ou plusieurs features
            # auraient ete creees.
            if feat:
                end_index = tl.markerPosition - 1
                if end_index > start_index:
                    try:
                        grp = tl.timelineGroups.add(start_index, end_index)
                        if grp:
                            grp.name = 'Marge CNC'
                            grp.isCollapsed = True
                    except Exception:
                        _dbg('groupement timeline Marge CNC EXCEPTION: ' + traceback.format_exc())
                else:
                    try:
                        feat.name = 'Marge CNC'
                    except Exception:
                        pass

            if not faces:
                _ui.messageBox(
                    "Aucune mortaise connue (creee par Mortaise CNC) et aucune entaille "
                    "detectee sur la selection.\n"
                    "Lancez d'abord Mortaise CNC, ou selectionnez le(s) corps contenant "
                    "l'entaille a traiter.",
                    'Marge CNC')
                _dbg('=== Fin Execute : aucune face ===')
                return

            if jeu_actif and jeu != 0:
                _app.activeViewport.fit()
                msg = f'1 feature creee : {round(jeu * 10, 3)} mm sur {len(faces)} face(s).'
                if n_heuristique:
                    msg += f'\n(dont {n_heuristique} face(s) via detection automatique des entailles.)'
                _ui.messageBox(msg, 'Marge CNC')
                _dbg(f'=== Fin Execute : jeu applique sur {len(faces)} face(s) ===')
            else:
                _pending_faces = faces
                _app.fireCustomEvent(EVT_ID, '')
                _dbg(f'=== Fin Execute : {len(faces)} face(s) selectionnee(s) (apercu) ===')
        except Exception:
            _ui.messageBox('Erreur execution Marge CNC:\n' + traceback.format_exc())
            _dbg('EXCEPTION Execute: ' + traceback.format_exc())


class CreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        global _execute_handler, _changed_handler, _validate_handler
        try:
            cmd = adsk.core.CommandCreatedEventArgs.cast(args).command
            cmd.isRepeatable = False
            _execute_handler  = ExecuteHandler()
            _changed_handler  = ChangedHandler()
            _validate_handler = ValidateHandler()
            cmd.execute.add(_execute_handler)
            cmd.inputChanged.add(_changed_handler)
            cmd.validateInputs.add(_validate_handler)

            inputs = cmd.commandInputs

            sel = inputs.addSelectionInput(
                'femelles', 'Corps femelle(s)',
                'Selectionnez les corps femelles a cibler (vide = toutes les mortaises connues). '
                'Selectionner un corps avec une entaille faite a la main y detecte aussi ses parois.')
            sel.addSelectionFilter('SolidBodies')
            sel.setSelectionLimits(0, 0)

            inputs.addTextBoxCommandInput(
                'lbl_sel', '', 'Aucun corps selectionne = toutes les mortaises connues', 1, True)

            jeu_cm, jeu_actif, exclure_fond = load_settings()
            inputs.addValueInput(
                'jeu', 'Jeu (mm)', 'mm', adsk.core.ValueInput.createByReal(jeu_cm))
            inputs.addBoolValueInput(
                'jeu_actif', 'Appliquer le jeu', True, '', jeu_actif)
            inputs.addBoolValueInput(
                'exclure_fond', 'Exclure le fond de mortaise', True, '', exclure_fond)

            inputs.addTextBoxCommandInput(
                'info', '',
                '<br><b>Marge CNC</b><br>'
                'Utilise les mortaises deja enregistrees par Mortaise CNC.<br>'
                '<i>Un corps selectionne qui contient en plus une entaille decoupee a la main '
                '(pas via Tenons CNC / Mortaise CNC) voit aussi ses parois detectees '
                'automatiquement.</i><br>'
                '<i>Desactive : selectionne les parois pour verification.<br>'
                'Active : cree une feature de jeu dans la timeline.</i><br>'
                '<i>"Exclure le fond de mortaise" : ne selectionne/decale pas la paroi du fond '
                'de chaque mortaise (generalement la plus petite face de la cavite) - le jeu '
                "n'est alors applique que sur les parois laterales.</i>",
                6, True)
        except Exception:
            _ui.messageBox('Erreur dialogue Marge CNC:\n' + traceback.format_exc())


# --- Garde-fou Calpinage CNC (2026-10-10) ------------------------------------
# Calpinage CNC peut poser les vraies pieces a plat sur des panneaux (groupe
# d'historique "Calpinage CNC"). Cet outil travaille sur les pieces en
# position d'assemblage : on refuse tant que le calpinage est en place.
def _calpinage_en_place():
    try:
        design = adsk.fusion.Design.cast(adsk.core.Application.get().activeProduct)
        tl = design.timeline
        for i in range(tl.timelineGroups.count):
            n = tl.timelineGroups.item(i).name
            if n.startswith('Calpinage CNC') and 'copie' not in n:
                return True
    except Exception:
        pass
    return False


def _calpinage_refus(ui, titre):
    ui.messageBox("Les pieces sont posees a plat par Calpinage CNC.\n\n"
                  "Remets-les d'abord en assemblage : palette CNC Toolkit > "
                  "Calpinage CNC > Remettre en assemblage.", titre)


class ModifMargeExecuteHandler(adsk.core.CommandEventHandler):
    """Execute de 'Modif Marge' : retrouve TOUTES les features de jeu deja
    creees dans le projet (manuelles via Marge CNC, ou automatiques via
    l'option MargeAuto de Tenons CNC), les supprime, puis les recree avec
    UNE SEULE nouvelle valeur de jeu pour toutes.

    IMPORTANT - deduplication par corps femelle avant recreation : chaque
    tenon cree avec MargeAuto declenche sa PROPRE application de jeu sur le
    corps femelle concerne, donc un meme corps peut avoir recu plusieurs
    features de jeu independantes au fil du projet (une par tenon). Les
    rejouer une par une (comme le fait 'Mise a jour CNC' pour ses propres
    features) ferait alors tourner apply_jeu plusieurs fois de suite sur le
    MEME corps - et comme apply_jeu relit a chaque fois TOUTES les parois
    connues de ce corps dans mortaise_face_map.json, ca superposerait
    plusieurs decalages sur les memes faces au lieu d'un seul. On regroupe
    donc d'abord tous les anciens runs par (corps cible, exclure_fond), et
    on ne rejoue qu'UNE fois par groupe."""
    def __init__(self): super().__init__()
    def notify(self, args):
        if _calpinage_en_place():
            _calpinage_refus(_ui, COMMAND_NAME2)
            return
        try:
            inputs = adsk.core.CommandEventArgs.cast(args).firingEvent.sender.commandInputs
            si_jeu = inputs.itemById('jeu')
            new_jeu = si_jeu.value if si_jeu else 0.02

            design = adsk.fusion.Design.cast(_app.activeProduct)
            root   = design.rootComponent
            tl     = design.timeline

            runs = _find_all_marge_runs(design)
            if not runs:
                _ui.messageBox(
                    "Aucune marge (jeu) trouvee dans ce projet.\nLancez d'abord "
                    "Marge CNC, ou activez 'MargeAuto' dans Tenons CNC.",
                    COMMAND_NAME2)
                return

            _dbg(f'=== Execute Modif Marge : {len(runs)} feature(s) existante(s), nouveau jeu={new_jeu} ===')

            start_index = tl.markerPosition

            # --- 1. Regroupe les runs existants par (ensemble de corps
            # cibles, exclure_fond) AVANT toute suppression, puis supprime
            # toutes les anciennes features de jeu. ------------------------
            has_all = {False: False, True: False}
            bucket_tokens = {False: set(), True: set()}
            for feat, toks, exclure_fond in runs:
                if toks:
                    bucket_tokens[exclure_fond].update(toks)
                else:
                    has_all[exclure_fond] = True

            _dog, _dog_snap = _dogbones_retirer(design)

            n_del = 0
            for feat, toks, exclure_fond in runs:
                try:
                    feat.deleteMe()
                    n_del += 1
                except Exception:
                    _dbg('Modif Marge suppression feature EXCEPTION: ' + traceback.format_exc())
            # Les suppressions ci-dessus font reculer le marqueur : le groupe
            # 'Modif Marge' doit partir d'ici.
            start_index = tl.markerPosition

            # --- 2. Recree UNE feature par groupe (exclure_fond=False puis
            # True), avec le nouveau jeu. -----------------------------------
            n_recreees = 0
            n_faces_total = 0
            errors = []
            for exclure_fond in (False, True):
                if has_all[exclure_fond]:
                    try:
                        feat, n_m, n_h, faces = apply_jeu(
                            design, root, set(), [], new_jeu, True, exclure_fond,
                            skip_heuristique=True)
                        if feat:
                            n_recreees += 1
                            n_faces_total += len(faces)
                    except Exception:
                        errors.append(traceback.format_exc().strip().splitlines()[-1])
                        _dbg('Modif Marge recreation (tout) EXCEPTION: ' + traceback.format_exc())
                elif bucket_tokens[exclure_fond]:
                    toks = bucket_tokens[exclure_fond]
                    selected_bodies = []
                    for t in toks:
                        try:
                            found = design.findEntityByToken(t)
                        except Exception:
                            found = None
                        body = adsk.fusion.BRepBody.cast(found[0]) if found else None
                        if body:
                            selected_bodies.append(body)
                    try:
                        feat, n_m, n_h, faces = apply_jeu(
                            design, root, toks, selected_bodies, new_jeu, True, exclure_fond,
                            skip_heuristique=True)
                        if feat:
                            n_recreees += 1
                            n_faces_total += len(faces)
                    except Exception:
                        errors.append(traceback.format_exc().strip().splitlines()[-1])
                        _dbg('Modif Marge recreation (ciblee) EXCEPTION: ' + traceback.format_exc())

            _dogbones_recreer(design, _dog, _dog_snap, errors)

            end_index = tl.markerPosition - 1
            if end_index > start_index:
                try:
                    grp = tl.timelineGroups.add(start_index, end_index)
                    if grp:
                        grp.name = 'Modif Marge'
                        grp.isCollapsed = True
                except Exception:
                    _dbg('groupement timeline Modif Marge EXCEPTION: ' + traceback.format_exc())
            elif end_index == start_index:
                try:
                    tl.item(end_index).entity.name = 'Modif Marge'
                except Exception:
                    pass

            _app.activeViewport.fit()
            msg = (f'{n_recreees} marge(s) recreee(s) avec un jeu de {round(new_jeu * 10, 3)} mm '
                   f'({n_faces_total} face(s) au total).\n'
                   f'({n_del} ancienne(s) feature(s) de jeu supprimee(s).)')
            if errors:
                msg += '\n\nErreurs :\n' + '\n'.join(errors[:10])
            _ui.messageBox(msg, COMMAND_NAME2)
            _dbg(f'=== Fin Execute Modif Marge : {n_recreees} feature(s) recreee(s) ===')
        except Exception:
            _ui.messageBox('Erreur execution Modif Marge:\n' + traceback.format_exc())
            _dbg('EXCEPTION Execute Modif Marge: ' + traceback.format_exc())


class ModifMargeCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        global _execute_handler2
        try:
            cmd = adsk.core.CommandCreatedEventArgs.cast(args).command
            cmd.isRepeatable = False
            _execute_handler2 = ModifMargeExecuteHandler()
            cmd.execute.add(_execute_handler2)

            inputs = cmd.commandInputs
            jeu_cm, _jeu_actif, _exclure_fond = load_settings()
            inputs.addValueInput(
                'jeu', 'Nouveau jeu (mm)', 'mm', adsk.core.ValueInput.createByReal(jeu_cm))
            inputs.addTextBoxCommandInput(
                'info', '',
                '<br><b>Modif Marge</b><br>'
                'Retrouve TOUTES les marges (jeu) deja creees dans ce projet - '
                'manuelles (Marge CNC) ou automatiques (option MargeAuto de Tenons CNC) '
                '- les supprime, puis les recree toutes avec la nouvelle valeur ci-dessus.<br>'
                "<i>Pratique en fin de projet pour ajuster le jeu de fonctionnement partout "
                "en un seul clic, sans repasser corps par corps.</i>",
                6, True)
        except Exception:
            _ui.messageBox('Erreur dialogue Modif Marge:\n' + traceback.format_exc())


def run(context):
    global _app, _ui, _cmd_def, _panel_ctrl, _created_handler, _select_evt_handler
    global _cmd_def2, _panel_ctrl2, _created_handler2
    try:
        _app = adsk.core.Application.get()
        _ui  = _app.userInterface

        try:
            _app.unregisterCustomEvent(EVT_ID)
        except Exception:
            pass
        evt = _app.registerCustomEvent(EVT_ID)
        _select_evt_handler = SelectEventHandler()
        evt.add(_select_evt_handler)

        for pid in PANEL_IDS:
            panel = _ui.allToolbarPanels.itemById(pid)
            if panel is None:
                continue
            c = panel.controls.itemById(CMD_ID)
            if c: c.deleteMe()
        old = _ui.commandDefinitions.itemById(CMD_ID)
        if old: old.deleteMe()

        _cmd_def = _ui.commandDefinitions.addButtonDefinition(
            CMD_ID, COMMAND_NAME, COMMAND_DESC, '')
        _created_handler = CreatedHandler()
        _cmd_def.commandCreated.add(_created_handler)

        # --- Deuxieme commande : Modif Marge -----------------------------
        for pid in PANEL_IDS:
            panel = _ui.allToolbarPanels.itemById(pid)
            if panel is None:
                continue
            c2 = panel.controls.itemById(CMD_ID2)
            if c2: c2.deleteMe()
        old2 = _ui.commandDefinitions.itemById(CMD_ID2)
        if old2: old2.deleteMe()

        _cmd_def2 = _ui.commandDefinitions.addButtonDefinition(
            CMD_ID2, COMMAND_NAME2, COMMAND_DESC2, '')
        _created_handler2 = ModifMargeCreatedHandler()
        _cmd_def2.commandCreated.add(_created_handler2)

        # Boutons de ruban (Marge CNC ET Modif Marge) RETIRES : devenus
        # inutiles depuis la creation de CNC Toolkit, qui retrouve et
        # execute ces deux CommandDefinitions directement depuis sa
        # palette (categorie "Assemblage" pour Marge CNC, "Selection &
        # utilitaires" pour Modif Marge).
    except Exception:
        if _ui:
            _ui.messageBox('Erreur run Marge CNC:\n' + traceback.format_exc())


def stop(context):
    global _cmd_def, _panel_ctrl, _created_handler
    global _execute_handler, _changed_handler, _validate_handler, _select_evt_handler
    global _cmd_def2, _panel_ctrl2, _created_handler2, _execute_handler2
    try:
        for pid in PANEL_IDS:
            panel = _ui.allToolbarPanels.itemById(pid)
            if panel is None:
                continue
            ctrl = panel.controls.itemById(CMD_ID)
            if ctrl: ctrl.deleteMe()
        cd = _ui.commandDefinitions.itemById(CMD_ID)
        if cd: cd.deleteMe()

        for pid in PANEL_IDS:
            panel = _ui.allToolbarPanels.itemById(pid)
            if panel is None:
                continue
            ctrl2 = panel.controls.itemById(CMD_ID2)
            if ctrl2: ctrl2.deleteMe()
        cd2 = _ui.commandDefinitions.itemById(CMD_ID2)
        if cd2: cd2.deleteMe()

        try:
            _app.unregisterCustomEvent(EVT_ID)
        except Exception:
            pass
        _cmd_def = _panel_ctrl = None
        _created_handler = _execute_handler = _changed_handler = None
        _validate_handler = _select_evt_handler = None
        _cmd_def2 = _panel_ctrl2 = _created_handler2 = _execute_handler2 = None
    except Exception:
        pass
