import adsk.core
import adsk.fusion
import traceback
import os
import json
import sys
import time

# Barre de chargement commune du Toolkit (ToolkitCNC/cnc_progress.py)
_TK_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _TK_DIR not in sys.path:
    sys.path.append(_TK_DIR)
import cnc_progress

# ---------------------------------------------------------------------------
# Extrusion CNC : meme outil que Solide > Creer > Extrusion, mais qui
# MEMORISE les derniers reglages (operation, debut, direction, type
# d'etendue, distances, depouille) d'une utilisation a l'autre et d'un
# document a l'autre (demande de l'utilisateur le 2026-10-09 : ne plus recliquer
# "Nouveau corps" / "Nouveau composant" a chaque extrusion).
#
# PRINCIPE
#   - L'API Fusion ne permet pas de pre-remplir la boite Extrusion native :
#     on recree une boite equivalente (CommandInputs) qui produit une VRAIE
#     ExtrudeFeature, modifiable ensuite avec la boite native.
#   - Apercu live : executePreview construit la fonction ; au clic OK,
#     execute la reconstruit a partir des champs. PAS d'isValidResult = True :
#     une distance prise en cliquant une face ne relance pas toujours
#     l'apercu, et Fusion gardait alors l'ancien apercu (15 mm) au lieu de la
#     distance affichee (retour de l'utilisateur le 2026-10-09).
#   - Les reglages valides sont ecrits dans extrusion_prefs.json (ce
#     dossier) quand la commande se termine par OK. Les distances sont
#     gardees sous forme d'EXPRESSION ("18 mm", "ep*2"...) ; une expression
#     invalide dans le document courant (parametre absent) retombe sur la
#     valeur par defaut.
#   - La selection (profils, objets, corps cibles) n'est jamais memorisee.
# ---------------------------------------------------------------------------

_app = None
_ui = None
_handlers = []

CMD_ID       = 'ExtrusionCNCCmd'
COMMAND_NAME = 'Extrusion CNC'
COMMAND_DESC = ('Extrusion identique a celle de Fusion, qui retient les derniers '
                'reglages (operation, direction, etendue, distances, depouille)')
PANEL_ID     = 'SolidCreatePanel'
NATIVE_EXTRUDE_ID = 'Extrude'

_ADDIN_DIR = os.path.dirname(os.path.abspath(__file__))
PREFS_FILE = os.path.join(_ADDIN_DIR, 'extrusion_prefs.json')
RESOURCES  = os.path.join(_ADDIN_DIR, 'resources')

START_TYPES  = [('profil', 'Plan du profil'), ('decalage', 'Decale'), ('objet', 'Objet')]
DIRECTIONS   = [('un_cote', 'Un cote'), ('deux_cotes', 'Deux cotes'), ('symetrique', 'Symetrique')]
EXTENTS      = [('distance', 'Distance'), ('objet', "A l'objet"), ('tout', 'Tout')]
MESURES      = [('demi', 'Demi-longueur'), ('totale', 'Longueur totale')]
OPERATIONS   = [('joindre', 'Joindre'), ('couper', 'Couper'), ('intersection', 'Intersection'),
                ('nouveau_corps', 'Nouveau corps'), ('nouveau_composant', 'Nouveau composant')]

DEFAULT_PREFS = {
    'start': 'profil', 'start_offset': '0 mm',
    'direction': 'un_cote',
    'extent1': 'distance', 'dist1': '10 mm', 'taper1': '0 deg', 'flip1': False,
    'extent2': 'distance', 'dist2': '10 mm', 'taper2': '0 deg', 'flip2': False,
    'mesure': 'demi',
    'operation': 'nouveau_corps',
    'cp': '',
    # Option tenons (2026-10-09) : None = reprendre la valeur de Tenons CNC
    # (tenon_prefs.json, lu seulement) tant que rien n'a ete memorise ici.
    'tenons': False, 'tenons_chants': 'longueur', 'tenons_mode': 'tenons',
    't_count': None, 't_len': None, 't_h': None, 't_edge': None,
    't_centrer': None, 't_rep_mode': None, 't_rep_pct': None,
    't_lang_bord': None, 't_lang_h': None, 't_mortaise': None, 't_marge': None,
    't_dogbone': None,
}
DOGBONE_PREFS_FILE = os.path.join(os.path.dirname(_ADDIN_DIR), 'DogboneCNC', 'dogbone_prefs.json')

TENON_PREFS_FILE = os.path.join(os.path.dirname(_ADDIN_DIR), 'TenonCNC', 'tenon_prefs.json')
TENONS_CHANTS = [('longueur', 'Longueur (2 grands chants)'), ('largeur', 'Largeur (2 petits chants)'),
                 ('les_deux', 'Les deux (4 chants)')]
TENONS_MODES = [('tenons', 'Tenons'), ('languette', 'Languette')]
REP_MODES = [('uniforme', 'Uniforme'), ('personnalise', 'Personnalise (% cotes)')]


def _tenon_defaults():
    """Reglages de Tenons CNC (memes valeurs par defaut que sa boite)."""
    t = {}
    try:
        with open(TENON_PREFS_FILE, 'r', encoding='utf-8') as f:
            t = json.load(f)
    except Exception:
        pass
    return {
        't_count': int(t.get('tenon_count', 2)),
        't_len': '%s mm' % t.get('tenon_len_mm', 20),
        't_h': '%s mm' % t.get('tenon_h_mm', 12),
        't_edge': '%s mm' % t.get('edge_dist_mm', 10),
        't_centrer': bool(t.get('centrer', False)),
        't_rep_mode': t.get('repartition_mode', 'uniforme'),
        't_rep_pct': float(t.get('repartition_cotes_pct', 33.3)),
        't_lang_bord': '%s mm' % t.get('languette_bord_mm', 5),
        't_lang_h': '%s mm' % t.get('languette_h_mm', 12),
        't_mortaise': bool(t.get('mortaise_auto', False)),
        't_marge': bool(t.get('marge_auto', False)),
        't_dogbone': _dogbone_auto_defaut(),
    }


def _dogbone_auto_defaut():
    """Valeur initiale de "Dogbone auto" : celle de la case Dogbone auto du
    panneau Tenons CNC (dogbone_prefs.json, lu seulement)."""
    try:
        with open(DOGBONE_PREFS_FILE, 'r', encoding='utf-8') as f:
            return bool(json.load(f).get('auto_tenon', False))
    except Exception:
        return False

# Raccourcis contreplaque (demande de l'utilisateur le 2026-10-09) : un clic sur
# CP15 met le PARAMETRE UTILISATEUR "CP15" dans Distance, pour pouvoir
# changer l'epaisseur de toutes les pieces en fin de modelisation (Modifier >
# Changer les parametres). Si le parametre n'existe pas encore dans le
# document, on propose de le creer (CP15 = 15 mm) ; il est cree avec
# l'extrusion (donc annule avec elle si la commande est annulee).
CP_EPAISSEURS = ('10', '15', '18')

# Reglages de la derniere previsualisation valide - ecrits dans le JSON
# seulement si la commande se termine par OK (voir _DestroyHandler).
_pending_prefs = None

# Epaisseur ('15'...) dont le parametre CPxx doit etre cree avec l'extrusion
# (accepte par l'utilisateur dans la boite de dialogue), '' sinon.
_cp_a_creer = ''

# Comme l'Extrusion native (retour de l'utilisateur le 2026-10-09) : tant que la
# fleche n'a pas ete touchee, un clic sur une face l'ajoute aux profils ; des
# que la fleche (Distance) a ete utilisee, un clic sur une face sert a
# mesurer la hauteur jusqu'a elle SANS la selectionner - sauf avec CTRL
# enfonce, qui ajoute la face aux profils.
_fleche_active = False


def _ctrl_enfonce():
    try:
        import ctypes
        return bool(ctypes.windll.user32.GetKeyState(0x11) & 0x8000)
    except Exception:
        return False


def load_prefs():
    p = dict(DEFAULT_PREFS)
    try:
        with open(PREFS_FILE, 'r', encoding='utf-8') as f:
            saved = json.load(f)
        p.update({k: saved[k] for k in DEFAULT_PREFS if k in saved})
    except Exception:
        pass
    if any(v is None for v in p.values()):
        for k, v in _tenon_defaults().items():
            if p.get(k) is None:
                p[k] = v
    return p


def save_prefs(prefs):
    try:
        p = load_prefs()
        p.update({k: prefs[k] for k in DEFAULT_PREFS if k in prefs})
        tmp = PREFS_FILE + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(p, f, indent=2, ensure_ascii=False)
        os.replace(tmp, PREFS_FILE)
    except Exception:
        pass


# --- Construction des inputs ---------------------------------------------

# Icones natives de la boite Extrusion de Fusion (demande de l'utilisateur le
# 2026-10-09). Elles vivent dans l'installation Fusion, dont le chemin
# (webdeploy\production\<hash>) change a chaque mise a jour : on le retrouve
# a chaque demarrage via le resourceFolder de la commande native 'Extrude'
# (...\FusionUI\Resources\solid\extrude). Dossier absent = pas d'icone.
NATIVE_ICONS = {
    'start':     {'profil': 'Modeling/ExtrudeFrom/FromSketch', 'decalage': 'Modeling/ExtrudeFrom/FromOffset',
                  'objet': 'Modeling/ExtrudeFrom/FromObject'},
    'direction': {'un_cote': 'Modeling/RightSide', 'deux_cotes': 'Modeling/BothSide',
                  'symetrique': 'Modeling/Symmetric'},
    'extent':    {'distance': 'Modeling/ExtrudeExtents/distance', 'objet': 'Modeling/ExtrudeExtents/to',
                  'tout': 'Modeling/ExtrudeExtents/all'},
    'mesure':    {'demi': 'Modeling/ExtrudeSymmetry/HalfLength', 'totale': 'Modeling/ExtrudeSymmetry/FullLength'},
    'operation': {'joindre': 'Modeling/BooleanAdd', 'couper': 'Modeling/BooleanSubtract',
                  'intersection': 'Modeling/BooleanIntersect', 'nouveau_corps': 'Modeling/BooleanNewBody',
                  'nouveau_composant': 'Modeling/BooleanNewComponent'},
}


def _native_extrude_folder():
    try:
        f = _ui.commandDefinitions.itemById(NATIVE_EXTRUDE_ID).resourceFolder
        return f if f and os.path.isfile(os.path.join(f, '16x16.png')) else ''
    except Exception:
        return ''


def _native_icon(group, key):
    base = _native_extrude_folder()
    if not base:
        return ''
    resources = os.path.dirname(os.path.dirname(os.path.normpath(base)))
    rel = NATIVE_ICONS.get(group, {}).get(key)
    if not rel:
        return ''
    path = os.path.join(resources, *rel.split('/'))
    return path if os.path.isfile(os.path.join(path, '16x16.png')) else ''


def _dropdown(inputs, id_, label, items, current, icons=None):
    style = adsk.core.DropDownStyles.LabeledIconDropDownStyle if icons else \
        adsk.core.DropDownStyles.TextListDropDownStyle
    dd = inputs.addDropDownCommandInput(id_, label, style)
    keys = [k for k, _ in items]
    if current not in keys:
        current = keys[0]
    for k, txt in items:
        dd.listItems.add(txt, k == current, _native_icon(icons, k) if icons else '')
    return dd


def _dd_key(dd, items):
    sel = dd.selectedItem
    if sel is None:
        return items[0][0]
    for k, txt in items:
        if txt == sel.name:
            return k
    return items[0][0]


def _angle_value_input(expr, fallback):
    um = _app.activeProduct.unitsManager
    for e in (expr, fallback):
        try:
            if e and um.isValidExpression(e, 'deg'):
                return adsk.core.ValueInput.createByString(e)
        except Exception:
            continue
    return adsk.core.ValueInput.createByString(fallback)


def _valeur_doc(valeur_cm):
    """Valeur interne (cm) ecrite dans l'unite de longueur du document
    ("201.89265 mm" chez l'utilisateur), pour ne jamais afficher de cm."""
    um = _app.activeProduct.unitsManager
    unite = um.defaultLengthUnits
    try:
        v = um.convert(valeur_cm, 'cm', unite)
    except Exception:
        v, unite = valeur_cm * 10.0, 'mm'
    return ('%.6f' % v).rstrip('0').rstrip('.') + ' ' + unite


def _expr_unite_doc(expr):
    """Une valeur simple en cm ("20.189265 cm", sauvegardee par une ancienne
    version) est remise dans l'unite du document ; les expressions
    (CP15, ep*2, "18 mm"...) restent intactes."""
    import re
    if expr and re.match(r'^\s*-?\d+(\.\d+)?\s*cm\s*$', expr):
        try:
            if _app.activeProduct.unitsManager.defaultLengthUnits != 'cm':
                return _valeur_doc(float(expr.strip()[:-2]))
        except Exception:
            pass
    return expr


def _length_value_input(expr, fallback):
    um = _app.activeProduct.unitsManager
    expr = _expr_unite_doc(expr)
    for e in (expr, fallback):
        try:
            if e and um.isValidExpression(e, um.defaultLengthUnits):
                return adsk.core.ValueInput.createByString(e)
        except Exception:
            continue
    return adsk.core.ValueInput.createByString(fallback)


def _build_inputs(cmd):
    p = load_prefs()
    inputs = cmd.commandInputs

    sel = inputs.addSelectionInput('profils', 'Profil', 'Profils d\'esquisse ou faces planes a extruder')
    sel.addSelectionFilter('Profiles')
    sel.addSelectionFilter('PlanarFaces')
    sel.addSelectionFilter('Texts')
    sel.setSelectionLimits(1, 0)

    _dropdown(inputs, 'start', 'Debut', START_TYPES, p['start'], 'start')
    inputs.addValueInput('start_offset', 'Decalage', _app.activeProduct.unitsManager.defaultLengthUnits,
                         _length_value_input(p['start_offset'], '0 mm'))
    s_ent = inputs.addSelectionInput('start_entity', 'Objet de debut', 'Plan ou face de depart')
    s_ent.addSelectionFilter('PlanarFaces')
    s_ent.addSelectionFilter('ConstructionPlanes')
    s_ent.addSelectionFilter('Vertices')
    s_ent.addSelectionFilter('SketchPoints')
    s_ent.setSelectionLimits(0, 1)

    _dropdown(inputs, 'direction', 'Direction', DIRECTIONS, p['direction'], 'direction')

    for side in ('1', '2'):
        if side == '2':
            grp = inputs.addGroupCommandInput('cote2', 'Cote 2')
            grp.isExpanded = True
            sub = grp.children
        else:
            sub = inputs
        _dropdown(sub, 'extent' + side, "Type d'etendue", EXTENTS, p['extent' + side], 'extent')
        sub.addDistanceValueCommandInput('dist' + side, 'Distance',
                                         _length_value_input(p['dist' + side], '10 mm'))
        if side == '1':
            row = sub.addButtonRowCommandInput('cp', 'Contreplaque', False)
            for ep in CP_EPAISSEURS:
                actif = p['cp'] == ep and _cp_param(ep) is not None
                row.listItems.add('CP' + ep, actif, os.path.join(RESOURCES, 'cp' + ep))
            row.tooltip = ('Contreplaque : met le parametre CP10/CP15/CP18 dans Distance '
                           '(le cree s\'il n\'existe pas encore)')
        ent = sub.addSelectionInput('to_entity' + side, 'Objet', "Face, plan, corps ou sommet d'arret")
        for f in ('Faces', 'ConstructionPlanes', 'SolidBodies', 'Vertices', 'SketchPoints', 'ConstructionPoints'):
            ent.addSelectionFilter(f)
        ent.setSelectionLimits(0, 1)
        sub.addBoolValueInput('flip' + side, 'Inverser', True, '', bool(p['flip' + side]))
        sub.addAngleValueCommandInput('taper' + side, 'Angle de depouille',
                                      _angle_value_input(p['taper' + side], '0 deg'))
        if side == '1':
            _dropdown(inputs, 'mesure', 'Mesure', MESURES, p['mesure'], 'mesure')

    _dropdown(inputs, 'operation', 'Operation', OPERATIONS, p['operation'], 'operation')
    tgt = inputs.addSelectionInput('cibles', 'Objets', 'Corps a modifier (vide = tous les corps touches)')
    tgt.addSelectionFilter('SolidBodies')
    tgt.setSelectionLimits(0, 0)

    _build_tenons_inputs(inputs, p)

    msg = inputs.addTextBoxCommandInput('msg', '', '', 2, True)
    msg.isFullWidth = True
    msg.isVisible = False

    _update_visibility(inputs)


def _build_tenons_inputs(inputs, p):
    """Groupe "Tenons" : memes reglages et libelles que la boite Tenons CNC."""
    grp = inputs.addGroupCommandInput('grp_tenons', 'Tenons')
    grp.isExpanded = bool(p['tenons'])
    g = grp.children
    chk = g.addBoolValueInput('tenons', 'Ajouter des tenons', True, '', bool(p['tenons']))
    chk.tooltip = ('Ajoute des tenons (Tenons CNC) sur les chants de la piece extrudee, '
                   'au clic sur OK. Nouveau corps / Nouveau composant uniquement.')
    _dropdown(g, 'tenons_chants', 'Chants', TENONS_CHANTS, p['tenons_chants'])
    _dropdown(g, 'tenons_mode', 'Mode', TENONS_MODES, p['tenons_mode'])
    g.addIntegerSpinnerCommandInput('t_count', 'Nombre de tenons', 1, 200, 1, int(p['t_count']))
    g.addValueInput('t_len', 'Longueur du tenon', 'mm', _length_value_input(p['t_len'], '20 mm'))
    g.addValueInput('t_h', 'Hauteur du tenon (extrusion)', 'mm', _length_value_input(p['t_h'], '12 mm'))
    g.addValueInput('t_edge', 'Distance du bord', 'mm', _length_value_input(p['t_edge'], '10 mm'))
    g.addBoolValueInput('t_centrer', 'Centrer', True, '', bool(p['t_centrer']))
    _dropdown(g, 't_rep_mode', 'Mode de repartition', REP_MODES, p['t_rep_mode'])
    g.addFloatSpinnerCommandInput('t_rep_pct', 'Part sur les cotes (%)', '', 0.0, 100.0, 1.0,
                                  float(p['t_rep_pct']))
    g.addValueInput('t_lang_bord', 'Dist. bord (languette)', 'mm',
                    _length_value_input(p['t_lang_bord'], '5 mm'))
    g.addValueInput('t_lang_h', 'Hauteur languette', 'mm', _length_value_input(p['t_lang_h'], '12 mm'))
    m = g.addBoolValueInput('t_mortaise', 'MortaiseAuto', True, '', bool(p['t_mortaise']))
    m.tooltip = 'Mortaise automatique (add-in Mortaise CNC)'
    m = g.addBoolValueInput('t_marge', 'MargeAuto', True, '', bool(p['t_marge']))
    m.tooltip = 'Jeu de Marge CNC sur la mortaise creee (necessite MortaiseAuto)'
    m = g.addBoolValueInput('t_dogbone', 'Dogbone auto', True, '', bool(p['t_dogbone']))
    m.tooltip = ('Dogbones (reglages du panneau Dogbone CNC) sur les coins interieurs de la '
                 'piece et des pieces qui recoivent ses mortaises')


_TENONS_IDS = ('tenons_chants', 'tenons_mode', 't_count', 't_len', 't_h', 't_edge', 't_centrer',
               't_rep_mode', 't_rep_pct', 't_lang_bord', 't_lang_h', 't_mortaise', 't_marge')


def _update_tenons_visibility(inputs):
    on = bool(inputs.itemById('tenons').value)
    lang = _dd_key(inputs.itemById('tenons_mode'), TENONS_MODES) == 'languette'
    centrer = bool(inputs.itemById('t_centrer').value)
    perso = _dd_key(inputs.itemById('t_rep_mode'), REP_MODES) == 'personnalise'
    vis = {
        'tenons_chants': on, 'tenons_mode': on,
        't_count': on and not lang, 't_len': on and not lang, 't_h': on and not lang,
        't_edge': on and not lang and not centrer, 't_centrer': on and not lang,
        't_rep_mode': on and not lang and centrer, 't_rep_pct': on and not lang and centrer and perso,
        't_lang_bord': on and lang, 't_lang_h': on and lang,
        't_mortaise': on, 't_marge': on, 't_dogbone': on,
    }
    for k, v in vis.items():
        _show(inputs, k, v)


def _show(inputs, id_, visible):
    # N'ecrit isVisible que s'il change : chaque ecriture relance la mise en
    # page de la boite (saccades pendant le glisser de la fleche).
    inp = inputs.itemById(id_)
    if inp.isVisible != visible:
        inp.isVisible = visible


# Inputs dont le changement modifie les champs affiches (voir _InputChangedHandler).
_INPUTS_AFFICHAGE = ('start', 'direction', 'extent1', 'extent2', 'operation',
                     'tenons', 'tenons_mode', 't_centrer', 't_rep_mode')


def _update_visibility(inputs):
    start = _dd_key(inputs.itemById('start'), START_TYPES)
    direction = _dd_key(inputs.itemById('direction'), DIRECTIONS)
    op = _dd_key(inputs.itemById('operation'), OPERATIONS)
    _show(inputs, 'start_offset', start == 'decalage')
    _show(inputs, 'start_entity', start == 'objet')
    _show(inputs, 'cote2', direction == 'deux_cotes')
    _show(inputs, 'mesure', direction == 'symetrique')
    for side in ('1', '2'):
        ext = _dd_key(inputs.itemById('extent' + side), EXTENTS)
        if side == '1' and direction == 'symetrique':
            ext = 'distance'
            _show(inputs, 'extent1', False)
        elif side == '1':
            _show(inputs, 'extent1', True)
        # Cote 2 masque explicitement hors "Deux cotes" : masquer seulement le
        # groupe laissait sa fleche (vers le bas) dans la vue 3D.
        actif = side == '1' or direction == 'deux_cotes'
        _show(inputs, 'dist' + side, actif and ext == 'distance')
        _show(inputs, 'to_entity' + side, actif and ext == 'objet')
        # Pour "Distance", une valeur negative inverse deja le sens (comme
        # dans Fusion) ; "Inverser" sert pour "Tout" et "A l'objet".
        _show(inputs, 'flip' + side, ext == 'tout' and direction == 'un_cote')
    _show(inputs, 'cibles', op in ('joindre', 'couper', 'intersection'))
    _update_tenons_visibility(inputs)


def _cp_param(ep):
    """Parametre utilisateur CPxx du document actif, ou None."""
    try:
        design = adsk.fusion.Design.cast(_app.activeProduct)
        return design.userParameters.itemByName('CP' + ep)
    except Exception:
        return None


def _cp_pending(inputs):
    """Epaisseur dont le parametre est a creer, si la distance vaut toujours
    cette epaisseur (sinon l'utilisateur l'a retouchee a la main)."""
    if not _cp_a_creer:
        return ''
    try:
        if abs(abs(inputs.itemById('dist1').value) - float(_cp_a_creer) / 10.0) > 1e-6:
            return ''
    except Exception:
        return ''
    return _cp_a_creer


def _cp_selected(inputs):
    """Epaisseur CP utilisee par Distance ('10', '15', '18') ou ''."""
    pend = _cp_pending(inputs)
    if pend:
        return pend
    expr = inputs.itemById('dist1').expression.replace(' ', '').lstrip('-')
    for ep in CP_EPAISSEURS:
        if expr == 'CP' + ep:
            return ep
    return ''


def _dist1_expression(inputs):
    """Expression de Distance (cote 1) a donner a l'extrusion : 'CP15' (ou
    '-CP15') quand le parametre est a creer, sinon celle de la boite."""
    d = inputs.itemById('dist1')
    pend = _cp_pending(inputs)
    if pend:
        return ('-' if d.value < 0 else '') + 'CP' + pend
    # Distance prise en cliquant une face : la valeur peut changer sans que
    # l'expression suive (elle restait "CP15"). Dans ce cas la valeur gagne.
    try:
        um = _app.activeProduct.unitsManager
        if abs(um.evaluateExpression(d.expression, 'cm') - d.value) > 1e-6:
            return _valeur_doc(d.value)
    except Exception:
        return _valeur_doc(d.value)
    return d.expression


# Journal temporaire de diagnostic (fluidite / distance mesuree), a lire
# apres l'essai de l'utilisateur du 2026-10-09 puis a retirer.
JOURNAL = os.path.join(_ADDIN_DIR, 'extrusion_journal.txt')


def _journal(evenement, inputs, ms):
    try:
        d = inputs.itemById('dist1')
        row = inputs.itemById('cp')
        cp = row.selectedItem.name if row is not None and row.selectedItem is not None else ''
        ligne = '%s %-8s %6.1f ms  expr=%r value_cm=%.4f utilise=%r cp=%s a_creer=%r op=%s\n' % (
            time.strftime('%H:%M:%S'), evenement, ms, d.expression, d.value, _dist1_expression(inputs),
            cp, _cp_a_creer, _dd_key(inputs.itemById('operation'), OPERATIONS))
        with open(JOURNAL, 'a', encoding='utf-8') as f:
            f.write(ligne)
    except Exception:
        pass


def _ensure_cp_param(inputs):
    """Cree le parametre CPxx accepte par l'utilisateur (dans la meme
    transaction que l'extrusion)."""
    pend = _cp_pending(inputs)
    if pend and _cp_param(pend) is None:
        design = adsk.fusion.Design.cast(_app.activeProduct)
        design.userParameters.add('CP' + pend, adsk.core.ValueInput.createByString(pend + ' mm'),
                                  'mm', 'Epaisseur contreplaque %s mm (Extrusion CNC)' % pend)


def _apply_cp(inputs):
    global _cp_a_creer
    row = inputs.itemById('cp')
    sel = row.selectedItem
    if sel is None:
        return
    ep = sel.name[2:]
    ext = inputs.itemById('extent1')
    for i in range(ext.listItems.count):
        it = ext.listItems.item(i)
        if it.name == dict(EXTENTS)['distance']:
            it.isSelected = True
    d = inputs.itemById('dist1')
    signe = '-' if d.value < 0 else ''
    if _cp_a_creer == ep:
        # Deja accepte dans cette commande (le parametre n'existe que dans
        # l'apercu) : on ne repose pas la question.
        d.expression = signe + ep + ' mm'
        return
    if _cp_param(ep) is not None:
        _cp_a_creer = ''
        d.expression = signe + 'CP' + ep
        return
    rep = _ui.messageBox(
        "Le parametre CP%s n'existe pas encore dans ce document.\n\n"
        "Le creer (CP%s = %s mm) ?\n\n"
        "Tu pourras changer cette epaisseur plus tard pour toutes les pieces "
        "dans Modifier > Changer les parametres." % (ep, ep, ep),
        COMMAND_NAME, adsk.core.MessageBoxButtonTypes.YesNoButtonType,
        adsk.core.MessageBoxIconTypes.QuestionIconType)
    d.expression = signe + ep + ' mm'
    if rep == adsk.core.DialogResults.DialogYes:
        _cp_a_creer = ep
    else:
        # Simple valeur, sans parametre : le bouton ne reste pas actif.
        _cp_a_creer = ''
        try:
            sel.isSelected = False
        except Exception:
            pass


def _sync_cp_row(inputs):
    """Distance retouchee a la main : on deselectionne le bouton CP."""
    global _cp_a_creer
    if _cp_a_creer and not _cp_pending(inputs):
        _cp_a_creer = ''
    row = inputs.itemById('cp')
    sel = row.selectedItem
    if sel is not None and _cp_selected(inputs) != sel.name[2:]:
        try:
            sel.isSelected = False
        except Exception:
            pass


def _current_prefs(inputs):
    p = {
        'cp': _cp_selected(inputs),
        'start': _dd_key(inputs.itemById('start'), START_TYPES),
        'start_offset': inputs.itemById('start_offset').expression,
        'direction': _dd_key(inputs.itemById('direction'), DIRECTIONS),
        'mesure': _dd_key(inputs.itemById('mesure'), MESURES),
        'operation': _dd_key(inputs.itemById('operation'), OPERATIONS),
    }
    for side in ('1', '2'):
        p['extent' + side] = _dd_key(inputs.itemById('extent' + side), EXTENTS)
        p['dist' + side] = inputs.itemById('dist' + side).expression
        p['taper' + side] = inputs.itemById('taper' + side).expression
        p['flip' + side] = bool(inputs.itemById('flip' + side).value)
    p['dist1'] = _dist1_expression(inputs)
    p.update({
        'tenons': bool(inputs.itemById('tenons').value),
        'tenons_chants': _dd_key(inputs.itemById('tenons_chants'), TENONS_CHANTS),
        'tenons_mode': _dd_key(inputs.itemById('tenons_mode'), TENONS_MODES),
        't_count': int(inputs.itemById('t_count').value),
        't_len': inputs.itemById('t_len').expression,
        't_h': inputs.itemById('t_h').expression,
        't_edge': inputs.itemById('t_edge').expression,
        't_centrer': bool(inputs.itemById('t_centrer').value),
        't_rep_mode': _dd_key(inputs.itemById('t_rep_mode'), REP_MODES),
        't_rep_pct': float(inputs.itemById('t_rep_pct').value),
        't_lang_bord': inputs.itemById('t_lang_bord').expression,
        't_lang_h': inputs.itemById('t_lang_h').expression,
        't_mortaise': bool(inputs.itemById('t_mortaise').value),
        't_marge': bool(inputs.itemById('t_marge').value),
        't_dogbone': bool(inputs.itemById('t_dogbone').value),
    })
    return p


# --- Option tenons (via Tenons CNC) -----------------------------------------

def _tenon_mod():
    """Module Tenons CNC deja charge par Fusion (meme recherche que le
    lanceur), ou None."""
    import sys
    for k, m in list(sys.modules.items()):
        if k.endswith('TenonCNC_py') and 'TenonMortaise' not in k:
            return m
    return None


def _tenons_actifs(inputs):
    return bool(inputs.itemById('tenons').value) and \
        _dd_key(inputs.itemById('operation'), OPERATIONS) in ('nouveau_corps', 'nouveau_composant')


def _chants(feat, inputs):
    """Faces laterales (chants) de la piece extrudee a equiper de tenons,
    en contexte assemblage (proxies) si la piece est dans un composant.
    Retourne (faces, message)."""
    # On raisonne sur le PANNEAU (pave a 6 faces), pas sur les faces laterales
    # de l'extrusion : l'utilisateur dessine souvent la section (epaisseur x
    # longueur) et extrude la largeur - les faces laterales contiennent alors
    # les grandes faces du panneau (retour du 2026-10-09). Tri par aire : les
    # 2 plus grandes = faces du panneau, puis 2 chants de longueur, puis 2
    # chants de largeur.
    body = feat.bodies.item(0) if feat.bodies.count else None
    faces6 = [f for f in body.faces] if body else []
    if len(faces6) != 6 or any(f.geometry.surfaceType != adsk.core.SurfaceTypes.PlaneSurfaceType
                               for f in faces6):
        return [], ("Tenons : la piece n'est pas un panneau rectangulaire (%d faces) - ajoute "
                    "les tenons ensuite avec Tenons CNC." % len(faces6))
    faces = _classer_chants(faces6, _dd_key(inputs.itemById('tenons_chants'), TENONS_CHANTS))
    try:
        comp = faces[0].body.parentComponent
        design = adsk.fusion.Design.cast(_app.activeProduct)
        if comp != design.rootComponent:
            occs = design.rootComponent.allOccurrencesByComponent(comp)
            if occs.count:
                faces = [f.createForAssemblyContext(occs.item(0)) for f in faces]
    except Exception:
        pass
    return faces, ''


def _normale(face):
    n = face.geometry.normal
    return (n.x, n.y, n.z)


def _classer_chants(faces6, choix):
    """Chants choisis (Longueur / Largeur / Les deux) parmi les 6 faces planes
    d'un panneau - MEME regle pour l'apercu (pave temporaire) et pour la vraie
    piece. Les 2 plus grandes faces sont les faces du panneau ; les 4 autres
    forment 2 paires de chants opposes. Longueur = la paire la plus longue.
    Panneau carre (paires egales a 1 % pres, retour de l'utilisateur du 2026-10-12) :
    le tri par aire etait alors au hasard, d'ou des tenons sur les mauvais
    chants. Regle : Longueur = les chants qui courent le long de l'axe X du
    modele (a defaut Y, puis Z)."""
    faces6 = sorted(faces6, key=lambda f: f.area, reverse=True)
    np_ = _normale(faces6[0])
    chants = faces6[2:6]
    n0 = _normale(chants[0])
    paire1 = [f for f in chants if abs(sum(a * b for a, b in zip(_normale(f), n0))) > 0.99]
    paire2 = [f for f in chants if f not in paire1]
    if len(paire1) != 2 or len(paire2) != 2:
        paire1, paire2 = chants[:2], chants[2:]
    a1 = sum(f.area for f in paire1) / 2.0
    a2 = sum(f.area for f in paire2) / 2.0
    if abs(a1 - a2) > 0.01 * max(a1, a2):
        longueur, largeur = (paire1, paire2) if a1 > a2 else (paire2, paire1)
    else:
        def axe(paire):
            nc = _normale(paire[0])
            d = (np_[1] * nc[2] - np_[2] * nc[1], np_[2] * nc[0] - np_[0] * nc[2],
                 np_[0] * nc[1] - np_[1] * nc[0])
            return tuple(round(abs(c), 6) for c in d)
        longueur, largeur = (paire1, paire2) if axe(paire1) >= axe(paire2) else (paire2, paire1)
    if choix == 'longueur':
        return longueur
    if choix == 'largeur':
        return largeur
    return longueur + largeur


def _tenon_args(inputs):
    lang = _dd_key(inputs.itemById('tenons_mode'), TENONS_MODES) == 'languette'
    return {
        'mode': 'languette' if lang else 'tenons',
        'edge_dist': inputs.itemById('t_edge').value,
        'count': int(inputs.itemById('t_count').value),
        'tenon_len': inputs.itemById('t_len').value,
        'tenon_h': inputs.itemById('t_h').value,
        'languette_bord': inputs.itemById('t_lang_bord').value,
        'languette_h': inputs.itemById('t_lang_h').value,
        'centrer': bool(inputs.itemById('t_centrer').value),
        'repartition_mode': _dd_key(inputs.itemById('t_rep_mode'), REP_MODES),
        'repartition_cotes_pct': float(inputs.itemById('t_rep_pct').value),
        'mortaise_auto': bool(inputs.itemById('t_mortaise').value),
        'marge_auto': bool(inputs.itemById('t_marge').value),
    }


def _apercu_tenons(feat, inputs):
    """Traits orange de Tenons CNC sur les chants du corps de l'apercu.
    Retourne un message ('' si tout va bien)."""
    tm = _tenon_mod()
    if not _tenons_actifs(inputs):
        if tm:
            tm._clear_preview_graphics()
        if inputs.itemById('tenons').value:
            return 'Tenons : seulement en Nouveau corps ou Nouveau composant.'
        return ''
    if tm is None:
        return 'Tenons : add-in "Tenons CNC" inactif.'
    faces, msg = _chants(feat, inputs)
    if not faces:
        tm._clear_preview_graphics()
        return msg
    a = _tenon_args(inputs)
    tm._draw_tenon_preview_graphics(
        faces, a['edge_dist'], a['count'], a['tenon_len'], a['tenon_h'], a['centrer'],
        a['repartition_mode'], a['repartition_cotes_pct'], a['mode'] == 'languette',
        a['languette_bord'], a['languette_h'], adsk.fusion.Design.cast(_app.activeProduct))
    return ''


def _creer_tenons(feat, inputs):
    """Au clic OK : tenons via Tenons CNC (create_tenons_core), qui regroupe
    lui-meme dans l'historique tout ce qu'il cree (groupe "Tenon CNC") a
    partir de l'etape qui suit l'extrusion - l'extrusion reste hors groupe.
    Retourne un message pour l'utilisateur ('' si rien a dire)."""
    tm = _tenon_mod()
    if tm is None:
        return 'Tenons non crees : add-in "Tenons CNC" inactif.'
    tm._clear_preview_graphics()
    faces, msg = _chants(feat, inputs)
    if not faces:
        return msg
    a = _tenon_args(inputs)
    design = adsk.fusion.Design.cast(_app.activeProduct)
    piece = faces[0].body
    voisins = _corps_en_contact(design, piece)
    # Mortaises attendues : memes criteres que MortaiseCNC (recouvrement reel
    # des boites englobantes), mesures APRES les tenons (voir plus bas).
    dog = _dogbone_mod() if inputs.itemById('t_dogbone').value else None
    dog_cles = None
    if dog is not None:
        try:
            dog_cles = dog.body_keys([piece] + voisins)
        except Exception:
            dog_cles = None
    res = tm.create_tenons_core(
        design, faces, a['mode'], a['edge_dist'], a['count'], a['tenon_len'], a['tenon_h'],
        a['languette_bord'], a['languette_h'], a['centrer'], a['repartition_mode'],
        a['repartition_cotes_pct'], a['mortaise_auto'], a['marge_auto'])
    problemes = _problemes_tenons(res, a, piece, voisins)
    if inputs.itemById('t_dogbone').value:
        if dog is None:
            problemes.append('Dogbone auto : add-in "Dogbone CNC" introuvable - aucun dogbone cree.')
        elif dog_cles:
            try:
                r = dog.auto_dogbones(design, dog_cles)
                if isinstance(r, dict) and r.get('error'):
                    problemes.append('Dogbone auto : %s' % r['error'])
            except Exception:
                problemes.append('Dogbone auto : ' + traceback.format_exc().strip().splitlines()[-1])
    return '\n'.join(problemes)


def _corps_en_contact(design, piece, tol=0.05):
    """Corps dont la boite englobante touche celle de la piece (pieces qui
    peuvent recevoir une mortaise), comme le fait le lanceur pour Dogbone."""
    try:
        m = piece.boundingBox
    except Exception:
        return []
    root = design.rootComponent
    candidats = list(root.bRepBodies)
    for occ in root.allOccurrences:
        try:
            candidats.extend(list(occ.bRepBodies))
        except Exception:
            pass
    out = []
    for b in candidats:
        try:
            if b.entityToken == piece.entityToken:
                continue
            bb = b.boundingBox
            if (bb.minPoint.x <= m.maxPoint.x + tol and bb.maxPoint.x >= m.minPoint.x - tol and
                    bb.minPoint.y <= m.maxPoint.y + tol and bb.maxPoint.y >= m.minPoint.y - tol and
                    bb.minPoint.z <= m.maxPoint.z + tol and bb.maxPoint.z >= m.minPoint.z - tol):
                out.append(b)
        except Exception:
            pass
    return out


def _problemes_tenons(res, a, piece, voisins):
    """Seulement les VRAIS problemes (retour de l'utilisateur du 2026-10-10) : pas
    de message quand MortaiseAuto/MargeAuto ne trouvent aucune piece
    receptrice (c'est voulu), ni pour les comptes rendus normaux."""
    out = []
    msgs = res.get('messages') or []
    if res.get('n_faces_ok', 0) < res.get('n_faces_total', 0):
        out.append('Tenons : %s chant(s) sur %s seulement.' % (res.get('n_faces_ok'), res.get('n_faces_total')))
        out += [m for m in msgs if m.startswith('Chant')]
    out += [m for m in msgs if not m.startswith('Chant') and ('inactif' in m or 'erreur' in m.lower())]
    nb_ok = res.get('mortaise_nb_ok') or 0
    if a['mortaise_auto']:
        # Pieces qui recoivent reellement un tenon (recouvrement, pas simple
        # contact) mais sans mortaise creee.
        attendues = 0
        mc = _module_addin('MortaiseCNC')
        if mc is not None:
            for v in voisins:
                try:
                    if mc._bbox_overlap(piece, v):
                        attendues += 1
                except Exception:
                    pass
        if attendues > nb_ok:
            out.append('MortaiseAuto : %d mortaise(s) non creee(s) sur %d piece(s) traversee(s) par les tenons.'
                       % (attendues - nb_ok, attendues))
    if a['mortaise_auto'] and a['marge_auto'] and nb_ok:
        mg = _module_addin('MargeCNC')
        jeu_actif = True
        try:
            jeu_actif = bool(mg.load_settings()[1]) if mg is not None else True
        except Exception:
            pass
        if jeu_actif and not res.get('marge_n_faces'):
            out.append('MargeAuto : aucun jeu applique sur les %d mortaise(s) creee(s).' % nb_ok)
    return out


def _module_addin(nom):
    import sys
    for k, m in list(sys.modules.items()):
        if k.endswith('%2F' + nom + '_py') or k == nom:
            return m
    return None


def _dogbone_mod():
    """Module Dogbone CNC, demarre a la demande par le lanceur s'il ne l'est
    pas encore (comme le panneau Tenons CNC)."""
    m = _module_addin('DogboneCNC')
    if m is not None:
        return m
    lanceur = _module_addin('ToolkitCNC')
    try:
        return lanceur._ensure_module('DogboneCNC') if lanceur is not None else None
    except Exception:
        return None


def _selections(sel_input):
    return [sel_input.selection(i).entity for i in range(sel_input.selectionCount)]


# --- Manipulateur (fleche de distance dans la vue 3D) ----------------------

def _profile_origin_normal(entity):
    """Point et normale (espace modele) du premier profil/face selectionne,
    pour placer la fleche des DistanceValueCommandInput."""
    if isinstance(entity, adsk.fusion.BRepFace):
        pt = entity.pointOnFace
        ok, n = entity.evaluator.getNormalAtPoint(pt)
        return (pt, n) if ok else (None, None)
    sk = None
    if isinstance(entity, adsk.fusion.Profile):
        sk = entity.parentSketch
        c = entity.areaProperties(adsk.fusion.CalculationAccuracy.LowCalculationAccuracy).centroid
    elif isinstance(entity, adsk.fusion.SketchText):
        sk = entity.parentSketch
        bb = entity.boundingBox
        c = adsk.core.Point3D.create((bb.minPoint.x + bb.maxPoint.x) / 2, (bb.minPoint.y + bb.maxPoint.y) / 2, 0)
    if sk is None:
        return None, None
    m = sk.transform.copy()
    if entity.assemblyContext is not None:
        m.transformBy(entity.assemblyContext.transform2)
    pt = c.copy()
    pt.transformBy(m)
    n = adsk.core.Vector3D.create(0, 0, 1)
    n.transformBy(m)
    n.normalize()
    return pt, n


def _place_manipulators(inputs):
    sel = _selections(inputs.itemById('profils'))
    if not sel:
        return
    try:
        pt, n = _profile_origin_normal(sel[0])
        if pt is None:
            return
        inputs.itemById('dist1').setManipulator(pt, n)
        # Fleche du cote 2 (vers le bas) seulement en "Deux cotes".
        if _dd_key(inputs.itemById('direction'), DIRECTIONS) == 'deux_cotes':
            n2 = n.copy()
            n2.scaleBy(-1)
            inputs.itemById('dist2').setManipulator(pt, n2)
    except Exception:
        pass


# --- Creation de la fonction ----------------------------------------------

def _extent_def(inputs, side, direction_key):
    ext = _dd_key(inputs.itemById('extent' + side), EXTENTS)
    if direction_key == 'symetrique':
        ext = 'distance'
    if ext == 'objet':
        ents = _selections(inputs.itemById('to_entity' + side))
        if not ents:
            raise ValueError("Choisis l'objet d'arret (cote %s)." % side)
        d = adsk.fusion.ToEntityExtentDefinition.create(ents[0], False)
        return d, None
    if ext == 'tout':
        return adsk.fusion.AllExtentDefinition.create(), None
    di = inputs.itemById('dist' + side)
    expr = _dist1_expression(inputs) if side == '1' else di.expression
    return adsk.fusion.DistanceExtentDefinition.create(adsk.core.ValueInput.createByString(expr)), di.value


def build_extrude(inputs, apercu=False):
    """apercu=True (executePreview) : "Nouveau composant" est previsualise en
    simple nouveau corps - creer un composant a chaque mouvement de la fleche
    (arbre du navigateur, occurrence) faisait saccader l'apercu. Le vrai
    composant est cree au clic OK (execute)."""
    design = adsk.fusion.Design.cast(_app.activeProduct)
    comp = design.activeComponent
    profils = _selections(inputs.itemById('profils'))
    if not profils:
        raise ValueError('Selectionne un profil ou une face.')
    if len(profils) == 1:
        prof = profils[0]
    else:
        prof = adsk.core.ObjectCollection.create()
        for e in profils:
            prof.add(e)

    op_key = _dd_key(inputs.itemById('operation'), OPERATIONS)
    op = {
        'joindre': adsk.fusion.FeatureOperations.JoinFeatureOperation,
        'couper': adsk.fusion.FeatureOperations.CutFeatureOperation,
        'intersection': adsk.fusion.FeatureOperations.IntersectFeatureOperation,
        'nouveau_corps': adsk.fusion.FeatureOperations.NewBodyFeatureOperation,
        'nouveau_composant': adsk.fusion.FeatureOperations.NewComponentFeatureOperation,
    }[op_key]
    if apercu and op_key == 'nouveau_composant':
        op = adsk.fusion.FeatureOperations.NewBodyFeatureOperation
    _ensure_cp_param(inputs)
    ext_input = comp.features.extrudeFeatures.createInput(prof, op)

    start = _dd_key(inputs.itemById('start'), START_TYPES)
    if start == 'decalage':
        ext_input.startExtent = adsk.fusion.OffsetStartDefinition.create(
            adsk.core.ValueInput.createByString(inputs.itemById('start_offset').expression))
    elif start == 'objet':
        ents = _selections(inputs.itemById('start_entity'))
        if not ents:
            raise ValueError("Choisis l'objet de debut.")
        ext_input.startExtent = adsk.fusion.EntityStartDefinition.create(
            ents[0], adsk.core.ValueInput.createByReal(0))

    direction = _dd_key(inputs.itemById('direction'), DIRECTIONS)
    taper1 = adsk.core.ValueInput.createByString(inputs.itemById('taper1').expression)
    if direction == 'symetrique':
        full = _dd_key(inputs.itemById('mesure'), MESURES) == 'totale'
        ext_input.setSymmetricExtent(
            adsk.core.ValueInput.createByString(_dist1_expression(inputs)), full, taper1)
    elif direction == 'deux_cotes':
        e1, _ = _extent_def(inputs, '1', direction)
        e2, _ = _extent_def(inputs, '2', direction)
        taper2 = adsk.core.ValueInput.createByString(inputs.itemById('taper2').expression)
        ext_input.setTwoSidesExtent(e1, e2, taper1, taper2)
    else:
        e1, val = _extent_def(inputs, '1', direction)
        sens = adsk.fusion.ExtentDirections.PositiveExtentDirection
        if isinstance(e1, adsk.fusion.AllExtentDefinition) and inputs.itemById('flip1').value:
            sens = adsk.fusion.ExtentDirections.NegativeExtentDirection
        if val is not None and val < 0:
            # Distance negative = sens oppose, comme dans la boite native.
            # "-CP15" -> "CP15" en sens negatif, pour garder le lien au parametre.
            expr = _dist1_expression(inputs).strip()
            vi = adsk.core.ValueInput.createByString(expr[1:]) if expr.startswith('-') \
                else adsk.core.ValueInput.createByReal(-val)
            e1 = adsk.fusion.DistanceExtentDefinition.create(vi)
            sens = adsk.fusion.ExtentDirections.NegativeExtentDirection
        ext_input.setOneSideExtent(e1, sens, taper1)

    if op_key in ('joindre', 'couper', 'intersection'):
        cibles = _selections(inputs.itemById('cibles'))
        if cibles:
            ext_input.participantBodies = cibles

    feat = comp.features.extrudeFeatures.add(ext_input)
    _garder_esquisses_visibles(profils)
    return feat


def _garder_esquisses_visibles(profils):
    """L'extrusion par l'API masque l'esquisse utilisee, meme avec la
    preference Fusion "Masquer automatiquement l'esquisse" decochee : l'utilisateur
    veut la garder affichee pendant l'apercu et apres OK (2026-10-09)."""
    for e in profils:
        sk = getattr(e, 'parentSketch', None)
        try:
            if sk is not None and not sk.isVisible:
                sk.isVisible = True
        except Exception:
            pass


# --- Handlers -------------------------------------------------------------

# --- Apercu "fantome" (2026-10-09) -------------------------------------------
# Une vraie extrusion recalculee a chaque mouvement de la fleche saccadait
# (22 a 85 ms par apercu, mesure sur l'essai de l'utilisateur). En Nouveau corps /
# Nouveau composant, l'apercu ne cree donc plus de fonction : il dessine un
# volume gris semi-transparent (CustomGraphics) calcule a partir du profil,
# mis en cache tant que le profil ne change pas. La vraie extrusion (et les
# tenons) n'est creee qu'au clic OK. Les cas que le fantome ne sait pas
# montrer (A l'objet, Tout, depouille, debut sur objet, Joindre/Couper/
# Intersection, texte) gardent l'apercu reel.

_fantome_groupe = None
_fantome_cache = {}


def _effacer_fantome():
    global _fantome_groupe, _fantome_cg
    try:
        if _fantome_groupe is not None and _fantome_groupe.isValid:
            _fantome_groupe.deleteMe()
    except Exception:
        pass
    _fantome_groupe = None
    _fantome_cg = None


def _fantome_possible(inputs):
    if _dd_key(inputs.itemById('operation'), OPERATIONS) not in ('nouveau_corps', 'nouveau_composant'):
        return False
    if _dd_key(inputs.itemById('start'), START_TYPES) == 'objet':
        return False
    direction = _dd_key(inputs.itemById('direction'), DIRECTIONS)
    cotes = ('1', '2') if direction == 'deux_cotes' else ('1',)
    for s in cotes:
        if direction != 'symetrique' and _dd_key(inputs.itemById('extent' + s), EXTENTS) != 'distance':
            return False
        if abs(inputs.itemById('taper' + s).value) > 1e-9:
            return False
    for e in _selections(inputs.itemById('profils')):
        if not isinstance(e, (adsk.fusion.Profile, adsk.fusion.BRepFace)):
            return False
    return True


def _intervalle(inputs):
    """[a, b] (cm) le long de la normale du profil, comme l'extrusion reelle."""
    s = 0.0
    if _dd_key(inputs.itemById('start'), START_TYPES) == 'decalage':
        s = inputs.itemById('start_offset').value
    d = inputs.itemById('dist1').value
    direction = _dd_key(inputs.itemById('direction'), DIRECTIONS)
    if direction == 'symetrique':
        h = d / 2.0 if _dd_key(inputs.itemById('mesure'), MESURES) == 'totale' else d
        return s - abs(h), s + abs(h)
    if direction == 'deux_cotes':
        return s - inputs.itemById('dist2').value, s + d
    return (s, s + d) if d >= 0 else (s + d, s)


def _face_temporaire(entity):
    """Corps temporaire (une face plane, en coordonnees modele) du profil."""
    tbm = adsk.fusion.TemporaryBRepManager.get()
    if isinstance(entity, adsk.fusion.BRepFace):
        return tbm.copy(entity)
    sk = entity.parentSketch
    m = sk.transform.copy()
    if entity.assemblyContext is not None:
        m.transformBy(entity.assemblyContext.transform2)
    fils = []
    for boucle in entity.profileLoops:
        courbes = []
        for pc in boucle.profileCurves:
            c = pc.geometry.copy()
            c.transformBy(m)
            courbes.append(c)
        fil, _ = tbm.createWireFromCurves(courbes, False)
        fils.append(fil)
    return tbm.createFaceFromPlanarWires(fils)


def _base_fantome(profils):
    """Triangles, segments de contour et normale des profils (en cache)."""
    global _fantome_cache
    cle = tuple(e.entityToken for e in profils)
    if _fantome_cache.get('cle') == cle:
        return _fantome_cache
    pt0, n = _profile_origin_normal(profils[0])
    tris, segs, rect = [], [], None
    corps = [_face_temporaire(e) for e in profils]
    for b in corps:
        calc = b.meshManager.createMeshCalculator()
        calc.setQuality(adsk.fusion.TriangleMeshQualityOptions.LowQualityTriangleMesh)
        mesh = calc.calculate()
        xyz = mesh.nodeCoordinatesAsDouble
        for i in mesh.nodeIndices:
            tris.append((xyz[3 * i], xyz[3 * i + 1], xyz[3 * i + 2]))
        for ed in b.edges:
            ev = ed.evaluator
            ok, p0, p1 = ev.getParameterExtents()
            ok, pts = ev.getStrokes(p0, p1, 0.01)
            for k in range(len(pts) - 1):
                segs.append(((pts[k].x, pts[k].y, pts[k].z), (pts[k + 1].x, pts[k + 1].y, pts[k + 1].z)))
    # Panneau rectangulaire (cas des tenons) : vrai pave temporaire, pour un
    # rendu propre et pour dessiner les tenons sur ses chants.
    if len(corps) == 1 and corps[0].edges.count == 4 and \
            all(isinstance(e.geometry, adsk.core.Line3D) for e in corps[0].edges):
        e0 = corps[0].edges.item(0).geometry
        u = e0.startPoint.vectorTo(e0.endPoint)
        lu = u.length
        u.normalize()
        v = n.crossProduct(u)
        xs = []
        for ed in corps[0].edges:
            g = ed.geometry
            xs += [g.startPoint, g.endPoint]
        pu = [pt0.vectorTo(p).dotProduct(u) for p in xs]
        pv = [pt0.vectorTo(p).dotProduct(v) for p in xs]
        lv = max(pv) - min(pv)
        if abs((max(pu) - min(pu)) - lu) < 1e-6 and abs(lu * lv - corps[0].faces.item(0).area) < 1e-6:
            c = pt0.copy()
            du = u.copy(); du.scaleBy((max(pu) + min(pu)) / 2.0)
            dv = v.copy(); dv.scaleBy((max(pv) + min(pv)) / 2.0)
            c.translateBy(du); c.translateBy(dv)
            rect = (c, u, v, lu, lv)
    _fantome_cache = {'cle': cle, 'n': n, 'p0': pt0, 'tris': tris, 'segs': segs, 'rect': rect}
    return _fantome_cache


def _pave_reel(base, a, b):
    """Pave temporaire aux vraies dimensions (pour les chants des tenons)."""
    c, u, v, lu, lv = base['rect']
    centre = c.copy()
    dn = base['n'].copy(); dn.scaleBy((a + b) / 2.0)
    centre.translateBy(dn)
    obb = adsk.core.OrientedBoundingBox3D.create(centre, u, v, lu, lv, max(abs(b - a), 1e-4))
    return adsk.fusion.TemporaryBRepManager.get().createBox(obb)


def _matrice_fantome(base, a, b):
    """Transformation qui etire le fantome "unitaire" (epaisseur 1 cm posee
    sur le plan du profil) jusqu'a l'intervalle [a, b] le long de la normale :
    p' = p + ((s - 1) * (p.n - p0.n) + a) n, avec s = b - a."""
    n, p0 = base['n'], base['p0']
    s = max(b - a, 1e-4)
    k = s - 1.0
    nx, ny, nz = n.x, n.y, n.z
    c0 = p0.x * nx + p0.y * ny + p0.z * nz
    t = a - k * c0
    m = adsk.core.Matrix3D.create()
    m.setWithArray([1 + k * nx * nx, k * nx * ny, k * nx * nz, t * nx,
                    k * ny * nx, 1 + k * ny * ny, k * ny * nz, t * ny,
                    k * nz * nx, k * nz * ny, 1 + k * nz * nz, t * nz,
                    0, 0, 0, 1])
    return m


_fantome_cg = None
_fantome_cg_cle = None


def _dessiner_fantome(inputs, avec_pave=False):
    """Dessine le volume fantome. La geometrie est construite UNE fois par
    profil (epaisseur 1 cm) puis seulement etiree par une transformation a
    chaque mouvement de la fleche (rien a recalculer ni a recreer). Retourne
    le pave temporaire aux vraies dimensions si avec_pave et que la piece est
    rectangulaire (pour les tenons), sinon None."""
    global _fantome_groupe, _fantome_cg, _fantome_cg_cle
    base = _base_fantome(_selections(inputs.itemById('profils')))
    a, b = _intervalle(inputs)
    pave = _pave_reel(base, a, b) if (avec_pave and base['rect'] is not None) else None
    # Toujours un groupe NEUF a chaque apercu. Modifier la transformation du
    # volume deja affiche faisait des allers-retours de haut en bas : Fusion
    # annule les modifications de l'apercu precedent (le volume revenait a son
    # ancienne hauteur) avant d'appliquer la nouvelle (essai du 2026-10-10).
    _effacer_fantome()
    design = adsk.fusion.Design.cast(_app.activeProduct)
    grp = design.rootComponent.customGraphicsGroups.add()
    _fantome_groupe = grp
    gris = adsk.fusion.CustomGraphicsBasicMaterialColorEffect.create(
        adsk.core.Color.create(160, 160, 160, 255), adsk.core.Color.create(90, 90, 90, 255),
        adsk.core.Color.create(40, 40, 40, 255), adsk.core.Color.create(0, 0, 0, 255), 10, 0.55)
    # Toujours un simple maillage (quelques triangles deja calcules) : un
    # corps BRep devait etre re-tessele par Fusion a chaque apercu.
    cg = _maillage_unitaire(grp, base)
    cg.color = gris
    cg.isSelectable = False
    cg.transform = _matrice_fantome(base, a, b)
    _fantome_cg, _fantome_cg_cle = cg, base['cle']
    return pave


def _maillage_unitaire(grp, base, a=0.0, b=1.0):
    n = base['n']
    nx, ny, nz = n.x, n.y, n.z
    coords, normales = [], []

    def tri(p, q, r):
        ux, uy, uz = q[0] - p[0], q[1] - p[1], q[2] - p[2]
        vx, vy, vz = r[0] - p[0], r[1] - p[1], r[2] - p[2]
        cx, cy, cz = uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx
        l = (cx * cx + cy * cy + cz * cz) ** 0.5 or 1.0
        for pt in (p, q, r):
            coords.extend(pt)
            normales.extend((cx / l, cy / l, cz / l))

    def dep(p, t):
        return (p[0] + nx * t, p[1] + ny * t, p[2] + nz * t)

    tr = base['tris']
    for k in range(0, len(tr) - 2, 3):
        p, q, r = tr[k], tr[k + 1], tr[k + 2]
        tri(dep(p, b), dep(q, b), dep(r, b))
        tri(dep(p, a), dep(r, a), dep(q, a))
    for p, q in base['segs']:
        tri(dep(p, a), dep(q, a), dep(q, b))
        tri(dep(p, a), dep(q, b), dep(p, b))
    idx = list(range(len(coords) // 3))
    return grp.addMesh(adsk.fusion.CustomGraphicsCoordinates.create(coords), idx, normales, idx)


def _chants_corps(body, inputs):
    """Meme regle que _chants, sur un corps (reel ou temporaire)."""
    faces6 = [f for f in body.faces] if body else []
    if len(faces6) != 6 or any(f.geometry.surfaceType != adsk.core.SurfaceTypes.PlaneSurfaceType
                               for f in faces6):
        return []
    return _classer_chants(faces6, _dd_key(inputs.itemById('tenons_chants'), TENONS_CHANTS))


def _apercu_fantome(inputs):
    """Apercu complet sans fonction : fantome + traits des tenons. Retourne
    le message a afficher."""
    actifs = _tenons_actifs(inputs)
    pave = _dessiner_fantome(inputs, avec_pave=actifs)
    tm = _tenon_mod()
    if not actifs:
        if tm:
            tm._clear_preview_graphics()
        return ''
    if tm is None:
        return 'Tenons : add-in "Tenons CNC" inactif.'
    faces = _chants_corps(pave, inputs) if pave is not None else []
    if not faces:
        tm._clear_preview_graphics()
        return ("Tenons : la piece n'est pas un panneau rectangulaire - ajoute les tenons "
                "ensuite avec Tenons CNC.")
    a = _tenon_args(inputs)
    tm._draw_tenon_preview_graphics(
        faces, a['edge_dist'], a['count'], a['tenon_len'], a['tenon_h'], a['centrer'],
        a['repartition_mode'], a['repartition_cotes_pct'], a['mode'] == 'languette',
        a['languette_bord'], a['languette_h'], adsk.fusion.Design.cast(_app.activeProduct))
    return ''


def _set_msg(inputs, text):
    # Ecrit seulement si le message change (pas de mise en page a chaque apercu).
    m = inputs.itemById('msg')
    text = text or ''
    if m.text != text:
        m.text = text
    if m.isVisible != bool(text):
        m.isVisible = bool(text)


class _CreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            global _pending_prefs, _cp_a_creer, _fleche_active
            _pending_prefs = None
            _cp_a_creer = ''
            _fleche_active = False
            cmd = args.command
            cmd.okButtonText = 'OK'
            _build_inputs(cmd)
            for ev, h in ((cmd.inputChanged, _InputChangedHandler()),
                          (cmd.preSelect, _PreSelectHandler()),
                          (cmd.executePreview, _PreviewHandler()),
                          (cmd.execute, _ExecuteHandler()),
                          (cmd.destroy, _DestroyHandler())):
                ev.add(h)
                _handlers.append(h)
        except Exception:
            _ui.messageBox('Erreur Extrusion CNC:\n' + traceback.format_exc(), COMMAND_NAME)


class _InputChangedHandler(adsk.core.InputChangedEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            inputs = args.input.parentCommand.commandInputs
            iid = args.input.id
            if iid == 'cp':
                _apply_cp(inputs)
            elif iid in ('dist1', 'dist2'):
                # Glisser de la fleche : rien d'autre a faire (fluidite). Le
                # fantome reste dessine dans executePreview : dessine ici (avec
                # l'apercu debranche), il disparaissait pendant le glisser
                # (essai du 2026-10-10).
                global _fleche_active
                _fleche_active = True
                if iid == 'dist1':
                    _sync_cp_row(inputs)
                return
            if iid in _INPUTS_AFFICHAGE:
                _update_visibility(inputs)
            if iid in ('profils', 'direction'):
                _place_manipulators(inputs)
        except Exception:
            pass


class _PreSelectHandler(adsk.core.SelectionEventHandler):
    """Fleche deja utilisee : un clic sur une face mesure la hauteur (Fusion
    l'ecrit dans Distance) sans l'ajouter aux profils, sauf avec CTRL.
    Aucun calcul ici : cet evenement part a chaque survol de la souris."""
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            if _fleche_active and args.activeInput is not None \
                    and args.activeInput.id == 'profils' and not _ctrl_enfonce():
                args.isSelectable = False
        except Exception:
            pass


class _PreviewHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        global _pending_prefs
        inputs = args.command.commandInputs
        try:
            t0 = time.perf_counter()
            if not _selections(inputs.itemById('profils')):
                raise ValueError('Selectionne un profil ou une face.')
            if _fantome_possible(inputs):
                try:
                    # Chemin du glisser de la fleche : le strict minimum (ni
                    # journal ni lecture des reglages, faits au clic OK).
                    _set_msg(inputs, _apercu_fantome(inputs))
                    return
                except Exception:
                    # Fantome impossible pour ce profil : apercu reel.
                    _journal('fantome_echec', inputs, 0.0)
            _effacer_fantome()
            feat = build_extrude(inputs, apercu=True)
            t1 = time.perf_counter()
            msg_t = _apercu_tenons(feat, inputs)
            _journal('apercu', inputs, (t1 - t0) * 1000)
            if inputs.itemById('tenons').value:
                _journal('ap_tenon', inputs, (time.perf_counter() - t1) * 1000)
            _pending_prefs = _current_prefs(inputs)
            _set_msg(inputs, msg_t)
        except ValueError as e:
            _set_msg(inputs, str(e))
        except Exception as e:
            _set_msg(inputs, 'Extrusion impossible avec ces reglages : ' + str(e).splitlines()[-1][:200])


class _ExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        global _pending_prefs
        inputs = args.command.commandInputs
        design = adsk.fusion.Design.cast(_app.activeProduct)
        # Fusion active le nouveau composant cree (les autres sont grises) :
        # on revient au composant actif d'avant (retour de l'utilisateur du 2026-10-09).
        occ_active = design.activeOccurrence
        try:
            self._executer(args, inputs)
        finally:
            try:
                if occ_active is None:
                    if design.activeComponent != design.rootComponent:
                        design.activateRootComponent()
                elif design.activeOccurrence != occ_active:
                    occ_active.activate()
            except Exception:
                pass

    def _executer(self, args, inputs):
        global _pending_prefs
        _effacer_fantome()
        try:
            t0 = time.perf_counter()
            feat = build_extrude(inputs)
            _journal('execute', inputs, (time.perf_counter() - t0) * 1000)
            _pending_prefs = _current_prefs(inputs)
        except Exception as e:
            args.executeFailed = True
            args.executeFailedMessage = 'Extrusion impossible : ' + str(e).splitlines()[-1][:300]
            return
        if _tenons_actifs(inputs):
            # Un echec des tenons ne doit pas annuler l'extrusion.
            try:
                with cnc_progress.Barre('Extrusion CNC', 'Creation des tenons...'):
                    msg = _creer_tenons(feat, inputs)
            except Exception:
                msg = 'Tenons non crees :\n' + traceback.format_exc()[-600:]
            if msg:
                _ui.messageBox(msg, COMMAND_NAME)


class _DestroyHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        global _pending_prefs
        _effacer_fantome()
        _fantome_cache.clear()
        try:
            tm = _tenon_mod()
            if tm:
                tm._clear_preview_graphics()
        except Exception:
            pass
        termine = False
        try:
            termine = args.terminationReason == adsk.core.CommandTerminationReason.CompletedTerminationReason
            if termine and _pending_prefs:
                save_prefs(_pending_prefs)
        except Exception:
            pass
        _pending_prefs = None
        if termine:
            # La fenetre reste ouverte apres OK (demande de l'utilisateur du
            # 2026-10-12) : Fusion ferme toujours une commande validee, on la
            # relance donc des que Fusion est libre, avec les memes reglages
            # (relus dans extrusion_prefs.json). Annuler ou un autre outil ne
            # relancent rien.
            try:
                _app.fireCustomEvent(RELANCE_ID, '')
            except Exception:
                pass


RELANCE_ID = 'ExtrusionCNC_Relance'


class _RelanceHandler(adsk.core.CustomEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            cd = _ui.commandDefinitions.itemById(CMD_ID)
            if cd is not None and _ui.activeCommand == 'SelectCommand':
                cd.execute()
        except Exception:
            pass


def run(context):
    global _app, _ui
    try:
        _app = adsk.core.Application.get()
        _ui = _app.userInterface
        old = _ui.commandDefinitions.itemById(CMD_ID)
        if old:
            old.deleteMe()
        try:
            _app.unregisterCustomEvent(RELANCE_ID)
        except Exception:
            pass
        ev = _app.registerCustomEvent(RELANCE_ID)
        h = _RelanceHandler()
        ev.add(h)
        _handlers.append(h)
        # Meme icone que l'Extrusion native ; repli sur nos propres icones.
        res = _native_extrude_folder() or (RESOURCES if os.path.isdir(RESOURCES) else '')
        cmd_def = _ui.commandDefinitions.addButtonDefinition(CMD_ID, COMMAND_NAME, COMMAND_DESC, res)
        on_created = _CreatedHandler()
        cmd_def.commandCreated.add(on_created)
        _handlers.append(on_created)
        panel = _ui.allToolbarPanels.itemById(PANEL_ID)
        if panel and not panel.controls.itemById(CMD_ID):
            ctrl = panel.controls.addCommand(cmd_def, NATIVE_EXTRUDE_ID, False)
            ctrl.isPromotedByDefault = True
    except Exception:
        if _ui:
            _ui.messageBox('Erreur au demarrage de Extrusion CNC:\n' + traceback.format_exc())


def stop(context):
    try:
        panel = _ui.allToolbarPanels.itemById(PANEL_ID)
        if panel:
            c = panel.controls.itemById(CMD_ID)
            if c:
                c.deleteMe()
        cd = _ui.commandDefinitions.itemById(CMD_ID)
        if cd:
            cd.deleteMe()
    except Exception:
        pass
    try:
        _app.unregisterCustomEvent(RELANCE_ID)
    except Exception:
        pass
    _handlers.clear()
