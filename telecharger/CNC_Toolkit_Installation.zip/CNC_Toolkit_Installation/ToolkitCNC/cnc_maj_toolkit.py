# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------------
# Mise a jour de CNC Toolkit lui-meme (demande de l'utilisateur le
# 2026-10-14 : "un bouton Mettre a jour sur la fenetre CNC Toolkit" + "a
# l'ouverture, un message dit mise a jour disponible").
# A ne pas confondre avec l'outil "Mettre a jour CNC" (MiseAJourCNC), qui
# met a jour les CORPS d'un design.
#
# Source : le depot public GitHub maxnc62/cnc-toolkit.
#   version.json  -> {"version": "2026.10.14", "zip": "telecharger/...zip",
#                     "sha256": "...", "notes_fr": "...", "notes_en": "..."}
#   version locale -> cnc_version.json (dans ce dossier, livre dans le zip).
# Aucune donnee n'est envoyee : simple lecture HTTPS de deux fichiers publics.
#
# Installation (apres confirmation dans la palette) :
#   1. telecharge le zip, verifie son sha256 et son contenu ;
#   2. copie le dossier ToolkitCNC actuel dans
#      AddIns\ToolkitCNC_ancien_maj_<date> (les 3 dernieres sont gardees) ;
#   3. copie les nouveaux fichiers par-dessus. Les .json deja presents
#      (preferences, memoires tenons/mortaises, langue, raccourcis) ne sont
#      JAMAIS ecrases ; seul cnc_version.json l'est. Aucun fichier local
#      n'est supprime. En cas d'erreur, les fichiers deja ecrits sont remis
#      depuis la sauvegarde.
#   4. Fusion doit etre redemarre pour charger la nouvelle version.
#
# Tout le reseau et la copie se font dans un fil d'arriere-plan (aucun appel
# adsk dans ce fil) ; la palette interroge l'etat (action maj_etat).
# ---------------------------------------------------------------------------
import os, json, shutil, threading, hashlib, zipfile, tempfile, time
import urllib.request

DEPOT_BRUT = 'https://raw.githubusercontent.com/maxnc62/cnc-toolkit/main/'
URL_VERSION = DEPOT_BRUT + 'version.json'
PREFIXE_ZIP = 'CNC_Toolkit_Installation/ToolkitCNC/'
PREFIXE_SAUVEGARDE = 'ToolkitCNC_ancien_maj_'
GARDER_SAUVEGARDES = 3
FICHIER_VERSION = 'cnc_version.json'

_DIR = os.path.dirname(os.path.abspath(__file__))
_verrou = threading.Lock()
_etat = {'etat': 'inconnu'}   # inconnu | verification | a_jour | dispo | erreur
                               # | installation | installe | echec_install
_distant = None
_fil = None


def version_locale():
    try:
        with open(os.path.join(_DIR, FICHIER_VERSION), 'r', encoding='utf-8') as f:
            return str(json.load(f).get('version', '')).strip()
    except Exception:
        return ''


def _cle(v):
    out = []
    for p in str(v).replace('-', '.').split('.'):
        try:
            out.append(int(p))
        except ValueError:
            out.append(0)
    return tuple(out)


def _get(url, timeout=10):
    sep = '&' if '?' in url else '?'
    req = urllib.request.Request(url + sep + 't=%d' % int(time.time()),
                                 headers={'User-Agent': 'CNC-Toolkit', 'Cache-Control': 'no-cache'})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def _maj(**kw):
    with _verrou:
        _etat.clear()
        _etat.update(kw)


def etat():
    with _verrou:
        d = dict(_etat)
    d['locale'] = version_locale()
    return d


def _occupe():
    return _fil is not None and _fil.is_alive()


# --------------------------------------------------------------- verification
def verifier(forcer=False):
    """Lance la verification en arriere-plan (une seule fois par session,
    sauf forcer=True)."""
    global _fil
    if _occupe():
        return
    if not forcer and _etat.get('etat') not in ('inconnu',):
        return
    _maj(etat='verification')
    _fil = threading.Thread(target=_verifier_fil, daemon=True)
    _fil.start()


def _verifier_fil():
    global _distant
    try:
        d = json.loads(_get(URL_VERSION).decode('utf-8'))
        v = str(d.get('version', '')).strip()
        if not v or not d.get('zip'):
            raise ValueError('version.json incomplet')
        _distant = d
        loc = version_locale()
        info = dict(distante=v, notes_fr=d.get('notes_fr', ''), notes_en=d.get('notes_en', ''),
                    date=d.get('date', ''))
        if not loc or _cle(v) > _cle(loc):
            _maj(etat='dispo', **info)
        else:
            _maj(etat='a_jour', **info)
    except Exception as e:
        _maj(etat='erreur', message=str(e)[:200])


# ---------------------------------------------------------------- installation
def installer():
    global _fil
    if _occupe():
        return
    if _etat.get('etat') != 'dispo' or not _distant:
        return
    _maj(etat='installation', etape='telechargement', distante=_etat.get('distante', ''))
    _fil = threading.Thread(target=_installer_fil, args=(dict(_distant),), daemon=True)
    _fil.start()


def _membres_surs(z):
    """Fichiers du zip sous CNC_Toolkit_Installation/ToolkitCNC/, chemins
    relatifs verifies (pas de .., pas de chemin absolu)."""
    out = []
    for info in z.infolist():
        n = info.filename.replace('\\', '/')
        if info.is_dir() or not n.startswith(PREFIXE_ZIP):
            continue
        rel = n[len(PREFIXE_ZIP):]
        parts = rel.split('/')
        if not rel or rel.startswith('/') or ':' in rel or any(p in ('', '.', '..') for p in parts):
            raise ValueError('chemin refuse dans le zip : ' + n)
        if '__pycache__' in parts or rel.endswith('.pyc'):
            continue
        out.append((info, rel))
    return out


def _nettoyer_sauvegardes(addins):
    try:
        anciens = sorted(d for d in os.listdir(addins)
                         if d.startswith(PREFIXE_SAUVEGARDE) and os.path.isdir(os.path.join(addins, d)))
        for d in anciens[:-GARDER_SAUVEGARDES]:
            shutil.rmtree(os.path.join(addins, d), ignore_errors=True)
    except Exception:
        pass


def _installer_fil(d):
    tmp = tempfile.mkdtemp(prefix='cnc_maj_')
    sauvegarde = None
    ecrits = []   # (destination, existait_avant)
    try:
        zbytes = _get(DEPOT_BRUT + str(d['zip']).lstrip('/'), timeout=60)
        attendu = str(d.get('sha256', '')).strip().lower()
        if attendu and hashlib.sha256(zbytes).hexdigest() != attendu:
            raise ValueError('le fichier telecharge est incomplet ou modifie (sha256)')
        zpath = os.path.join(tmp, 'maj.zip')
        with open(zpath, 'wb') as f:
            f.write(zbytes)

        _maj(etat='installation', etape='verification', distante=d.get('version', ''))
        with zipfile.ZipFile(zpath) as z:
            membres = _membres_surs(z)
            noms = set(rel for _, rel in membres)
            if 'ToolkitCNC.py' not in noms or 'palette.html' not in noms:
                raise ValueError('zip inattendu (ToolkitCNC.py absent)')
            src = os.path.join(tmp, 'ToolkitCNC')
            for info, rel in membres:
                cible = os.path.join(src, *rel.split('/'))
                os.makedirs(os.path.dirname(cible), exist_ok=True)
                with z.open(info) as fi, open(cible, 'wb') as fo:
                    shutil.copyfileobj(fi, fo)

        _maj(etat='installation', etape='sauvegarde', distante=d.get('version', ''))
        addins = os.path.dirname(_DIR)
        sauvegarde = os.path.join(addins, PREFIXE_SAUVEGARDE + time.strftime('%Y%m%d_%H%M%S'))
        shutil.copytree(_DIR, sauvegarde, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))

        _maj(etat='installation', etape='copie', distante=d.get('version', ''))
        gardes = 0
        for _, rel in membres:
            dst = os.path.join(_DIR, *rel.split('/'))
            existe = os.path.exists(dst)
            if existe and rel.lower().endswith('.json') and os.path.basename(rel) != FICHIER_VERSION:
                gardes += 1   # reglage ou memoire de l'utilisateur : conserve
                continue
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            provisoire = dst + '.maj_tmp'
            shutil.copyfile(os.path.join(tmp, 'ToolkitCNC', *rel.split('/')), provisoire)
            try:
                os.replace(provisoire, dst)
            except Exception:
                try:
                    os.remove(provisoire)
                except Exception:
                    pass
                raise
            ecrits.append((dst, existe))

        _nettoyer_sauvegardes(addins)
        _maj(etat='installe', distante=d.get('version', ''), fichiers=len(ecrits),
             gardes=gardes, sauvegarde=os.path.basename(sauvegarde))
    except Exception as e:
        restaure = _restaurer(ecrits, sauvegarde)
        _maj(etat='echec_install', message=str(e)[:300], restaure=restaure,
             sauvegarde=os.path.basename(sauvegarde) if sauvegarde else '')
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def _restaurer(ecrits, sauvegarde):
    if not ecrits:
        return True
    if not sauvegarde:
        return False
    ok = True
    for dst, existait in reversed(ecrits):
        try:
            if existait:
                rel = os.path.relpath(dst, _DIR)
                shutil.copyfile(os.path.join(sauvegarde, rel), dst)
            else:
                os.remove(dst)
        except Exception:
            ok = False
    return ok
