import adsk.core, adsk.fusion, traceback, math, os, json, time, re, unicodedata, sys

# Barre de chargement commune du Toolkit (ToolkitCNC/cnc_progress.py)
_TK_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _TK_DIR not in sys.path:
    sys.path.append(_TK_DIR)
import cnc_progress

_handlers = []
_app = None
_ui  = None
CMD_ID   = "GravureCNCCmd"
CMD_NAME = "Gravure CNC"
CMD_DESC = "Gravure du nom des composants (ou d'un texte personnalise) sur les faces selectionnees"
PANEL_ID = "SolidModifyPanel"
H_CENTER = adsk.core.HorizontalAlignments.CenterHorizontalAlignment
V_MIDDLE = adsk.core.VerticalAlignments.MiddleVerticalAlignment

# Police vectorielle interne "trait simple" (voir LINE_FONT_NAME plus bas) :
# essaye d'abord des polices TrueType "stick font" installees par
# l'utilisateur (ex. CamBam Stick Fonts) - abandonne : Fusion cree bien
# l'objet SketchText (boundingBox coherente), mais est incapable d'en tirer
# la moindre courbe exploitable (echec systematique a l'extrusion, meme
# a vide, sur les 8 variantes testees : "Un argument d'entree est
# incorrect"). Cause : ces polices definissent chaque lettre par un
# contour OUVERT (vrai trait simple), alors que le moteur SketchText de
# Fusion n'accepte que des contours FERMES (comme une police normale,
# ou chaque lettre est une forme pleine) pour en generer de la geometrie.
# La police "trait simple" ci-dessous contourne totalement cette
# limitation : les lettres sont dessinees directement comme des segments
# de droite (SketchLines) dans l'esquisse, sans jamais passer par le
# moteur de police de Fusion - donc de vrais traits ouverts, garantis
# fonctionnels, mais du coup jamais extrudables (voir _draw_line_text).
LINE_FONT_NAME = "Trait simple (interne - esquisse uniquement, sans extrusion)"

_ADDIN_DIR = os.path.dirname(os.path.abspath(__file__))
SETTINGS_PATH = os.path.join(_ADDIN_DIR, "settings.json")
DEBUG_LOG     = os.path.join(_ADDIN_DIR, "gravure_debug.log")
DEFAULT_SETTINGS = {"font_name": "Arial", "text_height": 5.0,
    "bold": False, "italic": False, "underline": False, "depth": 0.2,
    "margin": 5.0, "do_extrude": True, "custom_text": ""}
FONTS = ["Arial", "Arial Black", "Bahnschrift", "Calibri", "Courier New", "Georgia",
         "Impact", "Tahoma", "Times New Roman", "Trebuchet MS", "Verdana",
         LINE_FONT_NAME]


# ---------------------------------------------------------------------------
# Police vectorielle "trait simple" (donnees Hershey Simplex, domaine public -
# format brut : liste plate [x0,y0,x1,y1,...], le couple (-1,-1) marquant un
# leve de crayon). Repere d'origine du format : ligne de base a y=0, hauteur
# de capitale a y=21 (certains caracteres depassent legerement, ex.
# parentheses/hampes/jambages) - voir _draw_line_text pour la mise a
# l'echelle et le centrage.
# ---------------------------------------------------------------------------
_LINE_FONT_RAW = {
    " ": (16, []),
    "'": (10, [5,19,4,20,5,21,6,20,6,18,5,16,4,15]),
    ",": (10, [6,1,5,0,4,1,5,2,6,1,6,-1,5,-3,4,-4]),
    "-": (26, [4,9,22,9]),
    "_": (16, [0,-2,16,-2]),
    ".": (10, [5,2,4,1,5,0,6,1,5,2]),
    "/": (22, [20,25,2,-7]),
    "0": (20, [9,21,6,20,4,17,3,12,3,9,4,4,6,1,9,0,11,0,14,1,16,4,17,9,17,12,16,17,14,20,11,21,9,21]),
    "1": (20, [6,17,8,18,11,21,11,0]),
    "2": (20, [4,16,4,17,5,19,6,20,8,21,12,21,14,20,15,19,16,17,16,15,15,13,13,10,3,0,17,0]),
    "3": (20, [5,21,16,21,10,13,13,13,15,12,16,11,17,8,17,6,16,3,14,1,11,0,8,0,5,1,4,2,3,4]),
    "4": (20, [13,21,3,7,18,7,-1,-1,13,21,13,0]),
    "5": (20, [15,21,5,21,4,12,5,13,8,14,11,14,14,13,16,11,17,8,17,6,16,3,14,1,11,0,8,0,5,1,4,2,3,4]),
    "6": (20, [16,18,15,20,12,21,10,21,7,20,5,17,4,12,4,7,5,3,7,1,10,0,11,0,14,1,16,3,17,6,17,7,16,10,14,12,11,13,10,13,7,12,5,10,4,7]),
    "7": (20, [17,21,7,0,-1,-1,3,21,17,21]),
    "8": (20, [8,21,5,20,4,18,4,16,5,14,7,13,11,12,14,11,16,9,17,7,17,4,16,2,15,1,12,0,8,0,5,1,4,2,3,4,3,7,4,9,6,11,9,12,13,13,15,14,16,16,16,18,15,20,12,21,8,21]),
    "9": (20, [16,14,15,11,13,9,10,8,9,8,6,9,4,11,3,14,3,15,4,18,6,20,9,21,10,21,13,20,15,18,16,14,16,9,15,4,13,1,10,0,8,0,5,1,4,3]),
    ":": (10, [5,14,4,13,5,12,6,13,5,14,-1,-1,5,2,4,1,5,0,6,1,5,2]),
    "(": (14, [11,25,9,23,7,20,5,16,4,11,4,7,5,2,7,-2,9,-5,11,-7]),
    ")": (14, [3,25,5,23,7,20,9,16,10,11,10,7,9,2,7,-2,5,-5,3,-7]),
    "A": (18, [9,21,1,0,-1,-1,9,21,17,0,-1,-1,4,7,14,7]),
    "B": (21, [4,21,4,0,-1,-1,4,21,13,21,16,20,17,19,18,17,18,15,17,13,16,12,13,11,-1,-1,4,11,13,11,16,10,17,9,18,7,18,4,17,2,16,1,13,0,4,0]),
    "C": (21, [18,16,17,18,15,20,13,21,9,21,7,20,5,18,4,16,3,13,3,8,4,5,5,3,7,1,9,0,13,0,15,1,17,3,18,5]),
    "D": (21, [4,21,4,0,-1,-1,4,21,11,21,14,20,16,18,17,16,18,13,18,8,17,5,16,3,14,1,11,0,4,0]),
    "E": (19, [4,21,4,0,-1,-1,4,21,17,21,-1,-1,4,11,12,11,-1,-1,4,0,17,0]),
    "F": (18, [4,21,4,0,-1,-1,4,21,17,21,-1,-1,4,11,12,11]),
    "G": (21, [18,16,17,18,15,20,13,21,9,21,7,20,5,18,4,16,3,13,3,8,4,5,5,3,7,1,9,0,13,0,15,1,17,3,18,5,18,8,-1,-1,13,8,18,8]),
    "H": (22, [4,21,4,0,-1,-1,18,21,18,0,-1,-1,4,11,18,11]),
    "I": (8, [4,21,4,0]),
    "J": (16, [12,21,12,5,11,2,10,1,8,0,6,0,4,1,3,2,2,5,2,7]),
    "K": (21, [4,21,4,0,-1,-1,18,21,4,7,-1,-1,9,12,18,0]),
    "L": (17, [4,21,4,0,-1,-1,4,0,16,0]),
    "M": (24, [4,21,4,0,-1,-1,4,21,12,0,-1,-1,20,21,12,0,-1,-1,20,21,20,0]),
    "N": (22, [4,21,4,0,-1,-1,4,21,18,0,-1,-1,18,21,18,0]),
    "O": (22, [9,21,7,20,5,18,4,16,3,13,3,8,4,5,5,3,7,1,9,0,13,0,15,1,17,3,18,5,19,8,19,13,18,16,17,18,15,20,13,21,9,21]),
    "P": (21, [4,21,4,0,-1,-1,4,21,13,21,16,20,17,19,18,17,18,14,17,12,16,11,13,10,4,10]),
    "Q": (22, [9,21,7,20,5,18,4,16,3,13,3,8,4,5,5,3,7,1,9,0,13,0,15,1,17,3,18,5,19,8,19,13,18,16,17,18,15,20,13,21,9,21,-1,-1,12,4,18,-2]),
    "R": (21, [4,21,4,0,-1,-1,4,21,13,21,16,20,17,19,18,17,18,15,17,13,16,12,13,11,4,11,-1,-1,11,11,18,0]),
    "S": (20, [17,18,15,20,12,21,8,21,5,20,3,18,3,16,4,14,5,13,7,12,13,10,15,9,16,8,17,6,17,3,15,1,12,0,8,0,5,1,3,3]),
    "T": (16, [8,21,8,0,-1,-1,1,21,15,21]),
    "U": (22, [4,21,4,6,5,3,7,1,10,0,12,0,15,1,17,3,18,6,18,21]),
    "V": (18, [1,21,9,0,-1,-1,17,21,9,0]),
    "W": (24, [2,21,7,0,-1,-1,12,21,7,0,-1,-1,12,21,17,0,-1,-1,22,21,17,0]),
    "X": (20, [3,21,17,0,-1,-1,17,21,3,0]),
    "Y": (18, [1,21,9,11,9,0,-1,-1,17,21,9,11]),
    "Z": (20, [17,21,3,0,-1,-1,3,21,17,21,-1,-1,3,0,17,0]),
    "a": (19, [15,14,15,0,-1,-1,15,11,13,13,11,14,8,14,6,13,4,11,3,8,3,6,4,3,6,1,8,0,11,0,13,1,15,3]),
    "b": (19, [4,21,4,0,-1,-1,4,11,6,13,8,14,11,14,13,13,15,11,16,8,16,6,15,3,13,1,11,0,8,0,6,1,4,3]),
    "c": (18, [15,11,13,13,11,14,8,14,6,13,4,11,3,8,3,6,4,3,6,1,8,0,11,0,13,1,15,3]),
    "d": (19, [15,21,15,0,-1,-1,15,11,13,13,11,14,8,14,6,13,4,11,3,8,3,6,4,3,6,1,8,0,11,0,13,1,15,3]),
    "e": (18, [3,8,15,8,15,10,14,12,13,13,11,14,8,14,6,13,4,11,3,8,3,6,4,3,6,1,8,0,11,0,13,1,15,3]),
    "f": (12, [10,21,8,21,6,20,5,17,5,0,-1,-1,2,14,9,14]),
    "g": (19, [15,14,15,-2,14,-5,13,-6,11,-7,8,-7,6,-6,-1,-1,15,11,13,13,11,14,8,14,6,13,4,11,3,8,3,6,4,3,6,1,8,0,11,0,13,1,15,3]),
    "h": (19, [4,21,4,0,-1,-1,4,10,7,13,9,14,12,14,14,13,15,10,15,0]),
    "i": (8, [3,21,4,20,5,21,4,22,3,21,-1,-1,4,14,4,0]),
    "j": (10, [5,21,6,20,7,21,6,22,5,21,-1,-1,6,14,6,-3,5,-6,3,-7,1,-7]),
    "k": (17, [4,21,4,0,-1,-1,14,14,4,4,-1,-1,8,8,15,0]),
    "l": (8, [4,21,4,0]),
    "m": (30, [4,14,4,0,-1,-1,4,10,7,13,9,14,12,14,14,13,15,10,15,0,-1,-1,15,10,18,13,20,14,23,14,25,13,26,10,26,0]),
    "n": (19, [4,14,4,0,-1,-1,4,10,7,13,9,14,12,14,14,13,15,10,15,0]),
    "o": (19, [8,14,6,13,4,11,3,8,3,6,4,3,6,1,8,0,11,0,13,1,15,3,16,6,16,8,15,11,13,13,11,14,8,14]),
    "p": (19, [4,14,4,-7,-1,-1,4,11,6,13,8,14,11,14,13,13,15,11,16,8,16,6,15,3,13,1,11,0,8,0,6,1,4,3]),
    "q": (19, [15,14,15,-7,-1,-1,15,11,13,13,11,14,8,14,6,13,4,11,3,8,3,6,4,3,6,1,8,0,11,0,13,1,15,3]),
    "r": (13, [4,14,4,0,-1,-1,4,8,5,11,7,13,9,14,12,14]),
    "s": (17, [14,11,13,13,10,14,7,14,4,13,3,11,4,9,6,8,11,7,13,6,14,4,14,3,13,1,10,0,7,0,4,1,3,3]),
    "t": (12, [5,21,5,4,6,1,8,0,10,0,-1,-1,2,14,9,14]),
    "u": (19, [4,14,4,4,5,1,7,0,10,0,12,1,15,4,-1,-1,15,14,15,0]),
    "v": (16, [2,14,8,0,-1,-1,14,14,8,0]),
    "w": (22, [3,14,7,0,-1,-1,11,14,7,0,-1,-1,11,14,15,0,-1,-1,19,14,15,0]),
    "x": (17, [3,14,14,0,-1,-1,14,14,3,0]),
    "y": (16, [2,14,8,0,-1,-1,14,14,8,0,6,-4,4,-6,2,-7,1,-7]),
    "z": (17, [14,14,3,0,-1,-1,3,14,14,14,-1,-1,3,0,14,0]),
}


def _parse_strokes(flat):
    """Convertit une liste plate [x0,y0,x1,y1,...] (format Hershey brut) en
    liste de traits (chacun une liste de (x,y)) - coupee a chaque paire
    (-1,-1), qui marque un leve de crayon (donc plusieurs traits separes
    pour une meme lettre, ex. le "I" d'un "H" et ses deux jambages)."""
    pts = list(zip(flat[0::2], flat[1::2]))
    strokes = []
    cur = []
    for p in pts:
        if p == (-1, -1):
            if len(cur) >= 2:
                strokes.append(cur)
            cur = []
        else:
            cur.append(p)
    if len(cur) >= 2:
        strokes.append(cur)
    return strokes


_LINE_FONT = {ch: (w, _parse_strokes(flat)) for ch, (w, flat) in _LINE_FONT_RAW.items()}


def _strip_accents(text):
    """Remplace les lettres accentuees/cedille par leur equivalent de base
    (ex. "e"/"e"/"e" -> "e", "c" -> "c") - la police trait simple interne
    (voir _LINE_FONT) ne couvre que l'ASCII de base (comme la police
    Hershey Simplex d'origine), donc un caractere accentue sans cette
    normalisation ne serait tout simplement pas dessine (trou silencieux
    dans le texte grave) plutot que degrade proprement en sa version non
    accentuee."""
    try:
        nf = unicodedata.normalize("NFKD", text)
        return "".join(c for c in nf if unicodedata.category(c) != "Mn")
    except Exception:
        return text


def _simplify_collinear(pts, tol=1e-6):
    """Supprime les points intermediaires d'une liste de points consecutifs
    qui sont strictement ALIGNES avec leurs deux voisins (produit vectoriel
    quasi nul) : ca ne change RIEN au trait dessine (le segment resultant
    passe exactement par les memes points aux extremites), mais reduit le
    nombre de SketchLines a creer - donc le nombre d'appels a l'API Fusion,
    qui est le vrai cout de _draw_line_text sur un texte un peu long.

    Produit vectoriel calcule en 3D COMPLET (x, y ET z), jamais juste en
    x/y : quand les points sont en coordonnees MONDE reelles (voir
    world_basis dans _draw_line_text, utilise pour l'esquisse partagee),
    une face qui n'est pas parallele au plan XY global peut faire
    apparaitre des points comme "alignes" en ne regardant que leur
    projection x/y alors qu'ils ne le sont pas du tout en 3D - bug
    constate en direct (la quasi-totalite des segments d'un texte
    disparaissaient, silencieusement, via le try/except plus bas)."""
    if len(pts) < 3:
        return pts
    out = [pts[0]]
    for i in range(1, len(pts) - 1):
        a, b, c = out[-1], pts[i], pts[i + 1]
        abx, aby, abz = b.x - a.x, b.y - a.y, b.z - a.z
        bcx, bcy, bcz = c.x - b.x, c.y - b.y, c.z - b.z
        cross_x = aby * bcz - abz * bcy
        cross_y = abz * bcx - abx * bcz
        cross_z = abx * bcy - aby * bcx
        if (cross_x * cross_x + cross_y * cross_y + cross_z * cross_z) > tol * tol:
            out.append(b)
    out.append(pts[-1])
    return out


def _draw_line_text(sketch, text, cx, cy, scale, angle, world_basis=None):
    """Dessine `text` dans l'esquisse `sketch` avec la police vectorielle
    interne (_LINE_FONT) : un SketchLine par segment de chaque trait -
    aucun contour ferme n'est jamais cree (donc jamais de profil, jamais
    d'extrusion possible - texte export ONLY, voir LINE_FONT_NAME). `scale`
    convertit les unites de la police (hauteur de capitale nominale = 21)
    en cm ; le bloc de texte est centre sur (cx, cy) puis tourne de `angle`
    (radians, meme convention que le texte Fusion classique - voir
    _find_engrave_box). Les points strictement alignes d'un meme trait sont
    fusionnes avant creation (voir _simplify_collinear) pour limiter le
    nombre d'appels a l'API Fusion.

    world_basis (optionnel) : tuple (ox,oy,oz, ux,uy,uz, vx,vy,vz) - origine
    et les deux vecteurs de base (axes X/Y locaux de la face d'origine),
    exprimes en coordonnees MONDE REELLES (obtenues via SketchPoint.worldGeometry
    - fiable quel que soit le niveau d'imbrication des occurrences, on ne
    recalcule jamais ce transform a la main). Utilise quand `sketch` est une
    esquisse PARTAGEE entre plusieurs faces/corps (voir _engrave,
    shared_sketch) : chaque point 2D local (lx,ly) est alors place a
    origin + lx*u + ly*v avant creation, au lieu d'etre utilise tel quel.

    Les points sont places en 3D REEL sur la face d'origine (X, Y ET Z
    suivent origin + lx*u + ly*v) : la gravure epouse la face choisie de
    chaque panneau, quelle que soit son orientation dans l'assemblage
    (demande de l'utilisateur, 2026-10-10 - remplace l'ancien forcage a
    Z=0, qui ne convenait qu'a des pieces deja mises a plat et ecrasait
    les panneaux verticaux/inclines sur le plan XY). Calpinage CNC
    s'appuie justement sur ces points 3D (worldGeometry) pour reconnaitre
    la face gravee et la remettre au-dessus lors de la mise a plat.
    Si world_basis est None : comportement d'origine (sketch est deja la
    bonne esquisse pour cette face - points locaux utilises directement,
    z=0 egalement)."""
    text = _strip_accents(text)
    total_w = sum(_LINE_FONT.get(ch, _LINE_FONT[" "])[0] for ch in text)
    half_w = (total_w * scale) / 2.0
    half_h = (21.0 * scale) / 2.0
    cos_a, sin_a = math.cos(angle), math.sin(angle)
    dl = sketch.sketchCurves.sketchLines
    if world_basis is not None:
        ox, oy, oz, ux, uy, uz, vx, vy, vz = world_basis
    # Longueur MAX (cm) du trait du tiret "-", quelle que soit la hauteur du
    # texte : dans les donnees Hershey Simplex d'origine, le tiret est un
    # trait de 18 unites (sur une largeur de caractere de 26 unites) - donc
    # presque aussi long qu'une lettre pleine (ex. "0" ne fait que 14
    # unites) - a l'echelle d'un texte de plusieurs cm de haut ca donne un
    # tiret bien plus long et visuellement disproportionne qu'un vrai tiret
    # typographique (remonte par l'utilisateur, capture d'ecran a l'appui).
    # Beaucoup d'etiquettes en contiennent un (voir _clean_label, qui
    # remplace "(8)" par "-8"), d'ou l'impact visible. On ne touche PAS a
    # w_ch (largeur d'avancement) pour ne pas modifier l'espacement/la
    # recherche de placement (qui utilisent la largeur nominale) - seul le
    # trait dessine est raccourci, en le recentrant sur le meme milieu.
    DASH_MAX_CM = 1.0
    cursor = 0.0
    for ch in text:
        w_ch, strokes = _LINE_FONT.get(ch, _LINE_FONT[" "])
        if ch == "-" and scale > 0:
            (x0, y0), (x1, y1) = strokes[0][0], strokes[0][-1]
            mx = (x0 + x1) / 2.0
            half_len_units = abs(x1 - x0) / 2.0
            max_half_units = (DASH_MAX_CM / 2.0) / scale
            if half_len_units > max_half_units:
                half_len_units = max_half_units
            strokes = [[(mx - half_len_units, y0), (mx + half_len_units, y0)]]
        for stroke in strokes:
            pts = []
            for fx, fy in stroke:
                lx = (cursor + fx) * scale - half_w
                ly = fy * scale - half_h
                px = cx + lx * cos_a - ly * sin_a
                py = cy + lx * sin_a + ly * cos_a
                if world_basis is not None:
                    pts.append(adsk.core.Point3D.create(
                        ox + px * ux + py * vx,
                        oy + px * uy + py * vy,
                        oz + px * uz + py * vz))
                else:
                    pts.append(adsk.core.Point3D.create(px, py, 0.0))
            pts = _simplify_collinear(pts)
            prev = None
            for pt in pts:
                if prev is not None:
                    try:
                        dl.addByTwoPoints(prev, pt)
                    except Exception:
                        pass
                prev = pt
        cursor += w_ch


def _dbg(msg):
    try:
        with open(DEBUG_LOG, "a", encoding="utf-8") as f:
            f.write(time.strftime("%H:%M:%S") + " " + str(msg) + "\n")
    except Exception:
        pass


def _load_settings():
    try:
        if os.path.isfile(SETTINGS_PATH):
            with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
            s = dict(DEFAULT_SETTINGS); s.update(data); return s
    except Exception:
        pass
    return dict(DEFAULT_SETTINGS)


def _save_settings(s):
    try:
        with open(SETTINGS_PATH, "w", encoding="utf-8") as f:
            json.dump(s, f, indent=2)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Selection "en couches" : chaque corps dont une face est selectionnee est
# MASQUE pendant la selection, pour atteindre les faces des corps situes
# derriere. Case "Afficher les corps choisis" : les reaffiche (et bloque
# leurs faces via preSelect) pour revoir le modele.
#
# - Le masquage est fait dans executePreview : Fusion annule
#   automatiquement tout changement de preview (a chaque nouveau preview, a
#   l'annulation/fermeture et avant Execute). Par securite, les corps
#   masques sont aussi memorises par entityToken et reaffiches a la
#   fermeture de la commande (destroy) s'ils etaient restes caches.
# - On ne touche PAS a body.isSelectable : ce flag n'est pas annule par
#   Fusion (il restait bloque et s'enregistrait avec le document) et le
#   passer a False fait perdre a Fusion la selection en cours.
# - face_sel reste la liste de reference des faces choisies (ordre de clic).
# ---------------------------------------------------------------------------
_sync_guard = [False]
_hidden_tokens = set()
# Choix memorises par l'outil (faces ou corps, ordre de clic). Apres chaque
# clic, l'entite est retiree de la selection native (face_sel) pour que
# Fusion n'affiche plus la face choisie en bleu transparent par-dessus le
# corps masque : seuls les corps non choisis restent visibles.
_picked = []   # liste de (entityToken, entite)


def _resolve_picked(tok, ent):
    try:
        if ent is not None and ent.isValid:
            return ent
    except Exception:
        pass
    try:
        design = adsk.fusion.Design.cast(_app.activeProduct)
        found = design.findEntityByToken(tok)
        if found:
            return found[0]
    except Exception:
        pass
    return None


def _picked_entities(sel=None):
    ents = []
    for tok, ent in _picked:
        e = _resolve_picked(tok, ent)
        if e is not None:
            ents.append(e)
    if sel is not None:
        for i in range(sel.selectionCount):
            try:
                ents.append(sel.selection(i).entity)
            except Exception:
                pass
    return ents


def _absorb_selection(sel, en_apercu=False):
    """Transfere les entites de face_sel vers _picked (ou, en mode APERCU,
    vers les propositions : le corps reste visible) puis vide face_sel."""
    if sel is None or sel.selectionCount == 0:
        return []
    new = []
    for i in range(sel.selectionCount):
        try:
            new.append(sel.selection(i).entity)
        except Exception:
            pass
    for e in new:
        try:
            b = _entity_body(e)
            _proposes[:] = [(t, x) for (t, x) in _proposes
                            if not (_resolve_picked(t, x) is not None and _entity_body(_resolve_picked(t, x)) == b)]
        except Exception:
            pass
        cible = _proposes if en_apercu else _picked
        try:
            cible.append((e.entityToken, e))
        except Exception:
            cible.append((None, e))
    _sync_guard[0] = True
    try:
        sel.clearSelection()
    finally:
        _sync_guard[0] = False
    return new


def _unhide_remembered():
    try:
        design = adsk.fusion.Design.cast(_app.activeProduct)
        for t in list(_hidden_tokens):
            for e in design.findEntityByToken(t):
                try:
                    if not e.isLightBulbOn:
                        e.isLightBulbOn = True
                except Exception:
                    pass
    except Exception:
        _dbg('unhide: ' + traceback.format_exc())
    _hidden_tokens.clear()


def _entity_body(ent):
    if isinstance(ent, adsk.fusion.BRepBody):
        return ent
    return ent.body


def _selected_bodies(sel):
    bodies = []
    for ent in _picked_entities(sel):
        try:
            b = _entity_body(ent)
        except Exception:
            continue
        if not any(x == b for x in bodies):
            bodies.append(b)
    return bodies


def _undo_last_face(sel):
    _absorb_selection(sel)
    if _picked:
        _picked.pop()


def _auto_face(body):
    """Mode "par corps" : face a graver choisie automatiquement = une des
    deux grandes faces planes du panneau (aire >= 90 % de la plus grande).
    Entre elles, on prend celle dont la normale sortante pointe le plus
    vers le haut (+Z monde), puis vers l'avant (-Y), puis vers +X."""
    planars = []
    for f in body.faces:
        try:
            if f.geometry.surfaceType == adsk.core.SurfaceTypes.PlaneSurfaceType:
                planars.append(f)
        except Exception:
            pass
    if not planars:
        return None
    a_max = max(f.area for f in planars)
    cands = [f for f in planars if f.area >= 0.9 * a_max]
    def key(f):
        n = _face_normal(f) or (0.0, 0.0, 0.0)
        return (round(n[2], 3), round(-n[1], 3), round(n[0], 3))
    return max(cands, key=key)


def _apply_sel_mode(sel, mode):
    _sync_guard[0] = True
    try:
        sel.clearSelection()
        sel.clearSelectionFilter()
        sel.addSelectionFilter("SolidBodies" if mode == "Corps" else "PlanarFaces")
    finally:
        _sync_guard[0] = False


# ---------------------------------------------------------------------------
# Fenetre de selection en bas a gauche de la vue 3D (modele : fenetres de
# Reseau CNC, voir design/design_cnc_toolkit.md). Images PNG generees en
# Python, posees en CustomGraphics colles au coin bas gauche de la vue.
# - Ligne d'en-tete : boutons FACE / CORPS (mode de selection), compteur,
#   oeil (afficher / masquer les corps choisis), retour arriere (retire la
#   derniere selection et reaffiche son corps).
# - Une ligne par selection (les plus recentes), la derniere en bleu, avec
#   une croix pour retirer cette selection.
# Un clic sur la fenetre ne selectionne jamais rien derriere (preSelect).
# ---------------------------------------------------------------------------
GV_W, GV_H = 524, 28
GV_X, GV_Y, GV_GAP = 16, 60, 6
GV_FACE0, GV_FACE1 = 8, 60
GV_CORPS0, GV_CORPS1 = 66, 126
GV_DESSUS0, GV_DESSUS1 = 134, 198
GV_SENS0, GV_SENS1 = 204, 286
GV_COPIES0, GV_COPIES1 = 292, 352
GV_LISTE0, GV_LISTE1 = 358, 450
GV_VAL0, GV_VAL1 = 360, 470
GV_OEIL0, GV_OEIL1 = 456, 484
GV_RET0, GV_RET1 = 492, 520
GV_CROIX0, GV_CROIX1 = 492, 520
GV_MAX = 10

_gv = {'g': None, 'sig': None, 'lignes': [], 'mode': 'Face', 'show': False, 'prop': 'sens', 'liste': False, 'cmd': None}
_gv_tip = {'g': None, 'cle': None}
_gv_souris = {'vp': None, 'pos': None}
_gv_bloc = {'t': 0.0}
_gv_png = {}

_GLYPHES = {
    'C': '111100100100111', 'H': '101101111101101', 'E': '111100111100111', 'M': '101111111101101',
    'T': '111010010010010', 'O': '111101101101111', 'U': '101101101101111',
    'S': '111100111001111', 'I': '111010010010111', 'N': '111101101101101', ' ': '000000000000000',
    '0': '111101101101111', '1': '010110010010111', '2': '111001111100111', '3': '111001111001111',
    '4': '101101111001001', '5': '111100111001111', '6': '111100111101111', '7': '111001001001001',
    '8': '111101111101111', '9': '111101111001111',
    'A': '010101111101101', 'B': '110101110101110', 'D': '110101101101110', 'F': '111100110100100',
    'G': '011100101101011', 'J': '001001001101010', 'K': '101101110101101', 'L': '100100100100111',
    'P': '110101110100100', 'Q': '010101101111011', 'R': '110101110101101', 'V': '101101101101010',
    'W': '101101111111101', 'X': '101101010101101', 'Y': '101101010010010', 'Z': '111001010100111',
    "'": '010010000000000', '.': '000000000000010', ',': '000000000010100', '-': '000000111000000',
    ':': '000010000010000', '%': '101001010100101', '/': '001001010100100',
    '_': '000000000000111', '(': '010100100100010', ')': '010001001001010', '+': '000010111010000',
    '#': '101111101111101', '&': '010101010101011'}


def _gv_dpr():
    if 'k' not in _gv_png:
        k = 1.0
        try:
            import ctypes
            k = max(1.0, ctypes.windll.user32.GetDpiForSystem() / 96.0)
        except Exception:
            pass
        _gv_png['k'] = k
    return _gv_png['k']


def _gv_ecrire(cle, px, w, h):
    import zlib, struct, tempfile
    raw = bytearray()
    for y in range(h):
        raw.append(0)
        for x in range(w):
            raw += bytes(px[y][x])

    def chunk(tt, dd):
        c = struct.pack('>I', len(dd)) + tt + dd
        return c + struct.pack('>I', zlib.crc32(tt + dd) & 0xffffffff)
    png = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 6, 0, 0, 0)) + \
        chunk(b'IDAT', zlib.compress(bytes(raw))) + chunk(b'IEND', b'')
    chemin = os.path.join(tempfile.gettempdir(), 'gravure_cnc_%s.png' % cle)
    with open(chemin, 'wb') as f:
        f.write(png)
    _gv_png[cle] = chemin
    return chemin


def _gv_texte(px, txt, x0, y0, couleur, xmax=None):
    txt = ''.join(c for c in unicodedata.normalize('NFD', txt) if unicodedata.category(c) != 'Mn').upper()
    for n, c in enumerate(txt):
        if xmax is not None and x0 + n * 8 + 6 > xmax:
            break
        g = _GLYPHES.get(c, _GLYPHES[' '])
        for gy in range(5):
            for gx in range(3):
                if g[gy * 3 + gx] == '1':
                    for dy in range(2):
                        for dx in range(2):
                            px[y0 + gy * 2 + dy][x0 + n * 8 + gx * 2 + dx] = couleur


def _gv_fond(w, h, actif):
    px = [[(40, 40, 40, 255)] * w for _ in range(h)]
    cadre = (20, 130, 215, 255) if actif else (110, 110, 110, 255)
    for x in range(w):
        for y in (0, 1, h - 1, h - 2):
            px[y][x] = cadre
    for y in range(h):
        for x in (0, 1, w - 1, w - 2):
            px[y][x] = cadre
    return px


def _gv_bouton(px, x0, x1, yc, actif):
    fond = (110, 55, 0, 255) if actif else (62, 62, 62, 255)
    bord = (255, 170, 60, 255) if actif else (125, 125, 125, 255)
    for x in range(x0, x1):
        for y in range(yc - 11, yc + 11):
            px[y][x] = bord if (x in (x0, x1 - 1) or y in (yc - 11, yc + 10)) else fond
    return ((255, 140, 0, 255) if actif else (150, 150, 150, 255),
            (255, 225, 175, 255) if actif else (190, 190, 190, 255))


def _gv_png_entete(mode, n, show, prop=None, liste=False):
    cle = 'ent4_%s_%d_%d_%s_%d' % (mode, n, 1 if show else 0, prop, 1 if liste else 0)
    if cle in _gv_png and os.path.isfile(_gv_png[cle]):
        return _gv_png[cle]
    w, h = GV_W, GV_H
    px = _gv_fond(w, h, False)
    yc = h // 2
    for (x0, x1, txt, actif) in ((GV_FACE0, GV_FACE1, 'FACE', mode == 'Face'),
                                 (GV_CORPS0, GV_CORPS1, 'CORPS', mode == 'Corps'),
                                 (GV_DESSUS0, GV_DESSUS1, 'DESSUS', False),
                                 (GV_SENS0, GV_SENS1, 'MEME SENS', prop == 'sens'),
                                 (GV_COPIES0, GV_COPIES1, 'COPIES', prop == 'copies')):
        _gv_bouton(px, x0, x1, yc, actif)
        tx = (x0 + x1) // 2 - (len(txt) * 8 - 2) // 2
        _gv_texte(px, txt, tx, yc - 5, (255, 225, 175, 255) if actif else (190, 190, 190, 255))
    # compteur = bouton qui deplie / replie la liste des choix
    plein, clair = _gv_bouton(px, GV_LISTE0, GV_LISTE1, yc, liste)
    _gv_texte(px, '%d CHOIX' % n, GV_LISTE0 + 8, yc - 5,
              (255, 200, 60, 255) if n else (140, 140, 140, 255), xmax=GV_LISTE1 - 14)
    xt = GV_LISTE1 - 9
    for k in range(4):
        y = (yc - 2 + k) if not liste else (yc + 1 - k)      # triangle bas (replie) / haut (deplie)
        for x in range(xt - 3 + k, xt + 4 - k):
            px[y][x] = clair
    # oeil : afficher les corps choisis (actif = corps affiches)
    plein, clair = _gv_bouton(px, GV_OEIL0, GV_OEIL1, yc, show)
    xo = (GV_OEIL0 + GV_OEIL1) // 2
    for dx in range(-9, 10):
        ey = int(round(5.0 * (1 - (dx / 9.0) ** 2) ** 0.8))
        for y in (yc - ey, yc + ey):
            px[y][xo + dx] = clair
    for dx in range(-3, 4):
        for dy in range(-3, 4):
            if dx * dx + dy * dy <= 9:
                px[yc + dy][xo + dx] = plein
    # retour arriere : fleche courbe vers la gauche
    plein, clair = _gv_bouton(px, GV_RET0, GV_RET1, yc, False)
    if not n:
        clair = (95, 95, 95, 255)
    xr = (GV_RET0 + GV_RET1) // 2
    for x in range(xr - 6, xr + 5):
        for y in (yc - 4, yc - 3):
            px[y][x] = clair
    for y in range(yc - 4, yc + 6):
        for x in (xr + 5, xr + 6):
            px[y][x] = clair
    for x in range(xr - 2, xr + 7):
        for y in (yc + 5, yc + 6):
            px[y][x] = clair
    for k in range(5):
        for y in (yc - 4 - k, yc - 3 + k):
            px[y][xr - 6 + k] = clair
    return _gv_ecrire(cle, px, w, h)


def _gv_png_ligne(num, label, genre, actif):
    cle = 'l_%d_%s_%s_%d' % (num, abs(hash(label)), genre, 1 if actif else 0)
    if cle in _gv_png and os.path.isfile(_gv_png[cle]):
        return _gv_png[cle]
    w, h = GV_W, GV_H
    px = _gv_fond(w, h, actif)
    yc = h // 2
    c_txt = (235, 235, 235, 255) if actif else (140, 140, 140, 255)
    _gv_texte(px, str(num), 8, yc - 5, (255, 200, 60, 255) if actif else (140, 140, 140, 255))
    _gv_texte(px, label, 40, yc - 5, c_txt, xmax=420)
    _gv_texte(px, genre.upper(), 434, yc - 5, (140, 140, 140, 255))
    plein, clair = _gv_bouton(px, GV_CROIX0, GV_CROIX1, yc, False)
    xc = (GV_CROIX0 + GV_CROIX1) // 2
    for t in range(-6, 7):
        for e in (0, 1):
            px[yc + t][xc + t + e - 1] = clair
            px[yc + t][xc - t + e - 1] = clair
    return _gv_ecrire(cle, px, w, h)


def _gv_png_prop(n):
    """Ligne des propositions : nombre, bouton vert VALIDER, croix (ignorer)."""
    cle = 'prop_%d' % n
    if cle in _gv_png and os.path.isfile(_gv_png[cle]):
        return _gv_png[cle]
    w, h = GV_W, GV_H
    px = _gv_fond(w, h, False)
    yc = h // 2
    for x in range(w):
        for y in (0, 1, h - 1, h - 2):
            px[y][x] = (255, 140, 0, 255)
    for y in range(h):
        for x in (0, 1, w - 1, w - 2):
            px[y][x] = (255, 140, 0, 255)
    _gv_texte(px, '%d PROPOSITION%s EN ORANGE' % (n, 'S' if n > 1 else ''), 8, yc - 5, (255, 140, 0, 255), xmax=350)
    for x in range(GV_VAL0, GV_VAL1):
        for y in range(yc - 11, yc + 11):
            px[y][x] = (235, 245, 235, 255) if (x in (GV_VAL0, GV_VAL1 - 1) or y in (yc - 11, yc + 10)) else (24, 110, 62, 255)
    tx = (GV_VAL0 + GV_VAL1) // 2 - (7 * 8 - 2) // 2
    _gv_texte(px, 'VALIDER', tx, yc - 5, (255, 255, 255, 255))
    plein, clair = _gv_bouton(px, GV_CROIX0, GV_CROIX1, yc, False)
    xc = (GV_CROIX0 + GV_CROIX1) // 2
    for t in range(-6, 7):
        for e in (0, 1):
            px[yc + t][xc + t + e - 1] = clair
            px[yc + t][xc - t + e - 1] = clair
    return _gv_ecrire(cle, px, w, h)


def _gv_png_plus(n):
    cle = 'plus_%d' % n
    if cle in _gv_png and os.path.isfile(_gv_png[cle]):
        return _gv_png[cle]
    px = _gv_fond(GV_W, GV_H, False)
    _gv_texte(px, '... + %d AUTRE%s' % (n, 'S' if n > 1 else ''), 40, GV_H // 2 - 5, (140, 140, 140, 255))
    return _gv_ecrire(cle, px, GV_W, GV_H)


def _gv_png_info(txt):
    cle = 'tip_%s' % abs(hash(txt))
    w, h = len(txt) * 8 + 12, 24
    if cle in _gv_png and os.path.isfile(_gv_png[cle]):
        return _gv_png[cle], w, h
    px = [[(246, 246, 246, 255)] * w for _ in range(h)]
    for x in range(w):
        for y in (0, h - 1):
            px[y][x] = (110, 110, 110, 255)
    for y in range(h):
        for x in (0, w - 1):
            px[y][x] = (110, 110, 110, 255)
    _gv_texte(px, txt, 6, 7, (20, 20, 20, 255))
    return _gv_ecrire(cle, px, w, h), w, h


# --- toujours devant le modele (meme principe que Reseau CNC) --------------
_gv_dv = {'ents': [], 'h': None, 'c': None, 'r': 0.0, 't': 0.0}


def _gv_dv_point():
    des = adsk.fusion.Design.cast(_app.activeProduct)
    if des is None:
        return None
    if time.time() - _gv_dv['t'] > 1.0:
        _gv_dv['t'] = time.time()
        bb = des.rootComponent.boundingBox
        if bb is None:
            _gv_dv['c'] = None
        else:
            a, b = bb.minPoint, bb.maxPoint
            _gv_dv['c'] = ((a.x + b.x) / 2.0, (a.y + b.y) / 2.0, (a.z + b.z) / 2.0)
            _gv_dv['r'] = a.distanceTo(b) / 2.0
    c = _gv_dv['c']
    if c is None:
        return None
    cam = _app.activeViewport.camera
    e, t = cam.eye, cam.target
    d = (e.x - t.x, e.y - t.y, e.z - t.z)
    lg = math.sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2])
    if lg < 1e-9:
        return None
    d = (d[0] / lg, d[1] / lg, d[2] / lg)
    ec = (e.x - c[0]) * d[0] + (e.y - c[1]) * d[1] + (e.z - c[2]) * d[2]
    s = min(_gv_dv['r'] * 1.2 + 1.0, ec * 0.5) if ec > 0 else 0.0
    p = adsk.core.Point3D.create(c[0] + d[0] * s, c[1] + d[1] * s, c[2] + d[2] * s)
    occ = des.activeOccurrence
    if occ is not None:
        inv = occ.transform2.copy()
        inv.invert()
        p.transformBy(inv)
    return p


def _gv_dv_appliquer(ents):
    p = _gv_dv_point()
    if p is None:
        return
    m = adsk.core.Matrix3D.create()
    m.translation = adsk.core.Vector3D.create(p.x, p.y, p.z)
    for x in ents:
        x.transform = m


class _GvCamHandler(adsk.core.CameraEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            ents = [x for x in _gv_dv['ents'] if x.isValid]
            _gv_dv['ents'] = ents
            if ents:
                _gv_dv_appliquer(ents)
        except Exception:
            pass


def _gv_dv_poser(ps):
    try:
        _gv_dv['t'] = 0.0
        _gv_dv_appliquer([ps])
        _gv_dv['ents'] = [x for x in _gv_dv['ents'] if x.isValid] + [ps]
        if _gv_dv['h'] is None:
            h = _GvCamHandler()
            _app.cameraChanged.add(h)
            _gv_dv['h'] = h
    except Exception:
        pass


def _gv_dv_arreter():
    try:
        if _gv_dv['h'] is not None:
            _app.cameraChanged.remove(_gv_dv['h'])
    except Exception:
        pass
    _gv_dv['h'] = None
    _gv_dv['ents'] = []


def _gv_rafraichir():
    try:
        _app.activeViewport.refresh()
    except Exception:
        pass


def _gv_tip_effacer():
    g = _gv_tip['g']
    _gv_tip['g'] = None
    _gv_tip['cle'] = None
    try:
        if g is not None and g.isValid:
            g.deleteMe()
            _gv_rafraichir()
    except Exception:
        pass


def _gv_effacer():
    _gv_tip_effacer()
    g = _gv['g']
    _gv['g'] = None
    _gv['sig'] = None
    _gv['lignes'] = []
    try:
        if g is not None and g.isValid:
            g.deleteMe()
    except Exception:
        pass
    _gv_dv_arreter()
    _gv_rafraichir()


def _gv_nom(ent):
    try:
        if isinstance(ent, adsk.fusion.BRepBody):
            ctx = ent.assemblyContext
            return _clean_label(ctx.name if ctx is not None else ent.parentComponent.name)
        return _label_for_face(ent)
    except Exception:
        return '?'


def _gv_maj_ok():
    """Bouton OK cache tant que des propositions orange attendent VALIDER."""
    cmd = _gv.get('cmd')
    if cmd is None:
        return
    try:
        voulu = not _proposes
        if cmd.isOKButtonVisible != voulu:
            cmd.isOKButtonVisible = voulu
    except Exception:
        _dbg('ok visible: ' + traceback.format_exc().strip().splitlines()[-1])


def _gv_maj():
    """(Re)dessine la fenetre : en-tete + une ligne par selection recente."""
    _gv_maj_ok()
    try:
        ents = _picked_entities()
        n = len(ents)
        noms = [(_gv_nom(e), 'Corps' if isinstance(e, adsk.fusion.BRepBody) else 'Face') for e in ents]
        try:
            vp = _app.activeViewport
            taille = (int(vp.width), int(vp.height))
        except Exception:
            taille = None
        npr = len(_proposes)
        sig = (_gv['mode'], _gv['show'], _gv['prop'], _gv['liste'], npr, tuple(noms), taille)
        if sig == _gv['sig'] and _gv['g'] is not None and _gv['g'].isValid:
            return
        _gv_tip_effacer()
        old = _gv['g']
        try:
            if old is not None and old.isValid:
                old.deleteMe()
        except Exception:
            pass
        _gv_dv['ents'] = []
        des = adsk.fusion.Design.cast(_app.activeProduct)
        g = des.activeComponent.customGraphicsGroups.add()   # composant actif : sinon grise
        lignes = ([('prop', None, _gv_png_prop(npr))] if npr else []) + \
            [('entete', None, _gv_png_entete(_gv['mode'], n, _gv['show'], _gv['prop'], _gv['liste']))]
        debut = max(0, n - GV_MAX) if _gv['liste'] else n      # liste repliee par defaut
        if debut and _gv['liste']:
            lignes.append(('plus', None, _gv_png_plus(debut)))
        for i in range(debut, n):
            lignes.append(('ligne', i, _gv_png_ligne(i + 1, noms[i][0], noms[i][1], i == n - 1)))
        k = _gv_dpr()
        nr = len(lignes)
        for r, (_t, _i, png) in enumerate(lignes):
            ps = g.addPointSet(adsk.fusion.CustomGraphicsCoordinates.create([0.0, 0.0, 0.0]), [0],
                               adsk.fusion.CustomGraphicsPointTypes.UserDefinedCustomGraphicsPointType, png)
            ps.isSelectable = False
            ps.viewPlacement = adsk.fusion.CustomGraphicsViewPlacement.create(
                adsk.core.Point3D.create(0, 0, 0), adsk.fusion.ViewCorners.lowerLeftViewCorner,
                adsk.core.Point2D.create(GV_X + GV_W * k / 2.0,
                                         GV_Y + (nr - 1 - r) * (GV_H * k + GV_GAP) + GV_H * k / 2.0))
            _gv_dv_poser(ps)
        _gv['g'] = g
        _gv['sig'] = sig
        _gv['lignes'] = [(t, i) for (t, i, _p) in lignes]
        _gv_rafraichir()
    except Exception:
        _dbg('fenetre: ' + traceback.format_exc())


def _gv_cible(vp, pos):
    """(type, indice, x0, x1, rang) de l'element sous le curseur, sinon None.
    type : 'face', 'corps', 'oeil', 'retour', 'croix', 'ligne'."""
    if _gv['g'] is None or vp is None or pos is None:
        return None
    lignes = _gv['lignes']
    nr = len(lignes)
    k = _gv_dpr()
    h = vp.height * k
    for r, (t, i) in enumerate(lignes):
        yc = h - (GV_Y + (nr - 1 - r) * (GV_H * k + GV_GAP) + GV_H * k / 2.0)
        if not (GV_X <= pos.x <= GV_X + GV_W * k and abs(pos.y - yc) <= GV_H * k / 2.0):
            continue
        x = (pos.x - GV_X) / k
        if t == 'entete':
            for (x0, x1, nom) in ((GV_FACE0, GV_FACE1, 'face'), (GV_CORPS0, GV_CORPS1, 'corps'),
                                  (GV_DESSUS0, GV_DESSUS1, 'dessus'), (GV_SENS0, GV_SENS1, 'sens'),
                                  (GV_COPIES0, GV_COPIES1, 'copies'), (GV_LISTE0, GV_LISTE1, 'liste'),
                                  (GV_OEIL0, GV_OEIL1, 'oeil'), (GV_RET0, GV_RET1, 'retour')):
                if x0 <= x <= x1:
                    return (nom, None, x0, x1, r)
        elif t == 'prop':
            if GV_VAL0 <= x <= GV_VAL1:
                return ('valider', None, GV_VAL0, GV_VAL1, r)
            if GV_CROIX0 <= x <= GV_CROIX1:
                return ('ignorer', None, GV_CROIX0, GV_CROIX1, r)
        elif t == 'ligne' and GV_CROIX0 <= x <= GV_CROIX1:
            return ('croix', i, GV_CROIX0, GV_CROIX1, r)
        return ('ligne', i, 0, 0, r)
    return None


GV_AIDE = {'face': "Selection par face", 'corps': "Selection par corps",
           'oeil': "Afficher les corps choisis", 'oeil_on': "Masquer les corps choisis",
           'liste': "Deplier la liste des choix", 'liste_on': "Replier la liste des choix",
           'retour': "Annuler la derniere selection", 'croix': "Retirer cette selection",
           'dessus': "Proposer les faces du dessus de tous les corps",
           'sens': "Meme sens : toutes les faces orientees comme la face cliquee, en orange",
           'copies': "Copies : la meme face sur tous les corps identiques, en orange",
           'valider': "Valider les propositions", 'ignorer': "Ignorer les propositions"}


def _gv_tip_maj(vp, pos):
    c = _gv_cible(vp, pos)
    if c is not None and c[0] == 'ligne':
        c = None
    cle = None if c is None else (c[0], c[1])
    if cle == _gv_tip['cle'] and (cle is None or (_gv_tip['g'] is not None and _gv_tip['g'].isValid)):
        return
    _gv_tip_effacer()
    if c is None:
        return
    try:
        txt = GV_AIDE['oeil_on' if (c[0] == 'oeil' and _gv['show']) else
                      'liste_on' if (c[0] == 'liste' and _gv['liste']) else c[0]]
        png, w, h = _gv_png_info(txt)
        des = adsk.fusion.Design.cast(_app.activeProduct)
        g = des.activeComponent.customGraphicsGroups.add()
        k = _gv_dpr()
        nr = len(_gv['lignes'])
        gauche = GV_X + (GV_W + 8) * k
        haut = GV_Y + (nr - 1 - c[4]) * (GV_H * k + GV_GAP) + (GV_H * k - h * k) / 2.0
        ps = g.addPointSet(adsk.fusion.CustomGraphicsCoordinates.create([0.0, 0.0, 0.0]), [0],
                           adsk.fusion.CustomGraphicsPointTypes.UserDefinedCustomGraphicsPointType, png)
        ps.isSelectable = False
        ps.viewPlacement = adsk.fusion.CustomGraphicsViewPlacement.create(
            adsk.core.Point3D.create(0, 0, 0), adsk.fusion.ViewCorners.lowerLeftViewCorner,
            adsk.core.Point2D.create(gauche + w * k / 2.0, haut + h * k / 2.0))
        _gv_dv_poser(ps)
        _gv_tip['g'] = g
        _gv_tip['cle'] = cle
        _gv_rafraichir()
    except Exception:
        _dbg('tip: ' + traceback.format_exc())


def _gv_reafficher(ents):
    """Reaffiche tout de suite les corps des entites retirees de la selection."""
    for e in ents:
        try:
            b = _entity_body(e)
            if not b.isLightBulbOn:
                b.isLightBulbOn = True
        except Exception:
            pass


def _gv_apercu(cmd):
    try:
        cmd.doExecutePreview()
    except Exception:
        pass


def _gv_clic(cmd, c):
    inps = cmd.commandInputs
    sel = inps.itemById("face_sel")
    t = c[0]
    if t in ('face', 'corps'):
        mode = 'Face' if t == 'face' else 'Corps'
        if mode != _gv['mode']:
            rg = inps.itemById("sel_mode")
            for li in rg.listItems:
                if li.name == mode:
                    li.isSelected = True
            _gv['mode'] = mode
            _apply_sel_mode(sel, mode)
    elif t == 'retour':
        if _proposes:
            _ignorer_proposes()
        else:
            ents = _picked_entities()
            _undo_last_face(sel)
            if ents:
                _gv_reafficher(ents[-1:])
            _gv_apercu(cmd)
    elif t == 'dessus':
        _proposer_dessus()
        _prop_dessiner()
    elif t in ('sens', 'copies'):
        _gv['prop'] = None if _gv['prop'] == t else t
    elif t == 'valider':
        _valider_proposes()
        _gv_apercu(cmd)
    elif t == 'ignorer':
        _ignorer_proposes()
    elif t == 'croix' and c[1] is not None and 0 <= c[1] < len(_picked):
        ents = _picked_entities()
        del _picked[c[1]]
        if c[1] < len(ents):
            _gv_reafficher([ents[c[1]]])
        _gv_apercu(cmd)
    elif t == 'liste':
        _gv['liste'] = not _gv['liste']
    elif t == 'oeil':
        sp = inps.itemById("show_picked")
        sp.value = not sp.value
        _gv['show'] = sp.value
        if sp.value:
            _unhide_remembered()
        _gv_apercu(cmd)
    try:
        sel.hasFocus = True
    except Exception:
        pass
    _gv_maj()


class _GvMouseDownHandler(adsk.core.MouseEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            _gv_souris['vp'], _gv_souris['pos'] = args.viewport, args.viewportPosition
            c = _gv_cible(args.viewport, args.viewportPosition)
            if c is None:
                _gv_bloc['t'] = 0.0
                return
            _gv_bloc['t'] = time.time()      # le clic ne doit rien selectionner derriere
            _gv_tip_effacer()
            _gv_clic(adsk.core.Command.cast(args.firingEvent.sender), c)
        except Exception:
            _dbg('mouseDown: ' + traceback.format_exc())


class _GvKeyDownHandler(adsk.core.KeyboardEventHandler):
    """Entree : valide les propositions en orange (OK est grise tant qu'il
    en reste, donc Entree ne lance pas la gravure a ce moment-la)."""
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            if args.keyCode == adsk.core.KeyCodes.EnterKeyCode and _proposes:
                cmd = adsk.core.Command.cast(args.firingEvent.sender)
                _valider_proposes()
                _gv_apercu(cmd)
                _gv_maj()
        except Exception:
            _dbg('keyDown: ' + traceback.format_exc())


class _GvMouseMoveHandler(adsk.core.MouseEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            _gv_souris['vp'], _gv_souris['pos'] = args.viewport, args.viewportPosition
            _gv_tip_maj(args.viewport, args.viewportPosition)
        except Exception:
            pass


def _gv_sous_souris():
    return _gv_cible(_gv_souris['vp'], _gv_souris['pos']) is not None



# ---------------------------------------------------------------------------
# Propositions (apercu orange, a valider) : faces du dessus de tous les
# corps visibles, et meme face / meme corps sur les corps identiques (copies
# de Reseau CNC, montants, traverses...). Rien n'est choisi tant que le
# bouton VALIDER de la fenetre n'est pas clique (ou OK de la commande).
# ---------------------------------------------------------------------------
_proposes = []      # liste de (entityToken, entite)
_prop_g = {'g': None}
_sig_cache = {}


def _tous_corps():
    """Corps solides visibles du modele (proxys dans le contexte racine)."""
    des = adsk.fusion.Design.cast(_app.activeProduct)
    root = des.rootComponent
    out = []
    for b in root.bRepBodies:
        out.append(b)
    for occ in root.allOccurrences:
        try:
            for b in occ.bRepBodies:
                out.append(b)
        except Exception:
            pass
    res = []
    for b in out:
        try:
            if b.isSolid and b.isVisible:
                res.append(b)
        except Exception:
            pass
    return res


def _corps_exclus():
    excl = list(_selected_bodies(None))
    for tok, e in _proposes:
        e = _resolve_picked(tok, e)
        if e is not None:
            try:
                excl.append(_entity_body(e))
            except Exception:
                pass
    return excl


def _signature(b):
    try:
        k = b.entityToken
    except Exception:
        k = None
    if k is not None and k in _sig_cache:
        return _sig_cache[k]
    try:
        s = (round(b.volume, 2), round(b.area, 1), b.faces.count, b.edges.count)
    except Exception:
        s = None
    if k is not None:
        _sig_cache[k] = s
    return s


def _centre_bb(b):
    bb = b.boundingBox
    a, c = bb.minPoint, bb.maxPoint
    return ((a.x + c.x) / 2.0, (a.y + c.y) / 2.0, (a.z + c.z) / 2.0)


def _centre_face(f):
    try:
        c = f.centroid
        return (c.x, c.y, c.z)
    except Exception:
        p = f.pointOnFace
        return (p.x, p.y, p.z)


def _face_dessus(b):
    """Face plane du dessus d'un corps : normale sortante vers +Z (monde),
    la plus haute, puis la plus grande."""
    best = None
    for f in b.faces:
        try:
            if f.geometry.surfaceType != adsk.core.SurfaceTypes.PlaneSurfaceType:
                continue
            n = _face_normal(f)
            if n is None or n[2] < 0.999:
                continue
            z = _centre_face(f)[2]
            k = (round(z, 3), f.area)
            if best is None or k > best[0]:
                best = (k, f)
        except Exception:
            continue
    return None if best is None else best[1]


def _face_equivalente(ref, b):
    """Face de b equivalente a la face ref (corps identique) : meme aire,
    meme normale (monde), meme position par rapport au centre du corps."""
    try:
        n0 = _face_normal(ref)
        a0 = ref.area
        c0 = _centre_face(ref)
        cb0 = _centre_bb(ref.body)
        off0 = (c0[0] - cb0[0], c0[1] - cb0[1], c0[2] - cb0[2])
    except Exception:
        return None
    cb = _centre_bb(b)
    best = None
    for f in b.faces:
        try:
            if abs(f.area - a0) > max(1e-3, a0 * 1e-4):
                continue
            n = _face_normal(f)
            if n is None or n[0] * n0[0] + n[1] * n0[1] + n[2] * n0[2] < 0.999:
                continue
            c = _centre_face(f)
            off = (c[0] - cb[0], c[1] - cb[1], c[2] - cb[2])
            d = math.sqrt(sum((off[i] - off0[i]) ** 2 for i in range(3)))
            if best is None or d < best[0]:
                best = (d, f)
        except Exception:
            continue
    if best is None or best[0] > 0.05:
        return None
    return best[1]


def _ajouter_proposes(ents):
    for e in ents:
        try:
            _proposes.append((e.entityToken, e))
        except Exception:
            _proposes.append((None, e))


def _proposer_dessus():
    t0 = time.time()
    excl = _corps_exclus()
    nouv = []
    for b in _tous_corps():
        if any(x == b for x in excl):
            continue
        f = _face_dessus(b)
        if f is not None:
            nouv.append(f)
    _ajouter_proposes(nouv)
    _dbg(f'faces du dessus : {len(nouv)} proposee(s) en {time.time() - t0:.2f}s')
    return len(nouv)


_com_cache = {}


def _com(b):
    """Centre de gravite du corps (dans le contexte racine), en cache."""
    try:
        k = b.entityToken
    except Exception:
        k = None
    if k is not None and k in _com_cache:
        return _com_cache[k]
    try:
        c = b.getPhysicalProperties(adsk.fusion.CalculationAccuracy.LowCalculationAccuracy).centerOfMass
        r = (c.x, c.y, c.z)
    except Exception:
        r = _centre_bb(b)
    if k is not None:
        _com_cache[k] = r
    return r


def _desc_face(f, com):
    """Description de la face par rapport a son corps, independante de la
    position et de l'orientation du corps : normale, direction centre du
    corps -> centre de la face, distance le long de la normale."""
    n = _face_normal(f)
    c = _centre_face(f)
    d = (c[0] - com[0], c[1] - com[1], c[2] - com[2])
    h = d[0] * n[0] + d[1] * n[1] + d[2] * n[2]
    l = math.sqrt(d[0] ** 2 + d[1] ** 2 + d[2] ** 2) or 1.0
    return n, (d[0] / l, d[1] / l, d[2] / l), h, l


def _face_meme_place(ref, com_ref, b):
    """Face de b (corps identique) a la meme place que ref dans son corps.
    b peut etre tourne : on compare la normale et la direction depuis le
    centre du corps a celles de ref, qui vient d'un corps VOISIN (la
    rotation entre deux voisins d'un reseau reste faible)."""
    try:
        a0 = ref.area
        e0 = ref.edges.count
        n0, u0, h0, l0 = _desc_face(ref, com_ref)
    except Exception:
        return None
    com = _com(b)
    best = None
    for f in b.faces:
        try:
            if abs(f.area - a0) > max(1e-3, a0 * 1e-4) or f.edges.count != e0:
                continue
            n, u, h, l = _desc_face(f, com)
            if abs(h - h0) > 0.05 or abs(l - l0) > 0.05:
                continue
            sc = (1.0 - (n[0] * n0[0] + n[1] * n0[1] + n[2] * n0[2])) + \
                 (1.0 - (u[0] * u0[0] + u[1] * u0[1] + u[2] * u0[2]))
            if best is None or sc < best[0]:
                best = (sc, f)
        except Exception:
            continue
    return None if best is None else best[1]


def _proposer_identiques(ent):
    """Corps identiques (meme volume, aire, nombre de faces et d'aretes) :
    meme corps (mode Corps) ou meme face (mode Face). Pour les faces, on
    avance de proche en proche (corps le plus proche d'un corps deja traite)
    pour suivre un reseau le long d'une courbe ou les corps tournent."""
    t0 = time.time()
    try:
        b0 = _entity_body(ent)
    except Exception:
        return 0
    s0 = _signature(b0)
    if s0 is None:
        return 0
    excl = _corps_exclus() + [b0]
    cands = [b for b in _tous_corps()
             if _signature(b) == s0 and not any(x == b for x in excl)]
    nouv = []
    if isinstance(ent, adsk.fusion.BRepBody):
        nouv = cands
    else:
        faits = [(_com(b0), ent)]
        reste = [(b, _com(b)) for b in cands]
        # distance de chaque corps restant au corps traite le plus proche
        dist = []
        for b, c in reste:
            d = sum((c[i] - faits[0][0][i]) ** 2 for i in range(3))
            dist.append([d, 0])
        while reste:
            j = min(range(len(reste)), key=lambda q: dist[q][0])
            b, c = reste.pop(j)
            _d, k = dist.pop(j)
            com_ref, f_ref = faits[k]
            f = _face_meme_place(f_ref, com_ref, b)
            if f is None:
                continue
            nouv.append(f)
            faits.append((c, f))
            kk = len(faits) - 1
            for q, (bq, cq) in enumerate(reste):
                d = sum((cq[i] - c[i]) ** 2 for i in range(3))
                if d < dist[q][0]:
                    dist[q] = [d, kk]
    _ajouter_proposes(nouv)
    _dbg(f'identiques : {len(nouv)}/{len(cands)} proposee(s) en {time.time() - t0:.2f}s')
    return len(nouv)


def _est_grande_face(f):
    """Vrai si f est une grande face de son corps (pas un chant)."""
    try:
        a_max = 0.0
        for g in f.body.faces:
            try:
                if g.geometry.surfaceType == adsk.core.SurfaceTypes.PlaneSurfaceType:
                    a_max = max(a_max, g.area)
            except Exception:
                pass
        return f.area >= 0.5 * a_max
    except Exception:
        return False


def _proposer_sens(ent):
    """Meme sens : sur chaque corps visible, la face plane dont la normale
    sortante (monde) est orientee comme celle de la face cliquee (a 3 degres
    pres) ; s'il y en a plusieurs, la plus en avant dans ce sens (la face
    du dessus pour une face qui regarde vers +Z), puis la plus grande."""
    t0 = time.time()
    try:
        ref = ent if isinstance(ent, adsk.fusion.BRepFace) else _auto_face(ent)
        n0 = _face_normal(ref)
        b0 = _entity_body(ent)
    except Exception:
        return 0
    if n0 is None:
        return 0
    cos_max = math.cos(math.radians(3.0))
    excl = _corps_exclus() + [b0]
    # Chants exclus (panneaux CP15/CP18) : seules les grandes faces d'un
    # corps comptent, c.-a-d. les faces planes d'au moins la moitie de
    # l'aire de sa plus grande face plane. Si la face de reference est
    # elle-meme un chant, on garde l'ancien comportement (tout).
    sans_chants = _est_grande_face(ref)
    nouv = []
    for b in _tous_corps():
        if any(x == b for x in excl):
            continue
        best = None
        planes = []
        for f in b.faces:
            try:
                if f.geometry.surfaceType == adsk.core.SurfaceTypes.PlaneSurfaceType:
                    planes.append(f)
            except Exception:
                pass
        a_max = max([f.area for f in planes] or [0.0])
        for f in planes:
            try:
                if sans_chants and f.area < 0.5 * a_max:
                    continue
                n = _face_normal(f)
                if n is None or n[0] * n0[0] + n[1] * n0[1] + n[2] * n0[2] < cos_max:
                    continue
                c = _centre_face(f)
                k = (round(c[0] * n0[0] + c[1] * n0[1] + c[2] * n0[2], 3), f.area)
                if best is None or k > best[0]:
                    best = (k, f)
            except Exception:
                continue
        if best is not None:
            nouv.append(best[1])
    _ajouter_proposes(nouv)
    _dbg(f'meme sens : {len(nouv)} proposee(s) en {time.time() - t0:.2f}s')
    return len(nouv)


def _proposes_entites():
    out = []
    for tok, e in _proposes:
        e = _resolve_picked(tok, e)
        if e is not None:
            out.append(e)
    return out


def _prop_effacer():
    g = _prop_g['g']
    _prop_g['g'] = None
    try:
        if g is not None and g.isValid:
            g.deleteMe()
    except Exception:
        pass


def _prop_dessiner():
    """Apercu orange des propositions (CustomGraphics uniquement)."""
    _prop_effacer()
    ents = _proposes_entites()
    if not ents:
        _gv_rafraichir()
        return
    try:
        des = adsk.fusion.Design.cast(_app.activeProduct)
        g = des.rootComponent.customGraphicsGroups.add()
        orange = adsk.core.Color.create(255, 90, 0, 255)
        voile = adsk.core.Color.create(255, 90, 0, 90)
        for e in ents:
            faces = [e] if isinstance(e, adsk.fusion.BRepFace) else \
                [f for f in [_auto_face(e)] if f is not None]
            for f in faces:
                try:
                    mc = f.meshManager.createMeshCalculator()
                    mc.setQuality(adsk.fusion.TriangleMeshQualityOptions.LowQualityTriangleMesh)
                    tm = mc.calculate()
                    cc = adsk.fusion.CustomGraphicsCoordinates.create(tm.nodeCoordinatesAsDouble)
                    ms = g.addMesh(cc, tm.nodeIndices, tm.normalVectorsAsDouble, tm.nodeIndices)
                    ms.color = adsk.fusion.CustomGraphicsSolidColorEffect.create(voile)
                    ms.isSelectable = False
                except Exception:
                    pass
                pts = []
                idx = []
                for ed in f.edges:
                    try:
                        ev = ed.evaluator
                        ok, t0, t1 = ev.getParameterExtents()
                        ok2, sp = ev.getStrokes(t0, t1, 0.05)
                        sp = list(sp) if ok2 else []
                    except Exception:
                        sp = []
                    for k in range(len(sp) - 1):
                        base = len(pts) // 3
                        for p in (sp[k], sp[k + 1]):
                            pts += [p.x, p.y, p.z]
                        idx += [base, base + 1]
                if pts:
                    ln = g.addLines(adsk.fusion.CustomGraphicsCoordinates.create(pts), idx, False)
                    ln.color = adsk.fusion.CustomGraphicsSolidColorEffect.create(orange)
                    ln.weight = 4.0
                    ln.depthPriority = 1
                    ln.isSelectable = False
        _prop_g['g'] = g
    except Exception:
        _dbg('apercu propositions: ' + traceback.format_exc())
    _gv_rafraichir()


def _valider_proposes():
    """Les propositions deviennent des choix (leurs corps seront masques)."""
    ents = _proposes_entites()
    del _proposes[:]
    deja = list(_selected_bodies(None))
    for e in ents:
        try:
            b = _entity_body(e)
        except Exception:
            continue
        if any(x == b for x in deja):
            continue
        deja.append(b)
        try:
            _picked.append((e.entityToken, e))
        except Exception:
            _picked.append((None, e))
    _prop_effacer()
    return len(ents)


def _ignorer_proposes():
    del _proposes[:]
    _prop_effacer()
    _gv_rafraichir()


def _maj_police(inps):
    """Police trait simple : style, profondeur et extrusion ne servent pas."""
    try:
        ligne = inps.itemById("font_name").selectedItem.name == LINE_FONT_NAME
        for iid in ("grp_style", "depth", "do_extrude"):
            it = inps.itemById(iid)
            if it:
                it.isVisible = not ligne
    except Exception:
        pass


class MyInputChangedHandler(adsk.core.InputChangedEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            if _sync_guard[0]:
                return
            inp = args.input
            cmd = adsk.core.Command.cast(args.firingEvent.sender)
            inps = cmd.commandInputs
            sel = inps.itemById("face_sel")
            if inp.id == "font_name":
                _maj_police(inps)
            if inp.id == "show_picked":
                _gv['show'] = inp.value
                _gv_maj()
            if inp.id == "sel_mode":
                _gv['mode'] = inp.selectedItem.name
                _apply_sel_mode(sel, inp.selectedItem.name)
                sel.hasFocus = True
                _gv_maj()
            if inp.id == "undo_last":
                _undo_last_face(sel)
                try:
                    inp.value = False
                except Exception:
                    pass
                sel.hasFocus = True
            if inp.id == "face_sel":
                if time.time() - _gv_bloc['t'] < 1.0:
                    # clic sur la fenetre du bas a gauche : rien a selectionner
                    _sync_guard[0] = True
                    try:
                        sel.clearSelection()
                    finally:
                        _sync_guard[0] = False
                else:
                    nouv = _absorb_selection(sel, _gv['prop'] is not None)
                    if nouv and _gv['prop'] == 'copies':
                        for e in nouv:
                            _proposer_identiques(e)
                    elif nouv and _gv['prop'] == 'sens':
                        for e in nouv:
                            _proposer_sens(e)
                    if nouv:
                        _prop_dessiner()
                sel.hasFocus = True
            if inp.id in ("undo_last", "face_sel"):
                _gv_maj()
                _dbg(f'selection : {len(_picked)} face(s)')
        except Exception:
            _dbg('EXCEPTION InputChanged: ' + traceback.format_exc())


_gv_preview_log = [0]


class MyPreviewHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            cmd = adsk.core.Command.cast(args.firingEvent.sender)
            sel = cmd.commandInputs.itemById("face_sel")
            show = cmd.commandInputs.itemById("show_picked").value
            if not show:
                for b in _selected_bodies(sel):
                    try:
                        if b.isLightBulbOn:
                            _hidden_tokens.add(b.entityToken)
                            b.isLightBulbOn = False
                    except Exception:
                        _dbg('hide body: ' + traceback.format_exc())
            # Preview "jetable" : Fusion l'annule avant Execute, qui
            # repart donc des corps a leur visibilite d'origine.
            args.isValidResult = False
            # L'apercu de Fusion fait disparaitre la fenetre du bas a gauche
            # et l'apercu orange dessines juste avant (retour du 2026-11-12 :
            # ils ne revenaient qu'en bougeant la camera) : on les redessine
            # a la fin de chaque apercu.
            try:
                gv_ok = _gv['g'] is not None and _gv['g'].isValid
                pr_ok = _prop_g['g'] is not None and _prop_g['g'].isValid
                if _gv_preview_log[0] < 20:
                    _gv_preview_log[0] += 1
                    _dbg(f'apercu : fenetre valide={gv_ok} orange valide={pr_ok}')
            except Exception:
                pass
            _gv['sig'] = None
            _gv_maj()
            if _proposes:
                _prop_dessiner()
        except Exception:
            _dbg('EXCEPTION Preview: ' + traceback.format_exc())


class MyPreSelectHandler(adsk.core.SelectionEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        # Refuse toute face d'un corps deja choisi (y compris la face deja
        # selectionnee : pour la retirer, bouton "Annuler la derniere face").
        try:
            if _gv_sous_souris():
                args.isSelectable = False
                return
            ent = args.selection.entity
            if not isinstance(ent, (adsk.fusion.BRepFace, adsk.fusion.BRepBody)):
                return
            cmd = adsk.core.Command.cast(args.firingEvent.sender)
            sel = cmd.commandInputs.itemById("face_sel")
            body = _entity_body(ent)
            if any(b == body for b in _selected_bodies(sel)):
                args.isSelectable = False
        except Exception:
            pass


class MyValidateHandler(adsk.core.ValidateInputsEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            sel = args.inputs.itemById("face_sel")
            # Toujours valide des qu'il y a un choix ou une proposition : si
            # la commande devient invalide, Fusion ne relance plus l'apercu
            # et reaffiche les corps deja masques (bug du 2026-11-12). Le
            # bouton OK est cache tant qu'il reste des propositions (voir
            # _gv_maj_ok) : Entree les valide au lieu de lancer la gravure.
            args.areInputsValid = len(_picked_entities(sel)) + len(_proposes) > 0
        except Exception:
            pass


class MyCommandDestroyHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        _gv_effacer()
        _gv['cmd'] = None
        _prop_effacer()
        del _proposes[:]
        _sig_cache.clear()
        _com_cache.clear()
        _unhide_remembered()
        del _picked[:]


class MyActivateHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        _gv_maj()


class MyCommandCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            cmd = args.command; inps = cmd.commandInputs; s = _load_settings()
            mode = s.get("sel_mode", "Face")
            # Choix Face / Corps, retour arriere et affichage des corps
            # choisis : dans la fenetre du bas a gauche de la vue. Les
            # entrees restent dans la commande (masquees) pour la logique.
            rg = inps.addRadioButtonGroupCommandInput("sel_mode", "Selection par")
            rg.listItems.add("Face", mode != "Corps")
            rg.listItems.add("Corps", mode == "Corps")
            rg.isVisible = False
            sel = inps.addSelectionInput("face_sel", "A graver",
                "Face : cliquez la face a graver. Corps : cliquez le panneau, la grande face est choisie automatiquement")
            sel.addSelectionFilter("SolidBodies" if mode == "Corps" else "PlanarFaces")
            sel.setSelectionLimits(0, 0)
            sel.tooltip = "Choix Face / Corps et retour arriere : fenetre en bas a gauche de la vue"
            ul = inps.addBoolValueInput("undo_last", "Annuler la derniere selection", False, "", False)
            ul.isVisible = False
            sp = inps.addBoolValueInput("show_picked", "Afficher les corps choisis", True, "", False)
            sp.isVisible = False
            _hidden_tokens.clear()
            del _picked[:]
            _gv['mode'] = "Corps" if mode == "Corps" else "Face"
            _gv['show'] = False
            _gv['liste'] = False
            _gv['cmd'] = cmd
            _gv['prop'] = s.get("prop_mode", "sens")
            if _gv['prop'] not in ("sens", "copies"):
                _gv['prop'] = None
            _gv_bloc['t'] = 0.0
            del _proposes[:]
            _sig_cache.clear()
            _com_cache.clear()
            for H, ev in ((MyInputChangedHandler, cmd.inputChanged),
                          (MyValidateHandler, cmd.validateInputs),
                          (MyPreviewHandler, cmd.executePreview),
                          (MyPreSelectHandler, cmd.preSelect),
                          (MyActivateHandler, cmd.activate),
                          (_GvMouseDownHandler, cmd.mouseDown),
                          (_GvMouseMoveHandler, cmd.mouseMove),
                          (_GvKeyDownHandler, cmd.keyDown),
                          (MyCommandDestroyHandler, cmd.destroy)):
                h = H(); ev.add(h); _handlers.append(h)

            g_txt = inps.addGroupCommandInput("grp_texte", "Texte")
            g_txt.isExpanded = True
            gi = g_txt.children
            ct = gi.addStringValueInput("custom_text", "Texte", s.get("custom_text", ""))
            ct.tooltip = "Laisser vide pour graver le nom du composant"
            fd = gi.addDropDownCommandInput("font_name", "Police", adsk.core.DropDownStyles.TextListDropDownStyle)
            for f in FONTS: fd.listItems.add(f, f == s.get("font_name", "Arial"))
            gi.addValueInput("text_height", "Hauteur", "mm", adsk.core.ValueInput.createByReal(s.get("text_height", 5.0)))
            gi.addValueInput("margin", "Marge (%)", "", adsk.core.ValueInput.createByReal(s.get("margin", 5.0)))

            g_sty = inps.addGroupCommandInput("grp_style", "Style")
            g_sty.isExpanded = bool(s.get("bold", False) or s.get("italic", False) or s.get("underline", False))
            gs = g_sty.children
            gs.addBoolValueInput("bold", "Gras", True, "", s.get("bold", False))
            gs.addBoolValueInput("italic", "Italique", True, "", s.get("italic", False))
            gs.addBoolValueInput("underline", "Souligne", True, "", s.get("underline", False))

            inps.addValueInput("depth", "Profondeur", "mm", adsk.core.ValueInput.createByReal(s.get("depth", 0.2)))
            inps.addBoolValueInput("do_extrude", "Extruder (graver)", True, "", s.get("do_extrude", True))
            _maj_police(inps)
            onExec = MyCommandExecuteHandler(); cmd.execute.add(onExec); _handlers.append(onExec)
        except Exception:
            _ui.messageBox(traceback.format_exc())


class MyCommandExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            cmd = adsk.core.Command.cast(args.firingEvent.sender); inps = cmd.commandInputs
            _gv_effacer()
            _valider_proposes()        # propositions encore en orange : gravees aussi
            sel = inps.itemById("face_sel")
            custom_text = inps.itemById("custom_text").value.strip()
            fn = inps.itemById("font_name").selectedItem.name
            th = inps.itemById("text_height").value
            dc = inps.itemById("depth").value
            bold = inps.itemById("bold").value
            italic = inps.itemById("italic").value
            under = inps.itemById("underline").value
            mp = inps.itemById("margin").value / 100.0
            do_extrude = inps.itemById("do_extrude").value
            _save_settings({"font_name": fn, "text_height": th, "bold": bold, "italic": italic,
                "underline": under, "depth": dc, "margin": inps.itemById("margin").value,
                "do_extrude": do_extrude, "custom_text": custom_text,
                "sel_mode": inps.itemById("sel_mode").selectedItem.name,
                "prop_mode": _gv['prop'] or ""})
            style = 0
            if bold:   style |= adsk.fusion.TextStyles.TextStyleBold
            if italic: style |= adsk.fusion.TextStyles.TextStyleItalic
            if under:  style |= adsk.fusion.TextStyles.TextStyleUnderline
            faces = []
            auto_errors = []
            for ent in _picked_entities(sel):
                if isinstance(ent, adsk.fusion.BRepBody):
                    f = _auto_face(ent)
                    if f is None:
                        auto_errors.append(f'corps {ent.name} : aucune face plane')
                        continue
                    faces.append(f)
                else:
                    faces.append(ent)
            _unhide_remembered()
            design = adsk.fusion.Design.cast(_app.activeProduct)
            timeline = design.timeline
            start_index = timeline.markerPosition

            _dbg(f'=== Execute Gravure CNC : {len(faces)} face(s), '
                 f'texte={custom_text!r} police={fn} ===')

            n_ok = 0
            errors = list(auto_errors)
            font_warnings = []
            # Pour la police "trait simple" : esquisse(s) creee(s) dans le
            # composant RACINE du projet, pour toutes les gravures de cette
            # execution - quel que soit le corps/composant d'origine de
            # chaque face (voir _engrave/shared_sketch pour le repere monde
            # reel utilise pour y placer correctement chaque texte).
            #
            # Une seule GROSSE esquisse pour toute l'execution rendait la
            # modification manuelle penible ensuite (des centaines de
            # traits melanges, dur a trier/supprimer en partie) - on
            # decoupe donc en plusieurs esquisses de LINE_SKETCH_BATCH_SIZE
            # gravures maximum chacune (demande explicite de l'utilisateur) :
            # la 1ere esquisse recoit les gravures 1 a 40, une 2e est creee
            # pour les gravures 41 a 80, etc. Chaque esquisse du lot reste
            # journalisee dans line_sketches pour repasser son
            # isComputeDeferred a False a la fin (voir plus bas).
            LINE_SKETCH_BATCH_SIZE = 40
            root_comp = design.rootComponent
            line_sketches = []
            shared_line_sketch = None
            n_in_current_sketch = 0

            def _new_line_sketch():
                sk = root_comp.sketches.add(root_comp.xYConstructionPlane)
                idx = len(line_sketches) + 1
                sk.name = "Gravure CNC (trait simple)" if idx == 1 else f"Gravure CNC (trait simple) {idx}"
                # Mesure en direct : ajouter des SketchLines dans une
                # esquisse qui en contient deja beaucoup devient de plus en
                # plus lent (Fusion recalcule profils/contraintes a chaque
                # ajout) - avec des dizaines de gravures dans la MEME
                # esquisse partagee, ce cout croissant (quasi quadratique
                # sur l'ensemble de l'execution) finissait par dominer le
                # temps total, bien plus que la recherche de placement.
                # isComputeDeferred=True suspend ce recalcul pendant tous
                # les ajouts ; le recalcul final (une seule fois, a la
                # fin) ne coute presque rien - mesure : ~5x plus rapide sur
                # un test de 300 segments (0.20s/lot de 20 segments a la
                # fin sans, 0.037s avec).
                try:
                    sk.isComputeDeferred = True
                except Exception:
                    pass
                line_sketches.append(sk)
                return sk

            reperes = [None] * len(faces)
            if fn == LINE_FONT_NAME:
                t_rep = time.time()
                reperes = _reperes_faces(faces)
                _dbg(f'reperes de {sum(1 for r in reperes if r is not None)}/{len(faces)} face(s) en {time.time() - t_rep:.2f}s')
                shared_line_sketch = _new_line_sketch()
            barre = cnc_progress.Barre('Gravure CNC', 'Gravure des faces...', total=len(faces)).ouvrir()
            try:
                for i, face in enumerate(faces):
                    barre.avance()
                    try:
                        if fn == LINE_FONT_NAME and n_in_current_sketch >= LINE_SKETCH_BATCH_SIZE:
                            # Cette esquisse a atteint son quota : on la
                            # cloture (recalcul final) et on en demarre une
                            # nouvelle pour la suite - voir LINE_SKETCH_BATCH_SIZE.
                            try:
                                shared_line_sketch.isComputeDeferred = False
                            except Exception:
                                pass
                            shared_line_sketch = _new_line_sketch()
                            n_in_current_sketch = 0
                        label = custom_text if custom_text else _label_for_face(face)
                        xf_pre = None
                        try:
                            xf_pre = reperes[i]
                        except Exception:
                            xf_pre = None
                        warn = _engrave(face, label, fn, th, dc, style, mp, do_extrude,
                                         shared_line_sketch, xf_pre)
                        if warn:
                            font_warnings.append(f'face[{i}]: {warn}')
                        n_ok += 1
                        if fn == LINE_FONT_NAME:
                            n_in_current_sketch += 1
                    except Exception:
                        err = traceback.format_exc().strip().splitlines()[-1]
                        errors.append(f'face[{i}]: {err}')
                        _dbg(f'face[{i}] EXCEPTION: {traceback.format_exc()}')
            finally:
                barre.fin()
                # TOUJOURS repasser isComputeDeferred a False sur TOUTES les
                # esquisses creees, meme en cas d'exception inattendue dans
                # la boucle - sinon une esquisse partagee resterait "gelee"
                # (profils non recalcules) pour le reste de la session Fusion.
                for sk in line_sketches:
                    try:
                        sk.isComputeDeferred = False
                    except Exception:
                        pass

            # Fusion exige au moins 2 features pour former un groupe (sinon
            # RuntimeError) : si une seule face a ete gravee, on se
            # contente de renommer la feature creee.
            end_index = timeline.markerPosition - 1
            if end_index > start_index:
                try:
                    grp = timeline.timelineGroups.add(start_index, end_index)
                    if grp:
                        grp.name = "Gravure CNC"
                        grp.isCollapsed = True
                except Exception:
                    pass
            elif end_index == start_index:
                try:
                    timeline.item(end_index).entity.name = "Gravure CNC"
                except Exception:
                    pass
            _app.activeViewport.fit()
            effective_extrude = do_extrude and fn != LINE_FONT_NAME
            action = "gravure(s) creee(s)" if effective_extrude else "esquisse(s) creee(s)"
            msg = f'{n_ok}/{len(faces)} {action}.'
            if do_extrude and fn == LINE_FONT_NAME:
                msg += ("\n(Police \"trait simple\" : esquisse seule creee - "
                        "cette police est a traits ouverts, elle ne peut pas etre extrudee.)")
            if font_warnings:
                msg += "\n\nAvertissements :\n" + "\n".join(font_warnings)
            if errors:
                msg += "\n\nEchecs :\n" + "\n".join(errors)
            _ui.messageBox(msg, "Gravure CNC")
            _dbg(f'=== Fin Execute : n_ok={n_ok}/{len(faces)} errors={errors} '
                 f'warnings={font_warnings} ===')
        except Exception:
            _ui.messageBox('Erreur execution Gravure CNC:\n' + traceback.format_exc())
            _dbg('EXCEPTION Execute: ' + traceback.format_exc())


def _clean_label(name):
    """Nettoie le nom d'occurrence/composant brut de Fusion pour la gravure :
    - retire le suffixe d'instance ":<numero>" en fin de nom (ex "B (1):1" -> "B (1)")
    - retire les suffixes de copie miroir Fusion (ex "(symetrie miroir)")
    - remplace les parentheses autour d'un numero d'instance par un tiret
      (ex "F (5)" ou "F(5)" -> "F-5") : on ne veut pas graver les
      parentheses elles-memes, seulement le contenu, separe du nom par un
      tiret pour rester lisible une fois grave.
    """
    if not name:
        return name
    name = re.sub(r':\d+$', '', name)
    name = re.sub(r'\s*\(sym[ée]trie\s+miroir\)', '', name, flags=re.IGNORECASE)
    name = re.sub(r'\s*\(mirror(?:\s+copy)?\)', '', name, flags=re.IGNORECASE)
    # Parentheses restantes (ex numero d'instance "F (5)"/"F(5)") : on les
    # remplace par un tiret devant le contenu, ex "G1 (5)"/"G1(5)" -> "G1-5".
    name = re.sub(r'\s*\(([^)]*)\)', r'-\1', name)
    return name.strip()


def _label_for_face(face):
    """Texte par defaut grave sur la face (quand aucun texte personnalise
    n'est saisi) : le nom de l'OCCURRENCE de la face si elle en a une (donc
    unique par instance dans un assemblage - deux exemplaires du meme
    composant sont bien distingues, ex. "Panneau:1" / "Panneau:2"), sinon
    le nom du composant (design mono-composant, sans occurrence). Le nom
    brut Fusion est ensuite nettoye des suffixes techniques (numero
    d'instance, mention de symetrie miroir)."""
    try:
        ctx = face.assemblyContext
        if ctx is not None:
            return _clean_label(ctx.name)
    except Exception:
        pass
    try:
        return _clean_label(face.body.parentComponent.name)
    except Exception:
        return "?"


def _resolve_face(face):
    try:
        native = face.nativeObject
        if native is not None: return native
    except Exception: pass
    return face


def _face_normal(face):
    """Normale unitaire SORTANTE de la face plane (pointe hors de la
    matiere), dans le meme repere natif que les autres geometries utilisees
    dans _engrave (vertex.geometry, etc.) - sert a tester si un point situe
    sur le plan de la face est bien au-dessus de matiere pleine (voir
    _is_solid_point : on decale le point testee vers L'INTERIEUR, donc en
    sens INVERSE de cette normale - si elle pointe dans le mauvais sens, le
    decalage se fait vers l'EXTERIEUR et pointContainment ne renverra jamais
    'Inside', meme au beau milieu d'une piece pleine).

    BUG MAJEUR trouve et corrige en direct (explique la quasi-totalite des
    "texte pas dans la matiere" persistants, y compris sur des formes
    complexes) : face.geometry.normal renvoie la normale du plan
    MATHEMATIQUE sous-jacent (Surface.normal), qui NE TIENT PAS COMPTE de
    l'orientation reelle de LA FACE sur le solide (une face peut etre
    "retournee" par rapport a son plan porteur - cas frequent quand deux
    faces paralleles partagent le meme plan, ex. les deux grandes faces
    d'une planche) : verifie en direct sur une face reelle, geometry.normal
    donnait (1,0,0) alors que la vraie normale sortante de cette face
    precise etait (-1,0,0) - EXACTEMENT opposee. Consequence en cascade :
    pour une face touchee, TOUS les points testes (quadrillage ET
    verification reelle) se decalaient vers l'EXTERIEUR de la matiere au
    lieu de l'interieur -> pointContainment repondait TOUJOURS "dehors",
    meme au centre d'une planche bien pleine -> le quadrillage entier
    passait pour "vide" -> aucun candidat ne pouvait jamais obtenir un
    score plein -> repli silencieux sur le simple centre de la boite
    englobante, sans jamais verifier s'il tombe reellement en matiere.
    Sur une piece simple (rectangulaire), ce centre brut tombe souvent EN
    PLEINE matiere par pure coincidence (le bug restait alors invisible) -
    mais sur une forme complexe/courbe, le centre de la boite englobante
    peut tres bien tomber dans un evidement/une encoche -> texte visible-
    ment hors matiere (bug remonte par l'utilisateur, capture d'ecran a
    l'appui).

    Fix : Face.evaluator.getNormalAtPoint(...), qui lui respecte bien
    l'orientation reelle de LA FACE (pas seulement de son plan porteur)."""
    try:
        pof = face.pointOnFace
        ok, n = face.evaluator.getNormalAtPoint(pof)
        if ok:
            return (n.x, n.y, n.z)
    except Exception:
        pass
    try:
        n = face.geometry.normal
        return (n.x, n.y, n.z)
    except Exception:
        return None


def _dominant_edge_angle(face, xf_inv):
    """Angle (radians, repere esquisse natif de xf_inv) du bord de la face
    dont les deux extremites (sommets) sont les plus eloignees l'une de
    l'autre - sert a orienter le texte de la police "trait simple"
    PARALLELEMENT au vrai bord de la piece, plutot que selon les axes
    locaux U/V arbitraires que Fusion choisit pour construire l'esquisse
    d'une face (souvent sans rapport avec l'orientation visuelle de la
    piece sur une face inclinee/en diagonale) - bug remonte : texte visi-
    blement "de travers" par rapport au bord de la piece.

    On utilise la corde (sommet a sommet) plutot que la geometrie exacte
    du bord (qui peut etre un arc, ex. un coin arrondi) : le bord le plus
    long d'une piece est presque toujours un segment droit, donc sa corde
    EST le bord ; les petits arcs de coin, eux, ont une corde bien plus
    courte et ne peuvent pas gagner ce test.

    Retourne un angle ramene dans (-pi/2, pi/2] : un bord n'a pas de sens
    unique (atan2 peut renvoyer indifferemment l'angle du bord ou son
    oppose a 180 degres selon l'ordre start/end des sommets), donc on
    reduit MODULO 180 degres (pas 90 - une reduction modulo 90 melangerait
    a tort les bords a +90 degres, qui sont PERPENDICULAIRES et non
    paralleles : bug constate en direct, texte tourne a 90 degres du bord
    sur certaines faces). 0.0 si aucun bord exploitable n'a ete trouve
    (repli : comportement d'origine, axes natifs de la face)."""
    best_len2 = -1.0
    best_ang = 0.0
    try:
        for edge in face.edges:
            try:
                v1, v2 = edge.startVertex, edge.endVertex
                if v1 is None or v2 is None:
                    continue
                p1 = v1.geometry.copy(); p1.transformBy(xf_inv)
                p2 = v2.geometry.copy(); p2.transformBy(xf_inv)
                dx, dy = p2.x - p1.x, p2.y - p1.y
                len2 = dx * dx + dy * dy
                if len2 > best_len2:
                    best_len2, best_ang = len2, math.atan2(dy, dx)
            except Exception:
                continue
    except Exception:
        return 0.0
    if best_len2 <= 0:
        return 0.0
    ang = best_ang % math.pi
    if ang > math.pi / 2.0:
        ang -= math.pi
    return ang


def _outline_points(face, xf_inv):
    """Points du contour EXTERIEUR de la face (aretes courbes discretisees),
    en repere esquisse 2D de xf_inv. Les seuls sommets ne suffisent pas :
    sur une piece courbe, l'arc entre deux sommets depasse largement la
    boite des sommets (texte repousse contre le bord droit - bug remonte
    sur les pieces M et M-10 du fauteuil)."""
    pts = []
    try:
        loops = [lp for lp in face.loops if lp.isOuter] or list(face.loops)
        for lp in loops:
            for e in lp.edges:
                try:
                    ev = e.evaluator
                    ok, t0, t1 = ev.getParameterExtents()
                    ok2, sp = ev.getStrokes(t0, t1, 0.02)
                    geo = list(sp) if ok2 else []
                except Exception:
                    geo = []
                if not geo:
                    geo = [v.geometry for v in (e.startVertex, e.endVertex) if v is not None]
                for g in geo:
                    p = g.copy(); p.transformBy(xf_inv)
                    pts.append((p.x, p.y))
    except Exception:
        _dbg('outline_points: ' + traceback.format_exc())
    return pts


def _convex_hull(pts):
    pts = sorted(set((round(x, 6), round(y, 6)) for x, y in pts))
    if len(pts) < 3:
        return pts

    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    lower, upper = [], []
    for p in pts:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)
    for p in reversed(pts):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)
    return lower[:-1] + upper[:-1]


def _shape_axis_angle(face, xf_inv):
    """Angle (radians, ramene dans (-pi/2, pi/2]) de l'axe principal de la
    forme : grand cote du plus petit rectangle qui l'englobe. Sur une piece
    rectangulaire c'est son grand bord ; sur une piece courbe (bras,
    accoudoir...) c'est la direction generale de la piece, et non la corde
    du bord le plus long, qui peut etre en biais (bug remonte : gravure de
    travers sur les pieces courbes). Repli : _dominant_edge_angle."""
    hull = _convex_hull(_outline_points(face, xf_inv))
    if len(hull) < 3:
        return _dominant_edge_angle(face, xf_inv)
    # Plus long bord DROIT (vraie ligne, pas une corde d'arc) : c'est
    # l'horizontale naturelle de la piece (bord pose contre la regle, bord
    # d'assemblage) - retenu s'il pese assez dans la forme.
    line_len, line_ang = 0.0, None
    for e in face.edges:
        try:
            ln = adsk.core.Line3D.cast(e.geometry)
            if ln is None:
                continue
            p1 = ln.startPoint.copy(); p1.transformBy(xf_inv)
            p2 = ln.endPoint.copy(); p2.transformBy(xf_inv)
            l_ = math.hypot(p2.x - p1.x, p2.y - p1.y)
            if l_ > line_len:
                line_len, line_ang = l_, math.atan2(p2.y - p1.y, p2.x - p1.x)
        except Exception:
            continue
    best = None
    n = len(hull)
    for i in range(n):
        (x1, y1), (x2, y2) = hull[i], hull[(i + 1) % n]
        a = math.atan2(y2 - y1, x2 - x1)
        c, s_ = math.cos(a), math.sin(a)
        us = [x * c + y * s_ for x, y in hull]
        vs = [-x * s_ + y * c for x, y in hull]
        du, dv = max(us) - min(us), max(vs) - min(vs)
        area = du * dv
        if best is None or area < best[0] - 1e-9:
            best = (area, a if du >= dv else a + math.pi / 2.0, max(du, dv))
    ang = best[1]
    if line_ang is not None and line_len >= 0.3 * best[2]:
        ang = line_ang
    ang = ang % math.pi
    if ang > math.pi / 2.0 + 1e-9:
        ang -= math.pi
    return ang


def _is_solid_point(body, x, y, z, normal, epsilon=0.1):
    """Teste si le point (x, y, z) - pris SUR le plan de la face - se
    trouve au-dessus d'une zone PLEINE du corps (et non d'un creux :
    mortaise, languette voisine, trou, etc. presents sur la meme face).
    On decale legerement le point vers L'INTERIEUR de la matiere (sens
    oppose a la normale sortante de la face) et on verifie via
    BRepBody.pointContainment que ce point decale tombe bien EN PLEINE
    matiere : un creux n'a pas de matiere juste sous la surface a cet
    endroit et renverra 'Outside' (ou 'On'), jamais 'Inside'."""
    if normal is None:
        return True
    nx, ny, nz = normal
    p_in = adsk.core.Point3D.create(x - nx * epsilon, y - ny * epsilon, z - nz * epsilon)
    try:
        c = body.pointContainment(p_in)
    except Exception:
        return True
    return c == adsk.fusion.PointContainment.PointInsidePointContainment


def _rect_is_solid(face, cx, cy, hx, hy, xf_fwd, normal, nx=7, ny=3):
    """Teste si le rectangle (cx, cy, hx, hy) - en repere esquisse - est
    ENTIEREMENT sur de la matiere pleine, en echantillonnant une grille de
    points (nx x ny, bords inclus) plutot que seulement les 4 coins + le
    centre : une entaille de tenon/languette est souvent fine et
    ponctuelle (elle vient du contour EXTERIEUR de la face, pas d'une
    boucle interieure) - un simple test coins+centre peut passer a cote
    d'elle si elle ne tombe pas exactement sur l'un des 5 points, alors
    que le texte, lui, s'etend sur toute la largeur du rectangle (voir
    _is_solid_point)."""
    body = face.body
    xs = [cx - hx + 2 * hx * i / (nx - 1) for i in range(nx)] if nx > 1 else [cx]
    ys = [cy - hy + 2 * hy * j / (ny - 1) for j in range(ny)] if ny > 1 else [cy]
    for x in xs:
        for y in ys:
            p = adsk.core.Point3D.create(x, y, 0.0)
            p.transformBy(xf_fwd)
            if not _is_solid_point(body, p.x, p.y, p.z, normal):
                return False
    return True


def _search_rect_in_zone(face, x_min, x_max, y_min, y_max, hx, hy, xf_fwd, normal):
    """Cherche un placement (cx, cy) pour un rectangle de demi-largeur hx
    et demi-hauteur hy qui retombe ENTIEREMENT sur de la matiere pleine,
    en reduisant progressivement sa taille puis en le deplacant DANS LA
    ZONE [x_min, x_max] x [y_min, y_max] donnee (la face entiere, ou une
    bande de matiere pleine autour d'un evidement - voir
    _find_engrave_box). Le quadrillage des positions candidates est plus
    fin en largeur (nx=9) qu'en hauteur (ny=3) : les entailles de tenon
    sont typiquement reparties le long de la longueur d'une bande, donc
    c'est surtout un decalage horizontal qui permet de les eviter.
    Retourne (cx, cy, hx_final, hy_final, trouve:bool)."""
    cx0 = (x_min + x_max) / 2.0
    cy0 = (y_min + y_max) / 2.0
    nx, ny = 9, 3
    xs = [x_min + (x_max - x_min) * i / (nx - 1) for i in range(nx)] if x_max > x_min else [cx0]
    ys = [y_min + (y_max - y_min) * i / (ny - 1) for i in range(ny)] if y_max > y_min else [cy0]
    candidates = sorted(
        ((cx, cy) for cx in xs for cy in ys),
        key=lambda pt: (pt[0] - cx0) ** 2 + (pt[1] - cy0) ** 2)
    for shrink in (1.0, 0.85, 0.7, 0.55, 0.4, 0.28, 0.18):
        shx, shy = hx * shrink, hy * shrink
        if shx <= 0 or shy <= 0:
            continue
        for cx, cy in candidates:
            if _rect_is_solid(face, cx, cy, shx, shy, xf_fwd, normal):
                return cx, cy, shx, shy, True
    return cx0, cy0, hx, hy, False


def _grid_solid_mask(face, x_min, x_max, y_min, y_max, xf_fwd, normal,
                      target_cells=24, min_cells=4, max_cells=30):
    """Echantillonne un quadrillage de la face (au centre de chaque
    cellule) pour savoir quelles zones sont pleines/vides - approche
    GENERALE qui fonctionne quelle que soit la forme du vide : un
    evidement ferme (boucle interieure), PLUSIEURS evidements separes par
    une zone pleine entre eux, ou une encoche ouverte sur le contour
    exterieur (ex. une piece en U, qui n'a pas de boucle interieure du
    tout) - toutes se traduisent simplement par des cellules 'vides' dans
    le quadrillage, sans avoir a distinguer leur origine topologique.

    La densite est adaptee au plus grand cote de la face pour garder des
    cellules a peu pres carrees (une piece tres allongee aura donc plus de
    cellules sur sa longueur que sur sa largeur, et inversement).

    Retourne (solid, ncols, nrows, cell_w, cell_h) - solid[r][c] est un
    booleen (r=0 correspond a y_min, c=0 a x_min)."""
    w, h = x_max - x_min, y_max - y_min
    long_side = max(w, h) or 1.0
    cell = long_side / float(target_cells)
    ncols = max(min_cells, min(max_cells, round(w / cell))) if w > 0 else 1
    nrows = max(min_cells, min(max_cells, round(h / cell))) if h > 0 else 1
    cell_w, cell_h = w / ncols, h / nrows
    body = face.body
    solid = []
    for r in range(nrows):
        cy = y_min + (r + 0.5) * cell_h
        row = []
        for c in range(ncols):
            cx = x_min + (c + 0.5) * cell_w
            p = adsk.core.Point3D.create(cx, cy, 0.0)
            p.transformBy(xf_fwd)
            row.append(_is_solid_point(body, p.x, p.y, p.z, normal))
        solid.append(row)
    return solid, ncols, nrows, cell_w, cell_h


def _void_distance_grid(solid, ncols, nrows):
    """Distance (en NOMBRE DE CELLULES, 8-connexe) de chaque cellule PLEINE
    a la cellule VIDE (creux interne : mortaise, trou...) OU au BORD de la
    grille (donc au bord exterieur de la piece) la plus proche -
    transformee de distance classique, calculee par BFS multi-sources en
    O(ncols*nrows), aucun appel Fusion supplementaire (pur calcul sur le
    quadrillage deja echantillonne par _grid_solid_mask).

    Sert a mesurer, pour un emplacement de texte candidat, la marge de
    securite dont il dispose au-dela du strict minimum necessaire pour
    tenir en matiere pleine - sans ca, la recherche de placement pouvait
    choisir un emplacement colle contre un evidement interne (ex. un trou
    d'assemblage) alors qu'un emplacement tout aussi plein, mais bien plus
    degage, existait plus loin sur la meme face (bug remonte par
    l'utilisateur, capture d'ecran a l'appui).

    Retourne dist[r][c] (int, 0 pour une cellule vide)."""
    from collections import deque
    INF = float("inf")
    dist = [[INF] * ncols for _ in range(nrows)]
    dq = deque()
    for r in range(nrows):
        for c in range(ncols):
            if not solid[r][c]:
                dist[r][c] = 0
                dq.append((r, c))
    # Les cellules en bordure de quadrillage sont traitees comme adjacentes
    # au "vide" exterieur (hors face) - la marge calculee penalise donc
    # aussi bien la proximite d'un evidement INTERNE que celle du bord
    # EXTERIEUR de la piece.
    for r in range(nrows):
        for c in (0, ncols - 1):
            if dist[r][c] > 1:
                dist[r][c] = 1
                dq.append((r, c))
    for c in range(ncols):
        for r in (0, nrows - 1):
            if dist[r][c] > 1:
                dist[r][c] = 1
                dq.append((r, c))
    while dq:
        r, c = dq.popleft()
        d = dist[r][c]
        for dr in (-1, 0, 1):
            for dc in (-1, 0, 1):
                if dr == 0 and dc == 0:
                    continue
                rr, cc = r + dr, c + dc
                if 0 <= rr < nrows and 0 <= cc < ncols and dist[rr][cc] > d + 1:
                    dist[rr][cc] = d + 1
                    dq.append((rr, cc))
    return dist


def _max_rect_in_grid(solid, ncols, nrows):
    """Plus grand rectangle ENTIEREMENT plein dans la grille booleenne
    solid[r][c] - methode classique de l'histogramme (comme pour 'largest
    rectangle in a binary matrix'), en O(ncols*nrows), aucun appel a
    l'API Fusion ici (pur calcul sur le quadrillage deja echantillonne).
    Retourne (c0, r0, c1, r1) - colonnes/lignes INCLUSES du rectangle - ou
    None si aucune cellule n'est pleine."""
    heights = [0] * ncols
    best = None  # (aire, c0, r0, c1, r1)
    for r in range(nrows):
        for c in range(ncols):
            heights[c] = heights[c] + 1 if solid[r][c] else 0
        stack = []  # (colonne_depart, hauteur)
        for c in range(ncols + 1):
            hgt = heights[c] if c < ncols else 0
            start = c
            while stack and stack[-1][1] >= hgt:
                s, sh = stack.pop()
                if sh > 0:
                    area = sh * (c - s)
                    if best is None or area > best[0]:
                        best = (area, s, r - sh + 1, c - 1, r)
                start = s
            stack.append((start, hgt))
    return best[1:] if best else None


def _find_engrave_box(face, x_min, x_max, y_min, y_max, w, h, m, xf_fwd, normal):
    """Determine le rectangle final (cx, cy, hx, hy, angle) ou placer le
    texte, en evitant tout creux present sur la face - quelle que soit sa
    forme (evidement ferme, plusieurs evidements separes par une zone
    pleine, ou encoche ouverte type piece en U) :
    1) essaie d'abord la face ENTIERE (cas normal, rapide - la grande
       majorite des faces sans creux) ;
    2) sinon, quadrille la face et calcule le plus grand rectangle
       entierement plein (voir _grid_solid_mask / _max_rect_in_grid) - ne
       se limite pas a une bande pres d'un bord : trouve la VRAIE plus
       grande zone disponible, meme si elle est au centre entre deux
       evidements ;
    3) affine ce rectangle (retrecissement/decalage fin, voir
       _search_rect_in_zone) pour rattraper d'eventuels details plus
       petits qu'une cellule du quadrillage (ex. une entaille de tenon) ;
    4) si rien de tout cela ne fonctionne, retombe sur le centre brut de
       la face (dernier recours, comportement d'origine)."""
    def half_extents(hw, hh):
        if hw >= hh:
            return hw * (1 - m), hh * (1 - m), 0.0
        return hh * (1 - m), hw * (1 - m), math.pi / 2.0

    cx0, cy0 = (x_min + x_max) / 2.0, (y_min + y_max) / 2.0
    hx0, hy0, ang0 = half_extents(w / 2.0, h / 2.0)

    # 1) Face entiere.
    if _rect_is_solid(face, cx0, cy0, hx0, hy0, xf_fwd, normal):
        return cx0, cy0, hx0, hy0, ang0

    # 2) Plus grand rectangle plein dans un quadrillage de la face.
    solid, ncols, nrows, cell_w, cell_h = _grid_solid_mask(
        face, x_min, x_max, y_min, y_max, xf_fwd, normal)
    rect = _max_rect_in_grid(solid, ncols, nrows)
    if rect:
        c0, r0, c1, r1 = rect
        zx_min, zx_max = x_min + c0 * cell_w, x_min + (c1 + 1) * cell_w
        zy_min, zy_max = y_min + r0 * cell_h, y_min + (r1 + 1) * cell_h
        zw, zh = zx_max - zx_min, zy_max - zy_min
        if zw > 0 and zh > 0:
            hx, hy, ang = half_extents(zw / 2.0, zh / 2.0)
            # 3) Affinage fin dans la zone trouvee (rattrape les details
            # plus petits qu'une cellule, ex. une entaille de tenon).
            cx, cy, fhx, fhy, found = _search_rect_in_zone(
                face, zx_min, zx_max, zy_min, zy_max, hx, hy, xf_fwd, normal)
            if found:
                return cx, cy, fhx, fhy, ang

    # 4) Repli : centre brut, comportement d'origine.
    _dbg('Gravure: zone pleine introuvable - placement par defaut (centre de la face)')
    return cx0, cy0, hx0, hy0, ang0


def _find_line_text_position(face, x_min, x_max, y_min, y_max, half_w, half_h, m, xf_fwd, normal):
    """Equivalent de _find_engrave_box, mais pour la police vectorielle
    interne (_draw_line_text, voir LINE_FONT_NAME) : contrairement au texte
    Fusion classique (setAsMultiLine), qui n'a pas de taille fixe et se
    redimensionne/pivote pour remplir n'importe quelle boite qu'on lui
    donne, notre police interne a une taille FIXE, deja calculee a partir
    de la hauteur demandee (text_h_cm) - elle n'est JAMAIS redimensionnee
    ici : "si je dis 20, c'est 20". Cette fonction ne cherche donc qu'un
    EMPLACEMENT (cx, cy), en s'adaptant a la forme reelle du corps pour
    eviter les creux (mortaises, languettes, trous...).

    m (marge) ne retrecit plus le texte : il ajoute juste une petite zone
    de securite tout autour de lui pendant la recherche d'emplacement, pour
    eviter de le coller pile au bord d'un creux.

    RECHERCHE UNIFIEE (voir aussi gravure_debug.log qui a servi a diagnostiquer
    le probleme) : une version precedente procedait en 3 etapes distinctes
    (1: test du seul centre brut de la face : 2: plus grand rectangle plein
    d'un quadrillage grossier + une recherche locale a 27 positions
    candidates confinee a ce rectangle ; 3: en dernier recours, un balayage
    exhaustif de tout le quadrillage). Le journal de debogage reel a montre
    que les etapes 1 et 2 ratent regulierement des emplacements ENTIEREMENT
    PLEINS que l'etape 3 (le vrai balayage exhaustif) retrouvait ensuite -
    preuve qu'elles etaient trop fragiles (un seul point pour le centre ;
    une zone de depart, celle du "plus grand rectangle", qui peut elle-meme
    etre mal placee/trop petite a cause du quadrillage grossier). Et meme
    quand l'etape 3 finissait par trouver une position 100% pleine, elle
    gardait la PREMIERE trouvee en parcourant la grille (du bas vers le
    haut, de gauche a droite) plutot que la plus centree - d'ou des textes
    colles dans un coin/bord alors qu'il y avait largement la place de les
    centrer (bug remonte par l'utilisateur, capture d'ecran a l'appui).

    Cette version fait donc une seule recherche, exhaustive sur tout le
    quadrillage (plus fin qu'avant, pour une meilleure detection), qui
    classe les candidats par meilleur recouvrement puis, a recouvrement
    egal, par marge par rapport au creux/bord le plus proche puis par
    proximite au centre de la face - mais NE FAIT PLUS CONFIANCE au
    quadrillage seul pour valider le candidat final : celui-ci n'echantillonne
    qu'un point par cellule (son centre), donc une entaille plus etroite
    qu'une cellule peut passer inapercue si elle tombe entre deux centres
    (bug remonte, photo a l'appui : texte grave en plein milieu d'une
    entaille que le quadrillage disait pleine). Les meilleurs candidats du
    classement sont donc reverifies en conditions reelles (vrais appels
    pointContainment, echantillonnage dense - voir _rect_is_solid) avant
    d'etre acceptes ; en cas d'echec on passe au suivant. Cout
    supplementaire limite a une poignee de candidats, jamais a toute la
    grille - la qualite du placement reste neanmoins la priorite explicite
    sur la vitesse.

    Retourne (cx, cy, fits) - fits=False si aucun emplacement entierement
    plein n'a ete trouve a cette taille (le texte est alors place a
    l'endroit qui recouvre le plus de matiere, TOUJOURS a la taille
    demandee - jamais retreci)."""
    pad_x, pad_y = half_w * m, half_h * m
    test_hx, test_hy = half_w + pad_x, half_h + pad_y
    cx0, cy0 = (x_min + x_max) / 2.0, (y_min + y_max) / 2.0

    # Quadrillage plus fin que celui utilise pour la police Fusion classique
    # (target_cells/max_cells augmentes) : c'est desormais la SEULE source
    # de verite pour le placement, une meilleure resolution ameliore donc
    # directement la qualite de la detection des zones pleines.
    solid, ncols, nrows, cell_w, cell_h = _grid_solid_mask(
        face, x_min, x_max, y_min, y_max, xf_fwd, normal,
        target_cells=40, min_cells=6, max_cells=60)
    # Marge (en cellules) de chaque cellule pleine par rapport au creux ou
    # bord le plus proche - voir _void_distance_grid : sert a preferer un
    # emplacement DEGAGE (loin d'un trou d'assemblage/evidement voisin) a
    # un emplacement juste-assez-plein colle contre ce meme creux (bug
    # remonte par l'utilisateur : texte au bord d'une piece alors qu'il y
    # avait la place de le mettre plus loin d'un assemblage interne).
    void_dist = _void_distance_grid(solid, ncols, nrows)

    # Somme prefixee 2D (integral image) du quadrillage plein/vide : permet
    # de calculer en O(1) le recouvrement de n'importe quelle fenetre
    # candidate, au lieu de re-parcourir tout son contenu a chaque fois
    # (O(taille de la fenetre)) - c'etait la partie qui dominait le temps
    # de CALCUL PUR PYTHON (pas d'appel Fusion) de la recherche de
    # placement sur une face large/complexe, ou le nombre de positions
    # candidates x la taille de la fenetre testee peut vite depasser le
    # million d'iterations. Resultat mathematiquement identique (verifie
    # par comparaison exhaustive avec l'ancienne methode sur des grilles
    # aleatoires) - seule la vitesse change.
    psum = [[0] * (ncols + 1) for _ in range(nrows + 1)]
    for r in range(nrows):
        row_sum = 0
        prow, nrow, srow = psum[r], psum[r + 1], solid[r]
        for c in range(ncols):
            row_sum += 1 if srow[c] else 0
            nrow[c + 1] = prow[c + 1] + row_sum

    def _window_solid_count(r0, r1, c0, c1):
        rr0, rr1 = max(0, r0), min(nrows - 1, r1)
        cc0, cc1 = max(0, c0), min(ncols - 1, c1)
        if rr0 > rr1 or cc0 > cc1:
            return 0
        return (psum[rr1 + 1][cc1 + 1] - psum[rr0][cc1 + 1]
                - psum[rr1 + 1][cc0] + psum[rr0][cc0])

    half_cols = max(1, int(round(test_hx / cell_w))) if cell_w > 0 else 0
    half_rows = max(1, int(round(test_hy / cell_h))) if cell_h > 0 else 0
    half_span = max(half_cols, half_rows)

    # IMPORTANT : un centre candidat n'est retenu que si le texte, a sa
    # taille reelle (test_hx/test_hy), reste ENTIEREMENT dans la boite
    # englobante de la face (voir bug remonte precedemment : texte
    # partiellement hors de la piece). Sans ce filtre, un centre pres d'un
    # bord pouvait "gagner" au score de recouvrement local tout en faisant
    # deborder le texte hors du corps.
    candidates = []
    for r in range(nrows):
        cy = y_min + (r + 0.5) * cell_h
        if cy - test_hy < y_min or cy + test_hy > y_max:
            continue
        r0c, r1c = r - half_rows, r + half_rows
        for c in range(ncols):
            cx = x_min + (c + 0.5) * cell_w
            if cx - test_hx < x_min or cx + test_hx > x_max:
                continue
            c0c, c1c = c - half_cols, c + half_cols
            total = (r1c - r0c + 1) * (c1c - c0c + 1)
            solid_n = _window_solid_count(r0c, r1c, c0c, c1c)
            score = solid_n / total if total else 0.0
            # Marge restante APRES avoir couvert l'emprise du texte lui-
            # meme (distance au creux/bord le plus proche, moins la
            # demi-emprise en cellules du texte) - plus c'est grand, plus
            # l'emplacement est degage.
            clear = void_dist[r][c] - half_span
            d2 = (cx - cx0) ** 2 + (cy - cy0) ** 2
            candidates.append((score, clear, d2, cx, cy))

    if not candidates:
        # Meme le centre brut de la face ferait deborder le texte (texte
        # plus grand que la face elle-meme) : dernier recours absolu.
        _dbg('Gravure: police "trait simple" - texte trop grand pour tenir '
             'entierement dans la face (aucune position sans depassement) - '
             'place au centre brut de la face')
        return cx0, cy0, False

    # Priorite au meilleur recouvrement ; a recouvrement quasi egal
    # (tolerance 0.1% pour absorber le bruit d'arrondi du quadrillage), a
    # l'emplacement le plus DEGAGE (le plus loin d'un creux/bord) ; a marge
    # quasi egale enfin, au plus proche du centre de la face.
    candidates.sort(key=lambda t: (-round(t[0], 3), -round(t[1], 6), t[2]))

    # VERIFICATION REELLE des meilleurs candidats (voir bug remonte, photo
    # a l'appui : un texte s'est retrouve EN PLEIN MILIEU D'UNE ENTAILLE
    # alors que le quadrillage la disait "pleine" a cet endroit) : le
    # quadrillage n'echantillonne qu'UN point par cellule (son centre) - une
    # entaille plus etroite que la cellule peut donc passer totalement
    # inapercue si elle tombe entre deux centres de cellules, sans qu'aucune
    # d'elles ne la detecte. La priorite explicite de l'utilisateur etant la
    # QUALITE avant la vitesse, on ne fait plus confiance au quadrillage
    # seul pour le candidat final : on reverifie en conditions reelles
    # (vrais appels pointContainment, echantillonnage dense) les meilleurs
    # candidats du classement, et on ne retient le premier que s'il resiste
    # reellement a cette verification - sinon on passe au suivant. Le cout
    # supplementaire ne porte que sur une poignee de candidats (pas toute la
    # grille), donc reste largement raisonnable.
    #
    # IMPORTANT : on ne s'arrete PLUS des qu'un candidat a un score<1.0 (bug
    # constate en direct sur deux pieces quasiment identiques - meme forme,
    # meme aire - mais orientees en miroir l'une de l'autre : theta=+31.15
    # d'un cote, -31.15 de l'autre. Le decoupage en fenetre (half_cols /
    # half_rows, arrondis au nombre de cellules le plus proche) est une
    # APPROXIMATION de l'emprise reelle du texte : selon l'angle de rotation
    # (donc selon l'alignement du quadrillage avec le vrai contour), cet
    # arrondi peut faire deborder la fenetre testee d'une cellule sur un
    # bord proche d'une entaille et compter a tort ce candidat comme "pas
    # tout a fait plein" (score legerement <1.0), alors qu'en realite
    # (verification dense) l'emplacement est parfaitement degage. Comme
    # cette approximation depend de l'orientation, deux pieces en miroir
    # peuvent en etre affectees differemment - d'ou le bug observe. Le
    # quadrillage ne sert donc plus qu'a CLASSER les candidats (meilleur
    # recouvrement d'abord) ; c'est la verification reelle (pointContainment
    # dense) qui decide seule si un candidat est accepte, sur les K
    # meilleurs du classement quel que soit leur score.
    K = 40
    for score, clear, d2, cx, cy in candidates[:K]:
        if _rect_is_solid(face, cx, cy, test_hx, test_hy, xf_fwd, normal, nx=15, ny=7):
            return cx, cy, True

    # Aucun candidat verifie reellement plein (soit le quadrillage n'en
    # promettait deja aucun, soit ceux qu'il promettait n'ont pas resiste a
    # la verification fine) : on retombe sur le meilleur du classement,
    # avec l'avertissement habituel (texte place au mieux, a verifier
    # visuellement).
    best_score, best_clear, best_d2, best_cx, best_cy = candidates[0]
    _dbg('Gravure: police "trait simple" - zone entierement pleine '
         'introuvable (ou non confirmee par verification reelle) pour la '
         'taille demandee, placement au meilleur recouvrement, le plus '
         f'proche possible du centre de la face (score={best_score:.2f})')
    return best_cx, best_cy, False


def _noter_texte(sketch, wb, cx, cy, half_w, half_h):
    """Note dans l'esquisse (attribut CNCToolkit/gravures) le centre, le rayon
    et la normale sortante de la face de chaque texte : Calpinage CNC s'en
    sert pour ne pas donner l'etiquette d'une piece a la piece posee juste
    dessus (faces collees l'une contre l'autre)."""
    try:
        ox, oy, oz, ux, uy, uz, vx, vy, vz = wb
        n = (uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx)
        l = math.sqrt(n[0] ** 2 + n[1] ** 2 + n[2] ** 2) or 1.0
        n = [round(c / l, 6) for c in n]
        p = [round(ox + cx * ux + cy * vx, 5), round(oy + cx * uy + cy * vy, 5), round(oz + cx * uz + cy * vz, 5)]
        r = round(math.sqrt(half_w ** 2 + half_h ** 2) * 1.15 + 0.2, 4)
        at = sketch.attributes.itemByName('CNCToolkit', 'gravures')
        lst = json.loads(at.value) if at is not None else []
        lst.append({'p': p, 'r': r, 'n': n})
        sketch.attributes.add('CNCToolkit', 'gravures', json.dumps(lst))
    except Exception:
        _dbg('noter_texte: ' + traceback.format_exc())


def _reperes_faces(faces):
    """Acceleration "trait simple" (2026-11-12) : le repere de l'esquisse
    temporaire de chaque face (seul usage de cette esquisse quand le texte
    va dans l'esquisse partagee) est lu pour TOUTES les faces d'abord, puis
    toutes ces esquisses sont supprimees EN UNE FOIS (groupe de chronologie
    supprime avec son contenu). Mesure : la suppression une par une coutait
    plus que la creation ; groupee elle devient negligeable. Le repere est
    exactement celui de Fusion (pas de recalcul maison : la regle de Fusion
    pour l'axe X d'une esquisse sur face n'est pas reproductible), donc le
    placement et l'orientation du texte sont identiques a avant. Une face
    native partagee par plusieurs occurrences n'est traitee qu'une fois.
    Retourne une liste alignee sur faces (Matrix3D ou None).
    Pas de cle entityToken : creer/supprimer des esquisses modifie la
    chronologie et les jetons des faces peuvent changer entre-temps (bug du
    2026-11-12 : reperes melanges, textes en miroir / sur le mauvais corps)."""
    res = [None] * len(faces)
    natives = []      # (face native, Matrix3D) deja traitees
    sks = []
    design = adsk.fusion.Design.cast(_app.activeProduct)
    tl = None
    i0 = None
    try:
        tl = design.timeline
        i0 = tl.markerPosition
    except Exception:
        tl = None
    for i, f in enumerate(faces):
        try:
            nf = _resolve_face(f)
            deja = None
            for (g, m) in natives:
                try:
                    if g == nf:
                        deja = m
                        break
                except Exception:
                    pass
            if deja is not None:
                res[i] = deja
                continue
            sk = nf.body.parentComponent.sketches.addWithoutEdges(nf)
            m = sk.transform.copy()
            res[i] = m
            natives.append((nf, m))
            sks.append(sk)
        except Exception:
            _dbg('reperes_faces: ' + traceback.format_exc())
    groupe_ok = False
    if tl is not None and len(sks) >= 2:
        try:
            if tl.markerPosition - i0 == len(sks):
                g = tl.timelineGroups.add(i0, tl.markerPosition - 1)
                g.deleteMe(True)
                groupe_ok = all(not sk.isValid for sk in sks)
        except Exception:
            _dbg('reperes_faces groupe: ' + traceback.format_exc())
    if not groupe_ok:
        for sk in sks:
            try:
                if sk.isValid:
                    sk.deleteMe()
            except Exception:
                pass
    return res


def _engrave(face, text, font_name, text_h_cm, depth_cm, style, margin_pct, do_extrude,
             shared_sketch=None, xf_pre=None):
    """shared_sketch (optionnel, seulement pour LINE_FONT_NAME) : esquisse
    UNIQUE deja creee dans le composant RACINE par l'appelant (voir
    MyCommandExecuteHandler.notify) pour regrouper toutes les gravures
    "trait simple" d'une meme execution, quel que soit le corps/composant
    d'origine de chaque face. Quand fourni, l'esquisse temporaire creee ici
    (sur la face, pour ses reperes/sa recherche de placement) est ensuite
    supprimee ; le texte est dessine dans shared_sketch, en repere MONDE
    REEL (voir _draw_line_text/world_basis).

    Le repere monde est obtenu via face.assemblyContext.transform2 (le
    transform de L'OCCURRENCE reellement selectionnee, capture ICI avant
    tout appel a _resolve_face) applique au repere NATIF (xf_fwd) - PAS via
    SketchPoint.worldGeometry sur une esquisse batie sur la face NATIVE
    (tente initialement, mais confirme faux en direct : une esquisse creee
    via comp.sketches sur le composant natif n'a aucun contexte
    d'occurrence, donc worldGeometry y ignore silencieusement quelle
    instance/occurrence a ete reellement selectionnee - le texte finissait
    place n'importe ou, meme piege que le bug monde/natif deja rencontre
    dans TenonCNC). Verifie en direct sur une occurrence imbriquee a 3
    niveaux avec un vrai decalage : position reproduite exactement.

    Quand None (police Fusion classique, ou appel direct sans esquisse
    partagee) : comportement d'origine, inchange."""
    occ_transform = None
    if shared_sketch is not None:
        try:
            ctx = face.assemblyContext
            if ctx is not None:
                occ_transform = ctx.transform2
        except Exception:
            occ_transform = None
    face = _resolve_face(face)
    comp = face.body.parentComponent
    if xf_pre is not None and shared_sketch is not None and font_name == LINE_FONT_NAME:
        # repere deja lu par _reperes_faces : aucune esquisse temporaire ici
        sketch = None
        xf_fwd = xf_pre.copy()
    else:
        sketch = comp.sketches.addWithoutEdges(face)
        xf_fwd = sketch.transform.copy()      # repere esquisse -> modele
    xf_inv = xf_fwd.copy(); xf_inv.invert()   # repere modele -> esquisse
    m = margin_pct
    # Recherche d'une zone PLEINE pour le placement du texte, afin d'eviter
    # un creux (mortaise/languette voisine, trou, grand evidement central,
    # etc.) present sur la meme face - plutot que de toujours graver au
    # centre brut de la boite englobante de la face (qui, pour un corps en
    # forme de cadre/rectangle evide, tombe en plein dans le vide).
    normal = _face_normal(face)

    if font_name != LINE_FONT_NAME:
        # Boite englobante en repere NATIF - utilisee uniquement par le
        # chemin police Fusion classique (_find_engrave_box) juste en
        # dessous. La police "trait simple", elle, calcule sa PROPRE boite
        # englobante dans un repere different (tourne pour s'aligner sur le
        # bord de la piece - voir plus bas, pts_line) : pas la peine de
        # reparcourir les sommets de la face une seconde fois pour rien a
        # chaque gravure (petit gain de temps, mais systematique).
        pts = []
        for edge in face.edges:
            for vtx in (edge.startVertex, edge.endVertex):
                if vtx is not None:
                    p = vtx.geometry.copy(); p.transformBy(xf_inv); pts.append((p.x, p.y))
        if not pts:
            sketch.deleteMe(); return
        xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
        x_min, x_max = min(xs), max(xs); y_min, y_max = min(ys), max(ys)
        w = x_max - x_min; h = y_max - y_min

    if font_name == LINE_FONT_NAME:
        # Police vectorielle interne (voir _draw_line_text) : la hauteur
        # demandee (text_h_cm) est TOUJOURS respectee a la lettre - le texte
        # n'est JAMAIS redimensionne ("si je dis 20, c'est 20"). Seul le
        # PLACEMENT est recherche, adapte a la forme reelle du corps - voir
        # _find_line_text_position (pas _find_engrave_box, qui redimensionne
        # et peut pivoter, ce qui convient au texte Fusion classique mais
        # pas a une police a taille fixe).
        text_clean = _strip_accents(text)
        scale = text_h_cm / 21.0
        total_w_units = sum(_LINE_FONT.get(ch, _LINE_FONT[" "])[0] for ch in text_clean)
        half_w = (total_w_units * scale) / 2.0
        half_h = (21.0 * scale) / 2.0

        # Oriente la recherche (et donc le texte) sur le bord REEL le plus
        # long de la piece plutot que sur les axes U/V natifs, arbitraires,
        # de l'esquisse de la face (voir _dominant_edge_angle) - sinon, sur
        # une face inclinee/en diagonale, le texte est dessine bien droit
        # dans le repere de l'esquisse mais visiblement "de travers" par
        # rapport a la piece elle-meme (bug remonte, capture d'ecran a
        # l'appui). On construit un repere "xf_fwd_line" = xf_fwd tourne
        # (rotation PURE, autour de son propre axe Z local) de cet angle :
        # toute la recherche de placement tourne alors avec la piece, sans
        # toucher au reste de _find_line_text_position/_grid_solid_mask.
        theta = _shape_axis_angle(face, xf_inv)
        rot_mat = adsk.core.Matrix3D.create()
        rot_mat.setToRotation(theta, adsk.core.Vector3D.create(0, 0, 1),
                               adsk.core.Point3D.create(0, 0, 0))
        # IMPORTANT : Matrix3D.transformBy(M) applique D'ABORD la matrice
        # sur laquelle on l'appelle, PUIS M (verifie en direct : A.copy();
        # A.transformBy(B) donne le meme resultat que "appliquer A a un
        # point, puis appliquer B au resultat" - pas l'inverse). On veut
        # ici : tourner le point dans le repere LOCAL (rot_mat), PUIS le
        # convertir en monde (xf_fwd) - donc rot_mat.transformBy(xf_fwd),
        # et surtout pas xf_fwd.transformBy(rot_mat) (teste, donnait une
        # rotation fausse - le point se retrouvait tourne APRES la
        # conversion en monde, autour de l'axe Z MONDE et non de la
        # normale locale de la face).
        xf_fwd_line = rot_mat.copy(); xf_fwd_line.transformBy(xf_fwd)
        xf_inv_line = xf_fwd_line.copy(); xf_inv_line.invert()
        # Boite de la vraie forme (arcs compris), pas seulement des sommets.
        pts_line = _outline_points(face, xf_inv_line)
        if not pts_line:
            if sketch is not None:
                sketch.deleteMe()
            return
        xs_l = [p[0] for p in pts_line]; ys_l = [p[1] for p in pts_line]
        x_min_l, x_max_l = min(xs_l), max(xs_l)
        y_min_l, y_max_l = min(ys_l), max(ys_l)

        cx, cy, fits = _find_line_text_position(
            face, x_min_l, x_max_l, y_min_l, y_max_l, half_w, half_h, m,
            xf_fwd_line, normal)
        if shared_sketch is not None:
            # Reconstruit le repere MONDE REEL de la face (origine + axes
            # X/Y locaux, DEJA tournes de theta - voir plus haut) en
            # appliquant occ_transform (capture plus haut, AVANT
            # _resolve_face - voir docstring) aux memes 3 points de
            # reference (0,0,0)/(1,0,0)/(0,1,0) transformes par xf_fwd_line.
            # L'esquisse partagee, elle, est creee sur le plan XY du
            # composant RACINE, dont le repere natif est deja identique au
            # monde (verifie en direct) - les coordonnees monde peuvent
            # donc y etre utilisees telles quelles, sans transform
            # supplementaire de ce cote.
            p0 = adsk.core.Point3D.create(0.0, 0.0, 0.0); p0.transformBy(xf_fwd_line)
            px_ = adsk.core.Point3D.create(1.0, 0.0, 0.0); px_.transformBy(xf_fwd_line)
            py_ = adsk.core.Point3D.create(0.0, 1.0, 0.0); py_.transformBy(xf_fwd_line)
            if occ_transform is not None:
                p0.transformBy(occ_transform)
                px_.transformBy(occ_transform)
                py_.transformBy(occ_transform)
            world_basis = (p0.x, p0.y, p0.z,
                           px_.x - p0.x, px_.y - p0.y, px_.z - p0.z,
                           py_.x - p0.x, py_.y - p0.y, py_.z - p0.z)
            # Esquisse temporaire (creee au debut de _engrave) seulement
            # pour ses reperes/sa recherche de placement - le texte va dans
            # shared_sketch, pas dedans - donc on la supprime plutot que de
            # la laisser trainer (c'est exactement le but : une seule
            # esquisse pour toutes les gravures "trait simple" d'une meme
            # execution, au lieu d'une par face/corps).
            try:
                _draw_line_text(shared_sketch, text, cx, cy, scale, 0.0, world_basis)
                _noter_texte(shared_sketch, world_basis, cx, cy, half_w, half_h)
            finally:
                try:
                    if sketch is not None:
                        sketch.deleteMe()
                except Exception:
                    pass
        else:
            # sketch (temporaire, sur la face) utilise encore son propre
            # repere NON tourne (xf_fwd) - on reconvertit donc le point
            # (cx, cy), calcule dans le repere tourne xf_fwd_line, vers ce
            # repere natif (monde -> natif via xf_inv), et on fait pivoter
            # le texte lui-meme de theta via le parametre angle de
            # _draw_line_text (elle sait deja le faire, voir plus haut).
            p_c = adsk.core.Point3D.create(cx, cy, 0.0)
            p_c.transformBy(xf_fwd_line)
            p_c.transformBy(xf_inv)
            _draw_line_text(sketch, text, p_c.x, p_c.y, scale, theta)
        warning = None
        if not fits:
            warning = (f'"{text}" a {text_h_cm} cm : aucun emplacement '
                       'entierement plein trouve sur cette face - texte '
                       'place au mieux, a verifier visuellement (il peut '
                       'chevaucher un creux).')
        if do_extrude:
            _dbg('Gravure: police "trait simple" choisie - extrusion ignoree '
                 '(traits ouverts, pas de contour ferme a extruder)')
        return warning

    cx, cy, hx, hy, angle = _find_engrave_box(
        face, x_min, x_max, y_min, y_max, w, h, m, xf_fwd, normal)
    c1 = adsk.core.Point3D.create(cx - hx, cy - hy, 0.0)
    c2 = adsk.core.Point3D.create(cx + hx, cy + hy, 0.0)
    ti = sketch.sketchTexts.createInput(text, text_h_cm, c1)
    ti.fontName = font_name; ti.textStyle = style
    ti.isHorizontalFlip = False; ti.isVerticalFlip = False
    ti.angle = angle
    ti.setAsMultiLine(c1, c2, H_CENTER, V_MIDDLE, 0.0)
    txt = sketch.sketchTexts.add(ti)
    if not do_extrude:
        return
    extruded = False
    for direction in (True, False):
        try:
            profs = adsk.core.ObjectCollection.create()
            profs.add(txt)
            ei = comp.features.extrudeFeatures.createInput(
                profs, adsk.fusion.FeatureOperations.CutFeatureOperation)
            ei.setDistanceExtent(direction, adsk.core.ValueInput.createByReal(depth_cm))
            # Sans ca, une coupe en Cut affecte par defaut TOUS les corps
            # que le volume d'extrusion traverse - donc aussi un corps
            # voisin/au-dessus de la face gravee, meme si ce n'est pas
            # voulu. On restreint explicitement la coupe au seul corps
            # porteur de la face selectionnee.
            try:
                ei.participantBodies = [face.body]
            except Exception:
                pass
            comp.features.extrudeFeatures.add(ei)
            extruded = True; break
        except Exception:
            pass
    if not extruded:
        sketch.deleteMe()
        raise RuntimeError("Impossible d'extruder sur " + comp.name)


def run(context):
    global _app, _ui
    _app = adsk.core.Application.get(); _ui = _app.userInterface
    try:
        # Nettoyage d'une eventuelle ancienne commande "Gravure Composants"
        # (avant renommage), pour ne pas laisser un bouton fantome.
        for old_id in ("GravureComposantsCmd", CMD_ID):
            panel = _ui.allToolbarPanels.itemById(PANEL_ID)
            if panel:
                ctrl = panel.controls.itemById(old_id)
                if ctrl: ctrl.deleteMe()
            cd_old = _ui.commandDefinitions.itemById(old_id)
            if cd_old: cd_old.deleteMe()

        cd = _ui.commandDefinitions.addButtonDefinition(CMD_ID, CMD_NAME, CMD_DESC)
        h = MyCommandCreatedHandler(); cd.commandCreated.add(h); _handlers.append(h)
        # Bouton de ruban RETIRE (PANEL_ID) : devenu inutile depuis la
        # creation de CNC Toolkit, qui retrouve et execute cette
        # CommandDefinition directement depuis sa palette.
    except Exception:
        _ui.messageBox(traceback.format_exc())


def stop(context):
    global _handlers
    try:
        _gv_effacer()
        _prop_effacer()
    except Exception:
        pass
    _unhide_remembered()
    try:
        panel = _ui.allToolbarPanels.itemById(PANEL_ID)
        if panel:
            ctrl = panel.controls.itemById(CMD_ID)
            if ctrl: ctrl.deleteMe()
        cd = _ui.commandDefinitions.itemById(CMD_ID)
        if cd: cd.deleteMe()
        _handlers.clear()
    except Exception:
        _ui.messageBox(traceback.format_exc())
