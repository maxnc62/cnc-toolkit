import adsk.core
import adsk.fusion
import traceback
import os
import sys
import json

# Barre de chargement commune du Toolkit (ToolkitCNC/cnc_progress.py)
_TK_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _TK_DIR not in sys.path:
    sys.path.append(_TK_DIR)
import cnc_progress

# ---------------------------------------------------------------------------
# Purger CNC (demande de l'utilisateur, 2026-10-07) : supprime tout ce que CNC
# Toolkit a cree sur les corps / composants selectionnes, ET les coupes que
# ces corps ont faites dans les autres corps (entaille, mortaise, tenon qui y
# rentre, jeu, dogbones), sans toucher aux coupes des autres corps entre eux.
#
# PRINCIPE
#   - Fonctions CNC = fonctions de l'historique dans un groupe CNC (Tenon CNC,
#     Entaille CNC, Mortaise CNC, Marge CNC, Modif Marge, Mise a jour CNC,
#     Gravure CNC), ou portant des attributs / un nom CNC. Les jonctions ne
#     sont jamais touchees.
#   - Une fonction est liee a la selection si elle modifie un corps
#     selectionne, si un corps selectionne en est l'outil garde, ou si une de
#     ses faces est posee sur un corps selectionne (point interieur de la face
#     a moins de _TOUCH_CM pres : couvre le jeu) : c'est le cas des coupes
#     qu'il a faites dans ses voisins. Les esquisses partent avec leur
#     extrusion.
#   - Jeu (Decaler les faces) : une meme fonction couvre souvent tout un lot ;
#     on lui retire seulement les faces liees a la selection (la fonction
#     n'est supprimee que si toutes ses faces le sont).
#   - Dogbones : retires de la selection et des voisins touches, puis remis
#     sur les voisins (sur les coins qui restent).
#   - Corps outils figes (BaseFeature) liberes par la suppression de leur
#     Combiner : retires de leur BaseFeature.
#   - Lots d'Entaille CNC : la selection est retiree de leurs corps, pour que
#     Mettre a jour CNC ne recree pas ce qui vient d'etre purge.
#   - Tout est fait dans une commande Fusion : un seul Ctrl+Z annule tout.
#   - Aucun fichier JSON partage n'est lu ni ecrit.
# ---------------------------------------------------------------------------

_app = None
_ui = None
_handlers = []

CMD_ID = 'PurgeCNCCmd'
CMD_NAME = 'Purger CNC'
CMD_DESC = ('Supprime tout ce que CNC Toolkit a cree sur les corps selectionnes, '
            'et les coupes qu\'ils ont faites dans les autres corps')

CNC_GROUP_PREFIXES = ('Tenon CNC', 'Mortaise CNC', 'Entaille CNC', 'Marge CNC', 'Modif Marge',
                      'Mise a jour CNC', 'Mise \u00e0 jour CNC', 'Gravure CNC', 'Dogbone CNC')
CNC_NAME_PREFIXES = ('Tenon', 'Mortaise CNC', 'Entaille', 'Marge CNC', 'Modif Marge',
                     'Gravure CNC', 'Dogbone')
CNC_ATTR_GROUPS = ('TenonCNC', 'MortaiseCNC', 'MargeCNC', 'EntailleCNC', 'DogboneCNC')
_LOT_GROUP = 'EntailleCNC'
_TOUCH_CM = 0.1   # 1 mm : couvre le jeu des marges (0,1 a 0,5 mm)

_ADDIN_DIR = os.path.dirname(os.path.abspath(__file__))
DEBUG_LOG = os.path.join(_ADDIN_DIR, 'purge_debug.log')


def _dbg(msg):
    try:
        with open(DEBUG_LOG, 'a', encoding='utf-8') as f:
            f.write(msg + '\n')
    except Exception:
        pass


def _find_module(short_name):
    mod = sys.modules.get(short_name)
    if mod is not None:
        return mod
    for k, m in list(sys.modules.items()):
        if k.endswith(short_name + '_py'):
            return m
    return None


# --- Selection -------------------------------------------------------------

def _key(body):
    """(id du composant, nom du corps natif)."""
    try:
        nb = body.nativeObject or body
    except Exception:
        nb = body
    return (nb.parentComponent.id, nb.name)


def bodies_from_entities(design, entities):
    """Corps (proxies conserves) des corps / occurrences / composants."""
    out, seen = [], set()

    def add(b):
        k = _key(b)
        if k not in seen:
            seen.add(k)
            out.append(b)
    for e in entities:
        b = adsk.fusion.BRepBody.cast(e)
        if b is not None:
            add(b)
            continue
        occ = adsk.fusion.Occurrence.cast(e)
        if occ is not None:
            for bb in occ.bRepBodies:
                add(bb)
            for sub in occ.childOccurrences:
                for bb in sub.bRepBodies:
                    add(bb)
            continue
        comp = adsk.fusion.Component.cast(e)
        if comp is not None:
            for bb in comp.bRepBodies:
                add(bb)
    return out


# --- Espace monde -------------------------------------------------------------

def _single_occ(comp, design):
    """Occurrence unique d'un composant (None pour la racine). False si le
    composant est utilise plusieurs fois (espace monde ambigu)."""
    if comp == design.rootComponent:
        return None
    occs = design.rootComponent.allOccurrencesByComponent(comp)
    if occs.count == 1:
        return occs.item(0)
    return False


def _world(entity, design):
    """Proxy monde d'une face / d'un corps natif, ou None si ambigu."""
    try:
        if entity.assemblyContext is not None:
            return entity
    except Exception:
        pass
    occ = _single_occ(entity.body.parentComponent if hasattr(entity, 'body') and adsk.fusion.BRepFace.cast(entity)
                      else entity.parentComponent, design)
    if occ is None:
        return entity
    if occ is False:
        return None
    return entity.createForAssemblyContext(occ)


def _bb_near(b1, b2, tol):
    return not (b1.maxPoint.x + tol < b2.minPoint.x or b2.maxPoint.x + tol < b1.minPoint.x or
                b1.maxPoint.y + tol < b2.minPoint.y or b2.maxPoint.y + tol < b1.minPoint.y or
                b1.maxPoint.z + tol < b2.minPoint.z or b2.maxPoint.z + tol < b1.minPoint.z)


class _Sel:
    """Corps selectionnes, en espace monde, pour le test de contact."""

    def __init__(self, design, bodies):
        self.design = design
        self.keys = set(_key(b) for b in bodies)
        self.world = []
        for b in bodies:
            w = b if b.assemblyContext is not None else _world(b, design)
            if w is not None:
                self.world.append(w)
        self.mm = adsk.core.Application.get().measureManager

    def face_touches(self, face):
        try:
            if _key(face.body) in self.keys:
                return True
        except Exception:
            pass
        wf = _world(face, self.design)
        if wf is None:
            return False
        try:
            fb = wf.boundingBox
            # un point INTERIEUR de la face : un simple contact par une arete
            # (corps colles cote a cote) ne compte pas
            pt = wf.pointOnFace
        except Exception:
            return False
        for sb in self.world:
            try:
                if not _bb_near(fb, sb.boundingBox, _TOUCH_CM):
                    continue
                r = self.mm.measureMinimumDistance(pt, sb)
                if r is not None and r.value <= _TOUCH_CM:
                    return True
            except Exception:
                continue
        return False


# --- Fonctions CNC de l'historique ---------------------------------------------

def _cnc_items(design):
    """[(timelineObject, entite, nom du groupe CNC ou '')] des fonctions CNC
    actives, dans l'ordre de l'historique."""
    out = []

    def is_cnc_group(name):
        name = name or ''
        if name.startswith('Jonction'):
            return None
        return name.startswith(CNC_GROUP_PREFIXES)

    def walk(coll, gname):
        for i in range(coll.count):
            it = coll.item(i)
            if it.isGroup:
                g = adsk.fusion.TimelineGroup.cast(it)
                cg = is_cnc_group(g.name)
                if cg is None:
                    continue  # jonction : jamais touchee
                walk(g, g.name if cg else gname)
                continue
            try:
                if it.isSuppressed or it.isRolledBack:
                    continue
                ent = it.entity
            except Exception:
                continue
            if ent is None:
                continue
            nm = getattr(ent, 'name', '') or ''
            cnc = bool(gname)
            if not cnc and nm.startswith(CNC_NAME_PREFIXES):
                cnc = True
            if not cnc:
                try:
                    for a in ent.attributes:
                        if a.groupName in CNC_ATTR_GROUPS:
                            cnc = True
                            break
                except Exception:
                    pass
            if nm.startswith('_MortaiseCNC_marker') or nm.startswith('Jonction'):
                cnc = False
            if cnc:
                out.append((it, ent, gname or ''))
    walk(design.timeline, '')
    return out


def _has_attr_group(ent, group):
    try:
        for a in ent.attributes:
            if a.groupName == group:
                return True
    except Exception:
        pass
    return False


def _feature_sketches(feat):
    """Esquisses utilisees par une extrusion / un enlevement de matiere."""
    out = []
    try:
        prof = feat.profile
    except Exception:
        return out
    items = []
    if isinstance(prof, adsk.core.ObjectCollection):
        items = [prof.item(i) for i in range(prof.count)]
    elif prof is not None:
        items = [prof]
    for p in items:
        try:
            sk = p.parentSketch
            if sk is not None:
                out.append(sk)
        except Exception:
            continue
    return out


def analyse(design, bodies):
    """Plan de purge, sans rien modifier. Retourne un dict :
    {'delete': [entites], 'offsets': [OffsetFacesFeature], 'partners': [corps],
     'names': [noms des fonctions], 'base': [BaseFeature CNC]}"""
    sel = _Sel(design, bodies)
    items = _cnc_items(design)
    delete, offsets, base, names = [], [], [], []
    partner_keys = {}
    sketch_of = {}
    for it, ent, gname in items:
        if _has_attr_group(ent, 'DogboneCNC'):
            continue  # traites par DogboneCNC
        if adsk.fusion.Sketch.cast(ent) is not None:
            continue  # partent avec leur extrusion
        if adsk.fusion.BaseFeature.cast(ent) is not None:
            base.append(ent)
            continue
        if adsk.fusion.OffsetFacesFeature.cast(ent) is not None:
            offsets.append(ent)
            continue
        feat = adsk.fusion.Feature.cast(ent)
        if feat is None:
            continue
        related = False
        try:
            for b in feat.bodies:
                if _key(b) in sel.keys:
                    related = True
                    break
        except Exception:
            pass
        if not related:
            try:
                for f in feat.faces:
                    if sel.face_touches(f):
                        related = True
                        break
            except Exception:
                pass
        if not related:
            continue
        delete.append(feat)
        names.append(feat.name)
        try:
            for b in feat.bodies:
                k = _key(b)
                if k not in sel.keys:
                    partner_keys[k] = b
        except Exception:
            pass
        for sk in _feature_sketches(feat):
            delete.append(sk)
    return {'delete': delete, 'offsets': offsets, 'base': base, 'names': names,
            'partners': list(partner_keys.values()), 'sel': sel}


def summary(plan, bodies):
    n = len(plan['names'])
    lines = ['%d corps selectionne(s) : %s' % (len(bodies), ', '.join(b.name for b in bodies[:8])
                                                + (' ...' if len(bodies) > 8 else ''))]
    lines.append('%d fonction(s) CNC a supprimer' % n)
    if plan['partners']:
        lines.append('Coupes retirees aussi sur : ' + ', '.join(sorted(set(b.name for b in plan['partners']))))
    lines.append('Les jeux et les dogbones concernes sont retires (dogbones remis sur les autres corps).')
    return '\n'.join(lines)


# --- Execution -------------------------------------------------------------------

def _trim_offsets(design, offsets, sel, partner_keys):
    """Retire des fonctions de jeu les faces liees a la selection. Retourne
    (fonctions a supprimer, nombre de faces retirees)."""
    to_delete = []
    n_faces = 0
    tl = design.timeline
    at_end = tl.markerPosition >= tl.count
    pos = tl.markerPosition
    expanded = []
    for of in offsets:
        try:
            tlo = of.timelineObject
            g = tlo.parentGroup
            if g is not None and g.isCollapsed:
                # rollTo echoue dans un groupe replie ("feature is invalid")
                g.isCollapsed = False
                expanded.append(g)
            tlo.rollTo(True)
            faces = list(of.inputFaces)
            keep = []
            dropped = 0
            for f in faces:
                if sel.face_touches(f):
                    dropped += 1
                    try:
                        k = _key(f.body)
                        if k not in sel.keys:
                            partner_keys[k] = True
                    except Exception:
                        pass
                else:
                    keep.append(f)
            if dropped == 0:
                continue
            n_faces += dropped
            if not keep:
                to_delete.append(of)
            else:
                of.inputFaces = keep
        except Exception:
            _dbg('trim offset EXCEPTION: ' + traceback.format_exc())
    try:
        if at_end:
            tl.moveToEnd()
        else:
            tl.markerPosition = pos
    except Exception:
        pass
    for g in expanded:
        try:
            if g.isValid:
                g.isCollapsed = True
        except Exception:
            pass
    return to_delete, n_faces


def _delete_batch(design, feats):
    """Suppression en un seul recalcul (meme methode que DogboneCNC)."""
    Dog = _find_module('DogboneCNC')
    if Dog is not None and hasattr(Dog, '_delete_features_batch'):
        Dog._delete_features_batch(design, feats)
        return
    for f in feats:
        try:
            f.deleteMe()
        except Exception:
            _dbg('delete EXCEPTION: ' + traceback.format_exc())


def _clean_orphan_tools(design, base_feats, before_empty):
    """BaseFeature CNC dont les corps outils ne sont plus consommes (leur
    Combiner a ete supprime) : on retire ces corps ; la BaseFeature est
    supprimee si elle n'en contient plus. before_empty : index (dans
    base_feats) des BaseFeature vides en fin d'historique avant la purge."""
    n = 0
    whole = []
    tl = design.timeline
    at_end = tl.markerPosition >= tl.count
    for i, bf in enumerate(base_feats):
        try:
            if i not in before_empty or not bf.isValid:
                continue
            n_orph = bf.bodies.count  # corps visibles en fin d'historique
            if not n_orph:
                continue
            # en edition, les corps d'une BaseFeature portent d'autres noms :
            # on compare les nombres
            bf.startEdit()
            try:
                total = bf.bodies.count
            finally:
                bf.finishEdit()
            if total == n_orph:
                whole.append(bf)
                n += n_orph
            else:
                _dbg('orphan: %s garde %d corps outils sur %d' % (bf.name, n_orph, total))
        except Exception:
            _dbg('orphan EXCEPTION: ' + traceback.format_exc())
    for bf in whole:
        try:
            bf.deleteMe()
        except Exception:
            _dbg('orphan delete EXCEPTION: ' + traceback.format_exc())
    if at_end:
        try:
            tl.moveToEnd()
        except Exception:
            pass
    return n


def _clean_lots(design, sel_keys):
    """Retire la selection des lots d'Entaille CNC (sinon Mettre a jour CNC
    pourrait recreer ce qui vient d'etre purge)."""
    try:
        attrs = design.attributes
        lots = [attrs.item(i) for i in range(attrs.count)
                if attrs.item(i).groupName == _LOT_GROUP and attrs.item(i).name.startswith('lot_')]
    except Exception:
        return 0
    n = 0
    for a in lots:
        try:
            lot = json.loads(a.value)
        except Exception:
            continue

        def keep(ref):
            return (ref.get('comp'), ref.get('name')) not in sel_keys
        changed = False
        for fld in ('bodies', 'targets', 'tools'):
            if fld in lot:
                new = [r for r in lot[fld] if keep(r)]
                if len(new) != len(lot[fld]):
                    lot[fld] = new
                    changed = True
        if not changed:
            continue
        names = set('%s|%s' % (comp, name) for comp, name in sel_keys)
        lot['sig'] = {k: v for k, v in lot.get('sig', {}).items()
                      if '|'.join(k.split('|')[1:]) not in names}
        lot['flipped'] = [p for p in lot.get('flipped', [])
                          if not any('|'.join(x.split('|')[1:]) in names for x in p)]
        refs = lot.get('bodies', []) if lot.get('kind') == 'unique' else lot.get('targets', []) + lot.get('tools', [])
        if len(refs) < 2 or (lot.get('kind') != 'unique' and (not lot.get('targets') or not lot.get('tools'))):
            a.deleteMe()
        else:
            design.attributes.add(_LOT_GROUP, a.name, json.dumps(lot))
        n += 1
    return n


def purge(design, bodies):
    """Purge reelle. Retourne {'n_features', 'n_faces', 'n_dogbones', 'partners', 'messages'}."""
    messages = []
    groups = []
    try:
        groups = [(g, g.isCollapsed) for g in design.timeline.timelineGroups]
    except Exception:
        pass
    cnc_progress.etape('Analyse des fonctions CNC...', 0, 6)
    plan = analyse(design, bodies)
    sel = plan['sel']
    partner_keys = {}
    for b in plan['partners']:
        partner_keys[_key(b)] = True

    # 1) jeu : on retire les faces liees AVANT de supprimer les coupes
    off_delete, n_faces = _trim_offsets(design, plan['offsets'], sel, partner_keys)

    cnc_progress.etape('Retrait des dogbones...', 1)
    # 2) dogbones de la selection et des voisins (remis ensuite sur les voisins)
    Dog = _find_module('DogboneCNC')
    snap = None
    n_dog = 0
    if Dog is not None:
        try:
            comps = {c.id: c for c in design.allComponents}
            partners = []
            for (cid, name) in partner_keys:
                c = comps.get(cid)
                b = c.bRepBodies.itemByName(name) if c is not None else None
                if b is not None:
                    partners.append(b)
            snap = Dog.snapshot_dogbones(design, partners) if partners else None
            n_dog = Dog.remove_dogbones(design, keys=set(sel.keys) | set(partner_keys))
        except Exception:
            messages.append('Dogbones : ' + traceback.format_exc().strip().splitlines()[-1])

    cnc_progress.etape('Suppression des coupes...', 2)
    # 3) suppression groupee des coupes liees
    before_empty = set()
    for i, bf in enumerate(plan['base']):
        try:
            if bf.bodies.count == 0:
                before_empty.add(i)
        except Exception:
            pass
    feats = [f for f in plan['delete'] + off_delete if f is not None and f.isValid]
    if feats:
        _delete_batch(design, feats)

    cnc_progress.etape('Nettoyage des corps outils...', 3)
    # 4) corps outils figes liberes
    n_orph = _clean_orphan_tools(design, plan['base'], before_empty)

    cnc_progress.etape("Nettoyage des lots d'entailles...", 4)
    # 5) lots d'entailles
    _clean_lots(design, sel.keys)

    cnc_progress.etape('Dogbones remis sur les voisins...', 5)
    # 6) dogbones remis sur les voisins
    if Dog is not None and snap:
        try:
            _ok, _tot, errs = Dog.restore_dogbones(design, snap)
            messages.extend(errs or [])
        except Exception:
            messages.append('Dogbones : ' + traceback.format_exc().strip().splitlines()[-1])

    for g, collapsed in groups:
        try:
            if g.isValid and g.isCollapsed != collapsed:
                g.isCollapsed = collapsed
        except Exception:
            pass

    return {'n_features': len(plan['names']) + len(off_delete), 'n_faces': n_faces,
            'n_dogbones': n_dog, 'n_orphans': n_orph,
            'partners': sorted(set(n for _c, n in partner_keys)), 'messages': messages}


# --- Commande Fusion ---------------------------------------------------------------

def _selected(inputs):
    sel_in = inputs.itemById('sel')
    ents = [sel_in.selection(i).entity for i in range(sel_in.selectionCount)]
    design = adsk.fusion.Design.cast(_app.activeProduct)
    return design, bodies_from_entities(design, ents)


class _CreatedHandler(adsk.core.CommandCreatedEventHandler):
    def notify(self, args):
        try:
            cmd = args.command
            inputs = cmd.commandInputs
            si = inputs.addSelectionInput('sel', 'Corps / composants', 'Corps ou composants a purger')
            si.addSelectionFilter('Bodies')
            si.addSelectionFilter('Occurrences')
            si.setSelectionLimits(1, 0)
            tb = inputs.addTextBoxCommandInput('info', '', 'Selectionne les corps ou composants a purger.', 6, True)
            tb.isFullWidth = True
            for h, ev in ((_InputChangedHandler(), cmd.inputChanged),
                          (_ExecuteHandler(), cmd.execute)):
                ev.add(h)
                _handlers.append(h)
        except Exception:
            _ui.messageBox('Erreur :\n' + traceback.format_exc(), CMD_NAME)


class _InputChangedHandler(adsk.core.InputChangedEventHandler):
    def notify(self, args):
        try:
            if args.input.id != 'sel':
                return
            inputs = args.inputs
            design, bodies = _selected(inputs)
            info = inputs.itemById('info')
            if not bodies:
                info.text = 'Selectionne les corps ou composants a purger.'
                return
            info.text = summary(analyse(design, bodies), bodies)
        except Exception:
            _dbg('inputChanged EXCEPTION: ' + traceback.format_exc())


# --- Garde-fou Calpinage CNC (2026-10-10) ------------------------------------
# Calpinage CNC peut poser les vraies pieces a plat sur des panneaux (groupe
# d'historique "Calpinage CNC"). Cet outil travaille sur les pieces en
# position d'assemblage : on refuse tant que le calpinage est en place.
def _calpinage_en_place():
    try:
        design = adsk.fusion.Design.cast(adsk.core.Application.get().activeProduct)
        tl = design.timeline
        for i in range(tl.timelineGroups.count):
            n = tl.timelineGroups.item(i).name
            if n.startswith('Calpinage CNC') and 'copie' not in n:
                return True
    except Exception:
        pass
    return False


def _calpinage_refus(ui, titre):
    ui.messageBox("Les pieces sont posees a plat par Calpinage CNC.\n\n"
                  "Remets-les d'abord en assemblage : palette CNC Toolkit > "
                  "Calpinage CNC > Remettre en assemblage.", titre)


class _ExecuteHandler(adsk.core.CommandEventHandler):
    def notify(self, args):
        if _calpinage_en_place():
            _calpinage_refus(_ui, CMD_NAME)
            return
        try:
            design, bodies = _selected(args.command.commandInputs)
            if not bodies:
                return
            with cnc_progress.Barre(CMD_NAME, 'Purge en cours...', total=6):
                r = purge(design, bodies)
            msg = ('%d fonction(s) CNC supprimee(s), %d face(s) de jeu retiree(s), '
                   'dogbones retires sur %d corps.' % (r['n_features'], r['n_faces'], r['n_dogbones']))
            if r['partners']:
                msg += '\nAutres corps nettoyes : ' + ', '.join(r['partners'])
            if r['messages']:
                msg += '\n\n' + '\n'.join(r['messages'][:8])
            msg += '\n\nCtrl+Z annule toute la purge.'
            _ui.messageBox(msg, CMD_NAME)
        except Exception:
            _ui.messageBox('Erreur pendant la purge :\n' + traceback.format_exc(), CMD_NAME)


def run(context):
    global _app, _ui
    try:
        _app = adsk.core.Application.get()
        _ui = _app.userInterface
        cd = _ui.commandDefinitions.itemById(CMD_ID)
        if cd is None:
            cd = _ui.commandDefinitions.addButtonDefinition(CMD_ID, CMD_NAME, CMD_DESC)
        h = _CreatedHandler()
        cd.commandCreated.add(h)
        _handlers.append(h)
    except Exception:
        if _ui:
            _ui.messageBox('Erreur au demarrage de Purger CNC :\n' + traceback.format_exc())


def stop(context):
    try:
        cd = _ui.commandDefinitions.itemById(CMD_ID)
        if cd:
            cd.deleteMe()
    except Exception:
        pass
    _handlers.clear()
