import adsk.core, adsk.fusion, traceback
_app=None; _ui=None
_CMD_ID="ChantInterieur_Cmd"
_EVT_ID="ChantInterieur_SelEvt"
_hcreated=None; _hexecute=None; _hchanged=None; _hvalidate=None; _hevt=None
_pending_faces=[]
_SEUIL_TENON=0.40  # grande face > 40% de la longueur => tenon

def _get_normal(face):
    ev=face.evaluator; pr=ev.parametricRange()
    cu=(pr.minPoint.x+pr.maxPoint.x)/2; cv=(pr.minPoint.y+pr.maxPoint.y)/2
    ok,n=ev.getNormalAtParameter(adsk.core.Point2D.create(cu,cv))
    return n if ok else None

def _face_center(face):
    bb=face.boundingBox
    return((bb.minPoint.x+bb.maxPoint.x)/2,(bb.minPoint.y+bb.maxPoint.y)/2,(bb.minPoint.z+bb.maxPoint.z)/2)

def _get_axes(body):
    # Retourne (th_axis, wi_axis, lo_axis, ep, lo_val)
    planes=sorted([f for f in body.faces if isinstance(f.geometry,adsk.core.Plane)],key=lambda f:f.area,reverse=True)
    ep=0.0
    for i in range(len(planes)):
        for j in range(i+1,min(i+6,len(planes))):
            n1=_get_normal(planes[i]); n2=_get_normal(planes[j])
            if n1 is None or n2 is None: continue
            if abs(n1.x*n2.x+n1.y*n2.y+n1.z*n2.z)<0.99: continue
            b1=planes[i].boundingBox; b2=planes[j].boundingBox
            c1x=(b1.minPoint.x+b1.maxPoint.x)/2; c1y=(b1.minPoint.y+b1.maxPoint.y)/2; c1z=(b1.minPoint.z+b1.maxPoint.z)/2
            c2x=(b2.minPoint.x+b2.maxPoint.x)/2; c2y=(b2.minPoint.y+b2.maxPoint.y)/2; c2z=(b2.minPoint.z+b2.maxPoint.z)/2
            d=abs((c2x-c1x)*n1.x+(c2y-c1y)*n1.y+(c2z-c1z)*n1.z)
            if d>0.001: ep=d; break
        if ep>0: break
    if ep==0:
        bb=body.boundingBox; mn,mx=bb.minPoint,bb.maxPoint
        ep=min(mx.x-mn.x,mx.y-mn.y,mx.z-mn.z)
    bb=body.boundingBox; mn,mx=bb.minPoint,bb.maxPoint
    sx=mx.x-mn.x; sy=mx.y-mn.y; sz=mx.z-mn.z
    dims=sorted([("x",sx),("y",sy),("z",sz)],key=lambda t:t[1])
    return dims[0][0],dims[1][0],dims[2][0],ep,dims[2][1]

def _chant_faces(body, th_n, ep, lo_axis, lo_val):
    TOL=0.001; TOL_EP=ep*0.15
    bb=body.boundingBox; mn,mx=bb.minPoint,bb.maxPoint; kept=[]
    for face in body.faces:
        if not isinstance(face.geometry,adsk.core.Plane): continue
        n=_get_normal(face)
        if n is None: continue
        if th_n and abs(n.x*th_n.x+n.y*th_n.y+n.z*th_n.z)>0.99: continue
        fb=face.boundingBox; fm,fx=fb.minPoint,fb.maxPoint; bord=False
        if abs(n.y)>0.99:
            if n.y>0 and abs(fx.y-mx.y)<TOL: bord=True
            if n.y<0 and abs(fm.y-mn.y)<TOL: bord=True
        if abs(n.z)>0.99:
            if n.z>0 and abs(fx.z-mx.z)<TOL: bord=True
            if n.z<0 and abs(fm.z-mn.z)<TOL: bord=True
        if abs(n.x)>0.99:
            if n.x>0 and abs(fx.x-mx.x)<TOL: bord=True
            if n.x<0 and abs(fm.x-mn.x)<TOL: bord=True
        if bord: continue
        sx=fx.x-fm.x; sy=fx.y-fm.y; sz=fx.z-fm.z
        dims=sorted([sx,sy,sz])
        if abs(dims[1]-ep)>TOL_EP: continue
        kept.append(face)
    return kept

def _group_connected(faces):
    edge_idx={}
    for i,face in enumerate(faces):
        for e in face.edges:
            bb=e.boundingBox
            key=(round(bb.minPoint.x,3),round(bb.minPoint.y,3),round(bb.minPoint.z,3),
                 round(bb.maxPoint.x,3),round(bb.maxPoint.y,3),round(bb.maxPoint.z,3))
            edge_idx.setdefault(key,[]).append(i)
    adj=[set() for _ in range(len(faces))]
    for fl in edge_idx.values():
        for a in range(len(fl)):
            for b in range(a+1,len(fl)): adj[fl[a]].add(fl[b]); adj[fl[b]].add(fl[a])
    visited=[False]*len(faces); groups=[]
    for i in range(len(faces)):
        if visited[i]: continue
        grp=[i]; visited[i]=True; stack=[i]
        while stack:
            cur=stack.pop()
            for j in adj[cur]:
                if not visited[j]: visited[j]=True; grp.append(j); stack.append(j)
        groups.append([faces[k] for k in grp])
    return groups

def _is_group_female(grp, lo_axis, lo_val):
    # Vote centre-groupe
    gcx=sum(_face_center(f)[0] for f in grp)/len(grp)
    gcy=sum(_face_center(f)[1] for f in grp)/len(grp)
    gcz=sum(_face_center(f)[2] for f in grp)/len(grp)
    votes_f=0; votes_m=0; largest_dot=0; largest_area=0; largest_face=None
    for face in grp:
        n=_get_normal(face)
        if n is None: continue
        fcx,fcy,fcz=_face_center(face)
        dot=(gcx-fcx)*n.x+(gcy-fcy)*n.y+(gcz-fcz)*n.z
        if dot>0: votes_f+=1
        else: votes_m+=1
        if face.area>largest_area: largest_area=face.area; largest_dot=dot; largest_face=face
    # Critere 1: vote majoritaire
    if votes_f>votes_m: vote_result=True
    elif votes_m>votes_f: vote_result=False
    else: vote_result=(largest_dot>0)
    # Critere 2: si la grande face occupe >40% de la longueur -> TENON (surpasse vote)
    if largest_face is not None and lo_val>0:
        fb=largest_face.boundingBox
        large_lo=abs(getattr(fb.maxPoint,lo_axis)-getattr(fb.minPoint,lo_axis))
        ratio=large_lo/lo_val
        if ratio>_SEUIL_TENON: return False  # tenon confirme
    return vote_result

def _select_from_group(grp, lo_axis, lo_val):
    n=len(grp)
    if n<=2: return []
    sg=sorted(grp,key=lambda f:f.area)
    if n>=4: selected=list(grp)
    else:
        areas=[f.area for f in sg]
        if areas[0]<areas[1]*0.7: selected=sg[1:]
        else: selected=list(grp)
    if not _is_group_female(selected, lo_axis, lo_val): return []
    return selected

def _get_faces_body(body):
    th_axis,wi_axis,lo_axis,ep,lo_val=_get_axes(body)
    planes=sorted([f for f in body.faces if isinstance(f.geometry,adsk.core.Plane)],key=lambda f:f.area,reverse=True)
    th_n=_get_normal(planes[0]) if planes else None
    chant=_chant_faces(body,th_n,ep,lo_axis,lo_val)
    if not chant: return []
    result=[]
    for grp in _group_connected(chant): result.extend(_select_from_group(grp,lo_axis,lo_val))
    return result

def _get_bodies_from_sel(sel_input):
    design=adsk.fusion.Design.cast(_app.activeProduct)
    root=design.rootComponent; bodies=[]
    for i in range(sel_input.selectionCount):
        e=sel_input.selection(i).entity
        if isinstance(e,adsk.fusion.BRepBody):
            if e not in bodies: bodies.append(e)
        elif isinstance(e,adsk.fusion.Occurrence):
            for b in e.bRepBodies:
                if b not in bodies: bodies.append(b)
    if not bodies:
        for comp in design.allComponents:
            for b in comp.bRepBodies: bodies.append(b)
    return bodies

def _compute_all_faces(bodies):
    all_faces=[]
    for body in bodies: all_faces.extend(_get_faces_body(body))
    return all_faces

def _apply_jeu(all_faces,jeu_cm):
    design=adsk.fusion.Design.cast(_app.activeProduct)
    root=design.rootComponent
    if not all_faces: return 0
    dist=adsk.core.ValueInput.createByReal(jeu_cm)
    inp=root.features.offsetFacesFeatures.createInput(all_faces,dist)
    feat=root.features.offsetFacesFeatures.add(inp)
    if feat: feat.attributes.add("ChantInterieur","jeu_cm",str(jeu_cm)); return len(all_faces)
    return 0
class HSelectEvent(adsk.core.CustomEventHandler):
    def notify(self,args):
        global _pending_faces
        try:
            sels=_ui.activeSelections; sels.clear()
            for f in _pending_faces:
                try: sels.add(f)
                except: pass
            _pending_faces=[]
        except: pass

class HValidate(adsk.core.ValidateInputsEventHandler):
    def notify(self,args):
        try: args.areInputsValid=True
        except: args.areInputsValid=False

class HChanged(adsk.core.InputChangedEventHandler):
    def notify(self,args):
        try:
            inputs=args.inputs; s=inputs.itemById("sel_comps"); lbl=inputs.itemById("lbl_sel")
            if lbl and s: lbl.text=str(s.selectionCount)+" corps selectionne(s)"
        except: pass

class HExecute(adsk.core.CommandEventHandler):
    def notify(self,args):
        global _pending_faces
        try:
            inputs=args.command.commandInputs
            sel=inputs.itemById("sel_comps")
            val=inputs.itemById("val_jeu")
            tog=inputs.itemById("tog_enabled")
            jeu_cm=val.value if val else -0.02
            enabled=tog.value if tog else False
            bodies=_get_bodies_from_sel(sel)
            all_faces=_compute_all_faces(bodies)
            if enabled:
                nb=_apply_jeu(all_faces,jeu_cm)
                _ui.messageBox("1 feature creee : "+str(round(jeu_cm*10,3))+" mm sur "+str(nb)+" faces.","Chant Interieur")
            else:
                if not all_faces:
                    _ui.messageBox("Aucune mortaise trouvee.","Chant Interieur"); return
                _pending_faces=all_faces
                _app.fireCustomEvent(_EVT_ID,"")
        except: _ui.messageBox(traceback.format_exc())

class HCreated(adsk.core.CommandCreatedEventHandler):
    def notify(self,args):
        global _hexecute,_hchanged,_hvalidate
        try:
            cmd=args.command; cmd.isRepeatable=False; inputs=cmd.commandInputs
            sel=inputs.addSelectionInput("sel_comps","Corps / Composants","Selectionnez les corps (vide = tous)")
            sel.addSelectionFilter("SolidBodies"); sel.addSelectionFilter("Occurrences")
            sel.setSelectionLimits(0,0)
            inputs.addTextBoxCommandInput("lbl_sel","","0 corps selectionne(s)",1,True)
            inputs.addTextBoxCommandInput("lbl_sep","","<hr><b>Jeu de fonctionnement</b>",1,True)
            inputs.addValueInput("val_jeu","Valeur du jeu","mm",adsk.core.ValueInput.createByString("-0.2 mm"))
            inputs.addBoolValueInput("tog_enabled","Appliquer le jeu",True,"",False)
            inputs.addTextBoxCommandInput("lbl_info","",
                "<i>Mortaises uniquement.<br>Desactive : selectionne les faces.<br>Active : 1 feature dans la timeline.</i>",2,True)
            _hexecute=HExecute(); cmd.execute.add(_hexecute)
            _hchanged=HChanged(); cmd.inputChanged.add(_hchanged)
            _hvalidate=HValidate(); cmd.validateInputs.add(_hvalidate)
        except: _ui.messageBox(traceback.format_exc())

def run(context):
    global _app,_ui,_hcreated,_hevt
    try:
        _app=adsk.core.Application.get(); _ui=_app.userInterface
        try: _app.unregisterCustomEvent(_EVT_ID)
        except: pass
        custom_evt=_app.registerCustomEvent(_EVT_ID)
        _hevt=HSelectEvent(); custom_evt.add(_hevt)
        old=_ui.commandDefinitions.itemById(_CMD_ID)
        if old: old.deleteMe()
        cd=_ui.commandDefinitions.addButtonDefinition(
            _CMD_ID,"Chant Interieur",
            "Selectionne les mortaises et applique un jeu de fonctionnement.","")
        _hcreated=HCreated(); cd.commandCreated.add(_hcreated)
        # Bouton de ruban (SolidModifyPanel) RETIRE : devenu inutile depuis
        # la creation de CNC Toolkit, qui retrouve et execute cette
        # CommandDefinition directement depuis sa palette.
    except:
        if _ui: _ui.messageBox(traceback.format_exc())

def stop(context):
    global _hcreated,_hexecute,_hchanged,_hvalidate,_hevt
    try:
        panel=_ui.allToolbarTabs.itemById("SolidTab").toolbarPanels.itemById("SolidModifyPanel")
        c=panel.controls.itemById(_CMD_ID)
        if c: c.deleteMe()
        d=_ui.commandDefinitions.itemById(_CMD_ID)
        if d: d.deleteMe()
        try: _app.unregisterCustomEvent(_EVT_ID)
        except: pass
        _hcreated=_hexecute=_hchanged=_hvalidate=_hevt=None
    except: pass
