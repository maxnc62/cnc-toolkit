import adsk.core
import adsk.fusion
import traceback
import os
import json

_app             = None
_ui              = None
_cmd_def         = None
_panel_ctrl      = None
_created_handler = None
_execute_handler = None
_destroy_handler = None

CMD_ID        = 'TenonMortaiseCmd'
SETTINGS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'settings_tenon.json')


def load_settings():
    try:
        if os.path.exists(SETTINGS_FILE):
            d = json.load(open(SETTINGS_FILE))
            return (
                int(d.get('mode', 0)),        # 0=tiers 1=espace
                float(d.get('espace_cm', 5.0)),
                float(d.get('jeu_cm', 0.02)),
                bool(d.get('jeu_actif', True))
            )
    except: pass
    return 0, 5.0, 0.02, True

def save_settings(mode, espace_cm, jeu_cm, jeu_actif):
    try:
        json.dump({'mode':mode,'espace_cm':espace_cm,
                   'jeu_cm':jeu_cm,'jeu_actif':jeu_actif},
                  open(SETTINGS_FILE,'w'))
    except: pass


def get_bounding_box_dims(body):
    """Retourne (longueur, largeur, epaisseur) triees grand->petit en cm."""
    bb = body.boundingBox
    dx = bb.maxPoint.x - bb.minPoint.x
    dy = bb.maxPoint.y - bb.minPoint.y
    dz = bb.maxPoint.z - bb.minPoint.z
    dims = sorted([dx, dy, dz], reverse=True)
    return dims[0], dims[1], dims[2]  # long, larg, ep


def get_center(body):
    bb = body.boundingBox
    cx = (bb.maxPoint.x + bb.minPoint.x) / 2
    cy = (bb.maxPoint.y + bb.minPoint.y) / 2
    cz = (bb.maxPoint.z + bb.minPoint.z) / 2
    return cx, cy, cz


def get_large_face(body):
    best = None
    for face in body.faces:
        if face.geometry.objectType != adsk.core.Plane.classType(): continue
        if best is None or face.area > best.area: best = face
    return best

def get_fem_ep(female):
    bb = female.boundingBox; mn,mx = bb.minPoint,bb.maxPoint
    return min(mx.x-mn.x, mx.y-mn.y, mx.z-mn.z)


def creer_tenon_mortaise(male_bodies, female_bodies, mode, espace_cm,
                         jeu_cm, jeu_actif, root):
    # Workflow DEFINITIF :
    # 1. Sketch PARAMETRIQUE sur face nY=-1 du male
    # 2. Projete UNIQUEMENT l arete horizontale de face_bas/face_haut
    #    (l arete sur la face avant du corps, a Y=mny)
    #    => ligne violette exactement sur le bord Z du corps => solidaire
    # 3. Rectangle du tenon sous la ligne projetee
    #    bord CONTACT = y_bas (sur ligne projetee = face du corps)
    #    bord LIBRE   = y_bas + ep_femelle (dans la femelle => en dessous)
    # 4. Contraintes :
    #    - addCollinear (bord contact solidaire de la projection)
    #    - addPerpendicular (cotes lateraux a l equerre)
    #    - addEqual (cotes lateraux egaux)
    #    - addParallel (bord libre parallele au bord contact)
    # 5. Dimensions :
    #    - Largeur = tlen
    #    - Hauteur = epaisseur de la femelle
    # 6. Extrude JoinFeatureOperation POS (vers Y+ = epaisseur du corps)
    # 7. Combine Couper chaque femelle avec male
    # 8. OffsetFaces jeu

    ef  = root.features.extrudeFeatures
    cf  = root.features.combineFeatures
    off = root.features.offsetFacesFeatures
    j   = abs(jeu_cm) if jeu_actif else 0.0
    nb_ok = 0

    for male in male_bodies:
        bb_m = male.boundingBox; mn,mx = bb_m.minPoint,bb_m.maxPoint
        mnx=float(mn.x); mny=float(mn.y); mnz=float(mn.z)
        mxx=float(mx.x); mxy=float(mx.y); mxz=float(mx.z)

        face_front = max(
            [f for f in male.faces
             if f.geometry.objectType==adsk.core.Plane.classType()
             and abs(f.geometry.normal.y+1)<0.1],
            key=lambda f:f.area, default=None)
        face_back  = max(
            [f for f in male.faces
             if f.geometry.objectType==adsk.core.Plane.classType()
             and abs(f.geometry.normal.y-1)<0.1],
            key=lambda f:f.area, default=None)
        nz_faces   = [f for f in male.faces
            if f.geometry.objectType==adsk.core.Plane.classType()
            and abs(f.geometry.normal.z)>0.9]
        if not face_front or not face_back or len(nz_faces)<2: continue
        face_bas  = min(nz_faces, key=lambda f:f.geometry.origin.z)
        face_haut = max(nz_faces, key=lambda f:f.geometry.origin.z)

        # Sketch sur face avant
        sk = root.sketches.add(face_front)
        C  = sk.geometricConstraints
        D  = sk.sketchDimensions
        L  = sk.sketchCurves.sketchLines

        # Projete UNIQUEMENT l arete horizontale de chaque face nZ
        # => l arete sur la face avant (Y=mny) = ligne violette EXACTEMENT
        #    sur le bord du corps => solidaire parametriquement
        def project_front_edge(face):
            z_face = face.geometry.origin.z
            for edge in face.edges:
                if edge.geometry.objectType != adsk.core.Line3D.classType(): continue
                vs = edge.startVertex.geometry
                ve = edge.endVertex.geometry
                # Arete sur la face avant (Y=mny)
                if (abs(min(vs.y,ve.y) - mny) < 0.01 and
                    abs(max(vs.y,ve.y) - mny) < 0.01 and
                    abs(vs.z - z_face) < 0.01 and
                    abs(ve.z - z_face) < 0.01):
                    return sk.project(edge)
            return None

        project_front_edge(face_bas)
        project_front_edge(face_haut)

        # Lignes horizontales projetees
        horiz = [l for l in L
                  if abs(l.startSketchPoint.geometry.y
                         - l.endSketchPoint.geometry.y) < 0.01
                  and not l.isConstruction]
        if len(horiz) < 2: continue
        line_bas  = min(horiz, key=lambda l: l.startSketchPoint.geometry.y)
        line_haut = max(horiz, key=lambda l: l.startSketchPoint.geometry.y)

        y_bas  = float(line_bas.startSketchPoint.geometry.y)
        y_haut = float(line_haut.startSketchPoint.geometry.y)
        x_L    = min(line_bas.startSketchPoint.geometry.x,
                     line_bas.endSketchPoint.geometry.x)
        x_R    = max(line_bas.startSketchPoint.geometry.x,
                     line_bas.endSketchPoint.geometry.x)
        dx     = x_R - x_L

        if mode==0: tlen = dx/3.0
        else:       tlen = dx - 2.0*espace_cm
        tlen  = max(tlen, 0.001)
        x_ctr = (x_L + x_R) / 2.0
        x1    = x_ctr - tlen/2
        x2    = x_ctr + tlen/2

        # Associe chaque femelle a sa ligne projetee
        fem_data = []
        for female in female_bodies:
            fem_ep = get_fem_ep(female)
            bb_f   = female.boundingBox
            gap_bas  = abs(mnz - float(bb_f.maxPoint.z))
            gap_haut = abs(mxz - float(bb_f.minPoint.z))
            if gap_bas <= gap_haut:
                # Tenon bas : contact sur y_bas, libre EN-DESSOUS (y_bas + fem_ep)
                y_c = y_bas
                y_f = y_bas + fem_ep
                lp  = line_bas
            else:
                # Tenon haut: contact sur y_haut, libre EN-DESSOUS (y_haut - fem_ep)
                y_c = y_haut
                y_f = y_haut - fem_ep
                lp  = line_haut
            fem_data.append((female, fem_ep, y_c, y_f, lp))

        # Dessine les rectangles des tenons + contraintes + dimensions
        for female, fem_ep, y_c, y_f, lp in fem_data:
            tok_bef = set(l.entityToken for l in L)
            L.addTwoPointRectangle(
                adsk.core.Point3D.create(x1, y_c, 0),
                adsk.core.Point3D.create(x2, y_f, 0))

            new_nc = [l for l in L
                       if l.entityToken not in tok_bef
                       and not l.isConstruction]

            l_contact = None; l_libre = None; lats = []
            for l in new_nc:
                y1_ = l.startSketchPoint.geometry.y
                y2_ = l.endSketchPoint.geometry.y
                if abs(y1_-y2_) < 0.01:
                    if abs(y1_-y_c) < 0.01: l_contact = l
                    if abs(y1_-y_f) < 0.01: l_libre   = l
                else:
                    lats.append(l)

            if not l_contact or not l_libre: continue

            # Contrainte colineaire: bord contact solidaire de la projection
            try: C.addCollinear(l_contact, lp)
            except Exception: pass

            # Contraintes de perpendicularite des cotes lateraux
            for ll in lats:
                try: C.addPerpendicular(l_contact, ll)
                except Exception: pass

            # Egalite des cotes lateraux
            if len(lats) >= 2:
                try: C.addEqual(lats[0], lats[1])
                except Exception: pass

            # Parallelisme bord libre / bord contact
            try: C.addParallel(l_contact, l_libre)
            except Exception: pass

            # Dimension largeur = tlen
            try:
                D.addDistanceDimension(
                    l_contact.startSketchPoint, l_contact.endSketchPoint,
                    adsk.fusion.DimensionOrientations.HorizontalDimensionOrientation,
                    adsk.core.Point3D.create(
                        x_ctr,
                        y_c + (0.5 if y_f>y_c else -0.5), 0)
                ).parameter.value = tlen
            except Exception: pass

            # Dimension hauteur = epaisseur de la femelle
            try:
                D.addDistanceDimension(
                    l_contact.startSketchPoint,
                    l_libre.startSketchPoint,
                    adsk.fusion.DimensionOrientations.VerticalDimensionOrientation,
                    adsk.core.Point3D.create(x1-0.8, (y_c+y_f)/2, 0)
                ).parameter.value = fem_ep
            except Exception: pass

        if sk.profiles.count == 0: continue

        # Les profils les plus petits = les tenons rectangulaires
        plist = sorted([sk.profiles.item(i) for i in range(sk.profiles.count)],
                       key=lambda p: p.areaProperties().area)
        n = min(len(fem_data), len(plist))
        if n == 0: continue
        col = adsk.core.ObjectCollection.create()
        for i in range(n): col.add(plist[i])

        # Extrude Join POS (vers Y+ = epaisseur du corps)
        hidden=[]
        for b in list(root.bRepBodies):
            if b.name!=male.name and b.isLightBulbOn:
                b.isLightBulbOn=False; hidden.append(b)
        join_ok=False
        try:
            ei  = ef.createInput(
                col, adsk.fusion.FeatureOperations.JoinFeatureOperation)
            ext = adsk.fusion.ToEntityExtentDefinition.create(face_back, False)
            ei.setOneSideExtent(
                ext, adsk.fusion.ExtentDirections.PositiveExtentDirection)
            ft  = ef.add(ei)
            join_ok = ft is not None
        except Exception: pass
        finally:
            for b in hidden: b.isLightBulbOn=True

        if not join_ok: continue

        # Combine Couper chaque femelle
        for female, _, _, _, _ in fem_data:
            try:
                tc=adsk.core.ObjectCollection.create(); tc.add(male)
                ci=cf.createInput(female,tc)
                ci.operation=adsk.fusion.FeatureOperations.CutFeatureOperation
                ci.isKeepToolBodies=True; cf.add(ci)
                nb_ok+=1
            except Exception: pass

        # OffsetFaces jeu
        if j>0:
            tenon_faces=[]
            for face in male.faces:
                if face.geometry.objectType!=adsk.core.Plane.classType(): continue
                if abs(face.geometry.normal.x)<0.9: continue
                oz=float(face.geometry.origin.z)
                if (oz<mnz+0.1 or oz>mxz-0.1):
                    dx_m=mxx-mnx
                    if mode==0: ten_est=dx_m/3.0
                    else: ten_est=dx_m-2.0*espace_cm
                    if face.area<(mxy-mny)*ten_est*1.5:
                        tenon_faces.append(face)
            if tenon_faces:
                try:
                    oi=off.createInput(tenon_faces,
                                       adsk.core.ValueInput.createByReal(-j))
                    off.add(oi)
                except Exception: pass

    return nb_ok



class CreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        global _execute_handler, _destroy_handler
        try:
            cmd    = adsk.core.CommandCreatedEventArgs.cast(args).command
            _execute_handler = ExecuteHandler()
            _destroy_handler = DestroyHandler()
            cmd.execute.add(_execute_handler)
            cmd.destroy.add(_destroy_handler)
            inputs = cmd.commandInputs

            # Selection pieces males
            sel_m = inputs.addSelectionInput(
                'males', '1. Piece(s) male(s) - tenon',
                'Selectionnez les pieces qui recevront le tenon'
            )
            sel_m.addSelectionFilter('Bodies')
            sel_m.setSelectionLimits(1, 0)

            # Selection pieces femelles
            sel_f = inputs.addSelectionInput(
                'femelles', '2. Piece(s) femelle(s) - mortaise',
                'Selectionnez les pieces qui recevront la mortaise'
            )
            sel_f.addSelectionFilter('Bodies')
            sel_f.setSelectionLimits(1, 0)

            mode, espace_cm, jeu_cm, jeu_actif = load_settings()

            # Mode de creation du tenon
            dd = inputs.addDropDownCommandInput(
                'mode', 'Mode du tenon',
                adsk.core.DropDownStyles.TextListDropDownStyle
            )
            dd.listItems.add('Division en tiers (1/3 centre)', mode == 0)
            dd.listItems.add('Espace fixe de chaque cote',     mode == 1)

            # Espace (visible seulement en mode 1)
            vi = inputs.addValueInput(
                'espace', 'Espace de chaque cote', 'mm',
                adsk.core.ValueInput.createByReal(espace_cm)
            )
            vi.isVisible = (mode == 1)

            # Jeu
            inputs.addBoolValueInput('jeu_actif', 'Jeu de fonctionnement actif', True, '', jeu_actif)
            inputs.addValueInput('jeu', 'Jeu (mm)', 'mm',
                adsk.core.ValueInput.createByReal(jeu_cm))

            # Reactualise visibilite espace selon mode
            cmd.inputChanged.add(InputChangedHandler())

        except Exception:
            _ui.messageBox('Erreur dialogue:\n' + traceback.format_exc())


class InputChangedHandler(adsk.core.InputChangedEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            changed = adsk.core.InputChangedEventArgs.cast(args).input
            inputs  = changed.parentCommand.commandInputs
            if changed.id == 'mode':
                dd = inputs.itemById('mode')
                inputs.itemById('espace').isVisible = (dd.selectedItem.index == 1)
        except: pass


class ExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            inputs  = adsk.core.CommandEventArgs.cast(args).firingEvent.sender.commandInputs
            si_m    = inputs.itemById('males')
            si_f    = inputs.itemById('femelles')
            si_mode = inputs.itemById('mode')
            si_esp  = inputs.itemById('espace')
            si_jon  = inputs.itemById('jeu_actif')
            si_jeu  = inputs.itemById('jeu')

            if si_m.selectionCount < 1 or si_f.selectionCount < 1:
                _ui.messageBox('Selectionnez au moins une piece male et une piece femelle.')
                return

            males   = [adsk.fusion.BRepBody.cast(si_m.selection(i).entity)
                       for i in range(si_m.selectionCount)]
            femelles= [adsk.fusion.BRepBody.cast(si_f.selection(i).entity)
                       for i in range(si_f.selectionCount)]
            mode     = si_mode.selectedItem.index
            espace   = si_esp.value  if si_esp  else 5.0
            jeu_actif= si_jon.value  if si_jon  else True
            jeu      = si_jeu.value  if si_jeu  else 0.02

            save_settings(mode, espace, jeu, jeu_actif)

            design = adsk.fusion.Design.cast(_app.activeProduct)
            root   = design.rootComponent

            nb = creer_tenon_mortaise(males, femelles, mode, espace, jeu, jeu_actif, root)

            _app.activeViewport.fit()
            _ui.messageBox(f'{nb} mortaise(s) creee(s) avec succes.')

        except Exception:
            _ui.messageBox('Erreur execution:\n' + traceback.format_exc())


class DestroyHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args): pass


def run(context):
    global _app, _ui, _cmd_def, _panel_ctrl, _created_handler
    try:
        _app = adsk.core.Application.get()
        _ui  = _app.userInterface

        panel = _ui.allToolbarPanels.itemById('SolidModifyPanel')
        if panel:
            c = panel.controls.itemById(CMD_ID)
            if c: c.deleteMe()
        old = _ui.commandDefinitions.itemById(CMD_ID)
        if old: old.deleteMe()

        _cmd_def = _ui.commandDefinitions.addButtonDefinition(
            CMD_ID, 'Tenon / Mortaise',
            'Cree automatiquement un tenon et sa mortaise', ''
        )
        _created_handler = CreatedHandler()
        _cmd_def.commandCreated.add(_created_handler)

        panel = _ui.allToolbarPanels.itemById('SolidModifyPanel')
        if panel:
            _panel_ctrl = panel.controls.addCommand(_cmd_def)
            _panel_ctrl.isPromotedByDefault = True

    except Exception:
        if _ui:
            _ui.messageBox('Erreur run:\n' + traceback.format_exc())


def stop(context):
    global _cmd_def, _panel_ctrl, _created_handler, _execute_handler, _destroy_handler
    try:
        if _panel_ctrl:     _panel_ctrl.deleteMe()
        if _cmd_def:        _cmd_def.deleteMe()
        _cmd_def = _panel_ctrl = None
        _created_handler = _execute_handler = _destroy_handler = None
    except: pass
