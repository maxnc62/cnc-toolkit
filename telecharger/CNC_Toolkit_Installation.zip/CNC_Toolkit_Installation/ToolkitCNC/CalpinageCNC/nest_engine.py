# ---------------------------------------------------------------------------
# Moteur de placement de Calpinage CNC (nesting), en Python pur : aucune
# dependance a Fusion (adsk) ni a une bibliotheque externe, pour pouvoir le
# tester hors de Fusion (voir test_nest_engine.py).
#
# ENTREE : des pieces decrites en 2D (mm), chacune par une liste de REGIONS ;
# une region = liste d'anneaux (contour exterieur puis trous), remplie en
# pair-impair. Cote Fusion, une region = une face plane parallele au panneau
# (dessus, fond de poche, dessus de tenon...) : l'union des regions donne la
# silhouette vue de dessus, les trous traversants restent vides.
#
# PRINCIPE
#   - Chaque piece est RASTERISEE sur une grille (pas = step mm) de facon
#     conservatrice : une cellule touchee par la piece est pleine.
#   - Une ligne de grille = un entier Python utilise en masque de bits (bit
#     i = colonne i). Tester une collision = ET binaire ligne par ligne.
#   - Espacement : la piece testee est grossie d'un disque de k cellules
#     (k = ceil(espacement / pas) + 1), les pieces deja posees restent a
#     leur taille reelle.
#   - Placement bas-gauche (Bottom-Left-Fill) dans un repere CANONIQUE ou
#     l'on remplit les y croissants puis les x croissants. Le coin de depart
#     et la direction de tassement sont obtenus par symetrie / transposition
#     de TOUT (panneau ET pieces), puis on revient au repere du panneau.
#   - Une piece n'est retournee (miroir y -> -y) que si opts['flip'] et
#     part['flippable'] : le placement porte alors 'flip': True.
#   - Pour un y donne, les x interdits se calculent d'un coup : pour chaque
#     bande de lignes identiques du masque grossi, OU des lignes du panneau
#     (table creuse) puis dilatation par chaque segment de la ligne.
# ---------------------------------------------------------------------------
import itertools
import math
import random
import time

ZONE_FILL = 0.6   # piece creuse : surface < 60 % de sa boite englobante
ZONE_MIN = 0.04   # ... et boite > 4 % du panneau : ses creux et trous sont des zones de rangement
_CFG = {'zone': True, 'waste': None, 'stack': False, 'adj': 0.0, 'align': 0, 'ortho': False, 'cell': 1.0, 'noflip': False}
HOLE_MIN = 0.01   # trou interieur > 1 % du panneau : rempli en priorite


_HOLES = {}


def _holes(sh):
    """Cellules vides ENFERMEES par la forme (trous, interieur d'un
    anneau) : vides et non reliees au bord de sa boite. Calcule une fois par
    geometrie."""
    key = (sh.w, sh.h, tuple(sh.raw))
    r = _HOLES.get(key)
    if r is not None:
        return r
    w, h, raw = sh.w, sh.h, sh.raw
    full = (1 << w) - 1
    empty = [full & ~v for v in raw]
    edge = 1 | (1 << (w - 1))
    reach = [empty[j] & (full if j in (0, h - 1) else edge) for j in range(h)]
    changed = True
    while changed:
        changed = False
        for order in (range(h), range(h - 1, -1, -1)):
            prev = 0
            for j in order:
                v = reach[j] | prev
                # propage le long de la ligne jusqu'a stabilite
                while True:
                    n = (v | (v << 1) | (v >> 1)) & empty[j]
                    if n == v:
                        break
                    v = n
                if v != reach[j]:
                    reach[j] = v
                    changed = True
                prev = v
    holes = [empty[j] & ~reach[j] for j in range(h)]
    r = (holes, sum(_popcount(v) for v in holes))
    _HOLES[key] = r
    return r
FINE_BIG = 15    # pas (deg) des rotations des grandes pieces courbes
EXTRA_MIN = 4.0  # duree minimale des essais d'amelioration (s), hors mode Optimise
SUB_G = 12   # lignes par paquet de la sous-forme de rejet rapide (find)
WIDE_N = 1   # nombre de segments longs testes avant le calcul complet (find)

MODES = ('rectangulaire', 'imbrique', 'imbrique_trous', 'optimise')
CORNERS = ('bas_gauche', 'bas_droite', 'haut_gauche', 'haut_droite')

DEFAULT_OPTS = {
    'mode': 'imbrique',
    'margin': 10.0,         # marge en bordure de panneau (mm)
    'spacing': 10.0,        # espacement entre pieces (mm)
    'corner': 'bas_gauche',
    'compact': 'x',         # 'x' : chute en bout de panneau ; 'y' : sur la largeur
    'order': 'surface',     # 'surface', 'nom', 'composant'
    'rotations': (0, 90, 180, 270),
    'fill': 'panneau',      # 'panneau' (premier panneau rempli au max) ou 'equilibre'
    'time_limit': 30.0,     # mode optimise (s)
    'step': 1.0,            # pas de la grille (mm)
    'seed': 1,
    'flip': False,          # autoriser a retourner les pieces 'flippable' (miroir y -> -y)
}


# --- Geometrie 2D -------------------------------------------------------------

def ring_area(r):
    a = 0.0
    n = len(r)
    for i in range(n):
        x1, y1 = r[i]
        x2, y2 = r[(i + 1) % n]
        a += x1 * y2 - x2 * y1
    return a / 2.0


def regions_bbox(regions):
    xs = [p[0] for reg in regions for ring in reg for p in ring]
    ys = [p[1] for reg in regions for ring in reg for p in ring]
    return min(xs), min(ys), max(xs), max(ys)


def _mat_mul(a, b):
    return [[sum(a[i][k] * b[k][j] for k in range(3)) for j in range(3)] for i in range(3)]


def _mat_apply(m, x, y):
    return (m[0][0] * x + m[0][1] * y + m[0][2], m[1][0] * x + m[1][1] * y + m[1][2])


def _mat_inv_affine(m):
    a, b, c = m[0]
    d, e, f = m[1]
    det = a * e - b * d
    ia, ib, id_, ie = e / det, -b / det, -d / det, a / det
    return [[ia, ib, -(ia * c + ib * f)], [id_, ie, -(id_ * c + ie * f)], [0.0, 0.0, 1.0]]


def _rot_mat(deg):
    t = math.radians(deg)
    c, s = math.cos(t), math.sin(t)
    if abs(c) < 1e-12:
        c = 0.0
    if abs(s) < 1e-12:
        s = 0.0
    return [[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]]


def frame_matrix(L, W, corner, compact):
    """Matrice affine panneau -> repere canonique (y rempli en premier).
    Symetries pour le coin, puis transposition si l'on tasse vers x."""
    m = [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]]
    if corner in ('bas_droite', 'haut_droite'):
        m = _mat_mul([[-1.0, 0.0, L], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]], m)
    if corner in ('haut_gauche', 'haut_droite'):
        m = _mat_mul([[1.0, 0.0, 0.0], [0.0, -1.0, W], [0.0, 0.0, 1.0]], m)
    if compact == 'x':
        m = _mat_mul([[0.0, 1.0, 0.0], [1.0, 0.0, 0.0], [0.0, 0.0, 1.0]], m)
    return m


def transform_regions(regions, rot_deg, tx, ty, flip=False):
    """Applique la pose d'une piece (retournement eventuel y -> -y, puis
    rotation autour de l'origine locale, puis translation) - meme convention
    que les placements renvoyes par nest()."""
    t = math.radians(rot_deg)
    c, s = math.cos(t), math.sin(t)
    f = -1.0 if flip else 1.0
    return [[[(c * x - s * f * y + tx, s * x + c * f * y + ty) for (x, y) in ring] for ring in reg]
            for reg in regions]


# --- Rasterisation -------------------------------------------------------------

def _bits(a, b):
    return ((1 << (b - a + 1)) - 1) << a


def raster(regions, step, fill_holes=True, as_rect=False):
    """Masque conservateur des regions (deja placees en x, y >= 0).
    Renvoie (w, h, rows) : rows[j] = entier, bit i = cellule (i, j)."""
    x0, y0, x1, y1 = regions_bbox(regions)
    w = max(1, int(math.ceil((x1 - 1e-9) / step)))
    h = max(1, int(math.ceil((y1 - 1e-9) / step)))
    if as_rect:
        full = _bits(0, w - 1)
        return w, h, [full] * h
    rows = [0] * h

    def cell(v, n):
        i = int(math.floor(v / step))
        return 0 if i < 0 else (n - 1 if i >= n else i)

    for reg in regions:
        rings = reg[:1] if fill_holes else reg
        edges = []
        for ring in rings:
            n = len(ring)
            for i in range(n):
                edges.append((ring[i], ring[(i + 1) % n]))
        # 1) interieur : coupe au milieu de chaque rangee (pair-impair).
        # Chaque arete ne visite que les rangees qu'elle traverse (meme test
        # et meme calcul que le balayage de toutes les aretes par rangee).
        cuts = [[] for _ in range(h)]
        for (ax, ay), (bx, by) in edges:
            if ay == by:
                continue
            lo, hi = (ay, by) if ay < by else (by, ay)
            j0 = max(0, int(math.floor(lo / step - 0.5)) - 1)
            j1 = min(h - 1, int(math.ceil(hi / step - 0.5)) + 1)
            for j in range(j0, j1 + 1):
                yc = (j + 0.5) * step
                if (ay <= yc < by) or (by <= yc < ay):
                    cuts[j].append(ax + (yc - ay) * (bx - ax) / (by - ay))
        for j in range(h):
            xs = cuts[j]
            xs.sort()
            row = rows[j]
            for k in range(0, len(xs) - 1, 2):
                row |= _bits(cell(xs[k], w), cell(xs[k + 1], w))
            rows[j] = row
        # 2) bord : toutes les cellules traversees par chaque arete
        for (ax, ay), (bx, by) in edges:
            ja, jb = cell(min(ay, by), h), cell(max(ay, by), h)
            for j in range(ja, jb + 1):
                lo, hi = j * step, (j + 1) * step
                if abs(by - ay) < 1e-12:
                    xa, xb = ax, bx
                else:
                    ta = (max(lo, min(ay, by)) - ay) / (by - ay)
                    tb = (min(hi, max(ay, by)) - ay) / (by - ay)
                    xa = ax + ta * (bx - ax)
                    xb = ax + tb * (bx - ax)
                ca, cb = cell(min(xa, xb), w), cell(max(xa, xb), w)
                rows[j] |= _bits(ca, cb)
    return w, h, rows


def _dil_right(v, n):
    """OU de v >> t pour t dans [0, n-1] (doublement, log2(n) operations)."""
    acc, cover = v, 1
    while cover < n:
        sh = min(cover, n - cover)
        acc |= acc >> sh
        cover += sh
    return acc


_PLANS = {}


def _dil_plan(n):
    """Decalages successifs de _dil_right(v, n) (calcules une fois par n)."""
    plan = _PLANS.get(n)
    if plan is None:
        plan, cover = [], 1
        while cover < n:
            sh = min(cover, n - cover)
            plan.append(sh)
            cover += sh
        plan = _PLANS[n] = tuple(plan)
    return plan


def _dil_left(v, n):
    acc, cover = v, 1
    while cover < n:
        sh = min(cover, n - cover)
        acc |= acc << sh
        cover += sh
    return acc


def dilate(w, h, rows, k, K=None):
    """Grossit le masque d'un disque de rayon k cellules. Le resultat a
    h + 2k lignes et w + 2k colonnes (decalage de k).
    K (espacement en cellules, k = ceil(K)) : grossissement exact. Deux
    cellules pleines decalees de (dx, dy) sont separees d'au moins
    hypot(|dx| - 1, |dy| - 1) cellules ; on couvre juste les decalages ou
    cette distance est < K. L'ecart reel reste >= l'espacement, sans la
    cellule de securite en trop du disque."""
    if k <= 0:
        return w, h, list(rows)
    memo = {}

    def hdil(v, r):
        key = (v, r)
        if key not in memo:
            memo[key] = _dil_left(v << k, 2 * r + 1) >> r
        return memo[key]

    if K is None:
        radius = [int(math.sqrt((k + 0.5) ** 2 - d * d)) for d in range(k + 1)]
    else:
        radius = []
        for d in range(k + 1):
            v = K * K - max(d - 1, 0) ** 2
            # plus grand dx avec dx - 1 < sqrt(v)
            radius.append(min(k, int(math.ceil(1.0 + math.sqrt(v) - 1e-9)) - 1) if v > 0 else 0)
    out = [0] * (h + 2 * k)
    # Par suite de lignes identiques (v sur [i0, i1[) : la dilatation
    # horizontale de rayon r est incluse dans celle de rayon r' >= r, et le
    # rayon decroit avec l'ecart vertical. Une ligne de sortie recoit donc
    # seulement le terme de l'ecart le plus petit : rayon plein dans la
    # suite, rayon radius[t] a t lignes au-dessus / au-dessous. Meme
    # resultat que la double boucle (ligne x ecart), bien moins d'operations.
    n = len(rows)
    i = 0
    while i < n:
        v = rows[i]
        i0 = i
        while i < n and rows[i] == v:
            i += 1
        if not v:
            continue
        full = hdil(v, radius[0])
        for j in range(i0 + k, i + k):
            out[j] |= full
        for t in range(1, k + 1):
            r = hdil(v, radius[t])
            out[i0 + k - t] |= r
            out[i - 1 + k + t] |= r
    return w + 2 * k, h + 2 * k, out


def _runs(v):
    """Segments de bits a 1 : liste de (debut, longueur)."""
    out = []
    i = 0
    while v:
        if v & 1:
            n = (~v & (v + 1)).bit_length() - 1   # nombre de 1 en bas
            v >>= n
            out.append((i, n))
            i += n
        else:
            z = (v & -v).bit_length() - 1
            v >>= z
            i += z
    return out


if hasattr(int, 'bit_count'):
    _popcount = int.bit_count
else:
    def _popcount(v):
        return bin(v).count('1')


def _mirror(rows, w, mx, my):
    """Masque renverse : en x (bits sur la largeur w) et / ou en y (lignes)."""
    out = rows[::-1] if my else list(rows)
    if mx:
        fmt = '0%db' % w
        out = [int(format(v, fmt)[::-1], 2) if v else 0 for v in out]
    return out


def _mirror_of(m, bases):
    """(forme de base, (mx, my)) si la matrice lineaire m est le miroir de
    celle d'une forme deja preparee, sinon None."""
    for b in bases:
        a = b.lin
        for sx in (1.0, -1.0):
            for sy in (1.0, -1.0):
                if (abs(m[0][0] - sx * a[0][0]) < 1e-9 and abs(m[0][1] - sx * a[0][1]) < 1e-9 and
                        abs(m[1][0] - sy * a[1][0]) < 1e-9 and abs(m[1][1] - sy * a[1][1]) < 1e-9):
                    return b, (sx < 0, sy < 0)
    return None


# --- Forme preparee (piece x rotation) ----------------------------------------

class _Shape(object):
    """Piece dans une rotation donnee, dans le repere canonique : masques
    reel et grossi, bandes de lignes identiques, decalage d'origine."""

    def __init__(self, regions, rot, lin, step, k, fill_holes, as_rect, flip=False, intern=None,
                 base=None, mir=(False, False), K=None):
        # lin : partie lineaire du repere canonique ; rot applique ensuite.
        # flip : la piece est d'abord retournee (y -> -y, en local).
        # base, mir : la forme est le miroir (en x et / ou en y) de la forme
        # base deja preparee (rotation de 180 deg, piece retournee...) : ses
        # masques s'obtiennent en renversant ceux de base, sans rasteriser.
        m = _mat_mul(_rot_mat(rot), [[lin[0][0], lin[0][1], 0.0], [lin[1][0], lin[1][1], 0.0], [0, 0, 1.0]])
        if flip:
            m = _mat_mul(m, [[1.0, 0.0, 0.0], [0.0, -1.0, 0.0], [0.0, 0.0, 1.0]])
        self.flip = flip
        self.rot = rot
        self.cum = None
        self.lin = m
        if base is not None:
            mx, my = mir
            w, h = base.w, base.h
            self.w, self.h = w, h
            self.raw = _mirror(base.raw, w, mx, my)
            self.cells = base.cells
            self.off = (-base.off[0] - w * step if mx else base.off[0],
                        -base.off[1] - h * step if my else base.off[1])
        else:
            regs = [[[_mat_apply(m, x, y) for (x, y) in ring] for ring in reg] for reg in regions]
            x0, y0, _, _ = regions_bbox(regs)
            regs = [[[(x - x0, y - y0) for (x, y) in ring] for ring in reg] for reg in regs]
            self.off = (x0, y0)
            self.w, self.h, self.raw = raster(regs, step, fill_holes, as_rect)
            if as_rect:
                _, _, true_raw = raster(regs, step, fill_holes, False)
            else:
                true_raw = self.raw
            self.cells = sum(_popcount(v) for v in true_raw)
        # Formes identiques sur la grille (rotations d'une piece symetrique,
        # pieces identiques...) : une seule geometrie partagee. Le panneau
        # memorise ses recherches par geometrie (hint) : un echec pour une
        # piece vaut pour toutes ses jumelles.
        key = (self.w, self.h, tuple(self.raw))
        twin = intern.get(key) if intern is not None else None
        self._dirv = None
        self.stk = [None]     # decalages d'empilage (voir _stack_offsets), partages entre jumelles
        if twin is not None:
            self.gid = twin.gid
            self.stk = twin.stk
            self.dil, self.bands, self.wide, self.sub = twin.dil, twin.bands, twin.wide, twin.sub
            return
        if intern is not None:
            self.gid = len(intern)
            intern[key] = self
        else:
            self.gid = id(self)
        if base is not None:
            # le disque de l'espacement est symetrique : miroir du masque grossi
            self.dil = _mirror(base.dil, base.w + 2 * k, mx, my)
        else:
            _, _, self.dil = dilate(self.w, self.h, self.raw, k, K)
        bands = []
        j = 0
        n = len(self.dil)
        while j < n:
            v = self.dil[j]
            j0 = j
            while j < n and self.dil[j] == v:
                j += 1
            if v:
                cnt = j - j0
                p = cnt.bit_length() - 1
                runs = _runs(v)
                bands.append((v, j0, cnt, tuple((a, _dil_plan(ln)) for a, ln in runs),
                              p, cnt - (1 << p), sum(ln for _a, ln in runs)))
        # la bande la plus large en premier : c'est elle qui bloque le plus
        # souvent, la boucle de find() s'arrete plus tot (resultat identique)
        bands.sort(key=lambda b: -b[6])
        self.bands = [b[:6] for b in bands]
        # segments les plus longs (lignes j0..j0+cnt-1) : filtre rapide de
        # find(). Un par bande, les WIDE_N plus longs.
        wide = []
        for v, j0, cnt, runs, _p, _o in self.bands:
            ln = max(1 + sum(plan) for _a, plan in runs)
            wide.append((ln, cnt, j0))
        wide.sort(reverse=True)
        self.wide = [(j0, cnt, ln) for ln, cnt, j0 in wide[:WIDE_N]]
        # Sous-forme pour rejeter vite : par paquets de SUB_G lignes, ET des
        # lignes (cellules pleines sur tout le paquet). Une collision de la
        # sous-forme est une collision de la forme : si elle interdit deja
        # tous les x, inutile de tester la forme exacte a ce y. Seulement
        # pour les formes a beaucoup de bandes (pieces courbes).
        sub = []
        if len(self.bands) > 2 * SUB_G:
            n = len(self.dil)
            for g0 in range(0, n, SUB_G):
                g1 = min(n, g0 + SUB_G)
                v = -1
                for r in self.dil[g0:g1]:
                    v &= r
                if v > 0:
                    cnt = g1 - g0
                    p = cnt.bit_length() - 1
                    runs = _runs(v)
                    sub.append((v, g0, cnt, tuple((a, _dil_plan(ln)) for a, ln in runs),
                                p, cnt - (1 << p), sum(ln for _a, ln in runs)))
            sub.sort(key=lambda b: -b[6])
        self.sub = [b[:6] for b in sub]


def _dirv(sh):
    """Direction (unitaire) du centre de la boite vers le centre de la
    matiere : une piece creuse (J, U, arc...) s'ouvre du cote oppose."""
    d = sh._dirv
    if d is None:
        n = sx = sy = 0
        for j, v in enumerate(sh.raw):
            for a, ln in _runs(v):
                n += ln
                sx += ln * (2 * a + ln)
                sy += ln * (2 * j + 1)
        dx = sx / (2.0 * n) - sh.w / 2.0 if n else 0.0
        dy = sy / (2.0 * n) - sh.h / 2.0 if n else 0.0
        m = math.hypot(dx, dy)
        d = sh._dirv = (dx / m, dy / m) if m > 1e-9 else (0.0, 0.0)
    return d


def _aligned(sheet, t, shapes):
    """Grande piece creuse posee sur un panneau qui en porte deja une :
    orientations ouvertes du meme cote que la premiere (elles s'emboitent
    alors les unes dans les autres au lieu de se croiser). None si la regle
    ne s'applique pas."""
    lead = None
    for it in sheet.items:
        if it and it['t'].get('hollow'):
            lead = it['sh']
            break
    if lead is None:
        return None
    lx, ly = _dirv(lead)
    sc = []
    seen = set()
    for sh in shapes:
        if sh.gid in seen:
            continue
        seen.add(sh.gid)
        dx, dy = _dirv(sh)
        sc.append((-(dx * lx + dy * ly), len(sc), sh))
    sc.sort()
    return [c[2] for c in sc[:_CFG['align']]]


# --- Panneau -------------------------------------------------------------------

class _Sheet(object):
    def __init__(self, Wu, Hu, k):
        self.Wu, self.Hu, self.k = Wu, Hu, k
        self.occ = [0] * (Hu + 2 * k)
        self.items = []
        self.cells = 0
        self._table = None
        # y de depart par forme : le panneau ne fait que se remplir, donc une
        # position refusee le reste. On reprend la recherche au dernier y
        # trouve (None = la forme n'y rentre plus). Resultat identique.
        self.hint = {}
        self._runs_ok = {}
        self._ok = {}
        self.zones = []
        self.holes = []
        self._zs = [None, None]
        self._sfx = None
        self._bord = None
        self.ytop = 0

    def sfx(self):
        """sfx[r] : OU des lignes r et suivantes (colonnes occupees a partir
        de la ligne r) : profil du haut des pieces posees."""
        if self._sfx is None:
            out = [0] * (len(self.occ) + 1)
            acc = 0
            occ = self.occ
            for r in range(len(occ) - 1, -1, -1):
                acc |= occ[r]
                out[r] = acc
            self._sfx = out
        return self._sfx

    def waste(self, sh, x, y):
        """Cellules perdues si la forme est posee en (x, y) : surface
        ajoutee sous le profil du haut des pieces (creux enfermes sous la
        piece compris) moins la surface de la piece."""
        sfx = self.sfx()
        k = self.k
        cum = sh.cum
        if cum is None:
            cum = [0] * sh.h
            acc = 0
            for j in range(sh.h - 1, -1, -1):
                acc |= sh.raw[j]
                cum[j] = acc
            sh.cum = cum
        shift = x + k
        r = y + k
        inc = 0
        pc = _popcount
        for j in range(sh.h):
            v = (cum[j] << shift) & ~sfx[r + j]
            if v:
                inc += pc(v)
        s = cum[0] << shift
        r -= 1
        while r >= k:
            v = s & ~sfx[r]
            if not v:
                break
            inc += pc(v)
            r -= 1
        return inc - sh.cells

    def contact(self, sh, x, y):
        """Cellules de la couronne d'espacement de la forme posee en (x, y)
        deja occupees ou hors panneau : mesure de ce que la piece touche
        (pieces voisines, bords)."""
        bd = self._bord
        if bd is None:
            k = self.k
            inner = ((1 << self.Wu) - 1) << k
            full = (1 << (self.Wu + 2 * k)) - 1
            edge = full & ~inner
            bd = self._bord = [full] * k + [edge] * self.Hu + [full] * k
        occ = self.occ
        n = 0
        pc = _popcount
        for j, d in enumerate(sh.dil):
            v = (d << x) & (occ[y + j] | bd[y + j])
            if v:
                n += pc(v)
        return n

    def table(self):
        if self._table is None:
            t = [self.occ]
            p = 1
            n = len(self.occ)
            while (1 << p) <= n:
                prev = t[-1]
                half = 1 << (p - 1)
                t.append([prev[i] | prev[i + half] for i in range(n - (1 << p) + 1)])
                p += 1
            self._table = t
        return self._table

    def range_or(self, lo, hi):
        t = self.table()
        n = hi - lo + 1
        p = n.bit_length() - 1
        return t[p][lo] | t[p][hi - (1 << p) + 1]

    def last_bad(self, ln):
        """last_bad[r] : derniere ligne <= r du panneau sans aucun segment
        libre de ln cellules (-1 si aucune). Une forme dont un segment fait
        ln cellules ne peut couvrir aucune de ces lignes."""
        lb = self._runs_ok.get(ln)
        if lb is None:
            oks = self._ok.get(ln)
            if oks is None:
                # (les lignes modifiees ensuite sont remises a jour par place)
                full = (1 << (self.Wu + 2 * self.k)) - 1
                plan = _dil_plan(ln)
                memo = {}
                oks = []
                for o in self.occ:
                    ok = memo.get(o)
                    if ok is None:
                        e = ~o & full
                        for d in plan:
                            e &= e >> d
                        ok = memo[o] = bool(e)
                    oks.append(ok)
                self._ok[ln] = oks
            lb = []
            last = -1
            r = 0
            for ok in oks:
                if not ok:
                    last = r
                lb.append(last)
                r += 1
            self._runs_ok[ln] = lb
        return lb

    def find(self, sh, y_max=None):
        """Premiere position (y le plus bas, puis x le plus a gauche) ou la
        forme rentre. None si elle ne rentre pas (ou pas avec y <= y_max)."""
        if sh.w > self.Wu or sh.h > self.Hu:
            return None
        y_start = self.hint.get(sh.gid, 0)
        if y_start is None:
            return None
        y_end = self.Hu - sh.h
        limited = y_max is not None and y_max < y_end
        if limited:
            y_end = y_max
        xmask = (1 << (self.Wu - sh.w + 1)) - 1
        table = self.table()
        bands = [(bi, j0, table[p], off, runs) for bi, (v, j0, cnt, runs, p, off) in enumerate(sh.bands)]
        last_s = [None] * len(bands)   # d'un y au suivant, s change rarement
        last_f = [0] * len(bands)
        filt = [(j0, j0 + cnt - 1, self.last_bad(ln)) for j0, cnt, ln in sh.wide]
        subs = [(j0, table[p], off, runs) for (v, j0, cnt, runs, p, off) in sh.sub]
        nsub = len(subs)
        sub_s = [None] * nsub
        sub_f = [0] * nsub
        y = y_start - 1
        while y < y_end:
            y += 1
            skip = False
            for wj0, wj1, lb in filt:
                b = lb[y + wj1]
                if b >= y + wj0:
                    # une ligne de la fenetre n'a pas la place : saute apres elle
                    y = b - wj0
                    skip = True
                    break
            if skip:
                continue
            forb = 0
            if nsub:
                for bi in range(nsub):
                    j0, tp, off, runs = subs[bi]
                    i = y + j0
                    s = tp[i] | tp[i + off]
                    if not s:
                        continue
                    if s == sub_s[bi]:
                        f = sub_f[bi]
                    else:
                        f = 0
                        for a, plan in runs:
                            acc = s
                            for d in plan:
                                acc |= acc >> d
                            f |= acc >> a
                        sub_s[bi] = s
                        sub_f[bi] = f
                    forb |= f
                    if forb & xmask == xmask:
                        break
                if forb & xmask == xmask:
                    continue
            for bi, j0, tp, off, runs in bands:
                i = y + j0
                s = tp[i] | tp[i + off]
                if not s:
                    continue
                if s == last_s[bi]:
                    forb |= last_f[bi]
                    if forb & xmask == xmask:
                        break
                    continue
                # (pas de memo par valeur de s : mesure sur un vrai
                # calpinage, presque jamais de doublon, le dict coutait)
                f = 0
                for a, plan in runs:
                    acc = s
                    for d in plan:
                        acc |= acc >> d
                    f |= acc >> a
                last_s[bi] = s
                last_f[bi] = f
                forb |= f
                if forb & xmask == xmask:
                    break
            allowed = xmask & ~forb
            if allowed:
                self.hint[sh.gid] = y
                return (allowed & -allowed).bit_length() - 1, y
        if not limited:
            self.hint[sh.gid] = None
        elif y_end + 1 > y_start:
            self.hint[sh.gid] = y_end + 1
        return None

    def place(self, sh, x, y, item):
        k = self.k
        for j, v in enumerate(sh.raw):
            if v:
                self.occ[y + k + j] |= v << (x + k)
        self.cells += sh.cells
        self.items.append(item)
        if y + sh.h > self.ytop:
            self.ytop = y + sh.h
        self._sfx = None
        self._table = None
        self._runs_ok = {}
        if self._ok:
            full = (1 << (self.Wu + 2 * k)) - 1
            occ = self.occ
            for ln, oks in self._ok.items():
                plan = _dil_plan(ln)
                for r in range(y + k, y + k + sh.h):
                    if oks[r]:
                        e = ~occ[r] & full
                        for d in plan:
                            e &= e >> d
                        if not e:
                            oks[r] = False
        # zones de rangement : boites des pieces creuses (creux, trous)
        new = False
        if _CFG['zone'] and sh.w * sh.h >= ZONE_MIN * self.Wu * self.Hu:
            hl, nh = _holes(sh)
            if nh >= HOLE_MIN * self.Wu * self.Hu:
                # 1) interieur des anneaux et trous : rempli en premier
                self.holes.append((x, y, hl))
                new = True
            if sh.cells < ZONE_FILL * sh.w * sh.h:
                # 2) boite des pieces creuses (creux ouverts)
                self.zones.append((x, y, sh.w, sh.h))
                new = True
        if new:
            self._zs = [None, None]
        else:
            for z in self._zs:
                if z is not None:
                    z.place(sh, x, y, None)

    def zone_sheet(self, level=1):
        """Panneau temporaire ou tout ce qui est hors des boites des pieces
        creuses est marque occupe : une piece qui y rentre se loge dans un
        creux ou un trou d'une grande piece. None s'il n'y a pas de zone."""
        if not (self.holes if level == 0 else self.zones):
            return None
        if self._zs[level] is None:
            k = self.k
            n = len(self.occ)
            full = (1 << (self.Wu + 2 * k)) - 1
            inside = [0] * n
            if level == 0:
                for x, y, hl in self.holes:
                    for j, v in enumerate(hl):
                        if v:
                            inside[y + k + j] |= v << (x + k)
            else:
                for x, y, w, h in self.zones:
                    bits = ((1 << (w + 2 * k)) - 1) << x      # + marge k de chaque cote
                    for j in range(y, y + h + 2 * k):
                        inside[j] |= bits
            zs = _Sheet(self.Wu, self.Hu, k)
            zs.occ = [self.occ[j] | (full & ~inside[j]) for j in range(n)]
            self._zs[level] = zs
        return self._zs[level]

    def top(self):
        return max([it['_y'] + it['_h'] for it in self.items] or [0])


# --- Nesting -------------------------------------------------------------------

CURVED_FILL = 0.5   # surface / surface du rectangle englobant sous ce seuil : piece courbe


def _fill_ratio(p):
    if '_fill' in p:
        return p['_fill']
    x0, y0, x1, y1 = regions_bbox(p['regions'])
    bb = (x1 - x0) * (y1 - y0)
    if bb <= 0:
        return 1.0
    a = 0.0
    for reg in p['regions']:
        a += abs(ring_area(reg[0])) - sum(abs(ring_area(h)) for h in reg[1:])
    return a / bb


def _prepare(parts, opts):
    insts = []
    for p in parts:
        q = max(1, int(p.get('qty', 1) or 1))
        x0, y0, x1, y1 = regions_bbox(p['regions'])
        bbox_area = (x1 - x0) * (y1 - y0)
        bbox_long = max(x1 - x0, y1 - y0)
        for i in range(q):
            insts.append({'id': p['id'], 'name': p.get('name', p['id']), 'comp': p.get('comp', ''),
                          'inst': i, 'bbox_area': bbox_area, 'bbox_long': bbox_long,
                          'area': bbox_area * _fill_ratio(p), 'fillr': _fill_ratio(p)})
    return insts


def _order(insts, how):
    if how == 'nom':
        return sorted(insts, key=lambda t: (t['name'], t['inst']))
    if how == 'composant':
        tot = {}
        for t in insts:
            tot[t['comp']] = tot.get(t['comp'], 0) + t['bbox_area']
        return sorted(insts, key=lambda t: (-tot[t['comp']], t['comp'], -t['bbox_area'], t['name']))
    if how == 'aire':        # surface reelle (les pieces creuses passent apres les pleines)
        return sorted(insts, key=lambda t: (-t['area'], t['name'], t['inst']))
    if how == 'long':        # plus grande longueur d'abord
        return sorted(insts, key=lambda t: (-t['bbox_long'], -t['bbox_area'], t['name'], t['inst']))
    if how == 'pleines':     # pieces pleines d'abord (par surface), puis les creuses
        return sorted(insts, key=lambda t: (t['fillr'] < CURVED_FILL, -t['bbox_area'], t['name'], t['inst']))
    if how == 'creuses':     # pieces creuses d'abord, puis les pleines par surface reelle
        return sorted(insts, key=lambda t: (t['fillr'] >= CURVED_FILL, -t['bbox_area'], t['name'], t['inst']))
    return sorted(insts, key=lambda t: (-t['bbox_area'], t['name'], t['inst']))


def _fits(sheet, sh, x, y):
    if x < 0 or y < 0 or x + sh.w > sheet.Wu or y + sh.h > sheet.Hu:
        return False
    occ = sheet.occ
    for j, d in enumerate(sh.dil):
        if d and occ[y + j] & (d << x):
            return False
    return True


def _pin(sheet, insts, shapes_for, axis):
    """Pose les pieces insts contre le bord oppose au depart du placement
    (axis 'y' : en haut du repere, par rangees ; 'x' : a droite, par
    colonnes), a plat le long de ce bord. Les autres pieces viendront ensuite
    depuis le depart : une longue piece ne coupe plus le panneau en deux.
    Renvoie False si une piece ne trouve pas sa place."""
    k, Wu, Hu = sheet.k, sheet.Wu, sheet.Hu
    a, b, rb = 0, (Hu if axis == 'y' else Wu), 0   # avance le long du bord, bord courant, epaisseur
    for t in insts:
        shapes = [sh for sh in shapes_for(t['id']) if sh.w <= Wu and sh.h <= Hu]
        if not shapes:
            return False
        if axis == 'y':
            sh = min(shapes, key=lambda s: (s.h, s.flip))
            ln, th = sh.w, sh.h
            lim = Wu
        else:
            sh = min(shapes, key=lambda s: (s.w, s.flip))
            ln, th = sh.h, sh.w
            lim = Hu
        if a and a + ln > lim:
            a, b, rb = 0, b - rb - k, 0
        x, y = (a, b - th) if axis == 'y' else (b - th, a)
        if not _fits(sheet, sh, x, y):
            return False
        sheet.place(sh, x, y, {'t': t, 'sh': sh, '_x': x, '_y': y, '_h': sh.h})
        a, rb = a + ln + k, max(rb, th)
    return True


BIG_FRAC = 0.12   # piece "grande" : boite englobante > 12 % du panneau
LOOK_N = 3        # grandes pieces suivantes essayees sur un panneau neuf


def _lookahead(best, shapes, insts, ti, rot_order, shapes_for, Wu, Hu, k):
    """Grande piece posee sur un panneau NEUF : son orientation decide si les
    grandes pieces suivantes pourront s'y emboiter (deux grandes formes
    libres tete-beche...). Le glouton prend l'orientation la plus basse ;
    ici on essaie chaque orientation et on garde celle qui laisse entrer le
    plus de grandes pieces suivantes sur ce panneau (a egalite, la plus
    basse, comme avant)."""
    cands = []
    seen = set()
    empty = _Sheet(Wu, Hu, k)
    for sh in shapes:
        if sh.gid in seen:
            continue
        seen.add(sh.gid)
        pos = empty.find(sh)
        if pos is not None:
            cands.append(((pos[1] + sh.h, pos[0], sh.h), sh, pos[0], pos[1]))
    if len(cands) < 2:
        return best
    nxt = []
    for t in insts[ti + 1:]:
        shs = shapes_for(t['id'])
        r = rot_order.get((t['id'], t['inst']))
        if r is not None:
            shs = [shs[i] for i in r]
        if shs and min(s.w * s.h for s in shs) >= BIG_FRAC * Wu * Hu:
            nxt.append(shs)
            if len(nxt) >= LOOK_N:
                break
    if not nxt:
        return best
    scored = []
    for key, sh, x, y in cands:
        tmp = _Sheet(Wu, Hu, k)
        tmp.place(sh, x, y, None)
        n_in = 0
        for shs in nxt:
            b2 = None
            seen = set()
            for s2 in shs:
                if s2.gid in seen:
                    continue
                seen.add(s2.gid)
                pos = tmp.find(s2, None if b2 is None else b2[0] - s2.h)
                if pos is not None and (b2 is None or pos[1] + s2.h < b2[0]):
                    b2 = (pos[1] + s2.h, s2, pos[0], pos[1])
            if b2 is None:
                continue
            tmp.place(b2[1], b2[2], b2[3], None)
            n_in += 1
        scored.append(((-n_in, key), (key, sh, x, y)))
    scored.sort(key=lambda c: c[0])
    return scored[0][1]


def _choose(sheet, shapes, zs=None):
    """Meilleure pose d'une piece sur un panneau parmi ses orientations.
    zs : panneau des zones (recherche limitee aux creux / trous).
    Renvoie (cle, forme, x, y) ou None."""
    best = None
    seen = set()
    alpha = _CFG['waste']
    fs = zs if zs is not None else sheet
    if alpha is None:
        for sh in shapes:
            # doublon d'une forme deja essayee : meme position, meme cle
            if sh.gid in seen:
                continue
            seen.add(sh.gid)
            # une position n'est meilleure que si y + h <= meilleur y + h
            pos = fs.find(sh, None if best is None else best[0][0] - sh.h)
            if pos is None:
                continue
            key = (pos[1] + sh.h, pos[0], sh.h)
            if best is None or key < best[0]:
                best = (key, sh, pos[0], pos[1])
        return best
    ytop = sheet.ytop
    wu = sheet.Wu
    beta = _CFG['adj']
    for sh in shapes:
        if sh.gid in seen:
            continue
        seen.add(sh.gid)
        if best is None or beta:
            pos = fs.find(sh)
        else:
            # la perte vaut au moins -surface de la piece : au-dela de ce y,
            # la longueur entamee coute deja plus que la meilleure pose
            ym = int(ytop - sh.h + (best[0][0] + sh.cells) / (alpha * wu)) if alpha > 0 else None
            if ym is not None and ym < 0:
                continue
            pos = fs.find(sh, ym)
        if pos is None:
            continue
        x, y = pos
        top = y + sh.h
        cost = sheet.waste(sh, x, y) + alpha * wu * max(0, top - ytop)
        if beta:
            cost -= beta * sheet.contact(sh, x, y)
        key = (cost, top, x, sh.h)
        if best is None or key < best[0]:
            best = (key, sh, x, y)
    return best


STACK_FILL = 0.6    # piece empilable : surface < 60 % de sa boite (arc, S, U, L...)
STACK_ROWS = 160    # lignes examinees pour chercher les decalages d'empilage
STACK_N = 10        # decalages gardes par forme


def _stack_offsets(sh, k):
    """Decalages (dx, dy) qui posent une copie de la forme au plus pres
    d'elle-meme, dans la meme orientation (pieces courbes identiques
    empilees comme des cuilleres). Classes par surface consommee par copie :
    longueur du decalage x largeur de la forme perpendiculairement."""
    if sh.stk[0] is not None:
        return sh.stk[0]
    w, h = sh.w, sh.h
    tmp = _Sheet(3 * w, 3 * h, k)
    for j, v in enumerate(sh.raw):
        if v:
            tmp.occ[h + k + j] |= v << (w + k)
    table = tmp.table()
    xmask = (1 << (2 * w + 1)) - 1
    # largeur de la forme vue dans chaque direction (pas de 3 deg)
    pts = []
    for j, v in enumerate(sh.raw):
        if v:
            pts.append(((v & -v).bit_length() - 1, j))
            pts.append((v.bit_length(), j + 1))
    perp = []
    for a in range(0, 180, 3):
        c, sn = math.cos(math.radians(a)), math.sin(math.radians(a))
        pr = [-sn * x + c * y for x, y in pts]
        perp.append(max(pr) - min(pr))
    stride = max(1, h // STACK_ROWS)
    cands = []
    for dy in range(0, h + 1, stride):
        y = h + dy
        forb = 0
        for (v, j0, cnt, runs, p, off) in sh.bands:
            tp = table[p]
            i = y + j0
            sv = tp[i] | tp[i + off]
            if not sv:
                continue
            for a, plan in runs:
                acc = sv
                for d in plan:
                    acc |= acc >> d
                forb |= acc >> a
            if forb & xmask == xmask:
                break
        allowed = xmask & ~forb
        for a, ln in _runs(allowed):
            for x in ((a, a + ln - 1) if ln > 1 else (a,)):
                dx = x - w
                if dy == 0 and dx <= 0:
                    continue
                d = math.hypot(dx, dy)
                ang = math.degrees(math.atan2(dy, dx)) % 180.0
                cost = d * perp[int(ang / 3.0 + 0.5) % 60]
                cands.append((cost, ang, dx, dy))
    cands.sort()
    out = []
    for cost, ang, dx, dy in cands:
        if all(min(abs(ang - a2), 180.0 - abs(ang - a2)) > 6.0 for _c, a2, _x, _y in out):
            out.append((cost, ang, dx, dy))
            if len(out) >= STACK_N:
                break
    res = [(dx, dy) for _c, _a, dx, dy in out]
    sh.stk[0] = res
    return res


def _stack(sheet, t, shapes):
    """Piece courbe dont une jumelle (meme geometrie) est deja sur le
    panneau : pose contre elle, meme orientation, au decalage d'empilage le
    plus serre qui rentre. Renvoie (forme, x, y) ou None."""
    fam = t.get('fam')
    if fam is None:
        return None
    for it in reversed(sheet.items):
        if not it or it['t'].get('fam') != fam:
            continue
        g = it['sh'].gid
        sh = None
        for s2 in shapes:
            if s2.gid == g:
                sh = s2
                break
        if sh is None or sh.cells >= STACK_FILL * sh.w * sh.h:
            continue
        x0, y0 = it['_x'], it['_y']
        for dx, dy in _stack_offsets(sh, sheet.k):
            for sg in (1, -1):
                x, y = x0 + sg * dx, y0 + sg * dy
                if _fits(sheet, sh, x, y):
                    return sh, x, y
    return None


def _snap(sheets, unplaced):
    return ([(list(sh.occ), list(sh.items), sh.cells, dict(sh.hint), list(sh.zones), list(sh.holes)) for sh in sheets], list(unplaced))


def _unsnap(state, Wu, Hu, k):
    sheets = []
    for occ, items, cells, hint, zones, holes in state[0]:
        sh = _Sheet(Wu, Hu, k)
        sh.occ, sh.items, sh.cells, sh.hint = list(occ), list(items), cells, dict(hint)
        sh.ytop = max([it['_y'] + it['_h'] for it in items if it] or [0])
        sh.zones = list(zones)
        sh.holes = list(holes)
        sheets.append(sh)
    return sheets, list(state[1])


def _run(insts, rot_order, shapes_for, Wu, Hu, k, fill, n_balanced=0, deadline=None, tick=None, pin=None,
         memos=None, snap_out=None, lookahead=False, forced_out=None):
    """Une passe de placement. Renvoie (sheets, unplaced). tick() est appele
    a chaque piece (fenetre de chargement de Fusion). pin : pieces posees
    d'abord en haut du 1er panneau (voir _pin).
    memos / snap_out (recherche locale) : etats du panneau memorises apres
    chaque piece d'une passe precedente. Une passe qui commence par les
    memes pieces (memes rotations permises) reprend a la premiere
    difference au lieu de tout reposer : meme resultat, bien plus vite."""
    keys = None
    start = 0
    if snap_out is not None or memos:
        psig = (pin[0], tuple((t['id'], t['inst']) for t in pin[1])) if pin else None
        keys = []
        for t in insts:
            r = rot_order.get((t['id'], t['inst']))
            keys.append((t['id'], t['inst'], tuple(r) if r is not None else None))
    best_m, best_c = None, -1
    for mm in (memos or ()):
        if mm is None or mm['psig'] != psig:
            continue
        mk = mm['keys']
        c, n = 0, min(len(mk), len(keys))
        while c < n and mk[c] == keys[c]:
            c += 1
        if c > best_c:
            best_m, best_c = mm, c
    snaps = None
    if best_m is not None and best_c >= 1:
        start = best_c
        sheets, unplaced = _unsnap(best_m['snaps'][start], Wu, Hu, k)
        snaps = best_m['snaps'][:start + 1]
    else:
        sheets = [_Sheet(Wu, Hu, k) for _ in range(n_balanced)]
        unplaced = []
        if pin:
            if not sheets:
                sheets.append(_Sheet(Wu, Hu, k))
            if not _pin(sheets[0], pin[1], shapes_for, pin[0]):
                return [], [{'id': t['id']} for t in insts]
        if keys is not None:
            snaps = [_snap(sheets, unplaced)]
    for ti in range(start, len(insts)):
        t = insts[ti]
        if deadline is not None and time.time() > deadline:
            return None, None
        if tick:
            tick()
        shapes = shapes_for(t['id'])
        rots = rot_order.get((t['id'], t['inst']))
        if rots is not None:
            shapes = [shapes[i] for i in rots]
        if fill == 'equilibre':
            order = sorted(range(len(sheets)), key=lambda i: sheets[i].cells)
        else:
            order = range(len(sheets))
        if _CFG['noflip'] and rots is None:
            nf = [sh for sh in shapes if not sh.flip]
            if nf:
                shapes = nf
        done = False
        if _CFG['ortho'] or _CFG['align']:
            if 'hollow' not in t:
                t['hollow'] = (t['fillr'] < CURVED_FILL and t['bbox_area'] >= ZONE_MIN * Wu * Hu * _CFG['cell'])
            if _CFG['ortho'] and t['hollow'] and rots is None:
                # grandes pieces creuses : angles droits seulement (posees en
                # biais, elles coupent le panneau et gachent leur interieur)
                sq = [sh for sh in shapes if sh.rot % 90 == 0]
                if sq:
                    shapes = sq
        if _CFG['stack']:
            if 'fam' not in t:
                t['fam'] = tuple(sh.gid for sh in shapes_for(t['id']))
            for si in order:
                st = _stack(sheets[si], t, shapes)
                if st is not None:
                    sh, x, y = st
                    sheets[si].place(sh, x, y, {'t': t, 'sh': sh, '_x': x, '_y': y, '_h': sh.h})
                    done = True
                    break
        if _CFG['align'] and not done:
            if t['hollow']:
                for si in order:
                    al = _aligned(sheets[si], t, shapes)
                    if not al:
                        continue
                    best = _choose(sheets[si], al)
                    if best is not None:
                        _, sh, x, y = best
                        sheets[si].place(sh, x, y, {'t': t, 'sh': sh, '_x': x, '_y': y, '_h': sh.h})
                        done = True
                        break
        if _CFG['zone'] and not done:
            # 1) creux et trous des grandes pieces d'abord : les chutes du
            # reste du panneau restent d'un seul tenant
            for si, lv in [(si, lv) for lv in (0, 1) for si in order]:
                zs = sheets[si].zone_sheet(lv)
                if zs is None:
                    continue
                best = _choose(sheets[si], shapes, zs)
                if best is not None:
                    _, sh, x, y = best
                    sheets[si].place(sh, x, y, {'t': t, 'sh': sh, '_x': x, '_y': y, '_h': sh.h})
                    done = True
                    break
        for si in ([] if done else order):
            best = _choose(sheets[si], shapes)
            if best is not None:
                _, sh, x, y = best
                sheets[si].place(sh, x, y, {'t': t, 'sh': sh, '_x': x, '_y': y, '_h': sh.h})
                done = True
                break
        if not done:
            sheet = _Sheet(Wu, Hu, k)
            best = _choose(sheet, shapes)
            if best is not None and lookahead and best[1].w * best[1].h >= BIG_FRAC * Wu * Hu:
                best = _lookahead(best, shapes, insts, ti, rot_order, shapes_for, Wu, Hu, k)
                if forced_out is not None:
                    # orientation retenue, imposee aux passes suivantes
                    forced_out[(t['id'], t['inst'])] = [shapes_for(t['id']).index(best[1])]
            if best is None:
                unplaced.append({'id': t['id'], 'name': t['name'], 'inst': t['inst'],
                                 'reason': 'trop grande pour le panneau'})
            else:
                _, sh, x, y = best
                sheet.place(sh, x, y, {'t': t, 'sh': sh, '_x': x, '_y': y, '_h': sh.h})
                sheets.append(sheet)
        if snaps is not None:
            snaps.append(_snap(sheets, unplaced))
    if snap_out is not None and snaps is not None:
        snap_out.append({'psig': psig, 'keys': keys, 'snaps': snaps})
    return [s for s in sheets if s.items], unplaced


def _reduce(best, base, shapes_for, Wu, Hu, k, deadline, tick=None):
    """Essaie d'economiser des panneaux en changeant l'ordre de placement.
    Renvoie (best, nombre de passes, (pin, ordre, rotations) du meilleur
    ou None)."""
    n_runs = 0
    cfg = None
    pos = {(t['id'], t['inst']): i for i, t in enumerate(base)}
    by_long = sorted(base, key=lambda t: (-t['bbox_long'], pos[(t['id'], t['inst'])]))
    tried = set()
    while True:
        _sc, sheets, unplaced = best
        n = len(sheets)
        if n < 2 or unplaced or time.time() > deadline:
            break
        # borne : la surface reelle des pieces doit tenir dans n - 1 panneaux
        if sum(sh.cells for sh in sheets) > 0.95 * (n - 1) * Wu * Hu:
            break
        # pieces des derniers panneaux (les moins remplis) : a placer plus tot
        light = sorted(range(n), key=lambda i: sheets[i].cells)[:max(1, n // 3)]
        late = set()
        for i in light:
            late.update((it['t']['id'], it['t']['inst']) for it in sheets[i].items)
        lastk = set((it['t']['id'], it['t']['inst']) for it in sheets[-1].items)
        cands = []
        for keys in (lastk, late):
            first = [t for t in by_long if (t['id'], t['inst']) in keys]
            rest = [t for t in base if (t['id'], t['inst']) not in keys]
            # posees contre le bord oppose du 1er panneau, le reste dans
            # l'ordre habituel
            cands.append((('x', first), rest))
            cands.append((('y', first), rest))
            # posees en premier, par le bas
            cands.append(([], first + rest))
        cands.append(([], by_long))
        improved = False
        for pin, order in cands:
            sig = ((pin[0], tuple((t['id'], t['inst']) for t in pin[1])) if pin else None,
                   tuple((t['id'], t['inst']) for t in order))
            if sig in tried:
                continue
            tried.add(sig)
            s2, u2 = _run(order, {}, shapes_for, Wu, Hu, k, 'panneau', deadline=deadline, tick=tick, pin=pin)
            n_runs += 1
            sc = _score(s2, u2)
            if sc is None:
                return best, n_runs, cfg
            # les pieces restees sur le dernier panneau passent devant, et on
            # recommence (quelques fois) : elles prennent la place d'autres
            # pieces plus faciles a caser
            for _rep in range(3):
                if u2 or len(s2) < n or sc[:2] < best[0][:2]:
                    break
                lk = set((it['t']['id'], it['t']['inst']) for it in s2[-1].items)
                order = [t for t in order if (t['id'], t['inst']) in lk] + \
                        [t for t in order if (t['id'], t['inst']) not in lk]
                s2, u2 = _run(order, {}, shapes_for, Wu, Hu, k, 'panneau', deadline=deadline, tick=tick, pin=pin)
                n_runs += 1
                sc = _score(s2, u2)
                if sc is None:
                    return best, n_runs, cfg
            if sc[:2] < best[0][:2]:
                best = (sc, s2, u2)
                cfg = (pin, order, {})
                improved = True
                break
        if not improved:
            # ordres voisins tires au hasard (graine fixe : resultat stable)
            rnd = random.Random(len(base) * 7919 + n)
            pins = [c for c in cands if c[0]]
            while not improved and time.time() < deadline:
                pin, order = pins[n_runs % len(pins)] if pins else cands[0]
                order = list(order)
                for _ in range(rnd.randint(1, max(1, len(order) // 3))):
                    i = rnd.randrange(len(order))
                    j = min(len(order) - 1, max(0, i + rnd.randint(-3, 3)))
                    order[i], order[j] = order[j], order[i]
                rot_order = {}
                for t in order:
                    if rnd.random() < 0.3:
                        idx = list(range(len(shapes_for(t['id']))))
                        rnd.shuffle(idx)
                        rot_order[(t['id'], t['inst'])] = idx[:max(1, len(idx) // 2)]
                s2, u2 = _run(order, rot_order, shapes_for, Wu, Hu, k, 'panneau', deadline=deadline, tick=tick, pin=pin)
                n_runs += 1
                sc = _score(s2, u2)
                if sc is None:
                    return best, n_runs, cfg
                if sc[:2] < best[0][:2]:
                    best = (sc, s2, u2)
                    cfg = (pin, order, rot_order)
                    improved = True
        if not improved:
            break
    return best, n_runs, cfg


def _explore(best, base, shapes_for, Wu, Hu, k, deadline, tick=None, n_big=4, cfg=None):
    """Essaie d'autres ordres puis chaque orientation des n_big plus
    grandes pieces (descente coordonnee). cfg : (pin, ordre, rotations) de depart, sinon l'ordre de
    base. Renvoie (best, nombre de passes)."""
    n_runs = 0
    pin, order, forced = cfg if cfg else (None, base, {})
    forced = dict(forced)
    found = None   # (pin, ordre, rotations) du meilleur trouve ici
    pinned = set((t['id'], t['inst']) for t in pin[1]) if pin else set()
    big = sorted([t for t in order if (t['id'], t['inst']) not in pinned],
                 key=lambda t: -t['bbox_area'])[:n_big]
    # 1) ordre des grandes pieces : laquelle poser en premier, en deuxieme...
    # (une petite arche peut se loger dans le creux d'une grande, au lieu
    # d'aller au bout du panneau)
    idx = [i for i, t in enumerate(order) if t in big]
    for p in range(len(idx) - 1):
        cur = order
        for q in range(p + 1, len(idx)):
            if time.time() > deadline:
                return best, n_runs, found
            o2 = list(cur)
            t = o2.pop(idx[q])
            o2.insert(idx[p], t)
            s2, u2 = _run(o2, forced, shapes_for, Wu, Hu, k, 'panneau', deadline=deadline, tick=tick, pin=pin)
            n_runs += 1
            sc = _score(s2, u2)
            if sc is None:
                return best, n_runs, found
            if sc < best[0]:
                best = (sc, s2, u2)
                order = o2
                found = (pin, list(order), dict(forced))
        idx = [i for i, t in enumerate(order) if t in big]
    big = [t for t in order if t in big]
    # 2) orientation de chaque grande piece
    for t in big:
        key = (t['id'], t['inst'])
        chosen = None
        for i in range(len(shapes_for(t['id']))):
            if time.time() > deadline:
                return best, n_runs, found
            ro = dict(forced)
            ro[key] = [i]
            s2, u2 = _run(order, ro, shapes_for, Wu, Hu, k, 'panneau', deadline=deadline, tick=tick, pin=pin)
            n_runs += 1
            sc = _score(s2, u2)
            if sc is None:
                return best, n_runs, found
            if sc < best[0]:
                best = (sc, s2, u2)
                chosen = i
                found = (pin, list(order), dict(ro))
        if chosen is not None:
            forced[key] = [chosen]
    return best, n_runs, found


def _skeleton(base, shapes_for, Wu, Hu, k, deadline, tick=None, max_big=5, orient=True):
    """Les grandes pieces font l'ossature du calepinage. On cherche leur
    meilleur ordre (et leurs orientations) en les placant seules, sur une
    grille grossiere (passes rapides) ; les petites pieces viendront ensuite
    dans les creux, dans l'ordre habituel.
    Renvoie (ordre complet, rotations imposees, nombre de passes) ou None."""
    if not base:
        return None
    amax = max(t['bbox_area'] for t in base)
    big = sorted([t for t in base if t['bbox_area'] >= 0.25 * amax],
                 key=lambda t: -t['bbox_area'])[:max_big]
    if len(big) < 2 or len(big) == len(base):
        return None
    n_runs = 0

    rest = [t for t in base if t not in big]

    def ev(order, ro):
        s2, u2 = _run(order, ro, shapes_for, Wu, Hu, k, 'panneau', deadline=deadline, tick=tick)
        return _score(s2, u2)

    best_o, best_ro = list(big), {}
    best_sc = ev(best_o, {})
    n_runs += 1
    if best_sc is None:
        return None
    # ordre : toutes les permutations jusqu'a 4 pieces (24 passes rapides) ;
    # au-dela, la 1re piece (toutes essayees), puis la 2e parmi les
    # restantes, etc.
    if len(big) <= 4:
        for perm in itertools.permutations(big):
            perm = list(perm)
            if time.time() > deadline:
                break
            if perm == best_o:
                continue
            sc = ev(perm, {})
            n_runs += 1
            if sc is None:
                break
            if sc < best_sc:
                best_sc, best_o = sc, perm
    for p in range(len(big) - 1 if len(big) > 4 else 0):
        cur = best_o
        for q in range(p + 1, len(cur)):
            if time.time() > deadline:
                break
            perm = list(cur)
            perm.insert(p, perm.pop(q))
            sc = ev(perm, {})
            n_runs += 1
            if sc is None:
                break
            if sc < best_sc:
                best_sc, best_o = sc, perm
    # orientations, une piece a la fois
    for t in (best_o if orient else []):
        key = (t['id'], t['inst'])
        chosen = None
        for i in range(len(shapes_for(t['id']))):
            if time.time() > deadline:
                break
            ro = dict(best_ro)
            ro[key] = [i]
            sc = ev(best_o, ro)
            n_runs += 1
            if sc is None:
                break
            if sc < best_sc:
                best_sc, chosen = sc, i
        if chosen is not None:
            best_ro[key] = [chosen]
    if best_o == big and not best_ro:
        return None   # l'ordre habituel est deja le meilleur
    return best_o + rest, best_ro, n_runs


def _local_search(best, cfg, base, shapes_for, Wu, Hu, k, deadline, tick, rnd, progress=None, n0=0, max_idle=None):
    """Mode Optimise : recherche locale a partir du meilleur calepinage
    trouve (ordre de placement + rotations imposees). Chaque essai change
    un peu la configuration courante (echange de deux pieces, piece avancee
    dans l'ordre, rotation imposee ou liberee) et est garde s'il n'est pas
    moins bon. Les passes reprennent a la premiere piece changee (_run,
    memos) : beaucoup plus d'essais dans le meme temps.
    max_idle : arret apres ce nombre d'essais sans progres (apercu).
    Renvoie (best, nombre de passes)."""
    pin, order, ro = cfg if cfg else (None, list(base), {})
    idle = 0
    order, ro = list(order), dict(ro)
    pinned = set((t['id'], t['inst']) for t in pin[1]) if pin else set()
    cur_sc = best[0]
    cur_memo = last_memo = None
    n_runs = 0
    n = len(order)
    if n < 2:
        return best, 0
    while time.time() < deadline:
        o2, r2 = list(order), dict(ro)
        mv = rnd.random()
        # les dernieres pieces posees changent plus souvent : passes plus
        # courtes (reprise) et ce sont elles qui ouvrent / ferment un panneau
        i = n - 1 - min(n - 1, int(abs(rnd.gauss(0.0, n / 2.5))))
        if mv < 0.35:
            j = min(n - 1, max(0, i + rnd.randint(-4, 4))) if rnd.random() < 0.6 else rnd.randrange(n)
            if i == j:
                continue
            o2[i], o2[j] = o2[j], o2[i]
        elif mv < 0.65:
            j = rnd.randrange(0, i + 1)
            if i == j:
                continue
            o2.insert(j, o2.pop(i))
        else:
            t = o2[i]
            key = (t['id'], t['inst'])
            if key in pinned:
                continue
            ns = len(shapes_for(t['id']))
            if key in r2 and rnd.random() < 0.3:
                del r2[key]
            else:
                r2[key] = [rnd.randrange(ns)]
        out = []
        s2, u2 = _run(o2, r2, shapes_for, Wu, Hu, k, 'panneau', deadline=deadline, tick=tick, pin=pin,
                      memos=(cur_memo, last_memo), snap_out=out)
        n_runs += 1
        sc = _score(s2, u2)
        if sc is None:
            break
        last_memo = out[0] if out else None
        if sc <= cur_sc:
            order, ro, cur_sc = o2, r2, sc
            cur_memo = last_memo
        if sc < best[0]:
            best = (sc, s2, u2)
            idle = 0
        else:
            idle += 1
            if max_idle is not None and idle >= max_idle:
                break
        if progress:
            try:
                progress(n0 + n_runs, best[0])
            except Exception:
                pass
    return best, n_runs


def _score(sheets, unplaced):
    if sheets is None:
        return None
    # a nombre de panneaux egal : la longueur utilisee sur l'ensemble des
    # panneaux (tout tasse au depart, la chute au bout reste exploitable)
    return (len(unplaced), len(sheets), sum(sh.top() for sh in sheets))


_SHAPE_CACHE = {}


def clear_cache():
    _SHAPE_CACHE.clear()


def _fingerprint(regions):
    n, sx, sy = 0, 0.0, 0.0
    for reg in regions:
        for ring in reg:
            n += len(ring)
            for x, y in ring:
                sx += x
                sy += y * 1.000173
    return (len(regions), n, round(sx, 4), round(sy, 4))


# --- Emboitement exact d'une grande piece dans le trou d'une autre ----------------
# Deux grandes pieces dont l'une a la forme du trou de l'autre (a l'espacement
# pres) ne s'emboitent que dans UNE position, a un angle quelconque : la grille
# et les rotations par pas ne la trouvent pas. On la cherche en geometrie exacte
# (rotation relative + translation), puis le couple est place d'un seul bloc.

PAIR_TOL = 0.3        # mm : jeu accepte en dessous de l'espacement (ajustement "exact")
PAIR_RATIO = 0.75     # surface de la piece / surface du trou reduit de l'espacement
_PAIR_CACHE = {}


class _Poly(object):
    """Contour ferme avec index de segments : distance au contour et
    appartenance, sans parcourir tous les segments."""
    CELL = 25.0

    def __init__(self, ring):
        self.p = [(float(x), float(y)) for x, y in ring]
        n = len(self.p)
        self.segs = [(self.p[i], self.p[(i + 1) % n]) for i in range(n)]
        self.x0 = min(q[0] for q in self.p)
        self.y0 = min(q[1] for q in self.p)
        c = self.CELL
        self.grid = {}
        self.rows = {}
        for i, ((ax, ay), (bx, by)) in enumerate(self.segs):
            i0, i1 = int((min(ax, bx) - self.x0) // c), int((max(ax, bx) - self.x0) // c)
            j0, j1 = int((min(ay, by) - self.y0) // c), int((max(ay, by) - self.y0) // c)
            for gi in range(i0, i1 + 1):
                for gj in range(j0, j1 + 1):
                    self.grid.setdefault((gi, gj), []).append(i)
            for gj in range(j0, j1 + 1):
                self.rows.setdefault(gj, []).append(i)

    def inside(self, x, y):
        c = self.CELL
        n = 0
        for i in self.rows.get(int((y - self.y0) // c), ()):
            (ax, ay), (bx, by) = self.segs[i]
            if (ay <= y) != (by <= y):
                if ax + (y - ay) * (bx - ax) / (by - ay) > x:
                    n += 1
        return n & 1 == 1

    def dist(self, x, y, R):
        """Distance au contour si <= R, sinon None."""
        c = self.CELL
        gi, gj = int((x - self.x0) // c), int((y - self.y0) // c)
        r = int(R // c) + 1
        best = None
        seen = set()
        for a in range(gi - r, gi + r + 1):
            for b in range(gj - r, gj + r + 1):
                for i in self.grid.get((a, b), ()):
                    if i in seen:
                        continue
                    seen.add(i)
                    (ax, ay), (bx, by) = self.segs[i]
                    dx, dy = bx - ax, by - ay
                    l2 = dx * dx + dy * dy
                    t = 0.0 if l2 == 0 else max(0.0, min(1.0, ((x - ax) * dx + (y - ay) * dy) / l2))
                    ex, ey = ax + t * dx - x, ay + t * dy - y
                    d2 = ex * ex + ey * ey
                    if best is None or d2 < best:
                        best = d2
        if best is None or best > R * R:
            return None
        return math.sqrt(best)


def _ring_centroid(r):
    a = cx = cy = 0.0
    n = len(r)
    for i in range(n):
        x1, y1 = r[i]
        x2, y2 = r[(i + 1) % n]
        w = x1 * y2 - x2 * y1
        a += w
        cx += (x1 + x2) * w
        cy += (y1 + y2) * w
    if abs(a) < 1e-9:
        return sum(p[0] for p in r) / n, sum(p[1] for p in r) / n
    return cx / (3 * a), cy / (3 * a)


def _ring_perim(r):
    return sum(math.hypot(r[i][0] - r[(i + 1) % len(r)][0], r[i][1] - r[(i + 1) % len(r)][1])
               for i in range(len(r)))


def _ring_polar(r):
    """Moment polaire de la surface du contour autour de son centre (invariant
    par rotation) : filtre rapide des formes qui se ressemblent."""
    cx, cy = _ring_centroid(r)
    j = 0.0
    n = len(r)
    for i in range(n):
        x1, y1 = r[i][0] - cx, r[i][1] - cy
        x2, y2 = r[(i + 1) % n][0] - cx, r[(i + 1) % n][1] - cy
        w = x1 * y2 - x2 * y1
        j += w * (x1 * x1 + x1 * x2 + x2 * x2 + y1 * y1 + y1 * y2 + y2 * y2)
    return abs(j) / 12.0


def _densify(ring, step):
    out = []
    n = len(ring)
    for i in range(n):
        ax, ay = ring[i]
        bx, by = ring[(i + 1) % n]
        out.append((ax, ay))
        d = math.hypot(bx - ax, by - ay)
        for k in range(1, int(d // step) + 1):
            if d - k * step < 1e-6:
                break
            t = k * step / d
            out.append((ax + (bx - ax) * t, ay + (by - ay) * t))
    return out


def _fit_pair(hole, qring, spacing, tick=None):
    """Pose de la piece q (contour qring) dans le trou (contour hole) qui
    garde au moins spacing - PAIR_TOL partout. Renvoie (theta deg, ax, ay) :
    p -> R(theta) p + (ax, ay), ou None."""
    key = (_fingerprint([[hole]]), _fingerprint([[qring]]), round(spacing, 3))
    if key in _PAIR_CACHE:
        return _PAIR_CACHE[key]
    res = _fit_pair_raw(hole, qring, spacing, tick)
    if len(_PAIR_CACHE) > 64:
        _PAIR_CACHE.pop(next(iter(_PAIR_CACHE)))
    _PAIR_CACHE[key] = res
    return res


def _fit_pair_raw(hole, qring, spacing, tick=None):
    s = spacing
    cH = _ring_centroid(hole)
    cQ = _ring_centroid(qring)
    H = _Poly(hole)
    # 1) recherche grossiere de l'angle : difference symetrique sur une grille
    # de 8 mm, centres alignes
    st = 10.0
    off = 1500.0

    def rot_pts(ring, th):
        c, sn = math.cos(math.radians(th)), math.sin(math.radians(th))
        return [(c * (x - cQ[0]) - sn * (y - cQ[1]) + cH[0] + off, sn * (x - cQ[0]) + c * (y - cQ[1]) + cH[1] + off)
                for x, y in ring]
    hm = raster([[[(x - 0.0 + off, y + off) for x, y in hole]]], st, True)
    cands = []
    for ia in range(0, 360, 5):
        if tick:
            tick()
        w, h, rows = raster([[rot_pts(qring, ia)]], st, True)
        diff = 0
        n = max(len(rows), len(hm[2]))
        for j in range(n):
            a = rows[j] if j < len(rows) else 0
            b = hm[2][j] if j < len(hm[2]) else 0
            diff += _popcount(a ^ b)
        cands.append((diff, ia))
    cands.sort()
    if cands[0][0] * st * st > 0.25 * abs(ring_area(hole)):
        return None       # formes trop differentes
    # 2) affinage exact autour des meilleurs angles
    Qpts = _densify(qring, 12.0)
    R = s + 60.0
    big = (R + s) ** 2

    def viol(v):
        th, dx, dy = v
        c, sn = math.cos(math.radians(th)), math.sin(math.radians(th))
        tot = 0.0
        for x, y in Qpts:
            X = c * (x - cQ[0]) - sn * (y - cQ[1]) + cH[0] + dx
            Y = sn * (x - cQ[0]) + c * (y - cQ[1]) + cH[1] + dy
            ins = H.inside(X, Y)
            d = H.dist(X, Y, R)
            if d is None:
                if not ins:
                    tot += big
                continue
            sd = d if ins else -d
            if sd < s:
                tot += (s - sd) ** 2
        return tot
    best = None
    for _d, ia in cands[:3]:
        v = [float(ia), 0.0, 0.0]
        f = viol(v)
        steps = [1.5, 6.0, 6.0]
        while steps[1] > 0.02:
            if tick:
                tick()
            improved = False
            for i in range(3):
                for sg in (1.0, -1.0):
                    w = list(v)
                    w[i] += sg * steps[i]
                    fw = viol(w)
                    if fw < f:
                        v, f = w, fw
                        improved = True
            if not improved:
                steps = [x * 0.5 for x in steps]
            if f == 0.0:
                break
        if best is None or f < best[0]:
            best = (f, v)
        if f == 0.0:
            break
    f, v = best
    th, dx, dy = v
    c, sn = math.cos(math.radians(th)), math.sin(math.radians(th))
    ax = cH[0] + dx - (c * cQ[0] - sn * cQ[1])
    ay = cH[1] + dy - (sn * cQ[0] + c * cQ[1])
    # 3) controle exact : q dans le trou, jeu >= espacement - tolerance (des deux sens)
    Q = [(c * x - sn * y + ax, sn * x + c * y + ay) for x, y in qring]
    if not all(H.inside(x, y) for x, y in Q[::7]):
        return None
    mind = min((H.dist(x, y, s + 5.0) or 1e9) for x, y in _densify(Q, 6.0))
    QP = _Poly(Q)
    mind = min(mind, min((QP.dist(x, y, s + 5.0) or 1e9) for x, y in _densify(hole, 6.0)))
    if mind < s - PAIR_TOL:
        return None
    return (th % 360.0, ax, ay)


def _make_pairs(parts, spacing, L, W, o, tick=None):
    """Remplace les couples (grande piece creuse, piece qui epouse son trou) par
    une piece composite posee d'un seul bloc. Renvoie (parts, couples) ;
    couples : {id composite: (id anneau, id piece, theta, ax, ay)}."""
    avail = {p['id']: max(1, int(p.get('qty', 1) or 1)) for p in parts}
    by = {p['id']: p for p in parts}
    info = {}
    for p in parts:
        reg = p['regions']
        outer = abs(ring_area(reg[0][0])) if reg else 0.0
        info[p['id']] = outer - sum(abs(ring_area(h)) for h in reg[0][1:]) if reg else 0.0
    rings = []
    for p in parts:
        if not p['regions']:
            continue
        for hi, h in enumerate(p['regions'][0][1:]):
            ah = abs(ring_area(h))
            if ah >= 0.02 * L * W:
                rings.append((ah, p['id'], hi, h))
    rings.sort(key=lambda t: -t[0])
    pairs = {}
    comps = []
    for ah, rid, hi, h in rings:
        eff = ah - _ring_perim(h) * spacing
        for q in sorted(parts, key=lambda t: -info[t['id']]):
            qid = q['id']
            if qid == rid or avail.get(rid, 0) < 1 or avail.get(qid, 0) < 1 or not q['regions']:
                continue
            aq = info[qid]
            if aq > ah or aq < PAIR_RATIO * eff:
                continue
            qr, hp = q['regions'][0][0], _ring_perim(h)
            if abs(_ring_perim(qr) - hp) > 0.2 * hp:
                continue
            jr = _ring_polar(qr) / max(1e-9, _ring_polar(h))
            if not 0.5 <= jr <= 1.1:
                continue
            fit = _fit_pair(h, q['regions'][0][0], spacing, tick)
            if fit is None:
                continue
            n = min(avail[rid], avail[qid])
            th, ax, ay = fit
            c, sn = math.cos(math.radians(th)), math.sin(math.radians(th))
            qreg = [[[(c * x - sn * y + ax, sn * x + c * y + ay) for x, y in ring] for ring in reg]
                    for reg in q['regions']]
            r = by[rid]
            cid = 'pair|%s|%s|%d' % (rid, qid, hi)
            comp = {'id': cid, 'name': r.get('name', rid), 'comp': r.get('comp', ''), 'qty': n,
                    'regions': [list(reg) for reg in r['regions']] + qreg, 'flippable': False,
                    '_fill': _fill_ratio(r)}
            comps.append(comp)
            pairs[cid] = (rid, qid, th, ax, ay, r.get('name', rid), q.get('name', qid))
            avail[rid] -= n
            avail[qid] -= n
    if not comps:
        return parts, {}
    out = []
    for p in parts:
        n = avail[p['id']]
        if n > 0:
            out.append(dict(p, qty=n))
    return out + comps, pairs


def _expand_pairs(sheets, unplaced, pairs, parts):
    """Remplace chaque placement composite par ceux de ses deux pieces."""
    if not pairs:
        return
    made = {}                      # id -> nombre d'exemplaires pris par des composites
    for cid, v in pairs.items():
        for pid in (v[0], v[1]):
            made[pid] = 0
    for s in sheets:
        for pl in s['placements']:
            if pl['id'] in pairs:
                made[pairs[pl['id']][0]] += 1
                made[pairs[pl['id']][1]] += 1
    for s in sheets:
        new = []
        for pl in s['placements']:
            v = pairs.get(pl['id'])
            if v is None:
                if pl['id'] in made:
                    pl = dict(pl, inst=pl['inst'] + made[pl['id']])
                new.append(pl)
                continue
            rid, qid, th, ax, ay, rname, qname = v
            c, sn = math.cos(math.radians(pl['rot'])), math.sin(math.radians(pl['rot']))
            new.append(dict(pl, id=rid, name=rname))
            new.append({'id': qid, 'name': qname, 'inst': pl['inst'], 'rot': (pl['rot'] + th) % 360.0,
                        'tx': c * ax - sn * ay + pl['tx'], 'ty': sn * ax + c * ay + pl['ty'], 'flip': False})
        s['placements'] = new
    for u in list(unplaced):
        v = pairs.get(u['id'])
        if v is not None:
            unplaced.remove(u)
            unplaced.append(dict(u, id=v[0], name=v[5]))
            unplaced.append(dict(u, id=v[1], name=v[6]))


# Regles de pose essayees au depart (voir nest). waste : poids de la longueur
# de panneau entamee face a la surface perdue sous la piece (None = regle
# d'origine, la position la plus basse) ; align : les grandes pieces creuses
# s'ouvrent du meme cote que la premiere du panneau ; stack : les pieces
# courbes identiques s'empilent.
POLICIES = (
    {},
    {'waste': 4},
    {'waste': 1, 'align': 1},
    {'waste': 4, 'align': 2},
    {'waste': 4, 'align': 1, 'stack': True},
    {'waste': 1},
)


def _set_policy(p, as_rect=False):
    _CFG['waste'] = p.get('waste')
    _CFG['align'] = 0 if as_rect else int(p.get('align', 0) or 0)
    _CFG['stack'] = bool(p.get('stack', False)) and not as_rect
    _CFG['ortho'] = bool(p.get('ortho', False)) and not as_rect
    _CFG['noflip'] = bool(p.get('noflip', False))


def nest(parts, L=3100.0, W=1550.0, opts=None, progress=None, tick=None):
    """Place les pieces sur des panneaux L x W (mm).

    parts : [{'id', 'name', 'comp', 'qty', 'regions'}] (voir en-tete).
    Renvoie {'sheets': [{'index', 'util', 'placements': [{'id', 'name',
    'inst', 'rot', 'tx', 'ty'}]}], 'unplaced': [...], 'stats': {...}}.
    Pose d'une piece : point local p -> R(rot) p + (tx, ty), en mm, origine
    au coin bas-gauche du panneau brut (marge comprise)."""
    o = dict(DEFAULT_OPTS)
    o.update(opts or {})
    if o.get('mode') == 'rectangulaire' and o.get('coupes') in GUILLO_DIRS:
        # coupes prioritaires : placement par bandes guillotine (scie a format)
        return nest_guillotine(parts, L, W, o, tick)
    t0 = time.time()
    step = max(0.25, float(o['step']))
    m = max(0.0, float(o['margin']))
    mode = o['mode'] if o['mode'] in MODES else 'imbrique'
    as_rect = mode == 'rectangulaire'
    pairs = {}
    if not as_rect and o.get('pair', True) and len(parts) > 1:
        parts, pairs = _make_pairs(parts, float(o['spacing']), L, W, o, tick)
    # creux et trous des grandes pieces utilises dans tous les modes imbriques
    # (les petites pieces s'y logent d'abord, voir _run)
    fill_holes = as_rect
    _CFG['zone'] = bool(o.get('zone', True)) and not as_rect
    _CFG['adj'] = float(o.get('adj', 0.0) or 0.0)
    rotations = [r % 360 for r in (o['rotations'] or [0])]
    rotations = sorted(set(rotations), key=rotations.index)
    # rotations a 90 deg permises : le fil du bois n'est pas impose, les
    # pieces courbes (arcs, croissants...) essaient aussi les angles
    # intermediaires (pas de 30 deg), elles s'emboitent bien mieux
    fine_rots = None
    fine_big = None
    curved_fill = float(o.get('curved_fill', CURVED_FILL))
    if (o.get('rot_courbes', True) and not as_rect and sorted(rotations) == [0, 90, 180, 270]
            and any(_fill_ratio(p) < curved_fill for p in parts)):
        fine_rots = list(range(0, 360, int(o.get('fine_step', 30))))
        # grandes pieces courbes : angles plus fins (deux grandes formes libres
        # ne s'emboitent souvent qu'a quelques degres pres)
        fine_big = list(range(0, 360, int(o.get('fine_step_big', FINE_BIG))))
    if (len(rotations) > 4 or fine_rots) and step < 2.0:
        step = 2.0  # rotations libres : grille plus grossiere (temps de calcul)
    # (apres le choix du pas : calcule avant, l'espacement reel etait double
    # des que la grille passait a 2 mm)
    exact = bool(o.get('exact', True))
    sp = max(0.0, float(o['spacing']))

    def cells_k(st):
        # cellules de grossissement : exact = ceil(espacement / pas) (voir dilate)
        if exact:
            return max(1, int(math.ceil(sp / st - 1e-9)))
        return int(math.ceil(sp / st)) + 1
    k = cells_k(step)

    F = frame_matrix(L, W, o['corner'], o['compact'])
    lin = [[F[0][0], F[0][1]], [F[1][0], F[1][1]]]
    Lc, Wc = (W, L) if o['compact'] == 'x' else (L, W)
    Wu = int(math.floor((Lc - 2 * m) / step + 1e-9))
    Hu = int(math.floor((Wc - 2 * m) / step + 1e-9))
    Finv = _mat_inv_affine(F)

    by_id = {p['id']: p for p in parts}

    def make_shapes_for(step, k):
        cache = {}
        # formes deja preparees par un calcul precedent (meme piece, meme
        # grille, meme repere) : rien a refaire quand on change le format,
        # le nombre de meubles, la portee... (cache du module, borne)
        K = max(sp / step, 1e-6) if exact else None
        ckey = (step, k, K, fill_holes, as_rect, tuple(map(tuple, lin)), tuple(rotations),
                tuple(fine_rots or ()), tuple(fine_big or ()), curved_fill, bool(o.get('flip')))
        ent = _SHAPE_CACHE.get(ckey)
        if ent is None:
            if len(_SHAPE_CACHE) >= 6:
                _SHAPE_CACHE.pop(next(iter(_SHAPE_CACHE)))
            ent = _SHAPE_CACHE[ckey] = ({}, {})
        else:
            _SHAPE_CACHE[ckey] = _SHAPE_CACHE.pop(ckey)   # le plus recent a la fin
        pcache, intern = ent

        def shapes_for(pid):
            if pid not in cache:
                p = by_id[pid]
                fp = (pid, p.get('flippable', False), _fingerprint(p['regions']))
                if fp in pcache:
                    cache[pid] = pcache[fp]
                    return cache[pid]
                flips = (False, True) if (o.get('flip') and p.get('flippable')) else (False,)
                rots = rotations
                if fine_rots and _fill_ratio(p) < curved_fill:
                    # piece courbe (arc, croissant...) : les angles
                    # intermediaires l'emboitent bien mieux dans les autres
                    x0, y0, x1, y1 = regions_bbox(p['regions'])
                    # (boite 12 % du panneau, quel que soit le sens)
                    fr = fine_big if (x1 - x0) * (y1 - y0) >= BIG_FRAC * L * W else fine_rots
                    rots = rotations + [r for r in fr if r not in rotations]
                shs, bases = [], []
                for f in flips:
                    for r in rots:
                        m = _mat_mul(_rot_mat(r), [[lin[0][0], lin[0][1], 0.0], [lin[1][0], lin[1][1], 0.0], [0, 0, 1.0]])
                        if f:
                            m = _mat_mul(m, [[1.0, 0.0, 0.0], [0.0, -1.0, 0.0], [0.0, 0.0, 1.0]])
                        mb = _mirror_of(m, bases)
                        if mb is not None:
                            sh = _Shape(None, r, lin, step, k, fill_holes, as_rect, f, intern, mb[0], mb[1], K=K)
                        else:
                            sh = _Shape(p['regions'], r, lin, step, k, fill_holes, as_rect, f, intern, K=K)
                            bases.append(sh)
                        shs.append(sh)
                cache[pid] = pcache[fp] = shs
            return cache[pid]
        return shapes_for

    shapes_for = make_shapes_for(step, k)
    _CFG['cell'] = step * step
    # meme formes sur une grille 2x plus grossiere : recherche rapide de
    # l'ossature (_skeleton). Meme ordre des formes, indices compatibles.
    step2 = 2 * step
    k2 = cells_k(step2)
    Wu2 = int(math.floor((Lc - 2 * m) / step2 + 1e-9))
    Hu2 = int(math.floor((Wc - 2 * m) / step2 + 1e-9))
    coarse_for = make_shapes_for(step2, k2)

    insts = _prepare(parts, o)
    base = _order(insts, o['order'])
    for t in base:
        shapes_for(t['id'])
        if tick:
            tick()

    # Regles de pose : aucune n'est la meilleure sur tous les projets (ecarts
    # de 5 a 20 % d'un projet a l'autre). Une passe par regle, la meilleure
    # est gardee pour toute la suite du calcul. La 1re est la regle
    # d'origine : le resultat n'est jamais moins bon qu'avant.
    pols = o.get('policies')
    if pols is None:
        if 'waste' in o or 'align' in o or 'stack' in o:
            pols = [{'waste': o.get('waste'), 'align': o.get('align', 0), 'stack': o.get('stack', False)}]
        else:
            pols = list(POLICIES)
            if as_rect or not any(t['fillr'] < CURVED_FILL and t['bbox_area'] >= ZONE_MIN * L * W
                                  for t in base):
                # pas de grande piece creuse : les regles qui les concernent ne changent rien
                pols = [p for p in pols if not p.get('align') and not p.get('stack') and not p.get('ortho')]
            if o.get('flip') and any(p.get('flippable') for p in parts):
                # retournement permis : il ne doit pas donner moins bien que sans
                pols += [{'waste': 4, 'noflip': True}, {'noflip': True}]
    n_runs = 0
    t_run = None
    t_pol = time.time()
    first = []          # (score, rang, regle, resultat) de la 1re passe de chaque regle
    for p in pols:
        _set_policy(p, as_rect)
        t1 = time.time()
        sheets, unplaced = _run(base, {}, shapes_for, Wu, Hu, k, 'panneau', tick=tick)
        n_runs += 1
        if t_run is None:
            t_run = time.time() - t1
        first.append((_score(sheets, unplaced), len(first), p, (sheets, unplaced), None))
    first.sort(key=lambda c: c[:2])
    has_big = len(base) > 1 and any(min(sh.w * sh.h for sh in shapes_for(t['id'])) >= BIG_FRAC * Wu * Hu
                                    for t in base)
    # Essais d'une seule passe, du plus prometteur au moins prometteur, dans
    # un temps borne (t_port) :
    t_port = t_pol + float(o.get('port_time', max(6.0, 7.0 * t_run)))
    # 1) Grandes pieces de forme libre : le glouton pose la 1re grande piece
    # d'un panneau neuf dans l'orientation la plus basse, ce qui peut empecher
    # la suivante de s'emboiter a cote (une grande piece par panneau au lieu
    # de deux tete-beche). Une passe qui choisit cette orientation en
    # regardant les grandes pieces suivantes (_lookahead), pour chaque regle ;
    # gardee si elle fait mieux, ses orientations sont alors imposees aux
    # essais suivants.
    if has_big:
        for j in range(len(first)):
            if time.time() >= t_port:
                break
            sc, i, p, _r, _c = first[j]
            _set_policy(p, as_rect)
            fo = {}
            s2, u2 = _run(base, {}, shapes_for, Wu, Hu, k, 'panneau', tick=tick, lookahead=True, forced_out=fo)
            n_runs += 1
            sc2 = _score(s2, u2)
            if sc2 is not None and sc2 < sc:
                first[j] = (sc2, i, p, (s2, u2), (None, base, fo))
        first.sort(key=lambda c: c[:2])
    # 2) Un panneau de moins semble possible (surface des pieces) : autres
    # ordres de depart pour les deux meilleures regles, et chaque regle sans
    # retournement (cocher Retourner ne doit pas couter un panneau).
    bsc, _bi, _bp, (bsh, bun), _bc = first[0]
    if (o.get('more', True) and not bun and len(bsh) >= 2 and len(base) > 1
            and sum(sh.cells for sh in bsh) <= 0.95 * (len(bsh) - 1) * Wu * Hu):
        more = []
        if o['order'] == 'surface':
            for _sc, _i, p, _r, _c in first[:2]:
                for how in ('aire', 'long'):
                    more.append((p, _order(insts, how)))
        if o.get('flip') and any(p.get('flippable') for p in parts):
            for p in pols:
                q = dict(p, noflip=True)
                if not p.get('noflip') and q not in pols:
                    more.append((q, base))
        for p, order in more:
            if time.time() >= t_port:
                break
            _set_policy(p, as_rect)
            sheets, unplaced = _run(order, {}, shapes_for, Wu, Hu, k, 'panneau', tick=tick)
            n_runs += 1
            first.append((_score(sheets, unplaced), len(first), p, (sheets, unplaced),
                          None if order is base else (None, order, {})))
        first.sort(key=lambda c: c[:2])

    # temps des essais d'amelioration ci-dessous : borne pour garder un apercu rapide
    t_extra = time.time() + float(o.get('extra_time', min(10.0, max(2.0, 3.0 * t_run))))
    if mode == 'optimise':
        t_extra = max(t_extra, t0 + 0.6 * max(1.0, float(o['time_limit'])))

    def improve_a(best, cfg):
        """Essais d'amelioration avec la regle de pose courante : panneau
        economise. Renvoie (best, (pin, ordre, rotations) du meilleur ou
        None, passes)."""
        nr_tot = 0
        # Un panneau coute cher : si la surface des pieces laisse esperer un
        # panneau de moins, on relance quelques passes dans d'autres ordres
        # (pieces du dernier panneau d'abord, plus longues d'abord...) et on garde
        # le resultat qui utilise le moins de panneaux, meme avec une grosse chute.
        if o.get('reduce', True):
            lim = float(o.get('reduce_time', min(20.0, max(1.0, 2.5 * t_run))))
            best, nr, cfg2 = _reduce(best, base, shapes_for, Wu, Hu, k, min(t_extra, time.time() + lim), tick)
            nr_tot += nr
            cfg = cfg2 or cfg
        return best, cfg, nr_tot

    def improve_b(best, cfg):
        """Suite des essais : ordre et orientations des grandes pieces."""
        nr_tot = 0
        # ossature : ordre des grandes pieces (grille grossiere, rapide)
        if o.get('explore', True) and len(base) > 1:
            sk = _skeleton(base, coarse_for, Wu2, Hu2, k2, min(t_extra, time.time() + max(4.0, 3.0 * t_run)), tick, orient=o.get('sk_orient', False))
            if sk:
                order, ro, nr = sk
                nr_tot += nr
                s2, u2 = _run(order, ro, shapes_for, Wu, Hu, k, 'panneau', deadline=t_extra, tick=tick)
                nr_tot += 1
                sc = _score(s2, u2)
                if sc is not None and sc < best[0]:
                    best = (sc, s2, u2)
                    cfg = (None, order, ro)
        # Le glouton choisit l'orientation de chaque grande piece sans regarder
        # la suite : on essaie les autres orientations des plus grandes pieces
        # (une a la fois, en gardant la meilleure) pour que les suivantes
        # s'emboitent mieux. Garde le resultat le plus compact.
        if o.get('explore', True) and len(base) > 1:
            best, nr, cfg3 = _explore(best, base, shapes_for, Wu, Hu, k, t_extra, tick, cfg=cfg)
            nr_tot += nr
            cfg = cfg3 or cfg
        return best, cfg, nr_tot

    # La meilleure regle d'abord, puis les autres tant qu'il reste du temps :
    # la regle la mieux partie n'est pas toujours la meilleure a l'arrivee.
    second = []
    for sc, i, p, (sheets, unplaced), c0 in first:
        _set_policy(p, as_rect)
        b2, c2, nr = improve_a((sc, sheets, unplaced), c0)
        n_runs += nr
        second.append((b2[0], i, p, b2, c2))
    second.sort(key=lambda c: c[:2])
    best = None
    cfg = None
    pol = second[0][2]
    for _sc, _i, p, b2, c2 in second:
        if best is not None and time.time() >= t_extra:
            break
        _set_policy(p, as_rect)
        if o.get('explore', True):
            b2, c2, nr = improve_b(b2, c2)
            n_runs += nr
        if best is None or b2[0] < best[0]:
            best, cfg, pol = b2, c2, p
    _set_policy(pol, as_rect)

    if mode == 'optimise' and len(base) > 1:
        deadline = t0 + max(1.0, float(o['time_limit']))
        # (arret avant la limite si plus rien ne s'ameliore : inutile de faire
        # attendre 30 s pour quelques pieces)
        best, nr = _local_search(best, cfg, base, shapes_for, Wu, Hu, k, deadline, tick,
                                 random.Random(o.get('seed', 1)), progress, n_runs,
                                 max_idle=o.get('max_idle', max(80, 8 * len(base))))
        n_runs += nr
    _, sheets, unplaced = best

    if o['fill'] == 'equilibre' and len(sheets) > 1:
        s2, u2 = _run(base, {}, shapes_for, Wu, Hu, k, 'equilibre', n_balanced=len(sheets), tick=tick)
        if len(u2) <= len(unplaced):
            sheets, unplaced = s2, u2

    out_sheets = []
    total_cells = 0
    for si, sheet in enumerate(sheets):
        pls = []
        for it in sheet.items:
            sh, t = it['sh'], it['t']
            # point canonique Q = lin_rot p - off + (m + x*step, m + y*step)
            sx = m + it['_x'] * step - sh.off[0]
            sy = m + it['_y'] * step - sh.off[1]
            A = _mat_mul(Finv, sh.lin)
            # retournee : A = R . diag(1, -1), la 1re colonne donne encore R
            tx, ty = _mat_apply(Finv, sx, sy)
            rot = math.degrees(math.atan2(A[1][0], A[0][0])) % 360.0
            if abs(rot - round(rot)) < 1e-6:
                rot = float(round(rot)) % 360.0
            pls.append({'id': t['id'], 'name': t['name'], 'inst': t['inst'],
                        'rot': rot, 'tx': tx, 'ty': ty, 'flip': bool(sh.flip)})
        total_cells += sheet.cells
        out_sheets.append({'index': si + 1, 'placements': pls,
                           'util': sheet.cells * step * step / (L * W)})
    n_parts = len(insts) + sum(1 for t in insts if t['id'] in pairs)
    _expand_pairs(out_sheets, unplaced, pairs, parts)
    return {
        'sheets': out_sheets,
        'unplaced': unplaced,
        'stats': {'n_sheets': len(out_sheets), 'n_parts': n_parts, 'n_pairs': len(pairs),
                  'policy': dict(pol), 'n_runs': n_runs, 'time_s': round(time.time() - t0, 2),
                  'util': (total_cells * step * step / (L * W * len(out_sheets))) if out_sheets else 0.0,
                  'mode': mode, 'L': L, 'W': W, 'margin': m},
    }


# --- Coupes prioritaires (mode Rectangulaire, scie a format) --------------------
#
# Placement GUILLOTINE par bandes, comme OpenCutList : le panneau est d'abord
# coupe de bout en bout par les coupes prioritaires (niveau 1, horizontales =
# le long de la longueur L, verticales = le long de la largeur W), en bandes.
# Chaque bande est recoupee en travers en colonnes (niveau 2) ; avec 2
# niveaux ou plus, plusieurs pieces s'empilent dans une colonne (recoupe
# parallele aux coupes prioritaires) ; avec 3 niveaux, une rangee de colonne
# peut encore etre recoupee en travers. Tout se debite a la scie a format.
# Repere de travail (u, v) : u le long des coupes prioritaires, v en travers.

GUILLO_DIRS = ('horizontales', 'verticales')


def _g_orients(t, allow90):
    """Orientations (a, b, rot) : a = taille le long de u, b = en travers."""
    a, b = t['_gw'], t['_gh']
    out = [(a, b, 0)]
    if allow90 and abs(a - b) > 1e-6:
        out.append((b, a, 90))
    return out


def _g_fill_sheet(items, U, V, sp, levels, max_strips, pref, allow90):
    """Remplit un panneau. items : instances (dans l'ordre de priorite).
    Renvoie (bandes, restantes). Bande = {'v', 'H', 'cols': [{'u', 'w',
    'rows': [{'v', 'h', 'pcs': [(t, u, v, a, b, rot)]}]}]}."""
    rem = list(items)
    strips = []
    vpos = 0.0
    eps = 1e-6

    def take(pred_fit, choose):
        best = None
        for i, t in enumerate(rem):
            for o in _g_orients(t, allow90):
                if pred_fit(o):
                    key = choose(t, o)
                    if best is None or key < best[0]:
                        best = (key, i, o)
            if best is not None and pref not in ('meilleur', 'rapide'):
                break   # 1re piece de l'ordre qui entre (l'ordre est la priorite)
        if best is None:
            return None
        t = rem.pop(best[1])
        return t, best[2]

    while rem and len(strips) < max_strips:
        Vl = V - vpos
        if Vl < -eps:
            break

        def fit_open(o):
            return o[0] <= U + eps and o[1] <= Vl + eps

        if pref == 'rapide':
            # 1re piece de l'ordre (groupes de meme largeur), posee sur sa largeur
            def ch(t, o):
                return (rem.index(t), o[1] > min(o) + eps)
        elif pref == 'longue':
            ch = lambda t, o: (o[1] > o[0] + eps, o[1])           # cote long le long de la bande
        elif pref == 'courte':
            ch = lambda t, o: (o[0] > o[1] + eps, -o[1])
        else:
            ch = lambda t, o: (-t['_gw'] * t['_gh'], o[1])        # bande la plus basse
        got = take(fit_open, ch)
        if got is None:
            break
        t0, o0 = got
        H = o0[1]
        cols = []
        upos = 0.0
        first = (t0, o0)
        while True:
            Ul = U - upos
            if first is not None:
                tc, oc = first
                first = None
            else:
                # colonne suivante : la piece la plus haute qui entre (bande bien remplie)
                if pref == 'rapide':
                    # d'abord les pieces de la meme largeur que la bande (une
                    # seule cote a regler sur la scie), dans l'ordre
                    g = take(lambda o: o[0] <= Ul + eps and o[1] <= H + eps,
                             lambda t, o: (abs(o[1] - H) > eps, -(o[1] * o[0]), o[0]))
                else:
                    g = take(lambda o: o[0] <= Ul + eps and o[1] <= H + eps,
                             lambda t, o: (-(o[1] * o[0]), o[0]))
                if g is None:
                    break
                tc, oc = g
            cw = oc[0]
            col = {'u': upos, 'w': cw, 'rows': []}
            cols.append(col)
            vrow = 0.0
            first_row = (tc, oc)
            while True:
                hl = H - vrow
                if first_row is not None:
                    tr, orw = first_row
                    first_row = None
                else:
                    if levels < 2:
                        break
                    g = take(lambda o: o[0] <= cw + eps and o[1] <= hl + eps,
                             lambda t, o: (-(o[1] * o[0]), -o[0]))
                    if g is None:
                        break
                    tr, orw = g
                rh = orw[1]
                row = {'v': vrow, 'h': rh, 'pcs': [(tr, 0.0, 0.0, orw[0], orw[1], orw[2])]}
                col['rows'].append(row)
                if levels >= 3:
                    ur = orw[0] + sp
                    while True:
                        g = take(lambda o: o[0] <= cw - ur + eps and o[1] <= rh + eps,
                                 lambda t, o: (-(o[1] * o[0]), -o[1]))
                        if g is None:
                            break
                        tp, op = g
                        row['pcs'].append((tp, ur, 0.0, op[0], op[1], op[2]))
                        ur += op[0] + sp
                vrow += rh + sp
                if vrow >= H - eps:
                    break
            upos += cw + sp
            if upos >= U - eps:
                break
        strips.append({'v': vpos, 'H': H, 'cols': cols})
        vpos += H + sp
    return strips, rem


CHUTE_UTILE = 250.0     # chute en bout de bande gardee seulement si >= (mm)
MARGE_CHUTE = 25.0      # marge laissee avant cette chute (mm)


def _g_merge_cols(cols, sp):
    """Colonnes identiques qui se suivent dans une bande : un seul bloc
    (demande du 2026-11-19 : « on priorise la largeur, la mise a longueur
    apres »). Ex. 2 pieces 180 x 131 cote a cote dans une bande de 400 :
    couper le bloc a 360, le refendre a 131, puis le recouper a 180, au lieu
    de couper 180 / 131 / 180 / 131. Seulement si les pieces remplissent la
    largeur de la colonne dans chaque rangee (sinon une chute resterait
    collee entre deux pieces)."""
    def sig(c):
        return (round(c['w'], 3), tuple((round(r['v'], 3), round(r['h'], 3),
                                         tuple((round(pc[1], 3), round(pc[2], 3), round(pc[3], 3), round(pc[4], 3))
                                               for pc in r['pcs'])) for r in c['rows']))

    def fills(c):
        return all(r['pcs'] and max(pc[1] + pc[3] for pc in r['pcs']) >= c['w'] - 1e-3 for r in c['rows'])

    out = []
    i = 0
    while i < len(cols):
        c = cols[i]
        j = i + 1
        if fills(c) and c['rows']:
            while (j < len(cols) and sig(cols[j]) == sig(c)
                   and abs(cols[j]['u'] - (cols[j - 1]['u'] + c['w'] + sp)) < 1e-3):
                j += 1
        if j - i < 2:
            out.append(c)
            i += 1
            continue
        run = cols[i:j]
        rows = []
        for ri, r in enumerate(c['rows']):
            pcs = []
            for cc in run:
                off = cc['u'] - c['u']
                for pc in cc['rows'][ri]['pcs']:
                    pcs.append((pc[0], pc[1] + off) + tuple(pc[2:]))
            rows.append({'v': r['v'], 'h': r['h'], 'pcs': pcs})
        out.append({'u': c['u'], 'w': run[-1]['u'] + run[-1]['w'] - c['u'], 'rows': rows})
        i = j
    return out


def _g_reglage(st):
    """Reglage de la scie a format : guide parallele (coupes le long de la
    bande : prioritaires, refentes, mises a largeur) ou butee laterale
    (tronconnages, recoupes), et la cote."""
    return ('par' if st['kind'] in ('prim', 'refente', 'ajust') else 'lat', round(st['dim'], 1))


def _g_par_reglage(steps):
    """Ordre des coupes d'un panneau regroupe par reglage (demande du
    2026-11-19 : moins de reglages du guide). Les coupes prioritaires restent
    en tete, dans leur ordre ; ensuite, tant qu'une coupe disponible (ses
    coupes prealables faites) a le reglage en cours, on la fait ; sinon on
    passe au reglage qui permet le plus de coupes d'affilee."""
    n = len(steps)
    prim = [i for i in range(n) if steps[i]['kind'] == 'prim']
    rest = [i for i in range(n) if steps[i]['kind'] != 'prim']
    done = set(prim)
    order = list(prim)

    def avail(dn):
        return [i for i in rest if i not in dn and all(r in dn for r in steps[i]['req'])]

    def run(key, dn):
        dn = set(dn)
        seq = []
        while True:
            c = [i for i in avail(dn) if _g_reglage(steps[i]) == key]
            if not c:
                return seq
            i = min(c)
            dn.add(i)
            seq.append(i)

    cur = None
    while len(order) < n:
        av = avail(done)
        if not av:      # ne devrait pas arriver : on garde l'ordre d'origine
            order += [i for i in rest if i not in done]
            break
        seq = run(cur, done) if cur is not None else []
        if not seq:
            best = None
            for key in sorted(set(_g_reglage(steps[i]) for i in av), key=lambda k: min(i for i in av if _g_reglage(steps[i]) == k)):
                sq = run(key, done)
                if best is None or len(sq) > len(best[1]):
                    best = (key, sq)
            cur, seq = best
        for i in seq:
            done.add(i)
            order.append(i)
    return [steps[i] for i in order]


def _g_plan(strips, U, V, sp, m, full_u):
    """Ordre logique des coupes a la scie a format, dans le repere de travail :
    toutes les coupes prioritaires d'abord, puis chaque bande est tronconnee
    (colonnes), chaque troncon refendu (rangees) et chaque rangee recoupee et
    mise a largeur. Renvoie (etapes, rectangles des pieces dans l'ordre des
    placements). Etape : {'kind', 'cut': (u1, v1, u2, v2), 'zone': (u, v, a, b),
    'dim', 'strip', 'pieces': [indices des pieces liberees]}."""
    eps = 1e-6
    steps = []
    prect = []

    def add(kind, cut, zone, dim, k, req=()):
        steps.append({'kind': kind, 'cut': cut, 'zone': zone, 'dim': dim, 'strip': k + 1, 'pieces': [],
                      'req': [r for r in req if r is not None]})
        return len(steps) - 1

    for k, s in enumerate(strips):
        v_end = s['v'] + s['H']
        if v_end + sp / 2.0 < V - eps:
            vc = v_end + sp / 2.0
            add('prim', (-m, vc, full_u - m, vc), (0.0, s['v'], U, s['H']), s['H'], k)
    # indices des pieces dans l'ordre des placements (ordre d'origine)
    n_idx = 0
    s_cols = []
    for s in strips:
        cols = []
        for c in s['cols']:
            rows = []
            for r in c['rows']:
                pcs = []
                for pc in r['pcs']:
                    pcs.append(tuple(pc) + (n_idx,))
                    n_idx += 1
                rows.append({'v': r['v'], 'h': r['h'], 'pcs': pcs})
            cols.append({'u': c['u'], 'w': c['w'], 'rows': rows})
        s_cols.append(_g_merge_cols(cols, sp))
    prect = [None] * n_idx

    for k, s in enumerate(strips):
        v_end = s['v'] + s['H']
        lo = s['v'] - (sp / 2.0 if k else m)
        hi = v_end + sp / 2.0 if v_end + sp / 2.0 < V - eps else V + m
        ncol = len(s_cols[k])
        prev_t = None
        for ci, c in enumerate(s_cols[k]):
            uc = c['u'] + c['w'] + sp / 2.0
            has_c = uc < U - eps
            w0 = c['w']
            if has_c and ci == ncol - 1:
                # dernier troncon de la bande (demande du 2026-11-19) : pas de
                # coupe pour une petite chute en bout de bande, on coupe
                # jusqu'au bout du panneau ; grande chute : coupe avec une
                # marge de securite, la mise a longueur se fait apres.
                reste = U - (c['u'] + c['w'] + sp)
                if reste < CHUTE_UTILE:
                    c = dict(c, w=U - c['u'])
                    has_c = False
                else:
                    c = dict(c, w=c['w'] + MARGE_CHUTE)
                    uc = c['u'] + c['w'] + sp / 2.0
            # troncon d'une seule rangee pleine hauteur avec plusieurs pieces qui
            # remplissent sa longueur : pas de coupe pour detacher le troncon, les
            # pieces sont coupees directement a longueur depuis le bout de la
            # bande (demande du 2026-11-19 : 2 x 1425 puis 10 x 280 -> 10 x 280)
            rows0 = c['rows']
            if (has_c and len(rows0) == 1 and rows0[0]['v'] < eps and len(rows0[0]['pcs']) > 1
                    and max(pc[1] + pc[3] for pc in rows0[0]['pcs']) >= w0 - 1e-3):
                # une seule rangee moins large que la bande : on coupe d'abord les
                # pieces a longueur sur toute la largeur de la bande, puis on les
                # deligne (meme demande : longueur d'abord, reprise en largeur apres)
                c = dict(c, rows=[dict(rows0[0], h=s['H'])])
                rows0 = c['rows']
            direct = (has_c and len(rows0) == 1 and len(rows0[0]['pcs']) > 1
                      and not (rows0[0]['v'] + rows0[0]['h'] + sp / 2.0 < s['H'] - eps)
                      and max(pc[1] + pc[3] for pc in rows0[0]['pcs']) >= w0 - 1e-3)
            t_id = None
            if has_c and not direct:
                t_id = add('trons', (uc, lo, uc, hi), (c['u'], s['v'], c['w'], s['H']), c['w'], k, [prev_t])
            col_req = [t_id, prev_t]
            prev_t = t_id if t_id is not None else prev_t
            cu_lo = c['u'] - (sp / 2.0 if ci else m)
            cu_hi = uc if has_c else U + m
            rows = c['rows']
            # toutes les refentes du troncon d'abord, puis chaque bande en
            # pieces (demande du 2026-11-19 : 3 bandes a 46, puis 3 pieces
            # a 501,3 sur chacune)
            ref_ids = []
            prev_r = None
            for ri, r in enumerate(rows):
                rv = s['v'] + r['v']
                rh = r['h']
                r_end = rv + rh
                ref_ids.append(None)
                if r['v'] + rh + sp / 2.0 < s['H'] - eps:
                    prev_r = ref_ids[-1] = add('refente', (cu_lo, r_end + sp / 2.0, cu_hi, r_end + sp / 2.0),
                                               (c['u'], rv, c['w'], rh), rh, k, col_req + [prev_r])
                    nxt = rows[ri + 1] if ri + 1 < len(rows) else None
                    # derniere refente : la chute restante fait-elle aussi rh ?
                    if nxt is not None and ri + 1 == len(rows) - 1 and abs(nxt['h'] - rh) < 1e-3 \
                            and not (nxt['v'] + nxt['h'] + sp / 2.0 < s['H'] - eps):
                        steps[-1]['extra'] = 1
            for ri, r in enumerate(rows):
                rv = s['v'] + r['v']
                rh = r['h']
                r_end = rv + rh
                has_r = r['v'] + rh + sp / 2.0 < s['H'] - eps
                rlo = rv - sp / 2.0 if ri else lo
                rhi = r_end + sp / 2.0 if has_r else hi
                # rangee detachee : refentes de ses deux bords (ou la derniere avant elle)
                row_req = col_req + [ref_ids[ri]] + [x for x in ref_ids[:ri] if x is not None][-1:]
                prev_p = None
                for pi, (t, du, dv, a, b, rot, idx) in enumerate(r['pcs']):
                    pu = c['u'] + du
                    pe = pu + a
                    has_p = du + a + sp / 2.0 < c['w'] - eps or (direct and pi == len(r['pcs']) - 1)
                    p_id = None
                    if has_p:
                        p_id = add('recoupe', (pe + sp / 2.0, rlo, pe + sp / 2.0, rhi), (pu, rv, a, rh), a, k,
                                   row_req + [prev_p])
                        steps[p_id]['lp'] = [idx]   # piece mise a longueur (meme si encore a deligner)
                    if b < rh - eps:
                        pu_lo = pu - sp / 2.0 if pi else cu_lo
                        pu_hi = pe + sp / 2.0 if has_p else cu_hi
                        add('ajust', (pu_lo, rv + b + sp / 2.0, pu_hi, rv + b + sp / 2.0), (pu, rv, a, b), b, k,
                            row_req + [p_id, prev_p])
                    prev_p = p_id if p_id is not None else prev_p
                    prect[idx] = (pu, rv + dv, a, b)
                if direct:
                    prev_t = prev_p     # le troncon suivant vient apres la derniere piece
    steps = _g_par_reglage(steps)
    # piece liberee par la derniere coupe qui longe un de ses bords
    tol = sp / 2.0 + 1e-3
    for i, (pu, pv, a, b) in enumerate(prect):
        last = None
        for j, st in enumerate(steps):
            u1, v1, u2, v2 = st['cut']
            if abs(v1 - v2) < eps:      # coupe le long de u
                if min(u1, u2) < pu + a - eps and max(u1, u2) > pu + eps and \
                        (abs(v1 - pv) <= tol or abs(v1 - (pv + b)) <= tol):
                    last = j
            else:
                if min(v1, v2) < pv + b - eps and max(v1, v2) > pv + eps and \
                        (abs(u1 - pu) <= tol or abs(u1 - (pu + a)) <= tol):
                    last = j
        if last is not None:
            steps[last]['pieces'].append(i)
    return steps, prect


def _g_used(strips):
    if not strips:
        return 0.0
    s = strips[-1]
    return s['v'] + s['H']


def nest_guillotine(parts, L, W, o, tick=None):
    """Placement par bandes guillotine (voir plus haut). o : options de nest
    + 'coupes' ('horizontales' / 'verticales') et 'niveaux' (1 a 3) ou
    'bandes_max' (nombre maximal de bandes par panneau)."""
    t0 = time.time()
    m = max(0.0, float(o['margin']))
    sp = max(0.0, float(o['spacing']))
    sens = o.get('coupes') if o.get('coupes') in GUILLO_DIRS else 'horizontales'
    levels = max(1, min(3, int(o.get('niveaux', 2) or 2)))
    max_strips = int(o.get('bandes_max', 0) or 0) or 10 ** 6
    rots = [r % 360 for r in (o.get('rotations') or [0])]
    allow90 = any(r in (90, 270) for r in rots)
    horiz = sens == 'horizontales'
    U = (L if horiz else W) - 2 * m
    V = (W if horiz else L) - 2 * m
    corner = o.get('corner', 'bas_gauche')

    by_id = {p['id']: p for p in parts}
    insts = _prepare(parts, o)
    area = {}
    for p in parts:
        area[p['id']] = sum(abs(ring_area(reg[0])) - sum(abs(ring_area(r)) for r in reg[1:])
                            for reg in p['regions'] if reg)
        x0, y0, x1, y1 = regions_bbox(p['regions'])
        for t in insts:
            if t['id'] == p['id']:
                # dimensions le long de u (a) et en travers (b) a rotation 0
                dx, dy = x1 - x0, y1 - y0
                t['_gw'], t['_gh'] = (dx, dy) if horiz else (dy, dx)
    unplaced = []
    ok = []
    eps = 1e-6
    for t in insts:
        if any(a <= U + eps and b <= V + eps for a, b, _r in _g_orients(t, allow90)):
            ok.append(t)
        else:
            unplaced.append({'id': t['id'], 'name': t['name'], 'inst': t['inst'],
                             'reason': 'trop grande pour le panneau'})

    def keyed(how):
        if how == 'surface':
            return sorted(ok, key=lambda t: (-t['_gw'] * t['_gh'], t['name'], t['inst']))
        if how == 'long':
            return sorted(ok, key=lambda t: (-max(t['_gw'], t['_gh']), -min(t['_gw'], t['_gh']), t['name'], t['inst']))
        if how == 'large':
            return sorted(ok, key=lambda t: (-min(t['_gw'], t['_gh']), -max(t['_gw'], t['_gh']), t['name'], t['inst']))
        if how in ('nom', 'composant'):
            return _order(ok, how)
        return sorted(ok, key=lambda t: (-t['_gh'], -t['_gw'], t['name'], t['inst']))

    rapide = o.get('tri') == 'rapidite'
    if rapide:
        # Rapidite : les pieces de meme largeur se suivent (memes bandes,
        # meme panneau) ; groupes du plus large au plus etroit, ou du plus
        # nombreux au moins nombreux
        def wid(t):
            ws = [b for a, b, _r in _g_orients(t, allow90) if a <= U + eps and b <= V + eps]
            return round(min(ws), 1)
        cnt = {}
        for t in ok:
            cnt[wid(t)] = cnt.get(wid(t), 0) + 1
        ord_w = sorted(ok, key=lambda t: (-wid(t), -max(t['_gw'], t['_gh']), t['name'], t['inst']))
        ord_n = sorted(ok, key=lambda t: (-cnt[wid(t)], -wid(t), -max(t['_gw'], t['_gh']), t['name'], t['inst']))
        orders = ['_w', '_n']
        prefs = ('rapide',)
    else:
        orders = ['surface', 'long', 'large', 'haut']
        if o.get('order') in ('nom', 'composant'):
            orders = [o['order']] + orders
        prefs = ('longue', 'courte', 'meilleur') if allow90 else ('meilleur',)
    best = None
    for how in orders:
        base = ord_w if how == '_w' else ord_n if how == '_n' else keyed(how)
        for pref in prefs:
            rem = base
            sheets = []
            while rem:
                strips, rem2 = _g_fill_sheet(rem, U, V, sp, levels, max_strips, pref, allow90)
                if not strips:
                    break
                sheets.append(strips)
                rem = rem2
                if tick:
                    tick()
            if rem:
                continue
            # moins de panneaux, puis dernier panneau le moins entame
            sc = (len(sheets), _g_used(sheets[-1]) if sheets else 0.0)
            if rapide:
                # puis le moins de bandes (reglages de la scie)
                # le moins de reglages de la scie d'abord (largeurs de bande
                # differentes sur chaque panneau), puis de panneaux, de bandes
                sc = (sum(len(set(round(st['H'], 1) for st in x)) for x in sheets), len(sheets),
                      sum(len(x) for x in sheets), sc[1])
            if best is None or sc < best[0]:
                best = (sc, sheets)
    sheets = best[1] if best else []

    def to_xy(u, v, a, b):
        """Rectangle (u, v, a, b) du repere de travail -> (x, y, dx, dy) du
        panneau brut, coin de depart applique."""
        if horiz:
            x, y, dx, dy = m + u, m + v, a, b
        else:
            x, y, dx, dy = m + v, m + u, b, a
        if 'droite' in corner:
            x = L - x - dx
        if 'haut' in corner:
            y = W - y - dy
        return x, y, dx, dy

    def seg_xy(u1, v1, u2, v2):
        x1, y1, _a, _b = to_xy(u1, v1, 0.0, 0.0)
        x2, y2, _a, _b = to_xy(u2, v2, 0.0, 0.0)
        return [[round(x1, 2), round(y1, 2)], [round(x2, 2), round(y2, 2)]]

    out_sheets = []
    tot_area = 0.0
    n_parts = 0
    full_u = (L if horiz else W)
    for si, strips in enumerate(sheets):
        pls = []
        cuts = []
        bandes = []
        s_area = 0.0
        for k_s, s in enumerate(strips):
            v_end = s['v'] + s['H']
            # largeur de la bande (pieces), pour les cotes du PDF
            bx, by, bdx, bdy = to_xy(0.0, s['v'], 0.0, s['H'])
            if horiz:
                bandes.append({'axis': 'y', 'a': round(by, 2), 'b': round(by + bdy, 2)})
            else:
                bandes.append({'axis': 'x', 'a': round(bx, 2), 'b': round(bx + bdx, 2)})
            # coupe prioritaire au milieu du trait de scie, de bout en bout du
            # panneau brut (sauf si la bande touche la marge du haut)
            if v_end + sp / 2.0 < V - eps:
                vc = v_end + sp / 2.0
                cuts.append({'level': 1, 'seg': seg_xy(-m, vc, full_u - m, vc)})
            v_lo = s['v'] - (sp / 2.0 if k_s else m)
            for k_c, c in enumerate(s['cols']):
                uc = c['u'] + c['w'] + sp / 2.0
                if uc < U - eps:
                    cuts.append({'level': 2, 'seg': seg_xy(uc, v_lo, uc, v_end + sp / 2.0)})
                for r in c['rows']:
                    for (t, du, dv, a, b, rot) in r['pcs']:
                        x, y, dx, dy = to_xy(c['u'] + du, s['v'] + r['v'] + dv, a, b)
                        p = by_id[t['id']]
                        rr = 0 if rot == 0 else 90
                        reg = transform_regions(p['regions'], rr, 0.0, 0.0)
                        bx0, by0, _bx1, _by1 = regions_bbox(reg)
                        pls.append({'id': t['id'], 'name': t['name'], 'inst': t['inst'],
                                    'rot': float(rr), 'tx': x - bx0, 'ty': y - by0, 'flip': False})
                        s_area += area[t['id']]
                        n_parts += 1
        tot_area += s_area
        steps, _pr = _g_plan(strips, U, V, sp, m, full_u)
        plan = []
        for st in steps:
            zx, zy, zdx, zdy = to_xy(*st['zone'])
            plan.append({'kind': st['kind'], 'seg': seg_xy(*st['cut']), 'dim': round(st['dim'], 1),
                         'strip': st['strip'], 'pieces': st['pieces'], 'extra': st.get('extra', 0),
                         'lp': st.get('lp', []),
                         'zone': [round(zx, 2), round(zy, 2), round(zdx, 2), round(zdy, 2)]})
        out_sheets.append({'index': si + 1, 'placements': pls, 'cuts': cuts, 'bandes': bandes, 'plan': plan,
                           'util': s_area / (L * W)})
    return {
        'sheets': out_sheets,
        'unplaced': unplaced,
        'stats': {'n_sheets': len(out_sheets), 'n_parts': n_parts, 'n_pairs': 0,
                  'policy': {'coupes': sens, 'niveaux': levels, 'tri': 'rapidite' if rapide else 'quantite'}, 'n_runs': len(orders) * len(prefs),
                  'time_s': round(time.time() - t0, 2),
                  'util': (tot_area / (L * W * len(out_sheets))) if out_sheets else 0.0,
                  'mode': 'rectangulaire', 'L': L, 'W': W, 'margin': m},
    }
