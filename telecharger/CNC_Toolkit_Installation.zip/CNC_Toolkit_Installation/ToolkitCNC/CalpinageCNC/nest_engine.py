# ---------------------------------------------------------------------------
# Moteur de placement de Calpinage CNC (nesting), en Python pur : aucune
# dependance a Fusion (adsk) ni a une bibliotheque externe, pour pouvoir le
# tester hors de Fusion (voir test_nest_engine.py).
#
# ENTREE : des pieces decrites en 2D (mm), chacune par une liste de REGIONS ;
# une region = liste d'anneaux (contour exterieur puis trous), remplie en
# pair-impair. Cote Fusion, une region = une face plane parallele au panneau
# (dessus, fond de poche, dessus de tenon...) : l'union des regions donne la
# silhouette vue de dessus, les trous traversants restent vides.
#
# PRINCIPE
#   - Chaque piece est RASTERISEE sur une grille (pas = step mm) de facon
#     conservatrice : une cellule touchee par la piece est pleine.
#   - Une ligne de grille = un entier Python utilise en masque de bits (bit
#     i = colonne i). Tester une collision = ET binaire ligne par ligne.
#   - Espacement : la piece testee est grossie d'un disque de k cellules
#     (k = ceil(espacement / pas) + 1), les pieces deja posees restent a
#     leur taille reelle.
#   - Placement bas-gauche (Bottom-Left-Fill) dans un repere CANONIQUE ou
#     l'on remplit les y croissants puis les x croissants. Le coin de depart
#     et la direction de tassement sont obtenus par symetrie / transposition
#     de TOUT (panneau ET pieces), puis on revient au repere du panneau.
#   - Une piece n'est retournee (miroir y -> -y) que si opts['flip'] et
#     part['flippable'] : le placement porte alors 'flip': True.
#   - Pour un y donne, les x interdits se calculent d'un coup : pour chaque
#     bande de lignes identiques du masque grossi, OU des lignes du panneau
#     (table creuse) puis dilatation par chaque segment de la ligne.
# ---------------------------------------------------------------------------
import itertools
import math
import random
import time

WIDE_N = 1   # nombre de segments longs testes avant le calcul complet (find)

MODES = ('rectangulaire', 'imbrique', 'imbrique_trous', 'optimise')
CORNERS = ('bas_gauche', 'bas_droite', 'haut_gauche', 'haut_droite')

DEFAULT_OPTS = {
    'mode': 'imbrique',
    'margin': 10.0,         # marge en bordure de panneau (mm)
    'spacing': 10.0,        # espacement entre pieces (mm)
    'corner': 'bas_gauche',
    'compact': 'x',         # 'x' : chute en bout de panneau ; 'y' : sur la largeur
    'order': 'surface',     # 'surface', 'nom', 'composant'
    'rotations': (0, 90, 180, 270),
    'fill': 'panneau',      # 'panneau' (premier panneau rempli au max) ou 'equilibre'
    'time_limit': 30.0,     # mode optimise (s)
    'step': 1.0,            # pas de la grille (mm)
    'seed': 1,
    'flip': False,          # autoriser a retourner les pieces 'flippable' (miroir y -> -y)
}


# --- Geometrie 2D -------------------------------------------------------------

def ring_area(r):
    a = 0.0
    n = len(r)
    for i in range(n):
        x1, y1 = r[i]
        x2, y2 = r[(i + 1) % n]
        a += x1 * y2 - x2 * y1
    return a / 2.0


def regions_bbox(regions):
    xs = [p[0] for reg in regions for ring in reg for p in ring]
    ys = [p[1] for reg in regions for ring in reg for p in ring]
    return min(xs), min(ys), max(xs), max(ys)


def _mat_mul(a, b):
    return [[sum(a[i][k] * b[k][j] for k in range(3)) for j in range(3)] for i in range(3)]


def _mat_apply(m, x, y):
    return (m[0][0] * x + m[0][1] * y + m[0][2], m[1][0] * x + m[1][1] * y + m[1][2])


def _mat_inv_affine(m):
    a, b, c = m[0]
    d, e, f = m[1]
    det = a * e - b * d
    ia, ib, id_, ie = e / det, -b / det, -d / det, a / det
    return [[ia, ib, -(ia * c + ib * f)], [id_, ie, -(id_ * c + ie * f)], [0.0, 0.0, 1.0]]


def _rot_mat(deg):
    t = math.radians(deg)
    c, s = math.cos(t), math.sin(t)
    if abs(c) < 1e-12:
        c = 0.0
    if abs(s) < 1e-12:
        s = 0.0
    return [[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]]


def frame_matrix(L, W, corner, compact):
    """Matrice affine panneau -> repere canonique (y rempli en premier).
    Symetries pour le coin, puis transposition si l'on tasse vers x."""
    m = [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]]
    if corner in ('bas_droite', 'haut_droite'):
        m = _mat_mul([[-1.0, 0.0, L], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]], m)
    if corner in ('haut_gauche', 'haut_droite'):
        m = _mat_mul([[1.0, 0.0, 0.0], [0.0, -1.0, W], [0.0, 0.0, 1.0]], m)
    if compact == 'x':
        m = _mat_mul([[0.0, 1.0, 0.0], [1.0, 0.0, 0.0], [0.0, 0.0, 1.0]], m)
    return m


def transform_regions(regions, rot_deg, tx, ty, flip=False):
    """Applique la pose d'une piece (retournement eventuel y -> -y, puis
    rotation autour de l'origine locale, puis translation) - meme convention
    que les placements renvoyes par nest()."""
    t = math.radians(rot_deg)
    c, s = math.cos(t), math.sin(t)
    f = -1.0 if flip else 1.0
    return [[[(c * x - s * f * y + tx, s * x + c * f * y + ty) for (x, y) in ring] for ring in reg]
            for reg in regions]


# --- Rasterisation -------------------------------------------------------------

def _bits(a, b):
    return ((1 << (b - a + 1)) - 1) << a


def raster(regions, step, fill_holes=True, as_rect=False):
    """Masque conservateur des regions (deja placees en x, y >= 0).
    Renvoie (w, h, rows) : rows[j] = entier, bit i = cellule (i, j)."""
    x0, y0, x1, y1 = regions_bbox(regions)
    w = max(1, int(math.ceil((x1 - 1e-9) / step)))
    h = max(1, int(math.ceil((y1 - 1e-9) / step)))
    if as_rect:
        full = _bits(0, w - 1)
        return w, h, [full] * h
    rows = [0] * h

    def cell(v, n):
        i = int(math.floor(v / step))
        return 0 if i < 0 else (n - 1 if i >= n else i)

    for reg in regions:
        rings = reg[:1] if fill_holes else reg
        edges = []
        for ring in rings:
            n = len(ring)
            for i in range(n):
                edges.append((ring[i], ring[(i + 1) % n]))
        # 1) interieur : coupe au milieu de chaque rangee (pair-impair).
        # Chaque arete ne visite que les rangees qu'elle traverse (meme test
        # et meme calcul que le balayage de toutes les aretes par rangee).
        cuts = [[] for _ in range(h)]
        for (ax, ay), (bx, by) in edges:
            if ay == by:
                continue
            lo, hi = (ay, by) if ay < by else (by, ay)
            j0 = max(0, int(math.floor(lo / step - 0.5)) - 1)
            j1 = min(h - 1, int(math.ceil(hi / step - 0.5)) + 1)
            for j in range(j0, j1 + 1):
                yc = (j + 0.5) * step
                if (ay <= yc < by) or (by <= yc < ay):
                    cuts[j].append(ax + (yc - ay) * (bx - ax) / (by - ay))
        for j in range(h):
            xs = cuts[j]
            xs.sort()
            row = rows[j]
            for k in range(0, len(xs) - 1, 2):
                row |= _bits(cell(xs[k], w), cell(xs[k + 1], w))
            rows[j] = row
        # 2) bord : toutes les cellules traversees par chaque arete
        for (ax, ay), (bx, by) in edges:
            ja, jb = cell(min(ay, by), h), cell(max(ay, by), h)
            for j in range(ja, jb + 1):
                lo, hi = j * step, (j + 1) * step
                if abs(by - ay) < 1e-12:
                    xa, xb = ax, bx
                else:
                    ta = (max(lo, min(ay, by)) - ay) / (by - ay)
                    tb = (min(hi, max(ay, by)) - ay) / (by - ay)
                    xa = ax + ta * (bx - ax)
                    xb = ax + tb * (bx - ax)
                ca, cb = cell(min(xa, xb), w), cell(max(xa, xb), w)
                rows[j] |= _bits(ca, cb)
    return w, h, rows


def _dil_right(v, n):
    """OU de v >> t pour t dans [0, n-1] (doublement, log2(n) operations)."""
    acc, cover = v, 1
    while cover < n:
        sh = min(cover, n - cover)
        acc |= acc >> sh
        cover += sh
    return acc


def _dil_plan(n):
    """Decalages successifs de _dil_right(v, n) (calcules une fois par n)."""
    plan, cover = [], 1
    while cover < n:
        sh = min(cover, n - cover)
        plan.append(sh)
        cover += sh
    return tuple(plan)


def _dil_left(v, n):
    acc, cover = v, 1
    while cover < n:
        sh = min(cover, n - cover)
        acc |= acc << sh
        cover += sh
    return acc


def dilate(w, h, rows, k):
    """Grossit le masque d'un disque de rayon k cellules. Le resultat a
    h + 2k lignes et w + 2k colonnes (decalage de k)."""
    if k <= 0:
        return w, h, list(rows)
    memo = {}

    def hdil(v, r):
        key = (v, r)
        if key not in memo:
            memo[key] = _dil_left(v << k, 2 * r + 1) >> r
        return memo[key]

    radius = [int(math.sqrt((k + 0.5) ** 2 - d * d)) for d in range(k + 1)]
    out = [0] * (h + 2 * k)
    # Par suite de lignes identiques (v sur [i0, i1[) : la dilatation
    # horizontale de rayon r est incluse dans celle de rayon r' >= r, et le
    # rayon decroit avec l'ecart vertical. Une ligne de sortie recoit donc
    # seulement le terme de l'ecart le plus petit : rayon plein dans la
    # suite, rayon radius[t] a t lignes au-dessus / au-dessous. Meme
    # resultat que la double boucle (ligne x ecart), bien moins d'operations.
    n = len(rows)
    i = 0
    while i < n:
        v = rows[i]
        i0 = i
        while i < n and rows[i] == v:
            i += 1
        if not v:
            continue
        full = hdil(v, radius[0])
        for j in range(i0 + k, i + k):
            out[j] |= full
        for t in range(1, k + 1):
            r = hdil(v, radius[t])
            out[i0 + k - t] |= r
            out[i - 1 + k + t] |= r
    return w + 2 * k, h + 2 * k, out


def _runs(v):
    """Segments de bits a 1 : liste de (debut, longueur)."""
    out = []
    i = 0
    while v:
        if v & 1:
            n = (~v & (v + 1)).bit_length() - 1   # nombre de 1 en bas
            v >>= n
            out.append((i, n))
            i += n
        else:
            z = (v & -v).bit_length() - 1
            v >>= z
            i += z
    return out


def _popcount(v):
    return bin(v).count('1')


# --- Forme preparee (piece x rotation) ----------------------------------------

class _Shape(object):
    """Piece dans une rotation donnee, dans le repere canonique : masques
    reel et grossi, bandes de lignes identiques, decalage d'origine."""

    def __init__(self, regions, rot, lin, step, k, fill_holes, as_rect, flip=False):
        # lin : partie lineaire du repere canonique ; rot applique ensuite.
        # flip : la piece est d'abord retournee (y -> -y, en local).
        m = _mat_mul(_rot_mat(rot), [[lin[0][0], lin[0][1], 0.0], [lin[1][0], lin[1][1], 0.0], [0, 0, 1.0]])
        if flip:
            m = _mat_mul(m, [[1.0, 0.0, 0.0], [0.0, -1.0, 0.0], [0.0, 0.0, 1.0]])
        self.flip = flip
        regs = [[[_mat_apply(m, x, y) for (x, y) in ring] for ring in reg] for reg in regions]
        x0, y0, _, _ = regions_bbox(regs)
        regs = [[[(x - x0, y - y0) for (x, y) in ring] for ring in reg] for reg in regs]
        self.rot = rot
        self.lin = m
        self.off = (x0, y0)
        self.w, self.h, self.raw = raster(regs, step, fill_holes, as_rect)
        _, _, self.dil = dilate(self.w, self.h, self.raw, k)
        if as_rect:
            _, _, true_raw = raster(regs, step, fill_holes, False)
        else:
            true_raw = self.raw
        self.cells = sum(_popcount(v) for v in true_raw)
        bands = []
        j = 0
        n = len(self.dil)
        while j < n:
            v = self.dil[j]
            j0 = j
            while j < n and self.dil[j] == v:
                j += 1
            if v:
                cnt = j - j0
                p = cnt.bit_length() - 1
                runs = _runs(v)
                bands.append((v, j0, cnt, tuple((a, _dil_plan(ln)) for a, ln in runs),
                              p, cnt - (1 << p), sum(ln for _a, ln in runs)))
        # la bande la plus large en premier : c'est elle qui bloque le plus
        # souvent, la boucle de find() s'arrete plus tot (resultat identique)
        bands.sort(key=lambda b: -b[6])
        self.bands = [b[:6] for b in bands]
        # segments les plus longs (lignes j0..j0+cnt-1) : filtre rapide de
        # find(). Un par bande, les WIDE_N plus longs.
        wide = []
        for v, j0, cnt, runs, _p, _o in self.bands:
            ln = max(1 + sum(plan) for _a, plan in runs)
            wide.append((ln, cnt, j0))
        wide.sort(reverse=True)
        self.wide = [(j0, cnt, ln) for ln, cnt, j0 in wide[:WIDE_N]]
        self.memo = {}


# --- Panneau -------------------------------------------------------------------

class _Sheet(object):
    def __init__(self, Wu, Hu, k):
        self.Wu, self.Hu, self.k = Wu, Hu, k
        self.occ = [0] * (Hu + 2 * k)
        self.items = []
        self.cells = 0
        self._table = None
        # y de depart par forme : le panneau ne fait que se remplir, donc une
        # position refusee le reste. On reprend la recherche au dernier y
        # trouve (None = la forme n'y rentre plus). Resultat identique.
        self.hint = {}
        self._runs_ok = {}

    def table(self):
        if self._table is None:
            t = [self.occ]
            p = 1
            n = len(self.occ)
            while (1 << p) <= n:
                prev = t[-1]
                half = 1 << (p - 1)
                t.append([prev[i] | prev[i + half] for i in range(n - (1 << p) + 1)])
                p += 1
            self._table = t
        return self._table

    def range_or(self, lo, hi):
        t = self.table()
        n = hi - lo + 1
        p = n.bit_length() - 1
        return t[p][lo] | t[p][hi - (1 << p) + 1]

    def last_bad(self, ln):
        """last_bad[r] : derniere ligne <= r du panneau sans aucun segment
        libre de ln cellules (-1 si aucune). Une forme dont un segment fait
        ln cellules ne peut couvrir aucune de ces lignes."""
        lb = self._runs_ok.get(ln)
        if lb is None:
            full = (1 << (self.Wu + 2 * self.k)) - 1
            plan = _dil_plan(ln)
            memo = {}
            lb = []
            last = -1
            for r, o in enumerate(self.occ):
                ok = memo.get(o)
                if ok is None:
                    e = ~o & full
                    for d in plan:
                        e &= e >> d
                    ok = memo[o] = bool(e)
                if not ok:
                    last = r
                lb.append(last)
            self._runs_ok[ln] = lb
        return lb

    def find(self, sh, y_max=None):
        """Premiere position (y le plus bas, puis x le plus a gauche) ou la
        forme rentre. None si elle ne rentre pas (ou pas avec y <= y_max)."""
        if sh.w > self.Wu or sh.h > self.Hu:
            return None
        y_start = self.hint.get(sh, 0)
        if y_start is None:
            return None
        y_end = self.Hu - sh.h
        limited = y_max is not None and y_max < y_end
        if limited:
            y_end = y_max
        xmask = (1 << (self.Wu - sh.w + 1)) - 1
        table = self.table()
        bands = [(bi, j0, table[p], off, runs) for bi, (v, j0, cnt, runs, p, off) in enumerate(sh.bands)]
        last_s = [None] * len(bands)   # d'un y au suivant, s change rarement
        last_f = [0] * len(bands)
        filt = [(j0, j0 + cnt - 1, self.last_bad(ln)) for j0, cnt, ln in sh.wide]
        y = y_start - 1
        while y < y_end:
            y += 1
            skip = False
            for wj0, wj1, lb in filt:
                b = lb[y + wj1]
                if b >= y + wj0:
                    # une ligne de la fenetre n'a pas la place : saute apres elle
                    y = b - wj0
                    skip = True
                    break
            if skip:
                continue
            forb = 0
            for bi, j0, tp, off, runs in bands:
                i = y + j0
                s = tp[i] | tp[i + off]
                if not s:
                    continue
                if s == last_s[bi]:
                    forb |= last_f[bi]
                    if forb & xmask == xmask:
                        break
                    continue
                # (pas de memo par valeur de s : mesure sur un vrai
                # calpinage, presque jamais de doublon, le dict coutait)
                f = 0
                for a, plan in runs:
                    acc = s
                    for d in plan:
                        acc |= acc >> d
                    f |= acc >> a
                last_s[bi] = s
                last_f[bi] = f
                forb |= f
                if forb & xmask == xmask:
                    break
            allowed = xmask & ~forb
            if allowed:
                self.hint[sh] = y
                return (allowed & -allowed).bit_length() - 1, y
        if not limited:
            self.hint[sh] = None
        elif y_end + 1 > y_start:
            self.hint[sh] = y_end + 1
        return None

    def place(self, sh, x, y, item):
        k = self.k
        for j, v in enumerate(sh.raw):
            if v:
                self.occ[y + k + j] |= v << (x + k)
        self.cells += sh.cells
        self.items.append(item)
        self._table = None
        self._runs_ok = {}

    def top(self):
        return max([it['_y'] + it['_h'] for it in self.items] or [0])


# --- Nesting -------------------------------------------------------------------

CURVED_FILL = 0.5   # surface / surface du rectangle englobant sous ce seuil : piece courbe


def _fill_ratio(p):
    x0, y0, x1, y1 = regions_bbox(p['regions'])
    bb = (x1 - x0) * (y1 - y0)
    if bb <= 0:
        return 1.0
    a = 0.0
    for reg in p['regions']:
        a += abs(ring_area(reg[0])) - sum(abs(ring_area(h)) for h in reg[1:])
    return a / bb


def _prepare(parts, opts):
    insts = []
    for p in parts:
        q = max(1, int(p.get('qty', 1) or 1))
        x0, y0, x1, y1 = regions_bbox(p['regions'])
        bbox_area = (x1 - x0) * (y1 - y0)
        bbox_long = max(x1 - x0, y1 - y0)
        for i in range(q):
            insts.append({'id': p['id'], 'name': p.get('name', p['id']), 'comp': p.get('comp', ''),
                          'inst': i, 'bbox_area': bbox_area, 'bbox_long': bbox_long})
    return insts


def _order(insts, how):
    if how == 'nom':
        return sorted(insts, key=lambda t: (t['name'], t['inst']))
    if how == 'composant':
        tot = {}
        for t in insts:
            tot[t['comp']] = tot.get(t['comp'], 0) + t['bbox_area']
        return sorted(insts, key=lambda t: (-tot[t['comp']], t['comp'], -t['bbox_area'], t['name']))
    return sorted(insts, key=lambda t: (-t['bbox_area'], t['name'], t['inst']))


def _fits(sheet, sh, x, y):
    if x < 0 or y < 0 or x + sh.w > sheet.Wu or y + sh.h > sheet.Hu:
        return False
    occ = sheet.occ
    for j, d in enumerate(sh.dil):
        if d and occ[y + j] & (d << x):
            return False
    return True


def _pin(sheet, insts, shapes_for, axis):
    """Pose les pieces insts contre le bord oppose au depart du placement
    (axis 'y' : en haut du repere, par rangees ; 'x' : a droite, par
    colonnes), a plat le long de ce bord. Les autres pieces viendront ensuite
    depuis le depart : une longue piece ne coupe plus le panneau en deux.
    Renvoie False si une piece ne trouve pas sa place."""
    k, Wu, Hu = sheet.k, sheet.Wu, sheet.Hu
    a, b, rb = 0, (Hu if axis == 'y' else Wu), 0   # avance le long du bord, bord courant, epaisseur
    for t in insts:
        shapes = [sh for sh in shapes_for(t['id']) if sh.w <= Wu and sh.h <= Hu]
        if not shapes:
            return False
        if axis == 'y':
            sh = min(shapes, key=lambda s: (s.h, s.flip))
            ln, th = sh.w, sh.h
            lim = Wu
        else:
            sh = min(shapes, key=lambda s: (s.w, s.flip))
            ln, th = sh.h, sh.w
            lim = Hu
        if a and a + ln > lim:
            a, b, rb = 0, b - rb - k, 0
        x, y = (a, b - th) if axis == 'y' else (b - th, a)
        if not _fits(sheet, sh, x, y):
            return False
        sheet.place(sh, x, y, {'t': t, 'sh': sh, '_x': x, '_y': y, '_h': sh.h})
        a, rb = a + ln + k, max(rb, th)
    return True


def _run(insts, rot_order, shapes_for, Wu, Hu, k, fill, n_balanced=0, deadline=None, tick=None, pin=None):
    """Une passe de placement. Renvoie (sheets, unplaced). tick() est appele
    a chaque piece (fenetre de chargement de Fusion). pin : pieces posees
    d'abord en haut du 1er panneau (voir _pin)."""
    sheets = [_Sheet(Wu, Hu, k) for _ in range(n_balanced)]
    unplaced = []
    if pin:
        if not sheets:
            sheets.append(_Sheet(Wu, Hu, k))
        if not _pin(sheets[0], pin[1], shapes_for, pin[0]):
            return [], [{'id': t['id']} for t in insts]
    for t in insts:
        if deadline is not None and time.time() > deadline:
            return None, None
        if tick:
            tick()
        shapes = shapes_for(t['id'])
        rots = rot_order.get((t['id'], t['inst']))
        if rots is not None:
            shapes = [shapes[i] for i in rots]
        if fill == 'equilibre':
            order = sorted(range(len(sheets)), key=lambda i: sheets[i].cells)
        else:
            order = range(len(sheets))
        done = False
        for si in order:
            best = None
            for sh in shapes:
                # une position n'est meilleure que si y + h <= meilleur y + h
                pos = sheets[si].find(sh, None if best is None else best[0][0] - sh.h)
                if pos is None:
                    continue
                x, y = pos
                key = (y + sh.h, x, sh.h)
                if best is None or key < best[0]:
                    best = (key, sh, x, y)
            if best is not None:
                _, sh, x, y = best
                sheets[si].place(sh, x, y, {'t': t, 'sh': sh, '_x': x, '_y': y, '_h': sh.h})
                done = True
                break
        if done:
            continue
        sheet = _Sheet(Wu, Hu, k)
        best = None
        for sh in shapes:
            pos = sheet.find(sh, None if best is None else best[0][0] - sh.h)
            if pos is None:
                continue
            x, y = pos
            key = (y + sh.h, x, sh.h)
            if best is None or key < best[0]:
                best = (key, sh, x, y)
        if best is None:
            unplaced.append({'id': t['id'], 'name': t['name'], 'inst': t['inst'],
                             'reason': 'trop grande pour le panneau'})
            continue
        _, sh, x, y = best
        sheet.place(sh, x, y, {'t': t, 'sh': sh, '_x': x, '_y': y, '_h': sh.h})
        sheets.append(sheet)
    return [s for s in sheets if s.items], unplaced


def _reduce(best, base, shapes_for, Wu, Hu, k, deadline, tick=None):
    """Essaie d'economiser des panneaux en changeant l'ordre de placement.
    Renvoie (best, nombre de passes, (pin, ordre, rotations) du meilleur
    ou None)."""
    n_runs = 0
    cfg = None
    pos = {(t['id'], t['inst']): i for i, t in enumerate(base)}
    by_long = sorted(base, key=lambda t: (-t['bbox_long'], pos[(t['id'], t['inst'])]))
    tried = set()
    while True:
        _sc, sheets, unplaced = best
        n = len(sheets)
        if n < 2 or unplaced or time.time() > deadline:
            break
        # borne : la surface reelle des pieces doit tenir dans n - 1 panneaux
        if sum(sh.cells for sh in sheets) > 0.95 * (n - 1) * Wu * Hu:
            break
        # pieces des derniers panneaux (les moins remplis) : a placer plus tot
        light = sorted(range(n), key=lambda i: sheets[i].cells)[:max(1, n // 3)]
        late = set()
        for i in light:
            late.update((it['t']['id'], it['t']['inst']) for it in sheets[i].items)
        lastk = set((it['t']['id'], it['t']['inst']) for it in sheets[-1].items)
        cands = []
        for keys in (lastk, late):
            first = [t for t in by_long if (t['id'], t['inst']) in keys]
            rest = [t for t in base if (t['id'], t['inst']) not in keys]
            # posees contre le bord oppose du 1er panneau, le reste dans
            # l'ordre habituel
            cands.append((('x', first), rest))
            cands.append((('y', first), rest))
            # posees en premier, par le bas
            cands.append(([], first + rest))
        cands.append(([], by_long))
        improved = False
        for pin, order in cands:
            sig = ((pin[0], tuple((t['id'], t['inst']) for t in pin[1])) if pin else None,
                   tuple((t['id'], t['inst']) for t in order))
            if sig in tried:
                continue
            tried.add(sig)
            s2, u2 = _run(order, {}, shapes_for, Wu, Hu, k, 'panneau', deadline=deadline, tick=tick, pin=pin)
            n_runs += 1
            sc = _score(s2, u2)
            if sc is None:
                return best, n_runs, cfg
            # les pieces restees sur le dernier panneau passent devant, et on
            # recommence (quelques fois) : elles prennent la place d'autres
            # pieces plus faciles a caser
            for _rep in range(3):
                if u2 or len(s2) < n or sc[:2] < best[0][:2]:
                    break
                lk = set((it['t']['id'], it['t']['inst']) for it in s2[-1].items)
                order = [t for t in order if (t['id'], t['inst']) in lk] + \
                        [t for t in order if (t['id'], t['inst']) not in lk]
                s2, u2 = _run(order, {}, shapes_for, Wu, Hu, k, 'panneau', deadline=deadline, tick=tick, pin=pin)
                n_runs += 1
                sc = _score(s2, u2)
                if sc is None:
                    return best, n_runs, cfg
            if sc[:2] < best[0][:2]:
                best = (sc, s2, u2)
                cfg = (pin, order, {})
                improved = True
                break
        if not improved:
            # ordres voisins tires au hasard (graine fixe : resultat stable)
            rnd = random.Random(len(base) * 7919 + n)
            pins = [c for c in cands if c[0]]
            while not improved and time.time() < deadline:
                pin, order = pins[n_runs % len(pins)] if pins else cands[0]
                order = list(order)
                for _ in range(rnd.randint(1, max(1, len(order) // 3))):
                    i = rnd.randrange(len(order))
                    j = min(len(order) - 1, max(0, i + rnd.randint(-3, 3)))
                    order[i], order[j] = order[j], order[i]
                rot_order = {}
                for t in order:
                    if rnd.random() < 0.3:
                        idx = list(range(len(shapes_for(t['id']))))
                        rnd.shuffle(idx)
                        rot_order[(t['id'], t['inst'])] = idx[:max(1, len(idx) // 2)]
                s2, u2 = _run(order, rot_order, shapes_for, Wu, Hu, k, 'panneau', deadline=deadline, tick=tick, pin=pin)
                n_runs += 1
                sc = _score(s2, u2)
                if sc is None:
                    return best, n_runs, cfg
                if sc[:2] < best[0][:2]:
                    best = (sc, s2, u2)
                    cfg = (pin, order, rot_order)
                    improved = True
        if not improved:
            break
    return best, n_runs, cfg


def _explore(best, base, shapes_for, Wu, Hu, k, deadline, tick=None, n_big=4, cfg=None):
    """Essaie d'autres ordres puis chaque orientation des n_big plus
    grandes pieces (descente coordonnee). cfg : (pin, ordre, rotations) de depart, sinon l'ordre de
    base. Renvoie (best, nombre de passes)."""
    n_runs = 0
    pin, order, forced = cfg if cfg else (None, base, {})
    forced = dict(forced)
    pinned = set((t['id'], t['inst']) for t in pin[1]) if pin else set()
    big = sorted([t for t in order if (t['id'], t['inst']) not in pinned],
                 key=lambda t: -t['bbox_area'])[:n_big]
    # 1) ordre des grandes pieces : laquelle poser en premier, en deuxieme...
    # (une petite arche peut se loger dans le creux d'une grande, au lieu
    # d'aller au bout du panneau)
    idx = [i for i, t in enumerate(order) if t in big]
    for p in range(len(idx) - 1):
        cur = order
        for q in range(p + 1, len(idx)):
            if time.time() > deadline:
                return best, n_runs
            o2 = list(cur)
            t = o2.pop(idx[q])
            o2.insert(idx[p], t)
            s2, u2 = _run(o2, forced, shapes_for, Wu, Hu, k, 'panneau', deadline=deadline, tick=tick, pin=pin)
            n_runs += 1
            sc = _score(s2, u2)
            if sc is None:
                return best, n_runs
            if sc < best[0]:
                best = (sc, s2, u2)
                order = o2
        idx = [i for i, t in enumerate(order) if t in big]
    big = [t for t in order if t in big]
    # 2) orientation de chaque grande piece
    for t in big:
        key = (t['id'], t['inst'])
        chosen = None
        for i in range(len(shapes_for(t['id']))):
            if time.time() > deadline:
                return best, n_runs
            ro = dict(forced)
            ro[key] = [i]
            s2, u2 = _run(order, ro, shapes_for, Wu, Hu, k, 'panneau', deadline=deadline, tick=tick, pin=pin)
            n_runs += 1
            sc = _score(s2, u2)
            if sc is None:
                return best, n_runs
            if sc < best[0]:
                best = (sc, s2, u2)
                chosen = i
        if chosen is not None:
            forced[key] = [chosen]
    return best, n_runs


def _skeleton(base, shapes_for, Wu, Hu, k, deadline, tick=None, max_big=5, orient=True):
    """Les grandes pieces font l'ossature du calepinage. On cherche leur
    meilleur ordre (et leurs orientations) en les placant seules, sur une
    grille grossiere (passes rapides) ; les petites pieces viendront ensuite
    dans les creux, dans l'ordre habituel.
    Renvoie (ordre complet, rotations imposees, nombre de passes) ou None."""
    if not base:
        return None
    amax = max(t['bbox_area'] for t in base)
    big = sorted([t for t in base if t['bbox_area'] >= 0.25 * amax],
                 key=lambda t: -t['bbox_area'])[:max_big]
    if len(big) < 2 or len(big) == len(base):
        return None
    n_runs = 0

    rest = [t for t in base if t not in big]

    def ev(order, ro):
        s2, u2 = _run(order, ro, shapes_for, Wu, Hu, k, 'panneau', deadline=deadline, tick=tick)
        return _score(s2, u2)

    best_o, best_ro = list(big), {}
    best_sc = ev(best_o, {})
    n_runs += 1
    if best_sc is None:
        return None
    # ordre : toutes les permutations jusqu'a 4 pieces (24 passes rapides) ;
    # au-dela, la 1re piece (toutes essayees), puis la 2e parmi les
    # restantes, etc.
    if len(big) <= 4:
        for perm in itertools.permutations(big):
            perm = list(perm)
            if time.time() > deadline:
                break
            if perm == best_o:
                continue
            sc = ev(perm, {})
            n_runs += 1
            if sc is None:
                break
            if sc < best_sc:
                best_sc, best_o = sc, perm
    for p in range(len(big) - 1 if len(big) > 4 else 0):
        cur = best_o
        for q in range(p + 1, len(cur)):
            if time.time() > deadline:
                break
            perm = list(cur)
            perm.insert(p, perm.pop(q))
            sc = ev(perm, {})
            n_runs += 1
            if sc is None:
                break
            if sc < best_sc:
                best_sc, best_o = sc, perm
    # orientations, une piece a la fois
    for t in (best_o if orient else []):
        key = (t['id'], t['inst'])
        chosen = None
        for i in range(len(shapes_for(t['id']))):
            if time.time() > deadline:
                break
            ro = dict(best_ro)
            ro[key] = [i]
            sc = ev(best_o, ro)
            n_runs += 1
            if sc is None:
                break
            if sc < best_sc:
                best_sc, chosen = sc, i
        if chosen is not None:
            best_ro[key] = [chosen]
    if best_o == big and not best_ro:
        return None   # l'ordre habituel est deja le meilleur
    return best_o + rest, best_ro, n_runs


def _score(sheets, unplaced):
    if sheets is None:
        return None
    # a nombre de panneaux egal : la longueur utilisee sur l'ensemble des
    # panneaux (tout tasse au depart, la chute au bout reste exploitable)
    return (len(unplaced), len(sheets), sum(sh.top() for sh in sheets))


def nest(parts, L=3100.0, W=1550.0, opts=None, progress=None, tick=None):
    """Place les pieces sur des panneaux L x W (mm).

    parts : [{'id', 'name', 'comp', 'qty', 'regions'}] (voir en-tete).
    Renvoie {'sheets': [{'index', 'util', 'placements': [{'id', 'name',
    'inst', 'rot', 'tx', 'ty'}]}], 'unplaced': [...], 'stats': {...}}.
    Pose d'une piece : point local p -> R(rot) p + (tx, ty), en mm, origine
    au coin bas-gauche du panneau brut (marge comprise)."""
    o = dict(DEFAULT_OPTS)
    o.update(opts or {})
    t0 = time.time()
    step = max(0.25, float(o['step']))
    m = max(0.0, float(o['margin']))
    k = int(math.ceil(max(0.0, float(o['spacing'])) / step)) + 1
    mode = o['mode'] if o['mode'] in MODES else 'imbrique'
    as_rect = mode == 'rectangulaire'
    fill_holes = mode not in ('imbrique_trous', 'optimise')
    rotations = [r % 360 for r in (o['rotations'] or [0])]
    rotations = sorted(set(rotations), key=rotations.index)
    # rotations a 90 deg permises : le fil du bois n'est pas impose, les
    # pieces courbes (arcs, croissants...) essaient aussi les angles
    # intermediaires (pas de 30 deg), elles s'emboitent bien mieux
    fine_rots = None
    curved_fill = float(o.get('curved_fill', CURVED_FILL))
    if (o.get('rot_courbes', True) and not as_rect and sorted(rotations) == [0, 90, 180, 270]
            and any(_fill_ratio(p) < curved_fill for p in parts)):
        fine_rots = list(range(0, 360, int(o.get('fine_step', 30))))
    if (len(rotations) > 4 or fine_rots) and step < 2.0:
        step = 2.0  # rotations libres : grille plus grossiere (temps de calcul)

    F = frame_matrix(L, W, o['corner'], o['compact'])
    lin = [[F[0][0], F[0][1]], [F[1][0], F[1][1]]]
    Lc, Wc = (W, L) if o['compact'] == 'x' else (L, W)
    Wu = int(math.floor((Lc - 2 * m) / step + 1e-9))
    Hu = int(math.floor((Wc - 2 * m) / step + 1e-9))
    Finv = _mat_inv_affine(F)

    by_id = {p['id']: p for p in parts}

    def make_shapes_for(step, k):
        cache = {}

        def shapes_for(pid):
            if pid not in cache:
                p = by_id[pid]
                flips = (False, True) if (o.get('flip') and p.get('flippable')) else (False,)
                rots = rotations
                if fine_rots and _fill_ratio(p) < curved_fill:
                    # piece courbe (arc, croissant...) : les angles
                    # intermediaires l'emboitent bien mieux dans les autres
                    rots = rotations + [r for r in fine_rots if r not in rotations]
                cache[pid] = [_Shape(p['regions'], r, lin, step, k, fill_holes, as_rect, f)
                              for f in flips for r in rots]
            return cache[pid]
        return shapes_for

    shapes_for = make_shapes_for(step, k)
    # meme formes sur une grille 2x plus grossiere : recherche rapide de
    # l'ossature (_skeleton). Meme ordre des formes, indices compatibles.
    step2 = 2 * step
    k2 = int(math.ceil(max(0.0, float(o['spacing'])) / step2)) + 1
    Wu2 = int(math.floor((Lc - 2 * m) / step2 + 1e-9))
    Hu2 = int(math.floor((Wc - 2 * m) / step2 + 1e-9))
    coarse_for = make_shapes_for(step2, k2)

    insts = _prepare(parts, o)
    base = _order(insts, o['order'])
    for t in base:
        shapes_for(t['id'])
        if tick:
            tick()

    t_run = time.time()
    sheets, unplaced = _run(base, {}, shapes_for, Wu, Hu, k, 'panneau', tick=tick)
    best = (_score(sheets, unplaced), sheets, unplaced)
    n_runs = 1
    t_run = time.time() - t_run

    # temps total des essais ci-dessous : borne pour garder un apercu rapide
    t_extra = time.time() + float(o.get('extra_time', min(18.0, max(5.0, 8.0 * t_run))))
    cfg = None
    # Un panneau coute cher : si la surface des pieces laisse esperer un
    # panneau de moins, on relance quelques passes dans d'autres ordres
    # (pieces du dernier panneau d'abord, plus longues d'abord...) et on garde
    # le resultat qui utilise le moins de panneaux, meme avec une grosse chute.
    if o.get('reduce', True):
        lim = float(o.get('reduce_time', min(20.0, max(3.0, 2.5 * t_run))))
        best, nr, cfg2 = _reduce(best, base, shapes_for, Wu, Hu, k, min(t_extra, time.time() + lim), tick)
        n_runs += nr
        cfg = cfg2 or cfg

    # ossature : ordre des grandes pieces (grille grossiere, rapide)
    if o.get('explore', True) and len(base) > 1:
        sk = _skeleton(base, coarse_for, Wu2, Hu2, k2, min(t_extra, time.time() + max(4.0, 3.0 * t_run)), tick, orient=o.get('sk_orient', False))
        if sk:
            order, ro, nr = sk
            n_runs += nr
            s2, u2 = _run(order, ro, shapes_for, Wu, Hu, k, 'panneau', deadline=t_extra, tick=tick)
            n_runs += 1
            sc = _score(s2, u2)
            if sc is not None and sc < best[0]:
                best = (sc, s2, u2)
                cfg = (None, order, ro)

    # Le glouton choisit l'orientation de chaque grande piece sans regarder
    # la suite : on essaie les autres orientations des plus grandes pieces
    # (une a la fois, en gardant la meilleure) pour que les suivantes
    # s'emboitent mieux. Garde le resultat le plus compact.
    if o.get('explore', True) and len(base) > 1:
        best, nr = _explore(best, base, shapes_for, Wu, Hu, k, t_extra, tick, cfg=cfg)
        n_runs += nr

    if mode == 'optimise' and len(base) > 1:
        rnd = random.Random(o.get('seed', 1))
        deadline = t0 + max(1.0, float(o['time_limit']))
        while time.time() < deadline:
            order = list(base)
            # perturbation : quelques permutations proches + rotations melangees
            for _ in range(rnd.randint(1, max(1, len(order) // 3))):
                i = rnd.randrange(len(order))
                j = min(len(order) - 1, max(0, i + rnd.randint(-3, 3)))
                order[i], order[j] = order[j], order[i]
            rot_order = {}
            for t in order:
                if rnd.random() < 0.3:
                    idx = list(range(len(shapes_for(t['id']))))
                    rnd.shuffle(idx)
                    rot_order[(t['id'], t['inst'])] = idx[:max(1, len(idx) // 2)]
            s2, u2 = _run(order, rot_order, shapes_for, Wu, Hu, k, 'panneau', deadline=deadline, tick=tick)
            n_runs += 1
            sc = _score(s2, u2)
            if sc is not None and sc < best[0]:
                best = (sc, s2, u2)
            if progress:
                try:
                    progress(n_runs, best[0])
                except Exception:
                    pass
    _, sheets, unplaced = best

    if o['fill'] == 'equilibre' and len(sheets) > 1:
        s2, u2 = _run(base, {}, shapes_for, Wu, Hu, k, 'equilibre', n_balanced=len(sheets), tick=tick)
        if len(u2) <= len(unplaced):
            sheets, unplaced = s2, u2

    out_sheets = []
    total_cells = 0
    for si, sheet in enumerate(sheets):
        pls = []
        for it in sheet.items:
            sh, t = it['sh'], it['t']
            # point canonique Q = lin_rot p - off + (m + x*step, m + y*step)
            sx = m + it['_x'] * step - sh.off[0]
            sy = m + it['_y'] * step - sh.off[1]
            A = _mat_mul(Finv, sh.lin)
            # retournee : A = R . diag(1, -1), la 1re colonne donne encore R
            tx, ty = _mat_apply(Finv, sx, sy)
            rot = math.degrees(math.atan2(A[1][0], A[0][0])) % 360.0
            if abs(rot - round(rot)) < 1e-6:
                rot = float(round(rot)) % 360.0
            pls.append({'id': t['id'], 'name': t['name'], 'inst': t['inst'],
                        'rot': rot, 'tx': tx, 'ty': ty, 'flip': bool(sh.flip)})
        total_cells += sheet.cells
        out_sheets.append({'index': si + 1, 'placements': pls,
                           'util': sheet.cells * step * step / (L * W)})
    return {
        'sheets': out_sheets,
        'unplaced': unplaced,
        'stats': {'n_sheets': len(out_sheets), 'n_parts': len(insts),
                  'n_runs': n_runs, 'time_s': round(time.time() - t0, 2),
                  'util': (total_cells * step * step / (L * W * len(out_sheets))) if out_sheets else 0.0,
                  'mode': mode, 'L': L, 'W': W, 'margin': m},
    }
