# ---------------------------------------------------------------------------
# Calpinage CNC : nesting des pieces de la suite CNC Toolkit sur des
# panneaux (demande de l'utilisateur le 2026-10-10, voir conception_calpinage.md).
#
# Etapes 1 et 2 (ce fichier) : analyse des pieces, placement, apercu orange
# (palette + vue 3D). La creation (deplacer / copier) et l'export DXF
# viendront ensuite.
#
# PRINCIPE
#   - Pieces = corps solides visibles (tout le modele ou la selection de
#     Fusion au moment du clic sur "Utiliser la selection").
#   - Axe d'epaisseur = normale des deux plus grandes faces planes opposees
#     (meme calcul que Dogbone/Entaille CNC). Groupe = parametre CPxx dont
#     la valeur vaut l'epaisseur (Extrusion CNC), sinon "Ep. xx mm".
#   - Face du dessus : celle ou se trouve une gravure (esquisses "Gravure
#     CNC"), sinon celle d'ou s'ouvrent les usinages borgnes (fonds de
#     poche). Usinages borgnes des deux cotes = piece "a retourner".
#   - Contour 2D : toutes les faces planes tournees vers le haut (dessus,
#     fonds de poche, dessus de tenons), chacune avec ses boucles. Leur
#     union = vue de dessus ; un trou traversant n'est couvert par aucune.
#   - Repere local : u = plus longue arete droite de la grande face (les
#     pieces rectangulaires tombent d'equerre avec le panneau), v = n x u.
#   - Le placement est fait par nest_engine.py (Python pur, recharge a
#     chaque ouverture du panneau pour les tests en direct).
#   - Rien n'est modifie dans le document. Aucun JSON partage n'est lu ni
#     ecrit : seulement calpinage_prefs.json (ce dossier) et, en lecture,
#     le diametre de fraise de DogboneCNC/dogbone_prefs.json.
# ---------------------------------------------------------------------------
import adsk.core
import adsk.fusion
import adsk.cam
import importlib.util
import json
import math
import os
import re
import sys
import time
import traceback
import uuid

# Barre de chargement commune du Toolkit (ToolkitCNC/cnc_progress.py)
_TK_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _TK_DIR not in sys.path:
    sys.path.append(_TK_DIR)
import cnc_progress

_t_pump = [0.0]


def _pump(n=0, message=None):
    """Avance la barre de chargement ET laisse Fusion l'afficher : pendant un
    calcul en pur Python (placement, analyse) Fusion ne redessine rien, et la
    fenetre de chargement restait invisible (l'utilisateur, 2026-10-12). Les clics
    dans la palette pendant ce temps sont ignores par ToolkitCNC.py
    (cnc_progress.occupe())."""
    cnc_progress.avance(n, message)
    if cnc_progress.occupe():
        t = time.time()
        if t - _t_pump[0] > 0.1:
            _t_pump[0] = t
            try:
                adsk.doEvents()
            except Exception:
                pass


_app = None
_ui = None
_handlers = []

CMD_ID = 'CalpinageCNCCmd'
COMMAND_NAME = 'Calpinage CNC'

_ADDIN_DIR = os.path.dirname(os.path.abspath(__file__))
PREFS_FILE = os.path.join(_ADDIN_DIR, 'calpinage_prefs.json')
DEBUG_LOG = os.path.join(_ADDIN_DIR, 'calpinage_debug.log')
ENGINE_FILE = os.path.join(_ADDIN_DIR, 'nest_engine.py')
PDF_FILE = os.path.join(_ADDIN_DIR, 'calpinage_pdf.py')
DOGBONE_PREFS = os.path.join(os.path.dirname(_ADDIN_DIR), 'DogboneCNC', 'dogbone_prefs.json')

DEFAULT_FORMATS = [
    {'name': '3100 x 1550', 'L': 3100.0, 'W': 1550.0},
    {'name': '2500 x 1250', 'L': 2500.0, 'W': 1250.0},
    {'name': '2440 x 1220', 'L': 2440.0, 'W': 1220.0},
]

DEFAULT_PREFS = {
    'formats': DEFAULT_FORMATS,
    'format': '3100 x 1550',
    'mode': 'imbrique',
    'margin': 10.0,
    'spacing': None,          # None = diametre de fraise Dogbone + 2 mm
    'corner': 'bas_gauche',
    'compact': 'x',
    'order': 'surface',
    'rotations': '90',        # 'aucune', '180', '90', 'libre'
    'fill': 'panneau',
    'coupes': 'aucune',       # mode Rectangulaire : coupes prioritaires 'aucune', 'horizontales', 'verticales'
    'niveaux': 2,             # ... nombre de niveaux de coupe (1 a 3)
    'tri': 'quantite',        # ... 'quantite' (moins de panneaux) ou 'rapidite' (memes largeurs ensemble)
    'pdf_fiche': True,        # PDF : fiche de debit sous chaque panneau
    'pdf_ordre': True,        # PDF : ordre des coupes (coupes prioritaires), une vignette par etape
    'time_limit': 30.0,
    'gravure_dessus': True,
    'copier': False,
    'retourner': False,       # autoriser a retourner les pieces (gravure sur l'autre face)
    'exemplaires': 1,         # nombre de meubles a fabriquer (chaque piece x N)
    'esquisse': False,        # esquisse de projection des panneaux (utile au DXF seulement ; creee a l'export sinon)
    'brut': False,            # cree un corps "Brut CP 18" par panneau (simulation)
    'usinage': False,         # prepare la Fabrication : configuration, percages dogbones, contour 2D
    # reglages de l'usinage (section Usinage du panneau ; mm sauf mention)
    'u_pass_mode': 'profondeur',  # 'profondeur' (passe max) ou 'passes' (nombre de passes)
    'u_pass_depth': 6.0,
    'u_n_passes': 3,
    'u_finition': False,          # passe de finition laterale
    'u_fin_surep': 0.5,           # surepaisseur laissee avant la finition
    'u_depass': 0.5,              # contour : profondeur sous le brut
    'u_maintien': 'aucun',        # 'aucun', 'attaches', 'peau' (peau d'oignon)
    'u_tab_mode': 'nombre',       # attaches : 'nombre' par contour ou 'distance' entre attaches
    'u_tab_count': 4,
    'u_tab_dist': 300.0,
    'u_tab_w': 8.0,
    'u_tab_h': 3.0,
    'u_peau': 0.3,
    'u_rampe': True,              # entree en rampe
    'u_sens': 'avalant',          # 'avalant' ou 'opposition'
    'u_drill_dep': 1.0,           # percage : depassement sous le brut
    'u_cycle': 'simple',          # 'simple' ou 'debourrage'
    'u_peck': 3.0,                # profondeur de debourrage
    'u_retrait': 5.0,             # au-dessus du brut
    'u_degag': 10.0,              # au-dessus du retrait
    'u_avance': 5.0,              # au-dessus du haut de l'operation
    'u_z0': 'dessus',             # Z0 sur le dessus du panneau ou 'dessous' (table)
    'u_coin': 'bas_gauche',       # coin de l'origine
    # fraises creees dans Fabrication (bibliotheque locale + document), une par operation :
    # 'c' = contour 2D (detourage), 'p' = percage des dogbones
    'u_fraise_c': 'nouvelle',     # 'nouvelle' (Felder Format 4 H80), 'aucune' ou 'lib:<nom d'un outil de la bibliotheque>'
    'u_c_diam': 12.0, 'u_c_dents': 2, 'u_c_rpm': 18000, 'u_c_avance': 5000.0,
    'u_fraise_p': 'nouvelle',
    'u_p_diam': 8.0, 'u_p_dents': 2, 'u_p_rpm': 18000, 'u_p_avance': 3000.0,
}

ROTATIONS = {'aucune': [0], '180': [0, 180], '90': [0, 90, 180, 270],
             'libre': list(range(0, 360, 15))}

GROUP_NAME = 'Calpinage CNC'     # groupe d'historique, composant (mode Copier), esquisses
ATTR_GROUP = 'CalpinageCNC'

_TOL_PAR = 0.02      # |1 - |cos|| : face parallele au panneau
_STROKE_TOL = 0.01   # cm : discretisation des aretes courbes (0,1 mm)

_preview_cg = None
_y_up = None          # haut du document, lu une fois par ouverture du panneau


def _dbg(msg):
    try:
        with open(DEBUG_LOG, 'a', encoding='utf-8') as f:
            f.write(time.strftime('%Y-%m-%d %H:%M:%S ') + str(msg) + '\n')
    except Exception:
        pass


# --- Preferences ----------------------------------------------------------------

def _dogbone_diam():
    try:
        with open(DOGBONE_PREFS, 'r', encoding='utf-8') as f:
            return float(json.load(f).get('diam_mm', 8.0))
    except Exception:
        return 8.0


def _dogbone_jeu():
    try:
        with open(DOGBONE_PREFS, 'r', encoding='utf-8') as f:
            return float(json.load(f).get('jeu_mm', 0.1))
    except Exception:
        return 0.1


def load_prefs():
    p = json.loads(json.dumps(DEFAULT_PREFS))
    try:
        with open(PREFS_FILE, 'r', encoding='utf-8') as f:
            p.update(json.load(f))
    except Exception:
        pass
    if not p.get('formats'):
        p['formats'] = json.loads(json.dumps(DEFAULT_FORMATS))
    if p.get('spacing') is None:
        p['spacing'] = _dogbone_diam() + 2.0
    # le nombre d'exemplaires est propre a chaque projet (voir _ex_du_doc) :
    # jamais repris du fichier de preferences commun
    p['exemplaires'] = 1
    return p


def save_prefs(prefs):
    try:
        p = load_prefs()
        p.update({k: prefs[k] for k in DEFAULT_PREFS if k in prefs and k != 'exemplaires'})
        with open(PREFS_FILE, 'w', encoding='utf-8') as f:
            json.dump(p, f, indent=2)
    except Exception:
        _dbg('save_prefs EXCEPTION: ' + traceback.format_exc())


def _load_pdf():
    spec = importlib.util.spec_from_file_location('calpinage_pdf', PDF_FILE)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


_engine = [None, None]   # (module, date du fichier) : garde les formes deja preparees


def _load_engine():
    """Moteur charge une fois (relu seulement si nest_engine.py change) : son
    cache de formes sert d'un calcul a l'autre (format, portee, nombre de
    meubles... sans tout rasteriser de nouveau)."""
    try:
        mt = os.path.getmtime(ENGINE_FILE)
    except Exception:
        mt = None
    if _engine[0] is None or _engine[1] != mt:
        spec = importlib.util.spec_from_file_location('calpinage_nest_engine', ENGINE_FILE)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        _engine[0], _engine[1] = mod, mt
    return _engine[0]


# --- Collecte des corps (meme logique que DogboneCNC.collect_bodies) ------------

def _add_body(out, seen, body):
    try:
        if body is None or not body.isSolid or not body.isVisible:
            return
        occ = body.assemblyContext
        # brut d'un calpinage (corps "Brut CP 18") : jamais une piece
        if (body.nativeObject if occ else body).attributes.itemByName(ATTR_GROUP, 'brut') is not None:
            return
        key = (body.nativeObject.entityToken if occ else body.entityToken,
               occ.fullPathName if occ else '')
        if key in seen:
            return
        seen.add(key)
        out.append(body)
    except Exception:
        pass


def _add_occurrence(out, seen, occ):
    try:
        if not occ.isVisible or occ.component.name.startswith(GROUP_NAME):
            return
        for b in occ.bRepBodies:
            _add_body(out, seen, b)
        for child in occ.childOccurrences:
            _add_occurrence(out, seen, child)
    except Exception:
        pass


def collect_bodies(design, entities=None):
    out, seen = [], set()
    root = design.rootComponent
    if entities is None:
        for b in root.bRepBodies:
            _add_body(out, seen, b)
        for o in root.occurrences:
            _add_occurrence(out, seen, o)
        return out
    for e in entities:
        b = adsk.fusion.BRepBody.cast(e)
        if b is not None:
            _add_body(out, seen, b)
            continue
        o = adsk.fusion.Occurrence.cast(e)
        if o is not None:
            _add_occurrence(out, seen, o)
            continue
        for cls in (adsk.fusion.BRepFace, adsk.fusion.BRepEdge):
            x = cls.cast(e)
            if x is not None:
                _add_body(out, seen, x.body)
                break
    return out


# --- Geometrie ------------------------------------------------------------------

def _face_normal(face):
    try:
        ok, n = face.evaluator.getNormalAtPoint(face.pointOnFace)
        if ok:
            n.normalize()
            return n
    except Exception:
        pass
    return None


def _dot(a, b):
    return a.x * b.x + a.y * b.y + a.z * b.z


def _vec(p):
    return adsk.core.Vector3D.create(p.x, p.y, p.z)


def _thickness_axis(body):
    """(n, d_min, d_max, plus grande face) ou None. d = position le long de n."""
    planar = [f for f in body.faces if adsk.core.Plane.cast(f.geometry) is not None]
    if len(planar) < 2:
        return None
    planar.sort(key=lambda f: -f.area)
    n1 = _face_normal(planar[0])
    n2 = _face_normal(planar[1])
    if n1 is None or n2 is None or _dot(n1, n2) > -0.95:
        return None
    d1 = _dot(_vec(planar[0].pointOnFace), n1)
    d2 = _dot(_vec(planar[1].pointOnFace), n1)
    return n1, min(d1, d2), max(d1, d2), planar[0]


def _is_flat_part(body, n):
    """Piece 2,5D : chaque face non plane a sa normale perpendiculaire a n
    (chants courbes) ; sinon (corps cintre...) on ne sait pas la poser."""
    for f in body.faces:
        if adsk.core.Plane.cast(f.geometry) is not None:
            continue
        nf = _face_normal(f)
        if nf is not None and abs(_dot(nf, n)) > 0.05:
            return False
    return True


def gravure_lines(design):
    """Segments (P1, P2) monde de toutes les gravures "trait simple" (esquisses
    "Gravure CNC..." sans extrusion). Depuis le 2026-10-10, Gravure CNC pose
    ces traits en 3D sur la vraie face de chaque panneau."""
    segs = []
    try:
        for comp in design.allComponents:
            for sk in comp.sketches:
                if not sk.name.startswith('Gravure CNC'):
                    continue
                textes = _gravure_textes(sk)
                lines = sk.sketchCurves.sketchLines
                for i in range(lines.count):
                    ln = lines.item(i)
                    a, b = ln.startSketchPoint.worldGeometry, ln.endSketchPoint.worldGeometry
                    segs.append((a, b, ln, _normale_texte(textes, a, b)))
    except Exception:
        _dbg('gravure_lines EXCEPTION: ' + traceback.format_exc())
    return segs


def _gravure_textes(sk):
    """Textes poses par Gravure CNC dans cette esquisse (attribut
    CNCToolkit/gravures, depuis le 2026-11-12) : [(centre, rayon, normale)]
    ou [] pour une esquisse plus ancienne."""
    try:
        at = sk.attributes.itemByName('CNCToolkit', 'gravures')
        if at is None:
            return []
        out = []
        for e in json.loads(at.value):
            out.append((tuple(e['p']), float(e['r']), tuple(e['n'])))
        return out
    except Exception:
        return []


def _normale_texte(textes, a, b):
    """Normale sortante de la face pour laquelle ce trait a ete grave, ou None."""
    if not textes:
        return None
    m = ((a.x + b.x) / 2.0, (a.y + b.y) / 2.0, (a.z + b.z) / 2.0)
    best = None
    for c, r, n in textes:
        d = (m[0] - c[0], m[1] - c[1], m[2] - c[2])
        if abs(d[0] * n[0] + d[1] * n[1] + d[2] * n[2]) > 0.05:
            continue
        dd = math.sqrt(d[0] ** 2 + d[1] ** 2 + d[2] ** 2)
        if dd <= r and (best is None or dd < best[0]):
            best = (dd, n)
    return None if best is None else best[1]


def _in_bbox(bb, p, tol=0.1):
    return (bb.minPoint.x - tol <= p.x <= bb.maxPoint.x + tol and
            bb.minPoint.y - tol <= p.y <= bb.maxPoint.y + tol and
            bb.minPoint.z - tol <= p.z <= bb.maxPoint.z + tol)


def _body_gravure(body, n, d_min, d_max, grav_segs):
    """Segments de gravure poses sur une des deux grandes faces du corps :
    {+1: [...], -1: [...]} selon la face (cote +n / cote -n)."""
    bb = body.boundingBox
    out = {1: [], -1: []}
    for seg in grav_segs:
        a, b = seg[0], seg[1]
        if not (_in_bbox(bb, a) and _in_bbox(bb, b)):
            continue
        da, db = _dot(_vec(a), n), _dot(_vec(b), n)
        for side, d in ((1, d_max), (-1, d_min)):
            if abs(da - d) < 0.02 and abs(db - d) < 0.02:
                mid = adsk.core.Point3D.create((a.x + b.x) / 2 - side * n.x * 0.05,
                                               (a.y + b.y) / 2 - side * n.y * 0.05,
                                               (a.z + b.z) / 2 - side * n.z * 0.05)
                try:
                    inside = body.pointContainment(mid) == adsk.fusion.PointContainment.PointInsidePointContainment
                except Exception:
                    inside = True
                if inside:
                    out[side].append(seg)
                break
    return out


def _pocket_area(body, n, d_min, d_max):
    """Aire des fonds de poche (usinages borgnes, gravure extrudee) ouverts
    du cote +n (cle 1) et du cote -n (cle -1)."""
    area = {1: 0.0, -1: 0.0}
    for f in body.faces:
        if adsk.core.Plane.cast(f.geometry) is None:
            continue
        nf = _face_normal(f)
        if nf is None or abs(abs(_dot(nf, n)) - 1.0) > _TOL_PAR:
            continue
        d = _dot(_vec(f.pointOnFace), n)
        if d_min + 0.01 < d < d_max - 0.01:
            area[1 if _dot(nf, n) > 0 else -1] += f.area
    return area


def _top_sign(body, n, d_min, d_max, grav):
    """+1 si le dessus est du cote +n, -1 sinon ; (signe, raison, a_retourner)."""
    # 1) gravure en trait simple (esquisse) posee sur une des deux grandes faces
    votes = {1: len(grav[1]), -1: len(grav[-1])}
    if votes[1] or votes[-1]:
        return (1 if votes[1] >= votes[-1] else -1), 'gravure', False
    # 2) fonds de poche (usinages borgnes, gravure extrudee) : ouverts vers le haut
    area = {1: 0.0, -1: 0.0}
    for f in body.faces:
        if adsk.core.Plane.cast(f.geometry) is None:
            continue
        nf = _face_normal(f)
        if nf is None or abs(abs(_dot(nf, n)) - 1.0) > _TOL_PAR:
            continue
        d = _dot(_vec(f.pointOnFace), n)
        if d_min + 0.01 < d < d_max - 0.01:
            area[1 if _dot(nf, n) > 0 else -1] += f.area
    if area[1] or area[-1]:
        flip = area[1] > 0 and area[-1] > 0
        return (1 if area[1] >= area[-1] else -1), 'usinages', flip
    return 1, '', False


def _longest_edge_dir(face, n):
    best, bl = None, 0.0
    for e in face.edges:
        ln = adsk.core.Line3D.cast(e.geometry)
        if ln is None:
            continue
        v = ln.startPoint.vectorTo(ln.endPoint)
        v = v.copy()
        k = _dot(v, n)
        v = adsk.core.Vector3D.create(v.x - k * n.x, v.y - k * n.y, v.z - k * n.z)
        if v.length > bl:
            best, bl = v, v.length
    if best is None:
        # pas d'arete droite (disque...) : n'importe quelle perpendiculaire
        a = adsk.core.Vector3D.create(1, 0, 0) if abs(n.x) < 0.9 else adsk.core.Vector3D.create(0, 1, 0)
        best = n.crossProduct(a)
    best.normalize()
    return best


def _loop_points(loop):
    pts = []
    for ce in loop.coEdges:
        e = ce.edge
        try:
            ev = e.evaluator
            ok, t0, t1 = ev.getParameterExtents()
            ok2, sp = ev.getStrokes(t0, t1, _STROKE_TOL)
            seg = list(sp) if ok2 else [e.startVertex.geometry, e.endVertex.geometry]
        except Exception:
            seg = [e.startVertex.geometry, e.endVertex.geometry]
        # Les points de getStrokes suivent le parametre de la courbe, pas
        # toujours le sens de l'arete : on oriente chaque morceau d'apres le
        # sommet de depart de la co-arete (sinon des traits traversent la
        # piece et son contour se croise).
        try:
            start = (e.endVertex if ce.isOpposedToEdge else e.startVertex).geometry
            if len(seg) > 1 and seg[-1].distanceTo(start) < seg[0].distanceTo(start):
                seg.reverse()
        except Exception:
            if ce.isOpposedToEdge:
                seg.reverse()
        if pts and seg and pts[-1].distanceTo(seg[0]) < 1e-6:
            seg = seg[1:]
        pts.extend(seg)
    if len(pts) > 1 and pts[0].distanceTo(pts[-1]) < 1e-6:
        pts.pop()
    return pts


def _cp_labels(design):
    out = []
    try:
        for p in design.userParameters:
            if re.match(r'^CP\d+', p.name):
                out.append((p.name, p.value * 10.0))
    except Exception:
        pass
    return out


def _group_of(th_mm, cps):
    for name, v in cps:
        if abs(v - th_mm) < 0.05:
            return name, name
    key = 'EP%.1f' % th_mm
    return key, 'Ep. %s mm' % (('%.1f' % th_mm).rstrip('0').rstrip('.'))


def _part_label(body):
    occ = body.assemblyContext
    if occ is not None:
        nat = body.nativeObject
        comp = occ.component
        n_bodies = sum(1 for b in comp.bRepBodies if b.isSolid)
        return occ.name if n_bodies <= 1 else '%s / %s' % (occ.name, nat.name)
    return body.name


def _part_key(body):
    occ = body.assemblyContext
    nat = body.nativeObject if occ else body
    return '%s|%s|%s' % (occ.fullPathName if occ else '', nat.parentComponent.id, nat.name)


def analyse_part(body, grav_segs, cps, gravure_dessus=True):
    """Piece 2D d'un corps : dict pour nest_engine + infos, ou (None, alerte)."""
    label = _part_label(body)
    ax = _thickness_axis(body)
    if ax is None:
        return None, '%s : pas de grandes faces planes opposees (ignore)' % label
    n, d_min, d_max, big = ax
    if not _is_flat_part(body, n):
        return None, '%s : piece non plane (ignoree)' % label
    th = (d_max - d_min) * 10.0
    grav = _body_gravure(body, n, d_min, d_max, grav_segs)
    if gravure_dessus:
        s, why, flip = _top_sign(body, n, d_min, d_max, grav)
    else:
        s, why, flip = 1, '', False
    up = adsk.core.Vector3D.create(n.x * s, n.y * s, n.z * s)
    u = _longest_edge_dir(big, n)
    v = up.crossProduct(u)
    v.normalize()
    o = big.pointOnFace
    regions = []
    levels = []   # hauteur de chaque region le long de up (profondeur pour le PDF)
    for f in body.faces:
        if adsk.core.Plane.cast(f.geometry) is None:
            continue
        nf = _face_normal(f)
        if nf is None or _dot(nf, up) < 1.0 - _TOL_PAR:
            continue
        rings = []
        loops = sorted(f.loops, key=lambda lp: 0 if lp.isOuter else 1)
        for lp in loops:
            pts = _loop_points(lp)
            if len(pts) < 3:
                continue
            ring = []
            for p in pts:
                w = o.vectorTo(p)
                ring.append((round(_dot(w, u) * 10.0, 3), round(_dot(w, v) * 10.0, 3)))
            rings.append(ring)
        if rings:
            regions.append(rings)
            levels.append(_dot(_vec(f.pointOnFace), up))
    if not regions:
        return None, '%s : aucune face tournee vers le haut (ignoree)' % label

    def loc(p):
        w = o.vectorTo(p)
        return (round(_dot(w, u) * 10.0, 3), round(_dot(w, v) * 10.0, 3))
    gkey, glabel = _group_of(th, cps)
    occ = body.assemblyContext
    d_top, d_bot = (d_max, d_min) if s > 0 else (-d_min, -d_max)
    grav_loc = [[loc(g[0]), loc(g[1])] for g in grav[s]]
    # Retournable (bouton "Optimiser l'espace") : aucun usinage borgne (il
    # finirait sous la piece) et gravure d'un seul cote, dans une esquisse
    # du composant racine (elle sera reposee sur l'autre face).
    pockets = _pocket_area(body, n, d_min, d_max)
    root = body.parentComponent.parentDesign.rootComponent
    flippable = (not pockets[1] and not pockets[-1] and not grav[-s] and
                 all(g[2].parentSketch.parentComponent == root for g in grav[s]))
    vs = [q[1] for seg in grav_loc for q in seg]
    part = {'id': _part_key(body), 'name': label, 'regions': regions,
            'comp': occ.name if occ is not None else '', 'qty': 1,
            'group': gkey, 'group_label': glabel, 'th_mm': round(th, 2),
            'flip': flip, 'top_reason': why,
            'grav': grav_loc,
            'grav_cv': (min(vs) + max(vs)) / 2.0 if vs else 0.0,
            'flippable': bool(flippable),
            '_grav_lines': [g[2] for g in grav[s]],
            'grav_dessous': len(grav[-s]),
            # pour la creation (non envoye a la palette)
            'depths': [round(max(0.0, (d_top - lv) * 10.0), 2) for lv in levels],
            '_body': body, '_frame': (o, u, v, up, d_bot, d_top)}
    return part, None


def _exclusions_superposes(bodies, grav):
    """Corps superposes (2026-11-12) : un texte grave sur une face collee a
    un autre corps (dessus d'une piece posee sous une autre) se trouve aussi
    sur la face du dessous de la piece du dessus, qui le prenait pour le sien
    (etiquettes des pieces du dessous, en miroir, sur la piece du dessus).
    Quand plusieurs corps revendiquent le meme trait, on ne le laisse qu'a
    celui dont la face regarde dans le sens de la gravure (normale notee par
    Gravure CNC). Sans cette information (anciennes gravures) : inchange.
    Retourne {indice du corps: ensemble d'indices de traits a ignorer}."""
    claims = {}
    for i, b in enumerate(bodies):
        try:
            ax = _thickness_axis(b)
            if ax is None:
                continue
            n, d_min, d_max, _big = ax
            out = _body_gravure(b, n, d_min, d_max, grav)
            for side in (1, -1):
                sn = (n.x * side, n.y * side, n.z * side)
                for seg in out[side]:
                    claims.setdefault(seg[4], []).append((i, sn))
        except Exception:
            _dbg('exclusions_superposes: ' + traceback.format_exc())
    excl = {}
    n_conf = 0
    for k, lst in claims.items():
        if len(lst) < 2:
            continue
        nt = grav[k][3]
        if nt is None:
            continue
        bons = [i for i, sn in lst if sn[0] * nt[0] + sn[1] * nt[1] + sn[2] * nt[2] > 0.5]
        if not bons:
            continue
        n_conf += 1
        for i, sn in lst:
            if i not in bons:
                excl.setdefault(i, set()).add(k)
    if n_conf:
        _dbg('corps superposes : %d trait(s) de gravure rendus a leur seul corps' % n_conf)
    return excl


def analyse(design, bodies, gravure_dessus=True):
    grav = [(a, b, ln, nt, k) for k, (a, b, ln, nt) in enumerate(gravure_lines(design))]
    cps = _cp_labels(design)
    parts, warnings = [], []
    try:
        excl = _exclusions_superposes(bodies, grav)
    except Exception:
        excl = {}
        _dbg('exclusions EXCEPTION: ' + traceback.format_exc())
    cnc_progress.etape('Analyse des pieces...', 0, len(bodies))
    for ib, b in enumerate(bodies):
        _pump(1)
        try:
            gb = grav if ib not in excl else [g for g in grav if g[4] not in excl[ib]]
            p, w = analyse_part(b, gb, cps, gravure_dessus)
        except Exception:
            p, w = None, '%s : erreur d\'analyse (%s)' % (
                getattr(b, 'name', '?'), traceback.format_exc().strip().splitlines()[-1])
            _dbg('analyse_part EXCEPTION: ' + traceback.format_exc())
        if p is not None:
            parts.append(p)
            if p['flip']:
                warnings.append('%s : usinages borgnes des deux cotes (a retourner)' % p['name'])
            if p['grav_dessous']:
                warnings.append('%s : gravure sur la face du dessous (non reprise)' % p['name'])
        elif w:
            warnings.append(w)
    return parts, warnings


# --- Placement ------------------------------------------------------------------

def _format(prefs):
    for f in prefs.get('formats', []):
        if f.get('name') == prefs.get('format'):
            return float(f['L']), float(f['W'])
    f = (prefs.get('formats') or DEFAULT_FORMATS)[0]
    return float(f['L']), float(f['W'])


_nest_cache = {}   # resultat par epaisseur : decocher/recocher un groupe ne recalcule rien


def clear_cache():
    _nest_cache.clear()


def compute(parts, prefs, groups_off=()):
    eng = _load_engine()
    L, W = _format(prefs)
    opts = {
        'mode': prefs.get('mode', 'imbrique'),
        'margin': float(prefs.get('margin', 10.0)),
        'spacing': float(prefs.get('spacing', 10.0)),
        'corner': prefs.get('corner', 'bas_gauche'),
        'compact': prefs.get('compact', 'x'),
        'order': prefs.get('order', 'surface'),
        'rotations': ROTATIONS.get(str(prefs.get('rotations', '90')), ROTATIONS['90']),
        'fill': prefs.get('fill', 'panneau'),
        'time_limit': float(prefs.get('time_limit', 30.0)),
        'flip': bool(prefs.get('retourner', False)),
    }
    if opts['mode'] == 'rectangulaire' and prefs.get('coupes') in ('horizontales', 'verticales'):
        # coupes prioritaires (scie a format) : placement par bandes guillotine
        opts['coupes'] = prefs['coupes']
        opts['niveaux'] = max(1, min(3, int(prefs.get('niveaux', 2) or 2)))
        opts['tri'] = 'rapidite' if prefs.get('tri') == 'rapidite' else 'quantite'
    n_ex = _n_ex(prefs)
    if n_ex > 1:
        # plusieurs meubles : chaque piece est placee n_ex fois
        parts = [dict(p, qty=int(p.get('qty', 1) or 1) * n_ex) for p in parts]
    groups = {}
    for p in parts:
        groups.setdefault(p['group'], []).append(p)
    out = []
    cnc_progress.etape('Placement des pieces sur les panneaux...', 0, len(groups))
    for gkey in sorted(groups, key=lambda k: (-sum(1 for _ in groups[k]), k)):
        gparts = groups[gkey]
        _pump(1, 'Placement : %s...' % gparts[0]['group_label'])
        if gkey in groups_off:
            continue
        ck = (gkey, L, W, json.dumps(opts, sort_keys=True),
              tuple(sorted((p['id'], p.get('qty', 1), p.get('flippable', False)) for p in gparts)))
        if ck in _nest_cache:
            out.append(_nest_cache[ck])
            continue
        res = eng.nest(gparts, L, W, opts, progress=lambda n, _best: _pump(
            0, 'Optimisation : %s, essai %d...' % (gparts[0]['group_label'], n)), tick=_pump)
        by = {p['id']: p for p in gparts}
        for s in res['sheets']:
            for pl in s['placements']:
                p = by[pl['id']]
                fl = bool(pl.get('flip'))
                pl['regions'] = eng.transform_regions(p['regions'], pl['rot'], pl['tx'], pl['ty'], fl)
                pl['depths'] = p.get('depths', [])
                grav = p.get('grav', [])
                if fl:
                    # piece retournee : la gravure passe sur l'autre face, en
                    # miroir autour de son axe pour rester lisible de dessus
                    cv = p.get('grav_cv', 0.0)
                    grav = [[(a[0], 2 * cv - a[1]), (b[0], 2 * cv - b[1])] for a, b in grav]
                pl['grav'] = [r[0] for r in eng.transform_regions([[g] for g in grav],
                                                                   pl['rot'], pl['tx'], pl['ty'], fl)]
        g = {'group': gkey, 'label': gparts[0]['group_label'], 'th_mm': gparts[0]['th_mm'],
             'sheets': res['sheets'], 'unplaced': res['unplaced'], 'stats': res['stats']}
        _nest_cache[ck] = g
        out.append(g)
    return {'L': L, 'W': W, 'margin': opts['margin'], 'groups': out}


# --- Apercu 3D (CustomGraphics) ---------------------------------------------------

PREVIEW_ID = 'CalpinageCNC_apercu'


def clear_preview():
    """Efface l'apercu, dans TOUS les documents ouverts (un apercu laisse
    dans un autre projet, ou apres un rechargement de l'add-in, est
    retrouve par son id)."""
    global _preview_cg
    try:
        if _preview_cg is not None and _preview_cg.isValid:
            _preview_cg.deleteMe()
    except Exception:
        pass
    _preview_cg = None
    try:
        for doc in _app.documents:
            try:
                des = adsk.fusion.Design.cast(doc.products.itemByProductType('DesignProductType'))
                if des is None:
                    continue
                grps = des.rootComponent.customGraphicsGroups
                for i in range(grps.count - 1, -1, -1):
                    g = grps.item(i)
                    if g.id == PREVIEW_ID:
                        g.deleteMe()
            except Exception:
                pass
    except Exception:
        pass
    try:
        _app.activeViewport.refresh()
    except Exception:
        pass


def _is_y_up():
    """Haut du document : la camera par defaut suit l'orientation du
    document (la preference de Fusion ne vaut que pour les nouveaux
    documents - le document TENON CNC de l'utilisateur est en Y haut)."""
    try:
        # Vue "Accueil" lue sans animation puis camera remise en place : la
        # camera courante peut etre en vue de dessus (haut = -Z en Y haut).
        vp = _app.activeViewport
        cam = vp.camera
        try:
            vp.goHome(False)
            up = vp.camera.upVector
        finally:
            cam.isSmoothTransition = False
            vp.camera = cam
        if abs(up.y) > abs(up.z):
            return True
        if abs(up.z) > abs(up.y):
            return False
    except Exception:
        pass
    try:
        return (_app.preferences.generalPreferences.defaultModelingOrientation ==
                adsk.core.DefaultModelingOrientations.YUpModelingOrientation)
    except Exception:
        return False


def _model_bbox(design):
    """Boite des corps visibles hors calpinage : ((min), (max)) en cm."""
    mn, mx = [1e9] * 3, [-1e9] * 3
    for b in collect_bodies(design, None):
        bb = b.boundingBox
        for i, (a, c) in enumerate(((bb.minPoint.x, bb.maxPoint.x), (bb.minPoint.y, bb.maxPoint.y),
                                    (bb.minPoint.z, bb.maxPoint.z))):
            mn[i] = min(mn[i], a)
            mx[i] = max(mx[i], c)
    if mn[0] > mx[0]:
        return (0.0, 0.0, 0.0), (0.0, 0.0, 0.0)
    return tuple(mn), tuple(mx)


def sheet_axes():
    """Axes monde (ex, ey, ez) du repere des panneaux."""
    if _y_up:
        return (1, 0, 0), (0, 0, -1), (0, 1, 0)
    return (1, 0, 0), (0, 1, 0), (0, 0, 1)


def sheet_origins(design, result):
    """Origine monde (cm) de chaque panneau, a cote du modele, sur le sol
    (XY si Z en haut, XZ si Y en haut). Renvoie (liste, fonction de pose)."""
    global _y_up
    if _y_up is None:
        _y_up = _is_y_up()
    y_up = _y_up
    bb = _model_bbox(design)
    gap = 20.0
    x0 = bb[1][0] + 30.0
    origins = []
    k = 0
    for g in result['groups']:
        for _s in g['sheets']:
            # panneaux poses sur le sol (Z=0, ou Y=0 en Y haut), a cote du modele
            if y_up:
                origins.append((x0, 0.0, bb[1][2] - k * (result['W'] / 10.0 + gap)))
            else:
                origins.append((x0, bb[0][1] + k * (result['W'] / 10.0 + gap), 0.0))
            k += 1

    def to_world(o, x_mm, y_mm):
        if y_up:
            return (o[0] + x_mm / 10.0, o[1], o[2] - y_mm / 10.0)
        return (o[0] + x_mm / 10.0, o[1] + y_mm / 10.0, o[2])
    return origins, to_world


def draw_preview(design, result):
    global _preview_cg
    clear_preview()
    if not result or not result['groups']:
        return
    origins, to_world = sheet_origins(design, result)
    L, W, m = result['L'], result['W'], result['margin']
    sheet_c, sheet_i, part_c, part_i, grav_c, grav_i = [], [], [], [], [], []
    flip_c, flip_i = [], []   # pieces retournees : couleur a part
    cut_c, cut_i = [], []     # coupes prioritaires (scie a format)

    def add_ring(coords, idx, o, ring):
        base = len(coords) // 3
        for (x, y) in ring:
            coords.extend(to_world(o, x, y))
        n = len(ring)
        for i in range(n):
            idx.extend([base + i, base + (i + 1) % n])

    k = 0
    cnc_progress.etape("Dessin de l'apercu...", 0, sum(len(g['sheets']) for g in result['groups']))
    for g in result['groups']:
        for s in g['sheets']:
            _pump(1)
            o = origins[k]
            k += 1
            add_ring(sheet_c, sheet_i, o, [(0, 0), (L, 0), (L, W), (0, W)])
            if m > 0:
                add_ring(sheet_c, sheet_i, o, [(m, m), (L - m, m), (L - m, W - m), (m, W - m)])
            for pl in s['placements']:
                for reg in pl['regions']:
                    for ring in reg:
                        if pl.get('flip'):
                            add_ring(flip_c, flip_i, o, ring)
                        else:
                            add_ring(part_c, part_i, o, ring)
                for a, b in pl.get('grav', []):
                    base = len(grav_c) // 3
                    grav_c.extend(to_world(o, a[0], a[1]))
                    grav_c.extend(to_world(o, b[0], b[1]))
                    grav_i.extend([base, base + 1])
            for c in s.get('cuts') or []:
                if c.get('level') != 1:
                    continue
                a, b = c['seg']
                base = len(cut_c) // 3
                cut_c.extend(to_world(o, a[0], a[1]))
                cut_c.extend(to_world(o, b[0], b[1]))
                cut_i.extend([base, base + 1])
    try:
        _preview_cg = design.rootComponent.customGraphicsGroups.add()
        _preview_cg.id = PREVIEW_ID
        # traits affines (demande du 2026-11-04)
        for coords, idx, color, weight in ((sheet_c, sheet_i, (255, 170, 80, 255), 1.0),
                                           (part_c, part_i, (255, 90, 0, 255), 1.5),
                                           (flip_c, flip_i, (230, 40, 170, 255), 2.0),
                                           (grav_c, grav_i, (40, 190, 255, 255), 1.5),
                                           (cut_c, cut_i, (0, 200, 120, 255), 3.5)):
            if not idx:
                continue
            cc = adsk.fusion.CustomGraphicsCoordinates.create(coords)
            lines = _preview_cg.addLines(cc, idx, False)
            lines.color = adsk.fusion.CustomGraphicsSolidColorEffect.create(adsk.core.Color.create(*color))
            lines.weight = weight
            lines.depthPriority = 1
        _app.activeViewport.refresh()
    except Exception:
        _dbg('draw_preview EXCEPTION: ' + traceback.format_exc())


# --- Creation (Deplacer / Copier), retrait, export DXF ----------------------------
#
# Deplacer (defaut) : une fonction Deplacer par corps, dans le composant du
# corps (transformation exprimee dans l'espace du composant, l'occurrence
# ne bouge pas). Copier : un composant "Calpinage CNC" avec un sous-composant
# par panneau, chaque piece y est copiee figee (BaseFeature, comme Dogbone).
# Dans les deux cas : une esquisse par panneau avec le brut, le contour des
# pieces (projete : arcs exacts pour le DXF) et les gravures trait simple
# reposees sur chaque piece. Tout est regroupe dans un groupe d'historique
# "Calpinage CNC", ajoute en FIN d'historique, apres tous les usinages :
# "Remettre en assemblage" le supprime et les pieces reviennent en place.

def _p3(t):
    return adsk.core.Point3D.create(t[0], t[1], t[2])


def _v3(t):
    return adsk.core.Vector3D.create(t[0], t[1], t[2])


def _placement_matrix(frame, pl, o_sheet, axes, inv=None):
    """Matrice monde qui pose la piece (repere o, u, v, up) sur le panneau.
    inv : inverse de la transformation d'occurrence ; les deux reperes sont
    alors ramenes dans l'espace du composant avant l'alignement (aucune
    composition de matrices, dont l'ordre est facile a inverser)."""
    o, u, v, up, d_bot, d_top = frame
    if pl.get('flip'):
        # piece retournee : l'ancien dessous devient le dessus (y local -> -y)
        v = adsk.core.Vector3D.create(-v.x, -v.y, -v.z)
        up = adsk.core.Vector3D.create(-up.x, -up.y, -up.z)
        d_bot, d_top = -d_top, -d_bot
    ex, ey, ez = axes
    t = math.radians(pl['rot'])
    c, sn = math.cos(t), math.sin(t)
    h = _dot(_vec(o), up) - d_bot
    x, y = pl['tx'] / 10.0, pl['ty'] / 10.0
    to_o = adsk.core.Point3D.create(o_sheet[0] + ex[0] * x + ey[0] * y + ez[0] * h,
                                    o_sheet[1] + ex[1] * x + ey[1] * y + ez[1] * h,
                                    o_sheet[2] + ex[2] * x + ey[2] * y + ez[2] * h)
    to_x = adsk.core.Vector3D.create(c * ex[0] + sn * ey[0], c * ex[1] + sn * ey[1], c * ex[2] + sn * ey[2])
    to_y = adsk.core.Vector3D.create(-sn * ex[0] + c * ey[0], -sn * ex[1] + c * ey[1], -sn * ex[2] + c * ey[2])
    to_z = _v3(ez)
    fr = [o.copy(), u.copy(), v.copy(), up.copy()]
    if inv is not None:
        for e in fr + [to_o, to_x, to_y, to_z]:
            e.transformBy(inv)
    m = adsk.core.Matrix3D.create()
    m.setToAlignCoordinateSystems(fr[0], fr[1], fr[2], fr[3], to_o, to_x, to_y, to_z)
    return m


def _flip_model_gravure(p):
    """Piece retournee sur le panneau : sa gravure trait simple passe, dans
    le modele, sur l'autre grande face (en miroir autour de son axe, pour
    etre lisible quand la piece est retournee). Modifie les esquisses
    "Gravure CNC" d'origine : le changement reste apres "Remettre en
    assemblage". Renvoie le nombre de traits deplaces."""
    lines = [ln for ln in p.get('_grav_lines', []) if ln is not None and ln.isValid]
    if not lines:
        return 0
    o, u, v, up, d_bot, d_top = p['_frame']
    cv = p.get('grav_cv', 0.0) / 10.0
    dz = d_top - d_bot
    n = 0
    for ln in lines:
        sk = ln.parentSketch
        pts = []
        for sp in (ln.startSketchPoint, ln.endSketchPoint):
            q = sp.worldGeometry
            pv = _dot(o.vectorTo(q), v)
            k = 2.0 * (cv - pv)
            pts.append(adsk.core.Point3D.create(q.x + k * v.x - dz * up.x,
                                                q.y + k * v.y - dz * up.y,
                                                q.z + k * v.z - dz * up.z))
        try:
            sk.sketchCurves.sketchLines.addByTwoPoints(sk.modelToSketchSpace(pts[0]),
                                                       sk.modelToSketchSpace(pts[1]))
            ln.deleteMe()
            n += 1
        except Exception:
            _dbg('flip gravure EXCEPTION: ' + traceback.format_exc())
    return n


def _occ_matrix(body):
    occ = body.assemblyContext
    return occ.transform2.copy() if occ is not None else adsk.core.Matrix3D.create()


def find_groups(design):
    out = []
    try:
        tl = design.timeline
        for i in range(tl.timelineGroups.count):
            g = tl.timelineGroups.item(i)
            if g.name.startswith(GROUP_NAME):
                out.append(g)
    except Exception:
        pass
    return out


def state(design):
    try:
        a = design.attributes.itemByName(ATTR_GROUP, 'etat')
        if a is not None and find_groups(design):
            return json.loads(a.value)
    except Exception:
        pass
    return None


def _set_state(design, st):
    try:
        if st is None:
            a = design.attributes.itemByName(ATTR_GROUP, 'etat')
            if a is not None:
                a.deleteMe()
        else:
            design.attributes.add(ATTR_GROUP, 'etat', json.dumps(st))
    except Exception:
        _dbg('set_state EXCEPTION: ' + traceback.format_exc())


def _gravure_sketches(design):
    out = []
    for comp in design.allComponents:
        for sk in comp.sketches:
            if sk.name.startswith('Gravure CNC'):
                out.append(sk)
    return out


def _delete_group(g):
    """Supprime un groupe d'historique et son contenu. Un groupe deplie dans
    l'historique refuse deleteMe(True) : on le replie d'abord ; en dernier
    recours on degroupe et on supprime ses elements, du dernier au premier."""
    try:
        g.isCollapsed = True
    except Exception:
        pass
    try:
        if g.deleteMe(True):
            return True
    except Exception:
        _dbg('remove group EXCEPTION: ' + traceback.format_exc())
    try:
        ents = []
        for i in range(g.count):
            try:
                ents.append(g.item(i).entity)
            except Exception:
                pass
        g.deleteMe(False)
        for e in reversed(ents):
            try:
                if e is not None and e.isValid:
                    e.deleteMe()
            except Exception:
                _dbg('remove item EXCEPTION: ' + traceback.format_exc())
        return True
    except Exception:
        _dbg('remove ungroup EXCEPTION: ' + traceback.format_exc())
    return False


def remove_calpinage(design):
    """Supprime le(s) groupe(s) "Calpinage CNC" et tout leur contenu : les
    pieces deplacees reviennent en place, les copies disparaissent. Remet
    visibles les esquisses de gravure masquees a la creation."""
    st = state(design) or {}
    n = 0
    # configurations de Fabrication du calpinage : avant les corps qu'elles usinent
    try:
        remove_usinage()
    except Exception:
        _dbg('remove usinage EXCEPTION: ' + traceback.format_exc())
    for g in reversed(find_groups(design)):
        if _delete_group(g):
            n += 1
    _store_esquisses(design, None)
    hidden = set(st.get('hidden_sketches', []))
    if hidden:
        for sk in _gravure_sketches(design):
            if sk.name in hidden:
                try:
                    sk.isLightBulbOn = True
                except Exception:
                    pass
    _set_state(design, None)
    _store_pdf_doc(design, None)
    return n


# --- Export PDF ------------------------------------------------------------------

def pdf_doc(result, title):
    """Donnees du PDF (calpinage_pdf.build_pdf) depuis un resultat de compute."""
    n_pl = {}
    for g in result['groups']:
        for s in g['sheets']:
            for pl in s['placements']:
                n_pl[pl['id']] = n_pl.get(pl['id'], 0) + 1
    doc = {'title': title, 'L': result['L'], 'W': result['W'], 'margin': result.get('margin', 0), 'groups': []}
    for g in result['groups']:
        sheets = []
        for s in g['sheets']:
            pls = []
            for pl in s['placements']:
                lab = pl['name'].split(':')[0]
                if n_pl.get(pl['id'], 1) > 1:
                    lab += ' - ex %d' % (int(pl.get('inst', 0)) + 1)
                pls.append({'label': lab, 'flip': bool(pl.get('flip')), 'name': pl['name'],
                            'regions': _round_regions(pl['regions']),
                            'depths': list(pl.get('depths') or []),
                            'grav': [[[round(a[0], 1), round(a[1], 1)], [round(b[0], 1), round(b[1], 1)]]
                                     for a, b in pl.get('grav', [])]})
            sheets.append({'index': s['index'], 'placements': pls, 'cuts': list(s.get('cuts') or []),
                           'bandes': list(s.get('bandes') or []), 'plan': list(s.get('plan') or [])})
        doc['groups'].append({'label': g['label'], 'th_mm': g['th_mm'], 'sheets': sheets})
    return doc


def _store_pdf_doc(design, doc):
    """Garde le dessin du calpinage cree dans le document (PDF possible plus
    tard, meme apres fermeture de Fusion)."""
    import base64
    import zlib
    try:
        if doc is None:
            a = design.attributes.itemByName(ATTR_GROUP, 'pdf')
            if a is not None:
                a.deleteMe()
        else:
            design.attributes.add(ATTR_GROUP, 'pdf', base64.b64encode(
                zlib.compress(json.dumps(doc, separators=(',', ':')).encode('utf-8'))).decode('ascii'))
    except Exception:
        _dbg('store_pdf EXCEPTION: ' + traceback.format_exc())


def _stored_pdf_doc(design):
    import base64
    import zlib
    try:
        a = design.attributes.itemByName(ATTR_GROUP, 'pdf')
        if a is not None:
            return json.loads(zlib.decompress(base64.b64decode(a.value)).decode('utf-8'))
    except Exception:
        _dbg('stored_pdf EXCEPTION: ' + traceback.format_exc())
    return None


def _sheet_sketch(comp, name, th=0.0):
    """Esquisse du panneau sur le plan du DESSUS des pieces (sol + epaisseur) :
    brut, contours projetes et gravures y sont tous dans le plan de
    l'esquisse, donc au meme Z dans le DXF (avant : contours a Z=0 et
    gravures a Z=epaisseur)."""
    base = comp.xZConstructionPlane if _y_up else comp.xYConstructionPlane
    plane = base
    if th > 0:
        ez = sheet_axes()[2]
        sgn = 1.0
        try:
            nb = base.geometry.normal
            sgn = 1.0 if (nb.x * ez[0] + nb.y * ez[1] + nb.z * ez[2]) >= 0 else -1.0
        except Exception:
            pass
        try:
            pi = comp.constructionPlanes.createInput()
            pi.setByOffset(base, adsk.core.ValueInput.createByReal(sgn * th))
            plane = comp.constructionPlanes.add(pi)
            plane.name = name + ' (dessus)'
            plane.isLightBulbOn = False
        except Exception:
            _dbg('plan dessus EXCEPTION: ' + traceback.format_exc())
            plane = base
    sk = comp.sketches.add(plane)
    sk.name = name
    try:
        sk.isComputeDeferred = True
    except Exception:
        pass
    return sk


def _sk_line(sk, a, b, xf=None):
    pa, pb = _p3(a), _p3(b)
    if xf is not None:
        pa.transformBy(xf)
        pb.transformBy(xf)
    sk.sketchCurves.sketchLines.addByTwoPoints(sk.modelToSketchSpace(pa), sk.modelToSketchSpace(pb))


def _project_top(sk, body, up, d_top_world):
    """Projette dans l'esquisse les faces du dessus du corps pose (plan du
    dessus du panneau) : contour exterieur, trous et ouvertures de poche,
    en courbes exactes (arcs) pour le DXF."""
    n = 0
    for f in body.faces:
        if adsk.core.Plane.cast(f.geometry) is None:
            continue
        nf = _face_normal(f)
        if nf is None or _dot(nf, up) < 1.0 - _TOL_PAR:
            continue
        if abs(_dot(_vec(f.pointOnFace), up) - d_top_world) > 0.01:
            continue
        try:
            sk.project(f)
            n += 1
        except Exception:
            _dbg('project EXCEPTION: ' + traceback.format_exc())
    return n


def _fmt_mm(v):
    return ('%.1f' % v).rstrip('0').rstrip('.')


def _create_brut(comp, o_sheet, axes, L, W, th, name):
    """Corps du panneau brut (L x W x epaisseur, du sol au dessus des pieces),
    dans sa propre fonction de base, semi-transparent pour voir les pieces."""
    ex, ey, ez = axes
    c = tuple(o_sheet[i] + ex[i] * L / 2 + ey[i] * W / 2 + ez[i] * th / 2 for i in range(3))
    obb = adsk.core.OrientedBoundingBox3D.create(_p3(c), _v3(ex), _v3(ey), L, W, th)
    box = adsk.fusion.TemporaryBRepManager.get().createBox(obb)
    bf = comp.features.baseFeatures.add()
    bf.startEdit()
    comp.bRepBodies.add(box, bf)
    bf.finishEdit()
    try:
        bf.name = name
    except Exception:
        pass
    b = bf.bodies.item(0)
    b.name = name
    b.attributes.add(ATTR_GROUP, 'brut', name)
    try:
        b.opacity = 0.3
    except Exception:
        pass
    return b


def _dogbone_radii(design):
    """{rayon du trou (cm): diametre de fraise (mm)} des dogbones du document :
    parametres enregistres par Dogbone CNC sur ses fonctions, sinon ses
    preferences (8 mm + jeu)."""
    rs = {}
    try:
        for a in design.findAttributes('DogboneCNC', 'params'):
            try:
                d = json.loads(a.value)
                diam = float(d['diam_mm'])
                rs[round((diam / 2.0 + float(d.get('jeu_mm', 0.1))) / 10.0, 4)] = diam
            except Exception:
                pass
    except Exception:
        _dbg('dogbone radii EXCEPTION: ' + traceback.format_exc())
    if not rs:
        diam = _dogbone_diam()
        rs[round((diam / 2.0 + _dogbone_jeu()) / 10.0, 4)] = diam
    return rs


def _usinage_faces(bodies, ez, z_bot, th, radii):
    """Faces des pieces posees sur un panneau : faces du dessous (contour 2D,
    contours exterieurs et interieurs avec l'interieur des dogbones) et
    cylindres verticaux au rayon des dogbones, debouchants ou borgnes."""
    bottoms, through, blind = [], [], []
    for b in bodies:
        for f in b.faces:
            g = f.geometry
            if adsk.core.Plane.cast(g) is not None:
                nf = _face_normal(f)
                if (nf is not None and _dot(nf, ez) < -1.0 + _TOL_PAR
                        and abs(_dot(_vec(f.pointOnFace), ez) - z_bot) < 0.01):
                    bottoms.append(f)
                continue
            cyl = adsk.core.Cylinder.cast(g)
            if cyl is None or not any(abs(cyl.radius - r) < 0.002 for r in radii):
                continue
            ax = cyl.axis
            ax.normalize()
            if abs(abs(_dot(ax, ez)) - 1.0) > _TOL_PAR:
                continue
            bb = f.boundingBox
            h = abs(_dot(bb.maxPoint.asVector(), ez) - _dot(bb.minPoint.asVector(), ez))
            (through if h >= th - 0.01 else blind).append(f)
    return bottoms, through, blind


def _set_params(op, values):
    for n, v in values:
        p = op.parameters.itemByName(n)
        if p is None:
            continue
        try:
            p.expression = v
        except Exception:
            _dbg('param %s=%s EXCEPTION: %s' % (n, v, traceback.format_exc().strip().splitlines()[-1]))


def _u(cfg, k):
    """Reglage d'usinage k (prefs 'u_...'), valeur par defaut si absent."""
    v = (cfg or {}).get(k)
    return DEFAULT_PREFS[k] if v is None else v


def _mm(v):
    return '%g mm' % round(float(v), 3)


def _hauteurs(cfg):
    return [('clearanceHeight_mode', "'from retract height'"), ('clearanceHeight_offset', _mm(_u(cfg, 'u_degag'))),
            ('retractHeight_mode', "'from stock top'"), ('retractHeight_offset', _mm(_u(cfg, 'u_retrait'))),
            ('feedHeight_mode', "'from top'"), ('feedHeight_offset', _mm(_u(cfg, 'u_avance'))),
            ('topHeight_mode', "'from stock top'"), ('topHeight_offset', '0 mm')]


def _passes(cfg, depth_mm):
    """Passes en profondeur pour couper depth_mm : passe max ou nombre de passes."""
    if _u(cfg, 'u_pass_mode') == 'passes':
        n = max(1, int(_u(cfg, 'u_n_passes')))
        if n == 1:
            return [('doMultipleDepths', 'false')]
        step = math.ceil(depth_mm / n * 100.0) / 100.0
    else:
        step = float(_u(cfg, 'u_pass_depth'))
        if step <= 0 or step >= depth_mm:
            return [('doMultipleDepths', 'false')]
    return [('doMultipleDepths', 'true'), ('maximumStepdown', _mm(step)), ('useEvenStepdowns', 'true')]


def _cam():
    """Produit Fabrication du document (None s'il n'a jamais ete ouvert)."""
    try:
        return adsk.cam.CAM.cast(_app.activeDocument.products.itemByProductType('CAMProductType'))
    except Exception:
        return None


def remove_usinage():
    """Supprime les configurations de Fabrication creees par le calpinage."""
    cam = _cam()
    n = 0
    if cam is None:
        return 0
    for i in range(cam.setups.count - 1, -1, -1):
        st = cam.setups.item(i)
        try:
            if st.name.startswith(GROUP_NAME):
                st.deleteMe()
                n += 1
        except Exception:
            _dbg('remove setup EXCEPTION: ' + traceback.format_exc())
    return n


FRAISE_MARQUE = 'Felder Format 4 H80'
FRAISE_LIB_URL = 'toollibraryroot://Local/Library'   # bibliotheque d'outils locale de Fusion


def _fraise_cfg(cfg, role):
    """(diametre mm, dents, tr/min, avance mm/min) de la fraise du role 'c' ou 'p'."""
    d = max(1.0, min(40.0, float(_u(cfg, 'u_%s_diam' % role))))
    z = max(1, min(8, int(_u(cfg, 'u_%s_dents' % role))))
    n = max(1000, min(30000, int(float(_u(cfg, 'u_%s_rpm' % role)))))
    f = max(100.0, float(_u(cfg, 'u_%s_avance' % role)))
    return d, z, n, f


def _fraise_nom(d, z, role):
    return 'Fraise %s D%s mm Z%d - %s' % ('a detourer' if role == 'c' else 'a percer', _fmt_mm(d), z, FRAISE_MARQUE)


def _fraise_guid(d, z, role):
    return str(uuid.uuid5(uuid.NAMESPACE_URL, 'cnctoolkit/fraise-%s/%g/%d' % (role, d, z)))


def _fraise_json(d, z, n, f, role):
    """Fraise droite pour bois et contreplaque, sans porte-outil. Valeurs de
    coupe de depart (a ajuster selon la fraise reelle)."""
    fz = f / (n * z)
    vc = math.pi * d * n / 1000.0        # m/min
    lcf = 35.0 if d >= 8 else max(10.0, d * 3.0)
    preset = {
        'description': 'Bois / contreplaque', 'f_n': f / n, 'f_z': fz,
        'guid': str(uuid.uuid5(uuid.NAMESPACE_URL, 'cnctoolkit/preset/%s/%g/%d' % (role, d, z))),
        'material': {'category': 'all', 'query': '', 'use-hardness': False},
        'n': n, 'n_ramp': n, 'name': 'Bois et contreplaque', 'ramp-angle': 3,
        'tool-coolant': 'disabled', 'use-stepdown': False, 'use-stepover': False,
        'v_c': vc, 'v_f': f, 'v_f_leadIn': f, 'v_f_leadOut': f,
        'v_f_plunge': min(f, 1500.0), 'v_f_ramp': min(f, 2500.0), 'v_f_transition': f,
    }
    return {
        'BMC': 'carbide', 'GRADE': 'Mill Generic', 'description': _fraise_nom(d, z, role),
        'geometry': {'CSP': False, 'DC': d, 'HAND': True, 'LB': lcf + 5.0, 'LCF': lcf, 'NOF': z, 'NT': 1,
                     'OAL': lcf + 55.0, 'RE': 0, 'SFDM': d, 'TA': 0, 'TP': 0,
                     'shoulder-diameter': d, 'shoulder-length': lcf, 'thread-profile-angle': 60,
                     'tip-diameter': d, 'tip-length': 0, 'tip-offset': 0},
        'guid': _fraise_guid(d, z, role),
        'post-process': {'break-control': False, 'comment': '', 'diameter-offset': 0, 'length-offset': 0,
                         'live': True, 'manual-tool-change': False, 'number': 1 if role == 'c' else 2, 'turret': 0},
        'product-id': '', 'product-link': '',
        'start-values': {'presets': [preset]},
        'type': 'flat end mill', 'unit': 'millimeters', 'vendor': 'Felder',
    }


def _lib_tool(lib, nom):
    """Outil de la bibliotheque dont la description contient nom (Fusion
    renumerote l'identifiant a l'enregistrement : on reconnait par le nom)."""
    for i in range(lib.count):
        try:
            if nom in (lib.item(i).description or ''):
                return lib.item(i)
        except Exception:
            pass
    return None


def _local_lib():
    tl = adsk.cam.CAMManager.get().libraryManager.toolLibraries
    url = adsk.core.URL.create(FRAISE_LIB_URL)
    return tl, url, tl.toolLibraryAtURL(url)


def fraises_bibliotheque():
    """Descriptions des outils de la bibliotheque locale de Fusion."""
    try:
        lib = _local_lib()[2]
        return [lib.item(i).description for i in range(lib.count)]
    except Exception:
        _dbg('bibliotheque EXCEPTION: ' + traceback.format_exc())
        return []


def _assurer_fraise(cam, cfg, role):
    """Fraise du role 'c' (contour) ou 'p' (percage) : outil de la bibliotheque
    locale choisi par l'utilisateur, ou nouvelle fraise Felder enregistree une
    seule fois dans la bibliotheque locale (reutilisee par tous les projets).
    Elle est ajoutee au document si elle n'y est pas deja (jamais de doublon :
    reconnue par son nom). Retourne (outil du document ou None, nom, message)."""
    choix = str(_u(cfg, 'u_fraise_' + role))
    if choix == 'aucune':
        return None, '', ''
    dl = cam.documentToolLibrary
    msg = []
    if choix.startswith('lib:'):
        nom = choix[4:]
        tool = _lib_tool(dl, nom)
        if tool is None:
            try:
                src = _lib_tool(_local_lib()[2], nom)
                if src is not None:
                    dl.add(adsk.cam.Tool.createFromJson(src.toJson()))
                    tool = _lib_tool(dl, nom)
            except Exception:
                _dbg('fraise lib EXCEPTION: ' + traceback.format_exc())
        return tool, nom, 'outil de la bibliotheque'
    d, z, n, f = _fraise_cfg(cfg, role)
    nom = _fraise_nom(d, z, role)
    js = json.dumps(_fraise_json(d, z, n, f, role))
    try:
        tl, url, lib = _local_lib()
        if lib is not None and _lib_tool(lib, nom) is None:
            lib.add(adsk.cam.Tool.createFromJson(js))
            tl.updateToolLibrary(url, lib)
            msg.append("enregistree dans la bibliotheque locale")
        else:
            msg.append("deja dans la bibliotheque locale")
    except Exception:
        _dbg('fraise bibliotheque EXCEPTION: ' + traceback.format_exc())
        msg.append("bibliotheque locale indisponible")
    tool = _lib_tool(dl, nom)
    if tool is None:
        try:
            dl.add(adsk.cam.Tool.createFromJson(js))
            tool = _lib_tool(dl, nom)
        except Exception:
            _dbg('fraise document EXCEPTION: ' + traceback.format_exc())
    return tool, nom, '; '.join(msg)


def _outil_op(oi, tool):
    """Fraise et reglages de coupe de la fraise pour une operation en creation."""
    if tool is None:
        return
    try:
        oi.tool = tool
        if tool.presets.count:
            oi.toolPreset = tool.presets.item(0)
    except Exception:
        _dbg('outil operation EXCEPTION: ' + traceback.format_exc())


def _drill_cycle(cfg):
    if _u(cfg, 'u_cycle') == 'debourrage':
        return [('cycleType', "'deep-drilling'"), ('peckingDepth', _mm(_u(cfg, 'u_peck')))]
    return [('cycleType', "'drilling'")]


_setups_a_calculer = []


def calculer_trajectoires():
    """Calcule les trajectoires des operations creees par generer_usinage. A
    appeler a la toute fin de la creation : modifier le document ensuite
    (attributs, historique) rend les trajectoires obsoletes. Sans ce calcul
    les operations restent signalees jusqu'a ce que l'utilisateur ouvre chacune
    et clique sur OK."""
    msgs = []
    setups = list(_setups_a_calculer)
    del _setups_a_calculer[:]
    if not setups:
        return msgs
    ws_design = _ui.activeWorkspace
    try:
        _ui.workspaces.itemById('CAMEnvironment').activate()
        cam = _cam()
        ops = adsk.core.ObjectCollection.create()
        for st in setups:
            for i in range(st.allOperations.count):
                ops.add(st.allOperations.item(i))
        if cam is None or not ops.count:
            return msgs
        bad = []
        for _tour in range(2):
            fut = cam.generateToolpath(ops)
            t0 = time.time()
            while not fut.isGenerationCompleted and time.time() - t0 < 300:
                _pump(0)
                adsk.doEvents()
            bad = [ops.item(i) for i in range(ops.count)
                   if not (ops.item(i).hasToolpath and ops.item(i).isToolpathValid and not ops.item(i).hasError)]
            if not bad:
                break
        for o in bad:
            msgs.append("%s : %s" % (o.name, (o.error or o.warning or "trajectoire a recalculer").strip()))
        msgs.append("Trajectoires calculees : %d operation(s) sur %d." % (ops.count - len(bad), ops.count))
    except Exception:
        _dbg('trajectoires EXCEPTION: ' + traceback.format_exc())
        msgs.append("Trajectoires non calculees : a regenerer dans Fabrication.")
    finally:
        try:
            ws_design.activate()
        except Exception:
            pass
    return msgs


def generer_usinage(design, sheets, cfg=None):
    """Prepare la Fabrication, sans outil : une configuration par panneau
    (brut = corps Brut, origine au coin choisi du panneau), un percage des
    dogbones (tous les cylindres au rayon des dogbones) et un contour 2D
    traversant des pieces (faces du dessous : contours exterieurs,
    interieurs et interieur des dogbones), regles par la section Usinage
    du panneau (cfg = prefs 'u_...'). sheets : (nom, brut, corps, o_sheet, th)."""
    msgs = []
    ws_design = _ui.activeWorkspace
    ws = _ui.workspaces.itemById('CAMEnvironment')
    ws.activate()
    try:
        cam = _cam()
        if cam is None:
            return ["Fabrication indisponible : usinage non genere."]
        axes = sheet_axes()
        ez = _v3(axes[2])
        ex = _v3(axes[0])
        radii = _dogbone_radii(design)
        diams = '/'.join(_fmt_mm(d) for d in sorted(set(radii.values())))
        L, W = None, None
        n_ops = 0
        coin = str(_u(cfg, 'u_coin'))
        depass = float(_u(cfg, 'u_depass'))
        maintien = _u(cfg, 'u_maintien')
        peau = float(_u(cfg, 'u_peau')) if maintien == 'peau' else 0.0
        h = _hauteurs(cfg)
        created_setups = []
        fraises = {}
        for role, titre in (('p', 'percage'), ('c', 'detourage')):
            try:
                t, f_nom, f_msg = _assurer_fraise(cam, cfg, role)
            except Exception:
                _dbg('fraise EXCEPTION: ' + traceback.format_exc())
                t, f_nom, f_msg = None, '', ''
            fraises[role] = t
            if t is not None:
                msgs.append("Fraise de %s : %s (%s)." % (titre, f_nom, f_msg))
            elif str(_u(cfg, 'u_fraise_' + role)) != 'aucune':
                msgs.append("Fraise de %s non creee : a choisir dans Fabrication." % titre)
        for name, brut, bodies, o_sheet, th in sheets:
            _pump(1)
            z_bot = _dot(_vec(_p3(o_sheet)), ez)
            bottoms, through, blind = _usinage_faces(bodies, ez, z_bot, th, radii)
            si = cam.setups.createInput(adsk.cam.OperationTypes.MillingOperation)
            si.models = list(bodies)
            si.stockMode = adsk.cam.SetupStockModes.SolidStock
            si.stockSolids = [brut]
            si.name = name
            setup = cam.setups.add(si)
            created_setups.append(setup)
            # repere : Z = normale du dessus du brut, X = longueur du panneau,
            # origine = coin choisi du panneau, sur le dessus ou le dessous
            bb = brut.boundingBox
            L = abs(_dot(bb.maxPoint.asVector(), ex) - _dot(bb.minPoint.asVector(), ex))
            W = abs(_dot(bb.maxPoint.asVector(), _v3(axes[1])) - _dot(bb.minPoint.asVector(), _v3(axes[1])))
            ox = L if coin.endswith('droite') else 0.0
            oy = W if coin.startswith('haut') else 0.0
            oz = 0.0 if _u(cfg, 'u_z0') == 'dessous' else th
            o_pt = _p3(tuple(o_sheet[i] + axes[0][i] * ox + axes[1][i] * oy + axes[2][i] * oz for i in range(3)))
            top = edge = vtx = None
            flip_x = False
            for f in brut.faces:
                nf = _face_normal(f)
                if nf is not None and _dot(nf, ez) > 1.0 - _TOL_PAR:
                    top = f
            for v in brut.vertices:
                if v.geometry.distanceTo(o_pt) < 0.01:
                    vtx = v
            if top is not None:
                for e in top.edges:
                    d = e.endVertex.geometry.asVector()
                    d.subtract(e.startVertex.geometry.asVector())
                    d.normalize()
                    if abs(abs(_dot(d, ex)) - 1.0) < _TOL_PAR and edge is None:
                        edge, flip_x = e, _dot(d, ex) < 0
            try:
                if top is not None and edge is not None:
                    setup.parameters.itemByName('wcs_orientation_mode').expression = "'axesZX'"
                    setup.parameters.itemByName('wcs_orientation_axisZ').value.value = [top]
                    setup.parameters.itemByName('wcs_orientation_axisX').value.value = [edge]
                    setup.parameters.itemByName('wcs_orientation_flipX').value.value = flip_x
                if vtx is not None:
                    setup.parameters.itemByName('wcs_origin_mode').expression = "'point'"
                    setup.parameters.itemByName('wcs_origin_point').value.value = [vtx]
            except Exception:
                _dbg('wcs EXCEPTION: ' + traceback.format_exc())
                msgs.append("%s : repere a regler a la main." % name)
            # percages des dogbones (tous les cylindres au rayon des dogbones)
            for faces, label, vals in (
                    (through, 'Percage dogbones',
                     [('bottomHeight_mode', "'from stock bottom'"), ('bottomHeight_offset', '0 mm'),
                      ('drillTipThroughBottom', 'true'), ('breakThroughDepth', _mm(_u(cfg, 'u_drill_dep')))]),
                    (blind, 'Percage dogbones borgnes',
                     [('bottomHeight_mode', "'from hole bottom'"), ('bottomHeight_offset', '0 mm'),
                      ('drillTipThroughBottom', 'false')])):
                if not faces:
                    continue
                oi = setup.operations.createInput('drill')
                _outil_op(oi, fraises['p'])
                op = setup.operations.add(oi)
                op.name = '%s \u00d8%s' % (label, diams)
                op.parameters.itemByName('holeFaces').value.value = faces
                _set_params(op, h + vals + _drill_cycle(cfg))
                n_ops += 1
            # contour 2D traversant : faces du dessous des pieces
            if bottoms:
                th_mm = th * 10.0
                commun = h + [
                    ('compensation', "'right'" if _u(cfg, 'u_sens') == 'opposition' else "'left'"),
                    ('doRamp', 'true' if _u(cfg, 'u_rampe') else 'false')]
                if _u(cfg, 'u_finition'):
                    commun += [('doMultipleFinishingPasses', 'true'), ('numberOfFinishingStepovers', '2'),
                               ('finishingStepover', _mm(_u(cfg, 'u_fin_surep')))]
                if maintien == 'attaches':
                    commun += [('group_tabs', 'true'), ('tabShape', "'rectangular'"),
                               ('tabWidth', _mm(_u(cfg, 'u_tab_w'))), ('tabHeight', _mm(_u(cfg, 'u_tab_h')))]
                    if _u(cfg, 'u_tab_mode') == 'distance':
                        commun += [('tabPositioning', "'distance'"), ('tabDistance', _mm(_u(cfg, 'u_tab_dist')))]
                    else:
                        commun += [('tabPositioning', "'tabCount'"),
                                   ('tabsPerContour', str(max(1, int(_u(cfg, 'u_tab_count')))))]
                ops = [('Contour 2D pieces',
                        [('bottomHeight_mode', "'from stock bottom'"),
                         ('bottomHeight_offset', _mm(peau if peau > 0 else -depass))]
                        + _passes(cfg, th_mm - peau if peau > 0 else th_mm + depass))]
                if peau > 0:
                    # peau d'oignon : derniere passe a part, une fois toutes les pieces detourees
                    ops.append(("Contour 2D peau d'oignon",
                                [('topHeight_mode', "'from stock bottom'"), ('topHeight_offset', _mm(peau)),
                                 ('bottomHeight_mode', "'from stock bottom'"), ('bottomHeight_offset', _mm(-depass)),
                                 ('doMultipleDepths', 'false')]))
                for op_name, vals in ops:
                    oi = setup.operations.createInput('contour2d')
                    _outil_op(oi, fraises['c'])
                    op = setup.operations.add(oi)
                    op.name = op_name
                    cv = op.parameters.itemByName('contours').value
                    sels = cv.getCurveSelections()
                    fc = sels.createNewFaceContourSelection()
                    fc.inputGeometry = bottoms
                    fc.loopType = adsk.cam.LoopTypes.AllLoops
                    cv.applyCurveSelections(sels)
                    _set_params(op, commun + vals)
                    n_ops += 1
        _setups_a_calculer[:] = created_setups
        if all(fraises.values()):
            msgs.append("Fabrication : %d configuration(s), %d operation(s) (dogbones %s mm)."
                        % (len(sheets), n_ops, diams))
        else:
            msgs.append("Fabrication : %d configuration(s), %d operation(s) a completer avec la fraise (dogbones %s mm)."
                        % (len(sheets), n_ops, diams))
    finally:
        try:
            ws_design.activate()
        except Exception:
            pass
    return msgs


def create_calpinage(design, parts, result, copier=False, brut=False, usinage=False, esquisse=False):
    """Cree le calpinage calcule (result de compute). Renvoie un resume."""
    msgs = []
    if design.designType != adsk.fusion.DesignTypes.ParametricDesignType:
        return {'error': "Le document n'a pas d'historique (conception directe) : impossible de retirer le calpinage ensuite."}
    tl = design.timeline
    if tl.markerPosition != tl.count:
        return {'error': "Le curseur de l'historique n'est pas a la fin : amene-le a la fin puis recommence."}
    by = {p['id']: p for p in parts}
    # plusieurs exemplaires d'une piece (nombre de meubles > 1) : seules des
    # copies peuvent les poser, et la gravure du modele n'est reposee sur
    # l'autre face que si tous les exemplaires sont retournes
    n_pl, n_fl = {}, {}
    for g in result['groups']:
        for s in g['sheets']:
            for pl in s['placements']:
                n_pl[pl['id']] = n_pl.get(pl['id'], 0) + 1
                if pl.get('flip'):
                    n_fl[pl['id']] = n_fl.get(pl['id'], 0) + 1
    if not copier and any(c > 1 for c in n_pl.values()):
        return {'error': "Plusieurs exemplaires : coche Copier (les vraies pieces ne peuvent etre deplacees qu'une fois)."}
    mixed = [i for i, c in n_fl.items() if c < n_pl[i]]
    if mixed:
        msgs.append("%d piece(s) retournee(s) sur une partie de leurs exemplaires seulement : "
                    "leur gravure reste sur sa face dans le modele (elle est bien en miroir sur le panneau)." % len(mixed))
    origins, _to_world = sheet_origins(design, result)
    axes = sheet_axes()
    ez = _v3(axes[2])
    root = design.rootComponent
    start = tl.count
    n_parts, n_grav, skipped = 0, 0, []
    flipped = {}
    multi = {}
    a_copier = {}        # mode Deplacer : id(panneau) -> [(pl, corps, matrice)] poses en copie
    multi_noms = {}      # composant repete -> nombre d'occurrences
    echec_dep = []       # deplacements refuses par Fusion (poses en copie)
    copie_comps = {}     # id(panneau) -> composant des copies (mode Deplacer)
    n_copies = [0]

    calp_occ = None
    if copier:
        calp_occ = root.occurrences.addNewComponent(adsk.core.Matrix3D.create())
        calp_occ.component.name = GROUP_NAME
    tbm = adsk.fusion.TemporaryBRepManager.get()

    k = 0
    placed_bodies = []   # (sketch, body, d_top monde)
    pending = []         # panneaux dont l'esquisse reste a creer
    t_0 = time.time()    # durees par etape, ecrites dans calpinage_debug.log
    cnc_progress.etape('Copie des pieces...' if copier else 'Deplacement des pieces...', 0,
                       sum(len(s['placements']) for g in result['groups'] for s in g['sheets']))
    for g in result['groups']:
        n_sh = len(g['sheets'])
        for s in g['sheets']:
            o_sheet = origins[k]
            k += 1
            title = '%s - %s - Panneau %d sur %d' % (GROUP_NAME, g['label'], s['index'], n_sh)
            th = g['th_mm'] / 10.0
            if copier:
                sh_occ = calp_occ.component.occurrences.addNewComponent(adsk.core.Matrix3D.create())
                sh_comp = sh_occ.component
                sh_comp.name = '%s - Panneau %d' % (g['label'], s['index'])
                bf = sh_comp.features.baseFeatures.add()
                bf.startEdit()
                copy_names = []
            for pl in s['placements']:
                _pump(1)
                p = by.get(pl['id'])
                if p is None:
                    continue
                body = p['_body']
                if body is None or not body.isValid:
                    skipped.append(pl['name'] + ' (corps introuvable)')
                    continue
                m = _placement_matrix(p['_frame'], pl, o_sheet, axes)
                if pl.get('flip') and pl['id'] not in flipped and pl['id'] not in mixed:
                    flipped[pl['id']] = _flip_model_gravure(p)
                occ = body.assemblyContext
                nat = body.nativeObject if occ is not None else body
                if copier:
                    # copie du corps tel qu'il est dans l'assemblage (proxy :
                    # coordonnees monde), puis pose sur le panneau
                    tmp = tbm.copy(body)
                    tbm.transform(tmp, m)
                    sh_comp.bRepBodies.add(tmp, bf)
                    nm = pl['name'].split(':')[0]
                    if n_pl.get(pl['id'], 1) > 1:
                        nm += ' - ex %d' % (int(pl.get('inst', 0)) + 1)
                    copy_names.append(nm)
                    n_parts += 1
                else:
                    comp = nat.parentComponent
                    if occ is not None:
                        if comp.id not in multi:
                            multi[comp.id] = root.allOccurrencesByComponent(comp).count
                        if multi[comp.id] > 1:
                            # composant insere plusieurs fois (meuble copie-colle) :
                            # le deplacer deplacerait toutes ses occurrences. La piece
                            # est posee en copie, apres tous les deplacements
                            # (CLINT 01, 2026-11-19 : 115 pieces sur 183 ignorees).
                            a_copier.setdefault(id(s), []).append((pl, body, m))
                            multi_noms[comp.name] = multi[comp.id]
                            continue
                    # La matrice d'une fonction Deplacer s'applique dans le repere
                    # MONDE, meme pour un corps de sous-composant (mesure le
                    # 2026-10-10 : translation de 10 en X = +10 en X monde
                    # sur un composant tourne) : la matrice monde convient.
                    mc = m
                    try:
                        coll = adsk.core.ObjectCollection.create()
                        coll.add(nat)
                        mi = comp.features.moveFeatures.createInput2(coll)
                        mi.defineAsFreeMove(mc)
                        mf = comp.features.moveFeatures.add(mi)
                    except Exception:
                        _dbg('deplacement EXCEPTION %s: %s' % (pl['name'], traceback.format_exc()))
                        a_copier.setdefault(id(s), []).append((pl, body, m))
                        echec_dep.append(pl['name'].split(':')[0])
                        continue
                    try:
                        mf.name = 'Calpinage ' + pl['name']
                    except Exception:
                        pass
                    n_parts += 1
                pl['_m'] = m
            if copier:
                bf.finishEdit()
                # noms apres finishEdit (relus via base_feat.bodies, lecon Dogbone)
                for i in range(min(bf.bodies.count, len(copy_names))):
                    try:
                        bf.bodies.item(i).name = copy_names[i]
                    except Exception:
                        pass
            pending.append((title, th, o_sheet, s, sh_comp if copier else None))

    # Mode Deplacer : pieces de composants repetes (ou deplacement refuse) posees
    # en copie dans un composant "Calpinage CNC", APRES tous les deplacements
    # (comme les esquisses). Retire avec le groupe d'historique.
    if a_copier:
        calp_occ = root.occurrences.addNewComponent(adsk.core.Matrix3D.create())
        calp_occ.component.name = GROUP_NAME + ' - copies'
        for g in result['groups']:
            for s in g['sheets']:
                lst = a_copier.get(id(s))
                if not lst:
                    continue
                cp_occ = calp_occ.component.occurrences.addNewComponent(adsk.core.Matrix3D.create())
                cp_comp = cp_occ.component
                cp_comp.name = '%s - Panneau %d (copies)' % (g['label'], s['index'])
                bf = cp_comp.features.baseFeatures.add()
                bf.startEdit()
                noms = []
                for pl, body, m in lst:
                    _pump(1)
                    try:
                        tmp = tbm.copy(body)
                        tbm.transform(tmp, m)
                        cp_comp.bRepBodies.add(tmp, bf)
                        noms.append(pl['name'].split(':')[0])
                        pl['_m'] = m
                        pl['_copie'] = True
                        n_parts += 1
                        n_copies[0] += 1
                    except Exception:
                        _dbg('copie EXCEPTION %s: %s' % (pl['name'], traceback.format_exc()))
                        skipped.append(pl['name'] + ' (copie impossible)')
                bf.finishEdit()
                for i in range(min(bf.bodies.count, len(noms))):
                    try:
                        bf.bodies.item(i).name = noms[i]
                    except Exception:
                        pass
                copie_comps[id(s)] = cp_comp

    # Esquisses des panneaux APRES tous les deplacements : une esquisse (et son
    # plan) creee dans la racine entre deux fonctions Deplacer faussait les
    # deplacements suivants des corps de la racine (pieces dispersees,
    # TENON CNC le 2026-10-12, reproduit sur un document jetable).
    t_moves = time.time()
    cnc_progress.etape('Esquisses des panneaux...', 0, len(pending))
    for title, th, o_sheet, s, sh_comp in pending:
        _pump(1)
        # esquisse du panneau : brut + gravures (contours projetes ensuite)
        sk_comp = sh_comp if copier else root
        # esquisse de projection : seulement utile au DXF, la Fabrication n'en
        # a pas besoin. Decochee, on garde de quoi la creer a l'export.
        sk = _sheet_sketch(sk_comp, title, th) if esquisse else None
        L, W = result['L'] / 10.0, result['W'] / 10.0
        ex, ey = axes[0], axes[1]
        ent = {'title': title, 'th': th, 'o': list(o_sheet), 'L': L, 'W': W, 'grav': [],
               'comp': sh_comp.entityToken if (copier and sh_comp is not None) else '',
               'comp_name': sh_comp.name if (copier and sh_comp is not None) else '', 'bodies': []}

        def S(x, y, z=0.0):
            return tuple(o_sheet[i] + ex[i] * x + ey[i] * y + axes[2][i] * z for i in range(3))
        corners = [S(0, 0, th), S(L, 0, th), S(L, W, th), S(0, W, th)]
        if sk is not None:
            for i in range(4):
                _sk_line(sk, corners[i], corners[(i + 1) % 4])
        for pl in s['placements']:
            p = by.get(pl['id'])
            if p is None or '_m' not in pl:
                continue
            for a, b in pl.get('grav', []):
                if sk is not None:
                    _sk_line(sk, S(a[0] / 10.0, a[1] / 10.0, th), S(b[0] / 10.0, b[1] / 10.0, th))
                else:
                    ent['grav'].append([round(v, 5) for v in S(a[0] / 10.0, a[1] / 10.0, th) + S(b[0] / 10.0, b[1] / 10.0, th)])
                n_grav += 1
        placed_bodies.append((sk, s, o_sheet, th, sh_comp, title, g, ent))

    t_sketches = time.time()
    # contours : projection des faces du dessus des pieces posees
    cnc_progress.etape('Contours des pieces...', 0, len(placed_bodies))
    bruts = []           # (nom, brut, corps, o_sheet, th) pour la Fabrication
    for sk, s, o_sheet, th, sh_comp, title, g, ent in placed_bodies:
        _pump(1)
        d_top_w = _dot(_vec(_p3(o_sheet)), ez) + th
        if sh_comp is not None:
            bodies = list(sh_comp.bRepBodies)
            sh_occ = None
            for occ in root.allOccurrencesByComponent(sh_comp):
                sh_occ = occ
            bodies = [b.createForAssemblyContext(sh_occ) if sh_occ is not None else b for b in bodies]
        else:
            bodies = []
            for pl in s['placements']:
                p = by.get(pl['id'])
                if p is None or '_m' not in pl or pl.get('_copie'):
                    continue
                b = p['_body']
                occ = b.assemblyContext
                try:
                    if occ is None:
                        b = root.bRepBodies.itemByName(b.name) or b
                    else:
                        b = b.nativeObject.createForAssemblyContext(occ)
                except Exception:
                    pass
                bodies.append(b)
            cp_comp = copie_comps.get(id(s))
            if cp_comp is not None:
                cp_occ = None
                for o in root.allOccurrencesByComponent(cp_comp):
                    cp_occ = o
                bodies += [b.createForAssemblyContext(cp_occ) if cp_occ is not None else b
                           for b in cp_comp.bRepBodies]
        if sk is not None:
            for b in bodies:
                try:
                    _project_top(sk, b, ez, d_top_w)
                except Exception:
                    _dbg('projection EXCEPTION: ' + traceback.format_exc())
            try:
                sk.isComputeDeferred = False
            except Exception:
                pass
        else:
            for b in bodies:
                try:
                    ent['bodies'].append(b.entityToken)
                except Exception:
                    pass
        if brut or usinage:
            # brut du panneau "Brut CP 18" (l'utilisateur, 2026-10-27), apres
            # les deplacements comme les esquisses
            n_sh = len(g['sheets'])
            nm = 'Brut CP %s' % _fmt_mm(g['th_mm'])
            if n_sh > 1 or len(result['groups']) > 1:
                nm += ' - Panneau %d' % s['index']
            try:
                b_brut = _create_brut(sh_comp if sh_comp is not None else root, o_sheet, axes,
                                      result['L'] / 10.0, result['W'] / 10.0, th, nm)
                if sh_comp is not None and sh_occ is not None:
                    b_brut = b_brut.createForAssemblyContext(sh_occ)
                bruts.append((title, b_brut, bodies, o_sheet, th))
            except Exception:
                _dbg('brut EXCEPTION: ' + traceback.format_exc())
                msgs.append('Brut non cree : ' + nm)

    # gravures d'origine : masquees en mode Deplacer (elles restent a la
    # position d'assemblage), remises par "Remettre en assemblage"
    hidden = []
    if not copier:
        for sk in _gravure_sketches(design):
            try:
                if sk.isLightBulbOn:
                    sk.isLightBulbOn = False
                    hidden.append(sk.name)
            except Exception:
                pass

    _store_esquisses(design, None if esquisse else [e[7] for e in placed_bodies])
    end = tl.count - 1
    if end >= start:
        try:
            grp = tl.timelineGroups.add(start, end)
            grp.name = GROUP_NAME + (' (copie)' if copier else '')
        except Exception:
            _dbg('timeline group EXCEPTION: ' + traceback.format_exc())
            msgs.append("Groupe d'historique non cree.")
    if bruts:
        msgs.append('%d brut(s) cree(s) (Brut CP %s).' % (len(bruts), _fmt_mm(result['groups'][0]['th_mm'])))
    if usinage and bruts:
        try:
            msgs += generer_usinage(design, bruts, usinage if isinstance(usinage, dict) else None)
        except Exception:
            _dbg('usinage EXCEPTION: ' + traceback.format_exc())
            msgs.append('Usinage non genere : ' + traceback.format_exc().strip().splitlines()[-1])
    _dbg('creation : deplacements %.1fs, esquisses %.1fs, contours %.1fs'
         % (t_moves - t_0, t_sketches - t_moves, time.time() - t_sketches))
    _set_state(design, {'mode': 'copier' if copier else 'deplacer', 'hidden_sketches': hidden,
                        'L': result['L'], 'W': result['W'],
                        'n_sheets': sum(len(g['sheets']) for g in result['groups'])})
    _store_pdf_doc(design, pdf_doc(result, _doc_title()))
    if usinage and bruts:
        msgs += calculer_trajectoires()
    if n_copies[0]:
        det = ', '.join('%s x%d' % (k, v) for k, v in sorted(multi_noms.items()))
        msgs.insert(0, "%d piece(s) posee(s) en COPIE dans le composant '%s - copies' : %s"
                    % (n_copies[0], GROUP_NAME,
                       ("elles viennent de composants inseres plusieurs fois (%s) ; deplacer l'une "
                        "deplacerait toutes les autres. Les originaux restent en place dans l'assemblage." % det)
                       if multi_noms else "Fusion a refuse leur deplacement."))
    if echec_dep:
        msgs.append('Deplacement refuse par Fusion (posee en copie) : ' + ', '.join(echec_dep[:10])
                    + ('...' if len(echec_dep) > 10 else ''))
    if skipped:
        msgs.insert(0, 'ATTENTION : %d piece(s) NON placee(s) : ' % len(skipped) + ', '.join(skipped[:10])
                    + ('...' if len(skipped) > 10 else ''))
    return {'error': None, 'n_parts': n_parts, 'n_copies': n_copies[0], 'n_skipped': len(skipped),
            'skipped': skipped[:30], 'n_grav': n_grav, 'n_flip': len(flipped),
            'n_sheets': sum(len(g['sheets']) for g in result['groups']),
            'mode': 'copier' if copier else 'deplacer', 'messages': msgs}


def _store_esquisses(design, entries):
    """Memorise de quoi creer les esquisses de projection plus tard (export
    DXF) quand elles n'ont pas ete creees avec le calpinage."""
    import base64
    import zlib
    try:
        a = design.attributes.itemByName(ATTR_GROUP, 'esquisses')
        if a is not None:
            a.deleteMe()
        if entries:
            design.attributes.add(ATTR_GROUP, 'esquisses', base64.b64encode(
                zlib.compress(json.dumps(entries, separators=(',', ':')).encode('utf-8'))).decode('ascii'))
    except Exception:
        _dbg('store_esquisses EXCEPTION: ' + traceback.format_exc())


def _esquisses_existantes(design):
    return [sk for comp in design.allComponents for sk in comp.sketches
            if sk.name.startswith(GROUP_NAME + ' - ')]


def make_esquisses(design):
    """Cree les esquisses de projection des panneaux (cadre, gravures, contours
    des faces du dessus) d'un calpinage cree sans elles. Renvoie leur nombre."""
    import base64
    import zlib
    a = design.attributes.itemByName(ATTR_GROUP, 'esquisses')
    if a is None:
        return 0
    entries = json.loads(zlib.decompress(base64.b64decode(a.value)).decode('utf-8'))
    tl = design.timeline
    if tl.markerPosition != tl.count:
        raise RuntimeError("Le curseur de l'historique n'est pas a la fin.")
    root = design.rootComponent
    axes = sheet_axes()
    ez = _v3(axes[2])
    start = tl.count
    n = 0
    for e in entries:
        comp = root
        if e.get('comp'):
            found = design.findEntityByToken(e['comp'])
            comp = adsk.fusion.Component.cast(found[0]) if found else None
            if comp is None:
                for c in design.allComponents:
                    if c.name == e.get('comp_name'):
                        comp = c
                        break
        if comp is None:
            _dbg('esquisses : composant introuvable ' + str(e.get('comp_name')))
            continue
        o, L, W, th = e['o'], e['L'], e['W'], e['th']

        def S(x, y, z=0.0):
            return tuple(o[i] + axes[0][i] * x + axes[1][i] * y + axes[2][i] * z for i in range(3))
        sk = _sheet_sketch(comp, e['title'], th)
        corners = [S(0, 0, th), S(L, 0, th), S(L, W, th), S(0, W, th)]
        for i in range(4):
            _sk_line(sk, corners[i], corners[(i + 1) % 4])
        for g in e.get('grav', []):
            _sk_line(sk, tuple(g[:3]), tuple(g[3:]))
        d_top_w = _dot(_vec(_p3(o)), ez) + th
        for tok in e.get('bodies', []):
            try:
                found = design.findEntityByToken(tok)
                b = adsk.fusion.BRepBody.cast(found[0]) if found else None
                if b is not None:
                    _project_top(sk, b, ez, d_top_w)
            except Exception:
                _dbg('projection (export) EXCEPTION: ' + traceback.format_exc())
        try:
            sk.isComputeDeferred = False
        except Exception:
            pass
        n += 1
    end = tl.count - 1
    if end >= start:
        try:
            grp = tl.timelineGroups.add(start, end)
            grp.name = GROUP_NAME + ' (esquisses)'
            grp.isCollapsed = True
        except Exception:
            _dbg('timeline group (esquisses) EXCEPTION: ' + traceback.format_exc())
    return n


def export_dxf(design, folder):
    """Un DXF par esquisse de panneau "Calpinage CNC - ..." du document."""
    em = design.exportManager
    n = 0
    doc = re.sub(r'[\\/:*?"<>|]+', '_', _app.activeDocument.name if _app.activeDocument else 'calpinage')
    for comp in design.allComponents:
        for sk in comp.sketches:
            if not sk.name.startswith(GROUP_NAME + ' - '):
                continue
            name = re.sub(r'[\\/:*?"<>|]+', '_', sk.name[len(GROUP_NAME) + 3:])
            path = os.path.join(folder, '%s - %s.dxf' % (doc, name))
            try:
                opts = em.createDXFSketchExportOptions(path, sk)
                if em.execute(opts):
                    n += 1
            except Exception:
                try:
                    if sk.saveAsDXF(path):
                        n += 1
                except Exception:
                    _dbg('dxf EXCEPTION: ' + traceback.format_exc())
    return n


# --- Panneau de la palette --------------------------------------------------------

_panel_palette = None
_panel_open = False
_panel_prefs = None
_panel_scope = None        # None = tout le modele, sinon liste d'entites
SCOPE_AUCUN = 'aucun'      # a l'ouverture : rien n'est lu tant que l'utilisateur n'a pas choisi
_panel_parts = []
_panel_warnings = []
_panel_groups_off = []
_panel_result = None


def _send(action, payload):
    try:
        if _panel_palette is not None:
            _panel_palette.sendInfoToHTML(action, json.dumps(payload))
    except Exception:
        _dbg('send EXCEPTION: ' + traceback.format_exc())


def _scope_name():
    if _panel_scope is None:
        return 'tout'
    return 'aucun' if _panel_scope == SCOPE_AUCUN else 'selection'


def _scope_bodies(design):
    if _panel_scope == SCOPE_AUCUN:
        return []
    if _panel_scope is None:
        return collect_bodies(design, None)
    return collect_bodies(design, [e for e in _panel_scope if e is not None and e.isValid])


def _en_place(design):
    """Calpinage en mode Deplacer present : les vraies pieces sont a plat,
    il ne faut ni les relire ni proposer de les reposer a plat."""
    if design is None:
        return False
    st = state(design)
    if st is not None:
        return st.get('mode') != 'copier'
    return any('copie' not in g.name for g in find_groups(design))


def _send_parts():
    design = adsk.fusion.Design.cast(_app.activeProduct)
    if _en_place(design):
        _send('calpinage_parts', {'scope': _scope_name(), 'n_parts': 0,
                                  'groups': [], 'groups_off': [], 'warnings': [], 'en_place': True})
        return
    groups = {}
    for p in _panel_parts:
        g = groups.setdefault(p['group'], {'key': p['group'], 'label': p['group_label'],
                                           'th_mm': p['th_mm'], 'count': 0})
        g['count'] += 1
    _send('calpinage_parts', {
        'scope': _scope_name(),
        'n_parts': len(_panel_parts),
        'groups': sorted(groups.values(), key=lambda g: (-g['count'], g['key'])),
        'groups_off': list(_panel_groups_off),
        'warnings': _panel_warnings[:30],
    })


def _grav_top(prefs):
    """Face gravee au-dessus : forcee quand "Optimiser l'espace" est actif.
    Une piece deja retournee porte sa gravure sur l'autre face ; sans cette
    regle elle etait posee gravure dessous et sa gravure disparaissait."""
    prefs = prefs or {}
    return bool(prefs.get('gravure_dessus', True)) or bool(prefs.get('retourner', False))


def _reanalyse():
    global _panel_parts, _panel_warnings
    clear_cache()
    design = adsk.fusion.Design.cast(_app.activeProduct)
    if design is None:
        _panel_parts, _panel_warnings = [], ['Aucun design actif.']
    elif _en_place(design) or _panel_scope == SCOPE_AUCUN:
        _panel_parts, _panel_warnings = [], []
    else:
        t = time.time()
        bodies = _scope_bodies(design)
        _panel_parts, _panel_warnings = analyse(design, bodies, _grav_top(_panel_prefs))
        _dbg('analyse : %d corps -> %d pieces en %.2fs' % (len(bodies), len(_panel_parts), time.time() - t))
    _send_parts()


def _round_regions(regions):
    return [[[[round(x, 1), round(y, 1)] for (x, y) in ring] for ring in reg] for reg in regions]


def _recompute(rapide=False):
    """rapide : en mode Optimise, apercu immediat par une passe normale
    (imbrique, trous utilises comme en Optimise) ; la recherche longue ne
    tourne qu'au clic sur Calculer."""
    global _panel_result
    design = adsk.fusion.Design.cast(_app.activeProduct)
    if _en_place(design):
        _panel_result = None
        clear_preview()
        _send('calpinage_preview', {'ok': False, 'reason': 'Les pieces sont deja a plat sur les panneaux.'})
        return
    if design is None or not _panel_parts:
        _panel_result = None
        clear_preview()
        _send('calpinage_preview', {'ok': False, 'reason': 'Choisis Tout le modele ou Selection Fusion.'
                                    if _panel_scope == SCOPE_AUCUN else 'Aucune piece a placer.'})
        return
    t = time.time()
    try:
        prefs = _panel_prefs
        rapide = rapide and prefs.get('mode') == 'optimise'
        if rapide:
            prefs = dict(prefs, mode='imbrique_trous')
        res = compute(_panel_parts, prefs, _panel_groups_off)
    except Exception:
        _dbg('compute EXCEPTION: ' + traceback.format_exc())
        _send('calpinage_preview', {'ok': False,
                                    'reason': 'Erreur : ' + traceback.format_exc().strip().splitlines()[-1]})
        return
    _panel_result = res
    draw_preview(design, res)
    n_flip = sum(1 for g in res['groups'] for s in g['sheets'] for pl in s['placements'] if pl.get('flip'))
    if n_flip and not _flip_vu[0]:
        _flip_info[0] = n_flip   # affiche par palette_message, barre fermee
    _flip_vu[0] = n_flip
    payload = {'ok': True, 'L': res['L'], 'W': res['W'], 'margin': res['margin'],
               'time_s': round(time.time() - t, 2), 'groups': [], 'rapide': rapide,
               'time_limit': _panel_prefs.get('time_limit', 30.0)}
    for g in res['groups']:
        payload['groups'].append({
            'label': g['label'], 'th_mm': g['th_mm'], 'stats': g['stats'],
            'unplaced': g['unplaced'],
            'sheets': [{'index': s['index'], 'util': s['util'], 'cuts': list(s.get('cuts') or []),
                        'placements': [{'name': pl['name'], 'rot': pl['rot'], 'flip': bool(pl.get('flip')),
                                        'regions': _round_regions(pl['regions']),
                                        'grav': [[[round(a[0], 1), round(a[1], 1)], [round(b[0], 1), round(b[1], 1)]]
                                                 for a, b in pl.get('grav', [])]}
                                       for pl in s['placements']]}
                       for s in g['sheets']],
        })
    _dbg('calcul : %d groupe(s) en %.2fs' % (len(res['groups']), time.time() - t))
    _send('calpinage_preview', payload)


def _prefs_from(data):
    p = dict(_panel_prefs)
    for k in ('mode', 'corner', 'compact', 'order', 'rotations', 'fill', 'format', 'coupes', 'tri'):
        if k in data and data[k] is not None:
            p[k] = str(data[k])
    if data.get('niveaux') is not None:
        try:
            p['niveaux'] = max(1, min(3, int(data['niveaux'])))
        except Exception:
            pass
    for k in ('margin', 'spacing', 'time_limit'):
        try:
            v = float(data.get(k, p[k]))
            if v >= 0:
                p[k] = v
        except Exception:
            pass
    for k in ('gravure_dessus', 'copier', 'retourner', 'brut', 'usinage', 'esquisse'):
        if k in data:
            p[k] = bool(data[k])
    for k, dv in DEFAULT_PREFS.items():
        if not k.startswith('u_') or data.get(k) is None:
            continue
        try:
            if isinstance(dv, bool):
                p[k] = bool(data[k])
            elif isinstance(dv, (int, float)):
                v = type(dv)(float(data[k]))
                if v >= 0:
                    p[k] = v
            else:
                p[k] = str(data[k])
        except Exception:
            pass
    if 'exemplaires' in data:
        p['exemplaires'] = _n_ex(data)
    return p


# Exemplaires du meuble : propres a chaque projet. Un autre projet repart a 1
# (l'utilisateur, 2026-10-12 : « j'ai ouvert un autre projet et ca m'a charge
# directement 3 exemplaires »). Memorise pour la session, et dans le design
# a la creation du calpinage.
_ex_par_doc = {}


def _doc_key():
    try:
        doc = _app.activeDocument
        try:
            if doc.dataFile is not None:
                return doc.dataFile.id
        except Exception:
            pass
        return doc.name
    except Exception:
        return None


def _ex_du_doc(design):
    k = _doc_key()
    if k in _ex_par_doc:
        return _ex_par_doc[k]
    try:
        a = design.attributes.itemByName(ATTR_GROUP, 'exemplaires') if design else None
        if a is not None:
            return _n_ex({'exemplaires': a.value})
    except Exception:
        pass
    return 1


def _store_ex(design, n):
    try:
        a = design.attributes.itemByName(ATTR_GROUP, 'exemplaires')
        if n > 1:
            design.attributes.add(ATTR_GROUP, 'exemplaires', str(n))
        elif a is not None:
            a.deleteMe()
    except Exception:
        _dbg('store_ex EXCEPTION: ' + traceback.format_exc())


def _n_ex(prefs):
    """Nombre d'exemplaires du meuble (1 a 50)."""
    try:
        return min(50, max(1, int(float((prefs or {}).get('exemplaires', 1) or 1))))
    except Exception:
        return 1


def _send_state():
    design = adsk.fusion.Design.cast(_app.activeProduct)
    st = state(design) if design is not None else None
    if st is None and design is not None and find_groups(design):
        st = {'mode': 'inconnu'}
    _send('calpinage_state', {'state': st})


def _parts_sig(parts):
    return sorted((p['id'], len(p.get('grav', [])), p.get('grav_dessous', 0), p.get('flippable', False),
                   p.get('th_mm'), sum(len(r) for reg in p['regions'] for r in reg),
                   tuple(tuple(round(c, 1) for c in g[0]) for g in p.get('grav', [])[:3]))
                  for p in parts)


def _create(data):
    global _panel_result
    design = adsk.fusion.Design.cast(_app.activeProduct)
    if design is None:
        _send('calpinage_result', {'error': 'Aucun design actif.'})
        return
    if _panel_scope == SCOPE_AUCUN:
        _send('calpinage_result', {'error': "Choisis d'abord Tout le modele ou Selection Fusion."})
        return
    # curseur de l'historique recule (fonctions desactivees a la fin) : le
    # calpinage doit etre cree a la fin, on propose d'y amener le curseur
    # (l'utilisateur, 2026-10-27 : « je clique sur creer et rien ne se passe »)
    if design.designType == adsk.fusion.DesignTypes.ParametricDesignType:
        tl = design.timeline
        if tl.markerPosition != tl.count:
            r = _ui.messageBox(
                "Le curseur de l'historique n'est pas à la fin : %d fonction(s) en fin d'historique "
                "sont désactivées (curseur reculé).\n\nLe calepinage doit être créé à la fin de l'historique.\n"
                "Amener le curseur à la fin et créer le calepinage ?" % (tl.count - tl.markerPosition),
                'Calepinage CNC', adsk.core.MessageBoxButtonTypes.YesNoButtonType,
                adsk.core.MessageBoxIconTypes.QuestionIconType)
            if r != adsk.core.DialogResults.DialogYes:
                _send('calpinage_result', {'error': "Creation annulee : le curseur de l'historique n'est pas a la fin."})
                return
            tl.moveToEnd()
    copier = bool(data.get('copier', _panel_prefs.get('copier', False))) or _n_ex(_panel_prefs) > 1
    _panel_prefs['copier'] = copier
    # Creer le brut, Generer l'usinage et reglages de la section Usinage
    _panel_prefs.update(_prefs_from(dict(data, copier=copier)))
    save_prefs(_panel_prefs)
    if find_groups(design):
        # un calpinage est deja en place : on le retire, puis on relit les
        # pieces revenues en position d'assemblage avant de recalculer
        remove_calpinage(design)
        if find_groups(design):
            _send('calpinage_result', {'error': "Impossible de retirer le calpinage existant de l'historique."})
            return
        _reanalyse()
        _panel_result = None
    else:
        # Le modele a pu changer depuis l'apercu (gravure ajoutee, piece
        # modifiee...) : on relit les pieces ; si elles different, on
        # recalcule, sinon on garde le placement affiche avec des references
        # de corps et de traits fraiches.
        old_sig = _parts_sig(_panel_parts)
        _reanalyse()
        if _parts_sig(_panel_parts) != old_sig:
            _panel_result = None
            _send('calpinage_message', {'text': "Le modele a change depuis l'apercu : calpinage recalcule."})
    if _panel_result is None:
        _recompute()
    if _panel_result is None or not _panel_result['groups']:
        _send('calpinage_result', {'error': 'Rien a placer.'})
        return
    clear_preview()
    t = time.time()
    try:
        res = create_calpinage(design, _panel_parts, _panel_result, copier, bool(_panel_prefs.get('brut')),
                               dict(_panel_prefs) if _panel_prefs.get('usinage') else False,
                               bool(_panel_prefs.get('esquisse')))
    except Exception:
        _dbg('create EXCEPTION: ' + traceback.format_exc())
        res = {'error': traceback.format_exc().strip().splitlines()[-1]}
    res['time_s'] = round(time.time() - t, 1)
    _dbg('creation : %s' % json.dumps(res))
    _send('calpinage_result', res)
    _send_state()
    if not res.get('error') and res.get('n_skipped'):
        # echec de placement : signale en clair, pas seulement dans la palette
        try:
            _ui.messageBox("%d pièce(s) n'ont pas pu être placées sur les panneaux :\n\n%s%s\n\n"
                           "Détail dans calpinage_debug.log." % (
                               res['n_skipped'], '\n'.join(res.get('skipped', [])[:20]),
                               '\n...' if res['n_skipped'] > 20 else ''),
                           'Calepinage CNC', adsk.core.MessageBoxButtonTypes.OKButtonType,
                           adsk.core.MessageBoxIconTypes.WarningIconType)
        except Exception:
            pass
    if not res.get('error'):
        _store_ex(design, _n_ex(_panel_prefs))
        _panel_result = None
        try:
            _app.activeViewport.fit()
        except Exception:
            pass


def _remove():
    global _panel_result
    design = adsk.fusion.Design.cast(_app.activeProduct)
    if design is None:
        return
    try:
        n = remove_calpinage(design)
        if find_groups(design):
            _send('calpinage_result', {'error': "Le groupe Calpinage CNC n'a pas pu etre supprime de l'historique."})
        else:
            _send('calpinage_result', {'error': None, 'removed': n})
    except Exception:
        _send('calpinage_result', {'error': traceback.format_exc().strip().splitlines()[-1]})
    _send_state()
    _reanalyse()
    _panel_result = None
    _recompute(rapide=True)


def _dxf():
    design = adsk.fusion.Design.cast(_app.activeProduct)
    if design is None or not find_groups(design):
        _send('calpinage_message', {'text': "Cree d'abord le calpinage : le DXF reprend ses esquisses de panneau."})
        return
    dlg = _ui.createFolderDialog()
    dlg.title = 'Dossier des fichiers DXF du calpinage'
    if dlg.showDialog() != adsk.core.DialogResults.DialogOK:
        return
    if not _esquisses_existantes(design):
        # calpinage cree sans esquisse de projection : on la cree maintenant
        _send('calpinage_message', {'text': "Creation de l'esquisse de projection..."})
        try:
            make_esquisses(design)
        except Exception:
            _dbg('make_esquisses EXCEPTION: ' + traceback.format_exc())
            _send('calpinage_message', {'text': "Esquisse de projection non creee : refais le calpinage avec \"Esquisse de projection\" coche."})
            return
    n = export_dxf(design, dlg.folder)
    _send('calpinage_message', {'text': '%d fichier(s) DXF enregistre(s) dans %s' % (n, dlg.folder)})


def _doc_title():
    try:
        return _app.activeDocument.name
    except Exception:
        return 'Calpinage'


def _pdf(data=None):
    """PDF du calpinage affiche (apercu) ou, a defaut, du calpinage cree."""
    design = adsk.fusion.Design.cast(_app.activeProduct)
    if design is None:
        return
    # options du PDF (fiche de debit, ordre des coupes) : memorisees
    if _panel_prefs is not None:
        for k in ('pdf_fiche', 'pdf_ordre'):
            if data and k in data:
                _panel_prefs[k] = bool(data[k])
        save_prefs(_panel_prefs)
    if _panel_result is not None and _panel_result.get('groups'):
        doc = pdf_doc(_panel_result, _doc_title())
    elif find_groups(design):
        doc = _stored_pdf_doc(design)
        if doc is None:
            _send('calpinage_message', {'text': 'Ce calpinage a ete cree avant l\'export PDF : choisis les pieces, '
                                                'clique sur Recalculer puis Exporter PDF.'})
            return
    else:
        _send('calpinage_message', {'text': "Choisis les pieces et calcule d'abord le calpinage."})
        return
    pp = _panel_prefs or {}
    doc = dict(doc, noms=True, fiche=bool(pp.get('pdf_fiche', True)), ordre=bool(pp.get('pdf_ordre', True)))
    dlg = _ui.createFileDialog()
    dlg.title = 'Enregistrer le PDF du calpinage'
    dlg.filter = 'PDF (*.pdf)'
    dlg.initialFilename = re.sub(r'[\\/:*?"<>|]+', '_', '%s - calpinage.pdf' % _doc_title())
    if dlg.showSave() != adsk.core.DialogResults.DialogOK:
        return
    path = dlg.filename
    if not path.lower().endswith('.pdf'):
        path += '.pdf'
    try:
        n = _load_pdf().write_pdf(path, doc)
    except PermissionError:
        _send('calpinage_message', {'text': 'Impossible d\'ecrire %s : le fichier est peut-etre ouvert.' % path})
        return
    except Exception:
        _dbg('pdf EXCEPTION: ' + traceback.format_exc())
        _send('calpinage_message', {'text': 'Erreur PDF : ' + traceback.format_exc().strip().splitlines()[-1]})
        return
    _send('calpinage_message', {'text': 'PDF enregistre (%d page(s)) : %s' % (n, path)})
    try:
        os.startfile(path)
    except Exception:
        pass


def _open():
    global _panel_open, _panel_prefs, _panel_scope, _panel_groups_off, _y_up, _panel_result
    _panel_open = True
    _y_up = None
    _panel_prefs = load_prefs()
    _panel_prefs['exemplaires'] = _ex_du_doc(adsk.fusion.Design.cast(_app.activeProduct))
    _flip_vu[0] = 0
    # rien n'est analyse a l'ouverture : l'utilisateur choisit Tout le
    # modele ou Selection Fusion (evite un chargement inutile)
    _panel_scope = SCOPE_AUCUN
    _panel_groups_off = []
    _panel_result = None
    # reset : la palette efface tout ce qui reste d'un calpinage precedent
    # (apercu, resultat, messages), y compris d'un autre projet
    _send('calpinage_init', dict(_panel_prefs, reset=True))
    _send_state()
    _reanalyse()
    _recompute(rapide=True)


def _close():
    global _panel_open, _panel_result, _panel_parts
    _panel_open = False
    _panel_result = None
    _panel_parts = []
    clear_preview()


# Actions qui peuvent durer (analyse, placement, creation) : barre de
# chargement au milieu de l'ecran si elles depassent 1 s (cnc_progress).
def _nest_key():
    return json.dumps([{k: v for k, v in (_panel_prefs or {}).items() if k not in ('brut', 'usinage', 'esquisse')},
                       list(_panel_groups_off or [])], sort_keys=True, default=str)


_ACTIONS_LENTES = ('calpinage_open', 'calpinage_params', 'calpinage_scope',
                   'calpinage_create', 'calpinage_remove', 'calpinage_refresh')


# Pieces retournees dans l'apercu : fenetre d'info quand il y en a de nouveau
# (l'utilisateur, 2026-10-12), une fois la barre de chargement fermee.
_flip_vu = [0]      # pieces retournees dans le dernier apercu
_flip_info = [0]    # a annoncer


def _show_flip_info():
    n = _flip_info[0]
    _flip_info[0] = 0
    if not n:
        return
    try:
        _ui.messageBox(
            "%d pi\u00e8ce%s retourn\u00e9e%s volontairement pour gagner de la place sur "
            "les panneaux (affich\u00e9e%s en rose dans l'aper\u00e7u).\n\n"
            "Leur gravure passe sur l'autre face, sur le panneau et dans le mod\u00e8le.\n\n"
            "Tu peux le changer si besoin : bouton \u00ab Ne plus retourner les pi\u00e8ces \u00bb "
            "dans Calpinage CNC." % ((n,) + (('s', 's', 's') if n > 1 else ('', '', ''))),
            'Calpinage CNC', adsk.core.MessageBoxButtonTypes.OKButtonType,
            adsk.core.MessageBoxIconTypes.InformationIconType)
    except Exception:
        _dbg('flip info EXCEPTION: ' + traceback.format_exc())


def palette_message(palette, action, data):
    """Point d'entree des messages 'calpinage_*' de palette.html (relayes
    par ToolkitCNC.HTMLEventHandler)."""
    if action in _ACTIONS_LENTES:
        with cnc_progress.Barre('Calpinage CNC', 'Calcul en cours...'):
            r = _palette_message(palette, action, data)
        _show_flip_info()
        return r
    return _palette_message(palette, action, data)


_ferme_avec_palette = [False]


def _palette_visible():
    try:
        return bool(_panel_palette is not None and _panel_palette.isVisible)
    except Exception:
        return False


def _palette_message(palette, action, data):
    global _panel_palette, _panel_prefs, _panel_scope, _panel_groups_off, _panel_open
    if palette is not None:
        _panel_palette = palette
    if palette is not None:
        _ferme_avec_palette[0] = False
    if palette is not None and action not in ('calpinage_open', 'calpinage_close'):
        # le panneau est affiche (meme si le module a ete recharge depuis son
        # ouverture) : le changement de projet doit le remettre a zero
        _panel_open = True
        if _panel_prefs is None:
            _panel_prefs = load_prefs()
            _panel_prefs['exemplaires'] = _ex_du_doc(adsk.fusion.Design.cast(_app.activeProduct))
    try:
        if action == 'calpinage_open':
            _open()
        elif action == 'calpinage_close':
            # palette fermee (croix) alors que le panneau etait affiche : a sa
            # reouverture la page montre encore ce panneau, a remettre a zero
            # si le projet change entre-temps
            _ferme_avec_palette[0] = bool(_panel_open and palette is None and not _palette_visible())
            _close()
        elif action == 'calpinage_usinage':
            # Creer le brut, Generer l'usinage et section Usinage : memorises
            # sans recalculer le placement
            _panel_prefs = _prefs_from(data)
            save_prefs(_panel_prefs)
        elif action == 'calpinage_params':
            old_grav = _grav_top(_panel_prefs) if _panel_prefs else None
            old_key = _nest_key()
            _panel_prefs = _prefs_from(data)
            _ex_par_doc[_doc_key()] = _n_ex(_panel_prefs)
            if 'groups_off' in data:
                _panel_groups_off = list(data.get('groups_off') or [])
            save_prefs(_panel_prefs)
            if _grav_top(_panel_prefs) != old_grav:
                _reanalyse()
            # Creer le brut / Generer l'usinage ne changent pas le placement
            if data.get('compute') or _nest_key() != old_key:
                _recompute(rapide=not data.get('compute'))
        elif action == 'calpinage_scope':
            if data.get('selection'):
                ents = []
                sels = _ui.activeSelections
                for i in range(sels.count):
                    ents.append(sels.item(i).entity)
                _panel_scope = ents if ents else SCOPE_AUCUN
                if not ents:
                    _send('calpinage_message', {'text': 'Rien de selectionne dans Fusion : selectionne des corps ou des composants, puis reclique sur Selection Fusion.'})
            else:
                _panel_scope = None
            _reanalyse()
            _recompute(rapide=True)
        elif action == 'calpinage_fraises_list':
            _send('calpinage_fraises', {'tools': fraises_bibliotheque()})
        elif action == 'calpinage_create':
            _create(data)
        elif action == 'calpinage_remove':
            _remove()
        elif action == 'calpinage_dxf':
            _dxf()
        elif action == 'calpinage_pdf':
            _pdf(data)
        elif action == 'calpinage_refresh':
            _reanalyse()
            _recompute()
        elif action == 'calpinage_format_add':
            name = str(data.get('name') or '').strip()
            L, W = float(data.get('L', 0)), float(data.get('W', 0))
            if L < W:
                L, W = W, L
            if W <= 0:
                _send('calpinage_message', {'text': 'Format invalide.'})
                return
            if not name:
                name = '%g x %g' % (L, W)
            fmts = [f for f in _panel_prefs.get('formats', []) if f.get('name') != name]
            fmts.append({'name': name, 'L': L, 'W': W})
            _panel_prefs['formats'] = fmts
            _panel_prefs['format'] = name
            save_prefs(_panel_prefs)
            _send('calpinage_init', _panel_prefs)
            _recompute(rapide=True)
        elif action == 'calpinage_format_del':
            name = data.get('name')
            fmts = [f for f in _panel_prefs.get('formats', []) if f.get('name') != name]
            if fmts:
                _panel_prefs['formats'] = fmts
                if _panel_prefs.get('format') == name:
                    _panel_prefs['format'] = fmts[0]['name']
                save_prefs(_panel_prefs)
            _send('calpinage_init', _panel_prefs)
            _recompute(rapide=True)
    except Exception:
        _dbg('palette_message %s EXCEPTION: %s' % (action, traceback.format_exc()))
        _send('calpinage_message', {'text': 'Erreur : ' + traceback.format_exc().strip().splitlines()[-1]})


class _DocActivatedHandler(adsk.core.DocumentEventHandler):
    """Changement de projet avec le panneau ouvert : l'ancien apercu est
    efface et le calpinage repart des pieces du document actif."""
    def notify(self, args):
        try:
            clear_preview()
            if not _panel_open:
                if _ferme_avec_palette[0] and _palette_visible():
                    # retour au menu : Calpinage sera rouvert a neuf
                    _ferme_avec_palette[0] = False
                    _send('calpinage_force_reset', {})
                return
            _open()
            _show_flip_info()
        except Exception:
            _dbg('documentActivated EXCEPTION: ' + traceback.format_exc())


def run(context):
    global _app, _ui
    try:
        _app = adsk.core.Application.get()
        _ui = _app.userInterface
        h = _DocActivatedHandler()
        _app.documentActivated.add(h)
        _handlers.append(h)
        clear_preview()
    except Exception:
        if _ui:
            _ui.messageBox('Calpinage CNC - Erreur au demarrage :\n' + traceback.format_exc())


def stop(context):
    try:
        _close()
        for h in _handlers:
            try:
                _app.documentActivated.remove(h)
            except Exception:
                pass
        _handlers.clear()
    except Exception:
        pass
