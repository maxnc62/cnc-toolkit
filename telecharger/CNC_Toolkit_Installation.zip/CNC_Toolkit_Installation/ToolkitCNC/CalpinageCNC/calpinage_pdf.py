# ---------------------------------------------------------------------------
# Calpinage CNC : export PDF du calpinage (une page A3 paysage par panneau).
#
# Pour un partenaire qui ne connait pas le modele : panneau a l'echelle
# (1:N indique + barre d'echelle), cotes du panneau, pieces en gris (matiere),
# vides (trous traversants) en blanc, fonds d'usinages non debouchants en gris
# fonce avec leur profondeur, gravures en bleu (sans nom de piece).
#
# PDF ecrit a la main (aucune dependance) : utilisable dans Fusion et testable
# hors Fusion. Coordonnees d'entree en mm, repere du panneau (origine en bas a
# gauche, x le long de la longueur L, y le long de la largeur W).
# ---------------------------------------------------------------------------

import datetime
import math
import re
import zlib

try:
    import cnc_i18n as _i18n   # langue FR/EN de CNC Toolkit (textes du PDF)
except Exception:
    _i18n = None

MM = 72.0 / 25.4                       # points par mm
PAGE_W, PAGE_H = 420 * MM, 297 * MM    # A3 paysage
MARGIN = 12 * MM
TITLE_H = 7 * MM                       # ligne d'infos en bas de page (cartouche -> page de garde, 2026-11-19)
SCALES = (1, 2, 5, 10, 15, 20, 25, 50, 100, 200)

GRIS_MATIERE = (0.90, 0.90, 0.90)   # eclairci (demande du 2026-11-19)
GRIS_POCHE = (0.70, 0.70, 0.70)
BLEU_GRAVURE = (0.0, 0.35, 0.85)
VERT_COUPE = (0.0, 0.62, 0.32)       # coupes prioritaires (scie a format)


def _txt(s):
    """Chaine PDF (WinAnsi) : accents conserves, caracteres speciaux echappes."""
    b = str(s).encode('cp1252', 'replace')
    return b.replace(b'\\', b'\\\\').replace(b'(', b'\\(').replace(b')', b'\\)')


def _fmt(v):
    s = ('%.2f' % v).rstrip('0').rstrip('.')
    return s if s not in ('', '-0') else '0'


def _mm(v):
    """Cote en mm, au dixieme (sans zeros inutiles)."""
    s = ('%.1f' % v).rstrip('0').rstrip('.')
    return s if s not in ('', '-0') else '0'


def _ring_area(ring):
    a = 0.0
    for i in range(len(ring)):
        x1, y1 = ring[i]
        x2, y2 = ring[(i + 1) % len(ring)]
        a += x1 * y2 - x2 * y1
    return a / 2.0


def _inside(rings, x, y):
    """Point dans la region (regle pair-impair : les trous sont exclus)."""
    c = False
    for ring in rings:
        n = len(ring)
        for i in range(n):
            x1, y1 = ring[i]
            x2, y2 = ring[(i + 1) % n]
            if (y1 > y) != (y2 > y) and x < (x2 - x1) * (y - y1) / ((y2 - y1) or 1e-12) + x1:
                c = not c
    return c


def _label_point(rings):
    """Point interieur a la matiere pour poser le nom de la piece."""
    xs = [p[0] for p in rings[0]]
    ys = [p[1] for p in rings[0]]
    x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    if _inside(rings, cx, cy):
        return cx, cy
    best, bd = None, -1.0
    for i in range(1, 12):
        for j in range(1, 12):
            x, y = x0 + (x1 - x0) * i / 12.0, y0 + (y1 - y0) * j / 12.0
            if _inside(rings, x, y):
                d = -((x - cx) ** 2 + (y - cy) ** 2)
                if best is None or d > bd:
                    best, bd = (x, y), d
    return best or (cx, cy)


class _Page(object):
    def __init__(self):
        self.ops = []

    def add(self, s):
        self.ops.append(s)

    def color(self, rgb, stroke=False):
        self.add('%s %s %s %s' % (_fmt(rgb[0]), _fmt(rgb[1]), _fmt(rgb[2]), 'RG' if stroke else 'rg'))

    def width(self, w):
        self.add('%s w' % _fmt(w))

    def dash(self, on=None, off=None):
        self.add('[%s %s] 0 d' % (_fmt(on), _fmt(off)) if on else '[] 0 d')

    def line(self, x1, y1, x2, y2):
        self.add('%s %s m %s %s l S' % (_fmt(x1), _fmt(y1), _fmt(x2), _fmt(y2)))

    def rect(self, x, y, w, h, op='S'):
        self.add('%s %s %s %s re %s' % (_fmt(x), _fmt(y), _fmt(w), _fmt(h), op))

    def path(self, rings, op):
        for ring in rings:
            if len(ring) < 2:
                continue
            self.add('%s %s m' % (_fmt(ring[0][0]), _fmt(ring[0][1])))
            self.add(' '.join('%s %s l' % (_fmt(x), _fmt(y)) for x, y in ring[1:]))
            self.add('h')
        self.add(op)

    def text(self, x, y, s, size=9, bold=False, angle=0.0, align='left'):
        if _i18n is not None:
            s = _i18n.t(s)
        w = _text_width(s, size, bold)
        dx = {'left': 0.0, 'center': -w / 2.0, 'right': -w}[align]
        a = math.radians(angle)
        c, sn = math.cos(a), math.sin(a)
        tx, ty = x + c * dx, y + sn * dx
        self.add('BT /%s %s Tf %s %s %s %s %s %s Tm (' % ('F2' if bold else 'F1', _fmt(size), _fmt(c), _fmt(sn),
                                                         _fmt(-sn), _fmt(c), _fmt(tx), _fmt(ty))
                 + _txt(s).decode('latin-1') + ') Tj ET')

    def data(self):
        return '\n'.join(self.ops).encode('latin-1')


def _text_width(s, size, bold=False):
    # largeur approximative Helvetica (moyenne) : suffit pour centrer
    return len(str(s)) * size * (0.56 if bold else 0.52)


def _arrow(pg, x, y, dx, dy, size):
    n = math.hypot(dx, dy) or 1.0
    ux, uy = dx / n, dy / n
    px, py = -uy, ux
    pts = [(x, y), (x - ux * size + px * size * 0.35, y - uy * size + py * size * 0.35),
           (x - ux * size - px * size * 0.35, y - uy * size - py * size * 0.35)]
    pg.path([pts], 'f')


def _cote(pg, x1, y1, x2, y2, label, off_dir, off):
    """Cote entre deux points, decalee de off (en points) dans off_dir."""
    ox, oy = off_dir[0] * off, off_dir[1] * off
    a1, b1, a2, b2 = x1 + ox, y1 + oy, x2 + ox, y2 + oy
    pg.color((0, 0, 0), True)
    pg.width(0.4)
    pg.line(x1 + off_dir[0] * 2, y1 + off_dir[1] * 2, a1 + off_dir[0] * 3, b1 + off_dir[1] * 3)
    pg.line(x2 + off_dir[0] * 2, y2 + off_dir[1] * 2, a2 + off_dir[0] * 3, b2 + off_dir[1] * 3)
    pg.line(a1, b1, a2, b2)
    pg.color((0, 0, 0))
    _arrow(pg, a1, b1, a1 - a2, b1 - b2, 5)
    _arrow(pg, a2, b2, a2 - a1, b2 - b1, 5)
    ang = math.degrees(math.atan2(b2 - b1, a2 - a1))
    mx, my = (a1 + a2) / 2 + off_dir[0] * 3, (b1 + b2) / 2 + off_dir[1] * 3
    if off_dir[0] < 0:
        mx -= 2
    pg.text(mx, my, label, 9, True, ang, 'center')


def _cote_bande(pg, P, L, a, b, horiz):
    """Cote d'une bande (a -> b, mm) : a droite du panneau si horiz, sinon
    dessous ; texte horizontal, hors du trait de cote."""
    off = 6 * MM
    size = 11
    pg.color((0, 0, 0), True)
    pg.color((0, 0, 0))
    pg.width(0.4)
    if horiz:
        p1, p2 = P(L, a), P(L, b)
        x = p1[0] + off
        pg.line(p1[0] + 1, p1[1], x + 2, p1[1])
        pg.line(p2[0] + 1, p2[1], x + 2, p2[1])
        pg.line(x, p1[1], x, p2[1])
        ar = min(4.0, abs(p2[1] - p1[1]) / 3.0)
        _arrow(pg, x, p1[1], 0, p1[1] - p2[1], ar)
        _arrow(pg, x, p2[1], 0, p2[1] - p1[1], ar)
        pg.text(x + 2.5, (p1[1] + p2[1]) / 2.0 - size / 3.0, _mm(b - a), size, True)
    else:
        p1, p2 = P(a, 0), P(b, 0)
        y = p1[1] - off
        pg.line(p1[0], p1[1] - 1, p1[0], y - 2)
        pg.line(p2[0], p2[1] - 1, p2[0], y - 2)
        pg.line(p1[0], y, p2[0], y)
        ar = min(4.0, abs(p2[0] - p1[0]) / 3.0)
        _arrow(pg, p1[0], y, p1[0] - p2[0], 0, ar)
        _arrow(pg, p2[0], y, p2[0] - p1[0], 0, ar)
        pg.text((p1[0] + p2[0]) / 2.0, y - 2.5 - size * 0.72, _mm(b - a), size, True, 0, 'center')


def _scale_for(L, W, aw, ah):
    for s in SCALES:
        if L / s * MM <= aw and W / s * MM <= ah:
            return s
    return max(L * MM / aw, W * MM / ah)


# --- Fiche de debit (sous le panneau) ---------------------------------------------

FICHE_ROW = 4.6 * MM
FICHE_HEAD = 11 * MM            # titre + ligne d'en-tete
FICHE_COLS = ((u'Pièce', 92), (u'Qté', 14), ('Longueur (mm)', 26), ('Largeur (mm)', 26), (u'Épaisseur (mm)', 26))
FICHE_BLOCK_W = sum(w for _n, w in FICHE_COLS) * MM
FICHE_MAX = 24                  # lignes par colonne de la fiche


def _bbox_pl(pl):
    pts = [q for reg in (pl.get('regions') or []) if reg for q in reg[0]]
    if not pts:
        return None
    xs = [q[0] for q in pts]
    ys = [q[1] for q in pts]
    return min(xs), min(ys), max(xs), max(ys)


def _base_name(pl):
    # sans « - ex N » ni les numeros de copie Fusion « (1) », « (10) (4) »...
    # (demande du 2026-11-19 : retirer les chiffres entre parentheses partout)
    n = re.sub(r' - ex \d+$', '', pl.get('label') or pl.get('name', ''))
    n = re.sub(r'\s*\(\d+\)', '', n).strip()
    return n or (pl.get('name') or '')


_REP = {}      # nom de piece -> lettre repere, pour la carte en cours seulement


def _lettre(k):
    out = ''
    k += 1
    while k:
        k, r = divmod(k - 1, 26)
        out = chr(65 + r) + out
    return out


def _set_reperes(doc):
    """Lettre repere par piece (demande du 2026-11-19, 21h09 : retrouver les
    pieces de la liste sur la vignette)."""
    _REP.clear()
    for g in doc['groups']:
        for s in g['sheets']:
            for pl in s['placements']:
                n = _base_name(pl)
                if n not in _REP:
                    _REP[n] = _lettre(len(_REP))


def _rep(pl):
    return _REP.get(_base_name(pl), '')


def _fiche_rows(grp, sheet):
    """Pieces du panneau regroupees : [(nom, qte, longueur, largeur, epaisseur)]."""
    rows = {}
    for pl in sheet['placements']:
        bb = _bbox_pl(pl)
        if bb is None:
            continue
        dw, dh = bb[2] - bb[0], bb[3] - bb[1]
        key = (_base_name(pl), _mm(max(dw, dh)), _mm(min(dw, dh)))
        rows[key] = rows.get(key, 0) + 1
    out = [(n, q, a, b, _mm(float(grp.get('th_mm') or 0))) for (n, a, b), q in rows.items()]
    out.sort(key=lambda r: (-float(r[2]), -float(r[3]), r[0]))
    return out


def _fiche_layout(rows):
    """(colonnes, lignes par colonne, hauteur en points) de la fiche."""
    if not rows:
        return 0, 0, 0.0
    n_blk = 1 if len(rows) <= 12 else 2
    per = min(FICHE_MAX, int(math.ceil(len(rows) / float(n_blk))))
    return n_blk, per, FICHE_HEAD + per * FICHE_ROW + 2 * MM


def _draw_fiche(pg, rows, x, y_top, n_blk, per, title):
    pg.color((0, 0, 0))
    pg.text(x, y_top - 4 * MM, title, 9, True)
    shown = rows[:n_blk * per]
    for b in range(n_blk):
        bx = x + b * (FICHE_BLOCK_W + 8 * MM)
        part = shown[b * per:(b + 1) * per]
        if not part:
            break
        yh = y_top - FICHE_HEAD
        pg.color((0.9, 0.9, 0.9))
        pg.rect(bx, yh, FICHE_BLOCK_W, FICHE_ROW, 'f')
        cx = bx
        pg.color((0, 0, 0))
        for name, w in FICHE_COLS:
            pg.text(cx + 1.5 * MM, yh + 1.4 * MM, name, 7, True)
            cx += w * MM
        for i, r in enumerate(part):
            yr = yh - (i + 1) * FICHE_ROW
            if i % 2:
                pg.color((0.965, 0.965, 0.965))
                pg.rect(bx, yr, FICHE_BLOCK_W, FICHE_ROW, 'f')
            pg.color((0, 0, 0))
            cx = bx
            for j, (name, w) in enumerate(FICHE_COLS):
                v = str(r[j])
                if j == 0:
                    n_max = int(w * MM / (7 * 0.52)) - 1
                    if len(v) > n_max:
                        v = v[:n_max - 1] + '.'
                    pg.text(cx + 1.5 * MM, yr + 1.4 * MM, v, 7)
                else:
                    pg.text(cx + w * MM - 2 * MM, yr + 1.4 * MM, v, 7, j == 1, 0, 'right')
                cx += w * MM
        pg.color((0, 0, 0), True)
        pg.width(0.4)
        pg.rect(bx, yh - len(part) * FICHE_ROW, FICHE_BLOCK_W, (len(part) + 1) * FICHE_ROW)
    if len(rows) > len(shown):
        pg.text(x, y_top - FICHE_HEAD - per * FICHE_ROW - 4 * MM,
                '... %d ligne(s) de plus' % (len(rows) - len(shown)), 7)


def _sheet_page(doc, grp, sheet, n_sheets):
    pg = _Page()
    show_names = bool(doc.get('noms', False))   # noms des pieces (demande de l'utilisateur, 2026-11-19)
    L, W = float(doc['L']), float(doc['W'])
    f_rows = _fiche_rows(grp, sheet) if doc.get('fiche') else []
    n_blk, per, tab_h = _fiche_layout(f_rows)
    tab_sp = (tab_h + 12 * MM) if tab_h else 0.0   # fiche + place des cotes sous le panneau
    # panneau le plus grand possible (demande du 2026-11-19 : trop de vide,
    # ecritures plus lisibles) : echelle libre au lieu des echelles normalisees,
    # en gardant la place des cotes (gauche, haut, droite = bandes, bas)
    aw = PAGE_W - 2 * MARGIN - 14 * MM - 24 * MM
    ah = PAGE_H - 2 * MARGIN - TITLE_H - 12 * MM - 12 * MM - (tab_sp if tab_sp else 10 * MM)
    scale = max(L * MM / aw, W * MM / ah)
    scale = math.ceil(scale * 10.0 - 1e-9) / 10.0
    k = MM / scale
    ox = MARGIN + 14 * MM + (aw - L * k) / 2
    oy = MARGIN + TITLE_H + 4 * MM + (tab_sp if tab_sp else 10 * MM) + (ah - W * k) / 2
    if tab_h:
        _draw_fiche(pg, f_rows, MARGIN, MARGIN + TITLE_H + 4 * MM + tab_h, n_blk, per,
                    u'Fiche de débit  -  panneau %d' % sheet['index'])

    def P(x, y):
        return (ox + x * k, oy + y * k)

    def R(ring):
        return [P(x, y) for x, y in ring]

    # brut du panneau
    pg.color((1, 1, 1))
    pg.color((0, 0, 0), True)
    pg.width(1.0)
    pg.rect(ox, oy, L * k, W * k, 'B')
    m = float(doc.get('margin') or 0)
    if m > 0:
        pg.color((0.6, 0.6, 0.6), True)
        pg.width(0.3)
        pg.dash(3, 3)
        pg.rect(ox + m * k, oy + m * k, (L - 2 * m) * k, (W - 2 * m) * k)
        pg.dash()

    labels = []
    has_pocket = has_grav = False
    for pl in sheet['placements']:
        regs = pl.get('regions') or []
        depths = pl.get('depths') or [0.0] * len(regs)
        order = sorted(range(len(regs)), key=lambda i: depths[i] if i < len(depths) else 0.0)
        main = None
        for i in order:
            reg = regs[i]
            if not reg:
                continue
            d = depths[i] if i < len(depths) else 0.0
            poche = d > 0.05
            has_pocket = has_pocket or poche
            pg.color(GRIS_POCHE if poche else GRIS_MATIERE)
            pg.color((0, 0, 0), True)
            pg.width(0.5 if poche else 0.8)
            pg.path([R(r) for r in reg], 'B*')
            if poche:
                lx, ly = _label_point(reg)
                labels.append((P(lx, ly), 'prof. %s mm' % _fmt(d), 5.5, False, 0.0))
            elif main is None or abs(_ring_area(reg[0])) > abs(_ring_area(main[0])):
                main = reg
        g = pl.get('grav') or []
        if g:
            has_grav = True
            pg.color(BLEU_GRAVURE, True)
            pg.width(0.6)
            for a, b in g:
                pa, pb = P(a[0], a[1]), P(b[0], b[1])
                pg.line(pa[0], pa[1], pb[0], pb[1])
        # cotes de la piece (boite englobante, mm) : dimension horizontale en
        # haut, dimension verticale a droite (texte dans le sens de l'arete),
        # nom du composant / corps au milieu
        outer = [r[0] for r in regs if r]
        if outer:
            xs = [q[0] for r in outer for q in r]
            ys = [q[1] for r in outer for q in r]
            x0, y0, x1, y1 = min(xs), min(ys), max(xs), max(ys)
            wpt, hpt = (x1 - x0) * k, (y1 - y0) * k
            pad = 1.6
            t_w, t_h = _mm(x1 - x0), _mm(y1 - y0)
            ds = min(15.0, wpt * 0.3, hpt * 0.3)
            ds = min(ds, (wpt - 2 * pad) / (len(t_w) * 0.56), (hpt - 2 * pad) / (len(t_h) * 0.56))
            room = 0.0
            if ds >= 3.0:
                pt = P((x0 + x1) / 2.0, y1)
                labels.append(((pt[0], pt[1] - pad - ds / 2.0), t_w, ds, True, 0.0))
                pr = P(x1, (y0 + y1) / 2.0)
                labels.append(((pr[0] - pad - ds / 2.0, pr[1]), t_h, ds, True, 90.0))
                room = ds + 2 * pad
            if show_names:
                if main is not None:
                    lx, ly = _label_point(main)
                else:
                    lx, ly = (x0 + x1) / 2.0, (y0 + y1) / 2.0
                name = _base_name(pl)
                # place libre : sous la cote du haut, a gauche de la cote de droite
                bw, bh = wpt - room - 2 * pad, hpt - room - 2 * pad
                cx_, cy_ = P(lx, ly)
                if main is None or room:
                    cx_ = P(x0, y0)[0] + (wpt - room) / 2.0
                    cy_ = P(x0, y0)[1] + (hpt - room) / 2.0
                # piece haute et etroite : nom ecrit dans sa longueur
                ang = 90.0 if bh > bw * 1.3 else 0.0
                along, cross = (bh, bw) if ang else (bw, bh)
                size = min(10.0, cross * 0.75, along * 0.95 / (max(1, len(name)) * 0.54))
                if size < 4.0 and along > 0 and cross >= 4.5:
                    # nom tronque plutot qu'illisible
                    size = min(4.5, cross * 0.85)
                    n_max = int(along * 0.95 / (size * 0.54))
                    if n_max >= 4 and len(name) > n_max:
                        name = name[:n_max - 1] + '.'
                if size >= 3.5:
                    labels.append(((cx_, cy_), name, size, False, ang))
    # coupes prioritaires (mode Rectangulaire) : niveau 1 en trait epais
    # numerote dans l'ordre de coupe, recoupes (niveau 2) en trait fin
    cuts = sheet.get('cuts') or []
    has_cut = False
    for lev in (2, 1):
        for c in cuts:
            if c.get('level') != lev:
                continue
            (x1, y1), (x2, y2) = c['seg']
            pa, pb = P(x1, y1), P(x2, y2)
            pg.color(VERT_COUPE, True)
            pg.width(1.8 if lev == 1 else 0.5)
            pg.dash(6, 3) if lev == 1 else pg.dash(2, 2)
            pg.line(pa[0], pa[1], pb[0], pb[1])
            pg.dash()
            has_cut = True
    n1 = 0
    pg.color(VERT_COUPE)
    for c in cuts:
        if c.get('level') != 1:
            continue
        n1 += 1
        (x1, y1), (x2, y2) = c['seg']
        if abs(y1 - y2) < 1e-6:     # horizontale : numero a gauche du panneau (cotes des bandes a droite)
            q = P(min(x1, x2), y1)
            pg.text(q[0] - 2 * MM, q[1] - 1.2 * MM, str(n1), 9, True, 0, 'right')
        else:                       # verticale : numero au-dessus
            q = P(x1, max(y1, y2))
            pg.text(q[0], q[1] + 2 * MM, str(n1), 9, True, 0, 'center')
    # largeur de chaque bande, a regler sur la scie : a droite du panneau
    # (coupes horizontales) ou sous le panneau (coupes verticales)
    for bd in sheet.get('bandes') or []:
        a, b = float(bd['a']), float(bd['b'])
        if b - a < 1e-6:
            continue
        _cote_bande(pg, P, L, a, b, bd.get('axis') == 'y')
    if sheet.get('bandes'):
        pg.color(VERT_COUPE)
        if sheet['bandes'][0].get('axis') == 'y':
            q = P(L, W)
            pg.text(q[0] + 6 * MM, q[1] + 3 * MM, 'Bandes (mm)', 8, True, 0, 'left')
        else:
            q = P(0, 0)
            pg.text(q[0] - 2 * MM, q[1] - 6 * MM - 2.5 - 9 * 0.72, 'Bandes (mm)', 8, True, 0, 'right')
    pg.color((0, 0, 0))
    for (x, y), s, size, bold, ang in labels:
        a = math.radians(ang)
        # centrage vertical du texte (decalage perpendiculaire a la ligne)
        pg.text(x + math.sin(a) * size / 3.0, y - math.cos(a) * size / 3.0, s, size, bold, ang, 'center')

    # cotes du panneau
    _cote(pg, ox, oy + W * k, ox + L * k, oy + W * k, '%s mm' % _fmt(L), (0, 1), 8 * MM)
    _cote(pg, ox, oy, ox, oy + W * k, '%s mm' % _fmt(W), (-1, 0), 8 * MM)

    # une seule ligne d'infos en bas de page (le cartouche, la legende et
    # l'echelle sont sur la page de garde, demande du 2026-11-19)
    sc = ('1:%s' % _fmt(scale)) if float(scale).is_integer() else ('1:%.1f' % scale)
    pg.color((0.5, 0.5, 0.5), True)
    pg.width(0.4)
    pg.line(MARGIN, MARGIN + 5 * MM, PAGE_W - MARGIN, MARGIN + 5 * MM)
    pg.color((0, 0, 0))
    pg.text(MARGIN, MARGIN + 1.2 * MM, doc.get('title', 'Calpinage'), 9, True)
    tx0 = MARGIN + _text_width(doc.get('title', 'Calpinage'), 9, True) + 6 * MM
    pg.text(tx0, MARGIN + 1.2 * MM,
            u'Panneau %d sur %d  -  %s  -  %s x %s mm  -  %d pièce(s)  -  échelle %s (A3 à 100 %%)  -  %s'
            % (sheet['index'], n_sheets, grp['label'], _fmt(L), _fmt(W), len(sheet['placements']), sc,
               doc.get('date', '')), 9)
    return pg


# --- Ordre des coupes (scie a format) -----------------------------------------------

ROUGE_COUPE = (0.85, 0.1, 0.1)
ORANGE_ZONE = (1.0, 0.82, 0.6)
ORANGE_PIECE = (1.0, 0.55, 0.1)
C_CONTOUR = (0.42, 0.42, 0.42)
ORDRE_COLS = 4                      # 4 cartes par ligne, vignettes plus grandes (2026-11-20 16h37)
# couleurs des vignettes (2026-11-19 : retour aux gris, l'utilisateur n'aime pas le bleu)
C_RESTE = (0.42, 0.42, 0.42)        # pas encore coupe (gris fonce)
C_BANDE = (1.0, 1.0, 1.0)           # fond de la bande en cours
C_BANDE_P = (0.72, 0.72, 0.72)      # pieces de la bande en cours (gris moyen)
C_BANDE_L = (0.25, 0.25, 0.25)      # contour de la bande en cours
C_FAIT = (1.0, 1.0, 1.0)            # deja coupe : blanc (2026-11-19 : « plus blanc »)
C_FAIT_L = (0.72, 0.72, 0.72)
C_CADRE = (0.0, 0.62, 0.38)         # cadre de la bande en cours
C_DELIG = (0.84, 0.74, 0.95)        # coupee a longueur, reste a deligner (violet, 2026-11-19)
C_DELIG_L = (0.48, 0.28, 0.70)


def _step_text(st, n_prim):
    d = _mm(st['dim'])
    kind = st['kind']
    if kind == 'prim':
        return 'Coupe prioritaire %d : bande de %s mm' % (n_prim, d)
    # (l'utilisateur, 2026-11-19 : « au lieu de dire tronconner, etc., dis juste couper »)
    # (la bande est deja dans le titre de la section)
    return u'Couper à %s mm' % d


def _hatch(pg, x, y, w, h, step=3.2, lw=0.45, col=None, edge=0.35, sens=1, edge_col=None):
    """Hachures a 45 deg dans le rectangle (fond blanc, peu d'encre).
    Orange vers la droite = piece qu'on coupe ; gris vers la gauche = pas encore coupe."""
    col = col or ORANGE_PIECE
    pg.color((1, 1, 1))
    pg.rect(x, y, w, h, 'f')
    pg.add('q %s %s %s %s re W n' % (_fmt(x), _fmt(y), _fmt(w), _fmt(h)))
    pg.color(col, True)
    pg.width(lw)
    t = -h
    while t < w + h:
        if sens > 0:
            pg.line(x + t, y, x + t + h, y + h)
        else:
            pg.line(x + t, y + h, x + t + h, y)
        t += step
    pg.add('Q')
    # contour fin et gris : ne pas confondre avec une coupe (demande du 2026-11-20, 16h51)
    pg.color(C_CONTOUR if edge_col is None else edge_col, True)
    pg.width(edge)
    pg.rect(x, y, w, h)


# 2026-11-20 17h33 : rayures 2x plus espacees pour economiser l'encre
def _hatch_delig(pg, x, y, w, h):
    # coupe, reste a finir : rayures violettes au lieu d'un aplat (encre, 2026-11-20 17h37)
    _hatch(pg, x, y, w, h, step=3.2, lw=0.45, col=C_DELIG_L, edge=0.35, sens=-1, edge_col=C_DELIG_L)


def _hatch_reste(pg, x, y, w, h):
    # plus clair (2026-11-19 : ne pas confondre avec la bande en cours)
    _hatch(pg, x, y, w, h, step=4.0, lw=0.3, col=(0.66, 0.66, 0.66), edge=0.4, sens=-1,
           edge_col=(0.66, 0.66, 0.66))


def _reste_bande(sheet, si, k, L, W, seuil=20.0):
    """Morceau de la bande k (index 0) qui reste a l'etape si : la bande
    rognee, sur chaque axe, a l'enveloppe des pieces pas encore terminees et
    des chutes (parties sans piece de plus de `seuil` mm)."""
    bd = sheet['bandes'][k]
    a, b = float(bd['a']), float(bd['b'])
    sr = (0.0, a, L, b) if bd.get('axis') == 'y' else (a, 0.0, b, W)   # x1, y1, x2, y2
    plan = sheet['plan']
    st = plan[si]
    done = set(i for s2 in plan[:si] for i in s2['pieces'])
    # pieces deja detachees de la bande par une coupe precedente (mises de cote) :
    # elles ne font plus partie du morceau, sauf si on les reprend a cette carte
    # (demande du 2026-11-20, 17h04)
    z_av = [z for s2 in plan[:si] if s2['kind'] != 'prim' for z in (s2.get('zones') or [s2['zone']])]
    z_now = st.get('zones') or [st['zone']]
    lp_av = set(i for s2 in plan[:si] for i in (s2.get('lp') or []))

    def dans(bb, z):
        return (bb[0] >= z[0] - 0.5 and bb[1] >= z[1] - 0.5 and
                bb[2] <= z[0] + z[2] + 0.5 and bb[3] <= z[1] + z[3] + 0.5)
    # morceaux R repris a cette carte : toutes leurs pieces sont en main, meme
    # celles hors des zones coupees ici (ex. R6, reste du morceau, 2026-11-23 00h09)
    pris_pcs = set(i for b in _blocs_carte(sheet, si) if b['card'] < si for i in b['pcs'])
    bbs, rest, bloc, fin_bb = [], [], [], []
    for i, pl in enumerate(sheet['placements']):
        bb = _bbox_pl(pl)
        if bb is None or not (bb[0] >= sr[0] - 0.5 and bb[1] >= sr[1] - 0.5 and
                              bb[2] <= sr[2] + 0.5 and bb[3] <= sr[3] + 0.5):
            continue
        if i not in done and (i in lp_av or any(dans(bb, z) for z in z_av)) and \
                (i in st['pieces'] or i in pris_pcs or any(dans(bb, z) for z in z_now)):
            # morceau detache qu'on reprend a cette carte ; chaque morceau
            # (derniere zone qui le contient) est dessine a part (2026-11-20, 17h10)
            zk = [j for j, z in enumerate(z_av) if dans(bb, z)]
            bloc.append((zk[-1] if zk else ('p', i), bb))
        if i in done:
            bbs.append(bb)
            continue
        detache = i in lp_av or any(dans(bb, z) for z in z_av)
        if detache and not (i in st['pieces'] or i in pris_pcs or any(dans(bb, z) for z in z_now)):
            bbs.append(bb)          # emplacement vide maintenant, comme une piece finie
            continue
        bbs.append(bb)
        rest.append(bb)
    if bloc:
        # pieces qui ne sont pas en main (finies ou mises de cote dans d'autres
        # morceaux) : on les retire en travers des bords de chaque zone
        en_main_bb = set(id(bb) for _k, bb in bloc)
        for i, pl in enumerate(sheet['placements']):
            bb = _bbox_pl(pl)
            if bb is None or not (bb[0] >= sr[0] - 0.5 and bb[1] >= sr[1] - 0.5 and
                                  bb[2] <= sr[2] + 0.5 and bb[3] <= sr[3] + 0.5):
                continue
            if not any(bb == q for _k, q in bloc):
                fin_bb.append((i, bb))
        # on travaille des morceaux deja detaches : eux seuls sont en main
        # (le reste de la bande est mis de cote)
        # chaque morceau a la taille de la zone qui l'a detache (la chute
        # deja separee par un delignage n'en fait plus partie, 2026-11-22 23h39)
        grp = {}
        for key, bb in bloc:
            grp.setdefault(key, []).append(bb)
        outs = []
        for key, q_ in grp.items():
            x1, y1 = min(q[0] for q in q_), min(q[1] for q in q_)
            x2, y2 = max(q[2] for q in q_), max(q[3] for q in q_)
            if not isinstance(key, tuple):
                z = z_av[key]
                zx1, zy1, zx2, zy2 = z[0], z[1], z[0] + z[2], z[1] + z[3]
                # sans les pieces deja finies ou mises de cote aux bords de la
                # zone : en travers (delignees avant, 2026-11-22 23h50) puis le
                # long de la bande (recoupees avant, 2026-11-23 00h09)
                ax_t = 1 if bd.get('axis') == 'y' else 0
                for d in (ax_t, 1 - ax_t):
                    zz = [zx1, zy1, zx2, zy2]
                    o = 1 - d
                    lo_, hi_ = zz[d], zz[d + 2]
                    iv = sorted((q[d], q[d + 2]) for i2, q in fin_bb
                                if q[o] >= zz[o] - 0.5 and q[o + 2] <= zz[o + 2] + 0.5)
                    if d == ax_t:
                        for _r in range(len(iv) + 1):
                            for u, v in iv:
                                if u <= lo_ + 8.0 and v > lo_:
                                    lo_ = v
                                if v >= hi_ - 8.0 and u < hi_:
                                    hi_ = u
                    else:
                        # le long de la bande : les pieces sont coupees l'une a la
                        # suite de l'autre, les trous partent au bout ; d'un cote
                        # deja entame, le morceau commence a la premiere piece en
                        # main (demande du 2026-11-23 00h25)
                        h_lo, h_hi = min(q[d] for q in q_), max(q[d + 2] for q in q_)
                        if any(v <= h_lo + 0.5 and v > lo_ for u, v in iv):
                            lo_ = h_lo
                        if any(u >= h_hi - 0.5 and u < hi_ for u, v in iv):
                            hi_ = h_hi
                    # jamais plus etroit que les pieces en main
                    lo_ = min(lo_, min(q[d] for q in q_))
                    hi_ = max(hi_, max(q[d + 2] for q in q_))
                    zz[d], zz[d + 2] = lo_, hi_
                    zx1, zy1, zx2, zy2 = zz
                x1, y1 = min(x1, zx1), min(y1, zy1)
                x2, y2 = max(x2, zx2), max(y2, zy2)
            x1, y1 = max(x1, sr[0]), max(y1, sr[1])
            x2, y2 = min(x2, sr[2]), min(y2, sr[3])
            outs.append((x1, y1, x2 - x1, y2 - y1))
        # morceaux deja separes (delignes avant) : chacun son cadre, meme
        # empiles (demande du 2026-11-23 00h09) ; seuls les chevauchements reels
        # sont reunis
        fus = True
        while fus:
            fus = False
            for a_ in range(len(outs)):
                for b_ in range(a_ + 1, len(outs)):
                    p_, q_ = outs[a_], outs[b_]
                    if all(p_[d] < q_[d] + q_[d + 2] - 0.5 and q_[d] < p_[d] + p_[d + 2] - 0.5 for d in (0, 1)):
                        x1, y1 = min(p_[0], q_[0]), min(p_[1], q_[1])
                        x2, y2 = max(p_[0] + p_[2], q_[0] + q_[2]), max(p_[1] + p_[3], q_[1] + q_[3])
                        outs[a_] = (x1, y1, x2 - x1, y2 - y1)
                        del outs[b_]
                        fus = True
                        break
                if fus:
                    break
        if bd.get('axis') == 'y':
            return sorted(outs, key=lambda q: q[0])
        return sorted(outs, key=lambda q: -q[1])
    if not rest:
        return [(sr[0], sr[1], sr[2] - sr[0], sr[3] - sr[1])]
    out = {}
    al = 0 if bd.get('axis') == 'y' else 1          # axe le long de la bande d'abord
    for ax in (al, 1 - al):
        lo_s, hi_s = sr[ax], sr[ax + 2]
        lo = min(q[ax] for q in rest)
        hi = max(q[ax + 2] for q in rest)
        if ax == al:
            # le long de la bande : pieces coupees l'une a la suite de l'autre,
            # les trous partent au bout. Cote deja entame : le morceau commence a
            # la premiere piece qui reste ; cote intact : jusqu'au bout de la
            # bande (demande du 2026-11-23 00h25)
            ids = set(id(q) for q in rest)
            autres = [q for q in bbs if id(q) not in ids]
            if not any(q[ax + 2] <= lo + 0.5 for q in autres):
                lo = lo_s
            if not any(q[ax] >= hi - 0.5 for q in autres):
                hi = hi_s
            out[ax] = (lo, hi)
            continue
        # chutes : intervalles de l'axe sans aucune piece ; en travers, seulement
        # parmi les pieces du morceau qui reste (2026-11-22 23h39)
        src = bbs if ax == al else [q for q in bbs if q[al] < out[al][1] - 0.5 and q[al + 2] > out[al][0] + 0.5]
        iv = sorted((q[ax], q[ax + 2]) for q in src)
        t, gaps = lo_s, []
        for u, v in iv:
            if u > t:
                gaps.append((t, u))
            t = max(t, v)
        if hi_s > t:
            gaps.append((t, hi_s))
        for u, v in gaps:
            if v - u >= seuil:
                lo, hi = min(lo, u), max(hi, v)
        out[ax] = (lo, hi)
    return [(out[0][0], out[1][0], out[0][1] - out[0][0], out[1][1] - out[1][0])]


NUM_H = 4.0 * MM      # numeros des bandes verticales, au-dessus des morceaux


def _piles(rs, al):
    """Morceaux d'une bande regroupes en piles : ceux qui se recouvrent le long
    de la bande (axe al) sont empiles en travers, chacun dans son cadre."""
    rs = sorted(rs, key=lambda r_: r_[al])
    piles = []
    for r_ in rs:
        if piles and r_[al] < max(q[al] + q[al + 2] for q in piles[-1]) - 0.5:
            piles[-1].append(r_)
        else:
            piles.append([r_])
    return piles


def _zoom(sheet, si, kt, L, W):
    """Morceaux de bande a dessiner a l'etape si et leur placement :
    (lay, k, horizontales, hauteur utilisee) ou None (panneau entier).
    lay = [(bande, [(rect, dx, dy)], (nx, ny))], dx depuis x0, dy depuis le
    haut de la vignette (negatif), coin bas-gauche de chaque cadre."""
    st = sheet['plan'][si]
    bandes = sheet.get('bandes') or []
    curs = [k - 1 for k in (st.get('strips') or [st.get('strip', 0)]) if 0 < k <= len(bandes)]
    if st['kind'] == 'prim' or not curs:
        return None
    curs = sorted(set(curs))
    regs = [(c, _reste_bande(sheet, si, c, L, W)) for c in curs]
    bw, bh, g = L * kt, W * kt, 3 * MM
    horiz = bandes[curs[0]].get('axis') == 'y'
    al = 0 if horiz else 1          # axe le long de la bande
    if horiz:
        regs.sort(key=lambda t: -max(r_[1] + r_[3] for r_ in t[1]))    # de haut en bas
    else:
        regs.sort(key=lambda t: min(r_[0] for r_ in t[1]))             # de gauche a droite
    pl_ = [(c, _piles(rs, al)) for c, rs in regs]

    def ext(p, d):
        return max(q[d] + q[d + 2] for q in p) - min(q[d] for q in p)

    def mesure(k):
        # (le long, en travers) de chaque bande ; une pile : morceaux en travers
        # les uns a cote des autres, ecartes de g
        out = []
        for _c, ps in pl_:
            lg = sum(ext(p, al) * k for p in ps) + g * (len(ps) - 1)
            tr = max(sum(q[3 - al] for q in p) * k + g * (len(p) - 1) for p in ps)
            out.append((lg, tr))
        return out

    def tient(k):
        m = mesure(k)
        lg = max(x[0] for x in m)
        tr = sum(x[1] for x in m) + g * (len(m) - 1)
        if horiz:
            return lg <= bw and tr <= bh
        return lg <= bh - NUM_H and tr <= bw
    lo, hi = 0.0, 4.0 * kt
    if tient(hi):
        lo = hi
    else:
        for _ in range(50):
            mid = (lo + hi) / 2.0
            if tient(mid):
                lo = mid
            else:
                hi = mid
    k = lo
    m = mesure(k)
    lay = []
    tr0 = 0.0
    for (c, ps), (lg, tr) in zip(pl_, m):
        items = []
        a0 = 0.0
        for p in ps:
            if horiz:
                px, py2 = min(q[0] for q in p), max(q[1] + q[3] for q in p)
                yy = -tr0
                for q in sorted(p, key=lambda q: -(q[1] + q[3])):     # du haut vers le bas
                    items.append((q, a0 + (q[0] - px) * k, yy - q[3] * k))
                    yy -= q[3] * k + g
            else:
                py2, px = max(q[1] + q[3] for q in p), min(q[0] for q in p)
                xx = tr0
                for q in sorted(p, key=lambda q: q[0]):                # de gauche a droite
                    items.append((q, xx, -NUM_H - a0 - (py2 - q[1]) * k))
                    xx += q[2] * k + g
            a0 += ext(p, al) * k + g
        if horiz:
            lab = (-1.2 * MM, -tr0 - tr / 2.0 - 3.2)
        else:
            lab = (tr0 + tr / 2.0, -NUM_H + 1.0 * MM)
        lay.append((c, items, lab))
        tr0 += tr + g
    if horiz:
        h = sum(x[1] for x in m) + g * (len(m) - 1)
    else:
        h = max(x[0] for x in m) + NUM_H
    return lay, k, horiz, h


def thumb_h(sheet, si, kt, L, W):
    z = _zoom(sheet, si, kt, L, W)
    return W * kt if z is None else z[3]


def _thumb(pg, x0, y0, kt, L, W, sheet, si):
    """Aux etapes des bandes, seuls les morceaux de bande qui restent sont
    dessines, agrandis dans la vignette (demande du 2026-11-20, 16h53)."""
    z = _zoom(sheet, si, kt, L, W)
    if z is None:
        return _thumb_core(pg, x0, y0, kt, L, W, sheet, si)
    lay, k, horiz, _h = z
    top = y0 + W * kt
    apres = []
    for c, items, (lx, ly) in lay:
        for (rx, ry, rw, rh), ddx, ddy in items:
            dx, dy = x0 + ddx, top + ddy
            apres.append(_thumb_core(pg, dx - rx * k, dy - ry * k, k, L, W, sheet, si, reg=(rx, ry, rw, rh)))
            pg.color((0.55, 0.55, 0.55), True)
            pg.width(0.4)
            pg.rect(dx, dy, rw * k, rh * k)
            pg.color(C_CADRE, True)
            pg.width(1.8)
            pg.rect(dx, dy, rw * k, rh * k)
        pg.color(C_CADRE)
        pg.text(x0 + lx, top + ly, str(c + 1), 9, True, 0, 'right' if horiz else 'center')
        pg.color((0, 0, 0))
    # lettres et reperes par-dessus les cadres (lisibles sur les bandes fines)
    for fn in apres:
        if fn is not None:
            fn()
    pg.color((0, 0, 0))


def _thumb_core(pg, x0, y0, kt, L, W, sheet, si, reg=None):
    """Vignette du panneau pour l'etape si. Bande en cours en gris clair, les
    autres bandes (deja coupees ou pas encore) tres claires en pointille,
    partie coupee en orange clair, piece terminee en orange, coupe en rouge."""
    plan = sheet['plan']
    st = plan[si]
    bandes = sheet.get('bandes') or []
    curs = [k - 1 for k in (st.get('strips') or [st.get('strip', 0)]) if 0 < k <= len(bandes)]
    cur = min(curs) if curs else -1

    def P(x, y):
        return (x0 + x * kt, y0 + y * kt)

    def strip_rect(bd):
        a, b = float(bd['a']), float(bd['b'])
        if bd.get('axis') == 'y':
            return 0.0, a, L, b - a
        return a, 0.0, b - a, W

    if reg is not None:
        # seul le morceau de bande qui reste est visible
        pg.add('q %s %s %s %s re W n' % (_fmt(x0 + reg[0] * kt), _fmt(y0 + reg[1] * kt),
                                         _fmt(reg[2] * kt), _fmt(reg[3] * kt)))
    pg.color((1, 1, 1))
    pg.color((0.55, 0.55, 0.55), True)
    pg.width(0.4)
    pg.rect(x0, y0, L * kt, W * kt, 'B')
    crs = [strip_rect(bandes[c]) for c in curs]
    cr = crs[0] if crs else None
    if st['kind'] != 'prim':
        pg.color(C_BANDE)
        for r_ in crs:
            pg.rect(x0 + r_[0] * kt, y0 + r_[1] * kt, r_[2] * kt, r_[3] * kt, 'f')
    zones = st.get('zones') or [st['zone']]
    done = set(i for s2 in plan[:si] for i in s2['pieces'])
    now = set(st['pieces'])

    def within(bb, r):
        return (bb[0] >= r[0] - 0.5 and bb[1] >= r[1] - 0.5 and
                bb[2] <= r[0] + r[2] + 0.5 and bb[3] <= r[1] + r[3] + 0.5)

    # pieces entamees (coupees dans une etape precedente, hors coupes prioritaires)
    # mais pas encore terminees : violet jusqu'a leur derniere coupe
    # (demandes du 2026-11-19 et du 2026-11-20 14h38)
    mis = set(i for s2 in plan[:si] for i in (s2.get('lp') or []))
    z_av = [z for s2 in plan[:si] if s2['kind'] != 'prim' for z in (s2.get('zones') or [s2['zone']])]
    for i, pl in enumerate(sheet['placements']):
        bb = _bbox_pl(pl)
        if bb is not None and any(within(bb, z) for z in z_av):
            mis.add(i)
    # bande entamee (une coupe deja faite ou en cours dedans) : ce qui en reste
    # est un morceau mis de cote, en violet (demande du 2026-11-20, 16h21)
    entamees = set(s2['strip'] for s2 in plan[:si + 1] if s2['kind'] != 'prim')
    for s2 in plan[:si + 1]:
        if s2['kind'] != 'prim':
            entamees.update(s2.get('strips') or [])
    for i, pl in enumerate(sheet['placements']):
        bb = _bbox_pl(pl)
        if bb is None:
            continue
        k_ = next((j + 1 for j, bd in enumerate(bandes) if within(bb, strip_rect(bd))), 0)
        if k_ in entamees:
            mis.add(i)
    mis -= done

    prim = st['kind'] == 'prim'
    for i, pl in enumerate(sheet['placements']):
        bb = _bbox_pl(pl)
        if bb is None:
            continue
        rx, ry, rw, rh = bb[0], bb[1], bb[2] - bb[0], bb[3] - bb[1]
        in_cur = any(within(bb, r_) for r_ in crs)
        inside = any(within(bb, z) for z in zones)
        # bande deja detachee (pendant les coupes prioritaires)
        k_strip = next((j for j, bd in enumerate(bandes) if within(bb, strip_rect(bd))), -1)
        if i in now or (inside and i not in done):
            _hatch(pg, x0 + rx * kt, y0 + ry * kt, rw * kt, rh * kt)  # piece ou bande qu'on coupe
            continue
        elif i in mis:
            _hatch_delig(pg, x0 + rx * kt, y0 + ry * kt, rw * kt, rh * kt)   # entamee, reste a finir
            continue
        elif i in done or (prim and 0 <= k_strip < cur):
            # deja coupe en blanc ; aux etapes des bandes, les pieces pas
            # encore coupees des autres bandes restent « pas encore coupe »
            # (demande du 2026-11-19, 20h18)
            fill, line = C_FAIT, C_FAIT_L                    # deja coupe
        elif in_cur and not prim:
            fill, line = C_BANDE_P, C_BANDE_L                # bande qu'on utilise
        else:
            _hatch_reste(pg, x0 + rx * kt, y0 + ry * kt, rw * kt, rh * kt)  # pas encore coupe
            continue
        pg.color(fill)
        pg.color(line, True)
        pg.width(0.3)
        pg.rect(x0 + rx * kt, y0 + ry * kt, rw * kt, rh * kt, 'B')
    def _garde(bb):
        return reg is None or within(bb, (reg[0], reg[1], reg[2], reg[3]))

    def _lettres():
        # repere de chaque morceau en cours (le plus recent qui contient la piece)
        poses_b = []
        # seulement a la carte qui le detache (a marquer) et a celle qui le
        # reprend (demande du 2026-11-20, 16h21 : epurer les vignettes)
        actifs = list(_blocs_carte(sheet, si))
        # morceau repris de plusieurs pieces : pas de repere sur la vignette (le
        # texte « Prendre » suffit, seules les nouvelles marques sont dessinees,
        # demande du 2026-11-23 00h03) ; piece seule : on garde le repere
        actifs = [b for b in actifs if b['card'] == si or len(b['pcs']) == 1]
        for b in actifs:
            bx = [sheet['placements'][i] for i in b['pcs']]
            bbs = [_bbox_pl(pl) for pl in bx]
            bbs = [q for q in bbs if q is not None]
            if not bbs or not _garde(bbs[0]):
                continue
            ux, uy = min(q[0] for q in bbs), max(q[3] for q in bbs)
            bx_, by_ = x0 + ux * kt + 0.6, y0 + uy * kt - 7.0 * 1.05 - 0.6
            bw_ = _text_width(b['ref'], 7.0, True) + 2.0
            # badges qui se chevauchent (morceaux fins empiles) : decales a droite
            for _k in range(50):
                hit = [q for q in poses_b if abs(by_ - q[1]) < 7.5 and bx_ < q[0] + q[2] + 0.8 and bx_ + bw_ > q[0] - 0.8]
                if not hit:
                    break
                by_, bx_ = hit[0][1], hit[0][0] + hit[0][2] + 0.8   # meme ligne, juste a droite
            poses_b.append((bx_, by_, bw_))
            _badge(pg, bx_, by_, b['ref'])
        # lettre repere dans chaque piece terminee a cette carte
        pg.color((0, 0, 0))
        poses = []
        for i in now:
            pl = sheet['placements'][i]
            bb = _bbox_pl(pl)
            r_l = _rep(pl)
            if bb is None or not r_l or not _garde(bb):
                continue
            # meme taille pour toutes les lettres ; sur une petite piece la lettre
            # deborde, sur un fond blanc pour rester lisible (demande du 2026-11-19, 21h33)
            fs = 7.0
            mx, my = x0 + (bb[0] + bb[2]) / 2.0 * kt, y0 + (bb[1] + bb[3]) / 2.0 * kt
            lw_ = _text_width(r_l, fs, True)
            pw, ph = (bb[2] - bb[0]) * kt, (bb[3] - bb[1]) * kt
            # lettres qui se chevauchent (pieces fines empilees) : decalees a droite
            while any(abs(mx - qx) < (lw_ + qw) / 2.0 + 1.0 and abs(my - qy) < fs * 1.1 for qx, qy, qw in poses):
                mx += lw_ + 1.5
            poses.append((mx, my, lw_))
            if pw < lw_ + 1.5 or ph < fs * 0.9 or poses[-1][0] != x0 + (bb[0] + bb[2]) / 2.0 * kt:
                pg.color((1, 1, 1))
                pg.rect(mx - lw_ / 2.0 - 0.6, my - fs * 0.42, lw_ + 1.2, fs * 0.84, 'f')
                pg.color((0, 0, 0))
            pg.text(mx, my - fs * 0.36, r_l, fs, True, 0.0, 'center')

    for r_ in (crs if reg is None else []):
        # cadre autour de la ou des bandes en cours (coupes prioritaires et bandes)
        pg.color(C_CADRE, True)
        pg.width(1.8)
        pg.rect(x0 + r_[0] * kt, y0 + r_[1] * kt, r_[2] * kt, r_[3] * kt)
    if prim and cr is not None:
        _lettres()
        # numero des bandes a marquer (demande du 2026-11-20, 16h59)
        pg.color(C_CADRE)
        for k_ in _bandes_de_cote(sheet, si)[0]:
            r_ = strip_rect(bandes[k_ - 1])
            if bandes[k_ - 1].get('axis') == 'y':
                pg.text(x0 - 1.2 * MM, y0 + (r_[1] + r_[3] / 2.0) * kt - 3.2, str(k_), 9, True, 0, 'right')
            else:
                tx, ty = x0 + (r_[0] + r_[2] / 2.0) * kt, y0 + (r_[1] + r_[3]) * kt - 4.2 * MM
                tw = _text_width(str(k_), 9, True)
                pg.color((1, 1, 1))
                pg.rect(tx - tw / 2.0 - 0.8, ty - 1.0, tw + 1.6, 9 * 0.9, 'f')
                pg.color(C_CADRE)
                pg.text(tx, ty, str(k_), 9, True, 0, 'center')
        pg.color((0, 0, 0))
        return      # coupes prioritaires : le cadre vert suffit (demande du 2026-11-19)
    pg.color(ROUGE_COUPE, True)
    pg.width(1.7)
    for (a1, b1), (a2, b2) in st.get('segs') or [st['seg']]:
        p1, p2 = P(a1, b1), P(a2, b2)
        pg.line(p1[0], p1[1], p2[0], p2[1])
    if reg is not None:
        pg.add('Q')
        return _lettres     # dessinees apres les cadres (au-dessus)
    # numero de chaque bande travaillee, devant la bande (demande du 2026-11-20, 16h37)
    pg.color(C_CADRE)
    for c_, r_ in zip(curs, crs):
        if bandes[c_].get('axis') == 'y':
            pg.text(x0 - 1.2 * MM, y0 + (r_[1] + r_[3] / 2.0) * kt - 3.2, str(c_ + 1), 9, True, 0, 'right')
        else:
            pg.text(x0 + (r_[0] + r_[2] / 2.0) * kt, y0 + W * kt + 1.0 * MM, str(c_ + 1), 9, True, 0, 'center')
    pg.color((0, 0, 0))
    _lettres()


def _meme_ligne(z1, z2, seg):
    """Deux coupes de la meme bande / rangee : leurs zones ont la meme
    etendue le long du trait de coupe (une carte par bande, 2026-11-19)."""
    (a1, b1), (a2, b2) = seg
    if abs(a1 - a2) < 1e-6:        # trait vertical : meme y, meme hauteur
        return abs(z1[1] - z2[1]) < 0.6 and abs(z1[3] - z2[3]) < 0.6
    return abs(z1[0] - z2[0]) < 0.6 and abs(z1[2] - z2[2]) < 0.6


def _reglage(st):
    """Reglage de la scie : guide parallele ou butee laterale, et la cote."""
    return ('par' if st['kind'] in ('prim', 'refente', 'ajust') else 'lat', round(float(st['dim']), 1))


def _grouper_etapes(plan):
    """Regroupe les coupes qui se suivent avec le meme reglage de la scie
    (meme guide, meme cote), sur une ou plusieurs bandes (demandes du
    2026-11-19 : « 4 pieces a 251 », puis ordre par reglage dans le panneau)."""
    out = []
    np_ = 0
    for st in plan:
        if st['kind'] == 'prim':
            np_ += 1
        g = out[-1] if out else None
        if (g is not None and (g['kind'] == 'prim') == (st['kind'] == 'prim')
                and _reglage(g) == _reglage(st)):
            g['segs'].append(st['seg'])
            g['pieces'] = g['pieces'] + list(st['pieces'])
            g['n'] += 1
            g['lp'] = g['lp'] + list(st.get('lp') or [])
            g['extra'] = st.get('extra', 0)
            g['zones'].append(list(st['zone']))
            g['kinds'].add(st['kind'])
            if st['strip'] not in g['strips']:
                g['strips'].append(st['strip'])
            if st['kind'] == 'prim':
                g['pnums'].append(np_)
            continue
        out.append(dict(st, segs=[st['seg']], pieces=list(st['pieces']), n=1, zones=[list(st['zone'])],
                        kinds={st['kind']}, strips=[st['strip']], lp=list(st.get('lp') or []), pnums=[np_] if st['kind'] == 'prim' else []))
    return out


def _noms_groupes(names, idx):
    """Noms des pieces, les doublons comptes : « Traverse basse x4, Montant »."""
    cnt, order = {}, []
    for i in idx:
        n = names.get(i, '')
        if n not in cnt:
            order.append(n)
            cnt[n] = 0
        cnt[n] += 1
    return ', '.join(n if cnt[n] == 1 else '%s x%d' % (n, cnt[n]) for n in order)


C_REPERE = (0.88, 0.0, 0.52)        # badge des morceaux a finir (magenta, 2026-11-20)


def _within(bb, r):
    return (bb[0] >= r[0] - 0.5 and bb[1] >= r[1] - 0.5 and
            bb[2] <= r[0] + r[2] + 0.5 and bb[3] <= r[1] + r[3] + 0.5)


def _blocs(sheet):
    """Morceaux detaches mais pas finis : [{'ref': 'R1', 'card': si, 'pcs': set}].
    Un morceau nait a la carte qui le detache (hors coupes prioritaires) et
    contient les pieces de la zone qui ne sont pas terminees a cette carte
    (demande du 2026-11-20, 14h45 : un repere a ecrire sur le morceau)."""
    plan = sheet['plan']
    bbs = [_bbox_pl(pl) for pl in sheet['placements']]
    out, done = [], set()
    for si, st in enumerate(plan):
        fin = done | set(st['pieces'])
        if st['kind'] != 'prim':
            for z in (st.get('zones') or [st['zone']]):
                pcs = set(i for i, bb in enumerate(bbs) if bb is not None and i not in fin and _within(bb, z))
                pcs |= set(i for i in (st.get('lp') or []) if i not in fin and bbs[i] is not None and _within(bbs[i], z))
                if pcs and not any(b['pcs'] == pcs for b in out):
                    out.append({'ref': 'R%d' % (len(out) + 1), 'card': si, 'pcs': pcs})
            # morceau coupe en plusieurs a cette carte : ce qui en reste (hors des
            # nouveaux morceaux) recoit un nouveau repere, l'ancien est sur un des
            # morceaux (demande du 2026-11-23 00h03 : R3 n'existe plus)
            nouv = [b for b in out if b['card'] == si]
            if nouv:
                pris = set(i for b in nouv for i in b['pcs'])
                av = [b for b in out if b['card'] < si]
                # seulement le morceau le plus recent de chaque piece prise
                der = []
                for i in pris:
                    c_ = [b for b in av if i in b['pcs']]
                    if c_ and c_[-1] not in der:
                        der.append(c_[-1])
                for b in der:
                    rq = set(i for i in b['pcs'] if i not in fin and i not in pris)
                    if rq and rq != b['pcs'] and not any(c['pcs'] == rq for c in out):
                        out.append({'ref': 'R%d' % (len(out) + 1), 'card': si, 'pcs': rq, 'reste': True})
        done = fin
    # un morceau repris des la carte suivante n'a pas besoin de repere
    # (on enchaine sans le poser) : on ne garde que ceux mis de cote
    keep = []
    for b in out:
        use = None
        for sj in range(b['card'] + 1, len(plan)):
            st = plan[sj]
            zs = st.get('zones') or [st['zone']]
            if any(i in st['pieces'] or any(bbs[i] is not None and _within(bbs[i], z) for z in zs) for i in b['pcs']):
                use = sj
                break
        # ... sauf s'il sort d'une carte qui termine aussi d'autres pieces : il faut
        # le distinguer des pieces finies (demande du 2026-11-20, 17h05)
        if use is not None and (use > b['card'] + 1 or plan[b['card']]['pieces'] or b.get('reste')):
            keep.append(b)
    for k, b in enumerate(keep):
        b['ref'] = 'R%d' % (k + 1)
    return keep


def _blocs_carte(sheet, si):
    """(nouveaux, repris) : morceaux a marquer et morceaux repris a la carte si."""
    st = sheet['plan'][si]
    bbs = [_bbox_pl(pl) for pl in sheet['placements']]
    zs = st.get('zones') or [st['zone']]
    nouv = [b for b in (sheet.get('blocs') or []) if b['card'] == si]
    pris = []
    for b in (sheet.get('blocs') or []):
        if b['card'] >= si:
            continue
        # le morceau le plus recent de chaque piece coupee ici
        for i in b['pcs']:
            if i in st['pieces'] or any(bbs[i] is not None and _within(bbs[i], z) for z in zs):
                cand = [c for c in sheet['blocs'] if c['card'] < si and i in c['pcs']]
                if cand and cand[-1] is b and b not in pris:
                    pris.append(b)
                break
    return nouv + pris


def _bandes_de_cote(sheet, si):
    """(a marquer, a reprendre) : bandes laissees entamees apres la carte si,
    et bandes reprises a la carte si apres avoir ete mises de cote."""
    plan = sheet['plan']
    st = plan[si]
    bandes = sheet.get('bandes') or []
    if st['kind'] == 'prim':
        # coupes prioritaires : chaque bande liberee est a marquer (demande du
        # 2026-11-20, 16h59) ; la derniere carte libere aussi les bandes sans coupe
        mq = set(k for k in (st.get('strips') or [st['strip']]) if 0 < k <= len(bandes))
        prims = [j for j, s2 in enumerate(plan) if s2['kind'] == 'prim']
        if prims and si == prims[-1]:
            avec = set(k for j in prims for k in (plan[j].get('strips') or [plan[j]['strip']]))
            mq.update(k for k in range(1, len(bandes) + 1) if k not in avec)
        return sorted(mq), []
    bbs = [_bbox_pl(pl) for pl in sheet['placements']]

    def rect(bd):
        a, b = float(bd['a']), float(bd['b'])
        return (0.0, a, 1e9, b - a) if bd.get('axis') == 'y' else (a, 0.0, b - a, 1e9)

    def ks(sj):
        # bandes dont la carte sj coupe le morceau principal (pas seulement des
        # morceaux R deja detaches, demande du 2026-11-20, 17h21)
        s2 = plan[sj]
        if s2['kind'] == 'prim':
            return set()
        fini = set(i for s3 in plan[:sj] for i in s3['pieces'])
        z_av = [z for s3 in plan[:sj] if s3['kind'] != 'prim' for z in (s3.get('zones') or [s3['zone']])]
        lp_av = set(i for s3 in plan[:sj] for i in (s3.get('lp') or []))
        z_now = s2.get('zones') or [s2['zone']]
        out = set()
        for k in set(s2.get('strips') or [s2['strip']]):
            if not (0 < k <= len(bandes)):
                continue
            r_ = rect(bandes[k - 1])
            main = [i for i, bb in enumerate(bbs) if bb is not None and i not in fini and _within(bb, r_)
                    and (i in s2['pieces'] or any(_within(bb, z) for z in z_now))]
            if not main or not all(i in lp_av or any(_within(bbs[i], z) for z in z_av) for i in main):
                out.add(k)
        return out

    fait = set(i for s2 in plan[:si + 1] for i in s2['pieces'])
    ici = ks(si)
    nxt = ks(si + 1) if si + 1 < len(plan) else set()
    prv = ks(si - 1) if si > 0 else set()
    mq, pr = [], []
    for k in sorted(ici):
        r_ = rect(bandes[k - 1])
        # le morceau principal qui reste (sans les morceaux R detaches)
        z_j = [z for s3 in plan[:si + 1] if s3['kind'] != 'prim' for z in (s3.get('zones') or [s3['zone']])]
        lp_j = set(i for s3 in plan[:si + 1] for i in (s3.get('lp') or []))
        reste = [i for i, bb in enumerate(bbs) if bb is not None and i not in fait and _within(bb, r_)
                 and i not in lp_j and not any(_within(bb, z) for z in z_j)]
        # a marquer s'il en reste, sauf si on continue la meme bande seule a la
        # carte suivante (plusieurs bandes : on marque tout, 2026-11-20 17h21)
        if reste and not (ici == {k} and nxt == {k}):
            mq.append(k)
        # toute bande reprise, y compris la premiere fois apres les coupes
        # prioritaires (elle y a ete marquee, demande du 2026-11-20, 17h27)
        if k not in prv:
            pr.append(k)
    return mq, pr


def _badge(pg, x, y, txt, fs=7.0):
    """Repere en blanc sur fond magenta, coin bas-gauche en (x, y)."""
    w = _text_width(txt, fs, True) + 2.0
    h = fs * 1.05
    pg.color(C_REPERE)
    pg.rect(x, y, w, h, 'f')
    pg.color((1, 1, 1))
    pg.text(x + 1.0, y + h * 0.22, txt, fs, True)
    pg.color((0, 0, 0))
    return w


def _ordre_pages(doc, grp, sheet, n_sheets):
    plan = _grouper_etapes(sheet.get('plan') or [])
    if not plan:
        return []
    sheet = dict(sheet, plan=plan)
    sheet['blocs'] = _blocs(sheet)
    L, W = float(doc['L']), float(doc['W'])
    NUM_W = 5 * MM                      # colonne des numeros de bande a gauche de la vignette
    # vignettes aussi grandes que possible, mais 3 lignes de cartes doivent tenir
    # sur la premiere page avec les deux titres d'etape (demande du 2026-11-20, 16h40) :
    # 61 mm de titres et d'espaces + 3 cartes de (vignette + 21.2 mm)
    avail = PAGE_W - 2 * MARGIN
    th_max = ((PAGE_H - MARGIN - 16 * MM) - (MARGIN + 8 * MM) - 61 * MM - 1 * MM) / 3.0 - 19.0 * MM
    cw = min((avail - (ORDRE_COLS - 1) * 5 * MM) / ORDRE_COLS, th_max * L / W + 2 * MM + NUM_W)
    n_cols = max(ORDRE_COLS, int((avail + 5 * MM) // (cw + 5 * MM)))
    gap = (avail - n_cols * cw) / (n_cols - 1)
    kt = (cw - 2 * MM - NUM_W) / L
    th = W * kt
    hd = 9 * MM                          # en-tete de carte : la cote en gros (le numero est dans le bandeau)
    LN_H = 4.0 * MM                      # interligne des noms de pieces (police 8.5)
    ch = hd + th + 2 * MM + 2 * LN_H
    top = PAGE_H - MARGIN - 16 * MM
    names = {}
    for i, pl in enumerate(sheet['placements']):
        bb = _bbox_pl(pl)
        if bb is not None:
            dw, dh = bb[2] - bb[0], bb[3] - bb[1]
            # sans les cotes ni le numero de copie (demande du 2026-11-19)
            names[i] = _base_name(pl)
    # sections : coupes prioritaires, puis les cartes dans l'ordre, regroupees
    # sous un bandeau par bande (ou par groupe de bandes au meme reglage)
    bandes = sheet.get('bandes') or []

    def strips_title(ks):
        if len(ks) == 1:
            k = ks[0]
            if 0 < k <= len(bandes):
                bd = bandes[k - 1]
                return u'Bande %d  -  largeur %s mm' % (k, _mm(float(bd['b']) - float(bd['a'])))
            return u'Bande %d' % k
        return u'Bandes %s  -  même réglage' % ', '.join(str(k) for k in sorted(ks))

    sections = []
    for i, st in enumerate(plan):
        title = u'Coupes prioritaires' if st['kind'] == 'prim' else strips_title(st['strips'])
        if sections and sections[-1][0] == title:
            sections[-1][1].append(i)
        else:
            sections.append((title, [i]))
    head_h = 7 * MM
    bottom = MARGIN + 8 * MM
    # mise en page compacte (2026-11-19 : moins de pages) : les cartes se
    # suivent sur la ligne, chaque section a son bandeau au-dessus de ses
    # cartes ; une nouvelle section ne force plus une nouvelle ligne.
    # items : (page, 'head', y, titre, q0, q1) / (page, 'card', y, colonne, etape)
    # hauteur de chaque ligne de cartes : la plus haute vignette de la ligne
    # (les morceaux de bande zoomes prennent moins de place, 2026-11-20 16h53)
    row_h, rq, rph, ri = [], 0, None, -1
    card_row = {}
    for title, idx in sections:
        ph_ = 1 if plan[idx[0]]['kind'] == 'prim' else 2
        for si in idx:
            if ph_ != rph or rq >= n_cols:
                row_h.append(0.0)
                ri += 1
                rq = 0
                rph = ph_
            th_c = thumb_h(sheet, si, kt, L, W)
            row_h[ri] = max(row_h[ri], hd + th_c + 2 * MM + 2 * LN_H)
            card_row[si] = ri
            rq += 1
    items = []
    page = 0
    y = top
    q = 0
    phase_h = 9 * MM                    # titre d'etape : 1. couper les bandes, 2. les detailler
    phase = None
    for title, idx in sections:
        seg = None
        ph = 1 if plan[idx[0]]['kind'] == 'prim' else 2
        if ph != phase:
            # nouvelle etape : nouvelle ligne, un espace et un titre (demande du 2026-11-20, 16h29)
            if q:
                y -= head_h + ch_r + 8 * MM
                q = 0
            if phase is not None:
                y -= 6 * MM
            ch_r = row_h[card_row[idx[0]]]
            if y - (phase_h + head_h + ch_r) < bottom:
                page += 1
                y = top
            items.append((page, 'phase', y, ph))
            y -= phase_h
            phase = ph
        for si in idx:
            if q >= n_cols:                          # ligne suivante
                y -= head_h + ch_r + 8 * MM
                q = 0
                seg = None
                ch_r = row_h[card_row[si]]
                if y - (head_h + ch_r) < bottom:
                    page += 1
                    y = top
            if seg is None:
                seg = [page, 'head', y, title if si == idx[0] else title + u' (suite)', q, q, []]
                items.append(seg)
            seg[5] = q
            seg[6].append((q, si))
            items.append((page, 'card', y - head_h, q, si, ch_r))
            q += 1
    n_pages = page + 1
    pages = []
    for p in range(n_pages):
        pg = _Page()
        pg.color((0, 0, 0))
        pg.text(MARGIN, PAGE_H - MARGIN - 6 * MM,
                u'Ordre des coupes  -  panneau %d sur %d  -  %s' % (sheet['index'], n_sheets, grp['label']), 13, True)
        pg.text(MARGIN, PAGE_H - MARGIN - 12 * MM,
                u'Coupes prioritaires d\'abord, puis chaque bande est coupée en pièces.', 8.5)
        lx = MARGIN + 100 * MM
        for fill, line, txt in (('hatch', None, u'Pièce ou bande qu\'on coupe'),
                                ((1.0, 1.0, 1.0), C_CADRE, u'Bande en cours'),
                                ('reste', None, u'Pas encore coupé'),
                                (C_FAIT, C_FAIT_L, u'Déjà coupé'),
                                (C_DELIG, C_DELIG_L, u'Coupé, reste à finir'),
                                (None, ROUGE_COUPE, u'Coupe à faire')):
            if fill == C_DELIG and all(s2['kind'] == 'prim' for s2 in sheet['plan']):
                continue
            if fill == 'hatch':
                _hatch(pg, lx, PAGE_H - MARGIN - 12.4 * MM, 6 * MM, 3 * MM)
            elif fill == 'reste':
                _hatch_reste(pg, lx, PAGE_H - MARGIN - 12.4 * MM, 6 * MM, 3 * MM)
            elif fill == C_DELIG:
                _hatch_delig(pg, lx, PAGE_H - MARGIN - 12.4 * MM, 6 * MM, 3 * MM)
            elif fill is None:
                pg.color(line, True)
                pg.width(1.7)
                pg.line(lx, PAGE_H - MARGIN - 11.2 * MM, lx + 6 * MM, PAGE_H - MARGIN - 11.2 * MM)
            else:
                pg.color(fill)
                pg.color(line, True)
                pg.width(0.5)
                pg.rect(lx, PAGE_H - MARGIN - 12.4 * MM, 6 * MM, 3 * MM, 'B')
            pg.color((0, 0, 0))
            pg.text(lx + 8 * MM, PAGE_H - MARGIN - 12 * MM, txt, 8.5)
            lx += 8 * MM + _text_width(txt, 8.5) + 10 * MM
        pg.text(PAGE_W - MARGIN, MARGIN, '%s  -  %s  -  page %d / %d' % (doc.get('title', 'Calpinage'), doc.get('date', ''),
                                                                     p + 1, n_pages), 7, False, 0, 'right')
        for it in items:
            if it[0] != p:
                continue
            if it[1] == 'phase':
                t_ = (u'Étape 1  -  Couper les bandes (coupes prioritaires)' if it[3] == 1
                      else u'Étape 2  -  Détailler les bandes en pièces')
                pg.color((0, 0, 0))
                pg.text(MARGIN, it[2] - 5.5 * MM, t_, 12, True)
                pg.color(C_CADRE, True)
                pg.width(1.0)
                pg.line(MARGIN, it[2] - 7.5 * MM, PAGE_W - MARGIN, it[2] - 7.5 * MM)
                continue
            if it[1] == 'head':
                yh, q0, q1 = it[2], it[4], it[5]
                hx = MARGIN + q0 * (cw + gap)
                hw = (q1 - q0) * (cw + gap) + cw
                pg.color((0.88, 0.88, 0.88))
                pg.rect(hx, yh - 5.5 * MM, hw, 5.5 * MM, 'f')
                pg.color((0, 0, 0))
                # numero de chaque carte a gauche, au-dessus de sa carte ; le titre
                # (bandes, largeur ou reglage) colle a droite (demande du 2026-11-20, 16h47)
                for q_, si_ in it[6]:
                    pg.text(MARGIN + q_ * (cw + gap) + 1.5 * MM, yh - 4 * MM, '%d.' % (si_ + 1), 10, True)
                room = hw - 12 * MM
                fs = min(9.5, 9.5 * room / max(1.0, _text_width(it[3], 9.5, True)))
                pg.text(hx + hw - 1.5 * MM, yh - 4 * MM, it[3], fs, True, 0, 'right')
                continue
            _p, _k, cy, q, si, ch = it
            th_c = ch - (hd + 2 * MM + 2 * LN_H)
            st = plan[si]
            cx = MARGIN + q * (cw + gap)
            pg.color((0, 0, 0), True)
            pg.width(0.3)
            pg.rect(cx, cy - ch, cw, ch)
            pg.color((0, 0, 0))
            # a droite du gros texte, empiles : nombre de pieces, a marquer, a reprendre
            bl_ = _blocs_carte(sheet, si)
            b_mq, b_pr = _bandes_de_cote(sheet, si)
            droite = []
            # Prendre avant Marquer : on prend d'abord (demande du 2026-11-20, 17h21)
            for verbe, refs, bds in ((u'Prendre', [b['ref'] for b in bl_ if b['card'] != si], b_pr),
                                     (u'Marquer', [b['ref'] for b in bl_ if b['card'] == si], b_mq)):
                parts = []
                if refs:
                    parts.append(', '.join(refs[:6]) + (u'...' if len(refs) > 6 else ''))
                if bds:
                    if parts:
                        parts.append(u'et')         # « Marquer R1, R2 et bande 5 » (2026-11-20, 17h26)
                    parts.append((u'bande %d' % bds[0]) if len(bds) == 1 else
                                 (u'bandes %s' % ', '.join(str(k) for k in bds[:12])))
                if parts:
                    droite.append((verbe, parts))
            pg.color((0, 0, 0))
            # pieces de la carte qui font exactement la cote coupee (en travers de la coupe)
            (sa, sb), (ea, eb) = st['seg']
            # pieces mises a longueur par la carte, y compris celles encore a deligner
            # ensuite (demande du 2026-11-19 : « 15 pieces » au lieu de 17)
            pcs_l = list(st['pieces']) + [i for i in st.get('lp', []) if i not in st['pieces']]
            if st['kinds'] <= {'trons', 'recoupe'}:
                # un troncon detache une colonne de plusieurs pieces deja a longueur
                # (demande du 2026-11-19, 21h02 : « 4 pieces » pour 6 coupes)
                fait = set(i for s2 in plan[:si] for i in list(s2['pieces']) + list(s2.get('lp') or []))
                for i, pl in enumerate(sheet['placements']):
                    bb = _bbox_pl(pl)
                    if bb is None or i in fait or i in pcs_l:
                        continue
                    if any(bb[0] >= z[0] - 0.5 and bb[1] >= z[1] - 0.5 and bb[2] <= z[0] + z[2] + 0.5
                           and bb[3] <= z[1] + z[3] + 0.5 for z in (st.get('zones') or [st['zone']])):
                        pcs_l.append(i)
            k_ok = 0
            for i in pcs_l:
                bb = _bbox_pl(sheet['placements'][i])
                if bb is not None:
                    across = (bb[2] - bb[0]) if abs(sa - ea) < 1e-6 else (bb[3] - bb[1])
                    k_ok += abs(across - float(st['dim'])) < 0.6
            n_b = st['n'] + int(st.get('extra', 0) or 0)
            if st['kinds'] == {'ajust'}:
                # reprise d'une piece en largeur : « deligner » (demande du 2026-11-19)
                # plusieurs : « N coupes à » comme les autres cartes (2026-11-22 23h46)
                n_a = len(st['pieces'])
                big = (u'%d coupes à %s mm' % (n_a, _mm(st['dim']))) if n_a > 1 else \
                    (u'Déligner à %s mm' % _mm(st['dim']))
            elif st['kinds'] <= {'refente', 'ajust'} and 'refente' in st['kinds']:
                # refente dans une bande = coupe dans le fil de la bande : « deligner »
                # (demande du 2026-11-20, 16h51) ; plusieurs : « N coupes à » (2026-11-22 23h46)
                big = (u'%d coupes à %s mm' % (n_b, _mm(st['dim']))) if n_b > 1 else \
                    (u'Déligner à %s mm' % _mm(st['dim']))
            elif st['kinds'] <= {'refente', 'prim'} and n_b > 1:
                big = u'%d bandes à %s mm' % (n_b, _mm(st['dim']))
            elif len(pcs_l) > 1 and k_ok == len(pcs_l) and k_ok <= st['n']:
                big = u'%d pièces à %s mm' % (k_ok, _mm(st['dim']))
            elif k_ok > st['n'] and k_ok == len(pcs_l):
                # plus de pieces que de coupes : on annonce les coupes, et les pieces a droite
                big = (u'%d coupes à %s mm' % (st['n'], _mm(st['dim']))) if st['n'] > 1 else \
                    (u'Couper à %s mm' % _mm(st['dim']))
                droite.insert(0, (None, [u'%d pièces' % k_ok]))
            elif st['n'] > 1:
                big = u'%d coupes à %s mm' % (st['n'], _mm(st['dim']))
            else:
                big = u'Couper à %s mm' % _mm(st['dim'])
            # bloc de droite : chaque morceau traduit a part, aligne a droite
            wd = 0.0
            for verbe, parts in droite:
                w_ = sum(_text_width(t, 7.5, True) for t in parts) + 1.2 * MM * (len(parts) - 1)
                if verbe:
                    w_ += _text_width(verbe, 7.5, True) + 1.2 * MM
                wd = max(wd, w_)
            yl = cy - 3.2 * MM - (0 if len(droite) > 1 else 1.4 * MM)
            for verbe, parts in droite[:3]:
                pg.color(C_REPERE if verbe else (0, 0, 0))
                xr = cx + cw - 2 * MM
                for t in reversed(parts):
                    pg.text(xr, yl, t, 7.5, True, 0, 'right')
                    xr -= _text_width(t, 7.5, True) + 1.2 * MM
                if verbe:
                    pg.text(xr, yl, verbe, 7.5, True, 0, 'right')
                yl -= 2.9 * MM
            bs = min(15.0, (cw - 5 * MM - wd - (2 * MM if wd else 0)) / (len(big) * 0.56))
            pg.color((0, 0, 0))
            pg.text(cx + 2.5 * MM, cy - hd + 1.6 * MM + bs * 0.0, big, bs, True)
            # lettres reperes propres a la carte (A, B, C...), seulement s'il y a
            # plusieurs sortes de pieces (demande du 2026-11-19, 21h30)
            _REP.clear()
            for i in st['pieces']:
                if names.get(i, '') not in _REP:
                    _REP[names.get(i, '')] = _lettre(len(_REP))
            if len(_REP) < 2:
                _REP.clear()
            _thumb(pg, cx + 1 * MM + NUM_W, cy - hd - 1 * MM - th, kt, L, W, sheet, si)
            # noms des seules pieces terminees a cette carte (demande du 2026-11-19, 21h07)
            if st['pieces']:
                lab = _noms_groupes(dict((i, (u'%s = %s' % (_REP[n], n)) if n in _REP else n)
                                         for i, n in names.items()), st['pieces'])
                _REP.clear()
                pre = u'Pièce : ' if len(st['pieces']) == 1 else u'Pièces : '
                n_max = int((cw - 3 * MM) / (8.5 * 0.56))
                # coupure aux espaces (pas au milieu d'un mot), 2 lignes max
                lines, cur = [], ''
                for w in (pre + lab).split(' '):
                    if cur and len(cur) + 1 + len(w) > n_max:
                        lines.append(cur)
                        cur = w
                    else:
                        cur = (cur + ' ' + w) if cur else w
                lines.append(cur)
                if len(lines) > 2:
                    lines = [lines[0], (lines[1] + ' ' + ' '.join(lines[2:]))[:n_max - 1] + '.']
                pg.color((0, 0, 0))
                for li, t in enumerate(lines):
                    yt = cy - hd - 1 * MM - th_c - 4.6 * MM - li * LN_H
                    if li == 0 and t.startswith(pre):
                        # « Pieces : » de la couleur des reperes : noms a ecrire sur
                        # les pieces (demande du 2026-11-20, 17h07)
                        pg.color(C_REPERE)
                        pg.text(cx + 1.5 * MM, yt, pre.strip(), 8.5, True)
                        pg.color((0, 0, 0))
                        pre_t = _i18n.t(pre.strip()) if _i18n is not None else pre.strip()
                        pg.text(cx + 1.5 * MM + _text_width(pre_t, 8.5, True) * 0.9 + 0.6 * MM, yt, t[len(pre):], 8.5, True)
                    else:
                        pg.text(cx + 1.5 * MM, yt, t, 8.5, True)
        pages.append(pg)
    return pages


def _doc_flags(doc):
    poche = grav = cut = False
    for g in doc['groups']:
        for s in g['sheets']:
            cut = cut or bool(s.get('cuts'))
            for pl in s['placements']:
                poche = poche or any(d > 0.05 for d in (pl.get('depths') or []))
                grav = grav or bool(pl.get('grav'))
    return poche, grav, cut


# --- reglages et temps de coupe (page de garde, demande du 2026-11-23 00h25) ---

def _guide(kind):
    """Guide de la scie regle pour une coupe : guide parallele (refentes) ou
    butee de la table (mises a longueur)."""
    return 'par' if kind in ('prim', 'refente', 'ajust') else 'lat'


def compter_reglages(groups):
    """Nombre de reglages de la scie pour couper tous les panneaux dans l'ordre
    du PDF : un reglage chaque fois qu'un guide change de cote (chaque guide
    garde sa cote d'une coupe a l'autre et d'un panneau au suivant)."""
    cur, n = {}, 0
    for g in groups:
        for s in g['sheets']:
            for st in (s.get('plan') or []):
                k, d = _guide(st['kind']), round(float(st['dim']), 1)
                if cur.get(k) != d:
                    n += 1
                    cur[k] = d
    return n


# temps unitaires (secondes) : (bas, haut) ; hauts resserres le 2026-11-23 00h35
# (3 h maxi sur le projet de Maxence au lieu de 3 h 40)
T_PANNEAU = (120.0, 180.0)      # recuperer un panneau et le poser sur la machine (2 a 3 min)
T_COUPE_LONGUE = (35.0, 45.0)   # coupe prioritaire sur toute la longueur du panneau
T_COUPE = (12.0, 16.0)          # coupe dans une bande ou un morceau
T_REGLAGE = (30.0, 45.0)        # changer la cote d'un guide et la verifier
T_MARQUER = (15.0, 22.0)        # ecrire bande k / Rn au crayon et poser le morceau de cote
T_PRENDRE = (10.0, 13.0)        # retrouver un morceau mis de cote
T_NOM = (8.0, 10.0)             # ecrire le nom d'une piece et la ranger


def estimation(doc):
    """Comptes et temps estime (bas, haut) en secondes pour couper le lot."""
    n_pan = n_long = n_coupe = n_mq = n_pr = n_nom = 0
    for g in doc['groups']:
        for s in g['sheets']:
            n_pan += 1
            n_nom += len(s['placements'])
            plan = s.get('plan') or []
            for st in plan:
                if st['kind'] == 'prim':
                    n_long += 1
                else:
                    n_coupe += 1
            gp = _grouper_etapes(plan)
            if not gp:
                continue
            sh = dict(s, plan=gp)
            sh['blocs'] = _blocs(sh)
            for si, st in enumerate(gp):
                mq, pr = _bandes_de_cote(sh, si)
                n_mq += len(mq)
                n_pr += len(pr)
                if st['kind'] != 'prim':
                    for b in _blocs_carte(sh, si):
                        if b['card'] == si:
                            n_mq += 1
                        else:
                            n_pr += 1
    n_reg = compter_reglages(doc['groups'])
    lignes = [(u'Manutention des panneaux', n_pan, T_PANNEAU),
              (u'Coupes sur toute la longueur', n_long, T_COUPE_LONGUE),
              (u'Autres coupes', n_coupe, T_COUPE),
              (u'Réglages de la scie', n_reg, T_REGLAGE),
              (u'Marquer et mettre de côté (bandes, R)', n_mq, T_MARQUER),
              (u'Reprendre les morceaux mis de côté', n_pr, T_PRENDRE),
              (u'Noter le nom des pièces', n_nom, T_NOM)]
    out = [(lab, n, n * t[0], n * t[1]) for lab, n, t in lignes if n]
    return out, n_reg


def _duree(sec):
    m = int(round(sec / 60.0))
    if m < 60:
        return u'%d min' % m
    return u'%d h %02d' % (m // 60, m % 60)


def _cover_page(doc):
    """Page de garde : nom du projet au milieu, infos pratiques, legende."""
    pg = _Page()
    L, W = float(doc['L']), float(doc['W'])
    cx = PAGE_W / 2.0
    # infos
    n_sh = sum(len(g['sheets']) for g in doc['groups'])
    n_pc = sum(len(s['placements']) for g in doc['groups'] for s in g['sheets'])
    rows = [(u'Format des panneaux', u'%s x %s mm' % (_fmt(L), _fmt(W))),
            (u'Marge', u'%s mm' % _fmt(float(doc.get('margin') or 0)))]
    for g in doc['groups']:
        rows.append((g['label'], u'%d panneau(x)  -  %d pièce(s)'
                     % (len(g['sheets']), sum(len(s['placements']) for s in g['sheets']))))
    if len(doc['groups']) > 1:
        rows.append((u'Total', u'%d panneau(x)  -  %d pièce(s)' % (n_sh, n_pc)))
    est = None
    if any(s.get('plan') for g in doc['groups'] for s in g['sheets']):
        # coupes a la scie a format : reglages compares au mode quantite et
        # temps de coupe estime (demande du 2026-11-23 00h25)
        est, n_reg = estimation(doc)
        ref = doc.get('ref_quantite') or {}
        if doc.get('tri') == 'quantite':
            rows.append((u'Réglages de la scie', u'%d  (mode quantité)' % n_reg))
        elif ref.get('reglages') is not None:
            dif = int(ref['reglages']) - n_reg
            if dif > 0:
                txt = u'%d  (mode quantité : %d, soit %d de moins)' % (n_reg, ref['reglages'], dif)
            elif dif < 0:
                txt = u'%d  (mode quantité : %d, soit %d de plus)' % (n_reg, ref['reglages'], -dif)
            else:
                txt = u'%d  (autant qu\'en mode quantité)' % n_reg
            rows.append((u'Réglages de la scie', txt))
            if ref.get('panneaux') is not None and int(ref['panneaux']) != n_sh:
                rows.append((u'Panneaux en mode quantité', u'%d' % int(ref['panneaux'])))
        else:
            rows.append((u'Réglages de la scie', u'%d' % n_reg))
    n_l = len(rows) + (1 if est else 0)
    # beaucoup de lignes : on remonte le haut de page
    dy = min(max(0, n_l - 6) * 6.5 * MM, PAGE_H * 0.20)
    title = doc.get('title', 'Calpinage')
    ts = min(34.0, (PAGE_W - 2 * MARGIN - 40 * MM) / max(1.0, _text_width(title, 1.0, True)))
    y = PAGE_H * 0.70 + dy
    pg.color((0, 0, 0))
    pg.text(cx, y, title, ts, True, 0, 'center')
    y -= 12 * MM
    pg.text(cx, y, u'Calpinage  -  %s' % doc.get('date', ''), 13, False, 0, 'center')
    pg.color((0.6, 0.6, 0.6), True)
    pg.width(0.6)
    pg.line(cx - 90 * MM, y - 6 * MM, cx + 90 * MM, y - 6 * MM)
    y -= 16 * MM
    for a, b in rows:
        bold = a == u'Total'
        pg.color((0, 0, 0))
        pg.text(cx - 4 * MM, y, a, 12, bold, 0, 'right')
        pg.text(cx + 4 * MM, y, b, 12, True)
        y -= 7.5 * MM
    if est:
        y -= 3 * MM
        lo, hi = sum(e[2] for e in est), sum(e[3] for e in est)
        pg.text(cx - 4 * MM, y, u'Temps de coupe estimé', 12, True, 0, 'right')
        pg.text(cx + 4 * MM, y, u'entre %s et %s' % (_duree(lo), _duree(hi)), 12, True)
        # sans le detail par poste (demande du 2026-11-23 00h35)
        y -= 7.5 * MM
    # legende des pages panneau
    poche, grav, cut = _doc_flags(doc)
    items = [('fill', GRIS_MATIERE, u'Matière : pièce à découper'),
             ('fill', (1, 1, 1), u'Vide : trou traversant, à évider')]
    if poche:
        items.append(('fill', GRIS_POCHE, u'Usinage non débouchant (profondeur indiquée)'))
    if grav:
        items.append(('line', BLEU_GRAVURE, u'Gravure (trait, sans découpe)'))
    if cut:
        items.append(('cut', VERT_COUPE, u'Coupe prioritaire n° (scie à format)'))
    y -= 8 * MM
    pg.color((0, 0, 0))
    pg.text(cx, y, u'Légende', 11, True, 0, 'center')
    y -= 8 * MM
    tot = sum(14 * MM + _text_width(t, 10) for _k, _c, t in items) + 8 * MM * (len(items) - 1)
    x = cx - tot / 2.0
    for kind, rgb, txt in items:
        if kind == 'fill':
            pg.color(rgb)
            pg.color((0, 0, 0), True)
            pg.width(0.6)
            pg.rect(x, y - 1.5 * MM, 9 * MM, 5 * MM, 'B')
        elif kind == 'cut':
            pg.color(rgb, True)
            pg.width(1.8)
            pg.dash(6, 3)
            pg.line(x, y + 1 * MM, x + 9 * MM, y + 1 * MM)
            pg.dash()
        else:
            pg.color(rgb, True)
            pg.width(1.2)
            pg.line(x, y + 1 * MM, x + 9 * MM, y + 1 * MM)
        pg.color((0, 0, 0))
        pg.text(x + 12 * MM, y, txt, 10)
        x += 14 * MM + _text_width(txt, 10) + 8 * MM
    y -= 14 * MM
    pg.color((0.35, 0.35, 0.35))
    pg.text(cx, y, u'Imprimer en A3 paysage à 100 %, sans ajustement. L\'échelle de chaque panneau est indiquée en bas de sa page.',
            9, False, 0, 'center')
    return pg


def build_pdf(doc):
    """doc : {'title', 'date', 'L', 'W', 'margin', 'groups': [{'label', 'th_mm',
    'sheets': [{'index', 'placements': [{'name', 'label', 'regions', 'depths',
    'grav', 'flip'}]}]}]} (mm). Renvoie les octets du PDF."""
    if not doc.get('date'):
        doc = dict(doc, date=datetime.date.today().strftime('%d/%m/%Y'))
    pages = [_cover_page(doc)]
    for g in doc['groups']:
        for s in g['sheets']:
            pages.append(_sheet_page(doc, g, s, len(g['sheets'])))
            if doc.get('ordre'):
                pages.extend(_ordre_pages(doc, g, s, len(g['sheets'])))
    objs = []   # contenu des objets 1..n

    def new(body):
        objs.append(body)
        return len(objs)

    f1 = new(b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>')
    f2 = new(b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>')
    pages_id = new(None)
    kids = []
    for pg in pages:
        data = zlib.compress(pg.data())
        c = new(b'<< /Length %d /Filter /FlateDecode >>\nstream\n' % len(data) + data + b'\nendstream')
        kids.append(new(('<< /Type /Page /Parent %d 0 R /MediaBox [0 0 %s %s] /Contents %d 0 R '
                         '/Resources << /Font << /F1 %d 0 R /F2 %d 0 R >> >> >>'
                         % (pages_id, _fmt(PAGE_W), _fmt(PAGE_H), c, f1, f2)).encode('latin-1')))
    objs[pages_id - 1] = ('<< /Type /Pages /Kids [%s] /Count %d >>'
                          % (' '.join('%d 0 R' % i for i in kids), len(kids))).encode('latin-1')
    info = new(b'<< /Title (' + _txt(doc.get('title', 'Calpinage')) + b') /Producer (Toolkit CNC - Calpinage CNC) >>')
    catalog = new(('<< /Type /Catalog /Pages %d 0 R >>' % pages_id).encode('latin-1'))
    out = bytearray(b'%PDF-1.4\n%\xe2\xe3\xcf\xd3\n')
    offs = []
    for i, body in enumerate(objs):
        offs.append(len(out))
        out += b'%d 0 obj\n' % (i + 1) + body + b'\nendobj\n'
    xref = len(out)
    out += b'xref\n0 %d\n0000000000 65535 f \n' % (len(objs) + 1)
    for o in offs:
        out += b'%010d 00000 n \n' % o
    out += (b'trailer\n<< /Size %d /Root %d 0 R /Info %d 0 R >>\nstartxref\n%d\n%%EOF\n'
            % (len(objs) + 1, catalog, info, xref))
    return bytes(out), len(pages)


def write_pdf(path, doc):
    data, n = build_pdf(doc)
    with open(path, 'wb') as f:
        f.write(data)
    return n
