# ---------------------------------------------------------------------------
# Calpinage CNC : export PDF du calpinage (une page A3 paysage par panneau).
#
# Pour un partenaire qui ne connait pas le modele : panneau a l'echelle
# (1:N indique + barre d'echelle), cotes du panneau, pieces en gris (matiere),
# vides (trous traversants) en blanc, fonds d'usinages non debouchants en gris
# fonce avec leur profondeur, gravures en bleu (sans nom de piece).
#
# PDF ecrit a la main (aucune dependance) : utilisable dans Fusion et testable
# hors Fusion. Coordonnees d'entree en mm, repere du panneau (origine en bas a
# gauche, x le long de la longueur L, y le long de la largeur W).
# ---------------------------------------------------------------------------

import datetime
import math
import zlib

try:
    import cnc_i18n as _i18n   # langue FR/EN de CNC Toolkit (textes du PDF)
except Exception:
    _i18n = None

MM = 72.0 / 25.4                       # points par mm
PAGE_W, PAGE_H = 420 * MM, 297 * MM    # A3 paysage
MARGIN = 12 * MM
TITLE_H = 30 * MM                      # cartouche en bas de page
SCALES = (1, 2, 5, 10, 15, 20, 25, 50, 100, 200)

GRIS_MATIERE = (0.80, 0.80, 0.80)
GRIS_POCHE = (0.55, 0.55, 0.55)
BLEU_GRAVURE = (0.0, 0.35, 0.85)


def _txt(s):
    """Chaine PDF (WinAnsi) : accents conserves, caracteres speciaux echappes."""
    b = str(s).encode('cp1252', 'replace')
    return b.replace(b'\\', b'\\\\').replace(b'(', b'\\(').replace(b')', b'\\)')


def _fmt(v):
    s = ('%.2f' % v).rstrip('0').rstrip('.')
    return s if s not in ('', '-0') else '0'


def _ring_area(ring):
    a = 0.0
    for i in range(len(ring)):
        x1, y1 = ring[i]
        x2, y2 = ring[(i + 1) % len(ring)]
        a += x1 * y2 - x2 * y1
    return a / 2.0


def _inside(rings, x, y):
    """Point dans la region (regle pair-impair : les trous sont exclus)."""
    c = False
    for ring in rings:
        n = len(ring)
        for i in range(n):
            x1, y1 = ring[i]
            x2, y2 = ring[(i + 1) % n]
            if (y1 > y) != (y2 > y) and x < (x2 - x1) * (y - y1) / ((y2 - y1) or 1e-12) + x1:
                c = not c
    return c


def _label_point(rings):
    """Point interieur a la matiere pour poser le nom de la piece."""
    xs = [p[0] for p in rings[0]]
    ys = [p[1] for p in rings[0]]
    x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    if _inside(rings, cx, cy):
        return cx, cy
    best, bd = None, -1.0
    for i in range(1, 12):
        for j in range(1, 12):
            x, y = x0 + (x1 - x0) * i / 12.0, y0 + (y1 - y0) * j / 12.0
            if _inside(rings, x, y):
                d = -((x - cx) ** 2 + (y - cy) ** 2)
                if best is None or d > bd:
                    best, bd = (x, y), d
    return best or (cx, cy)


class _Page(object):
    def __init__(self):
        self.ops = []

    def add(self, s):
        self.ops.append(s)

    def color(self, rgb, stroke=False):
        self.add('%s %s %s %s' % (_fmt(rgb[0]), _fmt(rgb[1]), _fmt(rgb[2]), 'RG' if stroke else 'rg'))

    def width(self, w):
        self.add('%s w' % _fmt(w))

    def dash(self, on=None, off=None):
        self.add('[%s %s] 0 d' % (_fmt(on), _fmt(off)) if on else '[] 0 d')

    def line(self, x1, y1, x2, y2):
        self.add('%s %s m %s %s l S' % (_fmt(x1), _fmt(y1), _fmt(x2), _fmt(y2)))

    def rect(self, x, y, w, h, op='S'):
        self.add('%s %s %s %s re %s' % (_fmt(x), _fmt(y), _fmt(w), _fmt(h), op))

    def path(self, rings, op):
        for ring in rings:
            if len(ring) < 2:
                continue
            self.add('%s %s m' % (_fmt(ring[0][0]), _fmt(ring[0][1])))
            self.add(' '.join('%s %s l' % (_fmt(x), _fmt(y)) for x, y in ring[1:]))
            self.add('h')
        self.add(op)

    def text(self, x, y, s, size=9, bold=False, angle=0.0, align='left'):
        if _i18n is not None:
            s = _i18n.t(s)
        w = _text_width(s, size, bold)
        dx = {'left': 0.0, 'center': -w / 2.0, 'right': -w}[align]
        a = math.radians(angle)
        c, sn = math.cos(a), math.sin(a)
        tx, ty = x + c * dx, y + sn * dx
        self.add('BT /%s %s Tf %s %s %s %s %s %s Tm (' % ('F2' if bold else 'F1', _fmt(size), _fmt(c), _fmt(sn),
                                                         _fmt(-sn), _fmt(c), _fmt(tx), _fmt(ty))
                 + _txt(s).decode('latin-1') + ') Tj ET')

    def data(self):
        return '\n'.join(self.ops).encode('latin-1')


def _text_width(s, size, bold=False):
    # largeur approximative Helvetica (moyenne) : suffit pour centrer
    return len(str(s)) * size * (0.56 if bold else 0.52)


def _arrow(pg, x, y, dx, dy, size):
    n = math.hypot(dx, dy) or 1.0
    ux, uy = dx / n, dy / n
    px, py = -uy, ux
    pts = [(x, y), (x - ux * size + px * size * 0.35, y - uy * size + py * size * 0.35),
           (x - ux * size - px * size * 0.35, y - uy * size - py * size * 0.35)]
    pg.path([pts], 'f')


def _cote(pg, x1, y1, x2, y2, label, off_dir, off):
    """Cote entre deux points, decalee de off (en points) dans off_dir."""
    ox, oy = off_dir[0] * off, off_dir[1] * off
    a1, b1, a2, b2 = x1 + ox, y1 + oy, x2 + ox, y2 + oy
    pg.color((0, 0, 0), True)
    pg.width(0.4)
    pg.line(x1 + off_dir[0] * 2, y1 + off_dir[1] * 2, a1 + off_dir[0] * 3, b1 + off_dir[1] * 3)
    pg.line(x2 + off_dir[0] * 2, y2 + off_dir[1] * 2, a2 + off_dir[0] * 3, b2 + off_dir[1] * 3)
    pg.line(a1, b1, a2, b2)
    pg.color((0, 0, 0))
    _arrow(pg, a1, b1, a1 - a2, b1 - b2, 5)
    _arrow(pg, a2, b2, a2 - a1, b2 - b1, 5)
    ang = math.degrees(math.atan2(b2 - b1, a2 - a1))
    mx, my = (a1 + a2) / 2 + off_dir[0] * 3, (b1 + b2) / 2 + off_dir[1] * 3
    if off_dir[0] < 0:
        mx -= 2
    pg.text(mx, my, label, 9, True, ang, 'center')


def _scale_for(L, W, aw, ah):
    for s in SCALES:
        if L / s * MM <= aw and W / s * MM <= ah:
            return s
    return max(L * MM / aw, W * MM / ah)


def _sheet_page(doc, grp, sheet, n_sheets):
    pg = _Page()
    show_names = bool(doc.get('noms', False))   # noms des pieces : non (demande de Maxence)
    L, W = float(doc['L']), float(doc['W'])
    aw = PAGE_W - 2 * MARGIN - 14 * MM
    ah = PAGE_H - 2 * MARGIN - TITLE_H - 12 * MM
    scale = _scale_for(L, W, aw, ah)
    k = MM / scale
    ox = MARGIN + 14 * MM + (aw - L * k) / 2
    oy = MARGIN + TITLE_H + 4 * MM + (ah - W * k) / 2

    def P(x, y):
        return (ox + x * k, oy + y * k)

    def R(ring):
        return [P(x, y) for x, y in ring]

    # brut du panneau
    pg.color((1, 1, 1))
    pg.color((0, 0, 0), True)
    pg.width(1.0)
    pg.rect(ox, oy, L * k, W * k, 'B')
    m = float(doc.get('margin') or 0)
    if m > 0:
        pg.color((0.6, 0.6, 0.6), True)
        pg.width(0.3)
        pg.dash(3, 3)
        pg.rect(ox + m * k, oy + m * k, (L - 2 * m) * k, (W - 2 * m) * k)
        pg.dash()

    labels = []
    has_pocket = has_grav = False
    for pl in sheet['placements']:
        regs = pl.get('regions') or []
        depths = pl.get('depths') or [0.0] * len(regs)
        order = sorted(range(len(regs)), key=lambda i: depths[i] if i < len(depths) else 0.0)
        main = None
        for i in order:
            reg = regs[i]
            if not reg:
                continue
            d = depths[i] if i < len(depths) else 0.0
            poche = d > 0.05
            has_pocket = has_pocket or poche
            pg.color(GRIS_POCHE if poche else GRIS_MATIERE)
            pg.color((0, 0, 0), True)
            pg.width(0.5 if poche else 0.8)
            pg.path([R(r) for r in reg], 'B*')
            if poche:
                lx, ly = _label_point(reg)
                labels.append((P(lx, ly), 'prof. %s mm' % _fmt(d), 5.5, False, 0.0))
            elif main is None or abs(_ring_area(reg[0])) > abs(_ring_area(main[0])):
                main = reg
        g = pl.get('grav') or []
        if g:
            has_grav = True
            pg.color(BLEU_GRAVURE, True)
            pg.width(0.6)
            for a, b in g:
                pa, pb = P(a[0], a[1]), P(b[0], b[1])
                pg.line(pa[0], pa[1], pb[0], pb[1])
        if main is not None and show_names:
            lx, ly = _label_point(main)
            name = pl.get('label') or pl.get('name', '')
            xs = [q[0] for q in main[0]]
            ys = [q[1] for q in main[0]]
            bw, bh = (max(xs) - min(xs)) * k, (max(ys) - min(ys)) * k
            # piece haute et etroite : nom ecrit dans sa longueur
            ang = 90.0 if bh > bw * 1.3 else 0.0
            room = (bh if ang else bw) * 0.9
            size = max(3.5, min(7.0, room / max(1, len(name)) / 0.56))
            labels.append((P(lx, ly), name, size, True, ang))
    pg.color((0, 0, 0))
    for (x, y), s, size, bold, ang in labels:
        a = math.radians(ang)
        # centrage vertical du texte (decalage perpendiculaire a la ligne)
        pg.text(x + math.sin(a) * size / 3.0, y - math.cos(a) * size / 3.0, s, size, bold, ang, 'center')

    # cotes du panneau
    _cote(pg, ox, oy + W * k, ox + L * k, oy + W * k, '%s mm' % _fmt(L), (0, 1), 8 * MM)
    _cote(pg, ox, oy, ox, oy + W * k, '%s mm' % _fmt(W), (-1, 0), 8 * MM)

    # cartouche
    tx, ty = MARGIN, MARGIN
    tw = PAGE_W - 2 * MARGIN
    pg.color((0, 0, 0), True)
    pg.width(0.8)
    pg.rect(tx, ty, tw, TITLE_H)
    pg.width(0.4)
    pg.line(tx + tw * 0.45, ty, tx + tw * 0.45, ty + TITLE_H)
    pg.color((0, 0, 0))
    pg.text(tx + 4 * MM, ty + TITLE_H - 8 * MM, doc.get('title', 'Calpinage'), 13, True)
    pg.text(tx + 4 * MM, ty + TITLE_H - 15 * MM,
            'Panneau %d sur %d  -  %s' % (sheet['index'], n_sheets, grp['label']), 10)
    pg.text(tx + 4 * MM, ty + TITLE_H - 21 * MM,
            'Format %s x %s mm  -  %d pièce(s)  -  vue de dessus (face usinée visible)' % (_fmt(L), _fmt(W), len(sheet['placements'])), 9)
    sc = ('1:%s' % _fmt(scale)) if isinstance(scale, (int, float)) and scale in SCALES else ('1:%.1f' % scale)
    pg.text(tx + 4 * MM, ty + 4 * MM, 'Échelle %s sur A3 (imprimer à 100 %%, sans ajustement)  -  %s'
            % (sc, doc.get('date', '')), 8)

    # legende
    lx = tx + tw * 0.45 + 5 * MM
    ly = ty + TITLE_H - 9 * MM
    items = [('fill', GRIS_MATIERE, 'Matière : pièce à découper'),
             ('fill', (1, 1, 1), 'Vide : trou traversant, à évider')]
    if has_pocket:
        items.append(('fill', GRIS_POCHE, 'Usinage non débouchant (profondeur indiquée)'))
    if has_grav:
        items.append(('line', BLEU_GRAVURE, 'Gravure (trait, sans découpe)'))
    col_w = (tw * 0.55 - 10 * MM) / 2
    for i, (kind, rgb, txt) in enumerate(items):
        x = lx + (i // 2) * col_w
        y = ly - (i % 2) * 8 * MM
        if kind == 'fill':
            pg.color(rgb)
            pg.color((0, 0, 0), True)
            pg.width(0.6)
            pg.rect(x, y - 1.5 * MM, 8 * MM, 4.5 * MM, 'B')
        else:
            pg.color(rgb, True)
            pg.width(1.2)
            pg.line(x, y + 0.7 * MM, x + 8 * MM, y + 0.7 * MM)
        pg.color((0, 0, 0))
        pg.text(x + 11 * MM, y, txt, 8.5)

    # barre d'echelle (controle de l'impression)
    if isinstance(scale, (int, float)):
        step = 100.0 if scale <= 10 else 500.0
        n = 5
        bx, by = lx, ty + 4 * MM
        for i in range(n):
            pg.color((0, 0, 0) if i % 2 == 0 else (1, 1, 1))
            pg.color((0, 0, 0), True)
            pg.width(0.4)
            pg.rect(bx + i * step * k, by, step * k, 1.6 * MM, 'B')
        pg.color((0, 0, 0))
        for i in range(n + 1):
            pg.text(bx + i * step * k, by + 2.6 * MM, _fmt(i * step), 6, False, 0, 'center')
        pg.text(bx + n * step * k + 3 * MM, by, 'mm', 7)
    return pg


def build_pdf(doc):
    """doc : {'title', 'date', 'L', 'W', 'margin', 'groups': [{'label', 'th_mm',
    'sheets': [{'index', 'placements': [{'name', 'label', 'regions', 'depths',
    'grav', 'flip'}]}]}]} (mm). Renvoie les octets du PDF."""
    if not doc.get('date'):
        doc = dict(doc, date=datetime.date.today().strftime('%d/%m/%Y'))
    pages = []
    for g in doc['groups']:
        for s in g['sheets']:
            pages.append(_sheet_page(doc, g, s, len(g['sheets'])))
    objs = []   # contenu des objets 1..n

    def new(body):
        objs.append(body)
        return len(objs)

    f1 = new(b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>')
    f2 = new(b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>')
    pages_id = new(None)
    kids = []
    for pg in pages:
        data = zlib.compress(pg.data())
        c = new(b'<< /Length %d /Filter /FlateDecode >>\nstream\n' % len(data) + data + b'\nendstream')
        kids.append(new(('<< /Type /Page /Parent %d 0 R /MediaBox [0 0 %s %s] /Contents %d 0 R '
                         '/Resources << /Font << /F1 %d 0 R /F2 %d 0 R >> >> >>'
                         % (pages_id, _fmt(PAGE_W), _fmt(PAGE_H), c, f1, f2)).encode('latin-1')))
    objs[pages_id - 1] = ('<< /Type /Pages /Kids [%s] /Count %d >>'
                          % (' '.join('%d 0 R' % i for i in kids), len(kids))).encode('latin-1')
    info = new(b'<< /Title (' + _txt(doc.get('title', 'Calpinage')) + b') /Producer (Toolkit CNC - Calpinage CNC) >>')
    catalog = new(('<< /Type /Catalog /Pages %d 0 R >>' % pages_id).encode('latin-1'))
    out = bytearray(b'%PDF-1.4\n%\xe2\xe3\xcf\xd3\n')
    offs = []
    for i, body in enumerate(objs):
        offs.append(len(out))
        out += b'%d 0 obj\n' % (i + 1) + body + b'\nendobj\n'
    xref = len(out)
    out += b'xref\n0 %d\n0000000000 65535 f \n' % (len(objs) + 1)
    for o in offs:
        out += b'%010d 00000 n \n' % o
    out += (b'trailer\n<< /Size %d /Root %d 0 R /Info %d 0 R >>\nstartxref\n%d\n%%EOF\n'
            % (len(objs) + 1, catalog, info, xref))
    return bytes(out), len(pages)


def write_pdf(path, doc):
    data, n = build_pdf(doc)
    with open(path, 'wb') as f:
        f.write(data)
    return n
