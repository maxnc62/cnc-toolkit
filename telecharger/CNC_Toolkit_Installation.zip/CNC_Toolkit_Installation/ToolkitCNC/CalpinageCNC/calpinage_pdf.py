# ---------------------------------------------------------------------------
# Calpinage CNC : export PDF du calpinage (une page A3 paysage par panneau).
#
# Pour un partenaire qui ne connait pas le modele : panneau a l'echelle
# (1:N indique + barre d'echelle), cotes du panneau, pieces en gris (matiere),
# vides (trous traversants) en blanc, fonds d'usinages non debouchants en gris
# fonce avec leur profondeur, gravures en bleu (sans nom de piece).
#
# PDF ecrit a la main (aucune dependance) : utilisable dans Fusion et testable
# hors Fusion. Coordonnees d'entree en mm, repere du panneau (origine en bas a
# gauche, x le long de la longueur L, y le long de la largeur W).
# ---------------------------------------------------------------------------

import datetime
import math
import re
import zlib

try:
    import cnc_i18n as _i18n   # langue FR/EN de CNC Toolkit (textes du PDF)
except Exception:
    _i18n = None

MM = 72.0 / 25.4                       # points par mm
PAGE_W, PAGE_H = 420 * MM, 297 * MM    # A3 paysage
MARGIN = 12 * MM
TITLE_H = 7 * MM                       # ligne d'infos en bas de page (cartouche -> page de garde, 2026-11-19)
SCALES = (1, 2, 5, 10, 15, 20, 25, 50, 100, 200)

GRIS_MATIERE = (0.90, 0.90, 0.90)   # eclairci (demande du 2026-11-19)
GRIS_POCHE = (0.70, 0.70, 0.70)
BLEU_GRAVURE = (0.0, 0.35, 0.85)
VERT_COUPE = (0.0, 0.62, 0.32)       # coupes prioritaires (scie a format)


def _txt(s):
    """Chaine PDF (WinAnsi) : accents conserves, caracteres speciaux echappes."""
    b = str(s).encode('cp1252', 'replace')
    return b.replace(b'\\', b'\\\\').replace(b'(', b'\\(').replace(b')', b'\\)')


def _fmt(v):
    s = ('%.2f' % v).rstrip('0').rstrip('.')
    return s if s not in ('', '-0') else '0'


def _mm(v):
    """Cote en mm, au dixieme (sans zeros inutiles)."""
    s = ('%.1f' % v).rstrip('0').rstrip('.')
    return s if s not in ('', '-0') else '0'


def _ring_area(ring):
    a = 0.0
    for i in range(len(ring)):
        x1, y1 = ring[i]
        x2, y2 = ring[(i + 1) % len(ring)]
        a += x1 * y2 - x2 * y1
    return a / 2.0


def _inside(rings, x, y):
    """Point dans la region (regle pair-impair : les trous sont exclus)."""
    c = False
    for ring in rings:
        n = len(ring)
        for i in range(n):
            x1, y1 = ring[i]
            x2, y2 = ring[(i + 1) % n]
            if (y1 > y) != (y2 > y) and x < (x2 - x1) * (y - y1) / ((y2 - y1) or 1e-12) + x1:
                c = not c
    return c


def _label_point(rings):
    """Point interieur a la matiere pour poser le nom de la piece."""
    xs = [p[0] for p in rings[0]]
    ys = [p[1] for p in rings[0]]
    x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    if _inside(rings, cx, cy):
        return cx, cy
    best, bd = None, -1.0
    for i in range(1, 12):
        for j in range(1, 12):
            x, y = x0 + (x1 - x0) * i / 12.0, y0 + (y1 - y0) * j / 12.0
            if _inside(rings, x, y):
                d = -((x - cx) ** 2 + (y - cy) ** 2)
                if best is None or d > bd:
                    best, bd = (x, y), d
    return best or (cx, cy)


class _Page(object):
    def __init__(self):
        self.ops = []

    def add(self, s):
        self.ops.append(s)

    def color(self, rgb, stroke=False):
        self.add('%s %s %s %s' % (_fmt(rgb[0]), _fmt(rgb[1]), _fmt(rgb[2]), 'RG' if stroke else 'rg'))

    def width(self, w):
        self.add('%s w' % _fmt(w))

    def dash(self, on=None, off=None):
        self.add('[%s %s] 0 d' % (_fmt(on), _fmt(off)) if on else '[] 0 d')

    def line(self, x1, y1, x2, y2):
        self.add('%s %s m %s %s l S' % (_fmt(x1), _fmt(y1), _fmt(x2), _fmt(y2)))

    def rect(self, x, y, w, h, op='S'):
        self.add('%s %s %s %s re %s' % (_fmt(x), _fmt(y), _fmt(w), _fmt(h), op))

    def path(self, rings, op):
        for ring in rings:
            if len(ring) < 2:
                continue
            self.add('%s %s m' % (_fmt(ring[0][0]), _fmt(ring[0][1])))
            self.add(' '.join('%s %s l' % (_fmt(x), _fmt(y)) for x, y in ring[1:]))
            self.add('h')
        self.add(op)

    def text(self, x, y, s, size=9, bold=False, angle=0.0, align='left'):
        if _i18n is not None:
            s = _i18n.t(s)
        w = _text_width(s, size, bold)
        dx = {'left': 0.0, 'center': -w / 2.0, 'right': -w}[align]
        a = math.radians(angle)
        c, sn = math.cos(a), math.sin(a)
        tx, ty = x + c * dx, y + sn * dx
        self.add('BT /%s %s Tf %s %s %s %s %s %s Tm (' % ('F2' if bold else 'F1', _fmt(size), _fmt(c), _fmt(sn),
                                                         _fmt(-sn), _fmt(c), _fmt(tx), _fmt(ty))
                 + _txt(s).decode('latin-1') + ') Tj ET')

    def data(self):
        return '\n'.join(self.ops).encode('latin-1')


def _text_width(s, size, bold=False):
    # largeur approximative Helvetica (moyenne) : suffit pour centrer
    return len(str(s)) * size * (0.56 if bold else 0.52)


def _arrow(pg, x, y, dx, dy, size):
    n = math.hypot(dx, dy) or 1.0
    ux, uy = dx / n, dy / n
    px, py = -uy, ux
    pts = [(x, y), (x - ux * size + px * size * 0.35, y - uy * size + py * size * 0.35),
           (x - ux * size - px * size * 0.35, y - uy * size - py * size * 0.35)]
    pg.path([pts], 'f')


def _cote(pg, x1, y1, x2, y2, label, off_dir, off):
    """Cote entre deux points, decalee de off (en points) dans off_dir."""
    ox, oy = off_dir[0] * off, off_dir[1] * off
    a1, b1, a2, b2 = x1 + ox, y1 + oy, x2 + ox, y2 + oy
    pg.color((0, 0, 0), True)
    pg.width(0.4)
    pg.line(x1 + off_dir[0] * 2, y1 + off_dir[1] * 2, a1 + off_dir[0] * 3, b1 + off_dir[1] * 3)
    pg.line(x2 + off_dir[0] * 2, y2 + off_dir[1] * 2, a2 + off_dir[0] * 3, b2 + off_dir[1] * 3)
    pg.line(a1, b1, a2, b2)
    pg.color((0, 0, 0))
    _arrow(pg, a1, b1, a1 - a2, b1 - b2, 5)
    _arrow(pg, a2, b2, a2 - a1, b2 - b1, 5)
    ang = math.degrees(math.atan2(b2 - b1, a2 - a1))
    mx, my = (a1 + a2) / 2 + off_dir[0] * 3, (b1 + b2) / 2 + off_dir[1] * 3
    if off_dir[0] < 0:
        mx -= 2
    pg.text(mx, my, label, 9, True, ang, 'center')


def _cote_bande(pg, P, L, a, b, horiz):
    """Cote d'une bande (a -> b, mm) : a droite du panneau si horiz, sinon
    dessous ; texte horizontal, hors du trait de cote."""
    off = 6 * MM
    size = 11
    pg.color((0, 0, 0), True)
    pg.color((0, 0, 0))
    pg.width(0.4)
    if horiz:
        p1, p2 = P(L, a), P(L, b)
        x = p1[0] + off
        pg.line(p1[0] + 1, p1[1], x + 2, p1[1])
        pg.line(p2[0] + 1, p2[1], x + 2, p2[1])
        pg.line(x, p1[1], x, p2[1])
        ar = min(4.0, abs(p2[1] - p1[1]) / 3.0)
        _arrow(pg, x, p1[1], 0, p1[1] - p2[1], ar)
        _arrow(pg, x, p2[1], 0, p2[1] - p1[1], ar)
        pg.text(x + 2.5, (p1[1] + p2[1]) / 2.0 - size / 3.0, _mm(b - a), size, True)
    else:
        p1, p2 = P(a, 0), P(b, 0)
        y = p1[1] - off
        pg.line(p1[0], p1[1] - 1, p1[0], y - 2)
        pg.line(p2[0], p2[1] - 1, p2[0], y - 2)
        pg.line(p1[0], y, p2[0], y)
        ar = min(4.0, abs(p2[0] - p1[0]) / 3.0)
        _arrow(pg, p1[0], y, p1[0] - p2[0], 0, ar)
        _arrow(pg, p2[0], y, p2[0] - p1[0], 0, ar)
        pg.text((p1[0] + p2[0]) / 2.0, y - 2.5 - size * 0.72, _mm(b - a), size, True, 0, 'center')


def _scale_for(L, W, aw, ah):
    for s in SCALES:
        if L / s * MM <= aw and W / s * MM <= ah:
            return s
    return max(L * MM / aw, W * MM / ah)


# --- Fiche de debit (sous le panneau) ---------------------------------------------

FICHE_ROW = 4.6 * MM
FICHE_HEAD = 11 * MM            # titre + ligne d'en-tete
FICHE_COLS = ((u'Pièce', 92), (u'Qté', 14), ('Longueur (mm)', 26), ('Largeur (mm)', 26), (u'Épaisseur (mm)', 26))
FICHE_BLOCK_W = sum(w for _n, w in FICHE_COLS) * MM
FICHE_MAX = 24                  # lignes par colonne de la fiche


def _bbox_pl(pl):
    pts = [q for reg in (pl.get('regions') or []) if reg for q in reg[0]]
    if not pts:
        return None
    xs = [q[0] for q in pts]
    ys = [q[1] for q in pts]
    return min(xs), min(ys), max(xs), max(ys)


def _base_name(pl):
    # sans « - ex N » ni les numeros de copie Fusion « (1) », « (10) (4) »...
    # (demande du 2026-11-19 : retirer les chiffres entre parentheses partout)
    n = re.sub(r' - ex \d+$', '', pl.get('label') or pl.get('name', ''))
    n = re.sub(r'\s*\(\d+\)', '', n).strip()
    return n or (pl.get('name') or '')


_REP = {}      # nom de piece -> lettre repere, pour la carte en cours seulement


def _lettre(k):
    out = ''
    k += 1
    while k:
        k, r = divmod(k - 1, 26)
        out = chr(65 + r) + out
    return out


def _set_reperes(doc):
    """Lettre repere par piece (demande du 2026-11-19, 21h09 : retrouver les
    pieces de la liste sur la vignette)."""
    _REP.clear()
    for g in doc['groups']:
        for s in g['sheets']:
            for pl in s['placements']:
                n = _base_name(pl)
                if n not in _REP:
                    _REP[n] = _lettre(len(_REP))


def _rep(pl):
    return _REP.get(_base_name(pl), '')


def _fiche_rows(grp, sheet):
    """Pieces du panneau regroupees : [(nom, qte, longueur, largeur, epaisseur)]."""
    rows = {}
    for pl in sheet['placements']:
        bb = _bbox_pl(pl)
        if bb is None:
            continue
        dw, dh = bb[2] - bb[0], bb[3] - bb[1]
        key = (_base_name(pl), _mm(max(dw, dh)), _mm(min(dw, dh)))
        rows[key] = rows.get(key, 0) + 1
    out = [(n, q, a, b, _mm(float(grp.get('th_mm') or 0))) for (n, a, b), q in rows.items()]
    out.sort(key=lambda r: (-float(r[2]), -float(r[3]), r[0]))
    return out


def _fiche_layout(rows):
    """(colonnes, lignes par colonne, hauteur en points) de la fiche."""
    if not rows:
        return 0, 0, 0.0
    n_blk = 1 if len(rows) <= 12 else 2
    per = min(FICHE_MAX, int(math.ceil(len(rows) / float(n_blk))))
    return n_blk, per, FICHE_HEAD + per * FICHE_ROW + 2 * MM


def _draw_fiche(pg, rows, x, y_top, n_blk, per, title):
    pg.color((0, 0, 0))
    pg.text(x, y_top - 4 * MM, title, 9, True)
    shown = rows[:n_blk * per]
    for b in range(n_blk):
        bx = x + b * (FICHE_BLOCK_W + 8 * MM)
        part = shown[b * per:(b + 1) * per]
        if not part:
            break
        yh = y_top - FICHE_HEAD
        pg.color((0.9, 0.9, 0.9))
        pg.rect(bx, yh, FICHE_BLOCK_W, FICHE_ROW, 'f')
        cx = bx
        pg.color((0, 0, 0))
        for name, w in FICHE_COLS:
            pg.text(cx + 1.5 * MM, yh + 1.4 * MM, name, 7, True)
            cx += w * MM
        for i, r in enumerate(part):
            yr = yh - (i + 1) * FICHE_ROW
            if i % 2:
                pg.color((0.965, 0.965, 0.965))
                pg.rect(bx, yr, FICHE_BLOCK_W, FICHE_ROW, 'f')
            pg.color((0, 0, 0))
            cx = bx
            for j, (name, w) in enumerate(FICHE_COLS):
                v = str(r[j])
                if j == 0:
                    n_max = int(w * MM / (7 * 0.52)) - 1
                    if len(v) > n_max:
                        v = v[:n_max - 1] + '.'
                    pg.text(cx + 1.5 * MM, yr + 1.4 * MM, v, 7)
                else:
                    pg.text(cx + w * MM - 2 * MM, yr + 1.4 * MM, v, 7, j == 1, 0, 'right')
                cx += w * MM
        pg.color((0, 0, 0), True)
        pg.width(0.4)
        pg.rect(bx, yh - len(part) * FICHE_ROW, FICHE_BLOCK_W, (len(part) + 1) * FICHE_ROW)
    if len(rows) > len(shown):
        pg.text(x, y_top - FICHE_HEAD - per * FICHE_ROW - 4 * MM,
                '... %d ligne(s) de plus' % (len(rows) - len(shown)), 7)


def _sheet_page(doc, grp, sheet, n_sheets):
    pg = _Page()
    show_names = bool(doc.get('noms', False))   # noms des pieces (demande de l'utilisateur, 2026-11-19)
    L, W = float(doc['L']), float(doc['W'])
    f_rows = _fiche_rows(grp, sheet) if doc.get('fiche') else []
    n_blk, per, tab_h = _fiche_layout(f_rows)
    tab_sp = (tab_h + 12 * MM) if tab_h else 0.0   # fiche + place des cotes sous le panneau
    # panneau le plus grand possible (demande du 2026-11-19 : trop de vide,
    # ecritures plus lisibles) : echelle libre au lieu des echelles normalisees,
    # en gardant la place des cotes (gauche, haut, droite = bandes, bas)
    aw = PAGE_W - 2 * MARGIN - 14 * MM - 24 * MM
    ah = PAGE_H - 2 * MARGIN - TITLE_H - 12 * MM - 12 * MM - (tab_sp if tab_sp else 10 * MM)
    scale = max(L * MM / aw, W * MM / ah)
    scale = math.ceil(scale * 10.0 - 1e-9) / 10.0
    k = MM / scale
    ox = MARGIN + 14 * MM + (aw - L * k) / 2
    oy = MARGIN + TITLE_H + 4 * MM + (tab_sp if tab_sp else 10 * MM) + (ah - W * k) / 2
    if tab_h:
        _draw_fiche(pg, f_rows, MARGIN, MARGIN + TITLE_H + 4 * MM + tab_h, n_blk, per,
                    u'Fiche de débit  -  panneau %d' % sheet['index'])

    def P(x, y):
        return (ox + x * k, oy + y * k)

    def R(ring):
        return [P(x, y) for x, y in ring]

    # brut du panneau
    pg.color((1, 1, 1))
    pg.color((0, 0, 0), True)
    pg.width(1.0)
    pg.rect(ox, oy, L * k, W * k, 'B')
    m = float(doc.get('margin') or 0)
    if m > 0:
        pg.color((0.6, 0.6, 0.6), True)
        pg.width(0.3)
        pg.dash(3, 3)
        pg.rect(ox + m * k, oy + m * k, (L - 2 * m) * k, (W - 2 * m) * k)
        pg.dash()

    labels = []
    has_pocket = has_grav = False
    for pl in sheet['placements']:
        regs = pl.get('regions') or []
        depths = pl.get('depths') or [0.0] * len(regs)
        order = sorted(range(len(regs)), key=lambda i: depths[i] if i < len(depths) else 0.0)
        main = None
        for i in order:
            reg = regs[i]
            if not reg:
                continue
            d = depths[i] if i < len(depths) else 0.0
            poche = d > 0.05
            has_pocket = has_pocket or poche
            pg.color(GRIS_POCHE if poche else GRIS_MATIERE)
            pg.color((0, 0, 0), True)
            pg.width(0.5 if poche else 0.8)
            pg.path([R(r) for r in reg], 'B*')
            if poche:
                lx, ly = _label_point(reg)
                labels.append((P(lx, ly), 'prof. %s mm' % _fmt(d), 5.5, False, 0.0))
            elif main is None or abs(_ring_area(reg[0])) > abs(_ring_area(main[0])):
                main = reg
        g = pl.get('grav') or []
        if g:
            has_grav = True
            pg.color(BLEU_GRAVURE, True)
            pg.width(0.6)
            for a, b in g:
                pa, pb = P(a[0], a[1]), P(b[0], b[1])
                pg.line(pa[0], pa[1], pb[0], pb[1])
        # cotes de la piece (boite englobante, mm) : dimension horizontale en
        # haut, dimension verticale a droite (texte dans le sens de l'arete),
        # nom du composant / corps au milieu
        outer = [r[0] for r in regs if r]
        if outer:
            xs = [q[0] for r in outer for q in r]
            ys = [q[1] for r in outer for q in r]
            x0, y0, x1, y1 = min(xs), min(ys), max(xs), max(ys)
            wpt, hpt = (x1 - x0) * k, (y1 - y0) * k
            pad = 1.6
            t_w, t_h = _mm(x1 - x0), _mm(y1 - y0)
            ds = min(15.0, wpt * 0.3, hpt * 0.3)
            ds = min(ds, (wpt - 2 * pad) / (len(t_w) * 0.56), (hpt - 2 * pad) / (len(t_h) * 0.56))
            room = 0.0
            if ds >= 3.0:
                pt = P((x0 + x1) / 2.0, y1)
                labels.append(((pt[0], pt[1] - pad - ds / 2.0), t_w, ds, True, 0.0))
                pr = P(x1, (y0 + y1) / 2.0)
                labels.append(((pr[0] - pad - ds / 2.0, pr[1]), t_h, ds, True, 90.0))
                room = ds + 2 * pad
            if show_names:
                if main is not None:
                    lx, ly = _label_point(main)
                else:
                    lx, ly = (x0 + x1) / 2.0, (y0 + y1) / 2.0
                name = _base_name(pl)
                # place libre : sous la cote du haut, a gauche de la cote de droite
                bw, bh = wpt - room - 2 * pad, hpt - room - 2 * pad
                cx_, cy_ = P(lx, ly)
                if main is None or room:
                    cx_ = P(x0, y0)[0] + (wpt - room) / 2.0
                    cy_ = P(x0, y0)[1] + (hpt - room) / 2.0
                # piece haute et etroite : nom ecrit dans sa longueur
                ang = 90.0 if bh > bw * 1.3 else 0.0
                along, cross = (bh, bw) if ang else (bw, bh)
                size = min(10.0, cross * 0.75, along * 0.95 / (max(1, len(name)) * 0.54))
                if size < 4.0 and along > 0 and cross >= 4.5:
                    # nom tronque plutot qu'illisible
                    size = min(4.5, cross * 0.85)
                    n_max = int(along * 0.95 / (size * 0.54))
                    if n_max >= 4 and len(name) > n_max:
                        name = name[:n_max - 1] + '.'
                if size >= 3.5:
                    labels.append(((cx_, cy_), name, size, False, ang))
    # coupes prioritaires (mode Rectangulaire) : niveau 1 en trait epais
    # numerote dans l'ordre de coupe, recoupes (niveau 2) en trait fin
    cuts = sheet.get('cuts') or []
    has_cut = False
    for lev in (2, 1):
        for c in cuts:
            if c.get('level') != lev:
                continue
            (x1, y1), (x2, y2) = c['seg']
            pa, pb = P(x1, y1), P(x2, y2)
            pg.color(VERT_COUPE, True)
            pg.width(1.8 if lev == 1 else 0.5)
            pg.dash(6, 3) if lev == 1 else pg.dash(2, 2)
            pg.line(pa[0], pa[1], pb[0], pb[1])
            pg.dash()
            has_cut = True
    n1 = 0
    pg.color(VERT_COUPE)
    for c in cuts:
        if c.get('level') != 1:
            continue
        n1 += 1
        (x1, y1), (x2, y2) = c['seg']
        if abs(y1 - y2) < 1e-6:     # horizontale : numero a gauche du panneau (cotes des bandes a droite)
            q = P(min(x1, x2), y1)
            pg.text(q[0] - 2 * MM, q[1] - 1.2 * MM, str(n1), 9, True, 0, 'right')
        else:                       # verticale : numero au-dessus
            q = P(x1, max(y1, y2))
            pg.text(q[0], q[1] + 2 * MM, str(n1), 9, True, 0, 'center')
    # largeur de chaque bande, a regler sur la scie : a droite du panneau
    # (coupes horizontales) ou sous le panneau (coupes verticales)
    for bd in sheet.get('bandes') or []:
        a, b = float(bd['a']), float(bd['b'])
        if b - a < 1e-6:
            continue
        _cote_bande(pg, P, L, a, b, bd.get('axis') == 'y')
    if sheet.get('bandes'):
        pg.color(VERT_COUPE)
        if sheet['bandes'][0].get('axis') == 'y':
            q = P(L, W)
            pg.text(q[0] + 6 * MM, q[1] + 3 * MM, 'Bandes (mm)', 8, True, 0, 'left')
        else:
            q = P(0, 0)
            pg.text(q[0] - 2 * MM, q[1] - 6 * MM - 2.5 - 9 * 0.72, 'Bandes (mm)', 8, True, 0, 'right')
    pg.color((0, 0, 0))
    for (x, y), s, size, bold, ang in labels:
        a = math.radians(ang)
        # centrage vertical du texte (decalage perpendiculaire a la ligne)
        pg.text(x + math.sin(a) * size / 3.0, y - math.cos(a) * size / 3.0, s, size, bold, ang, 'center')

    # cotes du panneau
    _cote(pg, ox, oy + W * k, ox + L * k, oy + W * k, '%s mm' % _fmt(L), (0, 1), 8 * MM)
    _cote(pg, ox, oy, ox, oy + W * k, '%s mm' % _fmt(W), (-1, 0), 8 * MM)

    # une seule ligne d'infos en bas de page (le cartouche, la legende et
    # l'echelle sont sur la page de garde, demande du 2026-11-19)
    sc = ('1:%s' % _fmt(scale)) if float(scale).is_integer() else ('1:%.1f' % scale)
    pg.color((0.5, 0.5, 0.5), True)
    pg.width(0.4)
    pg.line(MARGIN, MARGIN + 5 * MM, PAGE_W - MARGIN, MARGIN + 5 * MM)
    pg.color((0, 0, 0))
    pg.text(MARGIN, MARGIN + 1.2 * MM, doc.get('title', 'Calpinage'), 9, True)
    tx0 = MARGIN + _text_width(doc.get('title', 'Calpinage'), 9, True) + 6 * MM
    pg.text(tx0, MARGIN + 1.2 * MM,
            u'Panneau %d sur %d  -  %s  -  %s x %s mm  -  %d pièce(s)  -  échelle %s (A3 à 100 %%)  -  %s'
            % (sheet['index'], n_sheets, grp['label'], _fmt(L), _fmt(W), len(sheet['placements']), sc,
               doc.get('date', '')), 9)
    return pg


# --- Ordre des coupes (scie a format) -----------------------------------------------

ROUGE_COUPE = (0.85, 0.1, 0.1)
ORANGE_ZONE = (1.0, 0.82, 0.6)
ORANGE_PIECE = (1.0, 0.55, 0.1)
ORDRE_COLS = 6
# couleurs des vignettes (2026-11-19 : retour aux gris, l'utilisateur n'aime pas le bleu)
C_RESTE = (0.42, 0.42, 0.42)        # pas encore coupe (gris fonce)
C_BANDE = (1.0, 1.0, 1.0)           # fond de la bande en cours
C_BANDE_P = (0.72, 0.72, 0.72)      # pieces de la bande en cours (gris moyen)
C_BANDE_L = (0.25, 0.25, 0.25)      # contour de la bande en cours
C_FAIT = (1.0, 1.0, 1.0)            # deja coupe : blanc (2026-11-19 : « plus blanc »)
C_FAIT_L = (0.72, 0.72, 0.72)
C_CADRE = (0.0, 0.62, 0.38)         # cadre de la bande en cours
C_DELIG = (0.84, 0.74, 0.95)        # coupee a longueur, reste a deligner (violet, 2026-11-19)
C_DELIG_L = (0.48, 0.28, 0.70)


def _step_text(st, n_prim):
    d = _mm(st['dim'])
    kind = st['kind']
    if kind == 'prim':
        return 'Coupe prioritaire %d : bande de %s mm' % (n_prim, d)
    # (l'utilisateur, 2026-11-19 : « au lieu de dire tronconner, etc., dis juste couper »)
    # (la bande est deja dans le titre de la section)
    return u'Couper à %s mm' % d


def _hatch(pg, x, y, w, h, step=1.6, lw=0.45, col=None, edge=1.0, sens=1):
    """Hachures a 45 deg dans le rectangle (fond blanc, peu d'encre).
    Orange vers la droite = piece qu'on coupe ; gris vers la gauche = pas encore coupe."""
    col = col or ORANGE_PIECE
    pg.color((1, 1, 1))
    pg.rect(x, y, w, h, 'f')
    pg.add('q %s %s %s %s re W n' % (_fmt(x), _fmt(y), _fmt(w), _fmt(h)))
    pg.color(col, True)
    pg.width(lw)
    t = -h
    while t < w + h:
        if sens > 0:
            pg.line(x + t, y, x + t + h, y + h)
        else:
            pg.line(x + t, y + h, x + t + h, y)
        t += step
    pg.add('Q')
    pg.color(col, True)
    pg.width(edge)
    pg.rect(x, y, w, h)


def _hatch_reste(pg, x, y, w, h):
    # plus clair (2026-11-19 : ne pas confondre avec la bande en cours)
    _hatch(pg, x, y, w, h, step=2.0, lw=0.3, col=(0.66, 0.66, 0.66), edge=0.4, sens=-1)


def _thumb(pg, x0, y0, kt, L, W, sheet, si):
    """Vignette du panneau pour l'etape si. Bande en cours en gris clair, les
    autres bandes (deja coupees ou pas encore) tres claires en pointille,
    partie coupee en orange clair, piece terminee en orange, coupe en rouge."""
    plan = sheet['plan']
    st = plan[si]
    bandes = sheet.get('bandes') or []
    curs = [k - 1 for k in (st.get('strips') or [st.get('strip', 0)]) if 0 < k <= len(bandes)]
    cur = min(curs) if curs else -1

    def P(x, y):
        return (x0 + x * kt, y0 + y * kt)

    def strip_rect(bd):
        a, b = float(bd['a']), float(bd['b'])
        if bd.get('axis') == 'y':
            return 0.0, a, L, b - a
        return a, 0.0, b - a, W

    pg.color((1, 1, 1))
    pg.color((0.55, 0.55, 0.55), True)
    pg.width(0.4)
    pg.rect(x0, y0, L * kt, W * kt, 'B')
    crs = [strip_rect(bandes[c]) for c in curs]
    cr = crs[0] if crs else None
    if st['kind'] != 'prim':
        pg.color(C_BANDE)
        for r_ in crs:
            pg.rect(x0 + r_[0] * kt, y0 + r_[1] * kt, r_[2] * kt, r_[3] * kt, 'f')
    zones = st.get('zones') or [st['zone']]
    done = set(i for s2 in plan[:si] for i in s2['pieces'])
    now = set(st['pieces'])
    # mises a longueur mais pas encore delignees : violet jusqu'a l'etape « deligner »
    mis = set(i for s2 in plan[:si] for i in (s2.get('lp') or [])) - done

    def within(bb, r):
        return (bb[0] >= r[0] - 0.5 and bb[1] >= r[1] - 0.5 and
                bb[2] <= r[0] + r[2] + 0.5 and bb[3] <= r[1] + r[3] + 0.5)

    prim = st['kind'] == 'prim'
    for i, pl in enumerate(sheet['placements']):
        bb = _bbox_pl(pl)
        if bb is None:
            continue
        rx, ry, rw, rh = bb[0], bb[1], bb[2] - bb[0], bb[3] - bb[1]
        in_cur = any(within(bb, r_) for r_ in crs)
        inside = any(within(bb, z) for z in zones)
        # bande deja detachee (pendant les coupes prioritaires)
        k_strip = next((j for j, bd in enumerate(bandes) if within(bb, strip_rect(bd))), -1)
        if i in mis and i not in now:
            fill, line = C_DELIG, C_DELIG_L                  # reste a deligner
        elif i in now or (inside and i not in done):
            _hatch(pg, x0 + rx * kt, y0 + ry * kt, rw * kt, rh * kt)  # piece ou bande qu'on coupe
            continue
        elif i in done or (prim and 0 <= k_strip < cur):
            # deja coupe en blanc ; aux etapes des bandes, les pieces pas
            # encore coupees des autres bandes restent « pas encore coupe »
            # (demande du 2026-11-19, 20h18)
            fill, line = C_FAIT, C_FAIT_L                    # deja coupe
        elif in_cur and not prim:
            fill, line = C_BANDE_P, C_BANDE_L                # bande qu'on utilise
        else:
            _hatch_reste(pg, x0 + rx * kt, y0 + ry * kt, rw * kt, rh * kt)  # pas encore coupe
            continue
        pg.color(fill)
        pg.color(line, True)
        pg.width(0.3)
        pg.rect(x0 + rx * kt, y0 + ry * kt, rw * kt, rh * kt, 'B')
    def _lettres():
        # lettre repere dans chaque piece terminee a cette carte
        pg.color((0, 0, 0))
        poses = []
        for i in now:
            pl = sheet['placements'][i]
            bb = _bbox_pl(pl)
            r_l = _rep(pl)
            if bb is None or not r_l:
                continue
            # meme taille pour toutes les lettres ; sur une petite piece la lettre
            # deborde, sur un fond blanc pour rester lisible (demande du 2026-11-19, 21h33)
            fs = 7.0
            mx, my = x0 + (bb[0] + bb[2]) / 2.0 * kt, y0 + (bb[1] + bb[3]) / 2.0 * kt
            lw_ = _text_width(r_l, fs, True)
            pw, ph = (bb[2] - bb[0]) * kt, (bb[3] - bb[1]) * kt
            # lettres qui se chevauchent (pieces fines empilees) : decalees a droite
            while any(abs(mx - qx) < (lw_ + qw) / 2.0 + 1.0 and abs(my - qy) < fs * 1.1 for qx, qy, qw in poses):
                mx += lw_ + 1.5
            poses.append((mx, my, lw_))
            if pw < lw_ + 1.5 or ph < fs * 0.9 or poses[-1][0] != x0 + (bb[0] + bb[2]) / 2.0 * kt:
                pg.color((1, 1, 1))
                pg.rect(mx - lw_ / 2.0 - 0.6, my - fs * 0.42, lw_ + 1.2, fs * 0.84, 'f')
                pg.color((0, 0, 0))
            pg.text(mx, my - fs * 0.36, r_l, fs, True, 0.0, 'center')

    for r_ in crs:
        # cadre autour de la ou des bandes en cours (coupes prioritaires et bandes)
        pg.color(C_CADRE, True)
        pg.width(1.8)
        pg.rect(x0 + r_[0] * kt, y0 + r_[1] * kt, r_[2] * kt, r_[3] * kt)
    if prim and cr is not None:
        _lettres()
        return      # coupes prioritaires : le cadre vert suffit (demande du 2026-11-19)
    pg.color(ROUGE_COUPE, True)
    pg.width(0.8)
    for (a1, b1), (a2, b2) in st.get('segs') or [st['seg']]:
        p1, p2 = P(a1, b1), P(a2, b2)
        pg.line(p1[0], p1[1], p2[0], p2[1])
    _lettres()


def _meme_ligne(z1, z2, seg):
    """Deux coupes de la meme bande / rangee : leurs zones ont la meme
    etendue le long du trait de coupe (une carte par bande, 2026-11-19)."""
    (a1, b1), (a2, b2) = seg
    if abs(a1 - a2) < 1e-6:        # trait vertical : meme y, meme hauteur
        return abs(z1[1] - z2[1]) < 0.6 and abs(z1[3] - z2[3]) < 0.6
    return abs(z1[0] - z2[0]) < 0.6 and abs(z1[2] - z2[2]) < 0.6


def _reglage(st):
    """Reglage de la scie : guide parallele ou butee laterale, et la cote."""
    return ('par' if st['kind'] in ('prim', 'refente', 'ajust') else 'lat', round(float(st['dim']), 1))


def _grouper_etapes(plan):
    """Regroupe les coupes qui se suivent avec le meme reglage de la scie
    (meme guide, meme cote), sur une ou plusieurs bandes (demandes du
    2026-11-19 : « 4 pieces a 251 », puis ordre par reglage dans le panneau)."""
    out = []
    np_ = 0
    for st in plan:
        if st['kind'] == 'prim':
            np_ += 1
        g = out[-1] if out else None
        if (g is not None and (g['kind'] == 'prim') == (st['kind'] == 'prim')
                and _reglage(g) == _reglage(st)):
            g['segs'].append(st['seg'])
            g['pieces'] = g['pieces'] + list(st['pieces'])
            g['n'] += 1
            g['lp'] = g['lp'] + list(st.get('lp') or [])
            g['extra'] = st.get('extra', 0)
            g['zones'].append(list(st['zone']))
            g['kinds'].add(st['kind'])
            if st['strip'] not in g['strips']:
                g['strips'].append(st['strip'])
            if st['kind'] == 'prim':
                g['pnums'].append(np_)
            continue
        out.append(dict(st, segs=[st['seg']], pieces=list(st['pieces']), n=1, zones=[list(st['zone'])],
                        kinds={st['kind']}, strips=[st['strip']], lp=list(st.get('lp') or []), pnums=[np_] if st['kind'] == 'prim' else []))
    return out


def _noms_groupes(names, idx):
    """Noms des pieces, les doublons comptes : « Traverse basse x4, Montant »."""
    cnt, order = {}, []
    for i in idx:
        n = names.get(i, '')
        if n not in cnt:
            order.append(n)
            cnt[n] = 0
        cnt[n] += 1
    return ', '.join(n if cnt[n] == 1 else '%s x%d' % (n, cnt[n]) for n in order)


def _ordre_pages(doc, grp, sheet, n_sheets):
    plan = _grouper_etapes(sheet.get('plan') or [])
    if not plan:
        return []
    sheet = dict(sheet, plan=plan)
    L, W = float(doc['L']), float(doc['W'])
    gap = 4 * MM
    cw = (PAGE_W - 2 * MARGIN - (ORDRE_COLS - 1) * gap) / ORDRE_COLS
    kt = (cw - 2 * MM) / L
    th = W * kt
    hd = 12 * MM                         # en-tete de carte : numero + cote en gros
    ch = hd + th + 2 * MM + 2 * 3.6 * MM
    top = PAGE_H - MARGIN - 16 * MM
    names = {}
    for i, pl in enumerate(sheet['placements']):
        bb = _bbox_pl(pl)
        if bb is not None:
            dw, dh = bb[2] - bb[0], bb[3] - bb[1]
            # sans les cotes ni le numero de copie (demande du 2026-11-19)
            names[i] = _base_name(pl)
    # sections : coupes prioritaires, puis les cartes dans l'ordre, regroupees
    # sous un bandeau par bande (ou par groupe de bandes au meme reglage)
    bandes = sheet.get('bandes') or []

    def strips_title(ks):
        if len(ks) == 1:
            k = ks[0]
            if 0 < k <= len(bandes):
                bd = bandes[k - 1]
                return u'Bande %d  -  largeur %s mm' % (k, _mm(float(bd['b']) - float(bd['a'])))
            return u'Bande %d' % k
        return u'Bandes %s  -  même réglage' % ', '.join(str(k) for k in sorted(ks))

    sections = []
    for i, st in enumerate(plan):
        title = u'Coupes prioritaires' if st['kind'] == 'prim' else strips_title(st['strips'])
        if sections and sections[-1][0] == title:
            sections[-1][1].append(i)
        else:
            sections.append((title, [i]))
    head_h = 7 * MM
    bottom = MARGIN + 8 * MM
    # mise en page compacte (2026-11-19 : moins de pages) : les cartes se
    # suivent sur la ligne, chaque section a son bandeau au-dessus de ses
    # cartes ; une nouvelle section ne force plus une nouvelle ligne.
    # items : (page, 'head', y, titre, q0, q1) / (page, 'card', y, colonne, etape)
    items = []
    page = 0
    y = top
    q = 0
    for title, idx in sections:
        seg = None
        for si in idx:
            if q >= ORDRE_COLS:                      # ligne suivante
                y -= head_h + ch + gap
                q = 0
                seg = None
                if y - (head_h + ch) < bottom:
                    page += 1
                    y = top
            if seg is None:
                seg = [page, 'head', y, title if si == idx[0] else title + u' (suite)', q, q]
                items.append(seg)
            seg[5] = q
            items.append((page, 'card', y - head_h, q, si))
            q += 1
    n_pages = page + 1
    pages = []
    for p in range(n_pages):
        pg = _Page()
        pg.color((0, 0, 0))
        pg.text(MARGIN, PAGE_H - MARGIN - 6 * MM,
                u'Ordre des coupes  -  panneau %d sur %d  -  %s' % (sheet['index'], n_sheets, grp['label']), 13, True)
        pg.text(MARGIN, PAGE_H - MARGIN - 12 * MM,
                u'Coupes prioritaires d\'abord, puis chaque bande est coupée en pièces.', 8.5)
        lx = MARGIN + 100 * MM
        for fill, line, txt in (('hatch', None, u'Pièce ou bande qu\'on coupe'),
                                (C_BANDE_P, C_CADRE, u'Bande en cours'),
                                ('reste', None, u'Pas encore coupé'),
                                (C_FAIT, C_FAIT_L, u'Déjà coupé'),
                                (C_DELIG, C_DELIG_L, u'Reste à déligner'),
                                (None, ROUGE_COUPE, u'Coupe à faire')):
            if fill == C_DELIG and not any(s2['kind'] == 'ajust' for s2 in sheet['plan']):
                continue
            if fill == 'hatch':
                _hatch(pg, lx, PAGE_H - MARGIN - 12.4 * MM, 6 * MM, 3 * MM)
            elif fill == 'reste':
                _hatch_reste(pg, lx, PAGE_H - MARGIN - 12.4 * MM, 6 * MM, 3 * MM)
            elif fill is None:
                pg.color(line, True)
                pg.width(0.8)
                pg.line(lx, PAGE_H - MARGIN - 11.2 * MM, lx + 6 * MM, PAGE_H - MARGIN - 11.2 * MM)
            else:
                pg.color(fill)
                pg.color(line, True)
                pg.width(0.5)
                pg.rect(lx, PAGE_H - MARGIN - 12.4 * MM, 6 * MM, 3 * MM, 'B')
            pg.color((0, 0, 0))
            pg.text(lx + 8 * MM, PAGE_H - MARGIN - 12 * MM, txt, 8.5)
            lx += 8 * MM + _text_width(txt, 8.5) + 10 * MM
        pg.text(PAGE_W - MARGIN, MARGIN, '%s  -  %s  -  page %d / %d' % (doc.get('title', 'Calpinage'), doc.get('date', ''),
                                                                     p + 1, n_pages), 7, False, 0, 'right')
        for it in items:
            if it[0] != p:
                continue
            if it[1] == 'head':
                yh, q0, q1 = it[2], it[4], it[5]
                hx = MARGIN + q0 * (cw + gap)
                hw = (q1 - q0) * (cw + gap) + cw
                pg.color((0.88, 0.88, 0.88))
                pg.rect(hx, yh - 5.5 * MM, hw, 5.5 * MM, 'f')
                pg.color((0, 0, 0))
                fs = min(9.5, 9.5 * (hw - 3 * MM) / max(1.0, _text_width(it[3], 9.5, True)))
                pg.text(hx + 1.5 * MM, yh - 4 * MM, it[3], fs, True)
                continue
            _p, _k, cy, q, si = it
            st = plan[si]
            cx = MARGIN + q * (cw + gap)
            pg.color((0, 0, 0), True)
            pg.width(0.3)
            pg.rect(cx, cy - ch, cw, ch)
            pg.color((0, 0, 0))
            # cote a couper en gros et en gras : lisible au premier coup d'oeil
            pg.text(cx + 1.5 * MM, cy - 4 * MM, '%d.' % (si + 1), 9, True)
            if st['kind'] == 'prim':
                pn = st['pnums']
                sub = (u'Coupe prioritaire %d' % pn[0]) if len(pn) == 1 else \
                    (u'Coupes prioritaires %s' % ', '.join(str(x) for x in pn))
            else:
                ks = sorted(st['strips'])
                sub = (u'Bande %d' % ks[0]) if len(ks) == 1 else (u'Bandes %s' % ', '.join(str(x) for x in ks))
            pg.text(cx + 9 * MM, cy - 4 * MM, sub, 7)
            # pieces de la carte qui font exactement la cote coupee (en travers de la coupe)
            (sa, sb), (ea, eb) = st['seg']
            # pieces mises a longueur par la carte, y compris celles encore a deligner
            # ensuite (demande du 2026-11-19 : « 15 pieces » au lieu de 17)
            pcs_l = list(st['pieces']) + [i for i in st.get('lp', []) if i not in st['pieces']]
            if st['kinds'] <= {'trons', 'recoupe'}:
                # un troncon detache une colonne de plusieurs pieces deja a longueur
                # (demande du 2026-11-19, 21h02 : « 4 pieces » pour 6 coupes)
                fait = set(i for s2 in plan[:si] for i in list(s2['pieces']) + list(s2.get('lp') or []))
                for i, pl in enumerate(sheet['placements']):
                    bb = _bbox_pl(pl)
                    if bb is None or i in fait or i in pcs_l:
                        continue
                    if any(bb[0] >= z[0] - 0.5 and bb[1] >= z[1] - 0.5 and bb[2] <= z[0] + z[2] + 0.5
                           and bb[3] <= z[1] + z[3] + 0.5 for z in (st.get('zones') or [st['zone']])):
                        pcs_l.append(i)
            k_ok = 0
            for i in pcs_l:
                bb = _bbox_pl(sheet['placements'][i])
                if bb is not None:
                    across = (bb[2] - bb[0]) if abs(sa - ea) < 1e-6 else (bb[3] - bb[1])
                    k_ok += abs(across - float(st['dim'])) < 0.6
            n_b = st['n'] + int(st.get('extra', 0) or 0)
            if st['kinds'] == {'ajust'}:
                # reprise d'une piece en largeur : « deligner » (demande du 2026-11-19)
                big = u'Déligner à %s mm' % _mm(st['dim'])
                if len(st['pieces']) > 1:
                    pg.text(cx + cw - 2 * MM, cy - 4 * MM, u'%d pièces' % len(st['pieces']), 8, True, 0, 'right')
            elif st['kinds'] <= {'refente', 'prim'} and n_b > 1:
                big = u'%d bandes à %s mm' % (n_b, _mm(st['dim']))
            elif len(pcs_l) > 1 and k_ok == len(pcs_l) and k_ok <= st['n']:
                big = u'%d pièces à %s mm' % (k_ok, _mm(st['dim']))
            elif k_ok > st['n'] and k_ok == len(pcs_l):
                # plus de pieces que de coupes : on annonce les coupes, et les pieces a droite
                big = (u'%d coupes à %s mm' % (st['n'], _mm(st['dim']))) if st['n'] > 1 else \
                    (u'Couper à %s mm' % _mm(st['dim']))
                pg.text(cx + cw - 2 * MM, cy - 4 * MM, u'%d pièces' % k_ok, 8, True, 0, 'right')
            elif st['n'] > 1:
                big = u'%d coupes à %s mm' % (st['n'], _mm(st['dim']))
            else:
                big = u'Couper à %s mm' % _mm(st['dim'])
            bs = min(15.0, (cw - 5 * MM) / (len(big) * 0.56))
            pg.color((0, 0, 0))
            pg.text(cx + 2.5 * MM, cy - hd + 0.6 * MM + bs * 0.32, big, bs, True)
            # lettres reperes propres a la carte (A, B, C...), seulement s'il y a
            # plusieurs sortes de pieces (demande du 2026-11-19, 21h30)
            _REP.clear()
            for i in st['pieces']:
                if names.get(i, '') not in _REP:
                    _REP[names.get(i, '')] = _lettre(len(_REP))
            if len(_REP) < 2:
                _REP.clear()
            _thumb(pg, cx + 1 * MM, cy - hd - 1 * MM - th, kt, L, W, sheet, si)
            # noms des seules pieces terminees a cette carte (demande du 2026-11-19, 21h07)
            if st['pieces']:
                lab = _noms_groupes(dict((i, (u'%s = %s' % (_REP[n], n)) if n in _REP else n)
                                         for i, n in names.items()), st['pieces'])
                _REP.clear()
                pre = u'Pièce : ' if len(st['pieces']) == 1 else u'Pièces : '
                n_max = int((cw - 3 * MM) / (7.0 * 0.56))
                # coupure aux espaces (pas au milieu d'un mot), 2 lignes max
                lines, cur = [], ''
                for w in (pre + lab).split(' '):
                    if cur and len(cur) + 1 + len(w) > n_max:
                        lines.append(cur)
                        cur = w
                    else:
                        cur = (cur + ' ' + w) if cur else w
                lines.append(cur)
                if len(lines) > 2:
                    lines = [lines[0], (lines[1] + ' ' + ' '.join(lines[2:]))[:n_max - 1] + '.']
                pg.color((0, 0, 0))
                for li, t in enumerate(lines):
                    pg.text(cx + 1.5 * MM, cy - hd - 1 * MM - th - 4.2 * MM - li * 3.6 * MM, t, 7, True)
        pages.append(pg)
    return pages


def _doc_flags(doc):
    poche = grav = cut = False
    for g in doc['groups']:
        for s in g['sheets']:
            cut = cut or bool(s.get('cuts'))
            for pl in s['placements']:
                poche = poche or any(d > 0.05 for d in (pl.get('depths') or []))
                grav = grav or bool(pl.get('grav'))
    return poche, grav, cut


def _cover_page(doc):
    """Page de garde : nom du projet au milieu, infos pratiques, legende."""
    pg = _Page()
    L, W = float(doc['L']), float(doc['W'])
    cx = PAGE_W / 2.0
    title = doc.get('title', 'Calpinage')
    ts = min(34.0, (PAGE_W - 2 * MARGIN - 40 * MM) / max(1.0, _text_width(title, 1.0, True)))
    y = PAGE_H * 0.70
    pg.color((0, 0, 0))
    pg.text(cx, y, title, ts, True, 0, 'center')
    y -= 12 * MM
    pg.text(cx, y, u'Calpinage  -  %s' % doc.get('date', ''), 13, False, 0, 'center')
    pg.color((0.6, 0.6, 0.6), True)
    pg.width(0.6)
    pg.line(cx - 90 * MM, y - 6 * MM, cx + 90 * MM, y - 6 * MM)
    # infos
    n_sh = sum(len(g['sheets']) for g in doc['groups'])
    n_pc = sum(len(s['placements']) for g in doc['groups'] for s in g['sheets'])
    rows = [(u'Format des panneaux', u'%s x %s mm' % (_fmt(L), _fmt(W))),
            (u'Marge', u'%s mm' % _fmt(float(doc.get('margin') or 0)))]
    for g in doc['groups']:
        rows.append((g['label'], u'%d panneau(x)  -  %d pièce(s)'
                     % (len(g['sheets']), sum(len(s['placements']) for s in g['sheets']))))
    if len(doc['groups']) > 1:
        rows.append((u'Total', u'%d panneau(x)  -  %d pièce(s)' % (n_sh, n_pc)))
    y -= 16 * MM
    for a, b in rows:
        bold = a == u'Total'
        pg.color((0, 0, 0))
        pg.text(cx - 4 * MM, y, a, 12, bold, 0, 'right')
        pg.text(cx + 4 * MM, y, b, 12, True)
        y -= 7.5 * MM
    # legende des pages panneau
    poche, grav, cut = _doc_flags(doc)
    items = [('fill', GRIS_MATIERE, u'Matière : pièce à découper'),
             ('fill', (1, 1, 1), u'Vide : trou traversant, à évider')]
    if poche:
        items.append(('fill', GRIS_POCHE, u'Usinage non débouchant (profondeur indiquée)'))
    if grav:
        items.append(('line', BLEU_GRAVURE, u'Gravure (trait, sans découpe)'))
    if cut:
        items.append(('cut', VERT_COUPE, u'Coupe prioritaire n° (scie à format)'))
    y -= 8 * MM
    pg.color((0, 0, 0))
    pg.text(cx, y, u'Légende', 11, True, 0, 'center')
    y -= 8 * MM
    tot = sum(14 * MM + _text_width(t, 10) for _k, _c, t in items) + 8 * MM * (len(items) - 1)
    x = cx - tot / 2.0
    for kind, rgb, txt in items:
        if kind == 'fill':
            pg.color(rgb)
            pg.color((0, 0, 0), True)
            pg.width(0.6)
            pg.rect(x, y - 1.5 * MM, 9 * MM, 5 * MM, 'B')
        elif kind == 'cut':
            pg.color(rgb, True)
            pg.width(1.8)
            pg.dash(6, 3)
            pg.line(x, y + 1 * MM, x + 9 * MM, y + 1 * MM)
            pg.dash()
        else:
            pg.color(rgb, True)
            pg.width(1.2)
            pg.line(x, y + 1 * MM, x + 9 * MM, y + 1 * MM)
        pg.color((0, 0, 0))
        pg.text(x + 12 * MM, y, txt, 10)
        x += 14 * MM + _text_width(txt, 10) + 8 * MM
    y -= 14 * MM
    pg.color((0.35, 0.35, 0.35))
    pg.text(cx, y, u'Imprimer en A3 paysage à 100 %, sans ajustement. L\'échelle de chaque panneau est indiquée en bas de sa page.',
            9, False, 0, 'center')
    return pg


def build_pdf(doc):
    """doc : {'title', 'date', 'L', 'W', 'margin', 'groups': [{'label', 'th_mm',
    'sheets': [{'index', 'placements': [{'name', 'label', 'regions', 'depths',
    'grav', 'flip'}]}]}]} (mm). Renvoie les octets du PDF."""
    if not doc.get('date'):
        doc = dict(doc, date=datetime.date.today().strftime('%d/%m/%Y'))
    pages = [_cover_page(doc)]
    for g in doc['groups']:
        for s in g['sheets']:
            pages.append(_sheet_page(doc, g, s, len(g['sheets'])))
            if doc.get('ordre'):
                pages.extend(_ordre_pages(doc, g, s, len(g['sheets'])))
    objs = []   # contenu des objets 1..n

    def new(body):
        objs.append(body)
        return len(objs)

    f1 = new(b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>')
    f2 = new(b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>')
    pages_id = new(None)
    kids = []
    for pg in pages:
        data = zlib.compress(pg.data())
        c = new(b'<< /Length %d /Filter /FlateDecode >>\nstream\n' % len(data) + data + b'\nendstream')
        kids.append(new(('<< /Type /Page /Parent %d 0 R /MediaBox [0 0 %s %s] /Contents %d 0 R '
                         '/Resources << /Font << /F1 %d 0 R /F2 %d 0 R >> >> >>'
                         % (pages_id, _fmt(PAGE_W), _fmt(PAGE_H), c, f1, f2)).encode('latin-1')))
    objs[pages_id - 1] = ('<< /Type /Pages /Kids [%s] /Count %d >>'
                          % (' '.join('%d 0 R' % i for i in kids), len(kids))).encode('latin-1')
    info = new(b'<< /Title (' + _txt(doc.get('title', 'Calpinage')) + b') /Producer (Toolkit CNC - Calpinage CNC) >>')
    catalog = new(('<< /Type /Catalog /Pages %d 0 R >>' % pages_id).encode('latin-1'))
    out = bytearray(b'%PDF-1.4\n%\xe2\xe3\xcf\xd3\n')
    offs = []
    for i, body in enumerate(objs):
        offs.append(len(out))
        out += b'%d 0 obj\n' % (i + 1) + body + b'\nendobj\n'
    xref = len(out)
    out += b'xref\n0 %d\n0000000000 65535 f \n' % (len(objs) + 1)
    for o in offs:
        out += b'%010d 00000 n \n' % o
    out += (b'trailer\n<< /Size %d /Root %d 0 R /Info %d 0 R >>\nstartxref\n%d\n%%EOF\n'
            % (len(objs) + 1, catalog, info, xref))
    return bytes(out), len(pages)


def write_pdf(path, doc):
    data, n = build_pdf(doc)
    with open(path, 'wb') as f:
        f.write(data)
    return n
