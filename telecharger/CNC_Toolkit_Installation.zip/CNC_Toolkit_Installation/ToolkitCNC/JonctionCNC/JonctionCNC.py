import adsk.core, adsk.fusion, traceback, os, sys, json, math, time

# ---------------------------------------------------------------------------
# Jonction CNC - coupe un corps plat (ex. plate-bande de 100 mm qui fait le
# tour d'un fond de canape ovale ou de forme libre) en plusieurs pieces,
# placees ensuite separement sur le calpinage. Deux formes de coupe :
#   - "Droite" : coupe nette perpendiculaire au contour ;
#   - "Puzzle" : col + tete ronde raccordes par des conges (forme dessinee
#     par l'utilisateur le 2026-10-06), pour que les pieces s'emboitent.
# Aucun jeu (demande de l'utilisateur) : seul un trait de 0.01 mm separe les pieces
# (voir _cut_body).
#
# Deroule (comme "Plan le long de la trajectoire" de Fusion, demande de
# l'utilisateur le 2026-10-06) : la carte "Jonction" de la palette CNC Toolkit
# lance la commande Fusion JonctionCNCCmd ;
#   1. clic sur une arete de la bande -> le plan de coupe (orange) se place
#      au point clique, perpendiculaire a l'arete, et traverse toute la
#      largeur de la bande jusqu'a l'arete d'en face, sur toute l'epaisseur ;
#   2. une FLECHE sur l'arete se fait glisser a la souris : le plan suit le
#      contour de la face (toutes les aretes de la boucle) ;
#   3. OK ("Couper") -> une esquisse + un enlevement a travers le corps,
#      regroupes dans un groupe d'historique "Jonction N" ; pieces renommees
#      <nom>_A, _B... Relancer la commande pour chaque coupe (sur une bande
#      fermee, 1 coupe ouvre la bande, 2 coupes = 2 pieces).
#
# Geometrie du puzzle (repere local u = en travers de la bande, de 0 au bord
# clique a W au bord oppose ; v = le long de l'arete) : ligne de base v = 0,
# tete ronde (centre (c, h), rayon R) raccordee a la ligne de base par deux
# conges de rayon r tangents a la ligne de base ET a la tete. Le col vaut
# 2*(a - r), a = demi-ecart des centres de conges. Un decalage d donne un
# profil exactement parallele (ligne v = d, tete R + d, conges r - d) : le
# trait de coupe est la bande entre les profils -d et +d.
# ---------------------------------------------------------------------------

CMD_ID = 'JonctionCNCCmd'
CMD_NAME = 'Jonction CNC'
CMD_DESC = 'Coupe un corps plat en plusieurs pieces (coupe droite ou puzzle) a un endroit choisi en faisant glisser une fleche le long du contour'
PALETTE_ID = 'ToolkitCNC_Palette'

_ADDIN_DIR = os.path.dirname(os.path.abspath(__file__))
_PREFS_FILE = os.path.join(_ADDIN_DIR, 'jonction_prefs.json')
_DEBUG_LOG = os.path.join(_ADDIN_DIR, 'jonction_debug.log')

DEFAULTS = {
    'forme': 'droite',    # 'droite' ou 'puzzle'
    'fraise_mm': 8.0,     # diametre de fraise -> rayon mini des angles rentrants
    'tete_mm': 30.0,      # diametre de la tete ronde
    'col_mm': 18.0,       # largeur du col (plus petite largeur du tenon)
    'conge_mm': 5.0,      # rayon des conges de raccordement
    'nb_tenons': 1,
    'flip': False,        # cote vers lequel part le tenon
    'auto': True,         # tete / col / conges calcules d'apres la largeur
    'jeu_mm': 0.0,        # jeu de fonctionnement (largeur du trait de coupe)
    'marge_auto': False,  # jeu de Marge CNC applique sur les faces coupees
}

# Mode auto (regles de l'utilisateur, 2026-10-06) : tete = largeur / 2, col =
# tete / 2, conges = 0.4 x tete (20 mm pour sa bande de 100 mm, valeur qu'il
# avait reglee a la main).
_AUTO_TETE = 0.5
_AUTO_COL = 0.5
_AUTO_CONGE = 0.4


def auto_puzzle_mm(width_mm):
    """(tete, col, conges) en mm pour une bande de width_mm."""
    tete = width_mm * _AUTO_TETE
    return round(tete, 2), round(tete * _AUTO_COL, 2), round(tete * _AUTO_CONGE, 2)

# Depassement de la coupe au-dela des deux bords de la bande (cm).
_EXT_CM = 0.5
# Largeur du trait de coupe (cm) : 0.01 mm, voir _cut_body.
_TRAIT_CM = 0.001
# Marge mini entre un tenon et un bord de bande / un autre tenon (cm).
_MARGE_TENON_CM = 0.3
# Rehausse du preview au-dessus de la face (cm) pour eviter qu'il soit
# masque par la face elle-meme.
_LIFT_CM = 0.02

_app = None
_ui = None
_handlers = []
_cmd_handlers = []
_params = dict(DEFAULTS)
_loop = None          # contour en cours (voir _build_loop)
_pos = 0.0            # position courante le long du contour (cm)
_cg_group = None
_pos0 = 0.0           # position au clic : la fleche mesure le decalage depuis ce point
_last = None          # dernier calcul (fr, g, geom, errs), dessine par executePreview
# Coupes deja placees (l'utilisateur 2026-10-12 : plusieurs coupes par commande) :
# [{'loop', 'pos', 'pos0', 'last'}]. La coupe en cours (celle qui a la
# fleche) reste dans _loop/_pos/_pos0/_last.
_cuts = []
_syncing = False      # True pendant que la commande vide elle-meme la selection


def _dbg(msg):
    try:
        with open(_DEBUG_LOG, 'a', encoding='utf-8') as f:
            f.write(time.strftime('%Y-%m-%d %H:%M:%S') + ' ' + str(msg) + '\n')
    except Exception:
        pass


def _load_prefs():
    p = dict(DEFAULTS)
    try:
        with open(_PREFS_FILE, 'r', encoding='utf-8') as f:
            saved = json.load(f)
        for k in DEFAULTS:
            if k in saved:
                p[k] = saved[k]
    except Exception:
        pass
    return p


def _save_prefs(p):
    try:
        with open(_PREFS_FILE, 'w', encoding='utf-8') as f:
            json.dump({k: p.get(k, DEFAULTS[k]) for k in DEFAULTS}, f, indent=2)
    except Exception:
        pass


def _palette():
    try:
        return _ui.palettes.itemById(PALETTE_ID)
    except Exception:
        return None


def _send(action, payload):
    pal = _palette()
    if pal is None:
        return
    try:
        pal.sendInfoToHTML(action, json.dumps(payload))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Parametres et profil puzzle (fonctions pures, unites internes Fusion = cm)
# ---------------------------------------------------------------------------

def params_cm(p):
    """Parametres (mm) -> grandeurs geometriques (cm)."""
    def f(k):
        try:
            return float(p.get(k, DEFAULTS[k]))
        except Exception:
            return float(DEFAULTS[k])
    try:
        nb = max(1, int(p.get('nb_tenons', 1)))
    except Exception:
        nb = 1
    return {
        'rf': f('fraise_mm') / 20.0,      # rayon de fraise
        'R': f('tete_mm') / 20.0,         # rayon de tete
        'col': f('col_mm') / 10.0,
        'r': f('conge_mm') / 10.0,
        # Pas de jeu (demande de l'utilisateur) : seulement le trait de 0.01 mm
        # qui separe les pieces, voir _cut_body.
        # Jeu de fonctionnement = largeur du trait de coupe (0.01 mm mini,
        # pour que les pieces soient bien separees, voir _cut_body).
        'jeu': max(f('jeu_mm') / 10.0, _TRAIT_CM),
        'puzzle': p.get('forme', 'droite') == 'puzzle',
        'nb': nb,
        'flip': bool(p.get('flip', False)),
    }


def check_profile(g, width):
    """Verifie que le profil est usinable et verrouillant. Retourne
    (geom, erreurs) ; geom = {'a', 'h', 'centers', 'tab_len'} ou None."""
    errs = []
    R, col, r, jeu, nb = g['R'], g['col'], g['r'], g['jeu'], g['nb']
    if R * 2 <= col + 1e-6:
        errs.append('La tete doit etre plus large que le col (sinon rien ne verrouille).')
    if r <= jeu / 2 + 1e-6:
        errs.append('Le jeu doit rester plus petit que le diametre des conges.')
    if errs:
        return None, errs
    a = col / 2 + r
    disc = (R + r) ** 2 - a ** 2
    if disc <= 1e-9:
        return None, ['Combinaison tete/col/conges impossible.']
    h = r + math.sqrt(disc)
    centers = [width * (k + 0.5) / nb for k in range(nb)]
    if width > 0:
        if centers[0] - a < _MARGE_TENON_CM or width - centers[-1] - a < _MARGE_TENON_CM:
            errs.append('Bande trop etroite pour %d tenon(s) de cette taille.' % nb)
        elif nb > 1 and (width / nb) - 2 * a < _MARGE_TENON_CM:
            errs.append('Tenons trop rapproches : reduis leur nombre ou leur taille.')
    return {'a': a, 'h': h, 'centers': centers, 'tab_len': h + R}, errs


def profile_segments(g, geom, width, d):
    """Chaine du profil decale de d (cm, vers le cote femelle), de u = -EXT
    a u = W + EXT. Segments en coordonnees locales (u, v) :
      ('L', (u0, v0), (u1, v1))
      ('A', (cu, cv), rayon, angle_debut, angle_fin)   (angles en radians)
    """
    R, r = g['R'], g['r']
    a, h = geom['a'], geom['h']
    segs = []
    u_prev = -_EXT_CM
    th = math.atan2(h - r, a)  # angle du centre de tete vu du conge gauche
    for c in geom['centers']:
        segs.append(('L', (u_prev, d), (c - a, d)))
        # conge gauche : centre (c-a, r), de -90 deg a th (sens trigo)
        segs.append(('A', (c - a, r), r - d, -math.pi / 2, th))
        # tete : centre (c, h), de pi+th a -th en passant par le haut (horaire)
        segs.append(('A', (c, h), R + d, math.pi + th, -th))
        # conge droit : centre (c+a, r), de pi-th a 3pi/2 (sens trigo)
        segs.append(('A', (c + a, r), r - d, math.pi - th, 1.5 * math.pi))
        u_prev = c + a
    segs.append(('L', (u_prev, d), (width + _EXT_CM, d)))
    return segs


def _arc_pt(seg, t):
    _, (cu, cv), rad, a0, a1 = seg
    ang = a0 + (a1 - a0) * t
    return (cu + rad * math.cos(ang), cv + rad * math.sin(ang))


def _seg_start(seg):
    return seg[1] if seg[0] == 'L' else _arc_pt(seg, 0.0)


def _seg_end(seg):
    return seg[2] if seg[0] == 'L' else _arc_pt(seg, 1.0)


def _reverse(segs):
    out = []
    for s in reversed(segs):
        if s[0] == 'L':
            out.append(('L', s[2], s[1]))
        else:
            out.append(('A', s[1], s[2], s[4], s[3]))
    return out


def sample_profile(segs, step_deg=5.0):
    """Polyligne (u, v) du profil, arcs echantillonnes - preview."""
    pts = []
    for s in segs:
        if s[0] == 'L':
            if not pts:
                pts.append(s[1])
            pts.append(s[2])
        else:
            n = max(2, int(abs(math.degrees(s[4] - s[3])) / step_deg) + 1)
            for i in range(0 if not pts else 1, n + 1):
                pts.append(_arc_pt(s, i / n))
    return pts


# ---------------------------------------------------------------------------

def _on_face(face, pt, ev=None):
    try:
        if ev is None:
            ev = face.evaluator
        ok, prm = ev.getParameterAtPoint(pt)
        if not ok:
            return False
        ok2, proj = ev.getPointAtParameter(prm)
        if ok2 and proj.distanceTo(pt) > 0.01:
            return False
        return ev.isParameterOnFace(prm)
    except Exception:
        return False


def _edge_len(edge):
    ev = edge.evaluator
    ok, p0, p1 = ev.getParameterExtents()
    ok2, length = ev.getLengthAtParameter(p0, p1)
    return p0, p1, length


def _param_at(ev, pt):
    """Parametre de l'arete le plus proche de pt. getParameterAtPoint ne
    suffit pas : verifie en direct, sur un arc d'anneau deja coupe
    (parametres de -2pi a 0), il renvoie 0 pour un point a 90 deg (le coin
    de l'arc) -> on verifie le resultat et on cherche sinon par
    echantillonnage + affinage."""
    ok, p0, p1 = ev.getParameterExtents()
    ok, prm = ev.getParameterAtPoint(pt)
    if ok and p0 - 1e-9 <= prm <= p1 + 1e-9:
        ok2, q = ev.getPointAtParameter(prm)
        if ok2 and q.distanceTo(pt) < 1e-3:
            return prm

    eps = (p1 - p0) * 1e-9

    def dist(t):
        try:
            ok3, q3 = ev.getPointAtParameter(min(max(t, p0 + eps), p1 - eps))
            return q3.distanceTo(pt) if ok3 else 1e9
        except Exception:
            return 1e9
    n = 400
    best = min((p0 + (p1 - p0) * i / n for i in range(n + 1)), key=dist)
    lo, hi = max(p0, best - (p1 - p0) / n), min(p1, best + (p1 - p0) / n)
    for _ in range(40):
        m1, m2 = lo + (hi - lo) / 3, hi - (hi - lo) / 3
        if dist(m1) < dist(m2):
            hi = m2
        else:
            lo = m1
    return min(max((lo + hi) / 2, p0 + eps), p1 - eps)


def _pick_top_face(edge, click_pt):
    """Parmi les faces de l'arete, la face PLANE la plus grande dont la
    normale est perpendiculaire a l'arete au point clique (= le dessus ou
    le dessous de la bande, jamais le chant)."""
    ev = edge.evaluator
    prm = _param_at(ev, click_pt)
    ok, tan = ev.getFirstDerivative(prm)
    tan.normalize()
    best = None
    for f in edge.faces:
        try:
            if f.geometry.surfaceType != adsk.core.SurfaceTypes.PlaneSurfaceType:
                continue
            n = f.geometry.normal
            if abs(n.dotProduct(tan)) > 0.05:
                continue
            if best is None or f.area > best.area:
                best = f
        except Exception:
            continue
    return best


def _build_loop(edge, click_pt):
    """Contour ferme de la face du dessus contenant l'arete cliquee.
    Retourne (loop, position_cm) ou (None, erreur).

    Tout le calcul se fait dans l'espace du COMPOSANT du corps (arete et
    face natives) : verifie en direct, l'evaluateur d'une face "proxy"
    (corps dans une occurrence deplacee) travaille en coordonnees du
    composant et non du monde - getParameterAtPoint avec un point monde y
    projette a des metres de la face. Le passage au monde ne sert qu'au
    preview (voir _to_world)."""
    occ = edge.assemblyContext
    if occ is not None:
        inv = occ.transform2.copy()
        inv.invert()
        click_pt = click_pt.copy()
        click_pt.transformBy(inv)
        edge = edge.nativeObject
    face = _pick_top_face(edge, click_pt)
    if face is None:
        return None, "Aucune face plane du dessus trouvee pour cette arete."
    target = None
    for lp in face.loops:
        for ce in lp.coEdges:
            try:
                if ce.edge.tempId == edge.tempId:
                    target = lp
                    break
            except Exception:
                continue
        if target is not None:
            break
    if target is None:
        return None, "Arete introuvable dans le contour de la face."
    items = []
    total = 0.0
    pos = 0.0
    for ce in target.coEdges:
        e = ce.edge
        p0, p1, length = _edge_len(e)
        items.append({'edge': e, 'opp': ce.isOpposedToEdge, 'p0': p0, 'len': length, 'start': total})
        if e.tempId == edge.tempId:
            prm = _param_at(e.evaluator, click_pt)
            ok, l = e.evaluator.getLengthAtParameter(p0, prm)
            pos = total + ((length - l) if ce.isOpposedToEdge else l)
        total += length
    return {'face': face, 'body': face.body, 'occ': occ, 'items': items, 'total': total}, pos


def _eval_loop(loop, s):
    """Point et tangente (sens du contour) a l'abscisse s (cm)."""
    memo = loop.get('memo')
    if memo is not None and memo[0] == s:
        return memo[1].copy(), memo[2].copy()
    pt, tan = _eval_loop_raw(loop, s)
    loop['memo'] = (s, pt.copy(), tan.copy())
    return pt, tan


def _eval_loop_raw(loop, s):
    total = loop['total']
    s = s % total if total > 0 else 0.0
    it = loop['items'][-1]
    for cand in loop['items']:
        if s <= cand['start'] + cand['len'] + 1e-9:
            it = cand
            break
    l = min(max(s - it['start'], 0.0), it['len'])
    if it['opp']:
        l = it['len'] - l
    ev = it['edge'].evaluator
    ok, prm = ev.getParameterAtLength(it['p0'], l)
    ok, pt = ev.getPointAtParameter(prm)
    ok, tan = ev.getFirstDerivative(prm)
    if it['opp']:
        tan.scaleBy(-1)
    return pt, tan


def _frame_at(loop, s, flip):
    """Repere local de la jonction a l'abscisse s : origine O sur l'arete,
    N en travers de la bande (vers l'interieur de la face), V le long de
    l'arete (cote femelle), n normale sortante de la face ; largeur W de la
    bande mesuree jusqu'au bord oppose."""
    face = loop['face']
    fev = loop.get('fev')
    if fev is None:
        fev = loop['fev'] = face.evaluator
    O, T = _eval_loop(loop, s)
    ok, n = fev.getNormalAtPoint(O)
    n.normalize()
    t = T.copy()
    k = n.copy(); k.scaleBy(t.dotProduct(n))
    t.subtract(k)
    if t.length < 1e-9:
        return None
    t.normalize()
    N = n.crossProduct(t)
    N.normalize()

    def at(u):
        p = O.copy(); w = N.copy(); w.scaleBy(u); p.translateBy(w)
        return p

    if not _on_face(face, at(0.05), fev):
        N.scaleBy(-1)
        if not _on_face(face, at(0.05), fev):
            return None
    # Largeur : on repart de la largeur precedente (+-2 mm) si elle encadre
    # encore le bord (cas courant en faisant glisser la fleche : quelques
    # appels au lieu d'une cinquantaine) ; sinon on avance par pas de 2.5 mm
    # jusqu'a sortir de la face. Puis dichotomie au 1/100 mm.
    step = 0.25
    u_in, u_out = 0.05, None
    hint = loop.get('w_hint')
    if hint and hint > 0.3 and _on_face(face, at(hint - 0.001), fev) and not _on_face(face, at(hint + 0.001), fev):
        # Meme largeur a 1/100 mm pres (bande reguliere) : 2 tests suffisent.
        u_in = u_out = hint
    elif hint and hint > 0.3 and _on_face(face, at(hint - 0.2), fev) and not _on_face(face, at(hint + 0.2), fev):
        u_in, u_out = hint - 0.2, hint + 0.2
    u = u_in
    while u_out is None and u < 500.0:
        u += step
        if _on_face(face, at(u), fev):
            u_in = u
        else:
            u_out = u
            break
    if u_out is None:
        return None
    for _ in range(14 if u_out - u_in > 0.5 else 10 if u_out > u_in else 0):
        mid = (u_in + u_out) / 2
        if _on_face(face, at(mid), fev):
            u_in = mid
        else:
            u_out = mid
    loop['w_hint'] = u_in
    V = t.copy()
    if flip:
        V.scaleBy(-1)
    return {'O': O, 'N': N, 'V': V, 'n': n, 'W': u_in, 's': s,
            'body': loop['body'], 'occ': loop['occ'], 'face': face}


def _local_to_comp(fr, u, v, lift=0.0):
    """Point (u, v) du repere local -> espace du composant du corps."""
    p = fr['O'].copy()
    for vec, k in ((fr['N'], u), (fr['V'], v), (fr['n'], lift)):
        w = vec.copy(); w.scaleBy(k); p.translateBy(w)
    return p


def _to_world(fr, p):
    if fr.get('occ') is not None:
        p = p.copy()
        p.transformBy(fr['occ'].transform2)
    return p


def _thickness(fr):
    """Epaisseur du corps sous le point O (cm) : distance a la face plane
    parallele a la face du dessus la plus proche (le dessous)."""
    best = None
    O, n = fr['O'], fr['n']
    for f in fr['body'].faces:
        try:
            if f.geometry.surfaceType != adsk.core.SurfaceTypes.PlaneSurfaceType:
                continue
            pl = f.geometry
            if abs(abs(pl.normal.dotProduct(n)) - 1.0) > 1e-4:
                continue
            d = abs(pl.origin.vectorTo(O).dotProduct(n))
            if d > 1e-3 and (best is None or d < best):
                best = d
        except Exception:
            continue
    return best if best is not None else 1.8


def _find_top_face(body, frc):
    """Retrouve sur le corps (natif) la face plane du dessus qui porte la
    coupe - les references d'avant decoupe ne sont plus fiables."""
    probe = _local_to_comp(frc, min(0.05, frc['W'] / 2), 0.0)
    for f in body.faces:
        try:
            if f.geometry.surfaceType != adsk.core.SurfaceTypes.PlaneSurfaceType:
                continue
            n = f.geometry.normal
            if abs(abs(n.dotProduct(frc['n'])) - 1.0) > 1e-4:
                continue
            if _on_face(f, probe):
                return f
        except Exception:
            continue
    return None


def _segments(g, geom, W, d):
    """Chaine du trait (u, v) decale de d : ligne droite, ou profil puzzle
    (voir profile_segments) si la forme est "puzzle"."""
    if g['puzzle'] and geom is not None:
        return profile_segments(g, geom, W, d)
    return [('L', (-_EXT_CM, d), (W + _EXT_CM, d))]


def _check(g, fr):
    """(geom, erreurs) pour la coupe fr ; geom None en coupe droite."""
    if fr is None:
        return None, ["Impossible de mesurer la bande a cet endroit (coin ou bord non parallele) : deplace un peu la fleche."]
    if not g['puzzle']:
        return None, []
    return check_profile(g, fr['W'])


# ---------------------------------------------------------------------------
# Preview (CustomGraphics, aucune modification du document)
# ---------------------------------------------------------------------------

def _clear_preview():
    global _cg_group
    for grp in (_cg_group if isinstance(_cg_group, list) else [_cg_group]):
        try:
            if grp is not None:
                grp.deleteMe()
        except Exception:
            pass
    _cg_group = None


def _draw_all(refresh=True):
    """Toutes les coupes : les coupes deja placees en orange clair, celle
    en cours en orange (rouge si elle est invalide)."""
    global _cg_group
    _clear_preview()
    groups = []
    for c in _cuts:
        fr, g, geom, errs = c['last']
        if fr is not None:
            _draw_preview(fr, g, geom, (255, 160, 90) if not errs else (220, 30, 30), refresh=False)
            if _cg_group is not None:
                groups.append(_cg_group)
                _cg_group = None
    if _last is not None and _last[0] is not None:
        fr, g, geom, errs = _last
        _draw_preview(fr, g, geom, (255, 90, 0) if not errs else (220, 30, 30), refresh=False)
        if _cg_group is not None:
            groups.append(_cg_group)
            _cg_group = None
    _cg_group = groups or None
    if refresh:
        try:
            _app.activeViewport.refresh()
        except Exception:
            pass


def _draw_preview(fr, g, geom, color=(255, 90, 0), refresh=True):
    """Le trait de coupe comme un "ruban" vertical sur toute l'epaisseur :
    contour epais + surface semi-transparente (comme un plan de Fusion)."""
    global _cg_group
    _clear_preview()
    if fr is None:
        return
    try:
        design = adsk.fusion.Design.cast(_app.activeProduct)
        grp = design.rootComponent.customGraphicsGroups.add()
        t = fr.get('t') or _thickness(fr)
        uv = sample_profile(_segments(g, geom, fr['W'], 0.0))
        # Calcul en flottants (sans objets Point3D : 4x plus rapide).
        O, N, V, nn = ([q.x, q.y, q.z] for q in (fr['O'], fr['N'], fr['V'], fr['n']))
        m = fr['occ'].transform2.asArray() if fr.get('occ') is not None else None

        def P(u, v, w):
            x, y, z = (O[i] + N[i] * u + V[i] * v + nn[i] * w for i in range(3))
            if m is not None:
                x, y, z = (m[4 * r] * x + m[4 * r + 1] * y + m[4 * r + 2] * z + m[4 * r + 3] for r in range(3))
            return [x, y, z]
        n = len(uv)
        flat = []
        for w in (_LIFT_CM, -t - _LIFT_CM):
            for (u, v) in uv:
                flat += P(u, v, w)
        coords = adsk.fusion.CustomGraphicsCoordinates.create(flat)
        # Contour : profil en haut, en bas, et les deux bouts.
        idx = []
        for k in range(n - 1):
            idx += [k, k + 1, n + k, n + k + 1]
        idx += [0, n, n - 1, 2 * n - 1]
        lines = grp.addLines(coords, idx, False)
        try:
            lines.color = adsk.fusion.CustomGraphicsSolidColorEffect.create(
                adsk.core.Color.create(color[0], color[1], color[2], 255))
            lines.weight = 3.0
            lines.depthPriority = 1
        except Exception:
            pass
        # Ruban semi-transparent (deux faces pour etre vu des deux cotes).
        try:
            tri = []
            for k in range(n - 1):
                a, b, c, d = k, k + 1, n + k + 1, n + k
                tri += [a, b, c, a, c, d, a, c, b, a, d, c]
            V = fr['V']
            nrm = [V.x, V.y, V.z] * (2 * n)
            mesh = grp.addMesh(coords, tri, nrm, tri)
            mesh.color = adsk.fusion.CustomGraphicsSolidColorEffect.create(
                adsk.core.Color.create(color[0], color[1], color[2], 90))
        except Exception:
            _dbg('preview ruban: ' + traceback.format_exc().strip().splitlines()[-1])
        _cg_group = grp
        if refresh:
            # Inutile dans executePreview (Fusion redessine lui-meme) et
            # c'etait 47 ms sur ~55 par deplacement de la fleche.
            try:
                _app.activeViewport.refresh()
            except Exception:
                pass
    except Exception:
        _dbg('ERREUR _draw_preview: ' + traceback.format_exc())
        _clear_preview()


def _current_frame(g):
    return _frame_for(_loop, _pos, g)


def _frame_for(loop, pos, g):
    if loop is None:
        return None
    fr = _frame_at(loop, pos, g['flip'])
    if fr is not None:
        # Bande plate : epaisseur mesuree une fois par arete (fluidite).
        if loop.get('t') is None:
            loop['t'] = _thickness(fr)
        fr['t'] = loop['t']
        fr['comp'] = loop.get('comp') or loop['body'].parentComponent
        loop['comp'] = fr['comp']
    return fr


def _compute(loop, pos, p):
    """(fr, g, geom, errs) d'une coupe ; en mode auto, tete/col/conges
    suivent la largeur de la bande a CET endroit."""
    g = params_cm(p)
    fr = None
    try:
        fr = _frame_for(loop, pos, g)
    except Exception:
        _dbg('ERREUR _frame_at: ' + traceback.format_exc())
    if fr is not None and p.get('auto', True):
        q = dict(p)
        q['tete_mm'], q['col_mm'], q['conge_mm'] = auto_puzzle_mm(fr['W'] * 10.0)
        g = params_cm(q)
    geom, errs = _check(g, fr)
    return fr, g, geom, errs


# ---------------------------------------------------------------------------
# Creation
# ---------------------------------------------------------------------------

def _cut_body(design, comp, body, frc, g, geom, index):
    """Une coupe : esquisse du trait (largeur _TRAIT_CM, entre les profils
    decales de -d et +d) + enlevement a travers le corps, regroupes dans un
    groupe d'historique "Jonction N".

    Un trait de 0.01 mm plutot qu'un "Scinder le corps" : verifie en direct,
    Scinder echoue sur une bande FERMEE (une coupe seule ne separe rien,
    SPLIT_TARGET_TOOL_NOT_INTERSECT). Invisible a l'usinage."""
    face = _find_top_face(body, frc)
    if face is None:
        raise RuntimeError('face du dessus introuvable sur ' + body.name)
    tl = design.timeline if design.designType == adsk.fusion.DesignTypes.ParametricDesignType else None
    sk = comp.sketches.add(face)
    sk.name = 'Jonction %d' % index
    for c in list(sk.sketchCurves):
        try:
            c.deleteMe()
        except Exception:
            pass
    sk.isComputeDeferred = True

    def P(uv):
        return sk.modelToSketchSpace(_local_to_comp(frc, uv[0], uv[1]))

    W = frc['W']
    d = g['jeu'] / 2   # jeu de fonctionnement (0.01 mm mini)
    chain = list(_segments(g, geom, W, d))
    chain.append(('L', (W + _EXT_CM, d), (W + _EXT_CM, -d)))
    chain += _reverse(_segments(g, geom, W, -d))
    chain.append(('L', (-_EXT_CM, -d), (-_EXT_CM, d)))
    for s in chain:
        if s[0] == 'L':
            sk.sketchCurves.sketchLines.addByTwoPoints(P(s[1]), P(s[2]))
        else:
            sk.sketchCurves.sketchArcs.addByThreePoints(
                P(_arc_pt(s, 0.0)), P(_arc_pt(s, 0.5)), P(_arc_pt(s, 1.0)))
    sk.isComputeDeferred = False
    profs = adsk.core.ObjectCollection.create()
    for pr in sk.profiles:
        profs.add(pr)
    if profs.count == 0:
        sk.deleteMe()
        raise RuntimeError('trait de coupe non ferme')
    t = frc.get('t') or _thickness(frc)
    ext = comp.features.extrudeFeatures
    inp = ext.createInput(profs, adsk.fusion.FeatureOperations.CutFeatureOperation)
    # isFullLength=False : t + 1 cm DE CHAQUE COTE de la face du dessus
    # (avec True, la distance est la longueur totale et le trait ne
    # traversait pas tout le corps).
    inp.setSymmetricExtent(adsk.core.ValueInput.createByReal(t + 1.0), False)
    inp.participantBodies = [body]
    try:
        last = ext.add(inp)
        _last_cut_feature[0] = last
    except Exception:
        try:
            sk.deleteMe()
        except Exception:
            pass
        raise
    if tl is not None:
        try:
            grp = tl.timelineGroups.add(sk.timelineObject.index, last.timelineObject.index)
            grp.name = 'Jonction %d' % index
        except Exception:
            _dbg('groupe historique: ' + traceback.format_exc())


_last_cut_feature = [None]


def _resolve_body(fr):
    """Corps (natif) qui contient la matiere a l'endroit de la coupe fr :
    milieu de la bande, a mi-epaisseur."""
    comp = fr.get('comp')
    if comp is None:
        return None
    t = fr.get('t') or 0.0
    p = _local_to_comp(fr, fr['W'] / 2, 0.0, -t / 2)
    for b in comp.bRepBodies:
        try:
            if b.isSolid and b.pointContainment(p) == adsk.fusion.PointContainment.PointInsidePointContainment:
                return b
        except Exception:
            continue
    return None


def _apply_marge(design, feat):
    """MargeAuto : le jeu regle dans Marge CNC est applique sur les faces
    creees par la coupe (memes appels que EntailleCNC._flush_marge_batch,
    pour que Modif Marge puisse le reajuster plus tard). Retourne un
    message, ou '' si tout va bien."""
    M = _find_module('MargeCNC')
    if M is None:
        return 'MargeAuto : add-in "Marge CNC" inactif - aucun jeu applique.'
    jeu_cm, jeu_actif, _excl = M.load_settings()
    if not jeu_actif:
        return 'MargeAuto : "Appliquer le jeu" est desactive dans Marge CNC.'
    by_body = {}
    for f in feat.faces:
        try:
            by_body.setdefault(f.body.entityToken, []).append(f.entityToken)
        except Exception:
            continue
    batch = [{'female_token': k, 'face_tokens': v} for k, v in by_body.items()]
    if not batch:
        return 'MargeAuto : aucune face de coupe trouvee.'
    try:
        M.record_face_tokens_batch(batch)
    except Exception:
        pass
    M.apply_jeu_to_tokens(design, design.rootComponent, batch, jeu_cm, False)
    return ''


def _find_module(short_name):
    mod = sys.modules.get(short_name)
    if mod is not None:
        return mod
    suffix = short_name + '_py'
    for k, m in list(sys.modules.items()):
        if k.endswith(suffix):
            return m
    return None


def create_jonction(fr, g, geom, marge_auto=False):
    """Coupe le corps de fr. Retourne un message (str)."""
    design = adsk.fusion.Design.cast(_app.activeProduct)
    native = fr['body']
    comp = native.parentComponent
    base = native.name
    others = set(b.entityToken for b in comp.bRepBodies if b.entityToken != native.entityToken)
    prev_occ = None
    try:
        prev_occ = design.activeOccurrence
    except Exception:
        pass
    try:
        if fr.get('occ') is not None:
            try:
                fr['occ'].activate()
            except Exception:
                pass
        _last_cut_feature[0] = None
        _cut_body(design, comp, native, fr, g, geom, _next_group_index(design))
        marge_msg = ''
        if marge_auto and _last_cut_feature[0] is not None:
            try:
                marge_msg = _apply_marge(design, _last_cut_feature[0])
            except Exception:
                marge_msg = 'MargeAuto : erreur - ' + traceback.format_exc().strip().splitlines()[-1]
        pieces = [b for b in comp.bRepBodies if b.isSolid and b.entityToken not in others]
        if len(pieces) > 1:
            # <racine>_A, _B... ; la racine perd le suffixe d'une coupe
            # precedente et les lettres deja prises par les autres pieces
            # sont sautees (2e coupe de Bande_A -> Bande_A + Bande_C).
            root = base
            if len(root) > 2 and root[-2] == '_' and root[-1].isupper():
                root = root[:-2]
            used = set(b.name for b in comp.bRepBodies if b.entityToken in others)
            i = 0
            for b in pieces:
                while '%s_%s' % (root, _letters(i)) in used:
                    i += 1
                try:
                    b.name = '%s_%s' % (root, _letters(i))
                    used.add(b.name)
                except Exception:
                    pass
                i += 1
        return '%s : %d piece(s)%s' % (base, len(pieces), (' ; ' + marge_msg) if marge_msg else '')
    finally:
        try:
            if prev_occ is not None:
                prev_occ.activate()
            else:
                design.activateRootComponent()
        except Exception:
            pass


def _letters(i):
    s = ''
    i += 1
    while i > 0:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s


def _next_group_index(design):
    n = 1
    try:
        for i in range(design.timeline.timelineGroups.count):
            nm = design.timeline.timelineGroups.item(i).name
            if nm.startswith('Jonction '):
                try:
                    n = max(n, int(nm.split(' ')[1]) + 1)
                except Exception:
                    pass
    except Exception:
        pass
    return n


# ---------------------------------------------------------------------------
# Commande Fusion (fleche a glisser sur l'arete)
# ---------------------------------------------------------------------------

_FORMES = (('droite', 'Droite'), ('puzzle', 'Puzzle'))


def _read_inputs(inputs):
    """Champs de la commande -> _params (mm)."""
    p = dict(_params)
    try:
        dd = adsk.core.DropDownCommandInput.cast(inputs.itemById('forme'))
        p['forme'] = _FORMES[1][0] if dd.selectedItem and dd.selectedItem.name == _FORMES[1][1] else _FORMES[0][0]
        for k in ('tete_mm', 'col_mm', 'conge_mm'):
            vi = adsk.core.ValueCommandInput.cast(inputs.itemById(k))
            p[k] = round(vi.value * 10.0, 4)   # cm -> mm
        p['flip'] = adsk.core.BoolValueCommandInput.cast(inputs.itemById('flip')).value
        p['auto'] = adsk.core.BoolValueCommandInput.cast(inputs.itemById('auto')).value
        p['jeu_mm'] = round(adsk.core.ValueCommandInput.cast(inputs.itemById('jeu_mm')).value * 10.0, 4)
        p['marge_auto'] = adsk.core.BoolValueCommandInput.cast(inputs.itemById('marge_auto')).value
    except Exception:
        _dbg('ERREUR _read_inputs: ' + traceback.format_exc())
    return p


def _place_arrow(inputs, g):
    """Pose la fleche (manipulateur de la distance) sur le contour a _pos,
    dans le sens du contour : origine = point - tangente * _pos, pour que
    origine + tangente * valeur tombe sur le point. Recalcule a chaque
    deplacement : la fleche suit ainsi les courbes."""
    dist = adsk.core.DistanceValueCommandInput.cast(inputs.itemById('pos'))
    if _loop is None:
        dist.isVisible = False
        return
    O, T = _eval_loop(_loop, _pos)
    T.normalize()
    occ = _loop.get('occ')
    if occ is not None:
        O = O.copy(); O.transformBy(occ.transform2)
        T = T.copy(); T.transformBy(occ.transform2); T.normalize()
    # Valeur = decalage depuis le point clique (pas depuis le debut du
    # contour : la cote partait tres loin de la piece, retour de l'utilisateur).
    off = _offset()
    org = O.copy()
    back = T.copy(); back.scaleBy(-off)
    org.translateBy(back)
    dist.setManipulator(org, T)
    dist.value = off
    dist.isVisible = True


def _offset():
    """Decalage signe de _pos par rapport a _pos0 (le plus court sur une
    boucle fermee)."""
    tot = _loop['total']
    off = _pos - _pos0
    if tot > 0:
        off = (off + tot / 2) % tot - tot / 2
    return off


def _update(inputs):
    """Recalcule la coupe, la fleche et le message. Le preview orange est
    dessine dans executePreview : Fusion efface a chaque deplacement de la
    fleche les graphiques crees ailleurs pendant la commande (le preview
    disparaissait, retour de l'utilisateur)."""
    global _params, _last
    _params = _read_inputs(inputs)
    g = params_cm(_params)
    grp = inputs.itemById('grpPuzzle')
    if grp is not None:
        grp.isVisible = g['puzzle']
    undo = inputs.itemById('undo')
    if undo is not None:
        undo.isEnabled = _loop is not None or bool(_cuts)
    msg = inputs.itemById('info')
    # Les reglages (forme, jeu...) s'appliquent a toutes les coupes.
    for c in _cuts:
        c['last'] = _compute(c['loop'], c['pos'], _params)
    if _loop is None:
        _last = None
        _place_arrow(inputs, g)
        _auto_lock(inputs)
        _draw_all()
        msg.formattedText = "Clique sur une arete de la bande." if not _cuts else (
            '%d coupe(s) placee(s).<br>Clique une autre arete pour en ajouter une, ou Couper.' % len(_cuts))
        return None, g, None, ['pas d\'arete']
    _place_arrow(inputs, g)
    fr, g, geom, errs = _compute(_loop, _pos, _params)
    if fr is not None and _params.get('auto', True):
        # Mode auto : les champs montrent les valeurs de la coupe en cours.
        for k, v in zip(('tete_mm', 'col_mm', 'conge_mm'), auto_puzzle_mm(fr['W'] * 10.0)):
            _params[k] = v
            vi = adsk.core.ValueCommandInput.cast(inputs.itemById(k))
            if abs(vi.value - v / 10.0) > 1e-6:
                vi.value = v / 10.0
    _auto_lock(inputs)
    _last = (fr, g, geom, errs)
    bad = [i + 1 for i, c in enumerate(_cuts) if c['last'][3]]
    if errs or bad:
        # Pas d'executePreview quand les champs sont invalides : dessin ici.
        _draw_all()
    n = len(_cuts) + 1
    if errs:
        msg.formattedText = '<b>' + '<br>'.join(errs) + '</b>'
    elif bad:
        msg.formattedText = '<b>Coupe(s) %s invalide(s) avec ces reglages.</b>' % ', '.join(map(str, bad))
    else:
        msg.formattedText = ('Coupe %d : bande de %.1f mm de large, %.1f mm d\'epaisseur.<br>'
                             'Fais glisser la fleche, clique une autre arete pour une coupe de plus, '
                             'puis Couper.' % (n, fr['W'] * 10, fr['t'] * 10))
    return fr, g, geom, errs


def _auto_lock(inputs):
    on = bool(_params.get('auto', True))
    for k in ('tete_mm', 'col_mm', 'conge_mm'):
        it = inputs.itemById(k)
        if it is not None and it.isEnabled == on:
            it.isEnabled = not on


class _InputChangedHandler(adsk.core.InputChangedEventHandler):
    def __init__(self):
        super().__init__()

    def notify(self, args):
        global _loop, _pos, _pos0, _last, _syncing
        try:
            # Toujours la collection de la commande : args.inputs est celle du
            # groupe quand le champ modifie est dans le groupe "Puzzle".
            inputs = args.input.parentCommand.commandInputs
            changed = args.input
            if changed.id == 'edge':
                if _syncing:
                    return
                sel = adsk.core.SelectionCommandInput.cast(changed)
                if sel.selectionCount == 0:
                    return
                s0 = sel.selection(0)
                loop, pos = _build_loop(adsk.fusion.BRepEdge.cast(s0.entity), s0.point)
                _dbg('arete: %s' % ('ok, contour %.1f mm' % (loop['total'] * 10) if loop else pos))
                # La selection est videe aussitot : chaque clic = une coupe
                # de plus, meme sur une arete deja utilisee (un 2e clic sur
                # une arete selectionnee la deselectionnerait).
                _syncing = True
                try:
                    sel.clearSelection()
                finally:
                    _syncing = False
                if loop is None:
                    inputs.itemById('info').formattedText = '<b>%s</b>' % pos
                    return
                if _loop is not None and _last is not None and _last[0] is not None:
                    # La coupe en cours est figee, la fleche passe a la nouvelle.
                    _cuts.append({'loop': _loop, 'pos': _pos, 'pos0': _pos0, 'last': _last})
                _loop, _pos, _pos0 = loop, pos, pos
            elif changed.id == 'undo':
                # Retour arriere : supprime la coupe en cours, la fleche
                # revient sur la precedente.
                if _loop is not None:
                    _loop, _last = None, None
                if _loop is None and _cuts:
                    c = _cuts.pop()
                    _loop, _pos, _pos0, _last = c['loop'], c['pos'], c['pos0'], c['last']
            elif changed.id == 'pos' and _loop is not None:
                dist = adsk.core.DistanceValueCommandInput.cast(changed)
                _pos = (_pos0 + dist.value) % _loop['total'] if _loop['total'] > 0 else 0.0
            _update(inputs)
        except Exception:
            _dbg('ERREUR inputChanged: ' + traceback.format_exc())


class _ValidateHandler(adsk.core.ValidateInputsEventHandler):
    def __init__(self):
        super().__init__()

    def notify(self, args):
        try:
            # Resultats deja calcules par inputChanged (pas de 2e mesure).
            alls = [c['last'] for c in _cuts] + ([_last] if _loop is not None and _last is not None else [])
            args.areInputsValid = bool(alls) and all(r[0] is not None and not r[3] for r in alls)
        except Exception:
            args.areInputsValid = False


class _PreviewHandler(adsk.core.CommandEventHandler):
    def __init__(self):
        super().__init__()

    def notify(self, args):
        try:
            _draw_all(refresh=False)
            args.isValidResult = False
        except Exception:
            _dbg('ERREUR preview: ' + traceback.format_exc())


class _ExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self):
        super().__init__()

    def notify(self, args):
        try:
            _save_prefs(_params)
            todo = [c['last'] for c in _cuts]
            if _loop is not None and _last is not None:
                todo.append(_last)
            _clear_preview()
            for i, (fr, g, geom, errs) in enumerate(todo):
                if fr is None or errs:
                    _ui.messageBox('Coupe %d : %s' % (i + 1, errs[0] if errs else 'invalide'), CMD_NAME)
                    return
            # Tous les reperes ont ete mesures AVANT la premiere coupe ; le
            # corps de chaque coupe est retrouve juste avant de couper (une
            # coupe precedente a pu le separer en plusieurs pieces).
            msgs = []
            for i, (fr, g, geom, errs) in enumerate(todo):
                body = _resolve_body(fr)
                if body is None:
                    msgs.append('Coupe %d : corps introuvable' % (i + 1))
                    continue
                fr = dict(fr)
                fr['body'] = body
                msgs.append(create_jonction(fr, g, geom, _params.get('marge_auto', False)))
            _dbg('coupe: ' + ' | '.join(msgs))
            bad = [m for m in msgs if 'introuvable' in m or 'MargeAuto :' in m]
            if bad:
                _ui.messageBox('\n'.join(bad), CMD_NAME)
        except Exception:
            _dbg('ERREUR execute: ' + traceback.format_exc())
            _ui.messageBox('Echec de la coupe :\n' + traceback.format_exc().strip().splitlines()[-1], CMD_NAME)


class _DestroyHandler(adsk.core.CommandEventHandler):
    def __init__(self):
        super().__init__()

    def notify(self, args):
        global _loop, _last
        _loop = None
        _last = None
        del _cuts[:]
        _clear_preview()
        _cmd_handlers.clear()


class _CmdCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self):
        super().__init__()

    def notify(self, args):
        global _loop, _pos, _params, _last
        try:
            _dbg('commande creee')
            _loop, _pos, _last = None, 0.0, None
            del _cuts[:]
            _params = _load_prefs()
            cmd = args.command
            cmd.okButtonText = 'Couper'
            cmd.isRepeatable = True
            inputs = cmd.commandInputs
            sel = inputs.addSelectionInput('edge', 'Arete', "Clique sur une arete de la bande")
            sel.addSelectionFilter('Edges')
            # 0 mini : la selection est videe a chaque clic (une coupe par clic).
            sel.setSelectionLimits(0, 1)
            dist = inputs.addDistanceValueCommandInput('pos', 'Decalage', adsk.core.ValueInput.createByReal(0.0))
            dist.isVisible = False
            undo = inputs.addBoolValueInput('undo', 'Retirer la derniere coupe', False, '', False)
            undo.isEnabled = False
            dd = inputs.addDropDownCommandInput('forme', 'Forme', adsk.core.DropDownStyles.TextListDropDownStyle)
            for key, label in _FORMES:
                dd.listItems.add(label, _params.get('forme') == key)
            grp = inputs.addGroupCommandInput('grpPuzzle', 'Puzzle')
            gi = grp.children
            gi.addBoolValueInput('auto', 'Auto (selon la largeur)', True, '', bool(_params.get('auto', True)))
            gi.addValueInput('tete_mm', 'Diametre de tete', 'mm', adsk.core.ValueInput.createByReal(_params['tete_mm'] / 10.0))
            gi.addValueInput('col_mm', 'Largeur du col', 'mm', adsk.core.ValueInput.createByReal(_params['col_mm'] / 10.0))
            gi.addValueInput('conge_mm', 'Rayon des conges', 'mm', adsk.core.ValueInput.createByReal(_params['conge_mm'] / 10.0))
            gi.addBoolValueInput('flip', 'Inverser le cote du tenon', True, '', bool(_params.get('flip', False)))
            grp.isVisible = _params.get('forme') == 'puzzle'
            _auto_lock(inputs)
            inputs.addValueInput('jeu_mm', 'Jeu de fonctionnement', 'mm',
                                 adsk.core.ValueInput.createByReal(_params.get('jeu_mm', 0.0) / 10.0))
            inputs.addBoolValueInput('marge_auto', 'MargeAuto', True, '', bool(_params.get('marge_auto', False)))
            info = inputs.addTextBoxCommandInput('info', '', "Clique sur une arete de la bande.", 3, True)
            info.isFullWidth = True
            for evt, h in ((cmd.inputChanged, _InputChangedHandler()),
                           (cmd.validateInputs, _ValidateHandler()),
                           (cmd.executePreview, _PreviewHandler()),
                           (cmd.execute, _ExecuteHandler()),
                           (cmd.destroy, _DestroyHandler())):
                evt.add(h)
                _cmd_handlers.append(h)
        except Exception:
            _dbg('ERREUR commandCreated: ' + traceback.format_exc())
            _ui.messageBox('Erreur Jonction CNC:\n' + traceback.format_exc(), CMD_NAME)


# ---------------------------------------------------------------------------
# Palette : la carte "Jonction" lance la commande (appele par ToolkitCNC.py
# pour toute action "jonction_*")
# ---------------------------------------------------------------------------

def handle_palette_action(action, data):
    if action == 'jonction_open':
        # La palette revient au menu : tout se passe dans la commande.
        _send('jonction_force_reset', {})
        try:
            act = _ui.activeCommand
            cd = _ui.commandDefinitions.itemById(CMD_ID)
            _dbg('ouverture demandee (commande active: %s, definition: %s)' % (act, cd is not None))
            if act != CMD_ID:
                if cd is None:
                    run({})
                    cd = _ui.commandDefinitions.itemById(CMD_ID)
                ok = cd.execute()
                _dbg('execute -> %s' % ok)
        except Exception:
            _dbg('ERREUR lancement commande: ' + traceback.format_exc())


def run(context):
    global _app, _ui
    try:
        _app = adsk.core.Application.get()
        _ui = _app.userInterface
        old = _ui.commandDefinitions.itemById(CMD_ID)
        if old:
            old.deleteMe()
        cmd_def = _ui.commandDefinitions.addButtonDefinition(CMD_ID, CMD_NAME, CMD_DESC)
        h = _CmdCreatedHandler()
        cmd_def.commandCreated.add(h)
        _handlers.append(h)
    except Exception:
        if _ui:
            _ui.messageBox('Erreur au demarrage de Jonction CNC:\n' + traceback.format_exc())


def stop(context):
    try:
        _clear_preview()
        cmd_def = _ui.commandDefinitions.itemById(CMD_ID)
        if cmd_def:
            cmd_def.deleteMe()
    except Exception:
        if _ui:
            _ui.messageBox("Erreur a l'arret de Jonction CNC:\n" + traceback.format_exc())
