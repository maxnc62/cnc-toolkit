import adsk.core, adsk.fusion, traceback, os, sys, json, math, time

# Apercu fluide partage (cnc_apercu_fluide.py a la racine de ToolkitCNC) : la coupe se glisse par une
# pastille tiree a la souris, hors du cycle de commande Fusion (valide sur Traverse le 2026-11-04).
try:
    _RACINE_TK = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if _RACINE_TK not in sys.path:
        sys.path.insert(0, _RACINE_TK)
    import cnc_apercu_fluide as _caf
except Exception:
    _caf = None

# ---------------------------------------------------------------------------
# Jonction CNC - coupe un corps plat (ex. plate-bande de 100 mm qui fait le
# tour d'un fond de canape ovale ou de forme libre) en plusieurs pieces,
# placees ensuite separement sur le calpinage. Deux formes de coupe :
#   - "Droite" : coupe nette perpendiculaire au contour ;
#   - "Puzzle" : col + tete ronde raccordes par des conges (forme dessinee
#     par l'utilisateur le 2026-10-06), pour que les pieces s'emboitent.
# Aucun jeu (demande de l'utilisateur) : seul un trait de 0.01 mm separe les pieces
# (voir _cut_body).
#
# Deroule (comme "Plan le long de la trajectoire" de Fusion, demande de
# l'utilisateur le 2026-10-06) : la carte "Jonction" de la palette CNC Toolkit
# lance la commande Fusion JonctionCNCCmd ;
#   1. clic sur une arete de la bande -> le plan de coupe (orange) se place
#      au point clique, perpendiculaire a l'arete, et traverse toute la
#      largeur de la bande jusqu'a l'arete d'en face, sur toute l'epaisseur ;
#   2. une FLECHE sur l'arete se fait glisser a la souris : le plan suit le
#      contour de la face (toutes les aretes de la boucle) ;
#   3. OK ("Couper") -> une esquisse + un enlevement a travers le corps,
#      regroupes dans un groupe d'historique "Jonction N" ; pieces renommees
#      <nom>_A, _B... Relancer la commande pour chaque coupe (sur une bande
#      fermee, 1 coupe ouvre la bande, 2 coupes = 2 pieces).
#
# Geometrie du puzzle (repere local u = en travers de la bande, de 0 au bord
# clique a W au bord oppose ; v = le long de l'arete) : ligne de base v = 0,
# tete ronde (centre (c, h), rayon R) raccordee a la ligne de base par deux
# conges de rayon r tangents a la ligne de base ET a la tete. Le col vaut
# 2*(a - r), a = demi-ecart des centres de conges. Un decalage d donne un
# profil exactement parallele (ligne v = d, tete R + d, conges r - d) : le
# trait de coupe est la bande entre les profils -d et +d.
# ---------------------------------------------------------------------------

CMD_ID = 'JonctionCNCCmd'
CMD_NAME = 'Jonction CNC'
CMD_DESC = 'Coupe un corps plat en plusieurs pieces (coupe droite ou puzzle) a un endroit choisi en faisant glisser une fleche le long du contour'
PALETTE_ID = 'ToolkitCNC_Palette'

_ADDIN_DIR = os.path.dirname(os.path.abspath(__file__))
_PREFS_FILE = os.path.join(_ADDIN_DIR, 'jonction_prefs.json')
_DEBUG_LOG = os.path.join(_ADDIN_DIR, 'jonction_debug.log')

DEFAULTS = {
    'forme': 'droite',    # 'droite' ou 'puzzle'
    'fraise_mm': 8.0,     # diametre de fraise -> rayon mini des angles rentrants
    'tete_mm': 30.0,      # diametre de la tete ronde
    'col_mm': 18.0,       # largeur du col (plus petite largeur du tenon)
    'conge_mm': 5.0,      # rayon des conges de raccordement
    'nb_tenons': 1,
    'flip': False,        # cote vers lequel part le tenon
    'auto': True,         # tete / col / conges calcules d'apres la largeur
    'jeu_mm': 0.0,        # jeu de fonctionnement (largeur du trait de coupe)
    'marge_auto': False,  # jeu de Marge CNC applique sur les faces coupees
    'param': True,        # trait parametrique (suit la courbe) : plus lent que le trait fixe
    'dup': False,         # dupliquer la coupe sur les corps empiles au-dessus / en dessous
    'dup_haut': True,     # True : corps du dessus ; False : corps du dessous
    'dup_n': 1,           # nombre de corps empiles coupes en plus
    'renf': 'aucun',      # renfort : 'aucun' ou 'cale' (cale posee sur la jonction)
    'renf_am_mm': 10.0,   # cale : longueur en amont de la jonction
    'renf_av_mm': 10.0,   # cale : longueur en aval de la jonction
}

# Mode auto (regles de l'utilisateur, 2026-10-06) : tete = largeur / 2, col =
# tete / 2, conges = 0.4 x tete (20 mm pour sa bande de 100 mm, valeur qu'il
# avait reglee a la main).
_AUTO_TETE = 0.5
_AUTO_COL = 0.5
_AUTO_CONGE = 0.4


def auto_puzzle_mm(width_mm):
    """(tete, col, conges) en mm pour une bande de width_mm."""
    tete = width_mm * _AUTO_TETE
    return round(tete, 2), round(tete * _AUTO_COL, 2), round(tete * _AUTO_CONGE, 2)

# Depassement de la coupe au-dela des deux bords de la bande (cm).
_EXT_CM = 0.5
# Largeur du trait de coupe (cm) : 0.01 mm, voir _cut_body.
_TRAIT_CM = 0.001
# Marge mini entre un tenon et un bord de bande / un autre tenon (cm).
_MARGE_TENON_CM = 0.3
# Rehausse du preview au-dessus de la face (cm) pour eviter qu'il soit
# masque par la face elle-meme.
_LIFT_CM = 0.02

_app = None
_ui = None
_handlers = []
_cmd_handlers = []
_params = dict(DEFAULTS)
_loop = None          # contour en cours (voir _build_loop)
_pos = 0.0            # position courante le long du contour (cm)
_cg_group = None
_pos0 = 0.0           # position au clic : la fleche mesure le decalage depuis ce point
_last = None          # dernier calcul (fr, g, geom, errs), dessine par executePreview
# Coupes deja placees (l'utilisateur 2026-10-12 : plusieurs coupes par commande) :
# [{'loop', 'pos', 'pos0', 'last'}]. La coupe en cours (celle qui a la
# fleche) reste dans _loop/_pos/_pos0/_last.
_cuts = []
_act = 0              # rang de la coupe en cours parmi toutes les coupes (fenetres en bas a gauche)
_syncing = False      # True pendant que la commande vide elle-meme la selection
_bloc_t = [0.0]       # clic sur une fenetre de la vue : le clic ne doit pas ajouter de coupe


def _dbg(msg):
    try:
        with open(_DEBUG_LOG, 'a', encoding='utf-8') as f:
            f.write(time.strftime('%Y-%m-%d %H:%M:%S') + ' ' + str(msg) + '\n')
    except Exception:
        pass


def _load_prefs():
    p = dict(DEFAULTS)
    try:
        with open(_PREFS_FILE, 'r', encoding='utf-8') as f:
            saved = json.load(f)
        for k in DEFAULTS:
            if k in saved:
                p[k] = saved[k]
        # 2026-11-02 : defaut des cales passe de 20 a 10 mm
        for k in ('renf_am_mm', 'renf_av_mm'):
            if p.get(k) == 20.0:
                p[k] = 10.0
    except Exception:
        pass
    return p


def _save_prefs(p):
    try:
        with open(_PREFS_FILE, 'w', encoding='utf-8') as f:
            json.dump({k: p.get(k, DEFAULTS[k]) for k in DEFAULTS}, f, indent=2)
    except Exception:
        pass


def _palette():
    try:
        return _ui.palettes.itemById(PALETTE_ID)
    except Exception:
        return None


def _send(action, payload):
    pal = _palette()
    if pal is None:
        return
    try:
        pal.sendInfoToHTML(action, json.dumps(payload))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Parametres et profil puzzle (fonctions pures, unites internes Fusion = cm)
# ---------------------------------------------------------------------------

def params_cm(p):
    """Parametres (mm) -> grandeurs geometriques (cm)."""
    def f(k):
        try:
            return float(p.get(k, DEFAULTS[k]))
        except Exception:
            return float(DEFAULTS[k])
    try:
        nb = max(1, int(p.get('nb_tenons', 1)))
    except Exception:
        nb = 1
    return {
        'rf': f('fraise_mm') / 20.0,      # rayon de fraise
        'R': f('tete_mm') / 20.0,         # rayon de tete
        'col': f('col_mm') / 10.0,
        'r': f('conge_mm') / 10.0,
        # Pas de jeu (demande de l'utilisateur) : seulement le trait de 0.01 mm
        # qui separe les pieces, voir _cut_body.
        # Jeu de fonctionnement = largeur du trait de coupe (0.01 mm mini,
        # pour que les pieces soient bien separees, voir _cut_body).
        'jeu': max(f('jeu_mm') / 10.0, _TRAIT_CM),
        'renf': p.get('renf', 'aucun') == 'cale',
        'renf_am': f('renf_am_mm') / 10.0,
        'renf_av': f('renf_av_mm') / 10.0,
        'puzzle': p.get('forme', 'droite') == 'puzzle',
        'nb': nb,
        'flip': bool(p.get('flip', False)),
    }


def check_profile(g, width):
    """Verifie que le profil est usinable et verrouillant. Retourne
    (geom, erreurs) ; geom = {'a', 'h', 'centers', 'tab_len'} ou None."""
    errs = []
    R, col, r, jeu, nb = g['R'], g['col'], g['r'], g['jeu'], g['nb']
    if R * 2 <= col + 1e-6:
        errs.append('La tete doit etre plus large que le col (sinon rien ne verrouille).')
    if r <= jeu / 2 + 1e-6:
        errs.append('Le jeu doit rester plus petit que le diametre des conges.')
    if errs:
        return None, errs
    a = col / 2 + r
    disc = (R + r) ** 2 - a ** 2
    if disc <= 1e-9:
        return None, ['Combinaison tete/col/conges impossible.']
    h = r + math.sqrt(disc)
    centers = [width * (k + 0.5) / nb for k in range(nb)]
    if width > 0:
        if centers[0] - a < _MARGE_TENON_CM or width - centers[-1] - a < _MARGE_TENON_CM:
            errs.append('Bande trop etroite pour %d tenon(s) de cette taille.' % nb)
        elif nb > 1 and (width / nb) - 2 * a < _MARGE_TENON_CM:
            errs.append('Tenons trop rapproches : reduis leur nombre ou leur taille.')
    return {'a': a, 'h': h, 'centers': centers, 'tab_len': h + R}, errs


def profile_segments(g, geom, width, d):
    """Chaine du profil decale de d (cm, vers le cote femelle), de u = -EXT
    a u = W + EXT. Segments en coordonnees locales (u, v) :
      ('L', (u0, v0), (u1, v1))
      ('A', (cu, cv), rayon, angle_debut, angle_fin)   (angles en radians)
    """
    R, r = g['R'], g['r']
    a, h = geom['a'], geom['h']
    segs = []
    u_prev = -_EXT_CM
    th = math.atan2(h - r, a)  # angle du centre de tete vu du conge gauche
    for c in geom['centers']:
        segs.append(('L', (u_prev, d), (c - a, d)))
        # conge gauche : centre (c-a, r), de -90 deg a th (sens trigo)
        segs.append(('A', (c - a, r), r - d, -math.pi / 2, th))
        # tete : centre (c, h), de pi+th a -th en passant par le haut (horaire)
        segs.append(('A', (c, h), R + d, math.pi + th, -th))
        # conge droit : centre (c+a, r), de pi-th a 3pi/2 (sens trigo)
        segs.append(('A', (c + a, r), r - d, math.pi - th, 1.5 * math.pi))
        u_prev = c + a
    segs.append(('L', (u_prev, d), (width + _EXT_CM, d)))
    return segs


def _arc_pt(seg, t):
    _, (cu, cv), rad, a0, a1 = seg
    ang = a0 + (a1 - a0) * t
    return (cu + rad * math.cos(ang), cv + rad * math.sin(ang))


def _seg_start(seg):
    return seg[1] if seg[0] == 'L' else _arc_pt(seg, 0.0)


def _seg_end(seg):
    return seg[2] if seg[0] == 'L' else _arc_pt(seg, 1.0)


def _reverse(segs):
    out = []
    for s in reversed(segs):
        if s[0] == 'L':
            out.append(('L', s[2], s[1]))
        else:
            out.append(('A', s[1], s[2], s[4], s[3]))
    return out


def sample_profile(segs, step_deg=5.0):
    """Polyligne (u, v) du profil, arcs echantillonnes - preview."""
    pts = []
    for s in segs:
        if s[0] == 'L':
            if not pts:
                pts.append(s[1])
            pts.append(s[2])
        else:
            n = max(2, int(abs(math.degrees(s[4] - s[3])) / step_deg) + 1)
            for i in range(0 if not pts else 1, n + 1):
                pts.append(_arc_pt(s, i / n))
    return pts


# ---------------------------------------------------------------------------

def _on_face(face, pt, ev=None):
    try:
        if ev is None:
            ev = face.evaluator
        ok, prm = ev.getParameterAtPoint(pt)
        if not ok:
            return False
        ok2, proj = ev.getPointAtParameter(prm)
        if ok2 and proj.distanceTo(pt) > 0.01:
            return False
        return ev.isParameterOnFace(prm)
    except Exception:
        return False


def _edge_len(edge):
    ev = edge.evaluator
    ok, p0, p1 = ev.getParameterExtents()
    ok2, length = ev.getLengthAtParameter(p0, p1)
    return p0, p1, length


def _param_at(ev, pt):
    """Parametre de l'arete le plus proche de pt. getParameterAtPoint ne
    suffit pas : verifie en direct, sur un arc d'anneau deja coupe
    (parametres de -2pi a 0), il renvoie 0 pour un point a 90 deg (le coin
    de l'arc) -> on verifie le resultat et on cherche sinon par
    echantillonnage + affinage."""
    ok, p0, p1 = ev.getParameterExtents()
    ok, prm = ev.getParameterAtPoint(pt)
    if ok and p0 - 1e-9 <= prm <= p1 + 1e-9:
        ok2, q = ev.getPointAtParameter(prm)
        if ok2 and q.distanceTo(pt) < 1e-3:
            return prm

    eps = (p1 - p0) * 1e-9

    def dist(t):
        try:
            ok3, q3 = ev.getPointAtParameter(min(max(t, p0 + eps), p1 - eps))
            return q3.distanceTo(pt) if ok3 else 1e9
        except Exception:
            return 1e9
    n = 400
    best = min((p0 + (p1 - p0) * i / n for i in range(n + 1)), key=dist)
    lo, hi = max(p0, best - (p1 - p0) / n), min(p1, best + (p1 - p0) / n)
    for _ in range(40):
        m1, m2 = lo + (hi - lo) / 3, hi - (hi - lo) / 3
        if dist(m1) < dist(m2):
            hi = m2
        else:
            lo = m1
    return min(max((lo + hi) / 2, p0 + eps), p1 - eps)


def _pick_top_face(edge, click_pt):
    """Parmi les faces de l'arete, la face PLANE la plus grande dont la
    normale est perpendiculaire a l'arete au point clique (= le dessus ou
    le dessous de la bande, jamais le chant)."""
    ev = edge.evaluator
    prm = _param_at(ev, click_pt)
    ok, tan = ev.getFirstDerivative(prm)
    tan.normalize()
    best = None
    for f in edge.faces:
        try:
            if f.geometry.surfaceType != adsk.core.SurfaceTypes.PlaneSurfaceType:
                continue
            n = f.geometry.normal
            if abs(n.dotProduct(tan)) > 0.05:
                continue
            if best is None or f.area > best.area:
                best = f
        except Exception:
            continue
    return best


def _build_loop(edge, click_pt):
    """Contour ferme de la face du dessus contenant l'arete cliquee.
    Retourne (loop, position_cm) ou (None, erreur).

    Tout le calcul se fait dans l'espace du COMPOSANT du corps (arete et
    face natives) : verifie en direct, l'evaluateur d'une face "proxy"
    (corps dans une occurrence deplacee) travaille en coordonnees du
    composant et non du monde - getParameterAtPoint avec un point monde y
    projette a des metres de la face. Le passage au monde ne sert qu'au
    preview (voir _to_world)."""
    occ = edge.assemblyContext
    if occ is not None:
        inv = occ.transform2.copy()
        inv.invert()
        click_pt = click_pt.copy()
        click_pt.transformBy(inv)
        edge = edge.nativeObject
    face = _pick_top_face(edge, click_pt)
    if face is None:
        return None, "Aucune face plane du dessus trouvee pour cette arete."
    target = None
    for lp in face.loops:
        for ce in lp.coEdges:
            try:
                if ce.edge.tempId == edge.tempId:
                    target = lp
                    break
            except Exception:
                continue
        if target is not None:
            break
    if target is None:
        return None, "Arete introuvable dans le contour de la face."
    items = []
    total = 0.0
    pos = 0.0
    for ce in target.coEdges:
        e = ce.edge
        p0, p1, length = _edge_len(e)
        items.append({'edge': e, 'opp': ce.isOpposedToEdge, 'p0': p0, 'len': length, 'start': total})
        if e.tempId == edge.tempId:
            prm = _param_at(e.evaluator, click_pt)
            ok, l = e.evaluator.getLengthAtParameter(p0, prm)
            pos = total + ((length - l) if ce.isOpposedToEdge else l)
        total += length
    return {'face': face, 'body': face.body, 'occ': occ, 'items': items, 'total': total}, pos


def _eval_loop(loop, s):
    """Point et tangente (sens du contour) a l'abscisse s (cm)."""
    memo = loop.get('memo')
    if memo is not None and memo[0] == s:
        return memo[1].copy(), memo[2].copy()
    pt, tan = _eval_loop_raw(loop, s)
    loop['memo'] = (s, pt.copy(), tan.copy())
    return pt, tan


def _eval_loop_raw(loop, s):
    total = loop['total']
    s = s % total if total > 0 else 0.0
    it = loop['items'][-1]
    for cand in loop['items']:
        if s <= cand['start'] + cand['len'] + 1e-9:
            it = cand
            break
    l = min(max(s - it['start'], 0.0), it['len'])
    if it['opp']:
        l = it['len'] - l
    ev = it['edge'].evaluator
    ok, prm = ev.getParameterAtLength(it['p0'], l)
    ok, pt = ev.getPointAtParameter(prm)
    ok, tan = ev.getFirstDerivative(prm)
    if it['opp']:
        tan.scaleBy(-1)
    return pt, tan


def _frame_at(loop, s, flip):
    """Repere local de la jonction a l'abscisse s : origine O sur l'arete,
    N en travers de la bande (vers l'interieur de la face), V le long de
    l'arete (cote femelle), n normale sortante de la face ; largeur W de la
    bande mesuree jusqu'au bord oppose."""
    face = loop['face']
    fev = loop.get('fev')
    if fev is None:
        fev = loop['fev'] = face.evaluator
    O, T = _eval_loop(loop, s)
    ok, n = fev.getNormalAtPoint(O)
    n.normalize()
    t = T.copy()
    k = n.copy(); k.scaleBy(t.dotProduct(n))
    t.subtract(k)
    if t.length < 1e-9:
        return None
    t.normalize()
    N = n.crossProduct(t)
    N.normalize()

    def at(u):
        p = O.copy(); w = N.copy(); w.scaleBy(u); p.translateBy(w)
        return p

    if not _on_face(face, at(0.05), fev):
        N.scaleBy(-1)
        if not _on_face(face, at(0.05), fev):
            return None
    # Largeur : on repart de la largeur precedente (+-2 mm) si elle encadre
    # encore le bord (cas courant en faisant glisser la fleche : quelques
    # appels au lieu d'une cinquantaine) ; sinon on avance par pas de 2.5 mm
    # jusqu'a sortir de la face. Puis dichotomie au 1/100 mm.
    step = 0.25
    u_in, u_out = 0.05, None
    hint = loop.get('w_hint')
    if hint and hint > 0.3 and _on_face(face, at(hint - 0.001), fev) and not _on_face(face, at(hint + 0.001), fev):
        # Meme largeur a 1/100 mm pres (bande reguliere) : 2 tests suffisent.
        u_in = u_out = hint
    elif hint and hint > 0.3 and _on_face(face, at(hint - 0.2), fev) and not _on_face(face, at(hint + 0.2), fev):
        u_in, u_out = hint - 0.2, hint + 0.2
    u = u_in
    while u_out is None and u < 500.0:
        u += step
        if _on_face(face, at(u), fev):
            u_in = u
        else:
            u_out = u
            break
    if u_out is None:
        return None
    for _ in range(14 if u_out - u_in > 0.5 else 10 if u_out > u_in else 0):
        mid = (u_in + u_out) / 2
        if _on_face(face, at(mid), fev):
            u_in = mid
        else:
            u_out = mid
    loop['w_hint'] = u_in
    V = t.copy()
    if flip:
        V.scaleBy(-1)
    return {'O': O, 'N': N, 'V': V, 'n': n, 'W': u_in, 's': s,
            'body': loop['body'], 'occ': loop['occ'], 'face': face}


def _local_to_comp(fr, u, v, lift=0.0):
    """Point (u, v) du repere local -> espace du composant du corps."""
    p = fr['O'].copy()
    for vec, k in ((fr['N'], u), (fr['V'], v), (fr['n'], lift)):
        w = vec.copy(); w.scaleBy(k); p.translateBy(w)
    return p


def _to_world(fr, p):
    if fr.get('occ') is not None:
        p = p.copy()
        p.transformBy(fr['occ'].transform2)
    return p


def _thickness(fr):
    """Epaisseur du corps sous le point O (cm) : distance a la face plane
    parallele a la face du dessus la plus proche (le dessous)."""
    best = None
    O, n = fr['O'], fr['n']
    for f in fr['body'].faces:
        try:
            if f.geometry.surfaceType != adsk.core.SurfaceTypes.PlaneSurfaceType:
                continue
            pl = f.geometry
            if abs(abs(pl.normal.dotProduct(n)) - 1.0) > 1e-4:
                continue
            d = abs(pl.origin.vectorTo(O).dotProduct(n))
            if d > 1e-3 and (best is None or d < best):
                best = d
        except Exception:
            continue
    return best if best is not None else 1.8


def _find_top_face(body, frc):
    """Retrouve sur le corps (natif) la face plane du dessus qui porte la
    coupe - les references d'avant decoupe ne sont plus fiables."""
    probe = _local_to_comp(frc, min(0.05, frc['W'] / 2), 0.0)
    for f in body.faces:
        try:
            if f.geometry.surfaceType != adsk.core.SurfaceTypes.PlaneSurfaceType:
                continue
            n = f.geometry.normal
            if abs(abs(n.dotProduct(frc['n'])) - 1.0) > 1e-4:
                continue
            if _on_face(f, probe):
                return f
        except Exception:
            continue
    return None


def _segments(g, geom, W, d):
    """Chaine du trait (u, v) decale de d : ligne droite, ou profil puzzle
    (voir profile_segments) si la forme est "puzzle"."""
    if g['puzzle'] and geom is not None:
        return profile_segments(g, geom, W, d)
    return [('L', (-_EXT_CM, d), (W + _EXT_CM, d))]


def _check(g, fr):
    """(geom, erreurs) pour la coupe fr ; geom None en coupe droite."""
    if fr is None:
        return None, ["Impossible de mesurer la bande a cet endroit (coin ou bord non parallele) : deplace un peu la fleche."]
    if not g['puzzle']:
        return None, []
    return check_profile(g, fr['W'])


# ---------------------------------------------------------------------------
# Preview (CustomGraphics, aucune modification du document)
# ---------------------------------------------------------------------------

def _clear_preview():
    global _cg_group
    for grp in (_cg_group if isinstance(_cg_group, list) else [_cg_group]):
        try:
            if grp is not None:
                grp.deleteMe()
        except Exception:
            pass
    _cg_group = None


_PREV_ID = 'JonctionCNC_preview'
_no_draw = [False]


def _balayer_apercus():
    """Supprime tout apercu orange oublie (groupes de graphiques a notre id)."""
    try:
        design = adsk.fusion.Design.cast(_app.activeProduct)
        gs = design.rootComponent.customGraphicsGroups
        for i in range(gs.count - 1, -1, -1):
            try:
                g_ = gs.item(i)
                if g_.id == _PREV_ID:
                    g_.deleteMe()
            except Exception:
                pass
    except Exception:
        pass


_shim_hit = []    # [((coupe, corps), [8 coins en coordonnees monde])] des boites de cale du preview


def _draw_all(refresh=True):
    """Toutes les coupes : les coupes deja placees en orange clair, celle
    en cours en orange (rouge si elle est invalide)."""
    global _cg_group
    if _no_draw[0]:
        return
    _clear_preview()
    _balayer_apercus()
    del _shim_hit[:]
    groups = []
    todo = []
    for j, c in enumerate(_all_cuts()):
        if c.get('last') is not None:
            actif = _loop is not None and j == min(_act, len(_cuts))
            todo.append((j, c['last'], (255, 90, 0) if actif else (255, 160, 90)))
    for j, (fr, g, geom, errs), color in todo:
        if fr is None:
            continue
        # la coupe, puis la meme sur les corps empiles choisis
        for b, frx in enumerate([fr] + list(fr.get('stack') or [])):
            _draw_preview(frx, g, geom, color if not errs else (220, 30, 30), refresh=False, tag=(j, b))
            if _cg_group is not None:
                groups.append(_cg_group)
                _cg_group = None
    _cg_group = groups or None
    _ov_maj()
    if refresh:
        try:
            _app.activeViewport.refresh()
        except Exception:
            pass


def _draw_preview(fr, g, geom, color=(255, 90, 0), refresh=True, tag=None):
    """Le trait de coupe comme un "ruban" vertical sur toute l'epaisseur :
    contour epais + surface semi-transparente (comme un plan de Fusion)."""
    global _cg_group
    _clear_preview()
    if fr is None:
        return
    try:
        design = adsk.fusion.Design.cast(_app.activeProduct)
        grp = design.rootComponent.customGraphicsGroups.add()
        try:
            grp.id = _PREV_ID
        except Exception:
            pass
        t = fr.get('t') or _thickness(fr)
        uv = sample_profile(_segments(g, geom, fr['W'], 0.0))
        # Calcul en flottants (sans objets Point3D : 4x plus rapide).
        O, N, V, nn = ([q.x, q.y, q.z] for q in (fr['O'], fr['N'], fr['V'], fr['n']))
        m = fr['occ'].transform2.asArray() if fr.get('occ') is not None else None

        def P(u, v, w):
            x, y, z = (O[i] + N[i] * u + V[i] * v + nn[i] * w for i in range(3))
            if m is not None:
                x, y, z = (m[4 * r] * x + m[4 * r + 1] * y + m[4 * r + 2] * z + m[4 * r + 3] for r in range(3))
            return [x, y, z]
        n = len(uv)
        flat = []
        for w in (_LIFT_CM, -t - _LIFT_CM):
            for (u, v) in uv:
                flat += P(u, v, w)
        coords = adsk.fusion.CustomGraphicsCoordinates.create(flat)
        # Contour : profil en haut, en bas, et les deux bouts.
        idx = []
        for k in range(n - 1):
            idx += [k, k + 1, n + k, n + k + 1]
        idx += [0, n, n - 1, 2 * n - 1]
        lines = grp.addLines(coords, idx, False)
        try:
            lines.color = adsk.fusion.CustomGraphicsSolidColorEffect.create(
                adsk.core.Color.create(color[0], color[1], color[2], 255))
            lines.weight = 2.0          # traits affines (2026-11-04)
            lines.depthPriority = 1
        except Exception:
            pass
        # Ruban semi-transparent (deux faces pour etre vu des deux cotes).
        try:
            tri = []
            for k in range(n - 1):
                a, b, c, d = k, k + 1, n + k + 1, n + k
                tri += [a, b, c, a, c, d, a, c, b, a, d, c]
            Vv = fr['V']
            nrm = [Vv.x, Vv.y, Vv.z] * (2 * n)
            mesh = grp.addMesh(coords, tri, nrm, tri)
            mesh.color = adsk.fusion.CustomGraphicsSolidColorEffect.create(
                adsk.core.Color.create(color[0], color[1], color[2], 90))
        except Exception:
            _dbg('preview ruban: ' + traceback.format_exc().strip().splitlines()[-1])
        if g.get('renf'):
            # La cale : boite bleue translucide (de v1 a v2 le long de la
            # bande, sur toute la largeur, de l'epaisseur de la bande, du
            # cote ou elle sera posee), deplacee avec la fleche.
            try:
                v1, v2 = _strip_v(g, geom, fr['W'])
                sg = fr.get('shim_s') or 1
                Wd = fr['W']
                pts = []
                # la cale est posee contre la face du cote sg : au-dessus de la
                # face du dessus (sg > 0), ou sous la face du dessous (sg < 0)
                base = 0.0 if sg > 0 else -t
                for w in (base, base + sg * t):
                    for (u, v) in ((0.0, v1), (Wd, v1), (Wd, v2), (0.0, v2)):
                        pts += P(u, v, w + sg * _LIFT_CM)
                cc = adsk.fusion.CustomGraphicsCoordinates.create(pts)
                if tag is not None:
                    _shim_hit.append((tag, [tuple(pts[3 * i:3 * i + 3]) for i in range(8)]))
                edges = [0, 1, 1, 2, 2, 3, 3, 0, 4, 5, 5, 6, 6, 7, 7, 4, 0, 4, 1, 5, 2, 6, 3, 7]
                cl = grp.addLines(cc, edges, False)
                cl.color = adsk.fusion.CustomGraphicsSolidColorEffect.create(adsk.core.Color.create(40, 130, 255, 255))
                cl.weight = 2.0
                cl.depthPriority = 1
                faces = [(0, 1, 2, 3), (4, 5, 6, 7), (0, 1, 5, 4), (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7)]
                tri = []
                for (q0, q1, q2, q3) in faces:
                    tri += [q0, q1, q2, q0, q2, q3, q0, q2, q1, q0, q3, q2]
                nz = [fr['n'].x, fr['n'].y, fr['n'].z] * 8
                ms = grp.addMesh(cc, tri, nz, tri)
                ms.color = adsk.fusion.CustomGraphicsSolidColorEffect.create(adsk.core.Color.create(40, 130, 255, 80))
            except Exception:
                _dbg('preview cale: ' + traceback.format_exc().strip().splitlines()[-1])
        _cg_group = grp
        if refresh:
            # Inutile dans executePreview (Fusion redessine lui-meme) et
            # c'etait 47 ms sur ~55 par deplacement de la fleche.
            try:
                _app.activeViewport.refresh()
            except Exception:
                pass
    except Exception:
        _dbg('ERREUR _draw_preview: ' + traceback.format_exc())
        _clear_preview()


def _current_frame(g):
    return _frame_for(_loop, _pos, g)


def _frame_for(loop, pos, g):
    if loop is None:
        return None
    fr = _frame_at(loop, pos, g['flip'])
    if fr is not None:
        # Bande plate : epaisseur mesuree une fois par arete (fluidite).
        if loop.get('t') is None:
            loop['t'] = _thickness(fr)
        fr['t'] = loop['t']
        fr['comp'] = loop.get('comp') or loop['body'].parentComponent
        loop['comp'] = fr['comp']
    return fr


def _compute(loop, pos, p):
    """(fr, g, geom, errs) d'une coupe ; en mode auto, tete/col/conges
    suivent la largeur de la bande a CET endroit."""
    g = params_cm(p)
    fr = None
    try:
        fr = _frame_for(loop, pos, g)
    except Exception:
        _dbg('ERREUR _frame_at: ' + traceback.format_exc())
    if fr is not None and p.get('auto', True):
        q = dict(p)
        q['tete_mm'], q['col_mm'], q['conge_mm'] = auto_puzzle_mm(fr['W'] * 10.0)
        g = params_cm(q)
    geom, errs = _check(g, fr)
    if fr is not None:
        # Cote de la cale par rapport a la normale n : vers les corps
        # empiles quand la duplication est active, sinon sur la face cliquee.
        want = _up_sign(loop, fr) * (1 if p.get('dup_haut', True) else -1) if p.get('dup') else 1
        fr['shim_s'] = want
    if fr is not None and p.get('dup'):
        try:
            lst = _stack(loop, fr, p.get('dup_haut', True))
        except Exception:
            _dbg('ERREUR _stack: ' + traceback.format_exc())
            lst = []
        fr['stack_avail'] = len(lst)
        fr['stack'] = lst[:max(1, int(p.get('dup_n', 1)))]
    if fr is not None:
        # cale basculee de l'autre cote : pour toute la jonction (shim_flip)
        # et/ou pour certains corps (shim_ov = rangs des corps, 0 = clique)
        flip = bool(p.get('shim_flip'))
        ov = set(p.get('shim_ov') or ())
        for i, f in enumerate([fr] + list(fr.get('stack') or [])):
            if f.get('shim_s') is not None and (flip != (i in ov)):
                f['shim_s'] = -f['shim_s']
    return fr, g, geom, errs


# ---------------------------------------------------------------------------
# Creation
# ---------------------------------------------------------------------------

_shim_start = [None]    # index chronologie de l'esquisse de la cale (debut du groupe Jonction)
_shim_tokens = []       # corps de cale crees par la coupe en cours (ne sont pas des pieces)


# ---------------------------------------------------------------------------
# Esquisse PARAMETRIQUE (v15) : le trait de coupe reste attache aux aretes de
# la bande par des contraintes, et suit donc la courbe quand on la modifie.
# ---------------------------------------------------------------------------

def _edge_near(face, pt, tol=0.02):
    """Arete de la face (tous contours) passant par pt, ou None."""
    best, bd = None, tol
    for lp in face.loops:
        for e in lp.edges:
            try:
                ev = e.evaluator
                ok, prm = ev.getParameterAtPoint(pt)
                if not ok:
                    continue
                ok, q = ev.getPointAtParameter(prm)
                if ok and q.distanceTo(pt) < bd:
                    best, bd = e, q.distanceTo(pt)
            except Exception:
                continue
    return best


def _near_vertex(edge, pt):
    vs = [v for v in (edge.startVertex, edge.endVertex) if v is not None]
    if not vs:
        raise RuntimeError('arete sans sommet')
    return min(vs, key=lambda v: v.geometry.distanceTo(pt))


def _param_sketch(sk, face, frc, g, geom):
    """Remplit l'esquisse sk (sur face) : trait de coupe contraint sur les deux
    aretes de la bande. Retourne {'Lc': ligne de construction, 'K0': ...}.
    Leve une exception si la geometrie n'est pas celle attendue."""
    W, E = frc['W'], _EXT_CM
    d = g['jeu'] / 2
    P1w = _local_to_comp(frc, 0.0, 0.0)
    P2w = _local_to_comp(frc, W, 0.0)
    e1 = _edge_near(face, P1w)
    e2 = _edge_near(face, P2w)
    if e1 is None or e2 is None or e1.tempId == e2.tempId:
        raise RuntimeError('aretes de la bande introuvables')
    v1_ = _near_vertex(e1, P1w)
    v2_ = _near_vertex(e2, P2w)
    gc, dm, lines, arcs = sk.geometricConstraints, sk.sketchDimensions, sk.sketchCurves.sketchLines, sk.sketchCurves.sketchArcs
    AL = adsk.fusion.DimensionOrientations.AlignedDimensionOrientation

    def S(u, v):
        return sk.modelToSketchSpace(_local_to_comp(frc, u, v, 0.0))

    pe1 = sk.project(e1).item(0)
    pe2 = sk.project(e2).item(0)
    for pe in (pe1, pe2):
        pe.isConstruction = True      # ne decoupe pas les profils
    pv1 = sk.project(v1_).item(0)
    pv2 = sk.project(v2_).item(0)
    _lap('p:projections')
    p1 = sk.sketchPoints.add(S(0, 0))
    p2 = sk.sketchPoints.add(S(W, 0))
    Lc = lines.addByTwoPoints(S(-E, 0), S(W + E, 0))
    Lc.isConstruction = True
    gc.addCoincident(p1, pe1)
    gc.addCoincident(p2, pe2)
    dm.addDistanceDimension(p1, pv1, AL, S(-1, -3))
    dm.addDistanceDimension(p2, pv2, AL, S(W + 1, -3))
    gc.addCoincident(p1, Lc)
    gc.addCoincident(p2, Lc)
    dm.addDistanceDimension(Lc.startSketchPoint, p1, AL, S(-E / 2, -1))
    dm.addDistanceDimension(p2, Lc.endSketchPoint, AL, S(W + E / 2, -1))
    _lap('p:ligne')
    expect = []   # (point d'esquisse, position attendue)
    chain = []
    if g['puzzle'] and geom is not None:
        a, h, R, r = geom['a'], geom['h'], g['R'], g['r']
        th = math.atan2(h - r, a)

        def mid(cu, cv, rad, a0, a1):
            t = (a0 + a1) / 2
            return (cu + rad * math.cos(t), cv + rad * math.sin(t))

        def EP(arc, uv):
            q = S(*uv)
            s_, e_ = arc.startSketchPoint, arc.endSketchPoint
            return s_ if s_.geometry.distanceTo(q) <= e_.geometry.distanceTo(q) else e_

        prev_end = S(-E, 0)
        prev_pt = None
        first = True
        for c in geom['centers']:
            F1 = (c - a, 0); F2 = (c + a, 0)
            C1 = (c - a, r); C3 = (c + a, r); C2 = (c, h)
            J1 = (C1[0] + r * math.cos(th), C1[1] + r * math.sin(th))
            J2 = (C3[0] - r * math.cos(th), C3[1] + r * math.sin(th))
            Lx = lines.addByTwoPoints(prev_end, S(*F1))
            A1 = arcs.addByThreePoints(S(*F1), S(*mid(C1[0], C1[1], r, -math.pi / 2, th)), S(*J1))
            A2 = arcs.addByThreePoints(S(*J1), S(C2[0], C2[1] + R), S(*J2))
            A3 = arcs.addByThreePoints(S(*J2), S(*mid(C3[0], C3[1], r, math.pi - th, 1.5 * math.pi)), S(*F2))
            if first:
                first = False
                gc.addCoincident(Lx.startSketchPoint, Lc.startSketchPoint)
            else:
                gc.addCoincident(Lx.startSketchPoint, prev_pt)
                gc.addTangent(prev_A3, Lx)
            gc.addCoincident(Lx.endSketchPoint, EP(A1, F1))
            gc.addCoincident(EP(A1, J1), EP(A2, J1))
            gc.addCoincident(EP(A2, J2), EP(A3, J2))
            gc.addTangent(Lx, A1); gc.addTangent(A1, A2); gc.addTangent(A2, A3)
            gc.addCollinear(Lx, Lc)
            dm.addRadialDimension(A1, S(C1[0] - 1, C1[1] + 1))
            dm.addRadialDimension(A2, S(C2[0], C2[1] + R + 1))
            gc.addEqual(A1, A3)
            dm.addDistanceDimension(p1, EP(A1, F1), AL, S(c - a, -1.5))
            dm.addDistanceDimension(A1.centerSketchPoint, A3.centerSketchPoint, AL, S(c, -1))
            expect.append((A2.centerSketchPoint, S(*C2)))
            chain += [Lx, A1, A2, A3]
            prev_end = EP(A3, F2).geometry
            prev_pt = EP(A3, F2)
            prev_A3 = A3
        Ll = lines.addByTwoPoints(prev_pt, S(W + E, 0))
        gc.addCoincident(Ll.endSketchPoint, Lc.endSketchPoint)
        gc.addCollinear(Ll, Lc)
        gc.addTangent(prev_A3, Ll)
        chain.append(Ll)
    else:
        Lx = lines.addByTwoPoints(S(-E, 0), S(W + E, 0))
        gc.addCoincident(Lx.startSketchPoint, Lc.startSketchPoint)
        gc.addCoincident(Lx.endSketchPoint, Lc.endSketchPoint)
        chain.append(Lx)
    _lap('p:chaine')
    for cv in chain:
        cv.isConstruction = True
    col = adsk.core.ObjectCollection.create()
    for cv in chain:
        col.add(cv)
    offs = {}
    for k, sg in (('p', 1), ('m', -1)):
        offs[k] = sk.offset(col, S(-E / 2, sg * 1.0), d)
    _lap('p:offsets')
    # extremites des deux chaines : sur des perpendiculaires a Lc (sinon elles
    # ne suivent pas quand la courbe bouge)
    K1 = lines.addByTwoPoints(S(-E, -1.0), S(-E, 1.0)); K1.isConstruction = True
    K2 = lines.addByTwoPoints(S(W + E, -1.0), S(W + E, 1.0)); K2.isConstruction = True
    gc.addCoincident(Lc.startSketchPoint, K1); gc.addPerpendicular(K1, Lc)
    gc.addCoincident(Lc.endSketchPoint, K2); gc.addPerpendicular(K2, Lc)
    dm.addDistanceDimension(K1.startSketchPoint, K1.endSketchPoint, AL, S(-E - 1, 0))
    dm.addDistanceDimension(K2.startSketchPoint, K2.endSketchPoint, AL, S(W + E + 1, 0))
    ends = {}
    for k, v in offs.items():
        for i in range(v.count):
            ln = v.item(i)
            if not ln.objectType.endswith('SketchLine'):
                continue
            for pt_ in (ln.startSketchPoint, ln.endSketchPoint):
                for tag, K, ref in (('s', K1, Lc.startSketchPoint), ('e', K2, Lc.endSketchPoint)):
                    dp = pt_.geometry.distanceTo(ref.geometry)
                    other = ln.endSketchPoint if pt_ == ln.startSketchPoint else ln.startSketchPoint
                    if dp < E + 3 * d + 0.05 and dp < other.geometry.distanceTo(ref.geometry):
                        ends[(k, tag)] = (pt_, K)
    if len(ends) != 4:
        raise RuntimeError('extremites du trait introuvables (%d)' % len(ends))
    for (k, tag), (pt_, K) in ends.items():
        gc.addCoincident(pt_, K)
    lines.addByTwoPoints(ends[('p', 's')][0], ends[('m', 's')][0])
    lines.addByTwoPoints(ends[('p', 'e')][0], ends[('m', 'e')][0])
    _lap('p:extremites')
    # axe de reference au milieu de la bande (pour la cale)
    K0 = None
    if g.get('renf'):
        Sg = lines.addByTwoPoints(p1, p2); Sg.isConstruction = True
        M = sk.sketchPoints.add(S(W / 2, 0))
        gc.addMidPoint(M, Sg)
        K0 = lines.addByTwoPoints(S(W / 2, -1.0), S(W / 2, 1.0)); K0.isConstruction = True
        gc.addCoincident(M, K0); gc.addPerpendicular(K0, Lc)
        dm.addDistanceDimension(K0.startSketchPoint, K0.endSketchPoint, AL, S(W / 2 + 1, 0))
    _lap('p:axe')
    # controle : la geometrie resolue est bien celle voulue
    for pt_, want in [(p1, S(0, 0)), (p2, S(W, 0)), (Lc.startSketchPoint, S(-E, 0)), (Lc.endSketchPoint, S(W + E, 0))] + expect:
        if pt_.geometry.distanceTo(want) > 0.02:
            raise RuntimeError('contraintes mal resolues')
    return {'Lc': Lc, 'K0': K0}


def _strip_v(g, geom, W):
    """(v1, v2) : bornes de la cale le long de la bande (repere local, cm) =
    etendue du trait de coupe - amont, + aval."""
    d = g['jeu'] / 2
    vs = [pt[1] for dd in (d, -d) for pt in sample_profile(_segments(g, geom, W, dd))]
    return min(vs) - g['renf_am'], max(vs) + g['renf_av']


def _face_side(body, frc, s, W, v1, v2):
    """(face, d) : face plane parallele a la bande, tournee vers s * n, la plus
    en avant de ce cote, qui porte la cale (d = decalage le long de n)."""
    nn = frc['n']
    probes = [(min(0.05, W / 2), v1 + 0.05), (max(W - 0.05, W / 2), v2 - 0.05),
              (min(0.05, W / 2), v2 - 0.05), (max(W - 0.05, W / 2), v1 + 0.05)]
    cands = []
    for f in body.faces:
        try:
            pl = adsk.core.Plane.cast(f.geometry)
            if pl is None or abs(abs(pl.normal.dotProduct(nn)) - 1.0) > 1e-4:
                continue
            ev = f.evaluator
            ok, on = ev.getNormalAtPoint(f.pointOnFace)
            if not ok or on.dotProduct(nn) * s <= 0:
                continue
            d = frc['O'].vectorTo(pl.origin).dotProduct(nn)
            if any(_on_face(f, _local_to_comp(frc, u, v, d), ev) for (u, v) in probes):
                cands.append((d * s, d, f))
        except Exception:
            continue
    if not cands:
        return None, 0.0
    best = max(cands, key=lambda c: c[0])
    return best[2], best[1]


def _make_shim_core(design, comp, body, frc, g, geom, pinfo, extm=1.0):
    """Cale de renfort : esquisse sur la face de la bande (deux segments
    paralleles, en amont et en aval de la coupe, qui coupent les aretes de la
    face projetees), puis extrusion d'un NOUVEAU corps de l'epaisseur de la
    bande, du cote voulu. Retourne un message ('' si tout va bien)."""
    W = frc['W']
    t = frc.get('t') or _thickness(frc)
    v1, v2 = _strip_v(g, geom, W)
    face, dface = _face_side(body, frc, frc.get('shim_s', 1), W, v1, v2)
    if face is None:
        return 'Renfort : face introuvable sur ' + body.name
    sk = comp.sketches.addWithoutEdges(face)
    sk.name = 'Renfort'
    sk.isComputeDeferred = True
    start = sk.timelineObject.index if design.designType == adsk.fusion.DesignTypes.ParametricDesignType else None

    def P(u, v):
        return sk.modelToSketchSpace(_local_to_comp(frc, u, v, dface))
    ext = (0.5 * W + 0.5) * extm
    done = False
    if pinfo is not None:
        try:
            sk.isComputeDeferred = False
            AL = adsk.fusion.DimensionOrientations.AlignedDimensionOrientation
            gc, dm, lns = sk.geometricConstraints, sk.sketchDimensions, sk.sketchCurves.sketchLines
            Lcp = sk.project(pinfo['Lc']).item(0)
            K0p = sk.project(pinfo['K0']).item(0)
            Lcp.isConstruction = True
            K0p.isConstruction = True
            for v in (v1, v2):
                ln = lns.addByTwoPoints(P(-ext, v), P(W + ext, v))
                gc.addParallel(ln, Lcp)
                dm.addOffsetDimension(Lcp, ln, P(W + ext + 1, v))
                dm.addDistanceDimension(ln.startSketchPoint, ln.endSketchPoint, AL, P(W / 2, v + 1))
                Ma = sk.sketchPoints.add(P(W / 2, v))
                gc.addMidPoint(Ma, ln)
                gc.addCoincident(Ma, K0p)
                for q, want in ((ln.startSketchPoint, P(-ext, v)), (ln.endSketchPoint, P(W + ext, v))):
                    if q.geometry.distanceTo(want) > 0.02:
                        raise RuntimeError('cale mal resolue')
            sk.isComputeDeferred = True
            done = True
        except Exception:
            _dbg('cale parametrique impossible: ' + traceback.format_exc())
            try:
                sk.deleteMe()
            except Exception:
                pass
            raise _ParamFail()
    if not done:
        for v in (v1, v2):
            sk.sketchCurves.sketchLines.addByTwoPoints(P(-ext, v), P(W + ext, v))
    # aretes de la face (tous les contours) qui passent dans la cale : les
    # bords de la bande, et les mortaises s'il y en a (la cale les garde)
    O, V = frc['O'], frc['V']
    for lp in face.loops:
        for e in lp.edges:
            try:
                bb = e.boundingBox
                lo = hi = None
                for x in (bb.minPoint.x, bb.maxPoint.x):
                    for y in (bb.minPoint.y, bb.maxPoint.y):
                        for z in (bb.minPoint.z, bb.maxPoint.z):
                            c = O.vectorTo(adsk.core.Point3D.create(x, y, z)).dotProduct(V)
                            lo = c if lo is None else min(lo, c)
                            hi = c if hi is None else max(hi, c)
                if hi >= v1 - 0.2 and lo <= v2 + 0.2:
                    sk.project(e)
            except Exception:
                continue
    sk.isComputeDeferred = False
    best, best_area = None, 0.0
    for pr in sk.profiles:
        try:
            ap = pr.areaProperties(adsk.fusion.CalculationAccuracy.LowCalculationAccuracy)
            rel = O.vectorTo(sk.sketchToModelSpace(ap.centroid))
            u, v = rel.dotProduct(frc['N']), rel.dotProduct(V)
            if v1 < v < v2 and -0.5 < u < W + 0.5 and ap.area > best_area:
                best, best_area = pr, ap.area
        except Exception:
            continue
    if best is None:
        try:
            info = []
            for pr in sk.profiles:
                ap = pr.areaProperties(adsk.fusion.CalculationAccuracy.LowCalculationAccuracy)
                rel = O.vectorTo(sk.sketchToModelSpace(ap.centroid))
                info.append((round(ap.area, 3), round(rel.dotProduct(frc['N']), 2), round(rel.dotProduct(V), 2)))
            _dbg('cale: profil introuvable (W=%.2f v1=%.2f v2=%.2f ext=%.2f param=%s) profils(aire,u,v)=%s' % (
                W, v1, v2, ext, pinfo is not None, info[:12]))
        except Exception:
            pass
        sk.deleteMe()
        return 'Renfort : profil de la cale introuvable'
    profs = adsk.core.ObjectCollection.create()
    profs.add(best)
    exts = comp.features.extrudeFeatures
    inp = exts.createInput(profs, adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
    nrm = sk.xDirection.crossProduct(sk.yDirection)
    want = frc['n'].copy()
    want.scaleBy(frc.get('shim_s', 1))
    sens = adsk.fusion.ExtentDirections.PositiveExtentDirection if nrm.dotProduct(want) > 0 else adsk.fusion.ExtentDirections.NegativeExtentDirection
    inp.setOneSideExtent(adsk.fusion.DistanceExtentDefinition.create(adsk.core.ValueInput.createByReal(t)), sens)
    feat = exts.add(inp)
    for b in feat.bodies:
        _shim_tokens.append(b.entityToken)
        try:
            b.name = 'Renfort_' + body.name
        except Exception:
            pass
    if start is not None:
        _shim_start[0] = start if _shim_start[0] is None else min(_shim_start[0], start)
    _lap('cale')
    return ''


class _ParamFail(Exception):
    pass


def _make_shim(design, comp, body, frc, g, geom, pinfo=None):
    """Cale parametrique si possible (lignes liees a la coupe), sinon fixe."""
    msg = None
    if pinfo is not None:
        try:
            msg = _make_shim_core(design, comp, body, frc, g, geom, pinfo)
        except _ParamFail:
            msg = None
    if msg is None:
        msg = _make_shim_core(design, comp, body, frc, g, geom, None)
    if msg.startswith('Renfort : profil'):
        # bande oblique ou courbee : les deux segments n'atteignaient pas les
        # deux bords. On recommence avec des segments plus longs.
        msg = _make_shim_core(design, comp, body, frc, g, geom, None, extm=4.0)
    return msg


def _cut_body(design, comp, body, frc, g, geom, index):
    """Une coupe : esquisse du trait (largeur _TRAIT_CM, entre les profils
    decales de -d et +d) + enlevement a travers le corps, regroupes dans un
    groupe d'historique "Jonction N".

    Un trait de 0.01 mm plutot qu'un "Scinder le corps" : verifie en direct,
    Scinder echoue sur une bande FERMEE (une coupe seule ne separe rien,
    SPLIT_TARGET_TOOL_NOT_INTERSECT). Invisible a l'usinage."""
    face = _find_top_face(body, frc)
    if face is None:
        raise RuntimeError('face du dessus introuvable sur ' + body.name)
    tl = design.timeline if design.designType == adsk.fusion.DesignTypes.ParametricDesignType else None
    _lap('face du dessus')
    def _new_sketch():
        # Sans projection des aretes de la face : sur un corps plein de
        # mortaises/dogbones, Fusion projetait des centaines de courbes (une
        # par arete de la face) qu'il fallait ensuite supprimer une a une.
        try:
            s_ = comp.sketches.addWithoutEdges(face)
        except Exception:
            s_ = comp.sketches.add(face)
            s_.isComputeDeferred = True
            for c in list(s_.sketchCurves):
                try:
                    c.deleteMe()
                except Exception:
                    pass
        s_.name = 'Jonction %d' % index
        return s_

    sk = _new_sketch()
    pinfo = None
    if tl is not None and _param_on[0]:
        # parametrique : trait contraint aux aretes, il suit la courbe
        try:
            pinfo = _param_sketch(sk, face, frc, g, geom)
            if sk.profiles.count == 0:
                raise RuntimeError('trait non ferme')
        except Exception:
            _dbg('esquisse parametrique impossible: ' + traceback.format_exc())
            pinfo = None
            try:
                sk.deleteMe()
            except Exception:
                pass
            sk = _new_sketch()
    _lap('esquisse')

    if pinfo is None:
        sk.isComputeDeferred = True

        def P(uv):
            return sk.modelToSketchSpace(_local_to_comp(frc, uv[0], uv[1]))

        W = frc['W']
        d = g['jeu'] / 2   # jeu de fonctionnement (0.01 mm mini)
        chain = list(_segments(g, geom, W, d))
        chain.append(('L', (W + _EXT_CM, d), (W + _EXT_CM, -d)))
        chain += _reverse(_segments(g, geom, W, -d))
        chain.append(('L', (-_EXT_CM, -d), (-_EXT_CM, d)))
        for s in chain:
            if s[0] == 'L':
                sk.sketchCurves.sketchLines.addByTwoPoints(P(s[1]), P(s[2]))
            else:
                sk.sketchCurves.sketchArcs.addByThreePoints(
                    P(_arc_pt(s, 0.0)), P(_arc_pt(s, 0.5)), P(_arc_pt(s, 1.0)))
        sk.isComputeDeferred = False
    profs = adsk.core.ObjectCollection.create()
    for pr in sk.profiles:
        profs.add(pr)
    _lap('trait')
    if profs.count == 0:
        sk.deleteMe()
        raise RuntimeError('trait de coupe non ferme')
    # cale de renfort (apres l'esquisse : elle s'y rattache)
    _renf_msg[0] = ''
    if g.get('renf') and frc.get('shim_s') is not None:
        try:
            _renf_msg[0] = _make_shim(design, comp, body, frc, g, geom, pinfo)
        except Exception:
            _dbg('ERREUR _make_shim: ' + traceback.format_exc())
            _renf_msg[0] = 'Renfort : erreur - ' + traceback.format_exc().strip().splitlines()[-1]
    t = frc.get('t') or _thickness(frc)
    ext = comp.features.extrudeFeatures
    inp = ext.createInput(profs, adsk.fusion.FeatureOperations.CutFeatureOperation)
    # isFullLength=False : t + 1 cm DE CHAQUE COTE de la face du dessus
    # (avec True, la distance est la longueur totale et le trait ne
    # traversait pas tout le corps).
    inp.setSymmetricExtent(adsk.core.ValueInput.createByReal(t + 1.0), False)
    inp.participantBodies = [body]
    try:
        last = ext.add(inp)
        _last_cut_feature[0] = last
        _memoriser(last, frc, comp, body)
        _lap('enlevement')
    except Exception:
        try:
            sk.deleteMe()
        except Exception:
            pass
        raise
    if tl is not None and not _batch[0]:
        try:
            first = sk.timelineObject.index
            if _shim_start[0] is not None:
                first = min(first, _shim_start[0])
            # le groupe est cree par create_jonction, apres MargeAuto
            # (sinon la marge se retrouve hors du groupe)
            _groupe_en_attente[0] = (first, 'Jonction %d' % index)
        except Exception:
            _dbg('groupe historique: ' + traceback.format_exc())


_last_cut_feature = [None]
_groupe_en_attente = [None]

# Historique CNC (2026-11-02) : chaque coupe memorise ses reglages dans un
# attribut de sa fonction d'enlevement, pour que « Modifier » de l'historique
# rouvre l'outil avec ses fenetres. Les jonctions creees avant n'en ont pas.
ATTR_G, ATTR_N = 'JonctionCNC', 'edition'
_edit_cur = {'p': None, 'sec': False}   # reglages de la coupe en cours de creation
_edition = {'v': None}                  # edition demandee par l'historique


def _json_p(p):
    return json.dumps(p, default=lambda o: sorted(o) if isinstance(o, (set, tuple, list)) else str(o))


def _memoriser(feature, frc, comp, body):
    """Ecrit les reglages de la coupe sur sa fonction (jamais bloquant)."""
    try:
        O = frc['O']
        d = {'v': 1, 'O': [O.x, O.y, O.z], 'comp': comp.id, 'body': body.name,
             'p': json.loads(_json_p(_edit_cur['p'] if _edit_cur['p'] is not None else _params)),
             'sec': bool(_edit_cur['sec'])}
        feature.attributes.add(ATTR_G, ATTR_N, json.dumps(d))
    except Exception:
        _dbg('memoriser reglages: ' + traceback.format_exc())
_renf_msg = ['']
_param_on = [True]
_batch = [False]      # plusieurs jonctions dans la meme commande : un seul groupe pour toutes
_batch_n = [1]
_laps = []


def _lap(name):
    """Chronometre des etapes d'une coupe, ecrit dans jonction_debug.log
    (pour voir ce qui est lent sur un gros corps)."""
    _laps.append((name, time.perf_counter()))


def _laps_text():
    out = []
    for (n0, t0), (n1, t1) in zip(_laps, _laps[1:]):
        out.append('%s %.2fs' % (n1, t1 - t0))
    return ', '.join(out)


def _up_sign(loop, fr):
    """+1 si la normale n de la face cliquee monte (axe vertical du modele :
    Y ou Z, celui avec lequel n est aligne), -1 si elle descend."""
    if loop.get('up') is not None:
        return loop['up']
    sgn = 1
    try:
        n = fr['n'].copy()
        if fr.get('occ') is not None:
            n.transformBy(fr['occ'].transform2)
        for c in (n.y, n.z):
            if abs(c) > 0.7:
                sgn = 1 if c > 0 else -1
                break
    except Exception:
        pass
    loop['up'] = sgn
    return sgn


def _layers(loop, fr):
    """Faces planes paralleles a la bande, sur les autres corps visibles du
    meme composant (calcule une fois par arete : la fleche reste fluide)."""
    if loop.get('layers') is not None:
        return loop['layers']
    res = []
    try:
        b0 = fr['body']
        tok0 = (b0.nativeObject or b0).entityToken
        nn = fr['n']
        for b in fr['comp'].bRepBodies:
            if not b.isSolid or not b.isVisible or b.entityToken == tok0:
                continue
            for f in b.faces:
                pl = adsk.core.Plane.cast(f.geometry)
                if pl is None or abs(abs(pl.normal.dotProduct(nn)) - 1.0) > 1e-4:
                    continue
                res.append((b, f, pl.origin, f.evaluator))
    except Exception:
        _dbg('ERREUR _layers: ' + traceback.format_exc())
    loop['layers'] = res
    return res


def _stack(loop, fr, haut):
    """Reperes de la meme coupe sur les corps empiles au-dessus (haut) ou en
    dessous, du plus proche au plus loin. Un corps compte s'il porte une face
    parallele qui couvre la coupe d'un bord a l'autre de la bande (une cale
    ou un tenon loge dans une mortaise ne la couvre pas)."""
    want = _up_sign(loop, fr) * (1 if haut else -1)
    W = fr['W']
    us = (min(0.05, W / 2), max(W - 0.05, W / 2))
    O, nn = fr['O'], fr['n']
    found = {}
    for b, f, org, ev in _layers(loop, fr):
        d = O.vectorTo(org).dotProduct(nn)
        if d * want <= 1e-4:
            continue
        try:
            if all(_on_face(f, _local_to_comp(fr, u, 0.0, d), ev) for u in us):
                found.setdefault(b.entityToken, [b, []])[1].append(d)
        except Exception:
            continue
    out = []
    for b, ds in found.values():
        top = max(ds)
        frk = {k: v for k, v in fr.items() if k not in ('stack', 'stack_avail')}
        frk['O'] = _local_to_comp(fr, 0.0, 0.0, top)
        frk['body'] = b
        frk['t'] = (top - min(ds)) if len(ds) > 1 and top - min(ds) > 1e-3 else fr.get('t')
        frk['shim_s'] = -want       # leur cale va vers le corps principal
        out.append((min(abs(x) for x in ds), frk))
    out.sort(key=lambda x: x[0])
    return [frk for _d, frk in out]


def _resolve_body(fr):
    """Corps (natif) de la bande a l'endroit de la coupe fr : il contient la
    matiere a mi-epaisseur ET porte la face du dessus de la coupe. Le corps
    clique est essaye en premier. Sans le test de la face, un tenon loge dans
    une mortaise de la bande (Corps129 dans FS210, 2026-11-01) etait pris
    pour la bande : "face du dessus introuvable"."""
    comp = fr.get('comp')
    if comp is None:
        return None
    t = fr.get('t') or 0.0
    W = fr['W']
    pts = [_local_to_comp(fr, u, 0.0, -t / 2) for u in (min(0.05, W / 2), W / 2, max(W - 0.05, W / 2))]
    first = None
    try:
        b0 = fr.get('body')
        if b0 is not None and b0.isValid:
            first = (b0.nativeObject or b0).entityToken
    except Exception:
        first = None
    bodies = list(comp.bRepBodies)
    bodies.sort(key=lambda b: 0 if first is not None and b.entityToken == first else 1)
    inside = adsk.fusion.PointContainment.PointInsidePointContainment
    for b in bodies:
        try:
            if not b.isSolid or not any(b.pointContainment(p) == inside for p in pts):
                continue
            if _find_top_face(b, fr) is not None:
                return b
        except Exception:
            continue
    return None


def _apply_marge(design, feat):
    """MargeAuto : le jeu regle dans Marge CNC est applique sur les faces
    creees par la coupe (memes appels que EntailleCNC._flush_marge_batch,
    pour que Modif Marge puisse le reajuster plus tard). Retourne un
    message, ou '' si tout va bien."""
    M = _find_module('MargeCNC')
    if M is None:
        return 'MargeAuto : add-in "Marge CNC" inactif - aucun jeu applique.'
    jeu_cm, jeu_actif, _excl = M.load_settings()
    if not jeu_actif:
        return 'MargeAuto : "Appliquer le jeu" est desactive dans Marge CNC.'
    by_body = {}
    for f in feat.faces:
        try:
            by_body.setdefault(f.body.entityToken, []).append(f.entityToken)
        except Exception:
            continue
    batch = [{'female_token': k, 'face_tokens': v} for k, v in by_body.items()]
    if not batch:
        return 'MargeAuto : aucune face de coupe trouvee.'
    try:
        M.record_face_tokens_batch(batch)
    except Exception:
        pass
    M.apply_jeu_to_tokens(design, design.rootComponent, batch, jeu_cm, False)
    return ''


def _find_module(short_name):
    mod = sys.modules.get(short_name)
    if mod is not None:
        return mod
    suffix = short_name + '_py'
    for k, m in list(sys.modules.items()):
        if k.endswith(suffix):
            return m
    return None


def create_jonction(fr, g, geom, marge_auto=False):
    """Coupe le corps de fr. Retourne un message (str)."""
    t_start = time.perf_counter()
    design = adsk.fusion.Design.cast(_app.activeProduct)
    native = fr['body']
    comp = native.parentComponent
    base = native.name
    others = set(b.entityToken for b in comp.bRepBodies if b.entityToken != native.entityToken)
    prev_occ = None
    try:
        prev_occ = design.activeOccurrence
    except Exception:
        pass
    try:
        if fr.get('occ') is not None:
            try:
                fr['occ'].activate()
            except Exception:
                pass
        _last_cut_feature[0] = None
        _groupe_en_attente[0] = None
        del _laps[:]
        _laps.append(('debut', t_start))
        _lap('activation')
        _shim_start[0] = None
        del _shim_tokens[:]
        if _batch[0]:
            idx = _batch_n[0]
            _batch_n[0] += 1
        else:
            idx = _next_group_index(design)
        _cut_body(design, comp, native, fr, g, geom, idx)
        renf_msg = _renf_msg[0]
        marge_msg = ''
        if marge_auto and _last_cut_feature[0] is not None:
            try:
                marge_msg = _apply_marge(design, _last_cut_feature[0])
                _lap('MargeAuto')
            except Exception:
                marge_msg = 'MargeAuto : erreur - ' + traceback.format_exc().strip().splitlines()[-1]
        if _groupe_en_attente[0] is not None:
            try:
                tl_ = design.timeline
                first_, nom_ = _groupe_en_attente[0]
                grp_ = tl_.timelineGroups.add(first_, tl_.markerPosition - 1)
                grp_.name = nom_
                _lap('groupe')
            except Exception:
                _dbg('groupe historique: ' + traceback.format_exc())
            _groupe_en_attente[0] = None
        pieces = [b for b in comp.bRepBodies if b.isSolid and b.entityToken not in others and b.entityToken not in _shim_tokens]
        if len(pieces) > 1:
            # <racine>_A, _B... ; la racine perd le suffixe d'une coupe
            # precedente et les lettres deja prises par les autres pieces
            # sont sautees (2e coupe de Bande_A -> Bande_A + Bande_C).
            root = base
            if len(root) > 2 and root[-2] == '_' and root[-1].isupper():
                root = root[:-2]
            used = set(b.name for b in comp.bRepBodies if b.entityToken in others)
            i = 0
            for b in pieces:
                while '%s_%s' % (root, _letters(i)) in used:
                    i += 1
                try:
                    b.name = '%s_%s' % (root, _letters(i))
                    used.add(b.name)
                except Exception:
                    pass
                i += 1
        _lap('noms')
        _dbg('temps : ' + _laps_text())
        extra = ''.join(' ; ' + m for m in (renf_msg, marge_msg) if m)
        return '%s : %d piece(s)%s%s' % (base, len(pieces), ' + cale' if _shim_tokens else '', extra)
    finally:
        try:
            if prev_occ is not None:
                prev_occ.activate()
            else:
                design.activateRootComponent()
        except Exception:
            pass


def _letters(i):
    s = ''
    i += 1
    while i > 0:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s


def _next_group_index(design):
    n = 1
    try:
        for i in range(design.timeline.timelineGroups.count):
            nm = design.timeline.timelineGroups.item(i).name
            if nm.startswith('Jonction '):
                try:
                    n = max(n, int(nm.split(' ')[1]) + 1)
                except Exception:
                    pass
            elif nm.startswith('Jonctions '):
                try:
                    n = max(n, int(nm.split(' ')[1].split('-')[-1]) + 1)
                except Exception:
                    pass
    except Exception:
        pass
    return n


# ---------------------------------------------------------------------------
# Fenetres des coupes dans la vue (en bas a gauche), meme dessin que les
# lignes de Reseau CNC (ReseauTrajectoireCNC, "Barres de quantite dans la
# vue") : une ligne par coupe, cliquer une ligne la rend active (la fleche y
# va, les reglages de la boite sont les siens), la croix la supprime.
# ---------------------------------------------------------------------------

OV_H = 28                       # hauteur de l'image d'une ligne (pixels d'image)
OV_X, OV_Y, OV_GAP = 16, 60, 6  # marges depuis le coin bas gauche (pixels ecran)
OV_F0 = 104                     # texte de la forme
# boutons (debut, fin) dans l'image ; "court" : dupliquer eteint
OV_D = (176, 204)               # dupliquer sur les corps empiles
OV_S = (210, 238)               # fleche haut / bas
OV_M = (244, 266)               # moins
OV_Q0 = 272                     # nombre de corps
OV_P = (290, 312)               # plus
OV_C0 = 28                      # largeur du bouton cale
OV_XL, OV_WL = (318, 346), 352  # croix et largeur, ligne longue
OV_XC, OV_WC = (210, 238), 244  # croix et largeur, ligne courte


def _lay(dup, renf):
    """({bouton: (debut, fin)}, largeur) d'une ligne selon dupliquer / cale."""
    b = {'dup': OV_D}
    if dup:
        b.update(sens=OV_S, moins=OV_M, plus=OV_P)
        nxt = OV_XL[0]
    else:
        nxt = OV_XC[0]
    if renf:
        b['cale'] = (nxt, nxt + OV_C0)
        nxt += OV_C0 + 6
    b['x'] = (nxt, nxt + 28)
    return b, nxt + 34


_ov = {'g': None, 'sig': None, 'n': 0, 'ext': [], 'lay': [], 'chaut': []}
_tip = {'g': None, 'cle': None}
_png_cache = {}
_dpr_cache = {}

_GLYPHES = {
    'C': '111100100100111', 'H': '101101111101101', 'E': '111100111100111', 'M': '101111111101101',
    'T': '111010010010010', 'O': '111101101101111', 'U': '101101101101111',
    'S': '111100111001111', 'I': '111010010010111', 'N': '111101101101101', ' ': '000000000000000',
    '0': '111101101101111', '1': '010110010010111', '2': '111001111100111', '3': '111001111001111',
    '4': '101101111001001', '5': '111100111001111', '6': '111100111101111', '7': '111001001001001',
    '8': '111101111101111', '9': '111101111001111',
    'A': '010101111101101', 'B': '110101110101110', 'D': '110101101101110', 'F': '111100110100100',
    'G': '011100101101011', 'J': '001001001101010', 'K': '101101110101101', 'L': '100100100100111',
    'P': '110101110100100', 'Q': '010101101111011', 'R': '110101110101101', 'V': '101101101101010',
    'W': '101101111111101', 'X': '101101010101101', 'Y': '101101010010010', 'Z': '111001010100111',
    "'": '010010000000000', '.': '000000000000010', ',': '000000000010100', '-': '000000111000000',
    ':': '000010000010000', '%': '101001010100101', '/': '001001010100100'}


def _dpr():
    """Facteur d'echelle de l'ecran (2 pour 192 dpi) : Fusion agrandit les
    images d'autant, les positions de la vue sont en pixels ecran."""
    if 'k' not in _dpr_cache:
        k = 1.0
        try:
            import ctypes
            k = max(1.0, ctypes.windll.user32.GetDpiForSystem() / 96.0)
        except Exception:
            pass
        _dpr_cache['k'] = k
    return _dpr_cache['k']


def _png_write(cle, px, w, h):
    import zlib, struct, tempfile
    raw = bytearray()
    for y in range(h):
        raw.append(0)
        for x in range(w):
            raw += bytes(px[y][x])

    def chunk(tt, dd):
        c = struct.pack('>I', len(dd)) + tt + dd
        return c + struct.pack('>I', zlib.crc32(tt + dd) & 0xffffffff)

    png = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 6, 0, 0, 0)) + \
        chunk(b'IDAT', zlib.compress(bytes(raw))) + chunk(b'IEND', b'')
    chemin = os.path.join(tempfile.gettempdir(), 'jonction_cnc_%s.png' % cle)
    with open(chemin, 'wb') as f:
        f.write(png)
    _png_cache[cle] = chemin
    return chemin


def _texte(px, txt, x0, y0, couleur):
    for n, c in enumerate(txt):
        g = _GLYPHES.get(c, _GLYPHES[' '])
        for gy in range(5):
            for gx in range(3):
                if g[gy * 3 + gx] == '1':
                    for dy in range(2):
                        for dx in range(2):
                            px[y0 + gy * 2 + dy][x0 + n * 8 + gx * 2 + dx] = couleur


def _png_ligne(i, forme, sel, bad, dup=False, haut=True, q=1, renf=False, chaut=True):
    """Image d'une ligne : "JONCTION i", la forme, dupliquer (+ fleche haut /
    bas, moins, nombre, plus quand il est actif) et la croix."""
    cle = 'jl%d_%s_%d_%d_%d_%d_%d_%d_%d' % (i, forme, 1 if sel else 0, 1 if bad else 0, 1 if dup else 0, 1 if haut else 0, q, 1 if renf else 0, 1 if chaut else 0)
    if cle in _png_cache and os.path.isfile(_png_cache[cle]):
        return _png_cache[cle]
    lay, w = _lay(dup, renf)
    h = OV_H
    bord = (20, 130, 215, 255) if sel else (110, 110, 110, 255)
    px = [[(40, 40, 40, 255)] * w for _ in range(h)]
    for x in range(w):
        for y in (0, 1, h - 1, h - 2):
            px[y][x] = bord
    for y in range(h):
        for x in (0, 1, w - 1, w - 2):
            px[y][x] = bord
    yc = h // 2
    y0 = (h - 10) // 2
    _texte(px, 'JONCTION %d' % (i + 1), 8, y0, (235, 235, 235, 255) if sel else (140, 140, 140, 255))
    coul = (230, 60, 60, 255) if bad else (255, 200, 60, 255) if sel else (140, 140, 140, 255)
    _texte(px, 'INVALIDE' if bad else forme.upper(), OV_F0, y0, coul)

    def bouton(x0, x1, actif):
        """Meme cadre que les boutons de Reseau CNC ; orange quand actif."""
        fond = (110, 55, 0, 255) if actif else (62, 62, 62, 255)
        cadre = (255, 170, 60, 255) if actif else (125, 125, 125, 255)
        for x in range(x0, x1):
            for y in range(yc - 11, yc + 11):
                px[y][x] = cadre if (x in (x0, x1 - 1) or y in (yc - 11, yc + 10)) else fond
        return (255, 140, 0, 255) if actif else (150, 150, 150, 255), (255, 225, 175, 255) if actif else (190, 190, 190, 255)

    # dupliquer : deux carres decales (l'icone "copier")
    plein, clair = bouton(OV_D[0], OV_D[1], dup)
    xd = (OV_D[0] + OV_D[1]) // 2
    for (ax, ay, c) in ((xd - 6, yc - 6, clair), (xd - 2, yc - 2, clair)):
        for x in range(ax, ax + 9):
            for y in range(ay, ay + 9):
                if x in (ax, ax + 8) or y in (ay, ay + 8):
                    px[y][x] = c
                elif ax == xd - 2:
                    px[y][x] = plein if dup else (62, 62, 62, 255)
    if dup:
        # fleche vers le haut ou vers le bas
        plein, clair = bouton(OV_S[0], OV_S[1], False)
        xs = (OV_S[0] + OV_S[1]) // 2
        sg = -1 if haut else 1
        for y in range(yc - 7, yc + 8):
            for x in (xs - 1, xs):
                px[y][x] = clair
        for k in range(6):
            yy = yc + sg * (7 - k)
            for x in range(xs - 1 - k, xs + k + 1):
                px[yy][x] = clair
        for (b0, b1, plus) in ((OV_M[0], OV_M[1], False), (OV_P[0], OV_P[1], True)):
            plein, clair = bouton(b0, b1, False)
            xm = (b0 + b1) // 2
            for x in range(xm - 5, xm + 5):
                for y in (yc - 1, yc):
                    px[y][x] = clair
            if plus:
                for y in range(yc - 5, yc + 5):
                    for x in (xm - 1, xm):
                        px[y][x] = clair
        _texte(px, str(q)[:2], OV_Q0, y0, (255, 200, 60, 255) if sel else (140, 140, 140, 255))
    if renf:
        plein, clair = bouton(lay['cale'][0], lay['cale'][1], False)
        xk = (lay['cale'][0] + lay['cale'][1]) // 2
        for x in range(xk - 8, xk + 8):
            px[yc][x] = clair
        ry = range(yc - 9, yc - 3) if chaut else range(yc + 4, yc + 10)
        for y in ry:
            for x in range(xk - 6, xk + 6):
                px[y][x] = (255, 140, 0, 255)
    x0, x1 = lay['x']
    bouton(x0, x1, False)
    xc = (x0 + x1) // 2
    for d in range(-5, 6):
        for e in (0, 1):
            px[yc + d][xc + d - 1 + e] = (190, 190, 190, 255)
            px[yc + d][xc - d - 1 + e] = (190, 190, 190, 255)
    return _png_write(cle, px, w, h)


def _png_info(txt):
    """Infobulle claire, comme celles de Reseau CNC."""
    import unicodedata
    txt = ''.join(c for c in unicodedata.normalize('NFD', txt) if unicodedata.category(c) != 'Mn').upper()
    cle = 'tip_%d' % (abs(hash(txt)) % 10 ** 10)
    w, h = len(txt) * 8 + 12, 24
    if cle in _png_cache and os.path.isfile(_png_cache[cle]):
        return _png_cache[cle], w, h
    px = [[(246, 246, 246, 255)] * w for _ in range(h)]
    for x in range(w):
        for y in (0, h - 1):
            px[y][x] = (110, 110, 110, 255)
    for y in range(h):
        for x in (0, w - 1):
            px[y][x] = (110, 110, 110, 255)
    _texte(px, txt, 6, 7, (20, 20, 20, 255))
    return _png_write(cle, px, w, h), w, h


def _all_cuts():
    """Toutes les coupes dans l'ordre des fenetres ; celle en cours a son rang _act."""
    allc = list(_cuts)
    if _loop is not None:
        allc.insert(min(_act, len(allc)), {'loop': _loop, 'pos': _pos, 'pos0': _pos0, 'last': _last, 'p': dict(_params)})
    return allc


def _ov_clear():
    g = _ov['g']
    _ov['g'] = None
    _ov['sig'] = None
    try:
        if g is not None and g.isValid:
            g.deleteMe()
    except Exception:
        pass



# --- Fenetres du bas a gauche toujours devant le modele (2026-11-05) ----------
# Une image posee en viewPlacement garde la profondeur de son point 3D : a
# l'origine, tout corps plus proche de la camera passait devant. On la decale
# vers la camera, juste devant la sphere englobante du modele, et on suit la
# camera (orbite, zoom) pour qu'elle reste toujours devant.
_dv = {'ents': [], 'h': None, 'c': None, 'r': 0.0, 't': 0.0}


def _dv_point():
    app = adsk.core.Application.get()
    des = adsk.fusion.Design.cast(app.activeProduct)
    if des is None:
        return None
    if time.time() - _dv['t'] > 1.0:
        _dv['t'] = time.time()
        bb = des.rootComponent.boundingBox
        if bb is None:
            _dv['c'] = None
        else:
            a, b = bb.minPoint, bb.maxPoint
            _dv['c'] = ((a.x + b.x) / 2.0, (a.y + b.y) / 2.0, (a.z + b.z) / 2.0)
            _dv['r'] = a.distanceTo(b) / 2.0
    c = _dv['c']
    if c is None:
        return None
    cam = app.activeViewport.camera
    e, t = cam.eye, cam.target
    d = (e.x - t.x, e.y - t.y, e.z - t.z)
    lg = math.sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2])
    if lg < 1e-9:
        return None
    d = (d[0] / lg, d[1] / lg, d[2] / lg)
    ec = (e.x - c[0]) * d[0] + (e.y - c[1]) * d[1] + (e.z - c[2]) * d[2]
    # juste devant le modele, mais jamais derriere la camera (perspective tres zoomee)
    s = min(_dv['r'] * 1.2 + 1.0, ec * 0.5) if ec > 0 else 0.0
    p = adsk.core.Point3D.create(c[0] + d[0] * s, c[1] + d[1] * s, c[2] + d[2] * s)
    occ = des.activeOccurrence
    if occ is not None:
        inv = occ.transform2.copy()
        inv.invert()
        p.transformBy(inv)
    return p


def _dv_appliquer(ents):
    p = _dv_point()
    if p is None:
        return
    m = adsk.core.Matrix3D.create()
    m.translation = adsk.core.Vector3D.create(p.x, p.y, p.z)
    for x in ents:
        x.transform = m


class _DvCamHandler(adsk.core.CameraEventHandler):
    def notify(self, args):
        try:
            ents = [x for x in _dv['ents'] if x.isValid]
            _dv['ents'] = ents
            if ents:
                _dv_appliquer(ents)
        except Exception:
            pass


def _dv_poser(ps):
    """A appeler apres chaque ps.viewPlacement = ... d'une fenetre du bas a gauche."""
    try:
        _dv['t'] = 0.0
        _dv_appliquer([ps])
        _dv['ents'] = [x for x in _dv['ents'] if x.isValid] + [ps]
        if _dv['h'] is None:
            h = _DvCamHandler()
            adsk.core.Application.get().cameraChanged.add(h)
            _dv['h'] = h
    except Exception:
        pass


def _dv_arreter():
    try:
        if _dv['h'] is not None:
            adsk.core.Application.get().cameraChanged.remove(_dv['h'])
    except Exception:
        pass
    _dv['h'] = None
    _dv['ents'] = []


def _ov_maj():
    """Dessine (ou garde) une ligne par coupe. Groupe a part du preview :
    il n'est refait que si une ligne change ou s'il a ete efface."""
    try:
        allc = _all_cuts()
        lignes = []
        for c in allc:
            last = c.get('last')
            p = c['p']
            fr = last[0] if last is not None else None
            dup = bool(p.get('dup'))
            q = min(int(p.get('dup_n', 1)), fr.get('stack_avail', 0)) if (dup and fr is not None) else 0
            renf = bool(last is not None and last[1].get('renf'))
            chaut = True
            try:
                if renf and fr is not None:
                    chaut = (fr.get('shim_s') or 1) * _up_sign(c['loop'], fr) > 0
            except Exception:
                pass
            lignes.append((p.get('forme', 'droite'), bool(last is None or fr is None or last[3]),
                           dup, bool(p.get('dup_haut', True)), q, renf, chaut))
        sel = min(_act, len(allc) - 1) if _loop is not None else -1
        sig = (tuple(lignes), sel, _vp_size())
        if sig == _ov['sig'] and _ov['g'] is not None and _ov['g'].isValid:
            return
        _ov_clear()
        _ov['n'] = len(lignes)
        _ov['ext'] = [l[2] for l in lignes]
        _ov['lay'] = [_lay(l[2], l[5]) for l in lignes]
        _ov['chaut'] = [l[6] for l in lignes]
        if not lignes:
            return
        design = adsk.fusion.Design.cast(_app.activeProduct)
        g = design.activeComponent.customGraphicsGroups.add()      # composant actif : sinon les fenetres sont grisees
        k = _dpr()
        n = len(lignes)
        for r, (forme, bad, dup, haut, q, renf, chaut) in enumerate(lignes):
            ps = g.addPointSet(adsk.fusion.CustomGraphicsCoordinates.create([0.0, 0.0, 0.0]), [0],
                               adsk.fusion.CustomGraphicsPointTypes.UserDefinedCustomGraphicsPointType,
                               _png_ligne(r, forme, r == sel, bad, dup, haut, q, renf, chaut))
            ps.isSelectable = False
            w = _lay(dup, renf)[1]
            ps.viewPlacement = adsk.fusion.CustomGraphicsViewPlacement.create(
                adsk.core.Point3D.create(0, 0, 0), adsk.fusion.ViewCorners.lowerLeftViewCorner,
                adsk.core.Point2D.create(OV_X + w * k / 2.0, OV_Y + (n - 1 - r) * (OV_H * k + OV_GAP) + OV_H * k / 2.0))
            _dv_poser(ps)
        _ov['g'] = g
        _ov['sig'] = sig
    except Exception:
        _dbg('ERREUR fenetres: ' + traceback.format_exc())


def _vp_size():
    try:
        v = _app.activeViewport
        return (int(v.width), int(v.height))
    except Exception:
        return None


def _ov_hit(vp, pos):
    """(ligne, bouton) sous le curseur, sinon None ; bouton : 'x', 'dup',
    'sens', 'moins', 'plus' ou None (le reste de la ligne)."""
    n = _ov['n']
    if not n or _ov['g'] is None:
        return None
    k = _dpr()
    h = vp.height * k      # vp.height est en pixels logiques
    for r in range(n):
        yc = h - (OV_Y + (n - 1 - r) * (OV_H * k + OV_GAP) + OV_H * k / 2.0)
        lay, wl = _ov['lay'][r]
        if not (OV_X <= pos.x <= OV_X + wl * k and abs(pos.y - yc) <= OV_H * k / 2.0):
            continue
        for nom, (b0, b1) in lay.items():
            if OV_X + b0 * k <= pos.x <= OV_X + b1 * k:
                return r, nom
        return r, None
    return None


TEXTES_AIDE = {
    'x': "Supprimer cette jonction",
    'dup': "Couper aussi les corps empiles",
    'cale_h': "Cale au-dessus - clic : dessous",
    'cale_b': "Cale en dessous - clic : dessus",
    'sens_h': "Corps du dessus - clic : dessous",
    'sens_b': "Corps du dessous - clic : dessus",
    'moins': "Un corps de moins",
    'plus': "Un corps de plus"}


def _tip_clear():
    g = _tip['g']
    _tip['g'] = None
    _tip['cle'] = None
    try:
        if g is not None and g.isValid:
            g.deleteMe()
            _app.activeViewport.refresh()
    except Exception:
        pass


def _tip_maj(vp, pos):
    """Infobulle a droite de la ligne survolee, sur l'icone sous le curseur."""
    hit = _ov_hit(vp, pos) if _ov['g'] is not None else None
    if hit is not None and hit[1] is None:
        hit = None
    cle = hit
    if cle == _tip['cle'] and (cle is None or (_tip['g'] is not None and _tip['g'].isValid)):
        return
    _tip_clear()
    if hit is None:
        return
    r, nom = hit
    if nom == 'sens':
        haut = True
        try:
            haut = bool(_all_cuts()[r]['p'].get('dup_haut', True))
        except Exception:
            pass
        nom = 'sens_h' if haut else 'sens_b'
    if nom == 'cale':
        nom = 'cale_h' if _ov['chaut'][r] else 'cale_b'
    png, w, h = _png_info(TEXTES_AIDE[nom])
    design = adsk.fusion.Design.cast(_app.activeProduct)
    g = design.activeComponent.customGraphicsGroups.add()
    k = _dpr()
    n = _ov['n']
    gauche = OV_X + (_ov['lay'][r][1] + 8) * k
    bas = OV_Y + (n - 1 - r) * (OV_H * k + OV_GAP) + OV_H * k / 2.0
    ps = g.addPointSet(adsk.fusion.CustomGraphicsCoordinates.create([0.0, 0.0, 0.0]), [0],
                       adsk.fusion.CustomGraphicsPointTypes.UserDefinedCustomGraphicsPointType, png)
    ps.isSelectable = False
    ps.viewPlacement = adsk.fusion.CustomGraphicsViewPlacement.create(
        adsk.core.Point3D.create(0, 0, 0), adsk.fusion.ViewCorners.lowerLeftViewCorner,
        adsk.core.Point2D.create(gauche + w * k / 2.0, bas))
    _dv_poser(ps)
    _tip['g'] = g
    _tip['cle'] = cle
    try:
        _app.activeViewport.refresh()
    except Exception:
        pass


def _freeze_active():
    """Range la coupe en cours dans _cuts, a son rang."""
    global _loop, _last
    if _loop is not None:
        _cuts.insert(min(_act, len(_cuts)), {'loop': _loop, 'pos': _pos, 'pos0': _pos0, 'last': _last, 'p': dict(_params)})
    _loop, _last = None, None


def _take(j, inputs):
    """La coupe j de _cuts devient la coupe en cours (fleche + reglages)."""
    global _loop, _pos, _pos0, _last, _act, _params
    c = _cuts.pop(j)
    marge = _params.get('marge_auto', False)      # MargeAuto vaut pour toute la commande
    parm = _params.get('param', True)
    _loop, _pos, _pos0, _last = c['loop'], c['pos'], c['pos0'], c['last']
    _params = dict(c['p'])
    _params['marge_auto'] = marge
    _params['param'] = parm
    _act = j
    _write_inputs(inputs, _params)


def _select_cut(inputs, j):
    """Clic sur la fenetre j."""
    if _loop is not None and j == _act:
        return
    _freeze_active()
    _take(j, inputs)


def _delete_cut(inputs, j):
    """Croix de la fenetre j (ou bouton de la boite pour la coupe en cours)."""
    global _act
    if _loop is not None and j == _act:
        _freeze_active()
        _cuts.pop(j)
        if _cuts:
            _take(min(j, len(_cuts) - 1), inputs)
        else:
            _act = 0
        return
    k = j if (_loop is None or j < _act) else j - 1
    if 0 <= k < len(_cuts):
        _cuts.pop(k)
        if _loop is not None and j < _act:
            _act -= 1


def _write_inputs(inputs, p):
    """Reglages d'une coupe -> champs de la boite (sans relancer inputChanged)."""
    global _syncing
    _syncing = True
    try:
        dd = adsk.core.DropDownCommandInput.cast(inputs.itemById('forme'))
        want = _FORMES[1][1] if p.get('forme') == 'puzzle' else _FORMES[0][1]
        for it in dd.listItems:
            if it.name == want and not it.isSelected:
                it.isSelected = True
        rd = adsk.core.DropDownCommandInput.cast(inputs.itemById('renf'))
        want = _RENF[1][1] if p.get('renf') == 'cale' else _RENF[0][1]
        for it in rd.listItems:
            if it.name == want and not it.isSelected:
                it.isSelected = True
        for k in ('tete_mm', 'col_mm', 'conge_mm', 'jeu_mm', 'renf_am_mm', 'renf_av_mm'):
            vi = adsk.core.ValueCommandInput.cast(inputs.itemById(k))
            dv = p.get(k, DEFAULTS.get(k, 0.0)) / 10.0
            if abs(vi.value - dv) > 1e-9:
                vi.value = dv
        for k in ('flip', 'auto', 'marge_auto', 'param'):
            bi = adsk.core.BoolValueCommandInput.cast(inputs.itemById(k))
            if bi.value != bool(p.get(k, False)):
                bi.value = bool(p.get(k, False))
    except Exception:
        _dbg('ERREUR _write_inputs: ' + traceback.format_exc())
    finally:
        _syncing = False


def _hull(pts):
    pts = sorted(set(pts))
    if len(pts) < 3:
        return pts

    def cr(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    lo, up = [], []
    for p in pts:
        while len(lo) >= 2 and cr(lo[-2], lo[-1], p) <= 0:
            lo.pop()
        lo.append(p)
    for p in reversed(pts):
        while len(up) >= 2 and cr(up[-2], up[-1], p) <= 0:
            up.pop()
        up.append(p)
    return lo[:-1] + up[:-1]


def _shim_pick(vp, pos):
    """(coupe, corps) de la boite de cale sous le curseur, sinon None.
    Comparaison dans l'espace "vue" (screenToView / modelToViewSpace) : pas
    de souci d'echelle ecran ni de sens vertical."""
    if not _shim_hit:
        return None
    k = _dpr()
    best = None
    try:
        P3 = adsk.core.Point3D.create
        P2 = adsk.core.Point2D.create
        # l'espace "vue" est en pixels du viewport (origine en haut a gauche),
        # comme viewportPosition de la souris (mesure dans le journal)
        cands = [(pos.x, pos.y)]
        # pas de bascule quand on attrape la fleche (poignee de la coupe en
        # cours, posee sur le bord de la bande a l'origine du repere)
        if _loop is not None and _last is not None and _last[0] is not None:
            fa = _last[0]
            Oa = fa['O'].copy()
            if fa.get('occ') is not None:
                Oa.transformBy(fa['occ'].transform2)
            qa = vp.modelToViewSpace(Oa)
            if (qa.x - pos.x) ** 2 + (qa.y - pos.y) ** 2 < (_FLECHE_PX * k) ** 2:
                if _SHIM_DBG:
                    _dbg('clic pres de la fleche : ignore')
                return None
        for tag, pts in _shim_hit:
            q = [vp.modelToViewSpace(P3(*p)) for p in pts]
            poly = _hull([(a.x, a.y) for a in q])
            if _SHIM_DBG:
                xs = [a[0] for a in poly]; ys = [a[1] for a in poly]
                _dbg('boite %s vue x %.2f..%.2f y %.2f..%.2f ; curseur %s' % (
                    tag, min(xs), max(xs), min(ys), max(ys), ['%.2f,%.2f' % c for c in cands]))
            if len(poly) < 3:
                continue
            cx = sum(a[0] for a in poly) / len(poly)
            cy = sum(a[1] for a in poly) / len(poly)
            for (mx, my) in cands:
                sg = [(poly[(i + 1) % len(poly)][0] - poly[i][0]) * (my - poly[i][1]) -
                      (poly[(i + 1) % len(poly)][1] - poly[i][1]) * (mx - poly[i][0]) for i in range(len(poly))]
                if all(v >= 0 for v in sg) or all(v <= 0 for v in sg):
                    d = (cx - mx) ** 2 + (cy - my) ** 2
                    if best is None or d < best[0]:
                        best = (d, tag)
                    break
    except Exception:
        _dbg('ERREUR _shim_pick: ' + traceback.format_exc())
    if _SHIM_DBG:
        _dbg('clic %.0f,%.0f k=%.2f boites=%d -> %s' % (pos.x, pos.y, k, len(_shim_hit), best[1] if best else None))
    return best[1] if best else None


_SHIM_DBG = True
_FLECHE_PX = 60     # rayon (pixels logiques) autour de la fleche ou un clic ne bascule pas


class _MouseMoveHandler(adsk.core.MouseEventHandler):
    """Infobulles des boutons des fenetres."""
    def __init__(self):
        super().__init__()

    def notify(self, args):
        try:
            _jsouris['pos'], _jsouris['vp'] = args.viewportPosition, args.viewport
            if _jd['on'] and _jd.get('pris'):
                _jd_glisser(args.viewport, args.viewportPosition)     # pastille attrapee par un clic
                return
            _tip_maj(args.viewport, args.viewportPosition)
        except Exception:
            pass


class _MouseDownHandler(adsk.core.MouseEventHandler):
    def __init__(self):
        super().__init__()

    def notify(self, args):
        try:
            if _jd['on'] and _jd.get('pris'):
                # pastille attrapee par un clic : ce clic la pose (aucun rectangle de selection)
                _bloc_t[0] = time.time()
                _jd_fin(args.firingEvent.sender)
                return
            hit = _ov_hit(args.viewport, args.viewportPosition)
            if hit is None and args.button == adsk.core.MouseButtons.LeftMouseButton and \
                    _jd_debut(args.firingEvent.sender.commandInputs, args.viewport, args.viewportPosition):
                _bloc_t[0] = time.time()       # ce clic ne pose pas de coupe
                _jd_figer(args.firingEvent.sender.commandInputs)
                _tip_clear()
                return
            if hit is None:
                pick = _shim_pick(args.viewport, args.viewportPosition)
                if pick is None:
                    return
                _bloc_t[0] = time.time()       # ce clic ne pose pas de coupe
                cmd = args.firingEvent.sender
                inputs = cmd.commandInputs
                _tip_clear()
                _select_cut(inputs, pick[0])
                ov = set(_params.get('shim_ov') or ())
                ov ^= {pick[1]}
                _params['shim_ov'] = tuple(sorted(ov))
                _update(inputs)
                _draw_all()
                try:
                    cmd.doExecutePreview()
                except Exception:
                    pass
                return
            _bloc_t[0] = time.time()       # ce clic ne pose pas de coupe
            cmd = args.firingEvent.sender
            inputs = cmd.commandInputs
            _tip_clear()
            j, bouton = hit
            if bouton == 'x':
                _delete_cut(inputs, j)
            else:
                # un clic sur une ligne la rend active ; ses boutons
                # s'appliquent ensuite a cette coupe
                _select_cut(inputs, j)
                if bouton == 'dup':
                    _params['dup'] = not _params.get('dup', False)
                elif bouton == 'cale':
                    _params['shim_flip'] = not _params.get('shim_flip', False)
                    _params['shim_ov'] = ()
                elif bouton == 'sens':
                    _params['dup_haut'] = not _params.get('dup_haut', True)
                elif bouton in ('moins', 'plus'):
                    avail = 0
                    if _last is not None and _last[0] is not None:
                        avail = _last[0].get('stack_avail', 0)
                    q = min(int(_params.get('dup_n', 1)), max(1, avail))
                    q = q - 1 if bouton == 'moins' else q + 1
                    # pas plus de corps qu'il n'y en a d'empiles
                    _params['dup_n'] = max(1, min(q, max(1, avail)))
            _update(inputs)
            _draw_all()
            try:
                cmd.doExecutePreview()
            except Exception:
                pass
        except Exception:
            _dbg('ERREUR mouseDown: ' + traceback.format_exc())


# ---------------------------------------------------------------------------
# Commande Fusion (fleche a glisser sur l'arete)
# ---------------------------------------------------------------------------

_FORMES = (('droite', 'Droite'), ('puzzle', 'Puzzle'))
_RENF = (('aucun', 'Aucun'), ('cale', 'Cale sur la jonction'))


def _read_inputs(inputs):
    """Champs de la commande -> _params (mm)."""
    p = dict(_params)
    try:
        dd = adsk.core.DropDownCommandInput.cast(inputs.itemById('forme'))
        p['forme'] = _FORMES[1][0] if dd.selectedItem and dd.selectedItem.name == _FORMES[1][1] else _FORMES[0][0]
        for k in ('tete_mm', 'col_mm', 'conge_mm'):
            vi = adsk.core.ValueCommandInput.cast(inputs.itemById(k))
            p[k] = round(vi.value * 10.0, 4)   # cm -> mm
        p['flip'] = adsk.core.BoolValueCommandInput.cast(inputs.itemById('flip')).value
        p['auto'] = adsk.core.BoolValueCommandInput.cast(inputs.itemById('auto')).value
        p['jeu_mm'] = round(adsk.core.ValueCommandInput.cast(inputs.itemById('jeu_mm')).value * 10.0, 4)
        p['marge_auto'] = adsk.core.BoolValueCommandInput.cast(inputs.itemById('marge_auto')).value
        p['param'] = adsk.core.BoolValueCommandInput.cast(inputs.itemById('param')).value
        rd = adsk.core.DropDownCommandInput.cast(inputs.itemById('renf'))
        p['renf'] = _RENF[1][0] if rd.selectedItem and rd.selectedItem.name == _RENF[1][1] else _RENF[0][0]
        for k in ('renf_am_mm', 'renf_av_mm'):
            p[k] = round(adsk.core.ValueCommandInput.cast(inputs.itemById(k)).value * 10.0, 4)
    except Exception:
        _dbg('ERREUR _read_inputs: ' + traceback.format_exc())
    return p


def _place_arrow(inputs, g):
    """Pose la fleche (manipulateur de la distance) sur le contour a _pos,
    dans le sens du contour : origine = point - tangente * _pos, pour que
    origine + tangente * valeur tombe sur le point. Recalcule a chaque
    deplacement : la fleche suit ainsi les courbes."""
    dist = adsk.core.DistanceValueCommandInput.cast(inputs.itemById('pos'))
    if _loop is None:
        dist.isVisible = False
        _jp_effacer()
        return
    O, T = _eval_loop(_loop, _pos)
    T.normalize()
    occ = _loop.get('occ')
    if occ is not None:
        O = O.copy(); O.transformBy(occ.transform2)
        T = T.copy(); T.transformBy(occ.transform2); T.normalize()
    # Valeur = decalage depuis le point clique (pas depuis le debut du
    # contour : la cote partait tres loin de la piece, retour de l'utilisateur).
    off = _offset()
    org = O.copy()
    back = T.copy(); back.scaleBy(-off)
    org.translateBy(back)
    dist.setManipulator(org, T)
    dist.value = off
    dist.isVisible = True
    if _caf is not None:
        dist.isVisible = False            # la pastille remplace la fleche native (glisser hors cycle Fusion)
        _jp_placer((O.x, O.y, O.z))


# --- Glisser maison de la coupe (pastille, module cnc_apercu_fluide) ---------------------
_jp = {'g': None, 'cam': None}
_jd = {'on': False, 'tm': 0.0}


def _jp_placer(p):
    if _caf is None:
        return
    try:
        if _jp['g'] is None:
            _jp['g'] = _caf.Poignee('JonctionCNC_pastille')
        _jp['g'].placer(p)
        if _jp['cam'] is None:
            _jp['cam'] = _JCameraHandler()
            _app.cameraChanged.add(_jp['cam'])
    except Exception:
        _dbg('pastille: ' + traceback.format_exc().strip().splitlines()[-1])


def _jp_effacer():
    if _jp['g'] is not None:
        _jp['g'].effacer()
        _jp['g'] = None
    if _caf is not None:
        _caf.balayer('JonctionCNC_pastille')
    if _jp['cam'] is not None:
        try:
            _app.cameraChanged.remove(_jp['cam'])
        except Exception:
            pass
        _jp['cam'] = None


def _jp_assurer():
    """executePreview : remet la pastille si Fusion l'a annulee."""
    g = _jp['g']
    if g is not None and g.p is not None and not _jd['on']:
        g.placer(g.p)


class _JCameraHandler(adsk.core.CameraEventHandler):
    def __init__(self):
        super().__init__()

    def notify(self, args):
        try:
            if _jp['g'] is not None:
                _jp['g'].recaler(args.viewport)
        except Exception:
            pass


def _jl_monde(loop):
    """Points du contour (abscisse, point monde), echantillonnes une fois par contour."""
    pts = loop.get('pts_w')
    if pts is None:
        tot = loop['total']
        n = max(40, min(400, int(tot / 0.25) + 1))
        occ = loop.get('occ')
        pts = []
        for k in range(n + 1):
            s = tot * k / n
            pt, _t = _eval_loop_raw(loop, s)
            if occ is not None:
                pt = pt.copy()
                pt.transformBy(occ.transform2)
            pts.append((s, (pt.x, pt.y, pt.z)))
        loop['pts_w'] = pts
    return pts


def _jl_abscisse(loop, vp, x, y, s_prev=None):
    """Abscisse du point du contour le plus proche de la souris a l'ecran (pres de s_prev si donne)."""
    pts = _jl_monde(loop)
    try:
        cam = vp.camera
        cle = (id(loop), tuple(round(v, 4) for v in cam.eye.asArray() + cam.target.asArray() + cam.upVector.asArray()),
               round(cam.viewExtents, 4), vp.width, vp.height)
    except Exception:
        cle = None
    ecr = loop.get('ecr')
    if ecr is None or cle is None or ecr[0] != cle:
        P3 = adsk.core.Point3D.create
        ecr = (cle, [vp.modelToViewSpace(P3(*p)) for _s, p in pts])
        loop['ecr'] = ecr
    e = ecr[1]
    tot = loop['total']
    fen = tot * 0.15
    best = None
    for passe in ((True, False) if s_prev is not None else (False,)):
        for j in range(len(pts) - 1):
            sa, sb = pts[j][0], pts[j + 1][0]
            if passe:
                dd = abs(((sa - s_prev) + tot / 2) % tot - tot / 2) if tot > 0 else 0.0
                if dd > fen:
                    continue
            ax, ay = e[j].x, e[j].y
            ex, ey = e[j + 1].x - ax, e[j + 1].y - ay
            e2 = ex * ex + ey * ey
            u = 0.0 if e2 < 1e-12 else max(0.0, min(1.0, ((x - ax) * ex + (y - ay) * ey) / e2))
            d = (ax + u * ex - x) ** 2 + (ay + u * ey - y) ** 2
            if best is None or d < best[0]:
                best = (d, sa + u * (sb - sa))
        if best is not None:
            break
    return best[1] if best else None


def _jd_debut(inputs, vp, pos):
    """mouseDown sur la pastille : debut du glisser maison."""
    g = _jp['g']
    if _caf is None or _loop is None or g is None or g.p is None:
        return False
    q = vp.modelToViewSpace(adsk.core.Point3D.create(*g.p))
    if math.hypot(q.x - pos.x, q.y - pos.y) > 14.0 * _dpr():
        return False
    _jd.update(on=True, tm=0.0, ins=inputs, n=0, calc=0.0, t0=time.perf_counter(), pris=False,
               pd=(pos.x, pos.y), td=time.perf_counter())
    return True


def _jd_figer(inputs):
    """Pendant le glisser, le champ 'edge' (1 arete maxi) recoit l'arete du contour : un champ PLEIN
    empeche Fusion de lancer son rectangle de selection (c'est pourquoi Traverse ne l'a pas)."""
    global _syncing
    if _jd.get('fige') or _loop is None:
        return
    try:
        sel = adsk.core.SelectionCommandInput.cast(inputs.itemById('edge'))
        if sel is None or sel.selectionCount:
            return
        e = _loop['items'][0]['edge']
        occ = _loop.get('occ')
        if occ is not None and e.assemblyContext is None:
            e = e.createForAssemblyContext(occ)
        _syncing = True
        try:
            _jd['fige'] = bool(sel.addSelection(e))
        finally:
            _syncing = False
    except Exception:
        _dbg('figer selection: ' + traceback.format_exc()[-300:])


def _jd_rendre(inputs):
    global _syncing
    if not _jd.pop('fige', False):
        return
    try:
        sel = adsk.core.SelectionCommandInput.cast(inputs.itemById('edge'))
        if sel is not None and sel.selectionCount:
            _syncing = True
            try:
                sel.clearSelection()
            finally:
                _syncing = False
    except Exception:
        pass


def _jd_glisser(vp, pos):
    global _pos, _last
    t0 = time.perf_counter()
    if not _jd['on'] or _loop is None or t0 - _jd['tm'] < 0.008:
        return
    _jd['tm'] = t0
    try:
        s = _jl_abscisse(_loop, vp, pos.x, pos.y, _pos)
        if s is None:
            return
        _pos = s
        _last = _compute(_loop, _pos, _params)
        _draw_all(refresh=False)
        O, _T = _eval_loop(_loop, _pos)
        occ = _loop.get('occ')
        if occ is not None:
            O = O.copy()
            O.transformBy(occ.transform2)
        _jp_placer((O.x, O.y, O.z))
        vp.refresh()                     # aucun cycle Fusion pendant le glisser : on demande le redessin
        _jd['n'] += 1
        _jd['calc'] += time.perf_counter() - t0
    except Exception:
        _dbg('ERREUR glisser maison: ' + traceback.format_exc())


def _jd_fin(cmd):
    """mouseUp : la position finale passe dans la commande (un seul cycle Fusion)."""
    _jd_rendre(cmd.commandInputs)
    _jd['on'] = False
    _jd['pris'] = False
    _bloc_t[0] = time.time()             # le relachement ne pose pas de coupe
    n = _jd.get('n', 0)
    _dbg('perf glisser maison : %d images en %.2f s, %.2f ms par image' % (
        n, time.perf_counter() - _jd.get('t0', 0.0), 1000 * _jd.get('calc', 0.0) / max(1, n)))
    inputs = cmd.commandInputs
    _update(inputs)
    _draw_all()
    try:
        cmd.doExecutePreview()
    except Exception:
        pass
    _jd.pop('ins', None)


class _MouseDragHandler(adsk.core.MouseEventHandler):
    def __init__(self):
        super().__init__()

    def notify(self, args):
        try:
            if _jd['on']:
                _jd_glisser(args.viewport, args.viewportPosition)
        except Exception:
            pass


class _MouseUpHandler(adsk.core.MouseEventHandler):
    def __init__(self):
        super().__init__()

    def notify(self, args):
        try:
            if _jd['on']:
                pd, m = _jd.get('pd'), args.viewportPosition
                if not _jd.get('pris') and pd is not None and time.perf_counter() - _jd.get('td', 0.0) < 0.4 \
                        and math.hypot(m.x - pd[0], m.y - pd[1]) < 5.0 * _dpr():
                    # appui + relachement rapide sans bouger : la pastille reste attrapee et suit la souris
                    # sans bouton (donc sans rectangle de selection) jusqu'au clic suivant
                    _jd['pris'] = True
                    _bloc_t[0] = time.time()
                    return
                if _jd.get('pris'):
                    return
                _jd_fin(args.firingEvent.sender)
        except Exception:
            _dbg('ERREUR mouseUp: ' + traceback.format_exc())


class _PreSelectHandler(adsk.core.SelectionEventHandler):
    """Rien n'est preselectionnable sous la pastille ni pendant son glisser (un clic sur une arete
    poserait sinon une nouvelle coupe)."""
    def __init__(self):
        super().__init__()

    def notify(self, args):
        try:
            if _jd['on']:
                args.isSelectable = False
                return
            g = _jp['g']
            m = _jsouris.get('pos')
            if g is None or g.p is None or m is None:
                return
            q = _jsouris['vp'].modelToViewSpace(adsk.core.Point3D.create(*g.p))
            if math.hypot(q.x - m.x, q.y - m.y) <= 16.0 * _dpr():
                args.isSelectable = False
        except Exception:
            pass


_jsouris = {'pos': None, 'vp': None}


def _offset():
    """Decalage signe de _pos par rapport a _pos0 (le plus court sur une
    boucle fermee)."""
    tot = _loop['total']
    off = _pos - _pos0
    if tot > 0:
        off = (off + tot / 2) % tot - tot / 2
    return off


def _update(inputs):
    """Recalcule la coupe, la fleche et le message. Le preview orange est
    dessine dans executePreview : Fusion efface a chaque deplacement de la
    fleche les graphiques crees ailleurs pendant la commande (le preview
    disparaissait, retour de l'utilisateur)."""
    global _params, _last
    _params = _read_inputs(inputs)
    g = params_cm(_params)
    grp = inputs.itemById('grpPuzzle')
    if grp is not None:
        grp.isVisible = g['puzzle']
    gr = inputs.itemById('grpRenf')
    if gr is not None:
        gr.isVisible = g['renf']
    undo = inputs.itemById('undo')
    if undo is not None:
        undo.isEnabled = _loop is not None or bool(_cuts)
    msg = inputs.itemById('info')
    # Chaque coupe garde ses reglages : seule la coupe en cours est recalculee.
    if _loop is None:
        _last = None
        _place_arrow(inputs, g)
        _auto_lock(inputs)
        _draw_all()
        msg.formattedText = "Clique sur une arete de la bande." if not _cuts else (
            '%d coupe(s) placee(s).<br>Clique une autre arete pour en ajouter une, ou Couper.' % len(_cuts))
        return None, g, None, ['pas d\'arete']
    _place_arrow(inputs, g)
    fr, g, geom, errs = _compute(_loop, _pos, _params)
    if fr is not None and _params.get('auto', True):
        # Mode auto : les champs montrent les valeurs de la coupe en cours.
        for k, v in zip(('tete_mm', 'col_mm', 'conge_mm'), auto_puzzle_mm(fr['W'] * 10.0)):
            _params[k] = v
            vi = adsk.core.ValueCommandInput.cast(inputs.itemById(k))
            if abs(vi.value - v / 10.0) > 1e-6:
                vi.value = v / 10.0
    _auto_lock(inputs)
    _last = (fr, g, geom, errs)
    bad = [i + 1 for i, c in enumerate(_all_cuts()) if i != _act and c['last'][3]]
    if errs or bad:
        # Pas d'executePreview quand les champs sont invalides : dessin ici.
        _draw_all()
    n = _act + 1
    if errs:
        msg.formattedText = '<b>' + '<br>'.join(errs) + '</b>'
    elif bad:
        msg.formattedText = '<b>Coupe(s) %s invalide(s) avec ces reglages.</b>' % ', '.join(map(str, bad))
    else:
        if _params.get('dup'):
            nb = len(fr.get('stack') or [])
            sens = 'au-dessus' if _params.get('dup_haut', True) else 'en dessous'
            extra = (' + %d corps %s' % (nb, sens)) if nb else (' (aucun corps empile %s)' % sens)
        else:
            extra = ''
        msg.formattedText = ('Coupe %d%s : bande de %.1f mm de large, %.1f mm d\'epaisseur.<br>'
                             'Fais glisser la fleche, clique une autre arete pour une coupe de plus '
                             '(ou une fenetre en bas a gauche pour revenir sur une coupe), '
                             'puis Couper.' % (n, extra, fr['W'] * 10, fr['t'] * 10))
    return fr, g, geom, errs


def _auto_lock(inputs):
    on = bool(_params.get('auto', True))
    for k in ('tete_mm', 'col_mm', 'conge_mm'):
        it = inputs.itemById(k)
        if it is not None and it.isEnabled == on:
            it.isEnabled = not on


class _InputChangedHandler(adsk.core.InputChangedEventHandler):
    def __init__(self):
        super().__init__()

    def notify(self, args):
        global _loop, _pos, _pos0, _last, _syncing, _act
        try:
            if _syncing:
                return
            # Toujours la collection de la commande : args.inputs est celle du
            # groupe quand le champ modifie est dans le groupe "Puzzle".
            inputs = args.input.parentCommand.commandInputs
            changed = args.input
            if changed.id == 'edge':
                sel = adsk.core.SelectionCommandInput.cast(changed)
                if sel.selectionCount == 0:
                    return
                if time.time() - _bloc_t[0] < 1.0:
                    # Clic sur une fenetre de la vue : l'arete derriere n'est pas une coupe.
                    _bloc_t[0] = 0.0
                    _syncing = True
                    try:
                        sel.clearSelection()
                    finally:
                        _syncing = False
                    return
                s0 = sel.selection(0)
                loop, pos = _build_loop(adsk.fusion.BRepEdge.cast(s0.entity), s0.point)
                _dbg('arete: %s' % ('ok, contour %.1f mm' % (loop['total'] * 10) if loop else pos))
                # La selection est videe aussitot : chaque clic = une coupe
                # de plus, meme sur une arete deja utilisee (un 2e clic sur
                # une arete selectionnee la deselectionnerait).
                _syncing = True
                try:
                    sel.clearSelection()
                finally:
                    _syncing = False
                if loop is None:
                    inputs.itemById('info').formattedText = '<b>%s</b>' % pos
                    return
                if _loop is not None and _last is not None and _last[0] is not None:
                    # La coupe en cours est figee, la fleche passe a la nouvelle
                    # (en derniere position, avec les reglages de la boite).
                    _freeze_active()
                elif _loop is not None:
                    _loop, _last = None, None
                _act = len(_cuts)
                _loop, _pos, _pos0 = loop, pos, pos
            elif changed.id == 'undo':
                # Supprime la coupe en cours (celle de la fenetre bleue).
                if _loop is not None:
                    _delete_cut(inputs, _act)
                elif _cuts:
                    _take(len(_cuts) - 1, inputs)
            elif changed.id == 'pos' and _loop is not None:
                dist = adsk.core.DistanceValueCommandInput.cast(changed)
                _pos = (_pos0 + dist.value) % _loop['total'] if _loop['total'] > 0 else 0.0
            _update(inputs)
        except Exception:
            _dbg('ERREUR inputChanged: ' + traceback.format_exc())


class _ValidateHandler(adsk.core.ValidateInputsEventHandler):
    def __init__(self):
        super().__init__()

    def notify(self, args):
        try:
            # Resultats deja calcules par inputChanged (pas de 2e mesure).
            alls = [c['last'] for c in _all_cuts() if c['last'] is not None]
            args.areInputsValid = bool(alls) and all(r[0] is not None and not r[3] for r in alls)
        except Exception:
            args.areInputsValid = False


class _PreviewHandler(adsk.core.CommandEventHandler):
    def __init__(self):
        super().__init__()

    def notify(self, args):
        try:
            _draw_all(refresh=False)
            _jp_assurer()
            args.isValidResult = False
        except Exception:
            _dbg('ERREUR preview: ' + traceback.format_exc())


class _ExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self):
        super().__init__()

    def notify(self, args):
        try:
            _save_prefs(_params)
            todo = [c['last'] for c in _all_cuts() if c['last'] is not None]
            _clear_preview()
            _ov_clear()
            _tip_clear()
            for i, (fr, g, geom, errs) in enumerate(todo):
                if fr is None or errs:
                    _ui.messageBox('Coupe %d : %s' % (i + 1, errs[0] if errs else 'invalide'), CMD_NAME)
                    return
            # Tous les reperes ont ete mesures AVANT la premiere coupe ; le
            # corps de chaque coupe est retrouve juste avant de couper (une
            # coupe precedente a pu le separer en plusieurs pieces).
            msgs = []
            design = adsk.fusion.Design.cast(_app.activeProduct)
            ps_all = [c['p'] for c in _all_cuts() if c['last'] is not None]
            items = [(t, ps_all[i] if i < len(ps_all) else None) for i, t in enumerate(todo)]
            # Une chronologie ne peut pas imbriquer des groupes : les jonctions
            # simples sont coupees ensemble (un groupe) ; chaque jonction multiple
            # (coupe + corps empiles) a son propre groupe.
            simples = [it for it in items if not (it[0][0].get('stack') or [])]
            multiples = [it for it in items if (it[0][0].get('stack') or [])]
            for lot, suffixe in [(simples, ' simples')] + [([m], ' empilees') for m in multiples]:
                if not lot:
                    continue
                total = sum(1 + len(it[0][0].get('stack') or []) for it in lot)
                tl0 = None
                if total > 1 and design.designType == adsk.fusion.DesignTypes.ParametricDesignType:
                    _batch[0] = True
                    _batch_n[0] = _next_group_index(design)
                    tl0 = (design.timeline.markerPosition, _batch_n[0])
                try:
                    _execute_cuts([it[0] for it in lot], msgs, [it[1] for it in lot])
                finally:
                    _batch[0] = False
                    if tl0 is not None:
                        try:
                            tl = design.timeline
                            if tl.markerPosition > tl0[0]:
                                grp = tl.timelineGroups.add(tl0[0], tl.markerPosition - 1)
                                grp.name = 'Jonctions %d-%d%s' % (tl0[1], _batch_n[0] - 1, suffixe if (simples and multiples) else '')
                                grp.isCollapsed = True
                        except Exception:
                            _dbg('groupe global: ' + traceback.format_exc())
            _dbg('coupe: ' + ' | '.join(msgs))
            # edition depuis l'historique : les anciennes jonctions partent
            # (seulement si toutes les nouvelles coupes ont reussi)
            if _edition['v'] is not None:
                _edition_fin(not any('introuvable' in m for m in msgs))
            bad = [m for m in msgs if 'introuvable' in m or 'MargeAuto :' in m or 'Renfort :' in m]
            if bad:
                _ui.messageBox('\n'.join(bad), CMD_NAME)
        except Exception:
            _dbg('ERREUR execute: ' + traceback.format_exc())
            _ui.messageBox('Echec de la coupe :\n' + traceback.format_exc().strip().splitlines()[-1], CMD_NAME)


def _execute_cuts(todo, msgs, ps=None):
    if True:
        if True:
            if ps is None:
                ps = [c['p'] for c in _all_cuts() if c['last'] is not None]
            for i, (fr0, g, geom, errs) in enumerate(todo):
                # la coupe cliquee puis la meme sur chaque corps empile choisi
                for k_, fr in enumerate([fr0] + list(fr0.get('stack') or [])):
                    _edit_cur['p'] = ps[i] if i < len(ps) else None
                    _edit_cur['sec'] = k_ > 0
                    body = _resolve_body(fr)
                    if body is None:
                        msgs.append('Coupe %d : corps introuvable' % (i + 1))
                        continue
                    fr = dict(fr)
                    fr['body'] = body
                    _param_on[0] = bool(_params.get('param', True))
                    msgs.append(create_jonction(fr, g, geom, _params.get('marge_auto', False)))


class _DestroyHandler(adsk.core.CommandEventHandler):
    def __init__(self):
        super().__init__()

    def notify(self, args):
        global _loop, _last
        _loop = None
        _last = None
        del _cuts[:]
        _balayer_apercus()
        if _edition['v'] is not None:
            try:
                _edition_fin(False)     # annulation : on remet la chronologie
            except Exception:
                _dbg('edition annulee: ' + traceback.format_exc())
        _clear_preview()
        _ov_clear()
        _tip_clear()
        _jd['on'] = False
        _jd.pop('fige', None)
        _jd['pris'] = False
        _jd.pop('ins', None)
        _jp_effacer()
        _cmd_handlers.clear()


# ---------------------------------------------------------------------------
# Edition depuis l'historique CNC (cnc_historique.py, bouton « Modifier »).
# La chronologie est reculee au debut des jonctions choisies (le corps est
# alors tel qu'avant la coupe), les coupes sont rebatties a partir des
# reglages memorises (_memoriser), la commande s'ouvre avec une fenetre
# « JONCTION n » par coupe et sa fleche. A « Couper », les anciennes
# jonctions sont supprimees et les nouvelles les remplacent ; a l'annulation,
# la chronologie revient a la fin sans rien changer.
# ---------------------------------------------------------------------------

def _entrees_groupe(g):
    """Reglages memorises des coupes principales d'un groupe d'historique."""
    res = []
    for i in range(g.count):
        try:
            a = g.item(i).entity.attributes.itemByName(ATTR_G, ATTR_N)
        except Exception:
            a = None
        if a is None:
            continue
        try:
            d = json.loads(a.value)
        except Exception:
            continue
        if not d.get('sec'):
            res.append(d)
    return res


def _boucle_depuis(design, d):
    """(loop, pos) de la coupe memorisee d, dans le corps tel qu'avant la coupe."""
    comp = None
    for c in design.allComponents:
        if c.id == d.get('comp'):
            comp = c
            break
    if comp is None:
        return None, 'composant introuvable'
    O = adsk.core.Point3D.create(*d['O'])
    try:
        es = comp.findBRepUsingPoint(O, adsk.fusion.BRepEntityTypes.BRepEdgeEntityType, 0.01, False)
    except Exception:
        return None, 'recherche d\'arete impossible : ' + traceback.format_exc().strip().splitlines()[-1]
    edges = []
    for k in range(es.count):
        e = adsk.fusion.BRepEdge.cast(es.item(k))
        if e is not None:
            edges.append(e)
    def _prio(e):
        try:
            return 0 if e.body.name == d.get('body') else 1
        except Exception:
            return 2
    edges.sort(key=_prio)
    for e in edges:
        loop, pos = _build_loop(e, O)
        if loop is not None:
            return loop, pos
    return None, 'arete introuvable'


def edit_groups(groups):
    """Appele par cnc_historique.modifier. groups : TimelineGroup des
    jonctions choisies. Retourne (ok, message). En cas d'echec, la
    chronologie est remise en place."""
    tl = None
    try:
        design = adsk.fusion.Design.cast(_app.activeProduct)
        tl = design.timeline
        if _ui.activeCommand == CMD_ID:
            return False, 'La commande Jonction est deja ouverte.'
        entrees, anciens = [], []
        for g in groups:
            e = _entrees_groupe(g)
            if not e:
                return False, 'Jonction creee avant la memorisation des reglages : modification impossible ici.'
            entrees.extend(e)
            anciens.append((g.name, g.item(0).entity.entityToken))
        etats = [(tl.timelineGroups.item(i), tl.timelineGroups.item(i).isCollapsed)
                 for i in range(tl.timelineGroups.count)]
        for gg, _c in etats:
            gg.isCollapsed = False
        debut = min(g.item(0).index for g in groups)
        tl.markerPosition = debut
        coupes = []
        for d in entrees:
            loop, pos = _boucle_depuis(design, d)
            if loop is None:
                raise RuntimeError('Coupe non retrouvee : ' + str(pos))
            p = dict(DEFAULTS)
            p.update(d.get('p') or {})
            coupes.append({'loop': loop, 'pos': pos, 'pos0': pos, 'p': p})
        _edition['v'] = {'anciens': anciens, 'coupes': coupes, 'etats': [(g.name, g.item(0).entity.entityToken, c) for g, c in etats if g.isValid and g.count]}
        cd = _ui.commandDefinitions.itemById(CMD_ID)
        if cd is None:
            run({})
            cd = _ui.commandDefinitions.itemById(CMD_ID)
        if not cd.execute():
            raise RuntimeError('La commande Jonction ne s\'ouvre pas.')
        return True, ''
    except Exception as ex:
        _dbg('edit_groups: ' + traceback.format_exc())
        _edition['v'] = None
        try:
            if tl is not None:
                tl.moveToEnd()
        except Exception:
            pass
        return False, str(ex)[:200]


_EVT_FIN = 'JonctionCNC_edition_fin'
_a_supprimer = []
_evt_keep = []
_evt_essais = [0]


def _replier_tout(tl):
    try:
        tl.moveToEnd()
        for i in range(tl.timelineGroups.count):
            gi = tl.timelineGroups.item(i)
            if gi.isValid and gi.count:
                try:
                    gi.isCollapsed = True
                except Exception:
                    pass
    except Exception:
        pass


def _supprimer_anciens_maintenant():
    """Supprime les anciennes jonctions de l'edition (hors de la commande :
    Fusion refuse de supprimer un groupe pendant l'evenement Execute)."""
    design = adsk.fusion.Design.cast(_app.activeProduct)
    tl = design.timeline
    anciens = list(_a_supprimer)
    del _a_supprimer[:]
    tl.moveToEnd()
    _dbg('edition fin : suppression de %d ancien(s) groupe(s), chronologie %d' % (len(anciens), tl.count))
    manquants = []
    for nom, tok in anciens:
        ok = False
        err = ''
        for essai in (1, 2):
            try:
                g = None
                for i in range(tl.timelineGroups.count):
                    gi = tl.timelineGroups.item(i)
                    if gi.isValid and gi.count and gi.item(0).entity.entityToken == tok:
                        g = gi
                        break
                if g is None:
                    ok = True
                    _dbg('edition fin : groupe %s deja supprime' % nom)
                    break
                if essai == 2:
                    # chronologie reculee au debut du groupe (rien apres n'est calcule)
                    g.isCollapsed = False
                    tl.markerPosition = g.item(0).index
                    g = None
                    for i in range(tl.timelineGroups.count):
                        gi = tl.timelineGroups.item(i)
                        if gi.isValid and gi.count and gi.item(0).entity.entityToken == tok:
                            g = gi
                            break
                    if g is None:
                        ok = True
                        break
                ok = bool(g.deleteMe(True))
                _dbg('edition fin : suppression de %s (essai %d) -> %s' % (nom, essai, ok))
                if essai == 2:
                    tl.moveToEnd()
                if ok:
                    break
            except Exception:
                err = traceback.format_exc()
                _dbg('edition fin : suppression de %s impossible (essai %d) : %s' % (nom, essai, err))
                try:
                    tl.moveToEnd()
                except Exception:
                    pass
        if not ok:
            manquants.append(nom)
    _replier_tout(tl)
    if manquants:
        _ui.messageBox('Les nouvelles coupes sont creees, mais ces anciennes jonctions n\'ont pas pu etre supprimees :\n'
                       + '\n'.join(manquants) + '\n\nSupprime-les dans la chronologie (clic droit > Supprimer).', CMD_NAME)


class _EvtFinHandler(adsk.core.CustomEventHandler):
    def __init__(self):
        super().__init__()

    def notify(self, args):
        try:
            if _ui.activeCommand == CMD_ID:
                # la commande n'est pas encore terminee : on reessaie
                _evt_essais[0] += 1
                if _evt_essais[0] < 300:
                    _app.fireCustomEvent(_EVT_FIN, '')
                    return
            _evt_essais[0] = 0
            _supprimer_anciens_maintenant()
        except Exception:
            _dbg('edition fin (evenement) : ' + traceback.format_exc())


def _enregistrer_evt_fin():
    try:
        _app.unregisterCustomEvent(_EVT_FIN)
    except Exception:
        pass
    ev = _app.registerCustomEvent(_EVT_FIN)
    h = _EvtFinHandler()
    ev.add(h)
    _evt_keep.append(h)


def _edition_fin(supprimer_anciens):
    """Termine l'edition : programme la suppression des anciennes jonctions
    (si on a coupe), remet la chronologie a la fin et replie les groupes."""
    v = _edition['v']
    _edition['v'] = None
    if v is None:
        return
    design = adsk.fusion.Design.cast(_app.activeProduct)
    tl = design.timeline
    if supprimer_anciens:
        _a_supprimer[:] = list(v['anciens'])
        try:
            _enregistrer_evt_fin()
            _app.fireCustomEvent(_EVT_FIN, '')
        except Exception:
            _dbg('edition fin : evenement impossible : ' + traceback.format_exc())
    _replier_tout(tl)


class _CmdCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self):
        super().__init__()

    def notify(self, args):
        global _loop, _pos, _pos0, _params, _last, _act
        try:
            _dbg('commande creee')
            _loop, _pos, _last, _act = None, 0.0, None, 0
            del _cuts[:]
            _ov_clear()
            _params = _load_prefs()
            ed = _edition['v']
            if ed is not None:
                # edition : reglages et coupes viennent de l'historique
                try:
                    _tl_ = adsk.fusion.Design.cast(_app.activeProduct).timeline
                    _dbg('edition : %d coupe(s), curseur %d / %d' % (len(ed['coupes']), _tl_.markerPosition, _tl_.count))
                except Exception:
                    pass
                _params = dict(ed['coupes'][-1]['p'])
            cmd = args.command
            cmd.okButtonText = 'Couper'
            cmd.isRepeatable = True
            inputs = cmd.commandInputs
            sel = inputs.addSelectionInput('edge', 'Arete', "Clique sur une arete de la bande")
            sel.addSelectionFilter('Edges')
            # 0 mini : la selection est videe a chaque clic (une coupe par clic).
            sel.setSelectionLimits(0, 1)
            dist = inputs.addDistanceValueCommandInput('pos', 'Decalage', adsk.core.ValueInput.createByReal(0.0))
            dist.isVisible = False
            undo = inputs.addBoolValueInput('undo', 'Retirer la coupe en cours', False, '', False)
            undo.isEnabled = False
            dd = inputs.addDropDownCommandInput('forme', 'Forme', adsk.core.DropDownStyles.TextListDropDownStyle)
            for key, label in _FORMES:
                dd.listItems.add(label, _params.get('forme') == key)
            grp = inputs.addGroupCommandInput('grpPuzzle', 'Puzzle')
            gi = grp.children
            gi.addBoolValueInput('auto', 'Auto (selon la largeur)', True, '', bool(_params.get('auto', True)))
            gi.addValueInput('tete_mm', 'Diametre de tete', 'mm', adsk.core.ValueInput.createByReal(_params['tete_mm'] / 10.0))
            gi.addValueInput('col_mm', 'Largeur du col', 'mm', adsk.core.ValueInput.createByReal(_params['col_mm'] / 10.0))
            gi.addValueInput('conge_mm', 'Rayon des conges', 'mm', adsk.core.ValueInput.createByReal(_params['conge_mm'] / 10.0))
            gi.addBoolValueInput('flip', 'Inverser le cote du tenon', True, '', bool(_params.get('flip', False)))
            grp.isVisible = _params.get('forme') == 'puzzle'
            _auto_lock(inputs)
            inputs.addValueInput('jeu_mm', 'Jeu de fonctionnement', 'mm',
                                 adsk.core.ValueInput.createByReal(_params.get('jeu_mm', 0.0) / 10.0))
            rd = inputs.addDropDownCommandInput('renf', 'Renfort', adsk.core.DropDownStyles.TextListDropDownStyle)
            for key, label in _RENF:
                rd.listItems.add(label, _params.get('renf') == key)
            gr = inputs.addGroupCommandInput('grpRenf', 'Cale')
            gri = gr.children
            gri.addValueInput('renf_am_mm', 'Longueur en amont', 'mm', adsk.core.ValueInput.createByReal(_params['renf_am_mm'] / 10.0))
            gri.addValueInput('renf_av_mm', 'Longueur en aval', 'mm', adsk.core.ValueInput.createByReal(_params['renf_av_mm'] / 10.0))
            gr.isVisible = _params.get('renf') == 'cale'
            inputs.addBoolValueInput('marge_auto', 'MargeAuto', True, '', bool(_params.get('marge_auto', False)))
            inputs.addBoolValueInput('param', 'Parametrique (suit la courbe)', True, '', bool(_params.get('param', True)))
            info = inputs.addTextBoxCommandInput('info', '', "Clique sur une arete de la bande.", 3, True)
            info.isFullWidth = True
            if ed is not None:
                # coupes d'abord (sinon _update ne voit rien a dessiner)
                try:
                    for c in ed['coupes'][:-1]:
                        c['last'] = _compute(c['loop'], c['pos'], c['p'])
                        _cuts.append(c)
                    c = ed['coupes'][-1]
                    _loop, _pos, _pos0 = c['loop'], c['pos'], c['pos0']
                    _act = len(_cuts)
                except Exception:
                    _dbg('edition prechargement: ' + traceback.format_exc())
                _no_draw[0] = True      # aucun dessin hors de l'evenement d'apercu
                try:
                    _update(inputs)
                except Exception:
                    _dbg('edition affichage: ' + traceback.format_exc())
                finally:
                    _no_draw[0] = False
            for evt, h in ((cmd.inputChanged, _InputChangedHandler()),
                           (cmd.validateInputs, _ValidateHandler()),
                           (cmd.executePreview, _PreviewHandler()),
                           (cmd.execute, _ExecuteHandler()),
                           (cmd.destroy, _DestroyHandler()),
                           (cmd.mouseDown, _MouseDownHandler()),
                           (cmd.mouseDrag, _MouseDragHandler()),
                           (cmd.mouseUp, _MouseUpHandler()),
                           (cmd.preSelect, _PreSelectHandler()),
                           (cmd.mouseMove, _MouseMoveHandler())):
                evt.add(h)
                _cmd_handlers.append(h)
            if ed is not None:
                try:
                    cmd.doExecutePreview()
                except Exception:
                    _dbg('edition apercu: ' + traceback.format_exc())
        except Exception:
            _dbg('ERREUR commandCreated: ' + traceback.format_exc())
            _ui.messageBox('Erreur Jonction CNC:\n' + traceback.format_exc(), CMD_NAME)


# ---------------------------------------------------------------------------
# Palette : la carte "Jonction" lance la commande (appele par ToolkitCNC.py
# pour toute action "jonction_*")
# ---------------------------------------------------------------------------

def handle_palette_action(action, data):
    if action == 'jonction_open':
        # La palette revient au menu : tout se passe dans la commande.
        _send('jonction_force_reset', {})
        try:
            act = _ui.activeCommand
            cd = _ui.commandDefinitions.itemById(CMD_ID)
            _dbg('ouverture demandee (commande active: %s, definition: %s)' % (act, cd is not None))
            if act != CMD_ID:
                if cd is None:
                    run({})
                    cd = _ui.commandDefinitions.itemById(CMD_ID)
                ok = cd.execute()
                _dbg('execute -> %s' % ok)
        except Exception:
            _dbg('ERREUR lancement commande: ' + traceback.format_exc())


def run(context):
    global _app, _ui
    try:
        _app = adsk.core.Application.get()
        _ui = _app.userInterface
        old = _ui.commandDefinitions.itemById(CMD_ID)
        if old:
            old.deleteMe()
        cmd_def = _ui.commandDefinitions.addButtonDefinition(CMD_ID, CMD_NAME, CMD_DESC)
        h = _CmdCreatedHandler()
        cmd_def.commandCreated.add(h)
        _handlers.append(h)
    except Exception:
        if _ui:
            _ui.messageBox('Erreur au demarrage de Jonction CNC:\n' + traceback.format_exc())


def stop(context):
    _dv_arreter()
    try:
        _clear_preview()
        _ov_clear()
        cmd_def = _ui.commandDefinitions.itemById(CMD_ID)
        if cmd_def:
            cmd_def.deleteMe()
    except Exception:
        if _ui:
            _ui.messageBox("Erreur a l'arret de Jonction CNC:\n" + traceback.format_exc())
