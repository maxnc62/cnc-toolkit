
import adsk.core
import adsk.fusion
import traceback
import os
import json

_app              = None
_ui               = None
_cmd_def_create   = None
_cmd_def_edit     = None
_panel_ctrl       = None
_custom_feat_def  = None
_compute_handler  = None
_marking_handler  = None

_create_created   = None
_create_execute   = None
_create_destroy   = None
_edit_created     = None
_edit_execute     = None
_edit_destroy     = None

# Nom de la CF ciblee par le clic droit
_cf_cible_name = None

CUSTOM_FEAT_ID = 'Autodesk.EntailleAutomatique'
CMD_CREATE_ID  = 'EntailleAutomatiqueCmd'
CMD_EDIT_ID    = 'EntailleAutomatiqueEditCmd'
PARAM_DEPTH    = 'retrait_profondeur'
PARAM_JEU      = 'jeu_lateral'
PARAM_EPAISSEUR = 'epaisseur_outil'
PARAM_JEU_ON   = 'jeu_actif'
SETTINGS_FILE  = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'settings.json')


def load_last_depth():
    try:
        if os.path.exists(SETTINGS_FILE):
            with open(SETTINGS_FILE, 'r') as f:
                return float(json.load(f).get('last_depth_cm', -0.05))
    except Exception:
        pass
    return -0.05

def save_last_depth(depth_cm):
    try:
        with open(SETTINGS_FILE, 'w') as f:
            data = {}
            if os.path.exists(SETTINGS_FILE):
                with open(SETTINGS_FILE, 'r') as fr:
                    try: data = json.load(fr)
                    except: pass
            data['last_depth_cm'] = depth_cm
            json.dump(data, f)
    except Exception:
        pass

def load_last_jeu():
    try:
        if os.path.exists(SETTINGS_FILE):
            data = json.load(open(SETTINGS_FILE))
            return float(data.get('last_jeu_cm', 0.02)), bool(data.get('jeu_actif', True))
    except Exception:
        pass
    return -0.02, True  # -0.2mm par defaut, actif

def save_last_jeu(jeu_cm, actif):
    try:
        data = {}
        if os.path.exists(SETTINGS_FILE):
            with open(SETTINGS_FILE, 'r') as f:
                try: data = json.load(f)
                except: pass
        data['last_jeu_cm'] = jeu_cm
        data['jeu_actif']   = actif
        with open(SETTINGS_FILE, 'w') as f:
            json.dump(data, f)
    except Exception:
        pass

def get_epaisseur(body):
    bb = body.boundingBox
    return min(
        bb.maxPoint.x - bb.minPoint.x,
        bb.maxPoint.y - bb.minPoint.y,
        bb.maxPoint.z - bb.minPoint.z
    )

def find_cf_by_name(design, name):
    timeline = design.timeline
    for i in range(timeline.count):
        cf = adsk.fusion.CustomFeature.cast(timeline.item(i).entity)
        if cf and cf.name == name:
            return cf
    return None


# ================================================================
# MARKING MENU : ajoute "Modifier Entaille" au clic droit
# sur une custom feature Entaille
# ================================================================
class MarkingMenuHandler(adsk.core.MarkingMenuEventHandler):
    def __init__(self): super().__init__()

    def notify(self, args):
        global _cf_cible_name
        try:
            eventArgs = adsk.core.MarkingMenuEventArgs.cast(args)

            # selectedEntities est un array Python natif
            # On cherche UNIQUEMENT parmi les entites directement cliquees
            # Pas de fallback sur le marker : trop permissif
            entities = eventArgs.selectedEntities
            cf_found = None
            for e in entities:
                cf = adsk.fusion.CustomFeature.cast(e)
                if cf and cf.definition and cf.definition.id == CUSTOM_FEAT_ID:
                    cf_found = cf
                    break

            # N ajoute le bouton QUE si on a clique sur une CF Entaille
            if cf_found is None:
                return

            # Stocke le nom de CETTE entaille specifique
            _cf_cible_name = cf_found.name
            linear = eventArgs.linearMarkingMenu
            linear.controls.addCommand(_cmd_def_edit)

        except Exception:
            pass


# ================================================================
# COMMANDE CREATION
# ================================================================
class CreateCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        global _create_execute, _create_destroy
        try:
            cmd    = adsk.core.CommandCreatedEventArgs.cast(args).command
            _create_execute = CreateExecuteHandler()
            _create_destroy = GenericDestroyHandler()
            cmd.execute.add(_create_execute)
            cmd.destroy.add(_create_destroy)
            inputs = cmd.commandInputs
            sel_t = inputs.addSelectionInput(
                'targetBody', '1. Corps a couper',
                'Selectionnez le corps qui recevra les entailles'
            )
            sel_t.addSelectionFilter('Bodies')
            sel_t.setSelectionLimits(1, 1)
            sel_o = inputs.addSelectionInput(
                'toolBodies', '2. Corps de decoupe',
                'Selectionnez le ou les corps formant les entailles'
            )
            sel_o.addSelectionFilter('Bodies')
            sel_o.setSelectionLimits(1, 0)
            last = load_last_depth()
            inputs.addValueInput(PARAM_DEPTH, 'Retrait profondeur', 'mm',
                adsk.core.ValueInput.createByReal(last))

            last_jeu, jeu_on = load_last_jeu()
            inputs.addBoolValueInput(PARAM_JEU_ON, 'Jeu lateral actif', True, '', jeu_on)
            inputs.addValueInput(PARAM_JEU, 'Jeu lateral (mm)', 'mm',
                adsk.core.ValueInput.createByReal(last_jeu))  # negatif = retrait

        except Exception:
            _ui.messageBox('Erreur creation dialogue:\n' + traceback.format_exc())


class CreateExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            inputs    = adsk.core.CommandEventArgs.cast(args).firingEvent.sender.commandInputs
            si_target = inputs.itemById('targetBody')
            si_tools  = inputs.itemById('toolBodies')
            si_depth  = inputs.itemById(PARAM_DEPTH)
            depth_cm  = si_depth.value
            if si_target.selectionCount < 1 or si_tools.selectionCount < 1:
                _ui.messageBox('Selectionnez un corps cible et un corps de decoupe.')
                return
            si_jeu_on = inputs.itemById(PARAM_JEU_ON)
            si_jeu    = inputs.itemById(PARAM_JEU)
            jeu_cm    = si_jeu.value if (si_jeu_on and si_jeu_on.value) else 0.0
            save_last_jeu(si_jeu.value if si_jeu else -0.02, si_jeu_on.value if si_jeu_on else True)
            save_last_depth(depth_cm)
            design = adsk.fusion.Design.cast(_app.activeProduct)
            root   = design.rootComponent
            target_body = adsk.fusion.BRepBody.cast(si_target.selection(0).entity)
            tool_bodies = [
                adsk.fusion.BRepBody.cast(si_tools.selection(i).entity)
                for i in range(si_tools.selectionCount)
            ]
            combine_feats = root.features.combineFeatures
            def aire_key(f): return round(f.area, 2)
            compteur_avant = {}
            for face in target_body.faces:
                if face.geometry.objectType != adsk.core.Plane.classType(): continue
                k = aire_key(face)
                compteur_avant[k] = compteur_avant.get(k, 0) + 1
            col1 = adsk.core.ObjectCollection.create()
            for b in tool_bodies: col1.add(b)
            ci1 = combine_feats.createInput(target_body, col1)
            ci1.operation        = adsk.fusion.FeatureOperations.CutFeatureOperation
            ci1.isKeepToolBodies = True
            feat1 = combine_feats.add(ci1)
            epaisseur_cm       = min(get_epaisseur(tb) for tb in tool_bodies)
            aire_cible         = epaisseur_cm * epaisseur_cm
            aire_min, aire_max = aire_cible * 0.90, aire_cible * 1.10
            compteur_apres = {}
            faces_par_aire = {}
            for face in target_body.faces:
                if face.geometry.objectType != adsk.core.Plane.classType(): continue
                k = aire_key(face)
                compteur_apres[k] = compteur_apres.get(k, 0) + 1
                faces_par_aire.setdefault(k, []).append(face)
            faces_nouvelles = []
            for k, nb_ap in compteur_apres.items():
                surplus = nb_ap - compteur_avant.get(k, 0)
                if surplus > 0:
                    faces_nouvelles.extend(faces_par_aire[k][:surplus])
            faces_fond    = [f for f in faces_nouvelles if aire_min <= f.area <= aire_max]
            faces_lateral = [f for f in faces_nouvelles if f not in faces_fond]
            offset_feats = root.features.offsetFacesFeatures
            last_offset  = None
            for face in faces_fond:
                try:
                    oi = offset_feats.createInput([face], adsk.core.ValueInput.createByReal(depth_cm))
                    r  = offset_feats.add(oi)
                    if r: last_offset = r
                except Exception:
                    continue
            if jeu_cm != 0.0 and faces_lateral:
                for face in faces_lateral:
                    try:
                        oi = offset_feats.createInput([face], adsk.core.ValueInput.createByReal(jeu_cm))
                        r  = offset_feats.add(oi)
                        if r: last_offset = r
                    except Exception:
                        continue
            # --- ETAPE 3 : Combine Couper inverse (cible -> outils) ---
            # Snapshot : pour chaque corps outil, on stocke
            # l aire maximale de ses faces planes (= aire des grandes faces originales)
            # Les nouvelles faces creees par l entaille seront forcement plus petites
            snapshots_outils = {}
            for tb in tool_bodies:
                aires_orig = []
                for face in tb.faces:
                    if face.geometry.objectType == adsk.core.Plane.classType():
                        aires_orig.append(face.area)
                # Seuil : on ne touchera que les faces < min des grandes faces
                # On prend la plus petite des grandes faces comme seuil max
                aires_orig.sort()
                # La plus petite face originale = seuil max pour les nouvelles
                seuil_max = aires_orig[0] * 0.95 if aires_orig else 999
                snapshots_outils[id(tb)] = (tb, seuil_max)

            col_inv  = adsk.core.ObjectCollection.create()
            col_inv.add(target_body)
            last_inv = None
            for tb in tool_bodies:
                ci_inv = combine_feats.createInput(tb, col_inv)
                ci_inv.operation        = adsk.fusion.FeatureOperations.CutFeatureOperation
                ci_inv.isKeepToolBodies = True
                last_inv = combine_feats.add(ci_inv)

            # --- ETAPE 4 : Jeu lateral sur les corps outils ---
            last_jeu_outil = None  # garde la derniere feature pour end_feat
            if jeu_cm != 0.0:
                for tb_id, (tb, seuil_max) in snapshots_outils.items():
                    # Nouvelles faces des corps outils
                    # Nouvelles faces = faces dont l aire < seuil_max
                    # (les faces originales du corps outil sont toutes >= seuil_max)
                    nouvelles_outil = [
                        face for face in tb.faces
                        if face.geometry.objectType == adsk.core.Plane.classType()
                        and face.area < seuil_max
                    ]
                    # Filtre : exclut les faces dont l aire est proche
                    # de l aire de fond (epaisseur^2) - ce sont les fonds de l entaille
                    # dans le corps outil, qu on ne doit PAS decaler
                    # On utilise une zone d exclusion elargie autour de l aire de fond
                    aire_fond_cm2 = epaisseur_cm * epaisseur_cm
                    exclusion_min = aire_fond_cm2 * 0.70  # marge large pour capturer
                    exclusion_max = aire_fond_cm2 * 1.30  # tous les fonds
                    laterales_outil = [
                        f for f in nouvelles_outil
                        if not (exclusion_min <= f.area <= exclusion_max)
                    ]
                    # Applique le jeu sur les laterales uniquement
                    for face in laterales_outil:
                        try:
                            oi = offset_feats.createInput([face],
                                adsk.core.ValueInput.createByReal(jeu_cm))
                            r = offset_feats.add(oi)
                            if r: last_jeu_outil = r
                        except Exception:
                            continue
            # end_feat = la derniere feature creee (inclut le jeu outils)
            end_feat = last_jeu_outil or last_inv or last_offset or feat1
            cf_input = root.features.customFeatures.createInput(_custom_feat_def)
            cf_input.addCustomParameter(PARAM_DEPTH, 'Retrait',
                adsk.core.ValueInput.createByReal(depth_cm), 'mm', True)
            cf_input.addCustomParameter(PARAM_JEU, 'Jeu lateral',
                adsk.core.ValueInput.createByReal(jeu_cm), 'mm', True)
            cf_input.addCustomParameter(PARAM_EPAISSEUR, 'Epaisseur outil',
                adsk.core.ValueInput.createByReal(epaisseur_cm), 'mm', False)
            cf_input.setStartAndEndFeatures(feat1, end_feat)
            root.features.customFeatures.add(cf_input)
            _app.activeViewport.fit()
        except Exception:
            _ui.messageBox('Erreur execution creation:\n' + traceback.format_exc())

class EditCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        global _edit_execute, _edit_destroy
        try:
            cmd    = adsk.core.CommandCreatedEventArgs.cast(args).command
            _edit_execute = EditExecuteHandler()
            _edit_destroy = GenericDestroyHandler()
            cmd.execute.add(_edit_execute)
            cmd.destroy.add(_edit_destroy)
            inputs = cmd.commandInputs
            design   = adsk.fusion.Design.cast(_app.activeProduct)
            cf_cible = find_cf_by_name(design, _cf_cible_name) if _cf_cible_name else None
            if cf_cible is None:
                _ui.messageBox('Aucune feature Entaille ciblee.')
                return
            # Valeur retrait actuelle
            cur_depth = load_last_depth()
            try:
                p = cf_cible.parameters.itemById(PARAM_DEPTH)
                if p: cur_depth = p.value
            except: pass
            inputs.addValueInput(PARAM_DEPTH, 'Retrait profondeur', 'mm',
                adsk.core.ValueInput.createByReal(cur_depth))
            # Valeur jeu actuelle
            cur_jeu = -0.02
            try:
                p = cf_cible.parameters.itemById(PARAM_JEU)
                if p: cur_jeu = p.value
            except: pass
            _, jeu_on = load_last_jeu()
            inputs.addBoolValueInput(PARAM_JEU_ON, 'Jeu lateral actif', True, '', jeu_on)
            inputs.addValueInput(PARAM_JEU, 'Jeu lateral (mm)', 'mm',
                adsk.core.ValueInput.createByReal(cur_jeu))
            flag = inputs.addStringValueInput('_cf_name', '', cf_cible.name)
            flag.isVisible = False
            inputs.addTextBoxCommandInput('info', '',
                f'Edition : <b>{cf_cible.name}</b>', 1, True)
        except Exception:
            _ui.messageBox('Erreur edition dialogue:\n' + traceback.format_exc())


class EditExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        global _cf_cible_name
        try:
            inputs    = adsk.core.CommandEventArgs.cast(args).firingEvent.sender.commandInputs
            si_depth  = inputs.itemById(PARAM_DEPTH)
            si_jeu_on = inputs.itemById(PARAM_JEU_ON)
            si_jeu    = inputs.itemById(PARAM_JEU)
            cf_name   = inputs.itemById('_cf_name')
            depth_cm  = si_depth.value
            jeu_cm    = si_jeu.value if (si_jeu_on and si_jeu_on.value) else 0.0
            save_last_depth(depth_cm)
            save_last_jeu(si_jeu.value if si_jeu else -0.02,
                          si_jeu_on.value if si_jeu_on else True)
            design   = adsk.fusion.Design.cast(_app.activeProduct)
            cf_cible = find_cf_by_name(design, cf_name.value) if cf_name else None
            if cf_cible is None:
                _ui.messageBox('Feature introuvable.')
                return
            # Recupere les anciens parametres pour identifier fond vs lateral
            try:   param_depth  = cf_cible.parameters.itemById(PARAM_DEPTH)
            except: param_depth = None
            try:   param_jeu_cf = cf_cible.parameters.itemById(PARAM_JEU)
            except: param_jeu_cf = None
            try:   param_ep = cf_cible.parameters.itemById(PARAM_EPAISSEUR)
            except: param_ep = None
            old_depth = param_depth.value  if param_depth  else depth_cm
            old_jeu   = param_jeu_cf.value if param_jeu_cf else jeu_cm

            # OPTIMISATION : deplace le marker AVANT la CF
            # pour que Fusion ne recalcule que la CF et pas toute la timeline
            # lors de chaque modification de parametre
            timeline = design.timeline
            marker_original = timeline.markerPosition

            # Trouve l index de la CF dans la timeline
            cf_index = None
            for i in range(timeline.count):
                item = timeline.item(i)
                cf_check = adsk.fusion.CustomFeature.cast(item.entity)
                if cf_check and cf_check.name == cf_cible.name:
                    cf_index = item.index
                    break

            # Rollback juste avant la CF pour bloquer le recalcul
            if cf_index is not None:
                timeline.markerPosition = cf_index

            try:
                # Modifie tous les parametres (pas de recalcul pendant rollback)
                for f in list(cf_cible.features):
                    of = adsk.fusion.OffsetFacesFeature.cast(f)
                    if not of: continue
                    try:
                        cur = of.distance.value
                        if abs(old_depth - old_jeu) < 1e-6:
                            is_fond = True
                        else:
                            is_fond = abs(cur - old_depth) <= abs(cur - old_jeu)
                        new_val = depth_cm if is_fond else jeu_cm
                        try:   of.distance.value = new_val
                        except: of.distance.expression = f'{round(new_val*10,4)} mm'
                    except Exception:
                        continue
                # Parametres CF
                if param_depth:  param_depth.value  = depth_cm
                if param_jeu_cf: param_jeu_cf.value = jeu_cm
            finally:
                # Remet le marker a la fin = recalcul unique de toute la timeline
                timeline.markerPosition = marker_original

            _cf_cible_name = None
        except Exception:
            _ui.messageBox('Erreur execution edition:\n' + traceback.format_exc())


class MyComputeHandler(adsk.fusion.CustomFeatureEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            eventArgs = adsk.fusion.CustomFeatureEventArgs.cast(args)
            cf = eventArgs.customFeature
            if cf is None:
                return

            # Synchronise les parametres CF avec l etat reel des features
            # pour eviter l icone jaune apres edition
            try:
                param_depth = cf.parameters.itemById(PARAM_DEPTH)
            except: param_depth = None
            try:
                param_jeu = cf.parameters.itemById(PARAM_JEU)
            except: param_jeu = None

            if param_depth is None and param_jeu is None:
                return

            # Lit les valeurs actuelles des OffsetFacesFeatures
            depths = []
            jeus   = []
            old_depth = param_depth.value if param_depth else None
            old_jeu   = param_jeu.value   if param_jeu   else None

            for f in list(cf.features):
                of = adsk.fusion.OffsetFacesFeature.cast(f)
                if not of: continue
                try:
                    cur = of.distance.value
                    if old_depth is not None and old_jeu is not None:
                        if abs(old_depth - old_jeu) < 1e-6:
                            depths.append(cur)
                        elif abs(cur - old_depth) <= abs(cur - old_jeu):
                            depths.append(cur)
                        else:
                            jeus.append(cur)
                    elif old_depth is not None:
                        depths.append(cur)
                except: continue

            # Met a jour les parametres avec les vraies valeurs
            # seulement si elles ont change (evite boucle infinie)
            if depths and param_depth:
                avg_depth = sum(depths) / len(depths)
                if abs(avg_depth - param_depth.value) > 1e-6:
                    param_depth.value = avg_depth

            if jeus and param_jeu:
                avg_jeu = sum(jeus) / len(jeus)
                if abs(avg_jeu - param_jeu.value) > 1e-6:
                    param_jeu.value = avg_jeu

        except Exception:
            pass

class GenericDestroyHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args): pass


# ================================================================
def run(context):
    global _app, _ui, _cmd_def_create, _cmd_def_edit, _panel_ctrl
    global _create_created, _edit_created
    global _custom_feat_def, _compute_handler, _marking_handler
    try:
        _app = adsk.core.Application.get()
        _ui  = _app.userInterface

        panel = _ui.allToolbarPanels.itemById('SolidModifyPanel')
        if panel:
            c = panel.controls.itemById(CMD_CREATE_ID)
            if c: c.deleteMe()
        for cid in [CMD_CREATE_ID, CMD_EDIT_ID]:
            old = _ui.commandDefinitions.itemById(cid)
            if old: old.deleteMe()

        # Commande creation
        _cmd_def_create = _ui.commandDefinitions.addButtonDefinition(
            CMD_CREATE_ID, 'Entaille Automatique',
            'Creer une entaille entre deux corps', ''
        )
        _create_created = CreateCreatedHandler()
        _cmd_def_create.commandCreated.add(_create_created)

        # Commande edition
        _cmd_def_edit = _ui.commandDefinitions.addButtonDefinition(
            CMD_EDIT_ID, 'Modifier Entaille',
            'Modifier le retrait de cette entaille', ''
        )
        _edit_created = EditCreatedHandler()
        _cmd_def_edit.commandCreated.add(_edit_created)

        # Custom Feature
        addin_dir = os.path.dirname(os.path.abspath(__file__))
        _custom_feat_def = adsk.fusion.CustomFeatureDefinition.create(
            CUSTOM_FEAT_ID, 'Entaille', addin_dir
        )
        _custom_feat_def.editCommandId = CMD_EDIT_ID
        _compute_handler = MyComputeHandler()
        _custom_feat_def.customFeatureCompute.add(_compute_handler)

        # Marking menu : ajoute l option au clic droit
        _marking_handler = MarkingMenuHandler()
        _ui.markingMenuDisplaying.add(_marking_handler)

        # Bouton de ruban (SolidModifyPanel) RETIRE : devenu inutile
        # depuis la creation de CNC Toolkit, qui retrouve et execute
        # _cmd_def_create directement depuis sa palette. La commande
        # d'edition (_cmd_def_edit) reste accessible comme avant via le
        # clic droit (marking menu) et l'edition de la custom feature -
        # aucun changement de ce cote.

    except Exception:
        if _ui:
            _ui.messageBox('Erreur run:\n' + traceback.format_exc())


def stop(context):
    global _cmd_def_create, _cmd_def_edit, _panel_ctrl
    global _custom_feat_def, _compute_handler, _marking_handler
    global _create_created, _create_execute, _create_destroy
    global _edit_created, _edit_execute, _edit_destroy
    try:
        if _marking_handler:
            _ui.markingMenuDisplaying.remove(_marking_handler)
        if _panel_ctrl:     _panel_ctrl.deleteMe()
        if _cmd_def_create: _cmd_def_create.deleteMe()
        if _cmd_def_edit:   _cmd_def_edit.deleteMe()
        _cmd_def_create = _cmd_def_edit = _panel_ctrl = None
        _custom_feat_def = _compute_handler = _marking_handler = None
        _create_created = _create_execute = _create_destroy = None
        _edit_created   = _edit_execute   = _edit_destroy   = None
    except Exception:
        pass
