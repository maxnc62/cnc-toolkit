import adsk.core
import adsk.fusion
import traceback
import os
import json
import sys
import time

# Barre de chargement commune du Toolkit (ToolkitCNC/cnc_progress.py)
_TK_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _TK_DIR not in sys.path:
    sys.path.append(_TK_DIR)
import cnc_progress

_app = None
_ui = None
_cmd_def = None
_panel_ctrl = None
_created_handler = None
_execute_handler = None
_validate_handler = None
_destroy_handler = None

CMD_ID       = 'MortaiseCNCCmd'
COMMAND_NAME = 'Mortaise CNC'
COMMAND_DESC = 'Decoupe automatiquement les mortaises correspondant aux tenons Tenons CNC'
PANEL_IDS    = ['SolidModifyPanel', 'SolidCreatePanel', 'SketchCreatePanel', 'ToolsPanel']

_ADDIN_DIR     = os.path.dirname(os.path.abspath(__file__))
DEBUG_LOG      = os.path.join(_ADDIN_DIR, 'mortaise_debug.log')
FACE_MAP_FILE  = os.path.join(_ADDIN_DIR, 'mortaise_face_map.json')
# Fichier partage avec l'add-in "Marge CNC" (meme dossier AddIns) : liste des
# parois de mortaise reellement creees, pour que Marge CNC applique le jeu
# de fonctionnement sans avoir a re-detecter les mortaises geometriquement.
# Mortaise CNC ne gere plus aucun jeu lui-meme : c'est desormais le role
# exclusif de Marge CNC.


def _load_face_map():
    try:
        with open(FACE_MAP_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return []


def _save_face_map(records):
    try:
        with open(FACE_MAP_FILE, 'w', encoding='utf-8') as f:
            json.dump(records, f, indent=2)
    except Exception:
        pass


def _record_mortaise_faces(male, female, face_tokens, cavities=None):
    """Ajoute un enregistrement {male_token, female_token, face_tokens} au
    fichier partage, pour que Marge CNC puisse retrouver EXACTEMENT les
    parois de cette mortaise plus tard (pas de detection geometrique).

    `cavities`, quand fourni, est la liste des face_tokens deja regroupes
    par CAVITE DISTINCTE (voir _group_by_shared_edges) : un seul
    enregistrement peut couvrir plusieurs mortaises independantes (ex. une
    rangee de N tenons decoupee en un seul Cut dans le meme corps femelle),
    et Marge CNC a besoin de savoir OU s'arrete chacune pour exclure UN
    fond par cavite (et non un seul fond pour tout l'enregistrement - voir
    MargeCNC._resolve_faces). Champ additif : un lecteur qui l'ignore
    retombe sur 'face_tokens' seul, comme avant."""
    if not face_tokens:
        return
    try:
        records = _load_face_map()
        rec = {
            'male_token':   male.entityToken,
            'female_token': female.entityToken,
            'face_tokens':  list(face_tokens),
        }
        if cavities:
            rec['cavities'] = [list(grp) for grp in cavities]
        records.append(rec)
        _save_face_map(records)
    except Exception:
        _dbg('_record_mortaise_faces: erreur sauvegarde: ' + traceback.format_exc())


def _group_by_shared_edges(items):
    """items : liste de (cle, face). Regroupe par COMPOSANTE CONNEXE selon
    les aretes partagees (meme entityToken d'arete) - deux parois qui
    partagent une arete appartiennent a la meme cavite (parois adjacentes
    d'un meme creux). Retourne une liste de groupes, chaque groupe etant
    une liste d'INDICES dans `items`.

    Sert a separer les parois de PLUSIEURS mortaises/tenons distincts qui
    peuvent se retrouver dans le MEME enregistrement (ex: une rangee de N
    tenons decoupee en un seul Cut dans le meme corps femelle) - sans ca,
    'exclure le fond' (Marge CNC) ne peut exclure qu'UNE SEULE face pour
    tout l'enregistrement au lieu d'une par cavite (bug signale : "la
    detection exclure les fond de mortaise se fait mal")."""
    n = len(items)
    edge_map = {}
    for idx, (_key, f) in enumerate(items):
        try:
            for e in f.edges:
                edge_map.setdefault(e.entityToken, []).append(idx)
        except Exception:
            pass
    parent = list(range(n))
    def _find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    def _union(a, b):
        ra, rb = _find(a), _find(b)
        if ra != rb:
            parent[ra] = rb
    for idxs in edge_map.values():
        for i in range(1, len(idxs)):
            _union(idxs[0], idxs[i])
    groups = {}
    for i in range(n):
        groups.setdefault(_find(i), []).append(i)
    return list(groups.values())


def _dbg(msg):
    try:
        with open(DEBUG_LOG, 'a', encoding='utf-8') as f:
            f.write(time.strftime('%H:%M:%S') + ' ' + str(msg) + '\n')
    except:
        pass


def _bbox_overlap(body_a, body_b, tol=-0.001):
    """Vrai si les bounding box des deux corps se chevauchent reellement en
    3D (tol legerement negatif = exige un vrai recouvrement de volume, pas
    juste un contact de surface), pour eviter de tenter une decoupe sur des
    couples male/femelle qui ne se touchent pas du tout."""
    try:
        a = body_a.boundingBox
        b = body_b.boundingBox
        return (a.minPoint.x <= b.maxPoint.x + tol and a.maxPoint.x >= b.minPoint.x - tol and
                a.minPoint.y <= b.maxPoint.y + tol and a.maxPoint.y >= b.minPoint.y - tol and
                a.minPoint.z <= b.maxPoint.z + tol and a.maxPoint.z >= b.minPoint.z - tol)
    except:
        return False


def _bbox_overlap_pt(bbox_a, bbox_b, tol=0.01):
    """Comme _bbox_overlap mais directement sur deux BoundingBox3D (pas des
    corps), avec une tolerance positive (recouvrement approximatif accepte) :
    sert a verifier que deux faces coplanaires sont bien au meme endroit
    (et pas juste sur le meme plan infini, ailleurs sur la piece)."""
    try:
        return (bbox_a.minPoint.x <= bbox_b.maxPoint.x + tol and bbox_a.maxPoint.x >= bbox_b.minPoint.x - tol and
                bbox_a.minPoint.y <= bbox_b.maxPoint.y + tol and bbox_a.maxPoint.y >= bbox_b.minPoint.y - tol and
                bbox_a.minPoint.z <= bbox_b.maxPoint.z + tol and bbox_a.maxPoint.z >= bbox_b.minPoint.z - tol)
    except Exception:
        return False


def _bbox_intersection_bounds(bbox_a, bbox_b):
    """Retourne (minx, miny, minz, maxx, maxy, maxz) de l'intersection de
    deux BoundingBox3D (en supposant qu'elles se chevauchent deja - verifie
    en amont par _bbox_overlap)."""
    return (
        max(bbox_a.minPoint.x, bbox_b.minPoint.x),
        max(bbox_a.minPoint.y, bbox_b.minPoint.y),
        max(bbox_a.minPoint.z, bbox_b.minPoint.z),
        min(bbox_a.maxPoint.x, bbox_b.maxPoint.x),
        min(bbox_a.maxPoint.y, bbox_b.maxPoint.y),
        min(bbox_a.maxPoint.z, bbox_b.maxPoint.z),
    )


def _bbox_within_bounds(bbox, bounds, tol=0.05):
    """Vrai si une bounding box de face est (a peu pres) entierement
    comprise dans la zone ou male et femelle se chevauchent reellement.

    Sert a exclure les grandes faces de reference du corps male (faces
    exterieures d'un panneau, souvent alignees avec d'autres pieces sur le
    meme plan de reference dans un montage a plat) : seule la portion du
    male qui penetre reellement dans la femelle (le tenon lui-meme) doit se
    trouver entierement dans cette zone de chevauchement, qui est en general
    petite. Une grande face de panneau, meme coplanaire par coincidence
    avec une face de la femelle, deborde largement de cette zone et est
    donc ecartee ici, avant meme le test de coplanarite."""
    minx, miny, minz, maxx, maxy, maxz = bounds
    try:
        return (bbox.minPoint.x >= minx - tol and bbox.maxPoint.x <= maxx + tol and
                bbox.minPoint.y >= miny - tol and bbox.maxPoint.y <= maxy + tol and
                bbox.minPoint.z >= minz - tol and bbox.maxPoint.z <= maxz + tol)
    except Exception:
        return False


def _male_plane_infos(male, overlap_bounds):
    """Pre-calcule, pour chaque face PLANE du corps male qui chevauche
    reellement la zone de recouvrement male/femelle (donc qui fait partie
    du tenon effectivement insere, ou en tout cas passe par cette zone),
    son plan (normale + origine) et une bounding box RESTREINTE a cette
    zone de recouvrement (et non la bounding box complete de la face).

    Pourquoi restreindre plutot qu'exiger une inclusion totale (l'ancien
    comportement, via _bbox_within_bounds) : quand le tenon occupe TOUTE
    l'epaisseur du panneau dans un axe donne, sa face laterale dans cet axe
    n'est pas un fragment separe - c'est tout simplement la meme grande
    face que le reste du panneau (elle continue dans le tenon sans etre
    redecoupee). Exiger une inclusion totale dans la (petite) zone de
    recouvrement excluait alors a tort cette face, qui ne peut jamais y
    etre entierement contenue puisqu'elle s'etend sur toute la hauteur du
    panneau - c'est ce qui faisait manquer les grandes parois de la
    cavite dans ce cas precis. En restreignant sa bounding box de
    reference a la zone de recouvrement (au lieu de garder sa bounding box
    complete), on retrouve une reference de taille realiste pour le test
    de taille (_face_size_ok) tout en la reperant correctement."""
    infos = []
    try:
        bx0, by0, bz0, bx1, by1, bz1 = overlap_bounds
        tol = 0.05
        for mf in male.faces:
            try:
                fb = mf.boundingBox
                cx0, cx1 = max(fb.minPoint.x, bx0), min(fb.maxPoint.x, bx1)
                cy0, cy1 = max(fb.minPoint.y, by0), min(fb.maxPoint.y, by1)
                cz0, cz1 = max(fb.minPoint.z, bz0), min(fb.maxPoint.z, bz1)
                if cx0 > cx1 + tol or cy0 > cy1 + tol or cz0 > cz1 + tol:
                    continue  # pas de recouvrement reel avec la zone
                cx0, cx1 = min(cx0, cx1), max(cx0, cx1)
                cy0, cy1 = min(cy0, cy1), max(cy0, cy1)
                cz0, cz1 = min(cz0, cz1), max(cz0, cz1)
                clipped = adsk.core.BoundingBox3D.create(
                    adsk.core.Point3D.create(cx0, cy0, cz0),
                    adsk.core.Point3D.create(cx1, cy1, cz1))
            except Exception:
                continue
            try:
                plane = adsk.core.Plane.cast(mf.geometry)
            except Exception:
                plane = None
            if plane is None:
                continue
            infos.append((plane.normal, plane.origin, clipped))
    except Exception:
        pass
    return infos


def _native_token(obj):
    """Retourne l'entityToken de l'objet, normalise sur sa version NATIVE
    (nativeObject) quand il en a une.

    En assemblage, un objet obtenu par selection dans la boite de dialogue
    (BRepBody.cast(selection.entity)) est souvent un PROXY lie a un contexte
    d'occurrence, dont l'entityToken differe de celui du meme corps obtenu
    en parcourant directement component.bRepBodies / feature.faces (objets
    natifs, sans contexte). Comparer les deux tokens bruts peut donc echouer
    a tort meme s'il s'agit exactement du meme corps - c'est ce qui faisait
    ne jamais trouver les faces du tenon appartenant au corps male (0 face
    du bon corps sur 60 scannees), et donc jamais les parois laterales."""
    try:
        native = obj.nativeObject
        if native is not None:
            obj = native
    except Exception:
        pass
    try:
        return obj.entityToken
    except Exception:
        return None


def _tenon_feature_planes(male):
    """Pre-calcule le plan (normale + origine) et la bounding box de chaque
    face PLANE appartenant a une feature d'extrusion nommee 'Tenon' (creee
    par Tenons CNC, en mode Join sur ce corps) - c-a-d UNIQUEMENT les faces
    du tenon lui-meme (parois laterales + face de bout), jamais les grandes
    faces de reference du panneau (faces exterieures, souvent coplanaires
    par coincidence avec d'autres pieces d'un montage a plat).

    C'est beaucoup plus fiable que n'importe quelle heuristique geometrique
    (bounding box, zone de chevauchement...) car ca s'appuie directement sur
    la feature qui a reellement cree la geometrie du tenon : pour une
    extrusion en Join, la face de depart (sur le chant d'origine) est
    absorbee dans le corps existant (plus de face separee a cet endroit),
    et seules les faces reellement nouvelles (parois + bout) apparaissent
    dans feature.faces - exactement ce qu'il faut pour retrouver les
    parois de la cavite (4 parois + le fond, determine par la longueur du
    tenon reglee dans Tenons CNC) une fois la decoupe faite dans la
    femelle."""
    infos = []
    dbg_n_name_matched = 0
    dbg_n_faces_total = 0
    dbg_n_faces_body_match = 0
    dbg_comp_name = None
    try:
        comp = male.parentComponent
        dbg_comp_name = getattr(comp, 'name', None)
        for feat in comp.features:
            try:
                # Fusion renomme automatiquement les features en doublon
                # ('Tenon' -> 'Tenon (1)', 'Tenon (2)', ...) dès qu'il y en a
                # plusieurs dans le même composant (meme convention que pour
                # les sketches dans Tenons CNC) : il faut donc matcher le
                # prefixe, pas seulement le nom exact 'Tenon'.
                if feat.name != 'Tenon' and not feat.name.startswith('Tenon ('):
                    continue
            except Exception:
                continue
            dbg_n_name_matched += 1
            try:
                feat_faces = feat.faces
            except Exception:
                continue
            male_tok = _native_token(male)
            for f in feat_faces:
                dbg_n_faces_total += 1
                try:
                    if _native_token(f.body) != male_tok:
                        continue
                except Exception:
                    continue
                dbg_n_faces_body_match += 1
                try:
                    plane = adsk.core.Plane.cast(f.geometry)
                except Exception:
                    plane = None
                if plane is None:
                    continue
                infos.append((plane.normal, plane.origin, f.boundingBox))
    except Exception:
        _dbg(f'_tenon_feature_planes EXCEPTION: {traceback.format_exc()}')
    _dbg(f'_tenon_feature_planes({getattr(male, "name", "?")}): comp={dbg_comp_name} '
         f'features_nommees_Tenon={dbg_n_name_matched} faces_scannees={dbg_n_faces_total} '
         f'faces_du_bon_corps={dbg_n_faces_body_match} planes_retenus={len(infos)}')
    return infos


def _male_candidate_planes(male, overlap_bounds):
    """Faces candidates du corps male pour la detection des parois de
    cavite : combine les faces des features 'Tenon' (Tenons CNC, voir
    _tenon_feature_planes - fiable, base sur la topologie reelle) ET
    l'heuristique geometrique par bounding box (_male_plane_infos), au lieu
    de ne prendre cette derniere qu'en repli quand la premiere ne trouve
    RIEN.

    Pourquoi : pour un tenon fin ("languette") dont l'epaisseur (dans un
    axe donne) est egale a celle du panneau, sa/ses face(s) laterale(s)
    dans cet axe sont FLUSH avec la grande face de reference du panneau -
    lors du Join (Tenons CNC), Fusion etend alors cette grande face
    existante au lieu de creer une nouvelle face separee a cet endroit.
    Cette paroi n'apparait donc JAMAIS dans feature.faces de la feature
    'Tenon' (elle n'a pas ete "creee", juste etendue) : _tenon_feature_planes
    retourne alors un resultat NON VIDE (les autres faces du tenon sont bien
    detectees) mais INCOMPLET, ce qui empechait tout repli vers
    _male_plane_infos (qui, lui, capture correctement ce cas via son
    decoupage de la bounding box a la zone de recouvrement - voir sa
    docstring). C'est ce qui faisait manquer systematiquement les deux
    parois laterales d'une languette (sur toute la longueur d'insertion),
    que le tenon soit en bordure ou au centre du corps femelle - le
    probleme vient de la geometrie du male, pas de sa position."""
    infos_feat = _tenon_feature_planes(male)
    infos_bbox = _male_plane_infos(male, overlap_bounds)
    infos = list(infos_feat) + list(infos_bbox)
    _dbg(f'_male_candidate_planes: {len(infos_feat)} face(s) via feature(s) "Tenon" '
         f'+ {len(infos_bbox)} face(s) via heuristique bounding box '
         f'(fusionnes, {len(infos)} au total)')
    return infos


def _inplane_extents(bbox):
    """Retourne les deux plus grandes dimensions (en cm) de la bounding box
    d'une face plane, triees par ordre decroissant - c-a-d les deux etendues
    DANS le plan de la face (la troisieme, ~0, est la direction de la
    normale). Comparer ces deux valeurs plutot que dx/dy/dz directement
    evite tout probleme d'axes si male et femelle ne sont pas dans le meme
    repere local."""
    try:
        dx = bbox.maxPoint.x - bbox.minPoint.x
        dy = bbox.maxPoint.y - bbox.minPoint.y
        dz = bbox.maxPoint.z - bbox.minPoint.z
    except Exception:
        return (0.0, 0.0)
    dims = sorted((dx, dy, dz), reverse=True)
    return dims[0], dims[1]


def _face_size_ok(bbox_m, bbox_f, tol=0.05):
    """Vrai si la face de la femelle n'est pas plus grande (dans son plan)
    que la face du male qui a servi de reference - a tol pres (0.05cm =
    0.5mm de marge numerique).

    Une paroi de cavite creee par la decoupe ne peut physiquement pas etre
    plus etendue que l'outil (le corps male) qui l'a creee a cet endroit :
    si la face de la femelle est beaucoup plus grande que la face du male,
    c'est que le plan coincide par pur hasard avec une grande face de
    reference (panneau entier), pas avec une vraie paroi de mortaise - c'est
    exactement ce qui faisait selectionner les deux grandes faces du
    panneau au lieu des parois laterales du tenon (qui, elles, sont bien
    plus petites que n'importe quelle grande face de reference)."""
    fd0, fd1 = _inplane_extents(bbox_f)
    md0, md1 = _inplane_extents(bbox_m)
    return fd0 <= md0 + tol and fd1 <= md1 + tol


def _preexisting_female_planes(female):
    """Pre-calcule le plan (normale + origine) et la bounding box de chaque
    face PLANE de la femelle, AVANT la decoupe - sert a reperer les faces
    preexistantes (voir _is_preexisting_fragment)."""
    infos = []
    try:
        for pf in female.faces:
            try:
                plane = adsk.core.Plane.cast(pf.geometry)
            except Exception:
                plane = None
            if plane is None:
                continue
            infos.append((plane.normal, plane.origin, pf.boundingBox))
    except Exception:
        pass
    return infos


def _is_preexisting_fragment(face, pre_planes, tol_dot=0.001, tol_dist=0.0005, tol_bbox=0.05):
    """Vrai si cette face de la femelle (APRES la decoupe) est un morceau
    (ou la totalite) d'une face qui existait DEJA avant la decoupe - donc
    pas une nouvelle paroi de cavite, meme si elle correspond par ailleurs
    geometriquement a une face du male.

    Cas typique : un tenon flush avec le bord du panneau. Le bord du
    panneau (grande face preexistante) ne change pas geometriquement lors
    de la decoupe, mais la decoupe peut le DIVISER en plusieurs morceaux
    (avant/apres/entre les mortaises) - chaque morceau a alors une bounding
    box differente de l'originale, donc une simple comparaison de signature
    exacte (plan + bbox identiques) ne suffit pas a les reconnaitre. Ici on
    verifie a la place que la face est CONTENUE (bounding box comprise,
    tolerance pres) dans une face preexistante de meme plan - vrai pour
    n'importe quel morceau resultant d'une division, comme pour la face
    entiere si elle n'a pas ete divisee du tout."""
    try:
        plane = adsk.core.Plane.cast(face.geometry)
    except Exception:
        plane = None
    if plane is None:
        return False
    nf = plane.normal
    of = plane.origin
    bbox_f = face.boundingBox

    for nm, om, bbox_m in pre_planes:
        try:
            dot = nf.dotProduct(nm)
        except Exception:
            continue
        if abs(abs(dot) - 1.0) > tol_dot:
            continue
        try:
            vec = om.vectorTo(of)
            dist = abs(vec.dotProduct(nm))
        except Exception:
            continue
        if dist > tol_dist:
            continue
        try:
            if (bbox_f.minPoint.x >= bbox_m.minPoint.x - tol_bbox and bbox_f.maxPoint.x <= bbox_m.maxPoint.x + tol_bbox and
                    bbox_f.minPoint.y >= bbox_m.minPoint.y - tol_bbox and bbox_f.maxPoint.y <= bbox_m.maxPoint.y + tol_bbox and
                    bbox_f.minPoint.z >= bbox_m.minPoint.z - tol_bbox and bbox_f.maxPoint.z <= bbox_m.maxPoint.z + tol_bbox):
                return True
        except Exception:
            continue
    return False


def _is_cavity_wall(male_planes, female_face, tol_dot=0.001, tol_dist=0.0005, tol_bbox=0.01):
    """Vrai si la face de la femelle est geometriquement confondue avec une
    face (plane) du corps male : meme plan (normale parallele/anti-parallele
    + meme distance a l'origine), bounding box qui se chevauche reellement
    (donc pas juste "sur le meme plan infini" ailleurs sur la piece), ET
    taille compatible (voir _face_size_ok) - sans ce dernier filtre, une
    grande face de reference du panneau (coplanaire par coincidence, par ex.
    dans un montage a plat ou plusieurs pieces partagent la meme epaisseur)
    peut se faire matcher a tort avec une face du tenon, meme minuscule,
    simplement parce qu'elle partage son plan.

    C'est ce qui permet d'isoler UNIQUEMENT les parois de la cavite creee
    par la decoupe (faces laterales + fond du tenon), sans dependre d'une
    difference de tokens avant/apres : ce diff s'est revele peu fiable pour
    un CombineFeature, qui peut reattribuer de nouveaux tokens a des faces
    du corps qui n'ont pourtant pas change geometriquement - c'est ce qui
    faisait selectionner le corps entier au lieu des seules parois de la
    mortaise."""
    try:
        plane_f = adsk.core.Plane.cast(female_face.geometry)
    except Exception:
        plane_f = None
    if plane_f is None:
        return False
    nf = plane_f.normal
    of = plane_f.origin
    bbox_f = female_face.boundingBox

    for nm, om, bbox_m in male_planes:
        try:
            dot = nf.dotProduct(nm)
        except Exception:
            continue
        if abs(abs(dot) - 1.0) > tol_dot:
            continue
        try:
            vec = om.vectorTo(of)
            dist = abs(vec.dotProduct(nm))
        except Exception:
            continue
        if dist > tol_dist:
            continue
        if not _bbox_overlap_pt(bbox_m, bbox_f, tol=tol_bbox):
            continue
        if not _face_size_ok(bbox_m, bbox_f):
            continue
        return True
    return False


def creer_mortaises(males, femelles, root):
    """Pour chaque couple (male, femelle) dont les bounding box se
    chevauchent reellement, decoupe la femelle avec la geometrie EXACTE du
    corps male (qui possede deja ses tenons, crees par Tenons CNC) : pas de
    reconstruction ni de detection de tenon necessaire - la femelle est
    simplement evidee de tout ce qui deborde du male dans son volume, donc
    ca fonctionne quel que soit le nombre/la forme des tenons.

    Les parois de la cavite nouvellement creee sont identifiees par
    correspondance geometrique avec les faces du corps male (voir
    _is_cavity_wall) et enregistrees dans mortaise_face_map.json pour que
    Marge CNC puisse plus tard y appliquer un jeu de fonctionnement - Mortaise
    CNC ne touche plus lui-meme a aucun jeu, et ne modifie jamais le corps
    male : seuls les corps femelles sont decoupes.
    """
    cf = root.features.combineFeatures

    nb_ok      = 0
    nb_skipped = 0
    errors     = []
    # Enregistrements des nouvelles mortaises creees PENDANT CET APPEL
    # (male_token/female_token/face_tokens/cavities) - utilise par
    # TenonCNC (MargeAuto) pour savoir exactement sur quelles faces
    # appliquer le jeu juste apres, sans avoir a relire tout
    # mortaise_face_map.json ni risquer de re-appliquer un jeu deja
    # applique a une mortaise plus ancienne du meme corps femelle.
    new_records = []

    _dbg(f'males={[getattr(m, "name", "?") for m in males]} '
         f'femelles={[getattr(f, "name", "?") for f in femelles]}')

    cnc_progress.etape('Mortaises...', 0, len(males) * len(femelles))
    for mi, male in enumerate(males):
        for fi, female in enumerate(femelles):
            cnc_progress.avance()
            try:
                if male.entityToken == female.entityToken:
                    continue
            except Exception:
                pass

            if not _bbox_overlap(male, female):
                _dbg(f'pair male[{mi}]/femelle[{fi}]: bounding box disjointes, ignore')
                nb_skipped += 1
                continue

            overlap_bounds = _bbox_intersection_bounds(male.boundingBox, female.boundingBox)
            male_planes = _male_candidate_planes(male, overlap_bounds)

            # Faces de la femelle AVANT la decoupe : sert a exclure les
            # faces preexistantes (ex: bord du panneau flush avec un tenon)
            # qui ne changent pas lors du cut - meme si la decoupe les
            # divise en plusieurs morceaux, ils restent detectables (voir
            # _is_preexisting_fragment).
            pre_planes = _preexisting_female_planes(female)
            # Nombre de faces de la femelle AVANT la decoupe : sert juste
            # apres a verifier que le Cut a EU UN EFFET REEL (voir plus
            # bas) - un recouvrement de bounding box ne garantit pas que le
            # male penetre reellement dans le volume solide de la femelle a
            # cet endroit precis (ex. tenon trop court, ou mal oriente).
            try:
                pre_face_count = female.faces.count
            except Exception:
                pre_face_count = None

            feat = None
            try:
                tool_bodies = adsk.core.ObjectCollection.create()
                tool_bodies.add(male)
                ci = cf.createInput(female, tool_bodies)
                ci.operation = adsk.fusion.FeatureOperations.CutFeatureOperation
                ci.isKeepToolBodies = True
                feat = cf.add(ci)
            except Exception:
                err = traceback.format_exc().strip().splitlines()[-1]
                errors.append(f'male[{mi}]/femelle[{fi}]: {err}')
                _dbg(f'pair male[{mi}]/femelle[{fi}] EXCEPTION cut: {traceback.format_exc()}')
                nb_skipped += 1
                continue

            if feat is None:
                nb_skipped += 1
                continue

            # VERIFICATION D'EFFET REEL : cf.add() peut reussir (aucune
            # exception, feat non None) alors que le Cut n'a EN FAIT rien
            # retire - constate en direct (bounding box bien chevauchantes,
            # mais tenon ne penetrant pas reellement le volume de la
            # femelle a cet endroit) : le code comptait alors a tort une
            # "mortaise creee" (nb_ok) alors qu'aucune cavite n'existe, et
            # laissait une feature Combiner fantome (sans effet visible)
            # trainer dans la chronologie. Un Cut qui enleve reellement de
            # la matiere fait TOUJOURS apparaitre au moins une nouvelle
            # face (parois + fond de la cavite) : si le nombre de faces de
            # la femelle n'a pas augmente (ou si la feature est en etat
            # d'erreur), on annule la feature et on compte l'echec au lieu
            # de mentir sur le resultat.
            try:
                post_face_count = female.faces.count
            except Exception:
                post_face_count = None
            try:
                en_erreur = feat.healthState == adsk.fusion.FeatureHealthStates.ErrorFeatureHealthState
            except Exception:
                en_erreur = False
            sans_effet = (pre_face_count is not None and post_face_count is not None
                          and post_face_count <= pre_face_count)
            if en_erreur or sans_effet:
                raison = 'feature en erreur' if en_erreur else 'aucun recouvrement reel (decoupe sans effet)'
                _dbg(f'pair male[{mi}]/femelle[{fi}]: CUT SANS EFFET REEL ({raison}) - annule, '
                     f'pre_face_count={pre_face_count} post_face_count={post_face_count}')
                try:
                    feat.deleteMe()
                except Exception:
                    _dbg(f'pair male[{mi}]/femelle[{fi}]: suppression de la feature sans effet EXCEPTION: '
                         + traceback.format_exc())
                errors.append(f'male[{mi}]/femelle[{fi}]: {raison}')
                nb_skipped += 1
                continue

            nb_ok += 1
            _dbg(f'pair male[{mi}]/femelle[{fi}]: mortaise creee')

            # Tag la feature avec les tokens male/femelle (memes tokens que
            # ceux enregistres par _record_mortaise_faces) : sert a
            # "Mise a jour CNC" pour retrouver, supprimer puis recreer
            # exactement cette paire apres un changement de parametre qui a
            # deplace les corps (une decoupe entre corps differents ne suit
            # pas automatiquement un deplacement d'occurrence/assemblage).
            try:
                feat.attributes.add('MortaiseCNC', 'male_token', male.entityToken)
                feat.attributes.add('MortaiseCNC', 'female_token', female.entityToken)
            except Exception:
                pass

            new_faces = []
            try:
                for f in female.faces:
                    try:
                        plane_dbg = adsk.core.Plane.cast(f.geometry)
                    except Exception:
                        plane_dbg = None
                    if plane_dbg is not None and abs(plane_dbg.normal.x) > 0.9:
                        bb_dbg = f.boundingBox
                        is_frag = _is_preexisting_fragment(f, pre_planes)
                        is_wall = _is_cavity_wall(male_planes, f)
                        _dbg(f'  face X-normal bbox=({round(bb_dbg.minPoint.x,3)},{round(bb_dbg.minPoint.y,3)},{round(bb_dbg.minPoint.z,3)})'
                             f'-({round(bb_dbg.maxPoint.x,3)},{round(bb_dbg.maxPoint.y,3)},{round(bb_dbg.maxPoint.z,3)}) '
                             f'is_preexisting_fragment={is_frag} is_cavity_wall={is_wall}')
                        if not is_frag and is_wall:
                            new_faces.append(f)
                    else:
                        if not _is_preexisting_fragment(f, pre_planes) and _is_cavity_wall(male_planes, f):
                            new_faces.append(f)
            except Exception:
                _dbg(f'pair male[{mi}]/femelle[{fi}] detection parois EXCEPTION: {traceback.format_exc()}')

            if new_faces:
                # Regroupe les parois par CAVITE DISTINCTE avant
                # d'enregistrer (voir _group_by_shared_edges) : un seul
                # Cut peut creer PLUSIEURS mortaises independantes d'un
                # coup (ex. une rangee de N tenons sur le meme male/
                # femelle) - sans ce regroupement, Marge CNC ("exclure le
                # fond") ne pouvait reperer qu'UN SEUL fond pour tout
                # l'enregistrement au lieu d'un par cavite.
                cavity_groups = _group_by_shared_edges(
                    [(f.entityToken, f) for f in new_faces])
                cavities = [[new_faces[i].entityToken for i in grp] for grp in cavity_groups]
                face_tokens = [f.entityToken for f in new_faces]
                _record_mortaise_faces(male, female, face_tokens, cavities=cavities)
                new_records.append({
                    'male_token': male.entityToken,
                    'female_token': female.entityToken,
                    'face_tokens': face_tokens,
                    'cavities': cavities,
                })
                _dbg(f'pair male[{mi}]/femelle[{fi}]: {len(new_faces)} paroi(s) de cavite enregistree(s) '
                     f'en {len(cavities)} cavite(s) distincte(s)')
            else:
                _dbg(f'pair male[{mi}]/femelle[{fi}]: aucune paroi de cavite detectee '
                     f'(pas de face plane du male correspondante)')

    return nb_ok, nb_skipped, errors, new_records


def find_all_mortaise_features(design):
    """Retourne [(feature, male_token, female_token), ...] pour toutes les
    decoupes encore presentes dans le design, creees par Mortaise CNC
    (identifiees via les attributs poses dans creer_mortaises). Utilise par
    l'add-in 'Mise a jour CNC' pour tout supprimer puis tout recreer a la
    position actuelle des corps."""
    out = []
    try:
        attrs = design.findAttributes('MortaiseCNC', 'male_token')
    except Exception:
        attrs = []
    for a in attrs:
        try:
            feat = a.parent
            male_tok = a.value
            female_tok = None
            fem_attr = feat.attributes.itemByName('MortaiseCNC', 'female_token')
            if fem_attr:
                female_tok = fem_attr.value
            out.append((feat, male_tok, female_tok))
        except Exception:
            continue
    return out


class CreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        global _execute_handler, _validate_handler, _destroy_handler
        try:
            cmd = adsk.core.CommandCreatedEventArgs.cast(args).command
            cmd.isRepeatable = True
            _execute_handler  = ExecuteHandler()
            _validate_handler = ValidateHandler()
            _destroy_handler  = DestroyHandler()
            cmd.execute.add(_execute_handler)
            cmd.validateInputs.add(_validate_handler)
            cmd.destroy.add(_destroy_handler)

            inputs = cmd.commandInputs

            sel_m = inputs.addSelectionInput(
                'males', '1. Corps male(s) - avec tenons',
                'Selectionnez le(s) corps qui possedent deja des tenons (crees par Tenons CNC)'
            )
            sel_m.addSelectionFilter('Bodies')
            sel_m.setSelectionLimits(1, 0)

            sel_f = inputs.addSelectionInput(
                'femelles', '2. Corps femelle(s)',
                'Selectionnez le(s) corps qui recevront la mortaise'
            )
            sel_f.addSelectionFilter('Bodies')
            sel_f.setSelectionLimits(1, 0)

            inputs.addTextBoxCommandInput(
                'info', '',
                '<br><b>Mortaise CNC</b><br>'
                'Decoupe les corps femelles avec la geometrie exacte des '
                'tenons deja presents sur les corps males selectionnes.<br>'
                '<i>Le jeu de fonctionnement se regle desormais avec '
                "l'add-in Marge CNC, apres la decoupe.</i>",
                4, True)
        except Exception:
            _ui.messageBox('Erreur dialogue Mortaise CNC:\n' + traceback.format_exc())


class ValidateHandler(adsk.core.ValidateInputsEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            i = args.inputs
            args.areInputsValid = (
                i.itemById('males').selectionCount >= 1 and
                i.itemById('femelles').selectionCount >= 1)
        except Exception:
            args.areInputsValid = False


class ExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            inputs  = adsk.core.CommandEventArgs.cast(args).firingEvent.sender.commandInputs
            si_m    = inputs.itemById('males')
            si_f    = inputs.itemById('femelles')

            if si_m.selectionCount < 1 or si_f.selectionCount < 1:
                _ui.messageBox('Selectionnez au moins un corps male et un corps femelle.')
                return

            males    = [adsk.fusion.BRepBody.cast(si_m.selection(i).entity)
                        for i in range(si_m.selectionCount)]
            femelles = [adsk.fusion.BRepBody.cast(si_f.selection(i).entity)
                        for i in range(si_f.selectionCount)]

            design = adsk.fusion.Design.cast(_app.activeProduct)
            root   = design.rootComponent
            tl     = design.timeline
            start_index = tl.markerPosition

            # Esquisse-marqueur, vide et masquee, creee juste avant la
            # decoupe : sert UNIQUEMENT a garantir au moins 2 items dans la
            # timeline pour ce passage, afin de pouvoir former un vrai
            # groupe replie "Mortaise CNC" - meme quand un seul couple
            # male/femelle est traite. C'est le cas le plus frequent (un
            # seul corps male + un seul corps femelle selectionnes = une
            # seule feature Combiner creee, quel que soit le nombre de
            # tenons deja presents sur le male), et Fusion refuse de
            # "grouper" une feature seule (RuntimeError : "au moins deux
            # fonctions sont requises pour un groupe") : sans ce marqueur,
            # ce cas courant ne formait donc jamais de vrai dossier replie,
            # juste un renommage discret de la feature (peu visible, d'ou
            # le rapport "MortaiseCNC ne cree pas de groupe"). Retiree plus
            # bas si finalement rien n'a ete cree (nb_ok == 0).
            marker_sketch = None
            try:
                marker_sketch = root.sketches.add(root.xYConstructionPlane)
                marker_sketch.name = '_MortaiseCNC_marker'
                marker_sketch.isVisible = False
            except Exception:
                marker_sketch = None
                _dbg('creation esquisse-marqueur EXCEPTION: ' + traceback.format_exc())

            _dbg('=== Execute Mortaise CNC ===')
            with cnc_progress.Barre('Mortaise CNC', 'Creation des mortaises...'):
                nb_ok, nb_skipped, errors, _new_records = creer_mortaises(males, femelles, root)

            # Regroupe les features venant d'etre creees (marqueur inclus)
            # dans un groupe nomme "Mortaise CNC" (repli sur son propre
            # dossier dans la timeline, comme Tenons CNC/Gravure CNC) : ca
            # rend tout de suite visible, sans avoir a lire chaque nom de
            # feature, ce qui a ete cree par cet add-in plutot qu'a la
            # main. Fusion n'expose pas de couleur/icone personnalisable
            # par groupe - c'est le dossier replie + son nom qui joue ce
            # role.
            end_index = tl.markerPosition - 1
            if nb_ok == 0:
                # Rien cree : le marqueur ne servirait a rien, on le
                # retire pour ne pas polluer l'historique avec une
                # esquisse vide.
                if marker_sketch is not None:
                    try:
                        marker_sketch.deleteMe()
                    except Exception:
                        pass
            elif end_index > start_index:
                try:
                    grp = tl.timelineGroups.add(start_index, end_index)
                    if grp:
                        grp.name = 'Mortaise CNC'
                        grp.isCollapsed = True
                except Exception:
                    _dbg('groupement timeline Mortaise CNC EXCEPTION: ' + traceback.format_exc())
            elif end_index == start_index:
                # Filet de securite (ne devrait plus se produire grace au
                # marqueur ci-dessus, qui garantit deja >=2 items dans ce
                # cas) : a defaut de pouvoir grouper, on renomme.
                try:
                    tl.item(end_index).entity.name = 'Mortaise CNC'
                except Exception:
                    pass

            _app.activeViewport.fit()
            msg = f'{nb_ok} mortaise(s) creee(s).'
            if nb_skipped:
                msg += (f'\n{nb_skipped} couple(s) male/femelle ignore(s) '
                        f'(pas de recouvrement, ou echec de la decoupe).')
            _ui.messageBox(msg, 'Mortaise CNC')
            _dbg(f'=== Fin Execute : nb_ok={nb_ok} nb_skipped={nb_skipped} errors={errors} ===')
        except Exception:
            _ui.messageBox('Erreur execution Mortaise CNC:\n' + traceback.format_exc())
            _dbg('EXCEPTION Execute: ' + traceback.format_exc())


class DestroyHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args): pass


def run(context):
    global _app, _ui, _cmd_def, _panel_ctrl, _created_handler
    try:
        _app = adsk.core.Application.get()
        _ui  = _app.userInterface

        for pid in PANEL_IDS:
            panel = _ui.allToolbarPanels.itemById(pid)
            if panel is None:
                continue
            c = panel.controls.itemById(CMD_ID)
            if c: c.deleteMe()
        old = _ui.commandDefinitions.itemById(CMD_ID)
        if old: old.deleteMe()

        _cmd_def = _ui.commandDefinitions.addButtonDefinition(
            CMD_ID, COMMAND_NAME, COMMAND_DESC, '')
        _created_handler = CreatedHandler()
        _cmd_def.commandCreated.add(_created_handler)

        # Bouton de ruban RETIRE (voir PANEL_IDS ci-dessus) : devenu inutile
        # depuis la creation de CNC Toolkit, qui retrouve et execute cette
        # CommandDefinition directement depuis sa palette. La boucle de
        # nettoyage plus haut continue de retirer un ancien bouton residuel
        # d'une installation precedente si besoin.
    except Exception:
        if _ui:
            _ui.messageBox('Erreur run Mortaise CNC:\n' + traceback.format_exc())


def stop(context):
    global _cmd_def, _panel_ctrl, _created_handler
    global _execute_handler, _validate_handler, _destroy_handler
    try:
        for pid in PANEL_IDS:
            panel = _ui.allToolbarPanels.itemById(pid)
            if panel is None:
                continue
            ctrl = panel.controls.itemById(CMD_ID)
            if ctrl: ctrl.deleteMe()
        cd = _ui.commandDefinitions.itemById(CMD_ID)
        if cd: cd.deleteMe()
        _cmd_def = _panel_ctrl = None
        _created_handler = _execute_handler = _validate_handler = _destroy_handler = None
    except Exception:
        pass
