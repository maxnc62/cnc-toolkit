# -*- coding: utf-8 -*-
"""
cnc_apercu_fluide : aperçus fluides sur trajectoire, partages par les outils CNC Toolkit
(Reseau CNC, Traverse CNC, Jonction CNC...).

Pourquoi les aperçus saccadaient (mesures Traverse v0.9-v0.13, traverse_journal.txt) :
  * chaque mouvement de la fleche native (DistanceValueCommandInput.setManipulator) change une
    valeur de la commande, donc Fusion relance TOUT son cycle de commande : inputChanged, annulation
    de l'aperçu precedent (les groupes graphiques crees depuis le dernier cycle sont detruits),
    validateInputs, executePreview, redessin. Mesure : un mouvement toutes les ~39 ms alors que
    notre code n'en prend que 5 ms. Quand la souris va vite, l'aperçu suit avec du retard ;
  * les groupes detruits par l'annulation etaient recrees a chaque cycle (journal « groupe perdu »).

Comment fait l'outil natif « Reseau sur la trajectoire » :
  * la poignee est geree en C++ dans la boucle d'affichage, sans passer par le cycle de commande ;
  * les fantomes sont des INSTANCES du maillage du corps : la geometrie est envoyee une fois a la
    carte graphique, puis seule une matrice par copie change ; aucun calcul BRep pendant le glisser ;
  * le vrai calcul n'a lieu qu'au relachement.

Ce module reproduit ces trois points avec l'API :
  1. Fantomes : la geometrie (filaire des aretes, voile translucide optionnel) est construite UNE
     fois, un groupe par copie ; ensuite on ne change que group.transform (aucune recreation).
  2. Glisseur : la poignee est glissee par les evenements souris de la commande (mouseDown /
     mouseDrag / mouseUp), sans changer aucune valeur de la commande pendant le glisser : aucun cycle
     Fusion, aucune annulation. Chaque mouvement = calcul des matrices + viewport.refresh().
     Les mouvements de souris de Windows sont regroupes : on traite toujours la DERNIERE position,
     donc l'aperçu reste colle au curseur au lieu de prendre du retard.
  3. Le relachement ecrit la valeur finale dans la commande : un seul cycle Fusion.

Regles de design respectees : aperçus CustomGraphics uniquement, orange (255,90,0) trait 2 par
defaut (affine a la demande de Maxence le 2026-11-04), rouge (220,30,30) si invalide, tailles ecran x _dpr(), effacer() a appeler dans destroy.
"""

import adsk.core
import adsk.fusion
import math
import os
import time
import traceback

VERSION = '0.6'

ORANGE = (255, 90, 0, 255)
ORANGE_AUT = (255, 165, 45, 255)
ROUGE = (220, 30, 30, 255)

_app = adsk.core.Application.get()


# --- Utilitaires ----------------------------------------------------------------

_dpr_cache = {}


def dpr():
    """Echelle de l'ecran (GetDpiForSystem / 96), comme _dpr() des autres outils."""
    if 'k' not in _dpr_cache:
        k = 1.0
        try:
            import ctypes
            k = max(1.0, ctypes.windll.user32.GetDpiForSystem() / 96.0)
        except Exception:
            pass
        _dpr_cache['k'] = k
    return _dpr_cache['k']


def _sub(a, b): return (a[0] - b[0], a[1] - b[1], a[2] - b[2])
def _add(a, b): return (a[0] + b[0], a[1] + b[1], a[2] + b[2])
def _mul(a, k): return (a[0] * k, a[1] * k, a[2] * k)
def _dot(a, b): return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
def _cross(a, b): return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def _norm(a):
    n = math.sqrt(_dot(a, a))
    return (a[0] / n, a[1] / n, a[2] / n) if n > 1e-12 else (1.0, 0.0, 0.0)


def _d3(a, b):
    return math.sqrt((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 + (a[2] - b[2]) ** 2)


class Journal:
    """Journal texte facultatif (une ligne horodatee par appel)."""
    def __init__(self, chemin=None):
        self.chemin = chemin

    def __call__(self, msg):
        if not self.chemin:
            return
        try:
            with open(self.chemin, 'a', encoding='utf-8') as f:
                f.write(time.strftime('%H:%M:%S ') + msg + '\n')
        except Exception:
            pass


# --- Matrices -------------------------------------------------------------------

IDENTITE = (1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0)


def repere_tangent(p, t, haut=(0.0, 0.0, 1.0)):
    """Repere (origine, R colonnes x=tangente, y, z) le long d'un chemin, z au plus pres de 'haut'."""
    t = _norm(t)
    h = haut
    if abs(_dot(t, h)) > 0.999:
        h = (0.0, 1.0, 0.0) if abs(t[1]) < 0.9 else (1.0, 0.0, 0.0)
    z = _norm(_sub(h, _mul(t, _dot(h, t))))
    y = _cross(z, t)
    return p, (t, y, z)


def matrice_deplacement(rep_depart, rep_arrivee):
    """Tableau 16 flottants (lignes) de la matrice qui envoie le repere de depart sur celui d'arrivee :
    M = F_arrivee * F_depart^-1. A donner aux fantomes."""
    o0, (a0, b0, c0) = rep_depart
    o1, (a1, b1, c1) = rep_arrivee
    # R = R1 * R0^T, colonnes de R0/R1 = (a, b, c)
    R = [[a1[i] * a0[j] + b1[i] * b0[j] + c1[i] * c0[j] for j in range(3)] for i in range(3)]
    tr = [o1[i] - (R[i][0] * o0[0] + R[i][1] * o0[1] + R[i][2] * o0[2]) for i in range(3)]
    return (R[0][0], R[0][1], R[0][2], tr[0],
            R[1][0], R[1][1], R[1][2], tr[1],
            R[2][0], R[2][1], R[2][2], tr[2],
            0.0, 0.0, 0.0, 1.0)


def translation(v):
    return (1.0, 0.0, 0.0, v[0], 0.0, 1.0, 0.0, v[1], 0.0, 0.0, 1.0, v[2], 0.0, 0.0, 0.0, 1.0)


# --- Trajectoire ----------------------------------------------------------------

def _courbe_monde(ent):
    n = ent.nativeObject if getattr(ent, 'assemblyContext', None) is not None else ent
    if isinstance(n, adsk.fusion.BRepEdge):
        g = n.geometry.copy()
    elif isinstance(n, adsk.fusion.SketchCurve):
        g = n.worldGeometry.copy()
    else:
        return None
    ctx = getattr(ent, 'assemblyContext', None)
    if ctx is not None:
        g.transformBy(ctx.transform2)
    return g


def _echantillonner(ent, n=160):
    c = _courbe_monde(ent)
    if c is None:
        return []
    if isinstance(c, adsk.core.Line3D):
        a, b = c.startPoint, c.endPoint
        return [(a.x, a.y, a.z), (b.x, b.y, b.z)]
    ev = c.evaluator
    ok, p0, p1 = ev.getParameterExtents()
    pts = []
    for k in range(n + 1):
        ok, p = ev.getPointAtParameter(p0 + (p1 - p0) * k / n)
        if ok:
            pts.append((p.x, p.y, p.z))
    return pts


class Trajet:
    """Chemin (aretes / courbes d'esquisse enchainees) echantillonne par abscisse curviligne.
    at(f) -> (point, tangente) pour f dans 0..1 ; tout est en flottants Python (rapide)."""

    def __init__(self, ents=None, pts=None):
        if pts is None:
            segs = [s for s in (_echantillonner(e) for e in ents) if len(s) >= 2]
            if not segs:
                raise ValueError('chemin vide')
            chain = segs.pop(0)
            while segs:
                best = None
                for i, s in enumerate(segs):
                    for d, mode, rev in ((_d3(chain[-1], s[0]), 'a', False), (_d3(chain[-1], s[-1]), 'a', True),
                                         (_d3(s[-1], chain[0]), 'p', False), (_d3(s[0], chain[0]), 'p', True)):
                        if best is None or d < best[0]:
                            best = (d, i, mode, rev)
                _d, i, mode, rev = best
                s = segs.pop(i)
                seg = s[::-1] if rev else s
                chain = chain + seg[1:] if mode == 'a' else seg[:-1] + chain
            pts = chain
        self.pts = list(pts)
        self.cum = [0.0]
        for i in range(1, len(self.pts)):
            self.cum.append(self.cum[-1] + _d3(self.pts[i - 1], self.pts[i]))
        self.longueur = self.cum[-1]
        if self.longueur < 1e-9:
            raise ValueError('chemin nul')
        self._ecr = None

    def at(self, f):
        f = max(0.0, min(1.0, f))
        s = f * self.longueur
        lo, hi = 0, len(self.cum) - 1
        while hi - lo > 1:
            m = (lo + hi) // 2
            if self.cum[m] <= s:
                lo = m
            else:
                hi = m
        a, b = self.pts[lo], self.pts[lo + 1]
        L = self.cum[lo + 1] - self.cum[lo] or 1.0
        u = (s - self.cum[lo]) / L
        return (a[0] + (b[0] - a[0]) * u, a[1] + (b[1] - a[1]) * u, a[2] + (b[2] - a[2]) * u), \
            ((b[0] - a[0]) / L, (b[1] - a[1]) / L, (b[2] - a[2]) / L)

    def frac_point(self, q):
        """Fraction du point du chemin le plus proche du point 3D q."""
        pts = self.pts
        best = min(range(len(pts)), key=lambda i: _d3(pts[i], q))
        sb, db = self.cum[best], _d3(pts[best], q)
        for j in (best - 1, best):
            if 0 <= j < len(pts) - 1:
                a, b = pts[j], pts[j + 1]
                e = _sub(b, a)
                e2 = _dot(e, e)
                if e2 < 1e-18:
                    continue
                u = max(0.0, min(1.0, _dot(_sub(q, a), e) / e2))
                dd = _d3(_add(a, _mul(e, u)), q)
                if dd < db:
                    db, sb = dd, self.cum[j] + u * (self.cum[j + 1] - self.cum[j])
        return sb / self.longueur

    # -- projection ecran (gardee tant que la camera ne bouge pas) --
    def ecran(self, vp):
        try:
            cam = vp.camera
            cle = (tuple(round(v, 5) for v in cam.eye.asArray() + cam.target.asArray() + cam.upVector.asArray()),
                   round(cam.viewExtents, 5), vp.width, vp.height)
        except Exception:
            cle = None
        if self._ecr is None or cle is None or self._ecr[0] != cle:
            P3 = adsk.core.Point3D.create
            res = []
            for p in self.pts:
                q = vp.modelToViewSpace(P3(p[0], p[1], p[2]))
                res.append((q.x, q.y))
            self._ecr = (cle, res)
        return self._ecr[1]

    def frac_ecran(self, vp, x, y):
        """(fraction, distance en pixels) du point du chemin le plus proche de la souris, a l'ecran."""
        ecr = self.ecran(vp)
        best_d, best_s = None, 0.0
        for j in range(len(ecr) - 1):
            ax, ay = ecr[j]
            ex, ey = ecr[j + 1][0] - ax, ecr[j + 1][1] - ay
            e2 = ex * ex + ey * ey
            u = 0.0 if e2 < 1e-12 else max(0.0, min(1.0, ((x - ax) * ex + (y - ay) * ey) / e2))
            dd = (ax + u * ex - x) ** 2 + (ay + u * ey - y) ** 2
            if best_d is None or dd < best_d:
                best_d, best_s = dd, self.cum[j] + u * (self.cum[j + 1] - self.cum[j])
        return best_s / self.longueur, math.sqrt(best_d or 0.0)


# --- Geometrie des fantomes --------------------------------------------------------

def _transfo_corps(body):
    ctx = getattr(body, 'assemblyContext', None)
    nat = body.nativeObject if ctx is not None else body
    return nat, (ctx.transform2 if ctx is not None else None)


def filaire_corps(bodies, pas_courbe=16):
    """(coords, indices) des aretes des corps, en coordonnees du document (une fois pour toutes)."""
    coords, idx = [], []
    for body in bodies:
        try:
            nat, T = _transfo_corps(body)
            aretes = list(nat.edges)
        except Exception:
            continue
        for e in aretes:
            try:
                if isinstance(e.geometry, adsk.core.Line3D):
                    pts = [e.startVertex.geometry.copy(), e.endVertex.geometry.copy()]
                else:
                    ev = e.evaluator
                    ok, p0, p1 = ev.getParameterExtents()
                    pts = []
                    for i in range(pas_courbe + 1):
                        ok, pt = ev.getPointAtParameter(min(p1, max(p0, p0 + (p1 - p0) * i / pas_courbe)))
                        if ok:
                            pts.append(pt)
                base = len(coords) // 3
                for pt in pts:
                    if T is not None:
                        pt.transformBy(T)
                    coords += [pt.x, pt.y, pt.z]
                for j in range(len(pts) - 1):
                    idx += [base + j, base + j + 1]
            except Exception:
                continue
    return coords, idx


def voile_corps(bodies):
    """(coords, indices) du maillage d'affichage des corps (voile translucide facultatif)."""
    coords, idx = [], []
    for body in bodies:
        try:
            nat, T = _transfo_corps(body)
            m = nat.meshManager.displayMeshes.bestMesh
            c = list(m.nodeCoordinatesAsDouble)
            if T is not None:
                a = T.asArray()
                for k in range(0, len(c), 3):
                    x, y, z = c[k], c[k + 1], c[k + 2]
                    c[k] = a[0] * x + a[1] * y + a[2] * z + a[3]
                    c[k + 1] = a[4] * x + a[5] * y + a[6] * z + a[7]
                    c[k + 2] = a[8] * x + a[9] * y + a[10] * z + a[11]
            base = len(coords) // 3
            coords += c
            idx += [base + i for i in m.nodeIndices]
        except Exception:
            continue
    return coords, idx


def boite_filaire(x0, x1, y0, y1, z0, z1):
    """(coords, indices) d'une boite (coordonnees locales), pour les pieces construites (traverse...)."""
    c = []
    for x, y, z in ((x0, y0, z0), (x1, y0, z0), (x0, y1, z0), (x1, y1, z0),
                    (x0, y0, z1), (x1, y0, z1), (x0, y1, z1), (x1, y1, z1)):
        c += [x, y, z]
    idx = []
    for i, j in ((0, 1), (2, 3), (4, 5), (6, 7), (0, 2), (1, 3), (4, 6), (5, 7), (0, 4), (1, 5), (2, 6), (3, 7)):
        idx += [i, j]
    return c, idx


# --- Fantomes : geometrie fixe, seules les matrices bougent -------------------------

class Fantomes:
    """N copies d'une meme geometrie. definir() construit la geometrie (une fois), placer() ne fait
    que changer les matrices (ajoute / cache des copies si le nombre change).

    Ou creer les groupes : PAS dans executePreview (Fusion les detruit au cycle suivant). Les outils
    qui n'ont que des CustomGraphics comme aperçu ne doivent pas brancher executePreview du tout,
    ou n'y faire que verifier valide() (voir assurer())."""

    def __init__(self, ident, journal=None):
        self.ident = ident
        self.log = journal or Journal()
        self.geo = None           # (cle, coords, idx, voile)
        self.style = None
        self.gs = []
        self.nvis = 0
        self.mats = []            # derniere matrice ecrite (tuple) par groupe
        self._pool = []
        self.pertes = 0

    def _comp(self):
        d = adsk.fusion.Design.cast(_app.activeProduct)
        return d.rootComponent

    def definir(self, cle, coords, idx, couleur=ORANGE, poids=2.0, voile=None, alpha_voile=45):
        """cle : signature de la forme. Meme cle = rien a refaire. voile = (coords, idx) ou None."""
        style = (tuple(couleur), float(poids), alpha_voile if voile else None)
        if self.geo is not None and self.geo[0] == cle and self.style == style and self.valide():
            return False
        self._detruire()
        self.geo = (cle, list(coords), list(idx), voile)
        self.style = style
        return True

    def _nouveau(self):
        _cle, coords, idx, voile = self.geo
        col, poids, av = self.style
        g = self._comp().customGraphicsGroups.add()
        g.id = self.ident
        if voile and voile[0]:
            try:
                mesh = g.addMesh(adsk.fusion.CustomGraphicsCoordinates.create(voile[0]), voile[1], [], [])
                mesh.color = adsk.fusion.CustomGraphicsSolidColorEffect.create(
                    adsk.core.Color.create(col[0], col[1], col[2], av))
                mesh.isSelectable = False
            except Exception:
                self.log('voile impossible : ' + traceback.format_exc()[-200:])
        if coords:
            ln = g.addLines(adsk.fusion.CustomGraphicsCoordinates.create(coords), idx, False)
            ln.weight = poids
            ln.color = adsk.fusion.CustomGraphicsSolidColorEffect.create(adsk.core.Color.create(*col))
            ln.isSelectable = False
        return g

    def valide(self):
        try:
            return all(g.isValid for g in self.gs)
        except Exception:
            return False

    def placer(self, mats):
        """mats : liste de tableaux 16 flottants (lignes). Renvoie le nombre de matrices ecrites."""
        if self.geo is None:
            return 0
        if not self.valide():
            self.pertes += 1
            self.gs, self.mats, self.nvis = [], [], 0
        n = len(mats)
        while len(self.gs) < n:
            self.gs.append(self._nouveau())
            self.mats.append(None)
            self.nvis = len(self.gs)
        while len(self._pool) < n:
            self._pool.append(adsk.core.Matrix3D.create())
        ecrites = 0
        for k in range(n):
            a = tuple(mats[k])
            if a != self.mats[k]:
                m = self._pool[k]
                m.setWithArray(list(a))
                self.gs[k].transform = m
                self.mats[k] = a
                ecrites += 1
        for k in range(self.nvis, n):
            self.gs[k].isVisible = True
        for k in range(n, min(self.nvis, len(self.gs))):
            self.gs[k].isVisible = False
        self.nvis = n
        return ecrites

    def _detruire(self):
        for g in self.gs:
            try:
                if g.isValid:
                    g.deleteMe()
            except Exception:
                pass
        self.gs, self.mats, self.nvis = [], [], 0

    def effacer(self):
        """A appeler dans destroy / cancel (et avant execute)."""
        self._detruire()
        self.geo = None
        balayer(self.ident)


def balayer(ident):
    """Supprime tous les groupes portant cet id (racine et composant actif) : groupes orphelins."""
    try:
        design = adsk.fusion.Design.cast(_app.activeProduct)
        comps = {design.rootComponent.entityToken: design.rootComponent}
        ac = design.activeComponent
        comps[ac.entityToken] = ac
        for comp in comps.values():
            gs = comp.customGraphicsGroups
            for i in range(gs.count - 1, -1, -1):
                try:
                    g = gs.item(i)
                    if g.id == ident:
                        g.deleteMe()
                except Exception:
                    pass
    except Exception:
        pass


# --- Poignee dessinee (point orange) -------------------------------------------------

def _sur(dst, src):
    sa = src[3] / 255.0
    da = dst[3] / 255.0
    oa = sa + da * (1 - sa)
    if oa <= 0:
        return (0, 0, 0, 0)
    return tuple(int((src[i] * sa + dst[i] * da * (1 - sa)) / oa) for i in range(3)) + (int(oa * 255),)


COULEUR_POIGNEE = (128, 133, 140, 255)       # gris (choisi le 2026-11-04 a la place de l'orange)


def _style_poignee(style, d, x, y):
    """Couleur d'un point de la poignee (d : distance au centre / rayon, x, y : -1..1)."""
    o = (255, 90, 0, 255)
    if style == 'quantite':                  # comme 'anneau' (meme disque) mais bleu, avec « - + »
        c = (0, 0, 0, 0)
        if d <= 1.0:
            c = (45, 45, 48, 230)
        if d <= 0.86:
            c = (255, 255, 255, 255)
        if d <= 0.68:
            c = (40, 120, 215, 255)
        return c
    if style == 'anneau':                    # disque gris cercle de blanc, liseré sombre net, double fleche
        c = (0, 0, 0, 0)
        if d <= 1.0:
            c = (45, 45, 48, 230)                # liseré net (pas de halo flou)
        if d <= 0.86:
            c = (255, 255, 255, 255)
        if d <= 0.68:
            c = COULEUR_POIGNEE
        return c
    if style == 'losange':                   # losange facon manipulateur Fusion
        m = abs(x) + abs(y)
        c = (0, 0, 0, 0)
        if m <= 1.0:
            c = (0, 0, 0, 80)
        if m <= 0.86:
            c = (255, 255, 255, 255)
        if m <= 0.66:
            c = o
        return c
    c = (0, 0, 0, 0)                         # 'cible' (defaut) : anneau orange, centre blanc, point orange
    if 0.86 < d <= 1.0:
        c = (0, 0, 0, 70)
    if d <= 0.86:
        c = o
    if d <= 0.70:
        c = (255, 255, 255, 240)
    if d <= 0.30:
        c = o
    return c


def _fleche_px(x, y, taille):
    """Double fleche gauche / droite en pixels pleins (nette une fois agrandie par Fusion)."""
    c = taille / 2.0
    X, Y = x + 0.5, y + 0.5                      # centre du pixel
    x0 = round(taille * 0.24)                    # pointe gauche (26 px : 6)
    tete = 3 if taille < 26 else 4
    if abs(Y - c) <= 1.0 and x0 + 2 <= X <= taille - x0 - 2:     # tige : 2 px de haut
        return True
    for bout, sens in ((x0, 1), (taille - x0, -1)):
        dx = (X - bout) * sens
        if 0.0 <= dx <= tete and abs(Y - c) <= dx + 0.01:
            return True
    return False


def _plusmoins_px(x, y, taille):
    """« -  + » en pixels pleins : poignee de quantite (gauche = moins, droite = plus)."""
    c = taille / 2.0
    X, Y = x + 0.5, y + 0.5
    k = taille / 26.0
    if abs(Y - c) <= 1.0 and 6 * k <= X <= 11 * k:                 # moins
        return True
    xp = 17.5 * k
    if abs(Y - c) <= 1.0 and xp - 3.5 * k <= X <= xp + 3.5 * k:    # plus : barre
        return True
    if abs(X - xp) <= 1.0 and abs(Y - c) <= 3.5 * k:               # plus : jambage
        return True
    return False


def _png_poignee(taille, style='anneau'):
    """PNG lisse (sur-echantillonne 4x4) de la poignee, en cache dans le dossier temporaire."""
    import zlib, struct, tempfile
    chemin = os.path.join(tempfile.gettempdir(), 'cnc_poignee_%s_%s_%d.png' % (VERSION, style, taille))
    if os.path.exists(chemin):
        return chemin
    S = 4
    r = taille * S / 2.0
    raw = bytearray()
    for y in range(taille):
        raw.append(0)
        for x in range(taille):
            acc = [0.0, 0.0, 0.0, 0.0]
            for sy in range(S):
                for sx in range(S):
                    X = (x * S + sx + 0.5 - r) / r
                    Y = (y * S + sy + 0.5 - r) / r
                    c = _style_poignee(style, math.hypot(X, Y), X, Y)
                    a = c[3] / 255.0
                    acc[0] += c[0] * a
                    acc[1] += c[1] * a
                    acc[2] += c[2] * a
                    acc[3] += a
            a = acc[3]
            px = (0, 0, 0, 0) if a == 0 else (int(acc[0] / a), int(acc[1] / a), int(acc[2] / a), int(255 * a / (S * S)))
            if style == 'anneau' and _fleche_px(x, y, taille):
                px = (255, 255, 255, 255)        # fleche en pixels pleins (nette, pas d'anticrenelage)
            if style == 'quantite' and _plusmoins_px(x, y, taille):
                px = (255, 255, 255, 255)
            raw += bytes(px)

    def chunk(tt, dd):
        c = struct.pack('>I', len(dd)) + tt + dd
        return c + struct.pack('>I', zlib.crc32(tt + dd) & 0xffffffff)
    png = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', taille, taille, 8, 6, 0, 0, 0)) + \
        chunk(b'IDAT', zlib.compress(bytes(raw))) + chunk(b'IEND', b'')
    with open(chemin, 'wb') as f:
        f.write(png)
    return chemin


_boite = {'t': 0.0, 'c': None, 'r': 0.0}


def _boite_modele():
    """(centre, rayon) de la boite englobante du modele, gardee 2 s (lue a chaque mouvement sinon)."""
    t = time.perf_counter()
    if _boite['c'] is None or t - _boite['t'] > 2.0:
        try:
            bb = adsk.fusion.Design.cast(_app.activeProduct).rootComponent.boundingBox
            a, b = bb.minPoint, bb.maxPoint
            _boite['c'] = ((a.x + b.x) / 2, (a.y + b.y) / 2, (a.z + b.z) / 2)
            _boite['r'] = _d3((a.x, a.y, a.z), (b.x, b.y, b.z)) / 2
        except Exception:
            _boite['c'], _boite['r'] = (0.0, 0.0, 0.0), 0.0
        _boite['t'] = t
    return _boite['c'], _boite['r']


def devant(p, vp=None):
    """Point sur la meme ligne de visee que p mais DEVANT tout le modele (juste devant sa boite
    englobante, cote camera) : ce qui y est dessine n'est jamais cache par un corps.
    (La version 0.4 se rapprochait seulement de 90 % de l'oeil : en vue orthographique l'oeil de Fusion
    peut etre DANS le modele, et la poignee restait coupee par les corps.)"""
    try:
        cam = (vp or _app.activeViewport).camera
        eye, tgt = cam.eye, cam.target
        vd = _norm((tgt.x - eye.x, tgt.y - eye.y, tgt.z - eye.z))
        c, r = _boite_modele()
        marge = r * 1.05 + 0.1
        prof_p = (p[0] - eye.x) * vd[0] + (p[1] - eye.y) * vd[1] + (p[2] - eye.z) * vd[2]
        prof_c = (c[0] - eye.x) * vd[0] + (c[1] - eye.y) * vd[1] + (c[2] - eye.z) * vd[2]
        voulu = prof_c - marge                       # profondeur du plan juste devant le modele
        if cam.cameraType == adsk.core.CameraTypes.OrthographicCameraType:
            k = prof_p - voulu                       # en orthographique, reculer le long de la visee
            if k <= 0:
                return p
            return (p[0] - vd[0] * k, p[1] - vd[1] * k, p[2] - vd[2] * k)
        if prof_p <= 1e-9:
            return p
        f = voulu / prof_p if voulu > prof_p * 0.02 else 0.1     # oeil dans le modele : 10 % de la distance
        f = max(0.02, min(1.0, f))
        return (eye.x + (p[0] - eye.x) * f, eye.y + (p[1] - eye.y) * f, eye.z + (p[2] - eye.z) * f)
    except Exception:
        return p


class Poignee:
    """Poignee de glisser (style 'anneau' par defaut : disque orange, double fleche blanche, choisi par
    Maxence le 2026-11-04 ; ou 'cible' / 'losange') : image lisse posee
    devant la camera, donc jamais coupee par les corps. Deplacee par matrice uniquement.
    Appeler recaler() quand la camera bouge (evenement app.cameraChanged)."""
    TAILLE = 26          # pixels d'image : Fusion l'agrandit lui-meme selon l'echelle de l'ecran (comme _png_case)

    def __init__(self, ident, style='anneau'):
        self.ident = ident
        self.style = style
        self.g = None
        self.p = None
        self._cle = None
        self._m = adsk.core.Matrix3D.create()

    def placer(self, p, vp=None):
        if self.g is None or not self.g.isValid:
            d = adsk.fusion.Design.cast(_app.activeProduct)
            g = d.rootComponent.customGraphicsGroups.add()
            g.id = self.ident
            ps = g.addPointSet(adsk.fusion.CustomGraphicsCoordinates.create([0.0, 0.0, 0.0]), [0],
                               adsk.fusion.CustomGraphicsPointTypes.UserDefinedCustomGraphicsPointType,
                               _png_poignee(self.TAILLE, self.style))
            ps.isSelectable = False
            try:
                ps.depthPriority = 2
            except Exception:
                pass
            self.g = g
            self._cle = None
        self.p = p
        q = devant(p, vp)
        cle = tuple(round(v, 6) for v in q)
        if cle != self._cle:
            self._m.setWithArray(list(translation(q)))
            self.g.transform = self._m
            self._cle = cle

    def recaler(self, vp=None):
        if self.p is not None and self.g is not None:
            try:
                if self.g.isValid:
                    self.placer(self.p, vp)
            except Exception:
                pass

    def cacher(self, oui=True):
        try:
            if self.g is not None and self.g.isValid:
                self.g.isVisible = not oui
        except Exception:
            pass

    def effacer(self):
        try:
            if self.g is not None and self.g.isValid:
                self.g.deleteMe()
        except Exception:
            pass
        self.g, self.p, self._cle = None, None, None


# --- Rectangle de selection de Fusion pendant le glisser --------------------------------

def _entrees_selection(inputs):
    out = []
    for i in range(inputs.count):
        it = inputs.item(i)
        sel = adsk.core.SelectionCommandInput.cast(it)
        if sel is not None:
            out.append(sel)
            continue
        for cls in (adsk.core.GroupCommandInput, adsk.core.TabCommandInput):
            g = cls.cast(it)
            if g is not None:
                out += _entrees_selection(g.children)
                break
    return out


def selections_figer(inputs, mode='desactiver'):
    """Au debut du glisser d'une poignee : empeche le rectangle de selection de Fusion.
    mode 'desactiver' : champs de selection grises ; 'focus' : on leur retire le focus.
    Renvoie l'etat a passer a selections_rendre() au relachement."""
    etat = []
    try:
        for sel in _entrees_selection(inputs):
            etat.append((sel, sel.isEnabled, sel.hasFocus))
        if mode == 'plein':
            # Fusion ne lance pas son rectangle de selection quand le champ actif est PLEIN (nombre maximal
            # atteint) : c'est pourquoi Traverse (chemins limites a 1) n'avait pas le rectangle.
            etat = []
            for sel in _entrees_selection(inputs):
                ok, mn, mx = sel.getSelectionLimits()
                n = sel.selectionCount
                etat.append((sel, mn, mx))
                if n > 0 and (mx == 0 or mx > n):
                    sel.setSelectionLimits(min(mn, n), n)
            return ('plein', etat)
        for sel, _en, _fo in etat:
            if mode == 'desactiver':
                sel.isEnabled = False
            else:
                sel.hasFocus = False
    except Exception:
        pass
    return etat


def selections_rendre(etat):
    try:
        if isinstance(etat, tuple) and etat and etat[0] == 'plein':
            for sel, mn, mx in etat[1]:
                ok, a, b = sel.getSelectionLimits()
                if (a, b) != (mn, mx):
                    sel.setSelectionLimits(mn, mx)
            return
        for sel, en, _fo in etat:
            if sel.isEnabled != en:
                sel.isEnabled = en
        for sel, _en, fo in etat:
            if fo:
                sel.hasFocus = True
    except Exception:
        pass


# --- Glisseur : la poignee suit la souris hors du cycle Fusion ---------------------------

class Glisseur:
    """Glisser maison d'un point sur un Trajet.

    sur_mouvement(frac) : appele a chaque mouvement, doit mettre a jour les fantomes (Fantomes.placer)
                          et rien d'autre (pas de calcul BRep, pas de champ de la commande).
    sur_fin(frac)       : appele au relachement ; c'est la qu'on ecrit la valeur dans la commande
                          (un seul cycle Fusion).

    Branchement dans la commande (voir ApercuFluideTest.py) :
        mouseDown -> if glis.prendre(args): bloquer la selection
        mouseDrag -> glis.glisser(args)
        mouseUp   -> glis.lacher(args)
    """
    RAYON = 12          # pixels (x dpr) autour de la pastille pour l'attraper

    def __init__(self, trajet, frac, sur_mouvement, sur_fin=None, poignee=None, journal=None, nom='glisser',
                 cadence_max=120.0):
        self.trajet = trajet
        self.frac = frac
        self.sur_mouvement = sur_mouvement
        self.sur_fin = sur_fin
        self.poignee = poignee
        self.log = journal or Journal()
        self.nom = nom
        self.actif = False
        self.dt_min = 1.0 / cadence_max
        self._stats()

    def _stats(self):
        self.st = {'n': 0, 'faits': 0, 'calc': 0.0, 'refresh': 0.0, 'gap': 0.0, 'gap_max': 0.0, 't0': 0.0,
                   'dernier': 0.0, 'ecrites': 0}

    def touche(self, vp, x, y):
        """La souris est-elle sur la pastille ?"""
        p, _t = self.trajet.at(self.frac)
        q = vp.modelToViewSpace(adsk.core.Point3D.create(*p))
        return math.hypot(q.x - x, q.y - y) <= self.RAYON * dpr()

    def prendre(self, args, sur_chemin=False):
        """mouseDown : True si le glisser commence (la pastille, ou le chemin si sur_chemin=True)."""
        try:
            if args.button != adsk.core.MouseButtons.LeftMouseButton:
                return False
            vp, pos = args.viewport, args.viewportPosition
            ok = self.touche(vp, pos.x, pos.y)
            if not ok and sur_chemin:
                f, d = self.trajet.frac_ecran(vp, pos.x, pos.y)
                if d <= self.RAYON * dpr():
                    self.frac = f
                    ok = True
            if not ok:
                return False
            self.actif = True
            self._stats()
            self.st['t0'] = self.st['dernier'] = time.perf_counter()
            return True
        except Exception:
            self.log('%s prendre erreur %s' % (self.nom, traceback.format_exc()[-300:]))
            return False

    def glisser(self, args):
        if not self.actif:
            return
        t0 = time.perf_counter()
        st = self.st
        st['n'] += 1
        gap = t0 - st['dernier']
        st['dernier'] = t0
        st['gap'] += gap
        st['gap_max'] = max(st['gap_max'], gap)
        # cadence limitee par rapport a la DERNIERE IMAGE (et non au dernier evenement) : quand la souris
        # envoie un evenement toutes les 5 ms, l'ancienne regle sautait presque toutes les images.
        if st['faits'] and t0 - st.get('img', 0.0) < self.dt_min:
            return
        st['img'] = t0
        try:
            vp, pos = args.viewport, args.viewportPosition
            f, _d = self.trajet.frac_ecran(vp, pos.x, pos.y)
            self.frac = f
            st['ecrites'] += self.sur_mouvement(f) or 0
            if self.poignee is not None:
                self.poignee.placer(self.trajet.at(f)[0])
            t1 = time.perf_counter()
            vp.refresh()                      # pas de cycle Fusion : il faut demander le redessin
            t2 = time.perf_counter()
            st['calc'] += t1 - t0
            st['refresh'] += t2 - t1
            st['faits'] += 1
        except Exception:
            self.log('%s glisser erreur %s' % (self.nom, traceback.format_exc()[-300:]))

    def lacher(self, args=None):
        if not self.actif:
            return False
        self.actif = False
        st = self.st
        n, k = st['n'], max(1, st['faits'])
        duree = time.perf_counter() - st['t0']
        self.log('perf %s : %d mouvements en %.2f s (ecart moyen %.1f ms, max %.1f ms), %d images, '
                 'calcul %.2f ms, redessin %.2f ms, %d matrices ecrites' % (
                     self.nom, n, duree, 1000 * st['gap'] / max(1, n), 1000 * st['gap_max'], st['faits'],
                     1000 * st['calc'] / k, 1000 * st['refresh'] / k, st['ecrites']))
        try:
            if self.sur_fin is not None:
                self.sur_fin(self.frac)
        except Exception:
            self.log('%s fin erreur %s' % (self.nom, traceback.format_exc()[-300:]))
        return True


# --- Mesure du cycle Fusion (pour comparer avec la fleche native) ----------------------------

class Chrono:
    """Compte les evenements d'un glisser par la fleche native : ecart moyen entre deux mouvements."""
    def __init__(self, nom, journal=None):
        self.nom = nom
        self.log = journal or Journal()
        self.raz()

    def raz(self):
        self.n, self.gap, self.gap_max, self.calc, self.dernier, self.t0 = 0, 0.0, 0.0, 0.0, 0.0, 0.0

    def debut(self):
        t = time.perf_counter()
        if self.n == 0:
            self.t0 = t
        elif self.dernier:
            g = t - self.dernier
            self.gap += g
            self.gap_max = max(self.gap_max, g)
        self.n += 1
        return t

    def fin(self, t):
        mt = time.perf_counter()
        self.calc += mt - t
        self.dernier = mt

    def bilan(self, extra=''):
        if self.n:
            self.log('perf %s : %d mouvements en %.2f s (ecart moyen %.1f ms, max %.1f ms), calcul %.2f ms %s' % (
                self.nom, self.n, self.dernier - self.t0, 1000 * self.gap / max(1, self.n - 1), 1000 * self.gap_max,
                1000 * self.calc / self.n, extra))
        self.raz()
