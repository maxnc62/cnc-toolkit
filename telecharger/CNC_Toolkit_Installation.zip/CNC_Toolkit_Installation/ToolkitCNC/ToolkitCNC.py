import adsk.core, adsk.fusion, traceback, os, json, sys, threading

# Barre de chargement commune (cnc_progress.py, dans ce dossier)
if os.path.dirname(os.path.abspath(__file__)) not in sys.path:
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
import cnc_progress
import cnc_raccourcis
import cnc_i18n  # langue FR/EN (drapeaux de la palette, voir cnc_i18n.py)
import cnc_maj_toolkit  # bouton Mettre a jour (mise a jour de CNC Toolkit lui-meme)

# ---------------------------------------------------------------------------
# CNC Toolkit - lanceur unique pour tous les add-ins CNC de l'utilisateur.
#
# PRINCIPE (choisi explicitement par l'utilisateur) : cet add-in est un
# lanceur LEGER, qui ne touche a AUCUN des add-ins existants (GravureCNC,
# TenonCNC, MortaiseCNC, ...). Il ne fait qu'ouvrir une palette HTML (une
# vraie petite fenetre, avec une grille d'icones) et, quand on clique sur une
# icone, retrouve la CommandDefinition deja enregistree par l'add-in cible
# (via son CMD_ID, identique a celui defini dans le fichier .py de cet
# add-in) et l'execute - exactement comme si on avait clique sur le bouton
# de ruban de cet add-in. Aucune logique metier n'est dupliquee ici : ce
# fichier ne fait QUE retrouver et executer les commandes des autres add-ins.
#
# Consequence importante : pour qu'un outil soit trouvable par le lanceur,
# l'add-in qui le fournit doit avoir deja enregistre sa CommandDefinition -
# donc etre demarre. Les add-ins coches "Executer au demarrage" (Outils >
# Scripts et complements, Maj+S) le sont automatiquement a l'ouverture de
# Fusion. Trois de tes add-ins ne le sont PAS actuellement (GravureCNC,
# MiseAJourCNC, EntailleCNC) - voir ADDIN_HINTS plus bas : si l'un
# de leurs outils est clique alors que l'add-in n'est pas demarre, le
# lanceur l'indique clairement plutot que d'echouer silencieusement.
# ---------------------------------------------------------------------------

_app = None
_ui = None
_handlers = []
_palette = None

# Panneau Tenons CNC integre a la palette (voir plus bas, section dediee) :
# corps femelles/chants actuellement selectionnes pour la creation en
# cours - reinitialise a chaque ouverture/fermeture du panneau.
_tenon_faces = []
# True uniquement pendant que le panneau Tenons CNC est ouvert - evite que
# le handler de selection globale (_TenonActiveSelectionHandler, voir plus
# bas) ne reagisse a des selections faites ailleurs dans Fusion.
_tenon_panel_open = False
# Dernier payload de parametres recu de palette.html (action "tenon_params")
# - mis en cache pour pouvoir recalculer le preview quand c'est la SELECTION
# qui change (le handler de selection n'a pas acces aux champs HTML).
_tenon_last_data = {}
# Handler Fusion pour adsk.core.UserInterface.activeSelectionChanged -
# garde en global pour pouvoir le desinscrire proprement dans stop().
# NOTE : une commande dediee (SelectionCommandInput) a ete essayee pour
# permettre un clic simple (sans Ctrl) pour ajouter/retirer un chant, mais
# elle ouvre TOUJOURS une petite fenetre flottante dans la vue 3D (meme
# sans aucun input visible, Fusion affiche au minimum un bouton Annuler) -
# rejetee par l'utilisateur ("je ne voulais pas qu'il y ait de petites
# fenetres qui se rajoutent"). On revient donc a ce mecanisme, qui n'ouvre
# AUCUNE fenetre (la commande Select est celle active par defaut) mais
# impose Ctrl pour un multi-select - compromis inevitable avec l'API
# Fusion (voir la reponse donnee a l'utilisateur a ce sujet).
_tenon_sel_handler = None

# Priorite de selection des faces (voir _tenon_restrict_face_selection) :
# reproduit EXACTEMENT le reglage natif Fusion "Selectionner > Priorite de
# selection > Prioriser les faces" (confirme par l'utilisateur comme etant
# le comportement qu'il veut, teste et valide manuellement cote Fusion
# avant de me le demander - voir le detail dans _tenon_restrict_face_selection
# plus bas : ca desactive TOUTES les categories de selection Fusion SAUF
# FaceSelectionCategory, pas seulement Arete/Sommet comme dans une version
# precedente). Une tentative plus poussee de classification geometrique
# (distinguer un "chant" d'une "grande face" par calcul d'aire/plan) a ete
# essayee puis abandonnee a la demande explicite de l'utilisateur : trop
# instable (un chant entre deux tenons deja crees devenait difficile a
# bien classer dans certains cas) pour un gain qu'il n'estimait pas
# necessaire une fois ce reglage natif reproduit. Sauvegarde l'etat EXACT
# d'avant (dict {categorie: bool}) pour le restaurer a l'identique - None
# quand la restriction n'est pas active.
_tenon_filters_saved_state = None

# Panneau Entaille CNC integre a la palette (meme principe que le panneau
# Tenons CNC ci-dessus, mais la selection porte sur des CORPS entiers, pas
# des faces : un ou plusieurs corps CIBLES et un ou plusieurs corps
# OUTILS, voir _EntailleActiveSelectionHandler). _entaille_role vaut
# 'cible' ou 'outils' - determine a quel "slot" s'applique le PROCHAIN
# clic dans la vue 3D (bascule via le toggle Cible/Outils du panneau, cote
# palette.html).
#
# _entaille_targets est une LISTE (et non plus un corps unique) depuis le
# 2026-10-03, suite au retour utilisateur sur les assemblages
# "enfourchement" (ex. une traverse courbe qui croise de nombreux
# montants) : dans ce cas c'est chaque MONTANT qui doit agir comme sa
# PROPRE cible (il recoit la cavite complete) face a la traverse utilisee
# comme UNIQUE outil partage - l'ancienne UI ne permettait de choisir
# qu'une seule cible a la fois. L'accumulation par bascule (clic simple =
# ajoute/retire) est EXACTEMENT le meme mecanisme que celui deja utilise
# pour _entaille_tools ci-dessous (voir _EntailleActiveSelectionHandler) -
# avec une seule cible selectionnee, le comportement est strictement
# identique a avant (EntailleCNC.create_entaille_core_multi /
# compute_entaille_preview_multi se comportent comme les fonctions a
# cible unique quand on ne leur passe qu'un seul corps).
_entaille_panel_open = False
_entaille_role = 'cible'
_entaille_targets = []
_entaille_tools = []
_entaille_last_data = {}
# Mode "Selection unique" (2026-10-06, demande de l'utilisateur) : au lieu de
# separer cible/outils, tous les corps sont selectionnes d'un coup
# (_entaille_bodies) et EntailleCNC.analyse_auto_pairs detecte chaque paire
# en recouvrement et le sens de son entaille. _entaille_mode vaut
# 'classique' (cible/outils, inchange) ou 'unique'. _entaille_auto_cache
# garde l'analyse de la selection courante (cle = entityTokens) pour que
# Inverser/surligner une paire ne relance pas les calculs booleens ;
# _entaille_auto_flips = index des paires inversees depuis l'apercu.
_entaille_mode = 'classique'
_entaille_bodies = []
_entaille_auto_cache = None
_entaille_auto_flips = set()
_entaille_auto_focus = None
_entaille_sel_handler = None
_entaille_filters_saved_state = None
# Opacite d'origine des corps assombris pendant que le panneau est ouvert
# (entityToken -> opacite 0.0-1.0), voir _entaille_dim_body/
# _entaille_restore_opacity - permet de voir le fil de fer orange du
# preview (compute_entaille_preview) A TRAVERS la cible et les outils,
# qui sont sinon opaques et le cachent entierement (retour utilisateur :
# "je ne vois pas le preview se deplacer").
_entaille_opacity_saved = {}
ENTAILLE_PREVIEW_OPACITY = 0.35
# Garde de reentrance pour _entaille_dim_body/_entaille_restore_opacity - voir
# le commentaire detaille sur ces 2 fonctions plus bas. CONFIRME EN DIRECT par
# script (trace d'appels instrumentee) : affecter BRepBody.opacity redeclenche
# Fusion, EN PLEIN MILIEU de cette affectation, un evenement
# activeSelectionChanged "fantome" avec une selection transitoirement VIDE -
# sans ce garde-fou, ce second appel (imbrique) de notify() ecrasait
# _entaille_targets/_entaille_tools avec None/[] et videait
# _entaille_opacity_saved AVANT que l'assombrissement reel n'ait fini de
# s'appliquer. Consequence observee cote utilisateur : plus aucun preview et
# "Creer" qui echoue silencieusement (selection Python remise a None juste
# apres chaque clic), et opacite qui reste bloquee a -30% a la fermeture du
# panneau (plus aucune trace dans _entaille_opacity_saved pour la restaurer).
_entaille_opacity_busy = False

# --- Anti-gel du preview live (correctif du 2026-10-05, retour utilisateur :
# "quand je selectionne beaucoup de cibles et outils en meme temps, le temps
# de chargement est tres long et au bout d'un moment, ca fige et mon fusion
# crash") -----------------------------------------------------------------
# _entaille_update_preview() (voir plus bas) appelle
# EntailleCNC.compute_entaille_preview_multi, qui refait un calcul booleen
# complet (intersection + decoupe en 2 zones + fil de fer) pour CHAQUE PAIRE
# cible x outil - O(n_cibles * n_outils) operations du noyau geometrique, a
# CHAQUE clic. Avant ce correctif, _EntailleActiveSelectionHandler.notify
# appelait cette fonction directement et SYNCHRONE sur chaque clic : avec
# une selection multiple de nombreux corps (ex. 20 montants x 3 traverses),
# le cout cumule sur toute la session de selection grandit en O(N^2) (chaque
# nouveau clic refait le calcul complet pour TOUS les corps deja choisis en
# plus du nouveau), ce qui finit par geler l'interface puis faire planter
# Fusion - confirme par le retour utilisateur et coherent avec le cout
# geometrique reel de compute_entaille_preview_multi.
#
# Solution : DEBOUNCE - le calcul couteux n'est plus declenche directement
# par le clic, mais programme pour s'executer apres un court delai
# (_ENTAILLE_PREVIEW_DEBOUNCE_S), delai qui est REINITIALISE a chaque nouveau
# clic (voir _entaille_schedule_preview_update). Resultat : tant que
# l'utilisateur enchaine les clics rapidement (selection multiple en cours),
# AUCUN calcul n'est lance ; le calcul complet ne s'execute qu'UNE SEULE FOIS,
# apres que l'utilisateur se soit arrete de cliquer - au lieu d'une fois par
# clic. L'API Fusion n'autorisant les appels que depuis son thread principal,
# le minuteur (threading.Timer, thread secondaire) ne fait que declencher un
# evenement personnalise (fireCustomEvent) repris cote
# _EntaillePreviewDebounceHandler sur le thread principal - pattern standard
# pour "debouncer" un traitement declenche par un evenement Fusion.
_ENTAILLE_PREVIEW_DEBOUNCE_S = 0.35
_ENTAILLE_PREVIEW_EVENT_ID = 'ToolkitCNC_EntaillePreviewDebounce'
_entaille_preview_timer = None
_entaille_preview_custom_event = None
_entaille_preview_custom_handler = None

PALETTE_ID = "ToolkitCNC_Palette"
PALETTE_NAME = "CNC Toolkit"
PALETTE_HTML = "palette.html"  # chemin relatif au dossier de cet add-in

CMD_ID = "ToolkitCNC_LauncherCmd"
CMD_NAME = "CNC Toolkit"
CMD_DESC = "Ouvre le lanceur regroupant tous les outils CNC (Gravure, Tenon/Mortaise, Entaille, Selection...)"
PANEL_IDS = ["SolidScriptsAddinsPanel", "SolidCreatePanel", "SolidModifyPanel"]

_ADDIN_DIR = os.path.dirname(os.path.abspath(__file__))

# Outils regroupes par categorie - le CMD_ID de chaque outil DOIT etre
# identique a la constante CMD_ID (ou COMMAND_ID) definie dans le .py de
# l'add-in cible (voir en-tete de chaque add-in). Le champ "icon" reference
# une cle geree cote HTML (voir palette.html) - pas un fichier, tout est en
# SVG inline pour rester autonome (aucune ressource externe a maintenir).
TOOL_CATEGORIES = [
    {
        "title": "Modelisation",
        "tools": [
            {"cmd": "ExtrusionCNCCmd", "name": "Extrusion CNC", "icon": "extrude",
             "desc": "Extrusion identique a celle de Fusion, qui retient les derniers reglages"},
            {"cmd": "ReseauTrajectoireCNCCmd", "name": "Reseau trajectoire", "icon": "pathpattern",
             "desc": "Reseau sur la trajectoire, avec une face du corps posee contre un plan"},
        ],
    },
    {
        "title": "Gravure & etiquetage",
        "tools": [
            {"cmd": "GravureCNCCmd", "name": "Gravure CNC", "icon": "engrave",
             "desc": "Grave le nom des pieces (ou un texte personnalise) sur les faces selectionnees"},
        ],
    },
    {
        "title": "Assemblage (tenon / mortaise)",
        "tools": [
            {"cmd": "TenonCNCCmd", "name": "Tenons CNC", "icon": "tenon",
             "desc": "Cree des tenons sur des chants de contreplaque pour decoupe CNC"},
            {"cmd": "MortaiseCNCCmd", "name": "Mortaise CNC", "icon": "mortise",
             "desc": "Decoupe les mortaises correspondant aux tenons crees par Tenons CNC"},
            {"cmd": "MargeCNCCmd", "name": "Marge CNC", "icon": "gap",
             "desc": "Applique un jeu de fonctionnement sur les mortaises creees par Mortaise CNC"},
            {"cmd": "MiseAJourCNCCmd", "name": "Mettre a jour CNC", "icon": "refresh",
             "desc": "Recree en 1 clic les mortaises et le jeu de fonctionnement"},
            {"cmd": "ChantInterieur_Cmd", "name": "Chant Interieur", "icon": "ruler",
             "desc": "Selectionne les mortaises et applique un jeu de fonctionnement"},
        ],
    },
    {
        "title": "Decoupe",
        "tools": [
            {"cmd": "EntailleCNCCmd", "name": "Entaille CNC", "icon": "notch",
             "desc": "Cree une entaille a mi-bois entre un corps cible et un ou plusieurs corps de decoupe"},
            {"cmd": "JonctionCNCCmd", "name": "Jonction", "icon": "jonction",
             "desc": "Scinde un corps en plusieurs pieces raccordees par une forme de puzzle"},
            {"cmd": "DogboneCNCCmd", "name": "Dogbone CNC", "icon": "dogbone",
             "desc": "Ajoute des dogbones dans les coins interieurs des entailles, mortaises et tenons CNC"},
        ],
    },
    {
        "title": "Fabrication",
        "tools": [
            {"cmd": "CalpinageCNCCmd", "name": "Calpinage CNC", "icon": "nesting",
             "desc": "Place les pieces a plat sur des panneaux (nesting), groupees par epaisseur"},
        ],
    },
    {
        "title": "Selection & utilitaires",
        "tools": [
            {"cmd": "SelectFaceCNC_Cmd", "name": "Select Face CNC", "icon": "select",
             "desc": "Selectionne toutes les faces coplanaires a la face cliquee, sur tous les corps visibles"},
            {"cmd": "DebugComposantCmd", "name": "Debug composant", "icon": "bug",
             "desc": "Remplace les numeros de piece en double par le nom actuel de chaque composant"},
            {"cmd": "ModifMargeCmd", "name": "Modif Marge", "icon": "resize",
             "desc": "Modifie en 1 clic la taille de toutes les marges (jeu) creees depuis le debut du projet"},
            {"cmd": "PurgeCNCCmd", "name": "Purger CNC", "icon": "purge",
             "desc": "Supprime tout ce que CNC Toolkit a cree sur les corps selectionnes, et leurs coupes dans les autres corps"},
        ],
    },
]

# Les 3 add-ins ci-dessous ne sont PAS coches "Executer au demarrage" (voir
# leur .manifest, runOnStartup=false) : leur CommandDefinition n'existe donc
# que si l'utilisateur les a demarres manuellement depuis Scripts et complements
# pendant la session en cours. Sert uniquement au message d'aide affiche
# quand un clic ne trouve pas la commande - voir _launch_tool ci-dessous.
ADDIN_HINTS = {
    "GravureCNCCmd": "GravureCNC",
    "MiseAJourCNCCmd": "MiseAJourCNC",
    "EntailleCNCCmd": "EntailleCNC",
}


def _find_module(short_name):
    """Retrouve un module d'add-in deja charge par Fusion dans cette
    session (meme technique que TenonCNC.py/MiseAJourCNC.py) - utilise
    pour appeler TenonCNC.create_tenons_core etc. depuis le panneau
    Tenons CNC de la palette, sans import direct (l'add-in cible peut
    etre inactif)."""
    mod = sys.modules.get(short_name)
    if mod is not None:
        return mod
    suffix = short_name + '_py'
    for k, m in list(sys.modules.items()):
        if k.endswith(suffix):
            return m
    return None


def _all_tools():
    for cat in TOOL_CATEGORIES:
        for t in cat["tools"]:
            yield t


def _availability_payload():
    """Pour chaque outil, indique si sa CommandDefinition est actuellement
    trouvable (donc si son add-in est demarre) - envoye a la palette HTML
    pour griser les icones indisponibles plutot que de laisser l'utilisateur
    cliquer dans le vide (voir palette.html, handler 'status')."""
    avail = {}
    for t in _all_tools():
        try:
            avail[t["cmd"]] = _ui.commandDefinitions.itemById(t["cmd"]) is not None
        except Exception:
            avail[t["cmd"]] = False
    avail["PurgeCNCCmd"] = True  # charge au premier clic (_ensure_module)
    avail["ExtrusionCNCCmd"] = True  # charge au premier clic (_ensure_module)
    avail["ReseauTrajectoireCNCCmd"] = True  # charge au premier clic (_ensure_module)
    avail["CalpinageCNCCmd"] = True  # panneau de la palette, charge a l'ouverture
    return avail


def _launch_tool(cmd_id):
    try:
        if cmd_id == "PurgeCNCCmd":
            _ensure_module('PurgeCNC')
        target = _ui.commandDefinitions.itemById(cmd_id)
        if target is None and cmd_id == "ExtrusionCNCCmd":
            # ExtrusionCNC n'est pas dans Scripts et complements : demarrage
            # a la demande, comme JonctionCNC/DogboneCNC (voir _ensure_module).
            _ensure_module('ExtrusionCNC')
            target = _ui.commandDefinitions.itemById(cmd_id)
        if target is None and cmd_id == "ReseauTrajectoireCNCCmd":
            _ensure_module('ReseauTrajectoireCNC')
            target = _ui.commandDefinitions.itemById(cmd_id)
        if target is None:
            addin_name = ADDIN_HINTS.get(cmd_id, "l'add-in correspondant")
            _ui.messageBox(
                f"Cet outil n'est pas actif pour le moment.\n\n"
                f"Demarre d'abord \"{addin_name}\" : Outils > Modules complementaires "
                f"> Scripts et compléments (Maj+S), selectionne-le et clique sur "
                f"\"Executer\" (ou coche \"Executer au demarrage\" pour qu'il soit "
                f"toujours pret).",
                CMD_NAME)
            return
        target.execute()
    except Exception:
        _ui.messageBox("Erreur au lancement de l'outil:\n" + traceback.format_exc(), CMD_NAME)


# ---------------------------------------------------------------------------
# Raccourcis clavier (2026-10-12) : un raccourci par outil, attribue depuis
# le panneau "Raccourcis" de la palette. Enregistrement Windows, stockage
# JSON et detection des conflits dans cnc_raccourcis.py. Les outils qui
# ont un panneau dans la palette (Tenons, Entaille, ...) ouvrent la palette
# sur ce panneau ; les autres lancent directement leur commande.
# ---------------------------------------------------------------------------
_PANNEAU_CMDS = {"TenonCNCCmd", "EntailleCNCCmd", "DogboneCNCCmd", "JonctionCNCCmd", "CalpinageCNCCmd"}
_raccourci_en_attente = None  # outil a ouvrir des que la palette aura charge


def _raccourcis_noms():
    noms = {CMD_ID: "Ouvrir / fermer CNC Toolkit"}
    for t in _all_tools():
        noms[t["cmd"]] = t["name"]
    return noms


def _raccourcis_envoyer(message=None, erreur=None):
    if _palette is None:
        return
    d = cnc_raccourcis.etat()
    noms = _raccourcis_noms()
    d["outils"] = [{"cmd": CMD_ID, "name": noms[CMD_ID], "cat": "CNC Toolkit"}] + [
        {"cmd": t["cmd"], "name": t["name"], "cat": cat["title"]}
        for cat in TOOL_CATEGORIES for t in cat["tools"]]
    d["message"] = message
    d["erreur"] = erreur
    _palette.sendInfoToHTML("shortcuts_state", json.dumps(d))


def _raccourcis_dispatch(action, data):
    if action == "shortcuts_open":
        _raccourcis_envoyer()
    elif action == "shortcuts_capture":
        cnc_raccourcis.pause(bool(data.get("on")))
    elif action == "shortcuts_set":
        cnc_raccourcis.pause(False)
        cmd = data.get("cmd", "")
        combo = data.get("combo") or None
        err = cnc_raccourcis.attribuer(cmd, combo, _raccourcis_noms())
        _raccourcis_envoyer(erreur=err, message=None if err else (
            "Raccourci %s enregistre." % cnc_raccourcis.normaliser(combo) if combo else "Raccourci retire."))
    elif action == "shortcuts_close":
        cnc_raccourcis.pause(False)


def _maj_dispatch(action, data):
    """Bouton Mettre a jour de la palette (voir cnc_maj_toolkit.py).
    maj_verifier : lance la verification (une fois par session, sauf
    forcer) ; maj_installer : installe apres confirmation dans la
    palette ; maj_etat : renvoie l'etat (la palette interroge pendant le
    travail en arriere-plan)."""
    if action == "maj_verifier":
        cnc_maj_toolkit.verifier(forcer=bool(data.get("forcer")))
    elif action == "maj_installer":
        cnc_maj_toolkit.installer()
    d = cnc_maj_toolkit.etat()
    en = cnc_i18n.langue() == 'en' and d.get('notes_en')
    d['notes'] = d.get('notes_en') if en else d.get('notes_fr', '')
    _palette.sendInfoToHTML("maj_etat", json.dumps(d))


def _raccourci_declenche(cmd):
    """Appele sur le thread principal quand un raccourci est presse."""
    global _raccourci_en_attente
    if cmd == cnc_raccourcis.ETAT:
        pal = _ui.palettes.itemById(PALETTE_ID)
        if pal is not None and pal.isVisible:
            _raccourcis_envoyer()
        return
    _barre = sys.modules.get('cnc_progress')
    if _barre is not None and _barre.occupe():
        return
    if cmd == CMD_ID:
        _show_palette()
        return
    if cmd not in _PANNEAU_CMDS:
        _launch_tool(cmd)
        return
    if _ui.palettes.itemById(PALETTE_ID) is None:
        _raccourci_en_attente = cmd
        _show_palette()
        return
    if not _palette.isVisible:
        _palette.isVisible = True
    _palette.sendInfoToHTML("shortcut_launch", json.dumps({"cmd": cmd}))


# ---------------------------------------------------------------------------
# Panneau Tenons CNC integre a la palette (demande explicite de l'utilisateur,
# inspire de l'add-in tiers "Tab & Slot" : parametres + preview live +
# creation directement dans la palette, plutot que d'ouvrir la boite de
# dialogue Fusion native de Tenons CNC). Seule EXCEPTION a la regle "lanceur
# leger" du commentaire d'entete de ce fichier : ce panneau appelle des
# fonctions PURES exposees par TenonCNC.py (compute_tenon_layout_1d,
# _face_len_for_preview, create_tenons_core, _draw_tenon_preview_graphics) -
# aucune logique metier n'est reecrite ici, seulement orchestree. La boite
# de dialogue native de Tenons CNC reste intacte et accessible telle quelle
# (ex. recherche de commande Fusion), ce panneau ne fait qu'offrir un autre
# chemin, plus rapide, pour le meme resultat.
# ---------------------------------------------------------------------------

def _tenon_params_from_data(data):
    """Convertit le payload JSON envoye par palette.html (valeurs en mm,
    cote utilisateur) en parametres prets pour TenonCNC (cm, unite interne
    Fusion)."""
    return {
        'mode': data.get('mode', 'tenon'),
        'tenon_count': int(data.get('tenon_count', 2) or 2),
        'tenon_len': float(data.get('tenon_len_mm', 20) or 0) / 10.0,
        'tenon_h': float(data.get('tenon_h_mm', 12) or 0) / 10.0,
        'edge_dist': float(data.get('edge_dist_mm', 10) or 0) / 10.0,
        'languette_bord': float(data.get('languette_bord_mm', 5) or 0) / 10.0,
        'languette_h': float(data.get('languette_h_mm', 12) or 0) / 10.0,
        'centrer': bool(data.get('centrer', False)),
        'repartition_mode': data.get('repartition_mode', 'uniforme'),
        'repartition_cotes_pct': float(data.get('repartition_cotes_pct', 33.3) or 33.3),
        'mortaise_auto': bool(data.get('mortaise_auto', False)),
        'marge_auto': bool(data.get('marge_auto', False)),
    }


def _tenon_restrict_face_selection():
    """Priorise la selection des faces pendant que le panneau Tenons CNC
    est ouvert (demande utilisateur : les clics pres d'un bord selectionnaient
    parfois une arete, ou une autre entite, a la place du chant vise).

    Reproduit EXACTEMENT le reglage natif Fusion "Selectionner > Priorite de
    selection > Prioriser les faces" - verifie en direct (lecture de
    Workspace.selectionFilterSettings apres avoir bascule ce reglage a la
    main dans Fusion) : ce reglage natif desactive TOUTES les categories de
    selection SAUF FaceSelectionCategory, pas seulement Arete/Sommet. On
    fait donc pareil ici via l'API (encore en preview cote Autodesk, mais
    stable) Workspace.selectionFilterSettings - cela revient a le faire a la
    main dans le menu deroulant "Select"/"Selectionner" du bandeau Fusion,
    sans ouvrir aucune commande/fenetre.

    Une classification geometrique plus fine (distinguer un chant d'une
    grande face par calcul) a ete essayee puis abandonnee a la demande de
    l'utilisateur, ce reglage natif suffisant deja tel quel - voir la note
    globale sur _tenon_filters_saved_state en tete de fichier.

    Sauvegarde l'etat EXACT (active/desactive) de chaque categorie touchee
    AVANT de la desactiver, pour pouvoir le restaurer a l'identique dans
    _tenon_restore_selection_filters - y compris si l'utilisateur avait deja
    lui-meme change ces reglages avant d'ouvrir Tenons CNC."""
    global _tenon_filters_saved_state
    try:
        sfs = _ui.activeWorkspace.selectionFilterSettings
        saved = {}
        for cat in sfs.availableFilters:
            try:
                saved[cat] = sfs.isFilterEnabled(cat)
                sfs.setFilterEnabled(cat, cat == 'FaceSelectionCategory')
            except Exception:
                pass
        _tenon_filters_saved_state = saved
    except Exception:
        _tenon_filters_saved_state = None


def _tenon_restore_selection_filters():
    """Reactive les categories de selection desactivees par
    _tenon_restrict_face_selection, en remettant l'etat EXACT d'avant
    (jamais juste 'tout reactiver') - appelee depuis _tenon_close, donc a
    chaque fois qu'on quitte le panneau Tenons CNC (bouton retour ou
    fermeture native de CNC Toolkit), jamais apres un simple clic sur
    'Creer' (on reste sur l'ecran Tenons CNC, la priorite doit persister)."""
    global _tenon_filters_saved_state
    if not _tenon_filters_saved_state:
        return
    try:
        sfs = _ui.activeWorkspace.selectionFilterSettings
        for cat, was_enabled in _tenon_filters_saved_state.items():
            try:
                sfs.setFilterEnabled(cat, was_enabled)
            except Exception:
                pass
    except Exception:
        pass
    _tenon_filters_saved_state = None


def _tenon_open():
    """Ouverture du panneau (clic sur la carte 'Tenons CNC' dans la
    grille) : reinitialise la selection en cours et envoie les valeurs
    sauvegardees (memes prefs.json que la boite de dialogue native, donc
    les deux restent coherentes) pour pre-remplir le formulaire HTML.
    La selection des chants est ensuite 100% geree par Fusion lui-meme
    (clic/ctrl-clic/deselection natifs dans la vue 3D, voir
    _TenonActiveSelectionHandler) - il n'y a plus de bouton "Selectionner"
    ni de boucle bloquante a declencher ici, et surtout AUCUNE fenetre de
    commande qui s'ouvre (voir la note sur _tenon_sel_handler plus haut)."""
    global _tenon_faces, _tenon_panel_open, _tenon_last_data
    _tenon_faces = []
    _tenon_panel_open = True
    try:
        _ui.activeSelections.clear()
    except Exception:
        pass
    _tenon_restrict_face_selection()
    defaults = {
        'edge_dist_mm': 10, 'tenon_count': 2, 'tenon_len_mm': 20, 'tenon_h_mm': 12,
        'languette_bord_mm': 5, 'languette_h_mm': 12, 'centrer': False,
        'repartition_mode': 'uniforme', 'repartition_cotes_pct': 33.3,
        'mortaise_auto': False, 'marge_auto': False,
    }
    defaults['dogbone_auto'] = _dogbone_auto_pref('tenon')
    TenonCNC = _find_module('TenonCNC')
    if TenonCNC is None:
        _tenon_last_data = defaults
        _palette.sendInfoToHTML('tenon_init', json.dumps(defaults))
        _ui.messageBox(
            'L\'add-in "Tenons CNC" n\'est pas actif : le panneau peut s\'afficher, '
            'mais la creation echouera tant qu\'il n\'est pas demarre.\n\n'
            'Demarre "Tenons CNC" (Outils > Scripts et complements, Maj+S).',
            CMD_NAME)
        return
    try:
        prefs = TenonCNC._load_prefs()
    except Exception:
        prefs = {}
    for k in defaults:
        defaults[k] = prefs.get(k, defaults[k])
    _tenon_last_data = defaults
    _palette.sendInfoToHTML('tenon_init', json.dumps(defaults))


class _TenonActiveSelectionHandler(adsk.core.ActiveSelectionEventHandler):
    """Ecoute adsk.core.UserInterface.activeSelectionChanged, l'evenement
    qui se declenche a CHAQUE changement de selection pendant que la
    commande Select (celle active par defaut quand aucune autre commande
    ne tourne) est utilisee - c'est a dire a chaque clic/ctrl-clic/
    deselection/clic dans le vide de l'utilisateur dans la vue 3D, sans
    rien bloquer (contrairement a ui.selectEntity). C'est ce qui permet de
    selectionner ET deselectionner librement des chants, avec le preview
    qui suit en direct, exactement comme le faisait la boite de dialogue
    native avec son SelectionCommandInput - mais sans ouvrir de commande,
    et sans bouton "Selectionner les chants" a cliquer au prealable.

    Limite acceptee (voir la note globale sur _tenon_sel_handler) : un clic
    simple REMPLACE la selection (convention standard de la commande Select
    de Fusion) - il faut Ctrl-clic pour ajouter/retirer un chant d'une
    selection multiple. C'est la seule facon d'avoir un multi-select SANS
    qu'aucune fenetre de commande ne s'ouvre dans la vue 3D.

    NOTE (historique) : une classification geometrique a ete essayee ici
    pour rejeter automatiquement toute face selectionnee qui ne serait pas
    un "chant" (par opposition a une grande face) - abandonnee a la
    demande de l'utilisateur, qui a prefere reproduire simplement le
    reglage natif Fusion "Prioriser les faces" (voir
    _tenon_restrict_face_selection) : suffisant en pratique, et plus
    fiable que la classification geometrique (qui coincait par exemple sur
    un chant deja coupe par des tenons). On garde donc ici la version
    simple : toute face plane selectionnee (quelle qu'elle soit) est
    acceptee telle quelle."""
    def __init__(self):
        super().__init__()

    def notify(self, args):
        global _tenon_faces
        if not _tenon_panel_open:
            return
        try:
            faces = []
            for item in args.currentSelection:
                ent = getattr(item, 'entity', item)
                f = adsk.fusion.BRepFace.cast(ent)
                if f and f.geometry.surfaceType == adsk.core.SurfaceTypes.PlaneSurfaceType:
                    faces.append(f)
            _tenon_faces = faces
            if _palette:
                _palette.sendInfoToHTML('tenon_selection', json.dumps({'count': len(faces)}))
            _tenon_update_preview(_tenon_last_data)
        except Exception:
            pass


def _tenon_update_preview(data):
    """Recalcule le preview (SVG cote HTML + fil de fer 3D dans le
    viewport, comme la boite de dialogue native) a partir des parametres
    courants envoyes par palette.html - toujours via les fonctions pures
    de TenonCNC.py, jamais de calcul de positionnement duplique ici."""
    TenonCNC = _find_module('TenonCNC')
    if TenonCNC is None or not _tenon_faces:
        try:
            if _palette:
                _palette.sendInfoToHTML('tenon_preview', json.dumps({'ok': False, 'reason': None}))
        except Exception:
            pass
        if TenonCNC is not None:
            try:
                TenonCNC._clear_preview_graphics()
            except Exception:
                pass
        return
    try:
        params = _tenon_params_from_data(data)
        face = _tenon_faces[0]
        face_len = TenonCNC._face_len_for_preview(face)
        if face_len is None:
            _palette.sendInfoToHTML('tenon_preview', json.dumps({'ok': False, 'reason': 'face_invalide'}))
            return
        layout = TenonCNC.compute_tenon_layout_1d(
            face_len, params['mode'], params['tenon_count'],
            params['tenon_len'], params['tenon_h'],
            params['languette_bord'], params['languette_h'], params['edge_dist'],
            params['centrer'], params['repartition_mode'], params['repartition_cotes_pct'])
        layout['face_len'] = face_len
        _palette.sendInfoToHTML('tenon_preview', json.dumps(layout))

        design = adsk.fusion.Design.cast(_app.activeProduct)
        if design:
            is_lang = params['mode'] == 'languette'
            TenonCNC._draw_tenon_preview_graphics(
                _tenon_faces, params['edge_dist'], params['tenon_count'],
                params['tenon_len'], params['tenon_h'], params['centrer'],
                params['repartition_mode'], params['repartition_cotes_pct'],
                is_lang, params['languette_bord'], params['languette_h'], design)
    except Exception:
        # Un preview rate ne doit jamais interrompre la saisie de
        # parametres - meme philosophie que _draw_tenon_preview_graphics
        # cote TenonCNC.py.
        pass


def _tenon_dogbone_bodies(design, faces, tol=0.05):
    """Dogbone auto pour Tenons CNC : corps des chants (tenons) + corps qui
    les touchent (mortaises/jeux possibles), par boite englobante."""
    males = []
    for f in faces:
        try:
            males.append(f.body)
        except Exception:
            pass
    boxes = []
    for b in males:
        try:
            boxes.append(b.boundingBox)
        except Exception:
            pass
    root = design.rootComponent
    candidates = list(root.bRepBodies)
    for occ in root.allOccurrences:
        try:
            candidates.extend(list(occ.bRepBodies))
        except Exception:
            pass
    out = list(males)
    for b in candidates:
        try:
            bb = b.boundingBox
            for m in boxes:
                if (bb.minPoint.x <= m.maxPoint.x + tol and bb.maxPoint.x >= m.minPoint.x - tol and
                        bb.minPoint.y <= m.maxPoint.y + tol and bb.maxPoint.y >= m.minPoint.y - tol and
                        bb.minPoint.z <= m.maxPoint.z + tol and bb.maxPoint.z >= m.minPoint.z - tol):
                    out.append(b)
                    break
        except Exception:
            pass
    return out


def _tenon_create(data):
    """Creation reelle (bouton 'Creer' du panneau) : delegue entierement
    a TenonCNC.create_tenons_core, exactement comme le ferait la boite de
    dialogue native.

    La creation (et MortaiseAuto/MargeAuto) active au passage l'occurrence
    de CHAQUE chant traite (necessaire pour dessiner dedans), et ne revient
    jamais au composant actif AVANT le clic sur 'Creer' - on se retrouve
    donc avec un composant different active apres coup (signale par
    l'utilisateur). On capture donc ce contexte juste avant l'appel et on
    le restaure dans le 'finally' ci-dessous, quoi qu'il arrive."""
    global _tenon_faces
    TenonCNC = _find_module('TenonCNC')
    if TenonCNC is None:
        _palette.sendInfoToHTML('tenon_result', json.dumps({
            'error': 'add-in "Tenons CNC" inactif', 'n_faces_ok': 0, 'n_faces_total': 0, 'messages': []}))
        return
    if not _tenon_faces:
        _palette.sendInfoToHTML('tenon_result', json.dumps({
            'error': 'aucun chant selectionne', 'n_faces_ok': 0, 'n_faces_total': 0, 'messages': []}))
        return
    _prev_active_occ = None
    _had_prev_design = False
    try:
        design = adsk.fusion.Design.cast(_app.activeProduct)
        if not design:
            _palette.sendInfoToHTML('tenon_result', json.dumps({
                'error': 'aucun document actif', 'n_faces_ok': 0, 'n_faces_total': 0, 'messages': []}))
            return
        _had_prev_design = True
        try:
            # None si c'est le composant racine qui est actif (cas normal,
            # pas d'occurrence "activee").
            _prev_active_occ = design.activeOccurrence
        except Exception:
            _prev_active_occ = None
        try:
            TenonCNC._clear_preview_graphics()
        except Exception:
            pass
        params = _tenon_params_from_data(data)
        try:
            TenonCNC._save_prefs({
                'edge_dist_mm': round(params['edge_dist']*10, 4),
                'tenon_count': params['tenon_count'],
                'tenon_len_mm': round(params['tenon_len']*10, 4),
                'tenon_h_mm': round(params['tenon_h']*10, 4),
                'languette_bord_mm': round(params['languette_bord']*10, 4),
                'languette_h_mm': round(params['languette_h']*10, 4),
                'centrer': params['centrer'],
                'repartition_mode': params['repartition_mode'],
                'repartition_cotes_pct': params['repartition_cotes_pct'],
                'mortaise_auto': params['mortaise_auto'],
                'marge_auto': params['marge_auto'],
            })
        except Exception:
            pass
        _dog_keys = _dogbone_auto_keys(data, 'tenon', _tenon_dogbone_bodies(design, _tenon_faces))
        result = TenonCNC.create_tenons_core(
            design, _tenon_faces, params['mode'], params['edge_dist'],
            params['tenon_count'], params['tenon_len'], params['tenon_h'],
            params['languette_bord'], params['languette_h'], params['centrer'],
            params['repartition_mode'], params['repartition_cotes_pct'],
            params['mortaise_auto'], params['marge_auto'])
        _dogbone_auto_run(design, _dog_keys, result)
        _palette.sendInfoToHTML('tenon_result', json.dumps(result))
    except Exception:
        _palette.sendInfoToHTML('tenon_result', json.dumps({
            'error': traceback.format_exc().strip().splitlines()[-1],
            'n_faces_ok': 0, 'n_faces_total': 0, 'messages': []}))
    finally:
        # Les faces utilisees viennent d'etre decoupees/modifiees par la
        # creation : leurs references ne sont plus fiables. On vide aussi
        # la selection Fusion elle-meme (sinon les chants consommes
        # restent surlignes alors qu'ils ne sont plus valides) pour que
        # l'utilisateur reparte d'une selection propre.
        _tenon_faces = []
        try:
            _ui.activeSelections.clear()
        except Exception:
            pass
        try:
            _palette.sendInfoToHTML('tenon_selection', json.dumps({'count': 0}))
        except Exception:
            pass
        # Restaure le composant/occurrence actif d'AVANT la creation (voir
        # docstring) - create_tenons_core/MortaiseAuto/MargeAuto peuvent
        # avoir active l'occurrence d'un ou plusieurs chants traites, sans
        # jamais y revenir elles-memes.
        #
        # BUG CORRIGE : adsk.fusion.Component (ce qu'est rootComponent) n'a
        # PAS de methode .activate() - seul Occurrence en a une. L'appeler
        # levait silencieusement une AttributeError (avalee par le except
        # ci-dessous), donc la restauration ne faisait RIEN des que le
        # composant actif avant creation etait la racine (cas le plus
        # frequent) - confirme en live par script avant ce correctif. La
        # bonne methode pour reactiver la racine est Design.activateRootComponent().
        if _had_prev_design:
            try:
                if _prev_active_occ is not None:
                    _prev_active_occ.activate()
                else:
                    _design_now = adsk.fusion.Design.cast(_app.activeProduct)
                    if _design_now is not None:
                        _design_now.activateRootComponent()
            except Exception:
                pass


def _tenon_close():
    """Fermeture du panneau (bouton retour OU fermeture native de la palette -
    voir PaletteClosedHandler) : efface le fil de fer 3D, la selection Fusion
    en cours, et desactive le handler de selection live (via _tenon_panel_open)
    pour que les clics ailleurs dans Fusion n'affectent plus ce panneau.

    Pousse aussi "tenon_force_reset" cote HTML : quand la palette est fermee
    via le controle natif (croix Fusion), le webview n'est PAS recree - il
    garde son etat (ex. toujours affiche sur le panneau Tenons CNC). Sans ce
    message, une reouverture ulterieure laissait le HTML sur l'ecran Tenons
    CNC alors que _tenon_panel_open venait d'etre remis a False cote Python,
    et la selection live ne refonctionnait qu'apres un clic manuel sur
    "retour" puis "TenonCNC" (bug remonte par l'utilisateur). On force donc
    explicitement le HTML a revenir au menu principal a chaque fermeture,
    qu'elle soit native ou via le bouton retour (idempotent dans ce 2e cas)."""
    global _tenon_faces, _tenon_panel_open
    _tenon_panel_open = False
    _tenon_faces = []
    try:
        _ui.activeSelections.clear()
    except Exception:
        pass
    _tenon_restore_selection_filters()
    TenonCNC = _find_module('TenonCNC')
    if TenonCNC is not None:
        try:
            TenonCNC._clear_preview_graphics()
        except Exception:
            pass
    try:
        if _palette is not None:
            _palette.sendInfoToHTML('tenon_force_reset', '{}')
    except Exception:
        pass


def _entaille_restrict_body_selection():
    """Priorise la selection des CORPS pendant que le panneau Entaille CNC
    est ouvert - meme technique que _tenon_restrict_face_selection (voir
    plus haut : reproduit le reglage natif Fusion "Priorite de selection"),
    mais pour BodySelectionCategory au lieu de FaceSelectionCategory."""
    global _entaille_filters_saved_state
    try:
        sfs = _ui.activeWorkspace.selectionFilterSettings
        saved = {}
        for cat in sfs.availableFilters:
            try:
                saved[cat] = sfs.isFilterEnabled(cat)
                sfs.setFilterEnabled(cat, cat == 'BodySelectionCategory')
            except Exception:
                pass
        _entaille_filters_saved_state = saved
    except Exception:
        _entaille_filters_saved_state = None


def _entaille_restore_body_selection_filters():
    """Symetrique de _entaille_restrict_body_selection - voir
    _tenon_restore_selection_filters pour le detail du principe (restaure
    l'etat EXACT d'avant, jamais juste 'tout reactiver')."""
    global _entaille_filters_saved_state
    if not _entaille_filters_saved_state:
        return
    try:
        sfs = _ui.activeWorkspace.selectionFilterSettings
        for cat, was_enabled in _entaille_filters_saved_state.items():
            try:
                sfs.setFilterEnabled(cat, was_enabled)
            except Exception:
                pass
    except Exception:
        pass
    _entaille_filters_saved_state = None


def _entaille_set_role(role):
    """Bascule le "slot" cible du PROCHAIN clic dans la vue 3D (voir
    _EntailleActiveSelectionHandler) - 'cible' (corps unique a couper) ou
    'outils' (un ou plusieurs corps formant les entailles, ctrl-clic pour
    une selection multiple comme les chants de Tenons CNC)."""
    global _entaille_role
    _entaille_role = role if role in ('cible', 'outils') else 'cible'


def _entaille_cleanup_stray_opacity():
    """Filet de securite : remet a 1.0 l'opacite de tout corps du document
    actif qui correspondrait exactement a ENTAILLE_PREVIEW_OPACITY (0.35)
    sans etre suivi dans _entaille_opacity_saved - signe d'un corps reste
    assombri suite a une session precedente (ex. add-in ou Fusion redemarre
    pendant que le panneau etait ouvert) sans avoir pu etre restaure
    automatiquement, notamment via le bug de reentrance corrige - voir
    _entaille_opacity_busy. Appelee a chaque ouverture du panneau, avant
    toute nouvelle selection, pour ne jamais laisser un corps bloque assombri
    indefiniment."""
    try:
        design = adsk.fusion.Design.cast(_app.activeProduct)
    except Exception:
        design = None
    if design is None:
        return
    try:
        comps = design.allComponents
    except Exception:
        return
    for comp in comps:
        try:
            bodies = comp.bRepBodies
        except Exception:
            continue
        for b in bodies:
            try:
                if abs(b.opacity - ENTAILLE_PREVIEW_OPACITY) < 0.01:
                    b.opacity = 1.0
            except Exception:
                pass


def _entaille_open():
    """Ouverture du panneau Entaille CNC (carte 'Entaille CNC' dans la
    grille) - meme principe que _tenon_open : reinitialise la selection en
    cours, priorise la selection des corps, et pre-remplit le formulaire
    HTML avec les reglages sauvegardes (settings.json de EntailleCNC, donc
    coherent avec la boite de dialogue native)."""
    global _entaille_targets, _entaille_tools, _entaille_panel_open
    global _entaille_last_data, _entaille_role
    _entaille_targets = []
    _entaille_tools = []
    _entaille_role = 'cible'
    _entaille_reset_auto(keep_mode=False)
    _entaille_panel_open = True
    try:
        _ui.activeSelections.clear()
    except Exception:
        pass
    _entaille_cleanup_stray_opacity()
    _entaille_restrict_body_selection()
    defaults = {'depth_mm': 0.0, 'marge_auto': False, 'dogbone_auto': _dogbone_auto_pref('entaille')}
    EntailleCNC = _find_module('EntailleCNC')
    if EntailleCNC is None:
        _entaille_last_data = defaults
        _palette.sendInfoToHTML('entaille_init', json.dumps(defaults))
        _ui.messageBox(
            'L\'add-in "Entaille CNC" n\'est pas actif : le panneau peut s\'afficher, '
            'mais la creation echouera tant qu\'il n\'est pas demarre.\n\n'
            'Demarre "Entaille CNC" (Outils > Scripts et complements, Maj+S).',
            CMD_NAME)
        return
    try:
        s = EntailleCNC._load_settings()
        defaults = {'depth_mm': round(s['depth_cm'] * 10, 4), 'marge_auto': s['marge_auto'],
                    'dogbone_auto': _dogbone_auto_pref('entaille')}
    except Exception:
        pass
    _entaille_last_data = defaults
    _palette.sendInfoToHTML('entaille_init', json.dumps(defaults))
    _entaille_sync_status()


def _entaille_sync_status():
    """Suivi des entailles (voir EntailleCNC.entailles_stale) : indique au
    panneau combien de groupes d'entailles ont un corps deplace depuis leur
    creation."""
    EntailleCNC = _find_module('EntailleCNC')
    design = adsk.fusion.Design.cast(_app.activeProduct)
    payload = {'n': 0, 'corps': [], 'manquants': []}
    if EntailleCNC is not None and design and hasattr(EntailleCNC, 'entailles_stale'):
        try:
            stale = EntailleCNC.entailles_stale(design)
            payload['n'] = len(stale)
            for s_ in stale:
                payload['corps'].extend(s_.get('moved', []))
                payload['manquants'].extend(s_.get('missing', []))
        except Exception:
            payload['error'] = traceback.format_exc().strip().splitlines()[-1]
    _palette.sendInfoToHTML('entaille_sync_status', json.dumps(payload))


def _entaille_sync_run():
    """Bouton 'Mettre a jour les entailles' : recree les groupes dont un
    corps a bouge (EntailleCNC.recreate_entailles)."""
    EntailleCNC = _find_module('EntailleCNC')
    design = adsk.fusion.Design.cast(_app.activeProduct)
    result = {'n_ok': 0, 'n_total': 0, 'errors': []}
    if EntailleCNC is None or not design or not hasattr(EntailleCNC, 'recreate_entailles'):
        result['errors'].append('add-in "Entaille CNC" inactif')
    else:
        try:
            EntailleCNC._clear_preview_graphics()
        except Exception:
            pass
        try:
            n_ok, n_total, errs = EntailleCNC.recreate_entailles(design)
            result = {'n_ok': n_ok, 'n_total': n_total, 'errors': list(errs or [])}
        except Exception:
            result['errors'].append(traceback.format_exc().strip().splitlines()[-1])
    _palette.sendInfoToHTML('entaille_sync_result', json.dumps(result))
    _entaille_sync_status()


def _entaille_dim_body(body, value=ENTAILLE_PREVIEW_OPACITY):
    """Baisse l'opacite d'un corps (BRepBody.opacity, 0.0-1.0) pour laisser
    voir le fil de fer orange du preview a travers (voir
    EntailleCNC.compute_entaille_preview) - sans ca, la cible et les outils
    sont opaques et cachent entierement le preview, qui semble alors "ne pas
    bouger" quand on change le retrait. Sauvegarde l'opacite d'ORIGINE (une
    seule fois par corps, via son entityToken) pour pouvoir la restaurer
    ensuite - voir _entaille_restore_opacity.

    IMPORTANT (bug corrige - voir _entaille_opacity_busy en tete de fichier) :
    l'affectation body.opacity = value redeclenche Fusion un evenement
    activeSelectionChanged IMBRIQUE (avec une selection transitoirement vide)
    PENDANT cette meme ligne - confirme en direct par script (trace d'appels
    instrumentee). On active le garde de reentrance _entaille_opacity_busy
    pour toute la duree de cette fonction afin que
    _EntailleActiveSelectionHandler.notify ignore cet evenement fantome
    plutot que d'ecraser _entaille_target/_entaille_tools avec None en plein
    milieu d'un clic utilisateur."""
    global _entaille_opacity_saved, _entaille_opacity_busy
    try:
        tok = body.entityToken
    except Exception:
        return
    if tok not in _entaille_opacity_saved:
        try:
            _entaille_opacity_saved[tok] = body.opacity
        except Exception:
            return
    _entaille_opacity_busy = True
    try:
        body.opacity = value
    except Exception:
        pass
    finally:
        _entaille_opacity_busy = False


def _entaille_restore_opacity():
    """Restaure l'opacite d'origine de tous les corps assombris depuis
    l'ouverture du panneau (voir _entaille_dim_body) - appelee a chaque
    changement de selection (les corps qui ne sont plus cible/outils
    retrouvent immediatement leur opacite normale) et a la fermeture du
    panneau/apres creation. Retrouve chaque corps via son entityToken
    (findEntityByToken) plutot qu'une reference Python directe, qui peut
    ne plus etre valide apres une recomputation du modele.

    Meme garde de reentrance que _entaille_dim_body (voir sa docstring) -
    necessaire ici aussi puisque cette fonction affecte elle aussi
    BRepBody.opacity (pour restaurer)."""
    global _entaille_opacity_saved, _entaille_opacity_busy
    if not _entaille_opacity_saved:
        return
    try:
        design = adsk.fusion.Design.cast(_app.activeProduct)
    except Exception:
        design = None
    _entaille_opacity_busy = True
    try:
        if design is not None:
            for tok, val in list(_entaille_opacity_saved.items()):
                try:
                    for e in design.findEntityByToken(tok):
                        b = adsk.fusion.BRepBody.cast(e)
                        if b:
                            b.opacity = val
                except Exception:
                    pass
    finally:
        _entaille_opacity_busy = False
    _entaille_opacity_saved = {}


class _EntailleActiveSelectionHandler(adsk.core.ActiveSelectionEventHandler):
    """Ecoute adsk.core.UserInterface.activeSelectionChanged (meme
    mecanisme que _TenonActiveSelectionHandler), mais pour des CORPS
    entiers plutot que des faces, et avec DEUX "slots" possibles (cible /
    outils, voir _entaille_role) puisque Fusion n'a qu'une seule selection
    active a la fois : le clic courant alimente toujours le slot
    actuellement arme, l'autre slot garde sa valeur precedente (juste plus
    visuellement surligne dans la vue 3D tant qu'on n'y revient pas) - le
    panneau affiche l'etat logique des deux slots independamment (voir
    entaille_selection cote palette.html)."""
    def __init__(self):
        super().__init__()

    @staticmethod
    def _toggle_accumulate(current_list, bodies):
        """Fusionne une nouvelle selection Fusion (bodies, ce que Fusion
        vient de placer dans activeSelections) dans current_list par
        BASCULE (toggle) plutot que par remplacement pur - meme mecanisme
        pour 'cible' ET 'outils' (generalisation du 2026-10-03 : un corps
        cible simple suffisait avant, mais un assemblage "enfourchement"
        avec N montants a chacun leur propre cible en a besoin aussi, voir
        le commentaire au-dessus de _entaille_targets en tete de fichier).

        Fusion REMPLACE nativement toute la selection a chaque clic simple
        (convention standard du Select natif), donc un clic simple sur un
        NOUVEAU corps arrive ici avec bodies=[ce_corps] (lui seul) : on
        l'AJOUTE a current_list sans toucher aux autres deja choisis. Un
        clic simple sur un corps DEJA present dans current_list le RETIRE
        (meme geste que le re-clic). Un vrai Ctrl-clic natif
        (len(bodies) > 1, qui ADDITIONNE au lieu de remplacer) retombe sur
        l'ancien comportement simple : remplacement integral par la
        selection native complete. len(bodies) == 0 (clic dans le vide) :
        on NE VIDE PAS la liste deja accumulee - sinon un clic accidentel
        a cote perdrait toute la selection multiple en cours."""
        if len(bodies) == 1:
            clicked = bodies[0]
            clicked_token = getattr(clicked, 'entityToken', None)
            match = None
            for t in current_list:
                if clicked_token is not None and getattr(t, 'entityToken', None) == clicked_token:
                    match = t
                    break
            if match is not None:
                current_list.remove(match)
            else:
                current_list.append(clicked)
            return current_list
        elif len(bodies) > 1:
            return list(bodies)
        return current_list

    @staticmethod
    def _exclude_tokens(list_to_filter, exclude_list):
        """Retire de list_to_filter tout corps dont l'entityToken apparait
        dans exclude_list - utilise pour l'EXCLUSION MUTUELLE cible/outil
        (retour utilisateur du 2026-10-04 : "un outil ne doit pas etre
        selectionnable avec cible, et vice versa") : un meme corps ne peut
        pas etre a la fois cible et outil dans la meme operation Entaille
        CNC - des qu'il est ajoute a un slot (voir notify ci-dessous), il
        est silencieusement retire de l'autre s'il s'y trouvait."""
        exclude_tokens = set()
        for b in exclude_list:
            try:
                exclude_tokens.add(b.entityToken)
            except Exception:
                pass
        if not exclude_tokens:
            return list_to_filter
        return [b for b in list_to_filter if getattr(b, 'entityToken', None) not in exclude_tokens]

    def notify(self, args):
        global _entaille_targets, _entaille_tools, _entaille_bodies
        if not _entaille_panel_open:
            return
        if _entaille_opacity_busy:
            # Evenement fantome redeclenche par notre PROPRE changement
            # d'opacite (voir _entaille_dim_body/_entaille_restore_opacity) -
            # jamais une vraie action de l'utilisateur. Sans ce garde-fou,
            # cet appel imbrique ecrasait _entaille_targets/_entaille_tools
            # avec [] juste apres chaque clic cible/outil (plus de preview,
            # "Creer" qui echoue silencieusement) et videait
            # _entaille_opacity_saved avant que l'assombrissement reel n'ait
            # fini de s'appliquer (opacite qui restait bloquee a -30% a la
            # fermeture du panneau) - bug remonte par l'utilisateur, confirme en
            # direct par script instrumente.
            return
        try:
            bodies = []
            for item in args.currentSelection:
                ent = getattr(item, 'entity', item)
                b = adsk.fusion.BRepBody.cast(ent)
                if b:
                    bodies.append(b)
            # 'cible' ET 'outils' utilisent desormais EXACTEMENT le meme
            # mecanisme d'accumulation par bascule (voir _toggle_accumulate
            # ci-dessus) - avant le 2026-10-03, 'cible' se contentait du
            # 1er corps de la selection courante (_entaille_target =
            # bodies[0]), ce qui ne permettait qu'une seule cible a la
            # fois.
            if _entaille_mode == 'unique':
                _entaille_bodies = self._toggle_accumulate(_entaille_bodies, bodies)
                if _palette:
                    _palette.sendInfoToHTML('entaille_selection', json.dumps({
                        'mode': 'unique', 'corps': [b.name for b in _entaille_bodies],
                    }))
                _entaille_schedule_preview_update()
                _entaille_restore_opacity()
                for b in _entaille_bodies:
                    _entaille_dim_body(b)
                return
            if _entaille_role == 'cible':
                _entaille_targets = self._toggle_accumulate(_entaille_targets, bodies)
                # Exclusion mutuelle (retour utilisateur du 2026-10-04) : un
                # corps qui vient d'etre choisi comme cible ne peut plus
                # rester selectionne comme outil.
                _entaille_tools = self._exclude_tokens(_entaille_tools, _entaille_targets)
            else:
                _entaille_tools = self._toggle_accumulate(_entaille_tools, bodies)
                # Et reciproquement.
                _entaille_targets = self._exclude_tokens(_entaille_targets, _entaille_tools)
            # Synchronise d'abord la palette HTML et le preview 3D avec le
            # nouvel etat de selection - AVANT toute manipulation d'opacite,
            # pour que ces 2 etapes utilisent toujours l'etat correct meme si
            # le garde-fou ci-dessus devait un jour echouer.
            if _palette:
                _palette.sendInfoToHTML('entaille_selection', json.dumps({
                    'cible': [b.name for b in _entaille_targets],
                    'outils': [b.name for b in _entaille_tools],
                }))
            _entaille_schedule_preview_update()
            # Reassombrit exactement les corps actuellement cible/outils (et
            # restaure d'abord TOUS les precedents, y compris ceux qui ne
            # sont plus selectionnes) - voir _entaille_dim_body. Plus simple
            # et plus sur que de calculer une difference ancien/nouveau
            # selection a chaque clic. Fait EN DERNIER (voir docstrings de
            # ces 2 fonctions et _entaille_opacity_busy).
            _entaille_restore_opacity()
            for b in _entaille_targets:
                _entaille_dim_body(b)
            for b in _entaille_tools:
                _entaille_dim_body(b)
        except Exception:
            pass


def _entaille_params_from_data(data):
    try:
        depth_mm = max(0.0, float(data.get('depth_mm', 0.0) or 0.0))
    except Exception:
        depth_mm = 0.0
    return {'depth_cm': depth_mm / 10.0, 'marge_auto': bool(data.get('marge_auto', False))}


def _entaille_schedule_preview_update(delay=_ENTAILLE_PREVIEW_DEBOUNCE_S):
    """Programme un appel a _entaille_update_preview() dans `delay` secondes,
    en ANNULANT tout appel deja programme et pas encore execute - voir le
    commentaire "Anti-gel du preview live" en tete de fichier pour le
    contexte complet (bug remonte par l'utilisateur : gel puis crash de Fusion
    lors d'une selection multiple de nombreux corps).

    A appeler a la place de _entaille_update_preview() partout ou le
    declencheur peut survenir en rafale (clics de selection, saisie du
    champ retrait) - PAS a la place des appels ponctuels (ex. apres
    deselection explicite via bouton), ou l'appel direct reste preferable
    pour un retour visuel immediat."""
    global _entaille_preview_timer
    try:
        if _entaille_preview_timer is not None:
            _entaille_preview_timer.cancel()
    except Exception:
        pass

    def _fire():
        try:
            _app.fireCustomEvent(_ENTAILLE_PREVIEW_EVENT_ID)
        except Exception:
            pass

    t = threading.Timer(delay, _fire)
    t.daemon = True
    _entaille_preview_timer = t
    t.start()


def _entaille_cancel_scheduled_preview_update():
    """Annule un calcul d'apercu programme (voir
    _entaille_schedule_preview_update) mais pas encore execute - appelee a la
    fermeture/reinitialisation du panneau et a l'arret de l'add-in, pour ne
    jamais laisser un appel fantome se declencher apres coup (ex. sur un
    panneau deja ferme, ou un module EntailleCNC en cours de rechargement)."""
    global _entaille_preview_timer
    try:
        if _entaille_preview_timer is not None:
            _entaille_preview_timer.cancel()
    except Exception:
        pass
    _entaille_preview_timer = None


class _EntaillePreviewDebounceHandler(adsk.core.CustomEventHandler):
    """Recoit l'evenement personnalise declenche par le minuteur de
    _entaille_schedule_preview_update UNE FOIS le delai de debounce ecoule,
    et execute ENFIN (sur le thread principal de Fusion, seul endroit
    autorise a appeler l'API) le calcul couteux _entaille_update_preview."""
    def __init__(self): super().__init__()

    def notify(self, args):
        try:
            if _entaille_panel_open:
                _entaille_update_preview()
        except Exception:
            pass


def _entaille_reset_auto(keep_mode=True):
    """Vide la selection et l'analyse du mode 'Selection unique'."""
    global _entaille_mode, _entaille_bodies, _entaille_auto_cache
    global _entaille_auto_flips, _entaille_auto_focus
    if not keep_mode:
        _entaille_mode = 'classique'
    _entaille_bodies = []
    _entaille_auto_cache = None
    _entaille_auto_flips = set()
    _entaille_auto_focus = None


def _entaille_set_mode(mode):
    """Bascule 'classique' (cible/outils) <-> 'unique' : repart d'une
    selection vide dans les deux cas."""
    global _entaille_mode, _entaille_targets, _entaille_tools
    _entaille_cancel_scheduled_preview_update()
    _entaille_targets = []
    _entaille_tools = []
    _entaille_reset_auto()
    _entaille_mode = 'unique' if mode == 'unique' else 'classique'
    try:
        _ui.activeSelections.clear()
    except Exception:
        pass
    _entaille_restore_opacity()
    _entaille_update_preview()


def _entaille_auto_analysis(EntailleCNC):
    """Analyse (en cache) des paires de la selection unique courante."""
    global _entaille_auto_cache, _entaille_auto_flips, _entaille_auto_focus
    try:
        key = tuple(b.entityToken for b in _entaille_bodies)
    except Exception:
        key = None
    if _entaille_auto_cache is not None and key is not None and _entaille_auto_cache['key'] == key:
        return _entaille_auto_cache
    pairs, skipped = EntailleCNC.analyse_auto_pairs(_entaille_bodies)
    _entaille_auto_cache = {'key': key, 'pairs': pairs, 'skipped': skipped}
    _entaille_auto_flips = set()
    _entaille_auto_focus = None
    return _entaille_auto_cache


def _entaille_auto_partage():
    """'auto' (prorata des largeurs), 'moitie' (50/50) ou, en mode
    'manuel', la profondeur en cm a donner au 2e corps (bleu) de chaque
    paire (bridee au recouvrement par EntailleCNC._auto_pair_plan)."""
    d = _entaille_last_data or {}
    p = d.get('partage')
    if p == 'manuel':
        try:
            return max(0.0, float(d.get('depth_auto_mm', 0.0) or 0.0)) / 10.0
        except Exception:
            return 0.0
    return 'moitie' if p == 'moitie' else 'auto'


def _entaille_update_preview_auto(EntailleCNC):
    if EntailleCNC is None or len(_entaille_bodies) < 2:
        if EntailleCNC is not None:
            try:
                EntailleCNC._clear_preview_graphics()
            except Exception:
                pass
        try:
            if _palette:
                _palette.sendInfoToHTML('entaille_auto_preview', json.dumps(
                    {'ok': False, 'pairs': [], 'skipped': [], 'n_corps': len(_entaille_bodies)}))
        except Exception:
            pass
        return
    try:
        design = adsk.fusion.Design.cast(_app.activeProduct)
        if not design:
            return
        cache = _entaille_auto_analysis(EntailleCNC)
        result = EntailleCNC.draw_auto_preview(design, cache['pairs'], cache['skipped'],
                                               _entaille_auto_flips, _entaille_auto_partage(),
                                               _entaille_auto_focus)
        result['n_corps'] = len(_entaille_bodies)
        _palette.sendInfoToHTML('entaille_auto_preview', json.dumps(result))
    except Exception:
        try:
            _palette.sendInfoToHTML('entaille_auto_preview', json.dumps(
                {'ok': False, 'pairs': [], 'skipped': [], 'n_corps': len(_entaille_bodies),
                 'error': traceback.format_exc().strip().splitlines()[-1]}))
        except Exception:
            pass


def _entaille_auto_flip(data):
    """Bouton Inverser d'une paire (index 'i'), de toutes les paires
    ('tous': true - inverse le sens de chaque mi-bois, les rainures
    d'insertion ne bougent pas) ou de toutes les paires ambigues
    ('ambigus': true)."""
    global _entaille_auto_flips
    if _entaille_auto_cache is None:
        return
    if data.get('tous'):
        for i, p in enumerate(_entaille_auto_cache['pairs']):
            if p.get('kind') == 'mibois':
                _entaille_auto_flips ^= {i}
    elif data.get('ambigus'):
        for i, p in enumerate(_entaille_auto_cache['pairs']):
            if p.get('ambiguous'):
                _entaille_auto_flips ^= {i}
    else:
        try:
            _entaille_auto_flips ^= {int(data.get('i'))}
        except Exception:
            return
    _entaille_update_preview()


def _entaille_auto_set_focus(data):
    global _entaille_auto_focus
    try:
        i = int(data.get('i'))
    except Exception:
        i = None
    _entaille_auto_focus = None if i == _entaille_auto_focus else i
    _entaille_update_preview()


def _entaille_update_preview():
    """Recalcule le fil de fer d'apercu (CustomGraphics, voir
    EntailleCNC.compute_entaille_preview) a partir de la selection
    courante ET du retrait de profondeur actuellement affiche dans le
    panneau (_entaille_last_data, mis a jour par le handler
    "entaille_params") - purement visuel/temporaire, aucune modification du
    document (voir la note dans compute_entaille_preview sur
    l'approximation utilisee). Appelee a la fois par le changement de
    selection (_EntailleActiveSelectionHandler) et par le changement du
    champ retrait (voir le handler "entaille_params" ci-dessous), pour que
    le schema 2D reste toujours synchronise."""
    EntailleCNC = _find_module('EntailleCNC')
    if _entaille_mode == 'unique':
        _entaille_update_preview_auto(EntailleCNC)
        return
    if EntailleCNC is None or not _entaille_targets or not _entaille_tools:
        try:
            if _palette:
                _palette.sendInfoToHTML('entaille_preview', json.dumps({'ok': False, 'reason': None}))
        except Exception:
            pass
        if EntailleCNC is not None:
            try:
                EntailleCNC._clear_preview_graphics()
            except Exception:
                pass
        return
    try:
        design = adsk.fusion.Design.cast(_app.activeProduct)
        if not design:
            return
        depth_cm = _entaille_params_from_data(_entaille_last_data)['depth_cm']
        result = EntailleCNC.compute_entaille_preview_multi(design, _entaille_targets, _entaille_tools, depth_cm)
        _palette.sendInfoToHTML('entaille_preview', json.dumps(result))
    except Exception:
        pass


def _dogbone_auto_pref(tool):
    """Etat memorise de la case "Dogbone auto" ('entaille' ou 'tenon'), lu
    directement dans dogbone_prefs.json (DogboneCNC n'est charge qu'au
    premier usage)."""
    try:
        p = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'DogboneCNC', 'dogbone_prefs.json')
        with open(p, 'r', encoding='utf-8') as f:
            return bool(json.load(f).get('auto_' + tool, False))
    except Exception:
        return False


def _dogbone_auto_keys(data, tool, bodies):
    """Dogbone auto, AVANT la creation des coupes : memorise la case et
    renvoie les cles des corps a traiter (None si decochee)."""
    on = bool(data.get('dogbone_auto', False))
    if on == _dogbone_auto_pref(tool) and not on:
        return None
    Dog = _ensure_module('DogboneCNC') if on else _find_module('DogboneCNC')
    if Dog is None:
        return None
    try:
        Dog.set_auto(tool, on)
        return Dog.body_keys(bodies) if on else None
    except Exception:
        return None


def _dogbone_auto_run(design, keys, result):
    """Dogbone auto, APRES la creation des coupes : dogbones sur les coins
    interieurs encore libres des corps concernes."""
    if not keys:
        return
    Dog = _find_module('DogboneCNC')
    if Dog is None:
        return
    try:
        r = Dog.auto_dogbones(design, keys)
        if isinstance(result, dict):
            result.setdefault('messages', []).append(
                'Dogbone auto : %d coin(s) sur %d corps.' % (r.get('n_corners', 0), r.get('n_bodies', 0)))
    except Exception:
        if isinstance(result, dict):
            result.setdefault('messages', []).append(
                'Dogbone auto : ' + traceback.format_exc().strip().splitlines()[-1])


def _entaille_create(data):
    """Creation reelle (bouton 'Creer' du panneau) : delegue entierement a
    EntailleCNC.create_entaille_core, exactement comme le ferait la boite
    de dialogue native (voir _tenon_create pour la meme logique de
    restauration du composant actif)."""
    global _entaille_targets, _entaille_tools
    EntailleCNC = _find_module('EntailleCNC')
    if EntailleCNC is None:
        _palette.sendInfoToHTML('entaille_result', json.dumps({
            'error': 'add-in "Entaille CNC" inactif', 'n_cotes_ok': 0, 'n_cotes_total': 0, 'messages': []}))
        return
    if _entaille_mode == 'unique':
        _entaille_create_auto(EntailleCNC, data)
        return
    if not _entaille_targets or not _entaille_tools:
        _palette.sendInfoToHTML('entaille_result', json.dumps({
            'error': 'corps cible et corps de decoupe requis', 'n_cotes_ok': 0, 'n_cotes_total': 0, 'messages': []}))
        return
    _prev_active_occ = None
    _had_prev_design = False
    try:
        design = adsk.fusion.Design.cast(_app.activeProduct)
        if not design:
            _palette.sendInfoToHTML('entaille_result', json.dumps({
                'error': 'aucun document actif', 'n_cotes_ok': 0, 'n_cotes_total': 0, 'messages': []}))
            return
        _had_prev_design = True
        try:
            _prev_active_occ = design.activeOccurrence
        except Exception:
            _prev_active_occ = None
        try:
            EntailleCNC._clear_preview_graphics()
        except Exception:
            pass
        params = _entaille_params_from_data(data)
        try:
            EntailleCNC._save_settings(params['depth_cm'], params['marge_auto'])
        except Exception:
            pass
        # Groupe de timeline unique pour TOUTE cette creation (entaille(s)
        # + MargeAuto le cas echeant, tout gere a l'interieur de
        # create_entaille_core) - demande explicite de l'utilisateur (meme
        # mecanisme que Tenon CNC) : un seul groupe nomme par utilisation,
        # supprimable d'un coup (clic droit > Supprimer, avec son contenu)
        # dans l'historique, plutot que de devoir faire Ctrl+Z plusieurs
        # fois (Ctrl+Z reste multi-etapes quel que soit le regroupement en
        # features/groupes - limite de Fusion, voir TenonCNC.py).
        _dog_keys = _dogbone_auto_keys(data, 'entaille', list(_entaille_targets) + list(_entaille_tools))
        tl = design.timeline
        _start_index = tl.markerPosition
        result = EntailleCNC.create_entaille_core_multi(
            design, _entaille_targets, _entaille_tools, params['depth_cm'], params['marge_auto'])
        _end_index = tl.markerPosition - 1
        try:
            EntailleCNC.record_lot(design, 'classique', _start_index, _end_index,
                                   targets=_entaille_targets, tools=_entaille_tools,
                                   depth_cm=params['depth_cm'], marge_auto=params['marge_auto'])
        except Exception:
            pass
        if _end_index > _start_index:
            try:
                _grp = tl.timelineGroups.add(_start_index, _end_index)
                if _grp:
                    _grp.name = 'Entaille CNC'
                    _grp.isCollapsed = True
            except Exception:
                pass
        _dogbone_auto_run(design, _dog_keys, result)
        _palette.sendInfoToHTML('entaille_result', json.dumps(result))
        _entaille_sync_status()
    except Exception:
        _palette.sendInfoToHTML('entaille_result', json.dumps({
            'error': traceback.format_exc().strip().splitlines()[-1],
            'n_cotes_ok': 0, 'n_cotes_total': 0, 'messages': []}))
    finally:
        # Restaure l'opacite d'origine des corps assombris pour le preview -
        # une fois l'entaille creee (ou en cas d'echec), on veut revoir le
        # resultat final a opacite normale, pas assombri.
        _entaille_restore_opacity()
        _entaille_targets = []
        _entaille_tools = []
        try:
            _ui.activeSelections.clear()
        except Exception:
            pass
        try:
            _palette.sendInfoToHTML('entaille_selection', json.dumps({'cible': [], 'outils': []}))
        except Exception:
            pass
        if _had_prev_design:
            try:
                if _prev_active_occ is not None:
                    _prev_active_occ.activate()
                else:
                    _design_now = adsk.fusion.Design.cast(_app.activeProduct)
                    if _design_now is not None:
                        _design_now.activateRootComponent()
            except Exception:
                pass


def _entaille_create_auto(EntailleCNC, data):
    """Creation en mode 'Selection unique' : toutes les paires detectees,
    avec le sens affiche dans l'apercu (inversions comprises), dans un seul
    groupe de timeline 'Entaille CNC' (meme principe que _entaille_create)."""
    global _entaille_last_data
    _prev_active_occ = None
    _had_prev_design = False
    try:
        design = adsk.fusion.Design.cast(_app.activeProduct)
        if not design:
            _palette.sendInfoToHTML('entaille_result', json.dumps({
                'error': 'aucun document actif', 'n_cotes_ok': 0, 'n_cotes_total': 0, 'messages': []}))
            return
        if len(_entaille_bodies) < 2:
            _palette.sendInfoToHTML('entaille_result', json.dumps({
                'error': 'selectionnez au moins 2 corps', 'n_cotes_ok': 0, 'n_cotes_total': 0, 'messages': []}))
            return
        _had_prev_design = True
        try:
            _prev_active_occ = design.activeOccurrence
        except Exception:
            _prev_active_occ = None
        _entaille_last_data = data
        params = _entaille_params_from_data(data)
        cache = _entaille_auto_analysis(EntailleCNC)
        try:
            EntailleCNC._clear_preview_graphics()
        except Exception:
            pass
        _dog_keys = _dogbone_auto_keys(data, 'entaille', list(_entaille_bodies))
        tl = design.timeline
        _start_index = tl.markerPosition
        _mode = _entaille_auto_partage()
        result = EntailleCNC.create_entaille_auto(
            design, cache['pairs'], set(_entaille_auto_flips), _mode,
            params['marge_auto'])
        _end_index = tl.markerPosition - 1
        try:
            EntailleCNC.record_lot(design, 'unique', _start_index, _end_index,
                                   bodies=list(_entaille_bodies), pairs=cache['pairs'],
                                   flips=set(_entaille_auto_flips), mode=_mode,
                                   marge_auto=params['marge_auto'])
        except Exception:
            pass
        if _end_index > _start_index:
            try:
                _grp = tl.timelineGroups.add(_start_index, _end_index)
                if _grp:
                    _grp.name = 'Entaille CNC'
                    _grp.isCollapsed = True
            except Exception:
                pass
        _dogbone_auto_run(design, _dog_keys, result)
        _palette.sendInfoToHTML('entaille_result', json.dumps(result))
        _entaille_sync_status()
    except Exception:
        _palette.sendInfoToHTML('entaille_result', json.dumps({
            'error': traceback.format_exc().strip().splitlines()[-1],
            'n_cotes_ok': 0, 'n_cotes_total': 0, 'messages': []}))
    finally:
        _entaille_restore_opacity()
        _entaille_reset_auto()
        try:
            _ui.activeSelections.clear()
        except Exception:
            pass
        try:
            _palette.sendInfoToHTML('entaille_selection', json.dumps({'mode': 'unique', 'corps': []}))
            _palette.sendInfoToHTML('entaille_auto_preview', json.dumps(
                {'ok': False, 'pairs': [], 'skipped': [], 'n_corps': 0}))
        except Exception:
            pass
        if _had_prev_design:
            try:
                if _prev_active_occ is not None:
                    _prev_active_occ.activate()
                else:
                    _design_now = adsk.fusion.Design.cast(_app.activeProduct)
                    if _design_now is not None:
                        _design_now.activateRootComponent()
            except Exception:
                pass


def _entaille_close():
    """Fermeture du panneau (bouton retour OU fermeture native) - meme
    principe que _tenon_close."""
    global _entaille_targets, _entaille_tools, _entaille_panel_open, _entaille_role
    _entaille_panel_open = False
    _entaille_cancel_scheduled_preview_update()
    _entaille_targets = []
    _entaille_tools = []
    _entaille_role = 'cible'
    _entaille_reset_auto(keep_mode=False)
    try:
        _ui.activeSelections.clear()
    except Exception:
        pass
    _entaille_restore_body_selection_filters()
    _entaille_restore_opacity()
    EntailleCNC = _find_module('EntailleCNC')
    if EntailleCNC is not None:
        try:
            EntailleCNC._clear_preview_graphics()
        except Exception:
            pass
    try:
        if _palette is not None:
            _palette.sendInfoToHTML('entaille_force_reset', '{}')
    except Exception:
        pass


def _entaille_deselect():
    """Bouton 'Deselectionner' du panneau Entaille CNC (demande de l'utilisateur,
    2026-10-04) : vide les listes cible/outils courantes SANS fermer le
    panneau (contrairement a _entaille_close) - l'utilisateur reste sur le
    meme role actif et peut recommencer une nouvelle selection a froid."""
    global _entaille_targets, _entaille_tools
    _entaille_cancel_scheduled_preview_update()
    _entaille_targets = []
    _entaille_tools = []
    _entaille_reset_auto()
    try:
        _ui.activeSelections.clear()
    except Exception:
        pass
    _entaille_restore_opacity()
    try:
        if _palette is not None:
            _palette.sendInfoToHTML('entaille_selection', json.dumps({
                'cible': [], 'outils': [], 'mode': _entaille_mode, 'corps': [],
            }))
    except Exception:
        pass
    _entaille_update_preview()


def _ensure_module(short_name):
    """Comme _find_module, mais demarre l'add-in s'il n'est pas charge.

    JonctionCNC et DogboneCNC ne sont pas enregistres dans "Scripts et
    complements" de Fusion (les autres outils du Toolkit y ont ete ajoutes a
    la main avec "+") : apres un redemarrage de Fusion, ils n'etaient donc pas
    lances et la palette affichait "n'est pas actif" (retour de l'utilisateur le
    2026-10-06). On les charge ici a la demande, au premier clic, avec la
    meme cle de module que Fusion pour que _find_module les retrouve."""
    mod = _find_module(short_name)
    if mod is not None or short_name not in ('JonctionCNC', 'DogboneCNC', 'PurgeCNC', 'ExtrusionCNC', 'CalpinageCNC', 'ReseauTrajectoireCNC'):
        return mod
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), short_name, short_name + '.py')
    if not os.path.isfile(path):
        return None
    import types
    key = '__main__' + path.replace(os.sep, '/').replace(':', '%3A').replace('/', '%2F').replace(' ', '%20').replace('.py', '_py')
    mod = types.ModuleType(key)
    mod.__file__ = path
    sys.modules[key] = mod
    try:
        with open(path, 'r', encoding='utf-8') as f:
            src = f.read()
        exec(compile(src, path, 'exec'), mod.__dict__)
        mod.run({'IsApplicationStartup': False})
    except Exception:
        sys.modules.pop(key, None)
        _ui.messageBox('Erreur au demarrage de %s:\n%s' % (short_name, traceback.format_exc()), CMD_NAME)
        return None
    return mod


def _jonction_dispatch(action, data):
    """Panneau Jonction de la palette : toute la logique (selection d'arete,
    preview, decoupe) est dans JonctionCNC.py - le lanceur ne fait que
    relayer les messages "jonction_*"."""
    mod = _ensure_module('JonctionCNC')
    if mod is None:
        if action == 'jonction_open':
            _ui.messageBox(
                'L\'add-in "JonctionCNC" n\'est pas actif.\n\n'
                'Demarre "JonctionCNC" (Outils > Scripts et complements, Maj+S).',
                CMD_NAME)
        return
    mod.handle_palette_action(action, data)


class LauncherCommandCreatedHandler(adsk.core.CommandCreatedEventHandler):
    """Bouton de ruban 'CNC Toolkit' : n'affiche aucun dialogue, ouvre/bascule
    juste la visibilite de la palette (action instantanee - voir _show_palette)."""
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            _show_palette()
        except Exception:
            _ui.messageBox("Erreur ouverture CNC Toolkit:\n" + traceback.format_exc(), CMD_NAME)


class HTMLEventHandler(adsk.core.HTMLEventHandler):
    """Recoit les messages envoyes par palette.html (adsk.fusionSendData)."""
    def __init__(self): super().__init__()
    def notify(self, args):
        global _tenon_last_data, _entaille_last_data, _raccourci_en_attente
        try:
            action = args.action
            data = json.loads(args.data) if args.data else {}
            # Un outil travaille sous la barre de chargement (cnc_progress
            # rafraichit Fusion pendant le calcul) : on ignore les clics de
            # la palette pour ne pas lancer un 2e outil au milieu du 1er.
            _barre = sys.modules.get('cnc_progress')
            if _barre is not None and _barre.occupe():
                return
            if (action == "ready" or action.endswith("_open")) and action != "dogbone_open":
                # Filet de securite : un autre panneau (ou une palette
                # rechargee) ne doit jamais heriter des filtres de selection
                # "corps uniquement" d'un panneau Dogbone CNC reste ouvert.
                _DogboneCNC = _find_module('DogboneCNC')
                if _DogboneCNC is not None and getattr(_DogboneCNC, '_panel_open', False):
                    # palette None : ne renvoie rien a la page (l'autre
                    # panneau est deja affiche, ne pas revenir au menu).
                    _DogboneCNC.palette_message(None, 'dogbone_close', {})
            if action == "ready" or (action.endswith("_open") and action != "calpinage_open"):
                # Meme filet de securite pour l'apercu du panneau Calpinage.
                _Calpinage = _find_module('CalpinageCNC')
                if _Calpinage is not None and getattr(_Calpinage, '_panel_open', False):
                    _Calpinage.palette_message(None, 'calpinage_close', {})
            if action.startswith("jonction_"):
                _jonction_dispatch(action, data)
                return
            if action.startswith("shortcuts_"):
                _raccourcis_dispatch(action, data)
                return
            if action.startswith("maj_"):
                _maj_dispatch(action, data)
                return
            if action.startswith("i18n_"):
                # Drapeaux FR/EN de la palette (voir cnc_i18n.py).
                if action == "i18n_set":
                    cnc_i18n.definir_langue(data.get("langue", "fr"))
                _palette.sendInfoToHTML("i18n", json.dumps(cnc_i18n.payload()))
                return
            if action.startswith("calpinage_"):
                # Panneau Calpinage CNC : toute sa logique vit dans
                # CalpinageCNC.palette_message (voir CalpinageCNC.py).
                Calpinage = _ensure_module('CalpinageCNC') if action == 'calpinage_open' else _find_module('CalpinageCNC')
                if Calpinage is not None:
                    Calpinage.palette_message(_palette, action, data)
                elif action == 'calpinage_open':
                    _palette.sendInfoToHTML('calpinage_force_reset', '{}')
                return
            if action == "ready":
                # La page HTML vient de finir de charger : on lui envoie
                # l'etat de disponibilite de chaque outil (voir palette.html).
                _palette.sendInfoToHTML("status", json.dumps(_availability_payload()))
                if _raccourci_en_attente:
                    _palette.sendInfoToHTML("shortcut_launch", json.dumps({"cmd": _raccourci_en_attente}))
                    _raccourci_en_attente = None
            elif action == "launch":
                cmd_id = data.get("cmd", "")
                if cmd_id:
                    _launch_tool(cmd_id)
            elif action == "tenon_open":
                _tenon_open()
            elif action == "tenon_params":
                _tenon_last_data = data
                _tenon_update_preview(data)
            elif action == "tenon_create":
                with cnc_progress.Barre('Tenons CNC', 'Creation des tenons...'):
                    _tenon_create(data)
            elif action == "tenon_close":
                _tenon_close()
            elif action == "entaille_open":
                _entaille_open()
            elif action == "entaille_role":
                _entaille_set_role(data.get("role", "cible"))
            elif action == "entaille_deselect":
                _entaille_deselect()
            elif action == "entaille_mode":
                _entaille_set_mode(data.get("mode", "classique"))
            elif action == "entaille_flip":
                _entaille_auto_flip(data)
            elif action == "entaille_focus":
                _entaille_auto_set_focus(data)
            elif action == "entaille_params":
                _entaille_last_data = data
                # Un changement du retrait de profondeur (ou de MargeAuto)
                # doit rafraichir le schema d'apercu live (overlap/retrait),
                # pas seulement un changement de selection - voir
                # _entaille_update_preview. Debounce (voir
                # _entaille_schedule_preview_update) : la saisie du champ
                # retrait peut aussi arriver en rafale (fleches haut/bas,
                # glissement), avec le meme risque de gel que la selection.
                _entaille_schedule_preview_update()
            elif action == "entaille_create":
                with cnc_progress.Barre('Entaille CNC', 'Creation des entailles...'):
                    _entaille_create(data)
            elif action == "entaille_sync_check":
                _entaille_sync_status()
            elif action == "entaille_sync":
                with cnc_progress.Barre('Entaille CNC', 'Mise a jour des entailles...'):
                    _entaille_sync_run()
            elif action == "entaille_close":
                _entaille_close()
            elif action.startswith("dogbone_"):
                # Panneau Dogbone CNC : toute sa logique vit dans
                # DogboneCNC.palette_message (voir DogboneCNC.py).
                DogboneCNC = _ensure_module('DogboneCNC') if action == 'dogbone_open' else _find_module('DogboneCNC')
                if DogboneCNC is not None:
                    DogboneCNC.palette_message(_palette, action, data)
                elif action == "dogbone_open":
                    _palette.sendInfoToHTML('dogbone_force_reset', '{}')
                    _ui.messageBox(
                        'L\'add-in "Dogbone CNC" n\'est pas actif.\n\n'
                        'Demarre "DogboneCNC" (Outils > Scripts et complements, Maj+S).',
                        CMD_NAME)
        except Exception:
            _ui.messageBox("Erreur CNC Toolkit:\n" + traceback.format_exc(), CMD_NAME)


class PaletteClosedHandler(adsk.core.UserInterfaceGeneralEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            _jonction_dispatch("jonction_close", {})
        except Exception:
            pass
        # Le panneau CNC Toolkit vient d'etre ferme (bouton de fermeture natif
        # Fusion, pas le bouton retour HTML) - on nettoie quand meme la
        # selection/l'etat des panneaux Tenons CNC et Entaille CNC comme si
        # l'utilisateur avait clique sur "retour", pour ne pas laisser un
        # chant/corps selectionne en surbrillance dans la vue 3D apres
        # fermeture de la palette.
        try:
            _tenon_close()
        except Exception:
            pass
        try:
            _entaille_close()
        except Exception:
            pass
        try:
            _DogboneCNC = _find_module('DogboneCNC')
            if _DogboneCNC is not None:
                _DogboneCNC.palette_message(_palette, 'dogbone_close', {})
        except Exception:
            pass
        try:
            _Calpinage = _find_module('CalpinageCNC')
            if _Calpinage is not None:
                _Calpinage.palette_message(None, 'calpinage_close', {})
        except Exception:
            pass


def _show_palette():
    global _palette
    palettes = _ui.palettes
    _palette = palettes.itemById(PALETTE_ID)
    if _palette is None:
        # IMPORTANT : ne JAMAIS construire un chemin Windows absolu ici
        # (os.path.join donne des antislashs, ex. "C:\Users\...\ToolkitCNC")
        # - Fusion transforme ce chemin en URL file:// en encodant les
        # antislashs tels quels (%5C) au lieu de les convertir en "/", ce qui
        # donne une URL invalide ("ERR_INVALID_URL" - bug constate en direct,
        # capture d'ecran a l'appui). Un simple nom de fichier RELATIF au
        # dossier de cet add-in (comportement documente de Palettes.add)
        # evite completement le probleme, quel que soit l'OS.
        _palette = palettes.add(
            PALETTE_ID, PALETTE_NAME, PALETTE_HTML,
            True,   # isVisible
            True,   # showCloseButton
            True,   # isResizable
            340,    # width
            520,    # height
        )
        _palette.dockingState = adsk.core.PaletteDockingStates.PaletteDockStateRight
        on_html = HTMLEventHandler()
        _palette.incomingFromHTML.add(on_html)
        _handlers.append(on_html)
        on_closed = PaletteClosedHandler()
        _palette.closed.add(on_closed)
        _handlers.append(on_closed)
    else:
        _palette.isVisible = not _palette.isVisible


def run(context):
    global _app, _ui, _tenon_sel_handler, _entaille_sel_handler
    global _entaille_preview_custom_event, _entaille_preview_custom_handler
    try:
        _app = adsk.core.Application.get()
        _ui = _app.userInterface

        # Evenement personnalise utilise pour debouncer le preview live
        # d'Entaille CNC (voir "Anti-gel du preview live" plus haut et
        # _entaille_schedule_preview_update) - desinscrit d'abord un residu
        # eventuel d'un rechargement precedent de l'add-in avant de
        # reinscrire, meme precaution que old_cmd ci-dessous pour CMD_ID.
        try:
            _app.unregisterCustomEvent(_ENTAILLE_PREVIEW_EVENT_ID)
        except Exception:
            pass
        _entaille_preview_custom_event = _app.registerCustomEvent(_ENTAILLE_PREVIEW_EVENT_ID)
        _entaille_preview_custom_handler = _EntaillePreviewDebounceHandler()
        _entaille_preview_custom_event.add(_entaille_preview_custom_handler)
        _handlers.append(_entaille_preview_custom_handler)

        # Langue FR/EN : traduction des textes envoyes a l'ecran par tous
        # les outils (voir cnc_i18n.py), posee avant de creer nos boutons.
        try:
            cnc_i18n.installer()
            cnc_i18n.memoriser_boutons()
        except Exception:
            pass

        old_cmd = _ui.commandDefinitions.itemById(CMD_ID)
        if old_cmd:
            old_cmd.deleteMe()

        cmd_def = _ui.commandDefinitions.addButtonDefinition(CMD_ID, CMD_NAME, CMD_DESC, "./resources")
        on_created = LauncherCommandCreatedHandler()
        cmd_def.commandCreated.add(on_created)
        _handlers.append(on_created)

        # Selection live des chants pour le panneau Tenons CNC (voir
        # _TenonActiveSelectionHandler) - enregistre une seule fois, actif
        # tout le temps mais ne fait quelque chose que si _tenon_panel_open.
        _tenon_sel_handler = _TenonActiveSelectionHandler()
        _ui.activeSelectionChanged.add(_tenon_sel_handler)
        _handlers.append(_tenon_sel_handler)

        # Selection live des corps pour le panneau Entaille CNC (meme
        # principe, voir _EntailleActiveSelectionHandler).
        _entaille_sel_handler = _EntailleActiveSelectionHandler()
        _ui.activeSelectionChanged.add(_entaille_sel_handler)
        _handlers.append(_entaille_sel_handler)

        # Nettoyage d'une CommandDefinition d'un essai precedent (version qui
        # ouvrait une petite fenetre de selection, abandonnee car rejetee par
        # l'utilisateur) - si elle existe encore sur ce poste, on la supprime
        # pour ne pas laisser de residu inutile.
        try:
            legacy_sel_cmd = _ui.commandDefinitions.itemById("ToolkitCNC_TenonLiveSelect")
            if legacy_sel_cmd:
                legacy_sel_cmd.deleteMe()
        except Exception:
            pass

        added = False
        for pid in PANEL_IDS:
            try:
                panel = _ui.allToolbarPanels.itemById(pid)
                if panel is None:
                    continue
                if not panel.controls.itemById(CMD_ID):
                    panel.controls.addCommand(cmd_def)
                added = True
            except Exception:
                continue
        if not added:
            _dbg_fallback_panel(cmd_def)

        # Extrusion CNC (2026-10-09) : demarre avec le Toolkit pour que son
        # bouton soit present dans Solide > Creer des l'ouverture de Fusion.
        try:
            _ensure_module('ExtrusionCNC')
        except Exception:
            pass
        # Reseau sur la trajectoire CNC (2026-10-12) : idem, bouton dans
        # Solide > Creer > Reseau.
        try:
            _ensure_module('ReseauTrajectoireCNC')
        except Exception:
            pass

        # Raccourcis clavier des outils (voir cnc_raccourcis.py).
        try:
            cnc_raccourcis.demarrer(_app, _raccourci_declenche)
        except Exception:
            pass
        # Boutons des outils demarres avant CNC Toolkit : dans la langue choisie.
        try:
            if cnc_i18n.langue() != 'fr':
                cnc_i18n.memoriser_boutons()
                cnc_i18n.rafraichir_ruban()
        except Exception:
            pass
    except Exception:
        if _ui:
            _ui.messageBox("Erreur au demarrage de CNC Toolkit:\n" + traceback.format_exc())


def _dbg_fallback_panel(cmd_def):
    try:
        panel = _ui.allToolbarPanels.itemById("SolidScriptsAddinsPanel")
        if panel and not panel.controls.itemById(CMD_ID):
            panel.controls.addCommand(cmd_def)
    except Exception:
        pass


def stop(context):
    global _tenon_sel_handler, _tenon_panel_open
    global _entaille_sel_handler, _entaille_panel_open
    try:
        _tenon_panel_open = False
        _entaille_panel_open = False
        # Filet de securite : si l'add-in est arrete/recharge pendant que le
        # panneau Tenons CNC ou Entaille CNC avait restreint la selection
        # (voir _tenon_restrict_face_selection/_entaille_restrict_body_selection),
        # on ne laisse pas Fusion avec des categories de selection
        # desactivees en permanence.
        _tenon_restore_selection_filters()
        _entaille_restore_body_selection_filters()
        _entaille_restore_opacity()
        # Annule tout calcul de preview debounce en attente (voir
        # _entaille_schedule_preview_update) avant de desinscrire
        # l'evenement personnalise qu'il declenche - sinon un minuteur deja
        # en cours pourrait appeler fireCustomEvent sur un evenement qui
        # n'existe plus.
        _entaille_cancel_scheduled_preview_update()
        try:
            cnc_raccourcis.arreter(_app)
        except Exception:
            pass
        try:
            cnc_i18n.desinstaller()
        except Exception:
            pass
        try:
            _app.unregisterCustomEvent(_ENTAILLE_PREVIEW_EVENT_ID)
        except Exception:
            pass
        if _tenon_sel_handler is not None:
            try:
                _ui.activeSelectionChanged.remove(_tenon_sel_handler)
            except Exception:
                pass
            _tenon_sel_handler = None
        if _entaille_sel_handler is not None:
            try:
                _ui.activeSelectionChanged.remove(_entaille_sel_handler)
            except Exception:
                pass
            _entaille_sel_handler = None
        for pid in PANEL_IDS:
            try:
                panel = _ui.allToolbarPanels.itemById(pid)
                if panel:
                    c = panel.controls.itemById(CMD_ID)
                    if c:
                        c.deleteMe()
            except Exception:
                continue
        cmd_def = _ui.commandDefinitions.itemById(CMD_ID)
        if cmd_def:
            cmd_def.deleteMe()
        # On ferme/supprime la palette pour eviter une erreur "deja existante"
        # au prochain demarrage de l'add-in (voir _show_palette).
        pal = _ui.palettes.itemById(PALETTE_ID)
        if pal:
            pal.deleteMe()
    except Exception:
        if _ui:
            _ui.messageBox("Erreur a l'arret de CNC Toolkit:\n" + traceback.format_exc())
