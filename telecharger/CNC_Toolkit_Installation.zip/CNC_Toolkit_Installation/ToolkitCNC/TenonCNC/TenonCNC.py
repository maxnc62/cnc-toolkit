import os
import sys
import adsk.core, adsk.fusion
import math
import traceback

# Barre de chargement commune du Toolkit (ToolkitCNC/cnc_progress.py)
_TK_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _TK_DIR not in sys.path:
    sys.path.append(_TK_DIR)
import cnc_progress

app  = None
ui   = None
_handlers        = []
_iso_hidden = []
_sel_faces_cache = {}
_preview_geom_present = False  # True si des tenons "live preview" existent deja
_preview_feat_tokens = []      # entityTokens des features creees par CETTE session de preview
_preview_sketch_tokens = []    # entityTokens des sketches creees par CETTE session de preview
# Apercu "trait leger" (CustomGraphics) - voir _draw_tenon_preview_graphics :
# remplace l'ancien apercu en VRAIE matiere (cree/purge a chaque changement
# de parametre, donc lourd - inspire par la fluidite du preview de l'add-in
# concurrent Tab & Slot, qui dessine en traits plutot que de modifier le
# corps). _preview_cg_group est le groupe de graphiques legers actuellement
# affiche (None si aucun) - un seul groupe pour TOUTES les faces/tenons de
# l'apercu en cours, recree entierement a chaque executePreview.
_preview_cg_group = None
_create_params = None
_create_ev_id = 'TenonCreateEv'
_purge_ev_id = 'TenonPurgeEv'
_delete_sel_ev_id = 'TenonDeleteSelEv'

import json as _json
import uuid as _uuid
# Chemins calcules DYNAMIQUEMENT par rapport a l'emplacement reel de ce
# fichier (meme convention que MargeCNC.py/ToolkitCNC.py) - et non plus en
# dur sur l'ancien chemin .../API/AddIns/TenonCNC : ces chemins en dur
# cassaient des que l'add-in etait deplace/range dans un autre dossier
# (voir le regroupement des add-ins sous ToolkitCNC).
_ADDIN_DIR = os.path.dirname(os.path.abspath(__file__))
_ADDINS_ROOT = os.path.dirname(_ADDIN_DIR)
_PREFS_FILE = os.path.join(_ADDIN_DIR, 'tenon_prefs.json')
_FACE_MAP_FILE = os.path.join(_ADDIN_DIR, 'tenon_face_map.json')
# Fichier PARTAGE avec Mortaise CNC / Marge CNC (voir leurs propres
# FACE_MAP_FILE/MORTAISE_FACE_MAP_FILE) : un enregistrement par mortaise
# precise {male_token, female_token, face_tokens}. Lu/modifie par
# 'Annuler tenon CNC' pour retirer UNIQUEMENT les faces de LA mortaise
# annulee (voir _pop_mortaise_record) - jamais tout le corps femelle, qui
# peut recevoir plusieurs mortaises d'autres tenons.
_MORTAISE_FACE_MAP_FILE = os.path.join(_ADDINS_ROOT, 'MortaiseCNC', 'mortaise_face_map.json')

import time as _time
_DEBUG_LOG = os.path.join(_ADDIN_DIR, 'tenon_debug.log')

def _dbg(msg):
    # Log de diagnostic temporaire (pour retrouver pourquoi "Creer" ne cree rien).
    try:
        with open(_DEBUG_LOG, 'a', encoding='utf-8') as _f:
            _f.write(_time.strftime('%H:%M:%S') + ' ' + str(msg) + '\n')
    except:
        pass

def _load_prefs():
    try:
        with open(_PREFS_FILE, 'r', encoding='utf-8') as _f:
            return _json.load(_f)
    except:
        return {}

def _save_prefs(prefs):
    try:
        with open(_PREFS_FILE, 'w', encoding='utf-8') as _f:
            _json.dump(prefs, _f, indent=2)
    except:
        pass


# ---------------------------------------------------------------------------
# Carte "chant -> tenons crees dessus", persistee sur disque pour retrouver
# quels tenons supprimer quand on cible un chant specifique (fonction
# "Supprimer les tenons des chants selectionnes"), meme d'une session Fusion
# a l'autre. Cle = composant + signature geometrique du chant (meme logique
# que le cache de selection _sel_faces_cache).
# ---------------------------------------------------------------------------
def _load_face_map():
    try:
        with open(_FACE_MAP_FILE, 'r', encoding='utf-8') as _f:
            return _json.load(_f)
    except:
        return {}

def _save_face_map(m):
    try:
        with open(_FACE_MAP_FILE, 'w', encoding='utf-8') as _f:
            _json.dump(m, _f, indent=2)
    except:
        pass

def _face_map_key(comp, face):
    # NB: on ne peut pas utiliser _face_signature (normal + origin) ici :
    # une fois les tenons crees, Fusion decoupe le chant d'origine en
    # plusieurs petites faces (les zones entre/autour des tenons), chacune
    # avec un point d'origine (parametrique) different, alors qu'elles
    # restent toutes dans le MEME plan infini que le chant d'origine. On
    # identifie donc le plan par sa normale + sa distance a l'origine du
    # monde (n . P), qui est identique pour n'importe quel morceau de ce
    # plan - ainsi selectionner n'importe quel fragment du chant retrouve
    # bien les tenons crees dessus.
    n = face.geometry.normal
    o = face.geometry.origin
    offset = o.x*n.x + o.y*n.y + o.z*n.z
    return comp.entityToken + '|' + ','.join(
        str(round(v, 4)) for v in (n.x, n.y, n.z, offset))

# Marque posee sur la FACE du chant elle-meme (attribut Fusion) a la
# creation du tenon, valeur = cle de tenon_face_map.json. Verifie en direct
# (2026-10-06, TENON CNC, Deplacer3 sur Corps18) : un attribut pose sur une
# face AVANT un Deplacer insere plus tot dans la chronologie se retrouve sur
# la meme face, a sa nouvelle position. 'Mettre a jour CNC' retrouve ainsi le
# chant quel que soit le deplacement (translation OU rotation), la ou la
# recherche par plan absolu (spec['plane']) echoue des que le corps tourne.
_CHANT_ATTR_GROUP = 'TenonCNC'
_CHANT_ATTR_NAME = 'chant_key'


def _tag_chant_face(face, key):
    if face is None or not key:
        return
    try:
        face.attributes.add(_CHANT_ATTR_GROUP, _CHANT_ATTR_NAME, key)
    except Exception as ex:
        _dbg(f'_tag_chant_face: echec ({ex})')


def _find_tagged_chant(design, key):
    """Face plane la plus grande portant la marque `key` (None si aucune).
    Plusieurs fragments peuvent la porter tant que les tenons sont en place
    (le chant est decoupe par le bossage) : la plus grande suffit pour
    retrouver le corps et le plan courant du chant."""
    if not key:
        return None
    try:
        attrs = design.findAttributes(_CHANT_ATTR_GROUP, _CHANT_ATTR_NAME)
    except Exception:
        return None
    best = None
    best_area = 0.0
    for a in attrs:
        try:
            if a.value != key:
                continue
            f = adsk.fusion.BRepFace.cast(a.parent)
            if f is None or not f.isValid:
                continue
            if f.geometry.surfaceType != adsk.core.SurfaceTypes.PlaneSurfaceType:
                continue
            if f.area > best_area:
                best = f; best_area = f.area
        except Exception:
            continue
    return best


def _face_plane(face):
    n = face.geometry.normal; o = face.geometry.origin
    return [round(n.x, 6), round(n.y, 6), round(n.z, 6),
            round(o.x*n.x + o.y*n.y + o.z*n.z, 6)]


# Signature du chant (plan + boite englobante de la plus grande face
# marquee, tenon en place) enregistree apres chaque recreation : si elle n'a
# pas bouge, Mettre a jour CNC laisse le tenon tel quel. Le plan seul ne
# suffit pas (un corps glisse dans le plan de son chant garde le meme plan).
_CHANT_SIG_TOL = 1e-4  # cm


def _chant_sig(face):
    if face is None:
        return None
    bb = face.boundingBox
    return _face_plane(face) + [round(v, 5) for v in (
        bb.minPoint.x, bb.minPoint.y, bb.minPoint.z,
        bb.maxPoint.x, bb.maxPoint.y, bb.maxPoint.z)]


def _chant_unchanged(face, spec):
    old = spec.get('chant_sig')
    if not old:
        return False
    try:
        cur = _chant_sig(face)
    except Exception:
        return False
    return cur is not None and len(cur) == len(old) and \
        all(abs(a - b) <= _CHANT_SIG_TOL for a, b in zip(cur, old))


# Cles des chants portees par les features de tenon elles-memes
# (CombineFeature 'Tenon' du format groupe, extrusions 'Tenon' recreees par
# 'Mettre a jour CNC'). Quand l'utilisateur supprime le tenon dans
# l'historique, la marque disparait avec la feature : recreate_all_tenons
# sait alors que ce chant n'a plus de tenon et ne le fait pas reapparaitre
# (bug signale le 2026-10-06 : tenon supprime recree par la mise a jour).
_KEYS_ATTR_NAME = 'keys'


def _tag_feature_keys(feat, keys):
    if feat is None or not keys:
        return
    try:
        old = feat.attributes.itemByName(_CHANT_ATTR_GROUP, _KEYS_ATTR_NAME)
        cur = _json.loads(old.value) if old is not None and old.value else []
        for k in keys:
            if k and k not in cur:
                cur.append(k)
        feat.attributes.add(_CHANT_ATTR_GROUP, _KEYS_ATTR_NAME, _json.dumps(cur))
    except Exception as ex:
        _dbg(f'_tag_feature_keys: echec ({ex})')


def _keys_on_live_features(design):
    keys = set()
    try:
        attrs = design.findAttributes(_CHANT_ATTR_GROUP, _KEYS_ATTR_NAME)
    except Exception:
        return keys
    for a in attrs:
        try:
            p = a.parent
            if p is None or not p.isValid:
                continue
            if getattr(p, 'isSuppressed', False):
                continue
            keys.update(_json.loads(a.value or '[]'))
        except Exception:
            continue
    return keys


def _sketch_tenon_keys(design):
    """Cles portees UNIQUEMENT par des fonctions en esquisse (extrusions
    'Tenon'), pas par un bossage fige (Combiner 'Tenon' + BaseFeature)."""
    sk, frozen = set(), set()
    try:
        attrs = design.findAttributes(_CHANT_ATTR_GROUP, _KEYS_ATTR_NAME)
    except Exception:
        return sk
    for a in attrs:
        try:
            p = a.parent
            if p is None or not p.isValid or getattr(p, 'isSuppressed', False):
                continue
            ks = _json.loads(a.value or '[]')
            if adsk.fusion.ExtrudeFeature.cast(p) is not None:
                sk.update(ks)
            else:
                frozen.update(ks)
        except Exception:
            continue
    return sk - frozen


def _old_format_present(body, planes, tol=1e-3):
    """Une esquisse 'Tenon'/'Languette' sur l'un de ces plans alimente-t-elle
    une extrusion qui touche `body` ? (tenons sans marque, ancien format)"""
    try:
        comp = body.parentComponent
        body_name = body.name
        names = set()
        for i in range(comp.sketches.count):
            sk = comp.sketches.item(i)
            if not (sk.name.startswith('Tenon') or sk.name.startswith('Languette')):
                continue
            pl = _sketch_plane_normal_offset(sk)
            if pl is not None and any(_planes_equal(pl, p, tol) for p in planes):
                names.add(sk.name)
        if not names:
            return False
        for i in range(comp.features.extrudeFeatures.count):
            ft = comp.features.extrudeFeatures.item(i)
            if not (ft.name.startswith('Tenon') or ft.name.startswith('Languette')):
                continue
            src = _extrude_source_sketch(ft)
            if getattr(src, 'name', None) not in names:
                continue
            try:
                if body_name in [b.name for b in ft.bodies]:
                    return True
            except Exception:
                continue
    except Exception:
        _dbg('_old_format_present EXCEPTION: ' + traceback.format_exc())
    return False


def _tenon_present(design, key, entry, body, live_keys, tagged=None):
    """Le tenon enregistre sous `key` existe-t-il encore dans CE design ?
    Ordre : marque 'keys' sur une feature vivante (fiable) ; sinon, pour
    les tenons crees avant cette marque : un token qui resout, la
    CombineFeature groupee du corps, ou l'ancien format esquisse+extrusion
    sur le plan du chant. Faux = tenon supprime de l'historique (ou cle d'un
    autre document) : 'Mettre a jour CNC' ne doit pas le recreer."""
    if key in live_keys:
        return True
    spec = _entry_spec(entry) or {}
    for t in _entry_tokens(entry):
        try:
            if design.findEntityByToken(t):
                return True
        except Exception:
            pass
    if spec.get('tracked'):
        # Cree apres l'ajout de la marque : son absence suffit.
        return False
    try:
        comp = body.parentComponent
        for feat in comp.features:
            try:
                if not isinstance(feat, adsk.fusion.CombineFeature):
                    continue
                if feat.name != 'Tenon' and not feat.name.startswith('Tenon ('):
                    continue
                a = feat.attributes.itemByName('TenonCNC', 'batch_body_name')
                if a is not None and a.value == body.name:
                    return True
            except Exception:
                continue
    except Exception:
        pass
    planes = [spec.get('plane') or [0, 0, 0, 0]]
    if tagged is not None:
        try:
            planes.append(_face_plane(tagged))
        except Exception:
            pass
    return _old_format_present(body, planes)


def _record_face_tenons(face, feat_tokens, sketch_tokens):
    """Enregistre, pour le chant donne, les tokens des features/sketches
    'Tenon' qui viennent d'y etre creees definitivement (appele uniquement
    depuis la creation reelle au clic sur "Creer", jamais depuis l'apercu).
    NB: prefer _record_face_tenons_by_key quand la cle a deja ete calculee
    AVANT la creation (voir _ExecuteHandler) - relire `face` APRES la
    creation peut echouer silencieusement si le chant a ete decoupe."""
    if not feat_tokens and not sketch_tokens:
        return
    try:
        comp = face.body.parentComponent
        key = _face_map_key(comp, face)
        _record_face_tenons_by_key(key, feat_tokens, sketch_tokens)
    except Exception as ex:
        _dbg(f'_record_face_tenons: erreur calcul cle (face invalidee ?): {ex}')


def _entry_tokens(entry):
    """L'entree d'une cle dans tenon_face_map.json a deux formats possibles :
    - ancien format (avant la fonctionnalite 'Mettre a jour CNC' pour les
      tenons) : simple liste de tokens ['tok1', 'tok2', ...].
    - nouveau format : {'tokens': [...], 'spec': {...}} ou 'spec' contient
      tout ce qu'il faut (mode, parametres, corps, plan) pour recreer ce
      chant de tenons/languette a l'identique plus tard (voir
      recreate_all_tenons). On accepte les deux pour ne pas casser les
      fichiers tenon_face_map.json existants."""
    if isinstance(entry, dict):
        return list(entry.get('tokens') or [])
    return list(entry or [])


def _entry_spec(entry):
    if isinstance(entry, dict):
        return entry.get('spec')
    return None


def _record_face_tenons_by_key(key, feat_tokens, sketch_tokens, spec=None):
    """Comme _record_face_tenons, mais a partir d'une cle deja calculee
    AVANT la creation des tenons. Indispensable : une fois les tenons
    crees (extrusion), l'objet BRepFace d'origine est souvent invalide
    (le chant a ete decoupe en plusieurs fragments) et le relire
    (face.geometry, face.body...) echoue alors silencieusement, ce qui
    laissait tenon_face_map.json vide malgre une creation reussie.

    `spec`, quand fourni (creation reelle depuis la boite de dialogue),
    enregistre le mode + les parametres + le corps + le plan du chant afin
    que 'Mettre a jour CNC' puisse plus tard supprimer et recreer ce tenon
    a la position courante du modele (voir recreate_all_tenons) - la seule
    methode fiable trouvee : les courbes de contour ajoutees par
    sketches.add(face)/project(face) ne sont PAS des references vivantes
    dans ce fichier (confirme empiriquement : deplacer le corps ne deplace
    pas ces courbes), donc aucun jeu de contraintes ne peut les rendre
    associatives - il faut les recreer entierement."""
    if not key or (not feat_tokens and not sketch_tokens):
        return
    try:
        m = _load_face_map()
        old = m.get(key)
        toks = _entry_tokens(old)
        toks.extend(feat_tokens or [])
        toks.extend(sketch_tokens or [])
        new_spec = spec if spec is not None else _entry_spec(old)
        if new_spec is not None:
            m[key] = {'tokens': toks, 'spec': new_spec}
        else:
            m[key] = toks
        _save_face_map(m)
    except Exception as ex:
        _dbg(f'_record_face_tenons_by_key: erreur sauvegarde: {ex}')

def _delete_tenons_for_face_keys(design, keys, keep_spec=False):
    """Supprime UNIQUEMENT les tenons associes aux cles de chants donnees
    (voir _face_map_key), en s'appuyant sur les tokens exacts enregistres a
    la creation. Ne touche a rien d'autre.

    Si keep_spec=True, la cle n'est pas totalement effacee de la carte :
    son 'spec' (parametres de recreation) est conserve mais vide de
    tokens - utilise par recreate_all_tenons qui doit supprimer puis
    recreer sous la MEME cle avec les memes parametres."""
    m = _load_face_map()
    deleted = 0
    errors = []
    for key in keys:
        old = m.pop(key, None)
        spec = _entry_spec(old)
        toks = _entry_tokens(old)
        if keep_spec and spec is not None:
            m[key] = {'tokens': [], 'spec': spec}
        ents = []
        for tok in toks:
            try:
                found = design.findEntityByToken(tok)
                if found: ents.append(found[0])
            except Exception as ex:
                errors.append(str(ex))
        feats = [e for e in ents if isinstance(e, adsk.fusion.Feature)]
        sks   = [e for e in ents if isinstance(e, adsk.fusion.Sketch)]
        for f in feats:
            try:
                f_tok = f.entityToken
                f.deleteMe()
                # Fusion peut parfois refuser une suppression SANS lever
                # d'exception (ex. dependances croisees entre plusieurs
                # tenons du meme corps) - on verifie que l'entite a
                # vraiment disparu, sinon 'Mettre a jour CNC' recreerait un
                # doublon a cote de l'ancienne feature encore presente
                # (confirme : c'est exactement ce qui s'est produit).
                still = design.findEntityByToken(f_tok)
                if still:
                    errors.append(f'suppression feature ignoree (cle {key[:12]}...)')
                else:
                    deleted += 1
            except Exception as ex: errors.append(str(ex))
        for s in sks:
            try:
                s_tok = s.entityToken
                s.deleteMe()
                still = design.findEntityByToken(s_tok)
                if still:
                    errors.append(f'suppression esquisse ignoree (cle {key[:12]}...)')
                else:
                    deleted += 1
            except Exception as ex: errors.append(str(ex))
    _save_face_map(m)
    return deleted, errors


def _pop_face_map_keys(keys):
    """Retire simplement les cles donnees de tenon_face_map.json, SANS
    toucher aux features/esquisses Fusion elles-memes - a utiliser quand le
    corps entier va de toute facon etre supprime juste apres (voir
    annuler_tenon_cnc_pour_corps) : le/les tenon(s) faisant partie
    integrante de ce corps, ils disparaissent automatiquement avec lui,
    inutile (et redondant) de les supprimer un par un via
    _delete_tenons_for_face_keys avant. On nettoie seulement le fichier de
    suivi pour ne pas laisser de cles orphelines pointant vers un corps
    disparu."""
    m = _load_face_map()
    n = 0
    for key in keys:
        if m.pop(key, None) is not None:
            n += 1
    if n:
        _save_face_map(m)
    return n


# ---------------------------------------------------------------------------
# "Annuler tenon CNC" : remplace l'ancienne commande "Suppr. Tenons chants"
# (qui demandait de reselectionner precisement chaque chant). Ici on
# selectionne directement le CORPS qui porte le/les tenon(s) a annuler, et
# la commande supprime en cascade :
#   1) le jeu de fonctionnement (Marge CNC) applique sur le(s) corps
#      "femelle(s)" concerne(s), s'il y en a un - EN PREMIER, car il
#      reference les parois de la mortaise (le supprimer apres la mortaise
#      casserait ses faces decalees - meme cascade Combiner1/DecalerLesFaces
#      deja observee ailleurs dans cette session) ;
#   2) la ou les mortaise(s) creusee(s) dans CES AUTRES corps pour ce
#      tenon - jamais le corps femelle lui-meme (seule la feature de
#      decoupe/Combiner est supprimee, ce qui restaure le corps femelle a
#      son etat plein) ;
#   3) le(s) tenon(s)/languette(s) sur le corps selectionne.
# Les mortaises/jeux sont retrouves directement via les attributs Fusion
# poses par Mortaise CNC / Marge CNC (memes attributs que
# MortaiseCNC.find_all_mortaise_features) : pas besoin que ces add-ins
# soient charges, on relit juste les memes attributs sur le document.
# ---------------------------------------------------------------------------

def _face_map_keys_for_body(design, body_token):
    """Retrouve, dans tenon_face_map.json, toutes les cles de chants dont
    les tenons/languettes ont ete crees sur le corps `body_token` (voir
    _face_map_key) - permet a 'Annuler tenon CNC' de tout retrouver a
    partir d'un seul corps selectionne, meme si ce corps porte des tenons
    sur plusieurs chants differents.

    Entrees recentes (avec 'spec') : comparaison directe via
    spec['body_token']. Entrees heritees (avant le suivi des parametres,
    simple liste de tokens sans spec) : on resout la feature d'extrusion
    enregistree et on lit le corps qu'elle a produit - meme methode que
    _backfill_spec_for_key."""
    m = _load_face_map()
    keys = []
    for key, entry in m.items():
        spec = _entry_spec(entry)
        if spec is not None:
            if spec.get('body_token') == body_token:
                keys.append(key)
            continue
        for tok in _entry_tokens(entry):
            try:
                found = design.findEntityByToken(tok)
            except Exception:
                found = None
            if not found:
                continue
            ent = found[0]
            if not isinstance(ent, adsk.fusion.Feature):
                continue
            try:
                bodies = ent.bodies
                b = bodies.item(0) if bodies and bodies.count else None
            except Exception:
                b = None
            if b is not None and b.entityToken == body_token:
                keys.append(key)
                break
    return keys


def _find_mortaise_features_for_male_body(design, body_token):
    """Retrouve les features de decoupe Mortaise CNC dont le 'male_token'
    (le corps porteur du tenon) correspond au corps donne - meme lecture
    d'attributs que MortaiseCNC.find_all_mortaise_features, faite ici
    directement pour ne pas dependre du module MortaiseCNC etre charge.
    Retourne [(feature, female_token), ...]."""
    out = []
    try:
        attrs = design.findAttributes('MortaiseCNC', 'male_token')
    except Exception:
        attrs = []
    for a in attrs:
        try:
            if a.value != body_token:
                continue
            feat = a.parent
            female_tok = None
            fem_attr = feat.attributes.itemByName('MortaiseCNC', 'female_token')
            if fem_attr:
                female_tok = fem_attr.value
            out.append((feat, female_tok))
        except Exception:
            continue
    return out


def _find_marge_features_for_body(design, body_token):
    """Retrouve les features Marge CNC (jeu de fonctionnement) appliquees
    sur le corps donne, via l'attribut 'selected_body_tokens' (liste de
    tokens separes par des virgules, voir MargeCNC.py)."""
    out = []
    try:
        attrs = design.findAttributes('MargeCNC', 'jeu_cm')
    except Exception:
        attrs = []
    for a in attrs:
        try:
            feat = a.parent
            sel_attr = feat.attributes.itemByName('MargeCNC', 'selected_body_tokens')
            toks = [t for t in (sel_attr.value.split(',') if sel_attr and sel_attr.value else []) if t]
            if body_token in toks:
                out.append(feat)
        except Exception:
            continue
    return out


def _find_module(short_name):
    """Retrouve un module d'add-in deja charge par Fusion dans cette
    session, quelle que soit la maniere dont il a ete charge (meme
    technique que MiseAJourCNC.py : chargement natif Fusion -> cle
    'mangled' se terminant par '<NomAddin>_py' ; rechargement manuel ->
    cle exacte). Utilise pour appeler MargeCNC.apply_jeu sans dependre
    d'un import direct (add-ins independants, l'un peut etre inactif)."""
    mod = sys.modules.get(short_name)
    if mod is not None:
        return mod
    suffix = short_name + '_py'
    for k, m in list(sys.modules.items()):
        if k.endswith(suffix):
            return m
    return None


def _load_mortaise_records_shared():
    try:
        with open(_MORTAISE_FACE_MAP_FILE, 'r', encoding='utf-8') as f:
            return _json.load(f)
    except Exception:
        return []


def _save_mortaise_records_shared(records):
    try:
        with open(_MORTAISE_FACE_MAP_FILE, 'w', encoding='utf-8') as f:
            _json.dump(records, f, indent=2)
    except Exception:
        pass


def _pop_mortaise_record(male_token, female_token):
    """Retire (et retourne) l'enregistrement mortaise_face_map.json
    correspondant EXACTEMENT a cette paire (male_token, female_token) -
    granularite indispensable : un meme corps femelle peut recevoir
    PLUSIEURS mortaises de tenons/corps males DIFFERENTS, chacune avec son
    propre enregistrement {male_token, female_token, face_tokens}. Annuler
    un seul tenon ne doit retirer QUE les faces de CETTE mortaise precise
    du fichier partage - jamais toutes celles du corps femelle, qui
    peuvent appartenir a d'autres mortaises encore bien presentes (bug
    signale : "ca supprime encore certain jeu de mortaise encore
    presente" - une precedente version raisonnait par CORPS entier plutot
    que par mortaise precise, ce qui coupait aussi le jeu de mortaises non
    concernees des qu'elles partageaient le meme corps femelle)."""
    records = _load_mortaise_records_shared()
    kept = []
    popped = None
    for rec in records:
        if (popped is None and rec.get('male_token') == male_token
                and rec.get('female_token') == female_token):
            popped = rec
            continue
        kept.append(rec)
    if popped is not None:
        _save_mortaise_records_shared(kept)
    return popped


def _capture_and_delete_marge_feature(feat):
    """Capture (jeu_cm, selected_body_tokens) puis SUPPRIME une feature de
    jeu de fonctionnement (Marge CNC), SANS la recreer immediatement.

    Cette capture doit avoir lieu AVANT la suppression de la/les mortaise(s)
    annulee(s) - mais la RECREATION (voir _recreate_marge_feature) doit elle
    avoir lieu APRES, une fois que la cavite de la mortaise annulee a
    reellement disparu de la geometrie. Sinon, la re-detection geometrique
    de secours de MargeCNC.apply_jeu (_chant_faces_heuristique, qui ne lit
    pas le fichier partage et repere toute face de chant non suivie sur un
    corps selectionne) peut re-inclure la cavite tout juste annulee alors
    meme que son enregistrement JSON precis a deja ete retire - c'est cette
    fenetre temporelle qui causait le probleme 'trop large' rapporte.

    Retourne un dict {'jeu': float|None, 'tokens': [str,...], 'erreur': str|None}."""
    try:
        jeu_attr = feat.attributes.itemByName('MargeCNC', 'jeu_cm')
        jeu = float(jeu_attr.value) if jeu_attr else None
    except Exception:
        jeu = None
    try:
        sel_attr = feat.attributes.itemByName('MargeCNC', 'selected_body_tokens')
        all_toks = [t for t in (sel_attr.value.split(',') if sel_attr and sel_attr.value else []) if t]
    except Exception:
        all_toks = []
    try:
        feat.deleteMe()
    except Exception:
        return {'jeu': jeu, 'tokens': all_toks,
                'erreur': 'suppression jeu: ' + traceback.format_exc().strip().splitlines()[-1]}
    return {'jeu': jeu, 'tokens': all_toks, 'erreur': None}


def _recreate_marge_feature(design, root, jeu, all_toks):
    """Recree une feature de jeu de fonctionnement a partir des donnees
    capturees par _capture_and_delete_marge_feature - a appeler UNIQUEMENT
    une fois que la/les mortaise(s) annulee(s) correspondante(s) ont deja
    ete physiquement supprimees du modele (plus seulement du fichier
    partage), pour que la re-detection geometrique de secours de
    MargeCNC.apply_jeu ne puisse plus re-inclure leur cavite.

    Retourne (statut, message) avec statut dans
    {'reduit', 'supprime', 'erreur'}."""
    if not all_toks:
        return 'supprime', 'jeu supprime (aucun corps enregistre sur cette feature)'
    if jeu is None:
        return 'erreur', 'jeu supprime mais NON recree : valeur de jeu (jeu_cm) illisible'
    MargeCNC = _find_module('MargeCNC')
    if MargeCNC is None:
        return 'erreur', 'jeu supprime mais NON recree : add-in Marge CNC non actif'
    selected_bodies = []
    for t in all_toks:
        try:
            found = design.findEntityByToken(t)
            b = adsk.fusion.BRepBody.cast(found[0]) if found else None
        except Exception:
            b = None
        if b:
            selected_bodies.append(b)
    if not selected_bodies:
        return 'supprime', 'jeu supprime (corps introuvables)'
    try:
        new_feat, n_m, n_h, _faces = MargeCNC.apply_jeu(
            design, root, set(all_toks), selected_bodies, jeu, True)
    except Exception:
        return 'erreur', 'recreation jeu EXCEPTION: ' + traceback.format_exc().strip().splitlines()[-1]
    if new_feat:
        return 'reduit', f'jeu recree sur {len(selected_bodies)} corps (mortaise annulee exclue)'
    return 'supprime', 'jeu supprime (plus aucune face a decaler pour ces corps)'


def _retirer_occurrence(occ):
    """Reproduit l'action 'Retirer' du clic droit sur un composant dans
    l'arbre Fusion, pour l'OCCURRENCE donnee (resolue par l'appelant via
    body.assemblyContext - voir annuler_tenon_cnc_pour_corps) : supprime
    cette occurrence de l'assemblage (et donc le composant lui-meme s'il
    n'a plus d'autre occurrence).

    Volontairement LIMITE a l'occurrence : ne supprime jamais le corps
    lui-meme (pas de body.deleteMe()). Sur ce modele, plusieurs corps
    peuvent partager une seule feature d'origine (plusieurs planches
    issues d'une meme extrusion multi-corps) ; supprimer un corps de cette
    facon peut entrainer Fusion a supprimer la feature entiere, donc TOUS
    les corps qui en dependent (deja provoque la suppression complete du
    'FOND' du canape avec tout ce qu'il contenait). Retirer l'occurrence
    est une operation d'assemblage scopee, sans ce risque de cascade.
    Constat empirique assume comme compromis : si le corps natif est
    partage, il peut rester visible ailleurs (ex. dans le composant de
    base) meme apres ce retrait - prefere a une suppression plus large et
    dangereuse."""
    if occ is None:
        _dbg('_retirer_occurrence: occ=None (corps dans le composant racine) - rien a retirer')
        return False, "corps directement dans le composant racine - rien a retirer"
    nom = occ.name
    try:
        occ_tok = occ.entityToken
    except Exception:
        occ_tok = None
    try:
        occ.deleteMe()
    except Exception:
        _dbg(f"_retirer_occurrence: occ.deleteMe() EXCEPTION sur '{nom}': " + traceback.format_exc())
        return False, 'retrait composant EXCEPTION: ' + traceback.format_exc().strip().splitlines()[-1]
    # Fusion peut parfois refuser une suppression SANS lever d'exception
    # (meme constat deja fait ailleurs dans ce fichier pour les features
    # Tenon/Languette - ex. l'occurrence est referencee par une feature
    # 'Reorganiser'/ArrangeFeature de nesting CNC plus loin dans la
    # chronologie) : on verifie donc que l'occurrence a REELLEMENT disparu
    # avant d'annoncer un succes.
    still = None
    if occ_tok is not None:
        try:
            app_ = adsk.core.Application.get()
            design = adsk.fusion.Design.cast(app_.activeProduct)
            still = design.findEntityByToken(occ_tok)
        except Exception:
            still = None
    if still:
        _dbg(f"_retirer_occurrence: '{nom}' TOUJOURS PRESENT apres deleteMe() (refuse silencieusement, "
             f"probablement reference ailleurs - ex. feature Reorganiser/nesting)")
        return False, (f"composant '{nom}' NON retire : Fusion a refuse la suppression sans erreur "
                        "(probablement encore reference ailleurs, ex. imbrication CNC/Reorganiser)")
    _dbg(f"_retirer_occurrence: '{nom}' retire avec succes")
    return True, f"composant '{nom}' retire"


def annuler_tenon_cnc_pour_corps(design, body):
    """Coeur de la commande 'Annuler tenon CNC' pour UN corps selectionne
    (celui qui porte le/les tenon(s)) :
    1) retire du fichier partage mortaise_face_map.json UNIQUEMENT le(s)
       enregistrement(s) de LA/LES mortaise(s) precise(s) liee(s) a ce
       corps (voir _pop_mortaise_record - jamais tout le corps femelle) ;
    2) supprime (capture jeu+corps au passage) chaque feature de jeu de
       fonctionnement concernee, SANS encore la recreer ;
    3) supprime la/les mortaise(s) sur le(s) corps femelle(s) (jamais ces
       corps eux-memes) - a ce stade la cavite de la mortaise annulee a
       donc REELLEMENT disparu du modele, pas seulement du JSON ;
    4) RECREE chaque feature de jeu capturee a l'etape 2, maintenant que la
       re-detection geometrique de secours de MargeCNC.apply_jeu ne peut
       plus re-inclure la cavite tout juste supprimee (c'est cet ordre -
       jeu supprime puis mortaise supprimee puis jeu recree - qui evite le
       probleme 'trop large' : recreer le jeu AVANT de supprimer la
       mortaise laissait sa cavite encore presente physiquement, et la
       recreation la reprenait quand meme) ;
    5) supprime le/les tenon(s) sur le corps selectionne (feature(s)
       precisement retrouvee(s) via leurs tokens enregistres - jamais tout
       le corps) ;
    6) 'retire' (voir _retirer_occurrence) UNIQUEMENT le composant/
       l'occurrence du corps selectionne lui-meme - demande explicitement
       par l'utilisateur, equivalent au clic droit > Retirer dans l'arbre
       Fusion.

    IMPORTANT (suite a un incident reel) : on ne supprime JAMAIS le corps
    via body.deleteMe(). Sur ce modele, plusieurs corps peuvent partager
    une meme feature d'origine (plusieurs planches issues d'une seule
    extrusion multi-corps) ; supprimer un corps de cette facon peut alors
    entrainer Fusion a supprimer la feature entiere, et donc TOUS les
    corps/composants qui en dependent (deja provoque la suppression
    complete du 'FOND' du canape avec tout ce qu'il contenait). On se
    limite donc strictement a retirer l'OCCURRENCE selectionnee (equivalent
    exact du clic droit > Retirer), qui est une operation d'assemblage
    scopee et sans risque de cascade sur d'autres corps. Si le corps
    natif reste malgre tout visible ailleurs (ex. dans le composant de
    base, cas deja observe quand la geometrie est partagee), c'est un
    compromis assume au profit de la securite du modele.
    Retourne un dict de compteurs + liste d'erreurs."""
    root = design.rootComponent
    body_token = body.entityToken
    result = {'tenons_supprimes': 0, 'mortaises_supprimees': 0,
              'jeux_supprimes': 0, 'jeux_reduits': 0,
              'composant_retire': None, 'erreurs': []}
    mortaise_hits = _find_mortaise_features_for_male_body(design, body_token)
    female_tokens = {ft for _feat, ft in mortaise_hits if ft}
    # 1) Retire du fichier partage les enregistrements PRECIS (male_token,
    # female_token) concernes - AVANT de toucher au jeu, pour que sa
    # future recreation ne resolve plus ces faces precises tout en gardant
    # celles des autres mortaises (meme corps femelle inclus).
    for ftok in female_tokens:
        _pop_mortaise_record(body_token, ftok)
    # 2) Jeu de fonctionnement : supprime chaque feature Marge CNC
    # concernee en capturant (jeu, corps) pour la recreer PLUS TARD, une
    # fois la mortaise annulee reellement supprimee du modele (etape 4).
    marge_feats_by_token = {}
    for ftok in female_tokens:
        for feat in _find_marge_features_for_body(design, ftok):
            try:
                marge_feats_by_token[feat.entityToken] = feat
            except Exception:
                pass
    marge_captures = []
    for feat in marge_feats_by_token.values():
        capture = _capture_and_delete_marge_feature(feat)
        if capture['erreur']:
            result['erreurs'].append(capture['erreur'])
        else:
            marge_captures.append(capture)
    # 3) Mortaise(s) - jamais le corps femelle lui-meme. A ce stade, la
    # cavite de la mortaise annulee disparait REELLEMENT de la geometrie.
    for feat, _ftok in mortaise_hits:
        try:
            feat.deleteMe()
            result['mortaises_supprimees'] += 1
        except Exception:
            result['erreurs'].append(
                'suppression mortaise: ' + traceback.format_exc().strip().splitlines()[-1])
    # 4) Recree maintenant chaque feature de jeu capturee a l'etape 2 - la
    # cavite annulee etant desormais absente du modele (pas seulement du
    # JSON), la re-detection geometrique de secours de MargeCNC.apply_jeu
    # ne peut plus la re-inclure a tort.
    for capture in marge_captures:
        status, msg = _recreate_marge_feature(design, root, capture['jeu'], capture['tokens'])
        if status == 'reduit':
            result['jeux_reduits'] += 1
        elif status == 'supprime':
            result['jeux_supprimes'] += 1
        elif status == 'erreur':
            result['erreurs'].append(msg)
    # 5) Tenon(s)/languette(s) sur le corps selectionne - suppression
    # PRECISE via les tokens de feature enregistres (jamais le corps
    # entier - voir la note de securite ci-dessus).
    keys = _face_map_keys_for_body(design, body_token)
    if keys:
        deleted, errs = _delete_tenons_for_face_keys(design, keys)
        result['tenons_supprimes'] += deleted
        result['erreurs'].extend(errs)
    # 6) Retire UNIQUEMENT le composant/l'occurrence du corps selectionne
    # (clic droit > Retirer) - jamais le corps lui-meme (body.deleteMe()
    # est volontairement evite, voir note de securite ci-dessus).
    try:
        occ = body.assemblyContext
    except Exception:
        occ = None
    ok, msg = _retirer_occurrence(occ)
    if ok:
        result['composant_retire'] = msg
    elif 'rien a retirer' not in msg:
        result['erreurs'].append(msg)
    return result


# ---------------------------------------------------------------------------
# "Mettre a jour CNC" pour les tenons/languettes : supprimer et RECREER (et
# non pas essayer de les rendre associatifs par des contraintes d'esquisse).
#
# Constat empirique (verifie en direct dans le fichier de l'utilisateur, a la
# fois en deplacant un corps via une fonction Deplacer inseree AVANT les
# esquisses "Tenon" dans l'historique, et avec un sk.project(face) explicite
# fraichement cree) : les courbes de contour ajoutees dans une esquisse par
# sketches.add(face)/project(face) ne sont PAS des references vivantes vers
# la face - ce sont des coordonnees figees au moment de la creation. Aucune
# contrainte geometrique ajoutee dans l'esquisse (colineaire, distance, etc.)
# ne peut donc rendre un tenon "associatif" a un changement de parametre :
# tout le paquet (contour + tenon ancre dessus) reste fige en bloc.
#
# La seule methode fiable, deja utilisee et verifiee pour Mortaise CNC /
# Marge CNC via "Mettre a jour CNC" : supprimer les features existantes et
# les RECREER a partir des parametres d'origine, sur la geometrie courante
# du modele. C'est ce que fait recreate_all_tenons ci-dessous.
# ---------------------------------------------------------------------------

def _find_face_by_plane(body, n, offset, tol=1e-3):
    """Cherche, parmi les faces planes d'un corps, celle dont le plan
    (normale + distance a l'origine) correspond a (n, offset). Si plusieurs
    fragments coplanaires existent (chant deja redecoupe), on prend le plus
    grand (le plus proche du chant complet, utile pour re-selectionner une
    base propre avant de recreer les tenons dessus)."""
    best = None
    best_area = 0.0
    for face in body.faces:
        try:
            geom = face.geometry
            if geom.surfaceType != adsk.core.SurfaceTypes.PlaneSurfaceType:
                continue
            fn = geom.normal; fo = geom.origin
            foffset = fo.x*fn.x + fo.y*fn.y + fo.z*fn.z
            # Tolerant au signe (voir _planes_equal) : une face d'un
            # composant derive/miroir peut exposer sa normale sortante
            # avec un signe oppose a celle enregistree dans le spec pour
            # ce qui est geometriquement le meme plan.
            if _planes_equal((fn.x, fn.y, fn.z, foffset), (n[0], n[1], n[2], offset), tol):
                if face.area > best_area:
                    best = face; best_area = face.area
        except Exception:
            continue
    return best


def _body_extent_along_normal(body, n):
    """Etendue (min, max) de la bounding box du corps le long de la
    direction `n` (produit scalaire de chaque coin de la bounding box avec
    `n`). Sert de repli quand la position absolue d'un chant a change de
    facon importante (voir _find_face_by_plane_resized) - typiquement un
    changement de CONFIGURATION PARAMETRIQUE Fusion (le canape existe en
    plusieurs longueurs - 1100/2400/2800mm - selectionnees via une table de
    configuration : changer de configuration redimensionne les panneaux, ce
    qui deplace radicalement les chants d'extremite bien au-dela de la
    tolerance de _find_face_by_plane, contrairement a un simple leger
    decalage du a une recreation de mortaise)."""
    bb = body.boundingBox
    xs = (bb.minPoint.x, bb.maxPoint.x)
    ys = (bb.minPoint.y, bb.maxPoint.y)
    zs = (bb.minPoint.z, bb.maxPoint.z)
    vals = [n[0] * x + n[1] * y + n[2] * z for x in xs for y in ys for z in zs]
    return min(vals), max(vals)


def _classify_extreme(body, n, offset):
    """A la creation d'un tenon, indique si son plan (normale `n`, distance
    `offset`) correspond a l'extremite MIN ou MAX du corps le long de cette
    normale (typiquement : le chant est un bout de planche). Retourne None
    si le plan n'est pas clairement pres d'une extremite (chant interieur,
    rainure...) - dans ce cas on ne memorise aucun indice de repli plutot
    que de risquer un mauvais accrochage plus tard."""
    try:
        lo, hi = _body_extent_along_normal(body, n)
    except Exception:
        return None
    span = hi - lo
    if span < 1e-6:
        return None
    d_lo = abs(offset - lo)
    d_hi = abs(offset - hi)
    nearest, d_near = ('min', d_lo) if d_lo <= d_hi else ('max', d_hi)
    if d_near > 0.25 * span:
        return None
    return nearest


def _find_face_by_plane_resized(body, n, extreme, area_tol=0.05):
    """Repli pour _find_face_by_plane quand la correspondance exacte de
    plan echoue - typiquement apres un changement de CONFIGURATION
    PARAMETRIQUE (le panneau a change de longueur, donc l'offset absolu
    enregistre a la creation ne correspond plus a rien) plutot qu'un simple
    decalage mineur. On sait (voir _classify_extreme, memorise dans le
    spec a la creation) si ce chant etait a l'extremite MIN ou MAX du
    corps le long de cette normale. On recalcule l'extremite ACTUELLE du
    corps le long de cette meme normale (la nouvelle bounding box refletant
    la nouvelle configuration), puis on cherche, parmi les faces planes de
    meme normale, celle dont l'offset est le plus proche de cette nouvelle
    extremite - departagee par la plus grande aire pour eviter d'accrocher
    un petit fragment de tenon/mortaise voisin plutot que le vrai bord du
    panneau."""
    if extreme is None:
        return None
    try:
        lo, hi = _body_extent_along_normal(body, n)
    except Exception:
        return None
    target = lo if extreme == 'min' else hi
    candidates = []
    for face in body.faces:
        try:
            geom = face.geometry
            if geom.surfaceType != adsk.core.SurfaceTypes.PlaneSurfaceType:
                continue
            fn = geom.normal; fo = geom.origin
            if not (abs(fn.x - n[0]) < 1e-3 and abs(fn.y - n[1]) < 1e-3 and abs(fn.z - n[2]) < 1e-3):
                continue
            foffset = fo.x * fn.x + fo.y * fn.y + fo.z * fn.z
            candidates.append((abs(foffset - target), face.area, face))
        except Exception:
            continue
    if not candidates:
        return None
    min_dist = min(c[0] for c in candidates)
    close = [c for c in candidates if c[0] <= min_dist + area_tol]
    close.sort(key=lambda c: -c[1])
    return close[0][2]


def _sketch_plane_normal_offset(sk):
    """Normale + distance a l'origine du plan d'une esquisse, calcules a
    partir de xDirection/yDirection/origin (Sketch.referencePlane leve une
    exception tant que le design n'est pas rembobine - voir plus haut).
    Retourne None si illisible."""
    try:
        ox = sk.xDirection; oy = sk.yDirection; oo = sk.origin
        nx = ox.y*oy.z - ox.z*oy.y
        ny = ox.z*oy.x - ox.x*oy.z
        nz = ox.x*oy.y - ox.y*oy.x
        norm = math.sqrt(nx*nx+ny*ny+nz*nz) or 1.0
        nx, ny, nz = nx/norm, ny/norm, nz/norm
        offset = oo.x*nx + oo.y*ny + oo.z*nz
        return (nx, ny, nz, offset)
    except Exception:
        return None


def _planes_equal(p1, p2, tol=1e-3):
    """Compare deux plans (normale, offset) en tolerant une normale
    INVERSEE - (n, d) et (-n, -d) decrivent le MEME plan geometrique
    (x : n.x=d) mais ne sont pas egaux composante par composante. Constate
    empiriquement : le plan enregistre dans un spec (derive de
    face.geometry.normal, la normale SORTANTE canonique de la face) et le
    plan recalcule pour une esquisse candidate via _sketch_plane_normal_offset
    (produit vectoriel xDirection x yDirection, dont le signe depend de
    l'orientation locale des axes de l'esquisse, pas forcement alignee avec
    la normale sortante de la face) peuvent legitimement differer par ce
    signe pour un chant parfaitement valide - une comparaison stricte
    composante par composante rate alors la correspondance, ce qui fait
    croire a _delete_old_tenon_geometry_by_plane qu'AUCUNE ancienne
    geometrie n'existe (candidates vide, aucune erreur remontee) alors
    qu'elle existe bel et bien : la suppression est silencieusement
    sautee et un nouveau tenon est cree A COTE de l'ancien jamais
    supprime - doublon constate en conditions reelles sur un chant du
    fond (2 tenons devenus 4 apres 'Mettre a jour CNC'), sans le moindre
    message d'erreur puisque le code ne voyait la aucun probleme."""
    if p1 is None or p2 is None:
        return False
    same = all(abs(p1[j] - p2[j]) < tol for j in range(4))
    if same:
        return True
    return all(abs(p1[j] + p2[j]) < tol for j in range(4))


def _extrude_source_sketch(ft):
    """Retrouve l'esquisse source d'une extrusion via son/ses profil(s),
    sans dependre d'aucun entityToken enregistre au prealable.

    ATTENTION : hasattr() sur les objets proxy de l'API Fusion n'est PAS
    fiable pour distinguer un Profile unique d'un ObjectCollection de
    profils (ft.profile est un ObjectCollection des que l'extrusion utilise
    plusieurs profils - le cas normal de _create_tenons_on_face avec
    tenon_count>=2) : hasattr(prof, 'parentSketch') peut repondre True meme
    sur un ObjectCollection, et l'acces leve alors une exception, avalee
    par le try/except, faisant echouer TOUTE la fonction et renvoyer None -
    un tenon a plusieurs profils apparaissait alors, a tort, comme
    'orphelin' (esquisse saine confondue avec une esquisse sans extrusion),
    ce qui aurait pu la faire supprimer par erreur dans
    _delete_old_tenon_geometry_by_plane. On tente donc SYSTEMATIQUEMENT le
    chemin ObjectCollection (count/item(0)) EN PREMIER, avec son propre
    try/except independant, puis seulement en repli le Profile unique (cas
    _create_languette_on_face, un seul profil)."""
    try:
        prof = ft.profile
    except Exception:
        return None
    if prof is None:
        return None
    try:
        if prof.count:
            ps = getattr(prof.item(0), 'parentSketch', None)
            if ps is not None:
                return ps
    except Exception:
        pass
    try:
        ps = prof.parentSketch
        if ps is not None:
            return ps
    except Exception:
        pass
    return None


def _delete_old_tenon_geometry_by_plane(body, plane, tol=1e-3):
    """Supprime les esquisses/extrusions 'Tenon'/'Languette' existantes sur
    `body` dont le PLAN correspond a `plane`, retrouvees par GEOMETRIE
    (plan de l'esquisse + extrusion qui en consomme un profil) plutot que
    par entityToken enregistre dans tenon_face_map.json.

    Necessaire EN PLUS de _delete_tenons_for_face_keys (fondee sur les
    tokens) : constate empiriquement que 'Mettre a jour CNC' recree
    d'abord les mortaises puis les marges AVANT les tenons - ces etapes
    modifient (decoupe booleenne) les MEMES corps partages, ce qui peut
    invalider les entityToken de tenons deja enregistres au point de faire
    lever une VRAIE exception Fusion ('RuntimeError: 2 :
    InternalValidationError : targetObj') plutot qu'un simple
    'introuvable'. Dans ce cas _delete_tenons_for_face_keys abandonne par
    securite (pour ne pas risquer un doublon), ce qui laisse l'ancien
    tenon en place - provoquant soit un vrai doublon a la recreation
    suivante, soit (le chant restant fragmente par l'ancien bossage) un
    echec 'Chant trop court' puisque la face trouvee n'est plus que le
    fragment restant. Cette fonction retrouve la geometrie par sa position
    reelle, quel que soit l'etat des tokens.

    Ignore toute esquisse/extrusion dont l'extrusion associee affecte un
    AUTRE corps que `body` (deux corps peuvent partager exactement le
    meme plan - voir _face_map_key) ; supprime en revanche les esquisses
    'Tenon'/'Languette' orphelines (aucune extrusion du tout, ex. un echec
    'Aucun profil'/'Chant trop court' laisse derriere lui).

    IMPORTANT : l'appariement esquisse<->extrusion et corps<->extrusion se
    fait par NOM (sk.name / body.name), PAS par entityToken - constate
    empiriquement que comparer les entityToken de DEUX objets proxy Fusion
    obtenus par des chemins d'API differents pour la MEME entite (ex. un
    Sketch lu via comp.sketches.item(i) vs le MEME Sketch relu via
    extrude.profile.item(0).parentSketch) peut donner des chaines qui ne
    correspondent PAS, meme au sein d'un seul et meme appel de script - un
    tenon parfaitement sain (esquisse+extrusion valides) etait alors pris a
    tort pour une esquisse orpheline. Les noms Fusion ('Tenon', 'Tenon
    (1)', ...) sont uniques au sein d'un composant et fiables pour cet
    appariement ephemere (le temps d'un seul appel) ; l'entityToken reste
    utilise ailleurs (tenon_face_map.json) uniquement pour la verification
    APRES coup d'une suppression, de facon tolerante."""
    comp = body.parentComponent
    errors = []
    candidates = []
    for i in range(comp.sketches.count):
        sk = comp.sketches.item(i)
        if not (sk.name.startswith('Tenon') or sk.name.startswith('Languette')):
            continue
        pl = _sketch_plane_normal_offset(sk)
        if pl is None:
            continue
        if _planes_equal(pl, plane, tol):
            candidates.append(sk)
    if not candidates:
        return 0, errors

    cand_by_name = {sk.name: sk for sk in candidates}

    to_delete_extrudes = []
    to_delete_sketch_names = set()
    matched_names = set()
    body_name = getattr(body, 'name', None)
    for i in range(comp.features.extrudeFeatures.count):
        ft = comp.features.extrudeFeatures.item(i)
        if not (ft.name.startswith('Tenon') or ft.name.startswith('Languette')):
            continue
        src = _extrude_source_sketch(ft)
        src_name = getattr(src, 'name', None) if src is not None else None
        if src_name not in cand_by_name:
            continue
        matched_names.add(src_name)
        try:
            b_names = [b.name for b in ft.bodies]
        except Exception:
            b_names = []
        if body_name and body_name in b_names:
            to_delete_extrudes.append(ft)
            to_delete_sketch_names.add(src_name)
        # sinon : cette esquisse candidate alimente une extrusion sur un
        # AUTRE corps coplanaire - on n'y touche pas du tout.

    # esquisses candidates sans AUCUNE extrusion (orphelines) : a supprimer
    # aussi, sauf celles deja identifiees comme appartenant a un autre corps.
    for name in cand_by_name:
        if name in matched_names and name not in to_delete_sketch_names:
            continue
        to_delete_sketch_names.add(name)

    deleted = 0
    for ft in to_delete_extrudes:
        nm = ft.name
        try:
            ft.deleteMe()
            deleted += 1
        except Exception as ex:
            # IMPORTANT - HISTORIQUE : une exception ici NE VEUT PAS TOUJOURS
            # DIRE que la suppression a rate (voir plus haut : suppression
            # d'une feature ancienne forcant Fusion a recalculer des features
            # sans rapport, en aval, qui echouent temporairement). On a
            # essaye de "tolerer" cette exception (verifier ft.isValid, puis
            # une relecture par nom de comp.features) pour eviter d'abandonner
            # a tort une recreation reussie - mais CONSTATE EN CONDITIONS
            # REELLES (chant du fond passe de 2 a 4 tenons apres 'Mettre a
            # jour CNC') que CES DEUX verifications peuvent donner un FAUX
            # NEGATIF (repondre "supprime" alors que la feature existe
            # encore) juste apres ce genre d'exception - vraisemblablement
            # parce que l'etat interne de Fusion n'est pas encore stabilise
            # au moment du test. Un faux negatif ici est BEAUCOUP plus grave
            # qu'un faux positif : il fait CREER un doublon de geometrie
            # reelle et permanente dans le document, invisible tant qu'on ne
            # va pas compter les features un par un. On revient donc au
            # comportement prudent : toute exception est traitee comme un
            # VRAI echec de suppression (recreation annulee pour ce chant,
            # 'ancienne geometrie non supprimee proprement...') - quitte a
            # avoir plus souvent ce message la ou une simple attente/nouvel
            # essai suffirait, plutot que de risquer un doublon silencieux.
            errors.append(f'extrusion {nm}: {ex}')
    for name in to_delete_sketch_names:
        sk = cand_by_name.get(name)
        if sk is None:
            continue
        try:
            sk.deleteMe()
            deleted += 1
        except Exception as ex:
            # Meme raisonnement que ci-dessus pour les extrusions : on ne
            # tente plus de "rattraper" l'exception, par securite.
            errors.append(f'esquisse {name}: {ex}')
    return deleted, errors


def _delete_tenon_batch_for_body(body):
    """Equivalent de _delete_old_tenon_geometry_by_plane, mais pour le
    NOUVEAU format groupe PAR CORPS (voir _commit_tenon_bumps_for_body) :
    aucune esquisse/extrusion 'Tenon' individuelle a trouver ici (elles ont
    ete supprimees immediatement apres isolement du bossage, voir
    _create_tenon_bump_isolated) - a la place, une seule CombineFeature +
    une seule BaseFeature partagees PAR CORPS, retrouvees par NOM ('Tenon'/
    'Tenon (n)') ET par l'attribut ('TenonCNC','batch_body_name') pose a
    leur creation - PAS par le token enregistre dans tenon_face_map.json :
    meme precaution que _delete_old_tenon_geometry_by_plane (un token peut
    devenir invalide entre deux etapes de 'Mettre a jour CNC' qui modifient
    le MEME corps partage avant les tenons - mortaises/marges). Appelee
    systematiquement a cote de _delete_old_tenon_geometry_by_plane : l'une
    des deux ne trouve simplement rien a faire selon le format
    effectivement utilise pour ce corps (ancien ou groupe).

    Supprime d'abord la/les CombineFeature (restaure les corps-outils
    individuels qu'elle avait fusionnes), PUIS la/les BaseFeature
    correspondante(s) (qui supprime ces corps-outils restaures avec elle) -
    le corps revient a son etat d'avant les tenons, pret pour la
    recreation."""
    errors = []
    deleted = 0
    try:
        comp = body.parentComponent
        body_name = body.name
    except Exception:
        return 0, ['corps invalide (_delete_tenon_batch_for_body)']
    if not body_name:
        return 0, errors

    combine_feats_to_delete = []
    try:
        for feat in comp.features:
            try:
                if feat.name != 'Tenon' and not feat.name.startswith('Tenon ('):
                    continue
                if not isinstance(feat, adsk.fusion.CombineFeature):
                    continue
                attr = feat.attributes.itemByName('TenonCNC', 'batch_body_name')
                if attr is None or attr.value != body_name:
                    continue
                combine_feats_to_delete.append(feat)
            except Exception:
                continue
    except Exception as ex:
        errors.append(str(ex))
    for cf in combine_feats_to_delete:
        try:
            cf.deleteMe()
            deleted += 1
        except Exception as ex:
            errors.append(f'combine Tenon (groupe): {ex}')

    base_feats_to_delete = []
    try:
        for feat in comp.features.baseFeatures:
            try:
                attr = feat.attributes.itemByName('TenonCNC', 'batch_body_name')
                if attr is None or attr.value != body_name:
                    continue
                base_feats_to_delete.append(feat)
            except Exception:
                continue
    except Exception as ex:
        errors.append(str(ex))
    for bf in base_feats_to_delete:
        try:
            bf.deleteMe()
            deleted += 1
        except Exception as ex:
            errors.append(f'base Tenon (groupe): {ex}')
    return deleted, errors


def _resolve_body_from_spec(design, spec):
    """Retrouve le BRepBody d'un spec (voir tenon_face_map.json) via son
    body_token, ou par nom dans le composant (comp_token) si le corps a
    ete recree entierement depuis (token change).

    Repli supplementaire (design derive/"composant maitre") : dans cette
    conception, chaque planche (ex. "D (2)") vit dans son PROPRE composant
    du meme nom, lui-meme lie par une "Fonction de base derivee" a un
    composant "maitre" partage (ex. "DOS") qui contient la geometrie
    commune (extrusions, reseau, symetrie...). Constate empiriquement :
    quand on selectionne une face d'un tel corps derive, `face.body.
    parentComponent` peut renvoyer le composant MAITRE ("DOS", qui n'a
    lui-meme AUCUN corps propre - toute sa geometrie n'existe que via les
    copies derivees) plutot que le composant reellement proprietaire du
    corps affiche/edite ("D (2)"). Le `comp_token` enregistre a la creation
    pointe alors vers ce maitre, et la recherche par nom ci-dessus ne
    trouve jamais rien (0 corps a chercher) - d'ou 'corps introuvable'
    meme quand le corps existe bel et bien ailleurs dans le design. En
    dernier recours, on cherche donc PAR NOM dans TOUT le design (tous les
    composants/occurrences) ; on ne l'utilise que si le nom est trouve
    EXACTEMENT UNE FOIS (sinon ambigu - ex. le nom generique par defaut
    'Corps1', partage par des dizaines de corps non lies - et on renonce
    plutot que de risquer de modifier le mauvais corps)."""
    body = None
    try:
        found = design.findEntityByToken(spec.get('body_token') or '')
        if found:
            body = adsk.fusion.BRepBody.cast(found[0])
    except Exception:
        body = None
    # findEntityByToken peut renvoyer une entite "au mieux" sans rapport
    # (token d'un autre document) : on n'accepte que le corps du bon nom.
    if body is not None and spec.get('body_name') and body.name != spec['body_name']:
        body = None
    if body is None:
        try:
            comp_found = design.findEntityByToken(spec.get('comp_token') or '')
        except Exception:
            comp_found = None
        comp = None
        if comp_found:
            ent = comp_found[0]
            comp = ent if isinstance(ent, adsk.fusion.Component) else getattr(ent, 'component', None)
        if comp is not None and spec.get('body_name'):
            for k in range(comp.bRepBodies.count):
                b = comp.bRepBodies.item(k)
                if b.name == spec['body_name']:
                    body = b; break
    if body is None and spec.get('body_name'):
        try:
            root = design.rootComponent
            name = spec['body_name']
            # Composants UNIQUES seulement (par entityToken) : bRepBodies
            # appartient a la definition du composant, partagee par toutes
            # ses occurrences - les parcourir par occurrence compterait
            # plusieurs fois le MEME corps pour un composant instancie
            # plusieurs fois (miroir/reseau), faussant le test d'unicite
            # ci-dessous.
            seen_comp_tokens = {root.entityToken}
            comps = [root]
            for occ in root.allOccurrences:
                if occ.component.entityToken not in seen_comp_tokens:
                    seen_comp_tokens.add(occ.component.entityToken)
                    comps.append(occ.component)
            matches = []
            for c in comps:
                for b in c.bRepBodies:
                    if b.name == name:
                        matches.append(b)
            if len(matches) == 1:
                body = matches[0]
        except Exception:
            pass
    return body


def _recreate_tenon_for_key(design, key, entry, already_deleted=False, defer_record=False):
    """Supprime puis recree, a la position/geometrie ACTUELLE du modele, le
    tenon/languette enregistre sous `key`. Retourne (ok, message) - ou,
    quand `defer_record=True`, (ok, message, feat_objs, sketch_objs) sans
    avoir ecrit les tokens dans la map (voir `recreate_all_tenons`).

    `already_deleted=True` quand l'appelant (recreate_all_tenons) a deja
    supprime l'ancienne feature/esquisse lui-meme, en groupant les
    suppressions par corps AVANT toute recreation - indispensable : deux
    tenons du meme corps supprimes/recrees en alternance (supprimer A,
    recreer A, supprimer B, recreer B...) peuvent se gener via des
    dependances croisees internes a Fusion, ce qui a deja provoque un echec
    de suppression silencieux laissant un tenon en double a cote du
    nouveau.

    `defer_record=True` : ne PAS appeler _record_face_tenons_by_key ici -
    l'entityToken d'une feature/esquisse tout juste creee s'est avere
    devenir invalide (design.findEntityByToken echoue ensuite) des qu'une
    AUTRE feature est ajoutee/supprimee sur le MEME corps juste apres (le
    recalcul du corps partage invalide/regenere les tokens deja distribues,
    meme si l'objet Python reste valide) - confirme empiriquement sur
    recreate_all_tenons (plusieurs tenons du meme corps recrees a la
    suite : les tokens des premiers, enregistres immediatement, ne se
    resolvaient plus quelques instants plus tard). Quand `defer_record`
    est vrai, on retourne les objets Python (feature/esquisse) tels quels ;
    l'appelant doit relire leur .entityToken une fois TOUTES les
    recreations du corps terminees (recalcul stabilise) puis enregistrer
    lui-meme via _record_face_tenons_by_key."""
    spec = _entry_spec(entry)
    if spec is None:
        msg = 'pas de parametres enregistres (cree avant la mise a jour - a recreer une fois manuellement, ou utiliser "Reparer anciens Tenons")'
        return (False, msg, [], []) if defer_record else (False, msg)
    try:
        _tagged = _find_tagged_chant(design, key)
        body = _tagged.body if _tagged is not None else _resolve_body_from_spec(design, spec)
        if body is None:
            msg = f"corps introuvable ({spec.get('body_name')})"
            return (False, msg, [], []) if defer_record else (False, msg)

        plane = spec.get('plane') or [0, 0, 0, 0]

        if not already_deleted:
            # Suppression par GEOMETRIE (plan), pas par token enregistre -
            # voir _delete_old_tenon_geometry_by_plane : plus fiable qu'un
            # token qui peut avoir ete invalide entre-temps par une autre
            # etape de 'Mettre a jour CNC' (mortaises/marges) touchant le
            # meme corps. Couvre l'ANCIEN format (esquisse+extrusion par
            # chant). Le NOUVEAU format groupe (voir
            # _commit_tenon_bumps_for_body) est retrouve separement par
            # _delete_tenon_batch_for_body (meme precaution nom+attribut,
            # pas de token) - les deux sont appeles systematiquement, l'un
            # des deux ne trouvant simplement rien a faire selon le format
            # effectivement utilise pour ce corps.
            _, del_errors = _delete_old_tenon_geometry_by_plane(body, plane)
            _, del_errors2 = _delete_tenon_batch_for_body(body)
            del_errors = list(del_errors) + list(del_errors2)
            if del_errors:
                _dbg(f'_recreate_tenon_for_key: suppression incomplete pour {key}: {del_errors}')
                msg = f"ancienne geometrie non supprimee proprement, recreation annulee pour eviter un doublon ({del_errors[0]})"
                return (False, msg, [], []) if defer_record else (False, msg)

        face = _find_tagged_chant(design, key)
        if face is not None and face.body.name != body.name:
            face = None
        if face is None:
            face = _find_face_by_plane(body, plane[:3], plane[3])
        if face is None:
            # Retenter apres avoir laisse Fusion "respirer" : constate
            # empiriquement que juste apres la suppression d'un ancien
            # Tenon (voir _delete_old_tenon_geometry_by_plane / isValid),
            # le corps peut se retrouver MOMENTANEMENT dans un etat de
            # recalcul non stabilise (une feature en aval - typiquement le
            # "jeu" de Marge CNC - n'a pas encore fini de se recalculer
            # suite a la suppression), ce qui fait echouer la recherche du
            # chant meme si le corps et sa face existent bel et bien.
            # adsk.doEvents() laisse Fusion traiter les recalculs en
            # attente avant de reessayer une seule fois.
            try:
                adsk.doEvents()
            except Exception:
                pass
            face = _find_face_by_plane(body, plane[:3], plane[3])
        if face is None:
            # Repli "configuration parametrique" : le panneau a peut-etre
            # change de longueur (ex. le canape existe en plusieurs tailles
            # - 1100/2400/2800mm - via une table de configuration Fusion),
            # ce qui deplace le chant bien au-dela d'une simple derive - la
            # correspondance de plan exacte ne peut alors plus fonctionner
            # par construction (l'offset enregistre ne correspond a rien de
            # nouveau). Voir _find_face_by_plane_resized : on retrouve le
            # chant via son extremite (min/max) memorisee a la creation,
            # recalculee sur la bounding box ACTUELLE du corps.
            face = _find_face_by_plane_resized(body, plane[:3], spec.get('extreme'))
        if face is None:
            msg = f"chant introuvable sur le corps {body.name} (a peut-etre change de forme/position)"
            return (False, msg, [], []) if defer_record else (False, msg)

        # Marque (tenons crees avant la marque) + spec rafraichi a la
        # position ACTUELLE du chant, pour que la prochaine suppression par
        # plan (_delete_old_tenon_geometry_by_plane) retrouve ces tenons.
        _tag_chant_face(face, key)
        try:
            spec['plane'] = _face_plane(face)
            spec['extreme'] = _classify_extreme(face.body, tuple(spec['plane'][:3]), spec['plane'][3])
            spec['body_token'] = face.body.entityToken
            spec['body_name'] = face.body.name
        except Exception:
            _dbg('_recreate_tenon_for_key: rafraichissement spec EXCEPTION: ' + traceback.format_exc())

        params = spec.get('params') or {}
        ft = []; st = []; fo = []; so = []
        if spec.get('mode') == 'languette':
            edge_dist = (params.get('edge_dist_mm', 50) / 10.0)
            lh = (params.get('languette_h_mm', 12) / 10.0)
            cnt, msg = _create_languette_on_face(face, edge_dist, lh, design, track_feats=ft, track_sketches=st,
                                                  track_feat_objs=fo, track_sketch_objs=so)
        else:
            edge_dist = (params.get('edge_dist_mm', 50) / 10.0)
            count = params.get('tenon_count', 2)
            tenon_len = (params.get('tenon_len_mm', 50) / 10.0)
            tenon_h = (params.get('tenon_h_mm', 12) / 10.0)
            # centrer/repartition_* : absents des specs enregistrees AVANT
            # l'ajout de cette fonctionnalite - valeurs par defaut fixees ici
            # pour que "Mettre a jour CNC" continue a recreer a l'identique
            # les tenons crees avant cette mise a jour (non centres).
            centrer = bool(params.get('centrer', False))
            rep_mode = params.get('repartition_mode', 'uniforme')
            rep_pct = params.get('repartition_cotes_pct', 33.3)
            cnt, msg = _create_tenons_on_face(face, edge_dist, count, tenon_len, tenon_h, design, track_feats=ft, track_sketches=st,
                                               track_feat_objs=fo, track_sketch_objs=so,
                                               centrer=centrer, repartition_mode=rep_mode, repartition_cotes_pct=rep_pct)
        if not cnt:
            msg = f'recreation echouee : {msg}'
            return (False, msg, [], []) if defer_record else (False, msg)
        if defer_record:
            return True, msg, fo, so
        _record_face_tenons_by_key(key, ft, st, spec=spec)
        return True, msg
    except Exception:
        _dbg('_recreate_tenon_for_key EXCEPTION: ' + traceback.format_exc())
        msg = traceback.format_exc().strip().splitlines()[-1]
        return (False, msg, [], []) if defer_record else (False, msg)


# Crochets de placement (Mettre a jour CNC, 2026-10-21) : si definis, chaque
# corps est recree A SA PLACE D'ORIGINE dans la chronologie plutot qu'en fin
# d'historique. before() -> snapshot ; after_delete(snapshot) replace le
# marqueur ; done() revient a la limite sure. None = comportement d'origine.
_PLACE_HOOKS = None


def set_place_hooks(hooks):
    global _PLACE_HOOKS
    _PLACE_HOOKS = hooks


def recreate_all_tenons(design, only_body_keys=None):
    """Supprime et recree TOUS les tenons/languettes crees par cet add-in
    dont les parametres d'origine ont ete enregistres (voir _spec dans
    tenon_face_map.json), a la position/forme ACTUELLE du modele. Appele
    par Mettre a jour CNC, exactement comme creer_mortaises pour Mortaise
    CNC. Retourne (n_ok, n_total_avec_spec, n_sans_spec, errors).

    Groupe par corps et supprime TOUTES les anciennes features/esquisses
    d'un meme corps AVANT d'en recreer aucune (voir _recreate_tenon_for_key)
    - plusieurs tenons/languettes sur le meme corps, supprimes et recrees en
    alternance, peuvent echouer silencieusement a se supprimer a cause de
    dependances croisees internes a Fusion ; les traiter par lots evite ce
    probleme.

    La suppression se fait par GEOMETRIE (plan du chant, voir
    _delete_old_tenon_geometry_by_plane), PAS par token enregistre :
    'Mettre a jour CNC' recree d'abord les mortaises puis les marges AVANT
    les tenons, et ces etapes modifient deja les MEMES corps partages - ce
    qui peut invalider les tokens de tenons enregistres au point de faire
    lever une vraie exception Fusion ('InternalValidationError : targetObj')
    plutot qu'un simple 'introuvable'. Une suppression fondee sur les
    tokens abandonnerait alors par securite, laissant l'ancien tenon en
    place (doublon a la prochaine recreation, ou chant vu comme 'trop
    court' puisque fragmente par l'ancien bossage). La recherche par plan
    retrouve la geometrie quel que soit l'etat des tokens."""
    m = _load_face_map()
    keys_with_spec = [k for k, v in m.items() if _entry_spec(v) is not None]
    n_sans_spec = sum(1 for v in m.values() if _entry_spec(v) is None)

    # Seulement les tenons qui existent encore dans CE design (voir
    # _tenon_present) : un tenon supprime de l'historique, ou une cle d'un
    # autre document dont le corps porte le meme nom, n'est plus recree.
    live_keys = _keys_on_live_features(design)
    sketch_keys = _sketch_tenon_keys(design)
    present = []
    seen_legacy = set()
    for key in keys_with_spec:
        entry = m.get(key)
        spec = _entry_spec(entry)
        tagged = _find_tagged_chant(design, key)
        body = tagged.body if tagged is not None else _resolve_body_from_spec(design, spec)
        if body is None:
            continue
        if only_body_keys is not None:
            # Mettre a jour CNC avec selection : seuls les corps choisis
            # ((id composant, nom du corps natif)).
            try:
                _nb = body.nativeObject or body
                if (_nb.parentComponent.id, _nb.name) not in only_body_keys:
                    continue
            except Exception:
                continue
        try:
            ok = _tenon_present(design, key, entry, body, live_keys, tagged)
        except Exception:
            _dbg('_tenon_present EXCEPTION: ' + traceback.format_exc())
            ok = False
        if ok and not spec.get('tracked'):
            # Anciennes cles (sans marque) : plusieurs cles pouvaient
            # designer le meme chant (cles d'autres documents, doublons) -
            # une seule recreation par corps+plan.
            _sig = (body.name, tuple(round(v, 3) for v in (spec.get('plane') or [0, 0, 0, 0])))
            if _sig in seen_legacy:
                ok = False
            seen_legacy.add(_sig)
        if ok and key in sketch_keys:
            # Tenon en esquisse : il suit deja le corps tout seul, le
            # supprimer/recreer ne ferait que casser ce qui vient apres.
            _dbg(f'recreate_all_tenons: {key} en esquisse, suit le corps')
            continue
        if ok and spec.get('tracked') and tagged is not None and _chant_unchanged(tagged, spec):
            # Corps pas deplace depuis la derniere (re)creation : rien a
            # refaire. Supprimer/recreer un tenon en place ne sert a rien,
            # rallonge la mise a jour, sort ses fonctions de leur groupe et
            # peut casser les entailles posees ensuite sur le meme corps
            # (constate 2026-10-06 : MULTIPLE_TARGET_ERROR sur Combiner690).
            _dbg(f'recreate_all_tenons: {key} inchange (corps non deplace)')
            continue
        if ok:
            present.append(key)
        else:
            _dbg(f'recreate_all_tenons: {key} ignore (tenon absent de ce design)')
    keys_with_spec = present

    by_body = {}
    for key in keys_with_spec:
        spec = _entry_spec(m.get(key))
        by_body.setdefault(spec.get('body_token') or '', []).append(key)

    n_ok = 0
    errors = []
    cnc_progress.etape('Tenons : repositionnement...', 0, len(by_body))
    for body_token, keys in by_body.items():
        cnc_progress.avance()
        _h = _PLACE_HOOKS
        _snap = None
        if _h is not None:
            try:
                _snap = _h.before()
            except Exception:
                _dbg('placement (avant) EXCEPTION: ' + traceback.format_exc())
                _h = None
        failed_delete = {}
        body_by_key = {}
        for key in keys:
            spec = _entry_spec(m.get(key))
            tagged = _find_tagged_chant(design, key)
            body = tagged.body if tagged is not None else _resolve_body_from_spec(design, spec)
            if body is None:
                failed_delete[key] = f"corps introuvable ({spec.get('body_name')})"
                continue
            body_by_key[key] = body
            plane = spec.get('plane') or [0, 0, 0, 0]
            planes = [plane]
            if tagged is not None:
                try:
                    cur = _face_plane(tagged)
                    if not _planes_equal(cur, plane):
                        planes.append(cur)
                except Exception:
                    pass
            try:
                del_errors = []
                for _pl in planes:
                    _, _e1 = _delete_old_tenon_geometry_by_plane(body, _pl)
                    del_errors += list(_e1)
                _, del_errors2 = _delete_tenon_batch_for_body(body)
                del_errors = list(del_errors) + list(del_errors2)
            except Exception:
                del_errors = [traceback.format_exc().strip().splitlines()[-1]]
            if del_errors:
                _dbg(f'recreate_all_tenons: suppression incomplete pour {key}: {del_errors}')
                failed_delete[key] = del_errors[0]
        if _h is not None:
            try:
                _h.after_delete(_snap)
            except Exception:
                _dbg('placement (apres suppression) EXCEPTION: ' + traceback.format_exc())
        m2 = _load_face_map()
        # Phase 2 : recreation de toutes les cles de ce corps, SANS encore
        # enregistrer les tokens (defer_record=True) - voir la docstring de
        # _recreate_tenon_for_key : recreer une autre cle du meme corps juste
        # apres invalide les tokens deja distribues pour les cles
        # precedentes. On garde les objets Python (feature/esquisse) et on
        # ne lira/enregistrera leurs tokens qu'une fois TOUTES les
        # recreations de ce corps terminees (Phase 3 ci-dessous), quand le
        # recalcul du corps est stabilise.
        pending = []  # (key, spec, feat_objs, sketch_objs)
        for key in keys:
            if key in failed_delete:
                errors.append(f"{key[:16]}...: ancienne geometrie non supprimee proprement, "
                               f"recreation annulee pour eviter un doublon ({failed_delete[key]})")
                continue
            entry = m2.get(key)
            spec = _entry_spec(entry)
            ok, msg, fo, so = _recreate_tenon_for_key(design, key, entry, already_deleted=True, defer_record=True)
            if ok:
                pending.append((key, spec, fo, so))
            else:
                errors.append(msg)
        # Phase 3 : maintenant que ce corps ne sera plus touche, relire les
        # entityToken (a jour) depuis les objets vivants et les enregistrer.
        for key, spec, fo, so in pending:
            for _f in fo:
                _tag_feature_keys(_f, [key])
            spec['tracked'] = True
            try:
                _sig = _chant_sig(_find_tagged_chant(design, key))
                if _sig is not None:
                    spec['chant_sig'] = _sig
            except Exception:
                _dbg('recreate_all_tenons: signature chant illisible pour ' + key)
            try:
                ft_tokens = [f.entityToken for f in fo]
                st_tokens = [s.entityToken for s in so]
            except Exception:
                _dbg('recreate_all_tenons: relecture token echouee pour ' + key + ': ' + traceback.format_exc())
                errors.append(f"{key[:16]}...: tokens illisibles apres recreation (objet invalide)")
                continue
            # Ecriture directe (remplace, n'AJOUTE PAS aux tokens
            # precedents) - la suppression ci-dessus etant fondee sur la
            # geometrie et non les tokens, d'anciens tokens morts pourraient
            # sinon s'accumuler indefiniment dans la map au fil des cycles
            # de mise a jour (deja observe : des entrees historiques avec
            # plusieurs dizaines de tokens morts).
            try:
                m3 = _load_face_map()
                m3[key] = {'tokens': ft_tokens + st_tokens, 'spec': spec}
                _save_face_map(m3)
                n_ok += 1
            except Exception:
                _dbg('recreate_all_tenons: sauvegarde map echouee pour ' + key + ': ' + traceback.format_exc())
                errors.append(f"{key[:16]}...: sauvegarde des tokens echouee")
        if _h is not None:
            try:
                _h.done()
            except Exception:
                _dbg('placement (fin) EXCEPTION: ' + traceback.format_exc())
    return n_ok, len(keys_with_spec), n_sans_spec, errors


COMMAND_ID   = 'TenonCNCCmd'
COMMAND_NAME = 'Tenons CNC'
COMMAND_DESC = 'Cree des tenons sur des chants de contreplaque pour decoupe CNC'
PANEL_ID      = 'SolidCreatePanel'
PURGE_ID      = 'TenonPurgeCmd'
DELETE_SEL_ID = 'TenonDeleteSelCmd'
REPAIR_ID     = 'TenonRepairCmd'

# ---------------------------------------------------------------------------
# Geometrie helpers
# ---------------------------------------------------------------------------
def _get_face_u_axis_and_origin(face):
    # Retourne (u_axis, origin, face_length) : u_axis = direction du plus long edge
    max_len = 0.0
    best = None
    for edge in face.edges:
        sv = edge.startVertex
        ev = edge.endVertex
        if sv is None or ev is None:
            continue
        p0, p1 = sv.geometry, ev.geometry
        d = p0.distanceTo(p1)
        if d > max_len:
            max_len = d
            best = (p0, p1)
    if best is None or max_len < 1e-6:
        return None, None, 0.0
    p0, p1 = best
    dx = p1.x - p0.x
    dy = p1.y - p0.y
    dz = p1.z - p0.z
    u = adsk.core.Vector3D.create(dx / max_len, dy / max_len, dz / max_len)
    return u, p0, max_len

def _project_face_verts(face, u, origin):
    # Min/max projetes sur u depuis origin (utilise startVertex/endVertex)
    mn, mx = float('inf'), float('-inf')
    seen = set()
    for edge in face.edges:
        for v in [edge.startVertex, edge.endVertex]:
            if v is None:
                continue
            k = v.tempId
            if k in seen:
                continue
            seen.add(k)
            p = v.geometry
            t = (p.x-origin.x)*u.x + (p.y-origin.y)*u.y + (p.z-origin.z)*u.z
            mn = min(mn, t)
            mx = max(mx, t)
    return mn, mx


# Stocke les INDICES des occurrences masquees (stable, pas de pb accents)

# Global pour stocker les noms a garder

def _find_occ_for_comp(comp, root):
    for occ in root.allOccurrences:
        if occ.component.entityToken == comp.entityToken:
            return occ
    return None


def _face_long_edge_angle(face, sk):
    """Angle (rad) dans le repere de l'esquisse de la plus longue arete de la
    face. Sert a detecter un chant dont les aretes ne sont PAS alignees sur
    les axes X/Y de l'esquisse (ex. chant d'un composant incline) : le
    rectangle de tenon doit alors etre dessine tourne du meme angle."""
    xD=sk.xDirection; yD=sk.yDirection
    best=None; best_len=0.0
    for edge in face.edges:
        try:
            a=edge.startVertex.geometry; b=edge.endVertex.geometry
        except Exception:
            continue
        dx=b.x-a.x; dy=b.y-a.y; dz=b.z-a.z
        du=dx*xD.x+dy*xD.y+dz*xD.z
        dv=dx*yD.x+dy*yD.y+dz*yD.z
        L=math.hypot(du,dv)
        if L>best_len:
            best_len=L; best=math.atan2(dv,du)
    return best


def _face_to_2d(face, sk):
    """Coords 2D des vertices dans le repere du sketch (sans projection)."""
    xD=sk.xDirection; yD=sk.yDirection; orig=sk.origin
    pts=set()
    for edge in face.edges:
        for v3 in [edge.startVertex.geometry, edge.endVertex.geometry]:
            dx=v3.x-orig.x; dy=v3.y-orig.y; dz=v3.z-orig.z
            u=round(dx*xD.x+dy*xD.y+dz*xD.z,8)
            v=round(dx*yD.x+dy*yD.y+dz*yD.z,8)
            pts.add((u,v))
    return pts


def _project_chant_and_classify(sk, face, long_axis, long_min, long_max, larg_min, larg_max, tol=1e-3):
    """Projette le contour du chant (face) dans l'esquisse - reference
    ASSOCIATIVE : ces courbes projetees suivent le chant si le corps bouge
    ou change de taille par la suite (ex: repositionne par un reseau
    rectangulaire), contrairement aux coordonnees fixes utilisees jusqu'ici
    pour dessiner le rectangle du tenon.

    Identifie parmi les 4 aretes projetees celles paralleles a long_axis
    (aux positions larg_min/larg_max - les 2 "grandes" aretes du chant, le
    long des faces avant/arriere du panneau), celle a long_min (le debut
    du chant, servant de reference pour la cote edge_dist) et celle a
    long_max (la fin du chant - line_end, ajoutee pour permettre de mesurer
    la longueur TOTALE et VIVANTE du chant entre line_start et line_end,
    utilisee par _parametrize_tenons pour rendre plusieurs tenons sur un
    meme chant proportionnels a sa longueur reelle). Retourne
    (line_min, line_max, line_start, line_end) ou (None, None, None, None)
    si le chant n'est pas un simple rectangle a 4 aretes (chant deja
    fragmente par des tenons existants, ou forme non rectangulaire) - dans
    ce cas on nettoie la projection et on retombe sur l'ancien comportement
    (coordonnees fixes, sans suivi parametrique).

    IMPORTANT : cette fonction n'appelle PLUS Sketch.project(face)
    explicitement. Verifie empiriquement (script de diagnostic direct dans
    Fusion) : quand l'esquisse est creee directement SUR la face
    (parent_comp.sketches.add(face), utilise par les deux appelants), Fusion
    inclut deja automatiquement le contour de cette face comme geometrie de
    l'esquisse des sa creation - un appel explicite a sk.project(face)
    ensuite est donc redondant. Pire : sa VALEUR DE RETOUR (l'ancien code
    faisait "proj = sk.project(face)" puis "for c in proj:") s'est averee
    etre une ObjectCollection VIDE (proj.count == 0) meme quand les 4
    aretes sont bien creees dans l'esquisse - iterer dessus ne trouvait donc
    jamais rien, et TOUT ce qui suit (classification line_min/line_max/
    line_start, puis l'appel a _anchor_rect_to_chant) etait silencieusement
    court-circuite a chaque fois : (None, None, None) etait renvoye
    systematiquement, meme pour un chant rectangulaire simple. C'est la
    cause racine du bug "le tenon/la languette ne suit pas le chant quand on
    change un parametre" - confirme sur les esquisses reelles du document
    (0 cote/contrainte sur les 4 tenons deja crees). Le contour de la face
    est maintenant lu directement dans sk.sketchCurves (deja present a
    l'appel de cette fonction, avant tout autre ajout), sans dependre de la
    valeur de retour de project()."""
    lines = []
    for i in range(sk.sketchCurves.count):
        c = sk.sketchCurves.item(i)
        try:
            if c.classType() == 'adsk::fusion::SketchLine':
                lines.append(c)
        except Exception:
            pass
    if len(lines) != 4:
        # Ne pas supprimer : ce sont les aretes de la face elle-meme,
        # ajoutees automatiquement par Fusion a la creation de l'esquisse
        # (pas quelque chose qu'on a cree nous-memes) - un chant qui n'est
        # pas un simple rectangle (deja fragmente par des tenons existants,
        # forme non rectangulaire...) en aura simplement plus ou moins de 4 ;
        # on se contente alors de ne pas s'en servir pour l'ancrage.
        return None, None, None, None
    line_min = line_max = line_start = line_end = None
    for ln in lines:
        try:
            p0 = ln.startSketchPoint.geometry
            p1 = ln.endSketchPoint.geometry
        except Exception:
            continue
        if long_axis == 'X':
            u0, v0, u1, v1 = p0.x, p0.y, p1.x, p1.y
        else:
            u0, v0, u1, v1 = p0.y, p0.x, p1.y, p1.x
        if abs(v0 - larg_min) < tol and abs(v1 - larg_min) < tol:
            line_min = ln
        elif abs(v0 - larg_max) < tol and abs(v1 - larg_max) < tol:
            line_max = ln
        elif abs(u0 - long_min) < tol and abs(u1 - long_min) < tol:
            line_start = ln
        elif abs(u0 - long_max) < tol and abs(u1 - long_max) < tol:
            line_end = ln
    if not (line_min and line_max and line_start and line_end):
        # Idem : on ne supprime pas ces aretes, ce sont celles de la face.
        return None, None, None, None
    return line_min, line_max, line_start, line_end


def _anchor_rect_to_chant(sk, rect_lines, line_min, line_max, line_start,
                           long_axis, larg_min, larg_max, long_min):
    """Ancre un rectangle de tenon/languette (4 lignes issues de
    addTwoPointRectangle) sur le chant projete (voir
    _project_chant_and_classify) :
    - colinearite des 2 aretes du rectangle qui longent le chant (fixe la
      position en largeur - suit le chant si son epaisseur change) ;
    - une cote de distance depuis l'arete de depart du chant pour CHAQUE
      coin de l'arete "pres/loin" (fixe la position ET la longueur le long
      du chant, a edge_dist/tenon_len pres, en restant relatif au chant).

    Sans cette fonction, le rectangle reste a des coordonnees 2D fixes dans
    l'esquisse : si le chant bouge ensuite (deplace par un reseau
    rectangulaire, un changement de cote...), le tenon reste a l'ancienne
    position et devient un petit corps detache au lieu de suivre le
    panneau."""
    gc = sk.geometricConstraints
    dims = sk.sketchDimensions
    edge_min = edge_max = None
    for ln in rect_lines:
        try:
            if ln.classType() != 'adsk::fusion::SketchLine':
                continue
            p0 = ln.startSketchPoint.geometry
            p1 = ln.endSketchPoint.geometry
        except Exception:
            continue
        v0 = p0.y if long_axis == 'X' else p0.x
        v1 = p1.y if long_axis == 'X' else p1.x
        if abs(v0 - larg_min) < 1e-6 and abs(v1 - larg_min) < 1e-6:
            edge_min = ln
        elif abs(v0 - larg_max) < 1e-6 and abs(v1 - larg_max) < 1e-6:
            edge_max = ln
    if edge_min is None or edge_max is None:
        return False
    try:
        gc.addCollinear(edge_min, line_min)
        gc.addCollinear(edge_max, line_max)
    except Exception:
        pass
    try:
        orientation = (adsk.fusion.DimensionOrientations.HorizontalDimensionOrientation
                       if long_axis == 'X' else
                       adsk.fusion.DimensionOrientations.VerticalDimensionOrientation)
        ref_pt = line_start.startSketchPoint
        for pt in (edge_min.startSketchPoint, edge_min.endSketchPoint):
            g = pt.geometry
            u = g.x if long_axis == 'X' else g.y
            target = abs(u - long_min)
            d = dims.addDistanceDimension(
                ref_pt, pt, orientation,
                adsk.core.Point3D.create(g.x, g.y - 0.3, 0))
            d.parameter.value = target
    except Exception:
        pass
    return True


# ---------------------------------------------------------------------------
# Reparation retroactive des tenons/languettes crees AVANT le correctif de
# l'associativite (voir _project_chant_and_classify) : ces esquisses ont ete
# creees a une epoque ou l'ancrage au chant echouait toujours silencieusement
# (0 cote, 0 contrainte), elles restent donc a des coordonnees figees et ne
# suivent pas le panneau si celui-ci bouge/change de taille. Comme la
# fonction n'a JAMAIS pose de contrainte, ces esquisses n'ont pas ete
# modifiees par le bug lui-meme (pas de nettoyage rate a rattraper) : il
# suffit de poser maintenant les contraintes qui auraient du l'etre des le
# depart, sans rien recreer.
# ---------------------------------------------------------------------------

def _classify_boundary_lines(lines):
    """Comme la classification dans _project_chant_and_classify, mais a
    partir de 4 SketchLine DEJA existantes (le contour du chant, toujours en
    premiere position dans une esquisse Tenon/Languette - voir
    _repair_tenon_sketch) plutot que fraichement obtenues. Determine
    long_axis/larg_min/larg_max/long_min directement a partir de leurs
    propres coordonnees (pas besoin de _face_to_2d : le rectangle du chant
    est deja dans l'esquisse). Retourne
    (line_min, line_max, line_start, line_end, long_axis, larg_min, larg_max,
    long_min, long_max) ou None si ces 4 lignes ne forment pas un rectangle
    exploitable. line_end (arete courte a long_max, symetrique de
    line_start) est utilisee par _retrofit_tenon_sketch pour mesurer la
    longueur totale vivante du chant (voir _parametrize_tenons)."""
    corners = []
    for ln in lines:
        try:
            p0 = ln.startSketchPoint.geometry
            p1 = ln.endSketchPoint.geometry
            corners.append((p0.x, p0.y))
            corners.append((p1.x, p1.y))
        except Exception:
            return None
    xs = [c[0] for c in corners]; ys = [c[1] for c in corners]
    x_min, x_max = min(xs), max(xs); y_min, y_max = min(ys), max(ys)
    x_span = x_max - x_min; y_span = y_max - y_min
    if x_span >= y_span:
        long_axis = 'X'; long_min, long_max = x_min, x_max; larg_min, larg_max = y_min, y_max
    else:
        long_axis = 'Y'; long_min, long_max = y_min, y_max; larg_min, larg_max = x_min, x_max
    tol = 1e-3
    line_min = line_max = line_start = line_end = None
    for ln in lines:
        try:
            p0 = ln.startSketchPoint.geometry
            p1 = ln.endSketchPoint.geometry
        except Exception:
            continue
        if long_axis == 'X':
            u0, v0, u1, v1 = p0.x, p0.y, p1.x, p1.y
        else:
            u0, v0, u1, v1 = p0.y, p0.x, p1.y, p1.x
        if abs(v0 - larg_min) < tol and abs(v1 - larg_min) < tol:
            line_min = ln
        elif abs(v0 - larg_max) < tol and abs(v1 - larg_max) < tol:
            line_max = ln
        elif abs(u0 - long_min) < tol and abs(u1 - long_min) < tol:
            line_start = ln
        elif abs(u0 - long_max) < tol and abs(u1 - long_max) < tol:
            line_end = ln
    if not (line_min and line_max and line_start):
        return None
    return line_min, line_max, line_start, line_end, long_axis, larg_min, larg_max, long_min, long_max


def _repair_tenon_sketch(sk):
    """Ancre retroactivement chaque rectangle de tenon/languette d'une
    esquisse 'Tenon'/'Tenon (n)' existante sur le contour du chant, deja
    present dans l'esquisse (voir _project_chant_and_classify - le contour
    de la face est ajoute automatiquement par Fusion des la creation de
    l'esquisse SUR la face, avant tout rectangle de tenon). Par construction,
    ce contour est toujours le tout premier rectangle (4 premieres lignes)
    de l'esquisse - chaque groupe de 4 lignes suivant est un rectangle de
    tenon/languette distinct. Retourne (n_rects_ancres, message)."""
    all_lines = [sk.sketchCurves.sketchLines.item(i)
                 for i in range(sk.sketchCurves.sketchLines.count)]
    if len(all_lines) < 8 or len(all_lines) % 4 != 0:
        return 0, 'geometrie inattendue (pas un ensemble de rectangles)'
    boundary = all_lines[0:4]
    classified = _classify_boundary_lines(boundary)
    if classified is None:
        return 0, 'chant non reconnu (contour non rectangulaire)'
    line_min, line_max, line_start, _line_end, long_axis, larg_min, larg_max, long_min, _long_max = classified
    n_ok = 0
    for start in range(4, len(all_lines), 4):
        rect = all_lines[start:start + 4]
        try:
            ok = _anchor_rect_to_chant(sk, rect, line_min, line_max, line_start,
                                        long_axis, larg_min, larg_max, long_min)
            if ok:
                n_ok += 1
        except Exception:
            _dbg('_repair_tenon_sketch EXCEPTION: ' + traceback.format_exc())
    return n_ok, f'{n_ok} rectangle(s) ancre(s)'


def _repair_all_tenon_sketches(design):
    """Parcourt tous les composants du design et repare (voir
    _repair_tenon_sketch) chaque esquisse 'Tenon'/'Tenon (n)' qui n'a pas
    encore de contrainte (0 geometricConstraints) - c-a-d celles creees
    avant le correctif, jamais retouchees depuis. Une esquisse deja
    contrainte (creee avec le code corrige) est laissee intacte pour ne pas
    lui ajouter de cotes en double. Retourne
    (n_sketches_reparees, n_rects_ancres_total, n_sketches_ignorees, errors)."""
    root = design.rootComponent
    comps = [root]
    seen = {root.entityToken}
    for occ in root.allOccurrences:
        c = occ.component
        if c.entityToken not in seen:
            seen.add(c.entityToken)
            comps.append(c)
    n_sk_ok = 0
    n_rects = 0
    n_skipped = 0
    errors = []
    for comp in comps:
        for k in range(comp.sketches.count):
            sk = comp.sketches.item(k)
            try:
                nm = sk.name
            except Exception:
                continue
            if not (nm == 'Tenon' or nm.startswith('Tenon (')):
                continue
            try:
                if sk.geometricConstraints.count > 0:
                    n_skipped += 1
                    continue
            except Exception:
                pass
            try:
                n_ok, msg = _repair_tenon_sketch(sk)
                if n_ok > 0:
                    n_sk_ok += 1
                    n_rects += n_ok
                else:
                    n_skipped += 1
                    errors.append(f'{comp.name}/{nm}: {msg}')
            except Exception:
                errors.append(f'{comp.name}/{nm}: {traceback.format_exc().strip().splitlines()[-1]}')
    return n_sk_ok, n_rects, n_skipped, errors


def _retrofit_tenon_sketch(sk):
    """Applique retroactivement, sur UNE esquisse Tenon/Languette EXISTANTE
    (creee avant l'ajout de _auto_constrain_tenon_sketch/_parametrize_tenons
    plus haut dans ce fichier), la meme associativite parametrique que les
    tenons nouvellement crees :
    - esquisse deja contrainte (geometricConstraints.count > 0, cree par le
      code corrige ou deja retrofit une fois) : ne rien faire, pour ne
      jamais ajouter de cotes en double ;
    - chant non reconnu comme un simple rectangle (contour fragmente, forme
      non standard) ou un seul tenon sur le chant : contrainte automatique
      generique (_auto_constrain_tenon_sketch), suffisante et deja validee
      par l'utilisateur pour le cas a un seul tenon (voir plus haut) ;
    - plusieurs tenons sur le meme chant : mise en formule via
      _parametrize_tenons, en reconstruisant edge_dist/tenon_len par
      inspection directe de la geometrie (meme methode que
      _infer_mode_params_from_sketch, deja utilisee ailleurs dans ce fichier
      pour reconstruire le 'spec' de tenons crees avant le suivi des
      parametres) : le premier tenon (le plus proche de long_min) fixe
      edge_dist et tenon_len, en supposant - comme le fait deja
      _backfill_spec_for_key pour ces memes tenons "herites" - le modele
      "distance de bord fixe, tenons interieurs repartis uniformement"
      (centrer=False), le mode d'origine (centre ou non) n'etant plus
      determinable une fois l'esquisse deja dessinee.

    Retourne (statut, message) avec statut dans
    {'parametrise', 'auto_constrain', 'ignore', 'erreur'}."""
    try:
        if sk.geometricConstraints.count > 0:
            return 'ignore', 'deja contrainte'
    except Exception:
        pass
    try:
        all_lines = [sk.sketchCurves.sketchLines.item(i)
                     for i in range(sk.sketchCurves.sketchLines.count)]
    except Exception:
        return 'erreur', traceback.format_exc().strip().splitlines()[-1]
    if len(all_lines) < 4 or len(all_lines) % 4 != 0:
        return 'erreur', 'geometrie inattendue (pas un ensemble de rectangles)'
    boundary = all_lines[0:4]
    classified = _classify_boundary_lines(boundary)
    if classified is None:
        try:
            _auto_constrain_tenon_sketch(sk)
            return 'auto_constrain', 'chant non reconnu (contour non rectangulaire) - contrainte automatique appliquee'
        except Exception:
            return 'erreur', traceback.format_exc().strip().splitlines()[-1]
    line_min, line_max, line_start, line_end, long_axis, larg_min, larg_max, long_min, long_max = classified
    if line_end is None:
        try:
            _auto_constrain_tenon_sketch(sk)
            return 'auto_constrain', 'arete de fin du chant non identifiee - contrainte automatique appliquee'
        except Exception:
            return 'erreur', traceback.format_exc().strip().splitlines()[-1]

    def _rect_span_u(rect):
        us = []
        for ln in rect:
            try:
                p0 = ln.startSketchPoint.geometry; p1 = ln.endSketchPoint.geometry
            except Exception:
                continue
            us.append(p0.x if long_axis == 'X' else p0.y)
            us.append(p1.x if long_axis == 'X' else p1.y)
        if not us:
            return None
        return min(us), max(us)

    rects = []
    for start in range(4, len(all_lines), 4):
        rect_lines = all_lines[start:start + 4]
        span = _rect_span_u(rect_lines)
        if span:
            rects.append((span[0], span[1], rect_lines))
    if not rects:
        return 'erreur', 'aucun rectangle de tenon trouve'
    rects.sort(key=lambda r: r[0])
    count = len(rects)
    if count <= 1:
        try:
            _auto_constrain_tenon_sketch(sk)
            return 'auto_constrain', '1 seul tenon - contrainte automatique appliquee'
        except Exception:
            return 'erreur', traceback.format_exc().strip().splitlines()[-1]
    edge_dist = max(rects[0][0] - long_min, 0.0)
    tenon_len = rects[0][1] - rects[0][0]
    all_rect_lines = [r[2] for r in rects]
    try:
        ok = _parametrize_tenons(
            sk, all_rect_lines, line_min, line_max, line_start, line_end,
            long_axis, larg_min, larg_max, long_min, long_max,
            False, 'uniforme', 33.3, count, tenon_len, edge_dist)
    except Exception:
        _dbg('_retrofit_tenon_sketch EXCEPTION: ' + traceback.format_exc())
        ok = False
    if ok:
        return 'parametrise', (f'{count} tenon(s) parametres '
                                f'(edge_dist={edge_dist*10:.2f}mm, tenon_len={tenon_len*10:.2f}mm)')
    try:
        _auto_constrain_tenon_sketch(sk)
        return 'auto_constrain', 'parametrisation echouee - contrainte automatique appliquee en repli'
    except Exception:
        return 'erreur', traceback.format_exc().strip().splitlines()[-1]


def retrofit_all_tenon_sketches(design):
    """Parcourt tous les composants du design et applique
    _retrofit_tenon_sketch a chaque esquisse 'Tenon'/'Tenon (n)' - correctif
    demande explicitement par l'utilisateur pour appliquer a TOUS les
    tenons/languettes deja presents dans le modele (crees avant l'ajout de
    _auto_constrain_tenon_sketch/_parametrize_tenons) la meme associativite
    que les tenons crees depuis. Retourne
    (n_parametrises, n_auto_constrain, n_ignores, errors)."""
    root = design.rootComponent
    comps = [root]
    seen = {root.entityToken}
    for occ in root.allOccurrences:
        c = occ.component
        if c.entityToken not in seen:
            seen.add(c.entityToken)
            comps.append(c)
    n_param = 0; n_auto = 0; n_skip = 0
    errors = []
    for comp in comps:
        for k in range(comp.sketches.count):
            sk = comp.sketches.item(k)
            try:
                nm = sk.name
            except Exception:
                continue
            if not (nm == 'Tenon' or nm.startswith('Tenon (')):
                continue
            try:
                status, msg = _retrofit_tenon_sketch(sk)
            except Exception:
                errors.append(f'{comp.name}/{nm}: ' + traceback.format_exc().strip().splitlines()[-1])
                continue
            if status == 'parametrise':
                n_param += 1
            elif status == 'auto_constrain':
                n_auto += 1
            elif status == 'ignore':
                n_skip += 1
            else:
                errors.append(f'{comp.name}/{nm}: {msg}')
    return n_param, n_auto, n_skip, errors


def _infer_mode_params_from_sketch(sk, feat):
    """A partir d'une esquisse Tenon/Languette EXISTANTE (creee avant le
    suivi des parametres) et de la feature d'extrusion associee, retrouve
    (mode, params) par inspection directe de la geometrie - sans avoir
    besoin de la face d'origine (souvent invalide/decoupee depuis)."""
    all_lines = [sk.sketchCurves.sketchLines.item(i)
                 for i in range(sk.sketchCurves.sketchLines.count)]
    if len(all_lines) < 8 or len(all_lines) % 4 != 0:
        return None
    boundary = all_lines[0:4]
    classified = _classify_boundary_lines(boundary)
    if classified is None:
        return None
    line_min, line_max, line_start, _line_end, long_axis, larg_min, larg_max, long_min, long_max = classified

    def _rect_span(rect):
        us = []
        for ln in rect:
            try:
                p0 = ln.startSketchPoint.geometry; p1 = ln.endSketchPoint.geometry
            except Exception:
                continue
            us.append(p0.x if long_axis == 'X' else p0.y)
            us.append(p1.x if long_axis == 'X' else p1.y)
        if not us:
            return None
        return min(us), max(us)

    rects = []
    for start in range(4, len(all_lines), 4):
        span = _rect_span(all_lines[start:start + 4])
        if span:
            rects.append(span)
    if not rects:
        return None
    rects.sort()

    try:
        h_val = abs(feat.extentOne.distance.value)
    except Exception:
        h_val = 1.2  # repli (12mm) si illisible

    full_span = long_max - long_min
    first_span = rects[0][1] - rects[0][0]
    if len(rects) == 1 and full_span > 1e-6 and (first_span / full_span) > 0.55:
        edge_dist = max(min(rects[0][0] - long_min, long_max - rects[0][1]), 0.0)
        return 'languette', {
            'edge_dist_mm': round(edge_dist * 10, 4),
            'languette_h_mm': round(h_val * 10, 4),
        }
    edge_dist = max(rects[0][0] - long_min, 0.0)
    tenon_len = first_span
    return 'tenon', {
        'edge_dist_mm': round(edge_dist * 10, 4),
        'tenon_count': len(rects),
        'tenon_len_mm': round(tenon_len * 10, 4),
        'tenon_h_mm': round(h_val * 10, 4),
    }


def _backfill_spec_for_key(design, key, entry):
    """Reconstruit un `spec` (mode, parametres, corps, plan) pour une entree
    de tenon_face_map.json qui n'en a pas encore (tenons/languettes crees
    avant le suivi des parametres), a partir des tokens deja enregistres a
    l'epoque (feature d'extrusion + esquisse). Une fois ce spec ecrit, ce
    chant devient recreable par 'Mettre a jour CNC' comme n'importe quel
    autre. Retourne (ok, message)."""
    if _entry_spec(entry) is not None:
        return False, 'deja a jour'
    toks = _entry_tokens(entry)
    if not toks:
        return False, 'aucun token enregistre'
    sk = None; feat = None
    for tok in toks:
        try:
            found = design.findEntityByToken(tok)
        except Exception:
            found = None
        if not found:
            continue
        ent = found[0]
        if isinstance(ent, adsk.fusion.Sketch) and sk is None:
            sk = ent
        elif isinstance(ent, adsk.fusion.Feature) and feat is None:
            feat = ent
    if sk is None or feat is None:
        return False, 'esquisse/feature introuvable (tokens perimes)'
    try:
        inferred = _infer_mode_params_from_sketch(sk, feat)
    except Exception:
        inferred = None
    if inferred is None:
        return False, 'geometrie non reconnue (pas un rectangle simple)'
    mode, params = inferred
    try:
        bodies = feat.bodies
        body = bodies.item(0) if bodies and bodies.count else None
    except Exception:
        body = None
    if body is None:
        return False, 'corps introuvable via la feature'
    try:
        ox = sk.xDirection; oy = sk.yDirection; oo = sk.origin
        nx = ox.y * oy.z - ox.z * oy.y
        ny = ox.z * oy.x - ox.x * oy.z
        nz = ox.x * oy.y - ox.y * oy.x
        norm = math.sqrt(nx * nx + ny * ny + nz * nz) or 1.0
        nx, ny, nz = nx / norm, ny / norm, nz / norm
        offset = oo.x * nx + oo.y * ny + oo.z * nz
    except Exception:
        return False, "plan de l'esquisse illisible"
    try:
        extreme = _classify_extreme(body, (nx, ny, nz), offset)
    except Exception:
        extreme = None
    spec = {
        'mode': mode,
        'params': params,
        'body_token': body.entityToken,
        'body_name': body.name,
        'comp_token': body.parentComponent.entityToken,
        'plane': [round(nx, 6), round(ny, 6), round(nz, 6), round(offset, 6)],
        'extreme': extreme,
    }
    m = _load_face_map()
    m[key] = {'tokens': toks, 'spec': spec}
    _save_face_map(m)
    return True, f'{mode} : {params}'


def purge_dead_face_map_entries(design):
    """Retire de tenon_face_map.json les entrees dont AUCUN token (spec
    comprise) ne resout plus vers une entite reelle du document - de la
    pure comptabilite morte (tenon supprime depuis via 'Suppr. Tenons
    chants', doublon nettoye manuellement, etc.), qui n'a plus rien a voir
    avec un vrai tenon a reparer/mettre a jour. Retourne le nombre
    d'entrees retirees."""
    m = _load_face_map()
    dead = []
    for key, entry in list(m.items()):
        toks = _entry_tokens(entry)
        if _entry_spec(entry) is not None:
            # Une entree AVEC spec n'est jamais consideree morte, meme si
            # ses tokens ne resolvent plus (cas observe : l'entityToken
            # d'une feature/esquisse fraichement creee peut devenir
            # non-resolvable via findEntityByToken peu apres, notamment
            # apres d'autres modifications du meme corps - voir
            # recreate_all_tenons). Purger perdrait definitivement les
            # parametres (mode/dimensions/plan) du chant sans aucun moyen
            # de le retrouver : on garde l'entree telle quelle, quitte a ce
            # que "Mettre a jour CNC" la retente (au pire elle recreera le
            # tenon a cote de l'ancien si celui-ci existe encore reellement
            # - un cas a verifier manuellement, mais bien moins grave que de
            # perdre la trace du chant).
            continue
        if not toks:
            # Une entree sans aucun token (recreation ratee laissant un
            # spec orphelin, voir _recreate_tenon_for_key) n'est PAS morte :
            # on la garde, elle sera retentee au prochain "Mettre a jour CNC".
            continue
        alive = False
        for tok in toks:
            try:
                if design.findEntityByToken(tok):
                    alive = True
                    break
            except Exception:
                pass
        if not alive:
            dead.append(key)
    for key in dead:
        m.pop(key, None)
    if dead:
        _save_face_map(m)
    return len(dead)


def backfill_all_tenon_specs(design):
    """Applique _backfill_spec_for_key a toutes les entrees de
    tenon_face_map.json qui n'ont pas encore de spec (tenons/languettes
    crees avant le suivi des parametres). Une fois fait, recreate_all_tenons
    (et donc 'Mettre a jour CNC') peut aussi les prendre en charge. Purge
    d'abord les entrees mortes (voir purge_dead_face_map_entries) pour que
    le compte-rendu ne compte pas indefiniment de la comptabilite obsolete.
    Retourne (n_ok, n_total_sans_spec, n_purgees, errors)."""
    n_purged = purge_dead_face_map_entries(design)
    m = _load_face_map()
    todo = [k for k, v in m.items() if _entry_spec(v) is None]
    n_ok = 0
    errors = []
    for key in todo:
        entry = m.get(key)
        ok, msg = _backfill_spec_for_key(design, key, entry)
        if ok:
            n_ok += 1
        else:
            errors.append(f'{key[:16]}...: {msg}')
    return n_ok, len(todo), n_purged, errors


def _auto_constrain_tenon_sketch(sk):
    """Applique la contrainte automatique de Fusion (Esquisse > Contraintes
    > Automatique, reglages par defaut - Option1AutoConstrainResultType,
    ce qui correspond au "resultat 1" utilise manuellement par l'utilisateur)
    sur l'esquisse d'un tenon/languette fraichement creee et deja extrudee.

    Rend l'esquisse associative a la geometrie du corps : Fusion detecte
    lui-meme les relations (coincidences avec les aretes reelles du corps,
    cotes de decalage/longueur) et les ajoute automatiquement. Verifie
    empiriquement par l'utilisateur en conditions reelles : apres un
    changement de longueur du canape, un tenon ainsi contraint suit et se
    redimensionne avec le panneau tout seul, SANS que 'Mettre a jour CNC'
    ait besoin de le supprimer/recreer - ce qui evite du meme coup toute la
    cascade Combiner1/DecalerLesFaces/FACE_REFERENCE_LOST provoquee par la
    suppression de l'ancienne extrusion de tenon (voir MiseAJourCNC.py).

    Applique UNIQUEMENT une fois l'extrusion deja creee (jamais avant, et
    jamais avant la recherche de profil par bounding-box) : le solveur de
    contraintes peut deplacer les points de quelques microns pour resoudre
    les contraintes, ce qui casserait cette recherche par tolerance
    (tol_size=1e-3) si elle etait faite apres coup - voir aussi le
    commentaire historique sur l'ancien `_anchor_rect_to_chant`, retire pour
    la meme raison quand le profil n'etait pas encore extrude.

    Best-effort : si Fusion ne trouve rien a inferer ou echoue pour
    n'importe quelle raison, l'esquisse/le tenon restent geometriquement
    valides et fonctionnels (juste moins associatifs, comme avant cet
    ajout) - toute exception est donc avalee sans faire echouer la
    creation du tenon elle-meme."""
    try:
        sk.isComputeDeferred = True
    except Exception:
        pass
    try:
        aci = sk.createAutoConstrainInput()
        sk.autoConstrain(aci)
    except Exception as ex:
        _dbg(f'autoConstrain EXCEPTION sur esquisse {sk.name}: {ex}')
    finally:
        try:
            sk.isComputeDeferred = False
        except Exception:
            pass


def _parametrize_tenons(sk, all_rect_lines, line_min, line_max, line_start, line_end,
                         long_axis, larg_min, larg_max, long_min, long_max,
                         centrer, repartition_mode, repartition_cotes_pct,
                         count, tenon_len, edge_dist):
    """Rend PROPORTIONNELS a la longueur reelle du chant tous les tenons
    d'une meme esquisse (cas plusieurs tenons sur un chant, count>1) -
    corrige la limitation signalee : _auto_constrain_tenon_sketch seul
    infere des contraintes/cotes a partir de la geometrie ACTUELLE, ce qui
    fige la distance mesuree a cet instant entre deux tenons voisins (ex.
    tenon de gauche <-> tenon du centre) en une valeur FIXE ; apres un
    changement de longueur du canape, le tenon extreme suit bien le chant
    (contrainte de coincidence avec la geometrie reelle) mais un tenon
    interieur reste a l'ancienne distance au lieu de se repositionner selon
    le meme calcul de repartition (uniforme/personnalise/edge_dist) que
    celui utilise a la creation dans _create_tenons_on_face.

    Principe : au lieu de laisser Fusion deviner, on pose nous-memes :
    1) UNE cote de reference ('chant_total') mesurant la distance reelle et
       VIVANTE entre line_start et line_end (les 2 aretes courtes du
       contour du chant, associatives - voir _project_chant_and_classify) :
       elle vaut donc la longueur ACTUELLE du chant, quelle qu'elle soit,
       et suit tout changement ulterieur du panneau.
    2) Pour chaque tenon, apres avoir colle ses aretes larg_min/larg_max au
       contour du chant (colinearite, comme _anchor_rect_to_chant), DEUX
       cotes de distance depuis line_start dont la VALEUR est une FORMULE
       ('.parameter.expression', jamais '.parameter.value') exprimee en
       fonction de 'chant_total' - la meme formule, litteralement transposee
       en expression Fusion, que celle utilisee en Python plus haut dans
       _create_tenons_on_face pour calculer 'centers'/'intervals' (modes
       'centrer'+uniforme, 'centrer'+personnalise, ou edge_dist classique).

    Doit etre appelee UNIQUEMENT apres extrusion reussie (meme contrainte
    de timing que _auto_constrain_tenon_sketch : le solveur de contraintes
    peut deplacer les points de quelques microns, ce qui casserait la
    recherche de profil par bounding-box si elle etait faite avant).

    Retourne True si au moins une cote de reference et un tenon ont pu etre
    parametres (l'appelant doit alors NE PAS appeler en plus
    _auto_constrain_tenon_sketch, pour ne pas ajouter de cotes
    redondantes/conflictuelles) ; False si le chant n'a pas ete projete
    proprement (chant non rectangulaire, plan de construction de secours...)
    ou en cas d'echec quelconque - l'appelant doit alors retomber sur
    _auto_constrain_tenon_sketch comme avant."""
    if not (line_min and line_max and line_start and line_end):
        return False
    if not all_rect_lines or len(all_rect_lines) != count:
        return False
    gc = sk.geometricConstraints
    dims = sk.sketchDimensions
    orientation = (adsk.fusion.DimensionOrientations.HorizontalDimensionOrientation
                   if long_axis == 'X' else
                   adsk.fusion.DimensionOrientations.VerticalDimensionOrientation)
    ref_pt = line_start.startSketchPoint
    # isComputeDeferred=True : chaque addCollinear/addDistanceDimension
    # declenche normalement un recalcul complet du modele (l'esquisse fait
    # deja partie d'une extrusion consommee plus loin dans l'arbre) - avec
    # plusieurs tenons cela fait autant de recalculs que de cotes posees.
    # Mesure (tenon_debug.log, "[perf] _parametrize_tenons") : ~1.8s pour 2
    # tenons (5 cotes/contraintes), soit l'essentiel du temps de creation
    # d'un tenon. En differant le recalcul jusqu'a la fin de cette fonction
    # (un seul recalcul au lieu d'un par cote), Fusion ne resout plus
    # qu'une fois - le solveur golfe toujours le meme resultat final, seul
    # le nombre de recalculs intermediaires change.
    try:
        sk.isComputeDeferred = True
    except Exception:
        pass
    try:
        return _parametrize_tenons_impl(
            sk, all_rect_lines, gc, dims, orientation, ref_pt,
            line_min, line_max, line_start, line_end,
            long_axis, larg_min, larg_max, long_min, long_max,
            centrer, repartition_mode, repartition_cotes_pct,
            count, tenon_len, edge_dist)
    finally:
        try:
            sk.isComputeDeferred = False
        except Exception:
            pass


def _parametrize_tenons_impl(sk, all_rect_lines, gc, dims, orientation, ref_pt,
                              line_min, line_max, line_start, line_end,
                              long_axis, larg_min, larg_max, long_min, long_max,
                              centrer, repartition_mode, repartition_cotes_pct,
                              count, tenon_len, edge_dist):
    """Corps de _parametrize_tenons, isole dans sa propre fonction pour que
    le bloc try/finally (isComputeDeferred) de l'appelant couvre TOUJOURS
    tout le travail, y compris les 'return' anticipes ci-dessous."""
    try:
        end_pt = line_end.startSketchPoint
        g = end_pt.geometry
        # isDriving=False : cote de REFERENCE (affichee entre parentheses
        # dans l'UI), pas une cote pilotante. line_start/line_end sont les
        # aretes du contour de la face, deja entierement fixees par la
        # geometrie reelle (esquisse creee directement sur la face) - leur
        # ajouter une cote PILOTANTE echoue avec
        # "VCS_SKETCH_OVER_CONSTRAINTS - La geometrie d'esquisse est
        # surcontrainte" (confirme via tenon_debug.log). Une cote de
        # reference se contente de MESURER la distance (elle suit la face
        # si elle bouge, sans tenter de la piloter) - elle garde neanmoins
        # un nom de parametre ('chant_total' ci-dessous) utilisable dans les
        # formules d'autres cotes, exactement comme le fait l'utilisateur
        # manuellement (cote "(2434.00)" entre parentheses, puis
        # "d.../2 - 25mm" ailleurs).
        d_total = dims.addDistanceDimension(
            ref_pt, end_pt, orientation,
            adsk.core.Point3D.create(g.x, g.y - 0.6, 0),
            False)
        try:
            d_total.parameter.name = 'chant_total'
        except Exception:
            pass
        pname = d_total.parameter.name
    except Exception:
        _dbg('_parametrize_tenons: cote de reference EXCEPTION: ' + traceback.format_exc())
        return False

    def _near_offset_expr(i):
        # Distance (formule) entre line_start et le coin "pres" (cote
        # long_min) du i-eme tenon - transpose fidelement les calculs
        # Python de _create_tenons_on_face (variables 'margin'/'inter_gap'/
        # 'gap'/'spacing' ci-dessus dans cette meme fonction appelante).
        if centrer:
            if count <= 1:
                return f'(({pname} - {tenon_len} cm) / 2)'
            leftover = f'({pname} - {count} * {tenon_len} cm)'
            if repartition_mode == 'personnalise':
                pct = repartition_cotes_pct
                try: pct = float(pct)
                except Exception: pct = 33.3
                pct = max(0.0, min(100.0, pct))
                side_total = f'({leftover} * {pct} / 100)'
                margin = f'({side_total} / 2)'
                inter_gap = f'(({leftover} - {side_total}) / {count - 1})'
                if i == 0:
                    return margin
                return f'({margin} + {i} * ({tenon_len} cm + {inter_gap}))'
            else:
                gap = f'({leftover} / {count + 1})'
                if i == 0:
                    return f'({gap} * {i + 1})'
                return f'({gap} * {i + 1} + {i} * {tenon_len} cm)'
        else:
            if count <= 1 or i == 0:
                return f'{edge_dist} cm'
            spacing = f'(({pname} - 2 * {edge_dist} cm - {tenon_len} cm) / {count - 1})'
            return f'({edge_dist} cm + {i} * {spacing})'

    n_ok = 0
    for i, rect_lines in enumerate(all_rect_lines):
        edge_min = edge_max = None
        for ln in rect_lines:
            try:
                if ln.classType() != 'adsk::fusion::SketchLine':
                    continue
                p0 = ln.startSketchPoint.geometry
                p1 = ln.endSketchPoint.geometry
            except Exception:
                continue
            v0 = p0.y if long_axis == 'X' else p0.x
            v1 = p1.y if long_axis == 'X' else p1.x
            if abs(v0 - larg_min) < 1e-6 and abs(v1 - larg_min) < 1e-6:
                edge_min = ln
            elif abs(v0 - larg_max) < 1e-6 and abs(v1 - larg_max) < 1e-6:
                edge_max = ln
        if edge_min is None or edge_max is None:
            continue
        try:
            gc.addCollinear(edge_min, line_min)
            gc.addCollinear(edge_max, line_max)
        except Exception:
            pass
        # Les 2 traits de longueur du tenon (cotes courts du rectangle, qui
        # traversent le chant) : perpendiculaires a l'arete longue du chant.
        # Sans ca, leur extremite cote line_max peut glisser le long du
        # chant et le tenon se deforme en parallelogramme.
        for ln in rect_lines:
            if ln == edge_min or ln == edge_max:
                continue
            try:
                if ln.classType() != 'adsk::fusion::SketchLine':
                    continue
                gc.addPerpendicular(ln, line_min)
            except Exception:
                _dbg(f'_parametrize_tenons: perpendiculaire tenon #{i} EXCEPTION: ' + traceback.format_exc())
        try:
            near_expr = _near_offset_expr(i)
            far_expr = f'(({near_expr}) + {tenon_len} cm)'
            pts = [edge_min.startSketchPoint, edge_min.endSketchPoint]
            us = [(p.geometry.x if long_axis == 'X' else p.geometry.y) for p in pts]
            if us[0] <= us[1]:
                near_pt, far_pt2 = pts[0], pts[1]
            else:
                near_pt, far_pt2 = pts[1], pts[0]
            for pt, expr in ((near_pt, near_expr), (far_pt2, far_expr)):
                g = pt.geometry
                d = dims.addDistanceDimension(
                    ref_pt, pt, orientation,
                    adsk.core.Point3D.create(g.x, g.y - 0.3, 0))
                d.parameter.expression = expr
            n_ok += 1
        except Exception:
            _dbg(f'_parametrize_tenons: tenon #{i} EXCEPTION: ' + traceback.format_exc())
    return n_ok > 0


def _create_languette_on_face(face, edge_dist, languette_h, design, track_feats=None, track_sketches=None,
                               track_feat_objs=None, track_sketch_objs=None,
                               deferred_constraints=None):
    root=design.rootComponent; parent_comp=face.body.parentComponent
    if parent_comp.entityToken!=root.entityToken:
        # IMPORTANT : quand le composant contenant `face` est instancie
        # PLUSIEURS FOIS (mirroir/motif - ex. "DOS" duplique de chaque cote
        # du caisson), `_find_occ_for_comp` renvoie la PREMIERE occurrence
        # trouvee, sans lien avec le chant reellement selectionne : la
        # geometrie etait alors parfois placee/visible dans la mauvaise
        # occurrence (ex. celle du dernier chant traite auparavant, restee
        # active). `face.assemblyContext` donne au contraire l'occurrence
        # EXACTE a laquelle appartient CE chant precis - on l'utilise en
        # priorite, et on ne retombe sur la recherche approximative que si
        # elle est absente (cas normal d'un composant non instancie via une
        # occurrence, ou face directement dans le composant racine).
        occ = face.assemblyContext
        if occ is None:
            occ=_find_occ_for_comp(parent_comp,root)
        if occ is not None: occ.activate()
    sk=parent_comp.sketches.add(face)
    sk.name='Tenon'
    pts=_face_to_2d(face,sk)
    if len(pts)<2:
        sk.deleteMe()
        return 0,'Pas assez de points.'
    xs=[p[0] for p in pts]; ys=[p[1] for p in pts]
    x_min,x_max=min(xs),max(xs); y_min,y_max=min(ys),max(ys)
    x_span=x_max-x_min; y_span=y_max-y_min
    if x_span>=y_span:
        long_min,long_max,long_axis=x_min,x_max,'X'
        larg_min,larg_max=y_min,y_max
    else:
        long_min,long_max,long_axis=y_min,y_max,'Y'
        larg_min,larg_max=x_min,x_max
    if (long_max-long_min)<=2*edge_dist:
        sk.deleteMe()
        return 0,'Chant trop court.'
    line_min, line_max, line_start, line_end = _project_chant_and_classify(
        sk, face, long_axis, long_min, long_max, larg_min, larg_max)
    nln=long_min+edge_dist; nlx=long_max-edge_dist
    # On reutilise le meme sketch (au lieu d'en creer un 2e, qui restait
    # orpheline dans l'arbre de construction a chaque appel).
    dl=sk.sketchCurves.sketchLines
    if long_axis=='X':
        p1=adsk.core.Point3D.create(nln,larg_min,0)
        p2=adsk.core.Point3D.create(nlx,larg_max,0)
    else:
        p1=adsk.core.Point3D.create(larg_min,nln,0)
        p2=adsk.core.Point3D.create(larg_max,nlx,0)
    rect_lines = dl.addTwoPointRectangle(p1,p2)
    # NB : plus d'ancrage via contraintes ici non plus - voir le commentaire
    # equivalent dans _create_tenons_on_face.
    prof=None; tol=1e-3
    ls_t=abs(nlx-nln); la_t=abs(larg_max-larg_min)
    for j in range(sk.profiles.count):
        prf=sk.profiles.item(j); bb=prf.boundingBox
        w=abs(bb.maxPoint.x-bb.minPoint.x); h2=abs(bb.maxPoint.y-bb.minPoint.y)
        if abs(max(w,h2)-ls_t)<tol and abs(min(w,h2)-la_t)<tol: prof=prf; break
    if prof is None: sk.deleteMe(); return 0,'Profil non trouve.'
    extr=parent_comp.features.extrudeFeatures
    dist=adsk.core.ValueInput.createByReal(languette_h); done=False
    for flip in [False,True]:
        try:
            ei=extr.createInput(prof,adsk.fusion.FeatureOperations.JoinFeatureOperation)
            ei.setDistanceExtent(flip,dist); ei.participantBodies=[face.body]
            ft=extr.add(ei); ft.name='Tenon'; done=True; break
        except: pass
    if not done: sk.deleteMe(); return 0,'Extrusion echouee.'
    if deferred_constraints is not None:
        deferred_constraints.append(lambda: _auto_constrain_tenon_sketch(sk))
    else:
        _auto_constrain_tenon_sketch(sk)
    if track_feats is not None: track_feats.append(ft.entityToken)
    if track_sketches is not None: track_sketches.append(sk.entityToken)
    if track_feat_objs is not None: track_feat_objs.append(ft)
    if track_sketch_objs is not None: track_sketch_objs.append(sk)
    return 1,'Languette creee'


def _create_tenons_on_face(face, edge_dist, count, tenon_len, tenon_h, design, track_feats=None, track_sketches=None,
                            track_feat_objs=None, track_sketch_objs=None,
                            centrer=False, repartition_mode='uniforme', repartition_cotes_pct=33.3,
                            deferred_constraints=None):
    # Chronometrage temporaire (diagnostic de lenteur signale par
    # l'utilisateur) : chaque etape ecrit son propre delta dans
    # tenon_debug.log - a retirer une fois la lenteur identifiee/corrigee.
    _t0=_time.time(); _tp=[_t0]
    def _lap(label):
        _now=_time.time()
        _dbg(f'  [perf] {label}: {_now-_tp[0]:.2f}s')
        _tp[0]=_now
    root=design.rootComponent; parent_comp=face.body.parentComponent
    if parent_comp.entityToken!=root.entityToken:
        # Voir le commentaire equivalent dans _create_languette_on_face :
        # on prefere l'occurrence EXACTE de ce chant (assemblyContext) a la
        # recherche approximative "premiere occurrence du composant", qui se
        # trompait quand le composant est instancie plusieurs fois.
        occ = face.assemblyContext
        if occ is None:
            occ=_find_occ_for_comp(parent_comp,root)
        if occ is not None: occ.activate()
    # NB (bug corrige) : quand `face` provient d'une selection en contexte
    # d'assemblage, c'est un objet PROXY dont la geometrie brute (points de
    # sommets, vecteurs normaux via .geometry) est exprimee en coordonnees
    # MONDE/assemblage - alors que parent_comp.constructionPlanes.add(...)
    # attend une definition de plan en coordonnees NATIVES/locales du
    # composant (le contexte d'edition active apres occ.activate() juste
    # au-dessus). Utiliser directement ref_pt/adj_normal issus du proxy
    # produisait un plan de construction - et donc un tenon extrude -
    # decale de tout l'offset de l'occurrence, disjoint du panneau cible.
    # On resout donc explicitement l'objet NATIF avant de lire sa geometrie
    # pour cette branche de secours (le chemin principal sketch-sur-face
    # plus bas passe l'objet `face` lui-meme, proxy ou non, a sketches.add,
    # ce qui est gere correctement par l'API - on ne touche pas a ce chemin).
    try:
        face_native = face.nativeObject
    except Exception:
        face_native = None
    if face_native is None:
        face_native = face
    # NB (bug corrige) : l'ancien critere de declenchement du plan de
    # construction de secours (produit scalaire entre la normale du chant
    # et celle de la face adjacente de plus grande aire) ciblait parfois la
    # mauvaise face adjacente - ex. une grande face du composant plutot que
    # le chant selectionne - et produisait alors un tenon extrude sur cette
    # grande face au lieu du chant (signale par l'utilisateur : "l'extrusion
    # se fait sur la face du composant, pas sur le chant selectionne").
    # Le sketch direct sur `face` (chemin principal, ci-dessous) fonctionne
    # de facon fiable dans l'immense majorite des cas puisque le chant est
    # quasi-toujours une face PLANE. Le plan de construction de secours
    # n'est donc plus utilise que si le chant n'a REELEMENT aucune normale
    # exploitable (face non plane) - cas ou le sketch direct est de toute
    # facon impossible.
    # NB (bug corrige, suite) : le meme probleme world-vs-native affectait en
    # fait aussi TOUT LE CHEMIN PRINCIPAL (pas seulement la branche cplane
    # ci-dessus) : sketch_ref=face (proxy) plus bas ne posait pas de
    # probleme pour PLACER le plan de l'esquisse (Fusion resout correctement
    # une face proxy pour ca), mais sk.origin/xDirection/yDirection d'une
    # esquisse NATIVE (parent_comp.sketches.add) sont eux en coordonnees
    # NATIVES - alors que _face_to_2d(face,sk) lisait ensuite les sommets de
    # `face.edges` (proxy => coordonnees MONDE si l'occurrence a une
    # transformation) pour les comparer a sk.origin (natif). Le decalage
    # (translation de l'occurrence) se retrouvait alors directement dans
    # les coordonnees 2D calculees, donc dans la position du rectangle de
    # tenon dessine puis extrude - explique le tenon extrude bien plus loin
    # que le chant reellement selectionne. Toutes les lectures de geometrie
    # de la face plus bas utilisent donc `face_native` desormais.
    face_has_normal=False
    try:
        face_has_normal = hasattr(face_native.geometry,'normal')
    except Exception:
        face_has_normal = False
    use_cplane=False; cplane=None; sketch_ref=face_native
    if not face_has_normal:
        adj_normal=None; best_area=0
        try:
            for edge in face_native.edges:
                for adj in edge.faces:
                    if adj.entityToken==face_native.entityToken: continue
                    if adj.area>best_area and hasattr(adj.geometry,'normal'):
                        best_area=adj.area; adj_normal=adj.geometry.normal
        except: pass
        if adj_normal is not None:
            try:
                ref_pt=None
                for edge in face_native.edges:
                    if edge.startVertex: ref_pt=edge.startVertex.geometry; break
                if ref_pt:
                    cp=adsk.core.Plane.create(ref_pt,adj_normal)
                    cpi=parent_comp.constructionPlanes.createInput()
                    cpi.setByPlane(cp)
                    cplane=parent_comp.constructionPlanes.add(cpi)
                    cplane.isLightBulbOn=False; sketch_ref=cplane; use_cplane=True
            except: pass
    _lap('detection face adjacente / plan de construction')
    sk=parent_comp.sketches.add(sketch_ref); sk.name='Tenon'
    _lap('creation esquisse (sketches.add)')
    pts=_face_to_2d(face_native,sk)
    _lap('_face_to_2d')
    if len(pts)<2:
        if use_cplane and cplane: cplane.deleteMe()
        try: sk.deleteMe()
        except Exception: pass
        return 0,'Pas assez de points.'
    # Chant tourne dans le plan de l'esquisse (aretes non alignees sur X/Y) :
    # on travaille dans un repere local (a = le long de la plus longue arete,
    # b = en travers) et on dessine le rectangle de tenon tourne du meme
    # angle. to_sk(a,b) renvoie le point 2D de l'esquisse. Sans cela le
    # rectangle aligne sur X/Y debordait du chant -> 'Aucun profil'.
    rot_ang=None
    if not use_cplane:
        _ang=_face_long_edge_angle(face_native,sk)
        if _ang is not None:
            _r=abs(_ang)%(math.pi/2.0)
            if not (_r<1e-5 or (math.pi/2.0-_r)<1e-5):
                rot_ang=_ang
    if rot_ang is not None:
        _ca=math.cos(rot_ang); _sa=math.sin(rot_ang)
        def to_sk(a,b):
            return adsk.core.Point3D.create(a*_ca-b*_sa, a*_sa+b*_ca, 0)
        xs=[p[0]*_ca+p[1]*_sa for p in pts]
        ys=[-p[0]*_sa+p[1]*_ca for p in pts]
    else:
        xs=[p[0] for p in pts]; ys=[p[1] for p in pts]
    x_min,x_max=min(xs),max(xs); y_min,y_max=min(ys),max(ys)
    x_span=x_max-x_min; y_span=y_max-y_min
    if x_span>=y_span or rot_ang is not None:
        long_min,long_max,face_len,long_axis=x_min,x_max,x_span,'X'
        larg_min,larg_max=y_min,y_max
    else:
        long_min,long_max,face_len,long_axis=y_min,y_max,y_span,'Y'
        larg_min,larg_max=x_min,x_max
    if centrer:
        # Mode "Centrer" : la distance du bord n'est plus utilisee, seule
        # compte la place necessaire pour les `count` tenons eux-memes.
        if face_len<=count*tenon_len+1e-6:
            if use_cplane and cplane: cplane.deleteMe()
            try: sk.deleteMe()
            except Exception: pass
            return 0,f'Chant trop court ({face_len*10:.1f}mm) pour {count} tenon(s) de {tenon_len*10:.1f}mm.'
    elif face_len<=2.0*edge_dist+tenon_len+1e-6:
        if use_cplane and cplane: cplane.deleteMe()
        try: sk.deleteMe()
        except Exception: pass
        return 0,f'Chant trop court ({face_len*10:.1f}mm).'
    # Projection du chant pour ancrer les tenons dessus (voir
    # _project_chant_and_classify) - seulement en sketch-sur-face directe :
    # avec le plan de construction de secours (use_cplane, oriente selon la
    # normale d'une face ADJACENTE), la projection ne serait pas dans le
    # meme plan que le chant et donnerait des distances faussees.
    line_min = line_max = line_start = line_end = None
    if not use_cplane and rot_ang is None:
        line_min, line_max, line_start, line_end = _project_chant_and_classify(
            sk, face_native, long_axis, long_min, long_max, larg_min, larg_max)
    _lap('_project_chant_and_classify')
    half_l=tenon_len/2.0
    if centrer:
        # Repartition centree : on ignore "distance du bord" et on repartit
        # l'espace disponible (face_len - count*tenon_len) soit uniformement
        # entre TOUS les intervalles (marges + espaces entre tenons), soit
        # selon un pourcentage choisi par l'utilisateur pour les deux marges
        # de cote combinees (mode "Personnalise", ex. 33.3% -> 1/3 sur les
        # cotes, 2/3 reparti entre les tenons).
        total_leftover=max(0.0, face_len-count*tenon_len)
        if count<=1:
            margin=total_leftover/2.0; inter_gap=0.0
        elif repartition_mode=='personnalise':
            pct=repartition_cotes_pct
            try: pct=float(pct)
            except Exception: pct=33.3
            pct=max(0.0,min(100.0,pct))
            side_total=total_leftover*pct/100.0
            margin=side_total/2.0
            inter_gap=(total_leftover-side_total)/(count-1)
        else:
            gap=total_leftover/(count+1)
            margin=gap; inter_gap=gap
        long_start=long_min+margin+half_l
        spacing=tenon_len+inter_gap
        centers=[long_start+i*spacing for i in range(count)]
    else:
        long_start=long_min+edge_dist+half_l
        long_end_pos=long_max-edge_dist-half_l
        if long_start>=long_end_pos and count>1:
            if use_cplane and cplane: cplane.deleteMe()
            return 0,'Parametres incompatibles.'
        spacing=(long_end_pos-long_start)/(count-1) if count>1 else 0.0
        centers=[long_start+i*spacing for i in range(count)]
    intervals=[(t-half_l,t+half_l) for t in centers]
    dl=sk.sketchCurves.sketchLines
    all_rect_lines=[]
    for t_c in centers:
        hl=half_l
        if rot_ang is not None:
            rect_lines = dl.addThreePointRectangle(
                to_sk(t_c-hl,larg_min), to_sk(t_c+hl,larg_min), to_sk(t_c+hl,larg_max))
            all_rect_lines.append(list(rect_lines))
            continue
        if long_axis=='X':
            p1=adsk.core.Point3D.create(t_c-hl,larg_min,0)
            p2=adsk.core.Point3D.create(t_c+hl,larg_max,0)
        else:
            p1=adsk.core.Point3D.create(larg_min,t_c-hl,0)
            p2=adsk.core.Point3D.create(larg_max,t_c+hl,0)
        rect_lines = dl.addTwoPointRectangle(p1,p2)
        all_rect_lines.append(list(rect_lines))
        # NB : on n'ancre plus le rectangle au chant projete via des cotes/
        # contraintes (_anchor_rect_to_chant) - inutile desormais puisque
        # l'architecture "supprimer puis recreer" (recreate_all_tenons) ne
        # compte plus sur l'associativite de l'esquisse pour suivre le
        # panneau, et le solveur de contraintes pouvait legerement deplacer
        # le rectangle (cote redondante avec le collineaire, resolue a une
        # valeur infinitesimalement differente des coordonnees exactes
        # utilisees ci-dessus), faisant echouer la recherche de profil par
        # bounding-box ci-dessous ("Aucun profil") meme quand le rectangle
        # etait visuellement correct.
    _lap(f'dessin des {count} rectangle(s)')
    face_larg_span=abs(larg_max-larg_min); tol_size=1e-3
    tenon_profiles=adsk.core.ObjectCollection.create()
    for j in range(sk.profiles.count):
        prof=sk.profiles.item(j); bb=prof.boundingBox
        if rot_ang is not None:
            # Rectangle tourne : la boite englobante ne donne plus les
            # dimensions - on compare l'aire et on projette le centre
            # (= centre de la boite pour un rectangle) sur l'axe a.
            try: _ar=prof.areaProperties().area
            except Exception: continue
            if abs(_ar-tenon_len*face_larg_span)>1e-3*max(1.0,face_larg_span): continue
            _cx=(bb.minPoint.x+bb.maxPoint.x)/2.0; _cy=(bb.minPoint.y+bb.maxPoint.y)/2.0
            pc=_cx*_ca+_cy*_sa
            if not any((lo-tol_size)<=pc<=(hi+tol_size) for lo,hi in intervals): continue
            tenon_profiles.add(prof)
            continue
        w=abs(bb.maxPoint.x-bb.minPoint.x); h2=abs(bb.maxPoint.y-bb.minPoint.y)
        # Dimensions lues selon les axes de l'esquisse (et non max/min) :
        # sur un chant large (largeur > longueur du tenon, ex. face de
        # 75 mm avec tenon de 30 mm) max/min inversait les deux cotes et
        # aucun profil ne correspondait ('Aucun profil').
        ls=w if long_axis=='X' else h2
        la=h2 if long_axis=='X' else w
        if not (abs(ls-tenon_len)<tol_size and abs(la-face_larg_span)<tol_size): continue
        pc=(bb.minPoint.x+bb.maxPoint.x)/2.0 if long_axis=='X' else (bb.minPoint.y+bb.maxPoint.y)/2.0
        if not any((lo-tol_size)<=pc<=(hi+tol_size) for lo,hi in intervals): continue
        tenon_profiles.add(prof)
    _lap(f'recherche profils (sk.profiles.count={sk.profiles.count})')
    created=0; errs=[]
    if tenon_profiles.count==0: errs.append('Aucun profil')
    else:
        extr=parent_comp.features.extrudeFeatures
        dist=adsk.core.ValueInput.createByReal(tenon_h); done=False
        for flip in [False,True]:
            try:
                ei=extr.createInput(tenon_profiles,adsk.fusion.FeatureOperations.JoinFeatureOperation)
                ei.setDistanceExtent(flip,dist); ei.participantBodies=[face_native.body]
                ft=extr.add(ei); ft.name='Tenon'; created=tenon_profiles.count; done=True; break
            except Exception as ex: last_ex=ex
        _lap('extrusion')
        if not done: errs.append(f'Extrusion: {last_ex}')
        elif done:
            def _finish_constraints():
                parametrized = False
                if not use_cplane:
                    try:
                        parametrized = _parametrize_tenons(
                            sk, all_rect_lines, line_min, line_max, line_start, line_end,
                            long_axis, larg_min, larg_max, long_min, long_max,
                            centrer, repartition_mode, repartition_cotes_pct,
                            count, tenon_len, edge_dist)
                    except Exception:
                        _dbg('_parametrize_tenons EXCEPTION: ' + traceback.format_exc())
                        parametrized = False
                _lap(f'_parametrize_tenons (ok={parametrized})')
                if not parametrized:
                    _auto_constrain_tenon_sketch(sk)
                    _lap('_auto_constrain_tenon_sketch (repli)')
                    if rot_ang is not None:
                        # Chant tourne : pas de parametrage sur le contour du
                        # chant, mais les 2 traits de longueur du tenon
                        # restent perpendiculaires aux traits de largeur.
                        for _rl in all_rect_lines:
                            try:
                                sk.geometricConstraints.addPerpendicular(_rl[0], _rl[1])
                            except Exception:
                                pass
            # Mode batched (voir _create_tenon_bump_isolated) : l'esquisse et
            # l'extrusion sont supprimees juste apres le calcul du bossage,
            # donc parametrer/contraindre ici (~60% du temps de creation,
            # cf. "[perf] _parametrize_tenons") serait du travail jete. On
            # differe : l'appelant n'execute la closure que s'il doit garder
            # la feature reelle (repli mode 'real').
            if deferred_constraints is not None:
                deferred_constraints.append(_finish_constraints)
            else:
                _finish_constraints()
            if track_feats is not None: track_feats.append(ft.entityToken)
            if track_sketches is not None: track_sketches.append(sk.entityToken)
            if track_feat_objs is not None: track_feat_objs.append(ft)
            if track_sketch_objs is not None: track_sketch_objs.append(sk)
    if use_cplane and cplane:
        try: cplane.deleteMe()
        except: pass
    if created==0:
        # Ne pas laisser une esquisse orpheline (rectangles dessines mais
        # jamais extrudes) trainer dans l'arbre - confirme comme cause d'un
        # doublon lors d'un echec de recreation via 'Mettre a jour CNC'
        # (l'ancien tenon supprime, le nouveau rate, l'esquisse abandonnee
        # restait visible sans faire partie du corps).
        try: sk.deleteMe()
        except Exception: pass
    msg=f'{created}/{count} tenon(s) crees'
    if errs: msg+=f' - {errs}'
    _dbg(f'  [perf] TOTAL _create_tenons_on_face: {_time.time()-_t0:.2f}s')
    return created,msg


# ---------------------------------------------------------------------------
# APERCU LEGER (CustomGraphics) - voir _preview_cg_group plus haut.
#
# Principe : calculer UNIQUEMENT les positions des tenons/languette (meme
# calcul que _create_tenons_on_face/_create_languette_on_face) SANS jamais
# creer la moindre geometrie Fusion reelle (ni sketch, ni plan de
# construction, ni extrusion) - on dessine juste des traits (CustomGraphics)
# representant les volumes, dans la vue 3D. Contrairement a l'ancien apercu
# (qui creait/purgeait de la VRAIE matiere a chaque changement de parametre,
# d'ou la lenteur remontee par l'utilisateur), ce nouveau chemin ne declenche
# AUCUN recalcul du modele : juste du dessin, donc quasi instantane - voir
# CustomGraphicsGroup dans la doc API Fusion ("to Fusion they're just
# 'graphics' without any meaning").
#
# IMPORTANT : ce code est totalement INDEPENDANT de _create_tenons_on_face/
# _create_languette_on_face (utilisees UNIQUEMENT par _ExecuteHandler, donc
# au clic final sur "Creer" - jamais touchees ici). La geometrie REELLEMENT
# creee ne depend donc en rien de ce qui suit : en cas de bug dans l'apercu,
# le pire risque est un dessin visuellement faux ou absent, jamais une
# mauvaise creation reelle.
#
# Astuce cle qui simplifie enormement ce calcul par rapport a la creation
# reelle : la face selectionnee (`sel_faces`, filtre 'PlanarFaces') est un
# objet PROXY quand elle appartient a une occurrence - et pour un proxy,
# `.geometry` (le plan), comme `.edges`/`.vertices`, est deja exprime en
# coordonnees MONDE REELLES (meme fait etabli et deja exploite plus haut
# dans ce fichier pour face_native/occ_transform). On peut donc calculer
# entierement en coordonnees monde, sans jamais activer d'occurrence ni
# resoudre l'objet natif - le dessin final est ajoute tel quel au composant
# racine (transform identite), quel que soit le niveau d'imbrication de la
# face selectionnee.
def _face_plane_axes_world(face):
    """Origine/normale/axes U-V (tous unitaires, coordonnees MONDE) du plan
    d'une face plane - None si la face n'a pas de plan exploitable (ne
    devrait normalement jamais arriver ici puisque le selectionInput est
    filtre 'PlanarFaces', mais on reste defensif).

    CORRECTIF (bug remonte par l'utilisateur le 2026-10-07 : "dans les arrondis,
    les tenons se creent mal") - CONFIRME EN DIRECT par script (inspection
    directe de montants de la section courbe de TENON CNC) : sur un montant
    DROIT, face.geometry.uDirection/vDirection coincide par pur hasard avec
    les aretes reelles du chant (les deux sont alignees sur les axes
    globaux X/Y). Des que le montant est tourne pour suivre la courbe (tout
    angle hors des multiples de 90 degres), uDirection/vDirection RESTENT
    FIGES sur les axes GLOBAUX du plan sous-jacent (Plane.uDirection ne
    tourne PAS avec le corps - confirme : un montant tourne a ~46 degres
    donnait quand meme uDirection=(1,0,0) exact, alors que ses aretes
    reelles pointaient a (-0.69, 0.73, 0)). L'ancien code utilisait pourtant
    ces u/v figes pour mesurer l'etendue du chant (projection des sommets
    en u/v) : des que le chant est tourne, cette projection donne un
    rectangle englobant EXAGEREMENT GRAND et desaxe par rapport au chant
    reel - d'ou l'apercu de tenon visiblement desaxe/deforme observe sur
    les montants de la partie courbe.

    NOTE IMPORTANTE : la creation REELLE (_create_tenons_on_face/
    _create_languette_on_face) n'est PAS affectee par ce bug - elle utilise
    sk.xDirection/sk.yDirection d'une esquisse Fusion placee DIRECTEMENT
    sur la face (sketches.add(face)), et Fusion aligne alors CORRECTEMENT
    ces axes sur le chant reel, confirme en direct sur le meme montant
    tourne (sk.xDirection colle exactement a l'arete reelle, dot=1.0). Seul
    cet apercu (CustomGraphics, qui evite expres de creer un sketch par
    face pour rester rapide meme avec de nombreux chants selectionnes a la
    fois - voir l'optimisation de vitesse d'EntailleCNC pour un probleme
    similaire) avait besoin de ce correctif, pour refleter fidelement ce
    que la creation produira vraiment.

    On derive donc u a partir de la PLUS LONGUE arete reelle du contour de
    la face (sa direction, normalisee) plutot que du plan brut - v = normal
    x u (puis u = v x n pour re-orthogonaliser exactement) complete la base
    dans le plan de la face. Pour un chant rectangulaire simple (cas
    normal, meme fragmente par des tenons deja crees), la plus longue arete
    est toujours parallele a l'un des 2 grands cotes du rectangle, donc u/v
    obtenus ainsi coincident avec les aretes reelles quelle que soit la
    rotation du corps dans l'espace - et la logique existante plus bas (qui
    compare les etendues projetees en u/v pour decider quel axe est "long")
    reste inchangee et continue de fonctionner quel que soit celui des 2
    axes choisi comme reference ici."""
    try:
        geo = face.geometry
        n = geo.normal
        o = geo.origin
    except Exception:
        return None
    u = None
    best_len = -1.0
    try:
        for e in face.edges:
            try:
                sp = e.startVertex.geometry
                ep = e.endVertex.geometry
                dx, dy, dz = ep.x - sp.x, ep.y - sp.y, ep.z - sp.z
                length = (dx * dx + dy * dy + dz * dz) ** 0.5
                if length > best_len and length > 1e-9:
                    best_len = length
                    u = adsk.core.Vector3D.create(dx / length, dy / length, dz / length)
            except Exception:
                continue
    except Exception:
        pass
    if u is None:
        # Repli (face sans aretes exploitables - ne devrait normalement
        # jamais arriver sur un chant rectangulaire) : ancien comportement.
        try:
            u = geo.uDirection
        except Exception:
            return None
    try:
        v = n.crossProduct(u)
        if v.length < 1e-9:
            return None
        v.normalize()
        u = v.crossProduct(n)  # re-orthogonalise u exactement
        if u.length < 1e-9:
            return None
        u.normalize()
    except Exception:
        return None
    return o, n, u, v


def _world_point(origin, u, v, du, dv, normal=None, dn=0.0):
    x = origin.x + du*u.x + dv*v.x
    y = origin.y + du*u.y + dv*v.y
    z = origin.z + du*u.z + dv*v.z
    if normal is not None and dn:
        x += dn*normal.x; y += dn*normal.y; z += dn*normal.z
    return adsk.core.Point3D.create(x, y, z)


def _preview_outward_offset(face, origin, normal, eps=0.05):
    """Determine de quel cote de la face (le long de +normal ou -normal) se
    trouve le VIDE (donc le sens dans lequel un tenon depasserait vraiment
    de la matiere, visuellement) - pur test de lecture (pointContainment),
    aucune geometrie creee. Repli sur +normal si le test echoue/est ambigu
    (un apercu qui pointe dans le mauvais sens reste sans consequence : la
    creation reelle, elle, teste les deux sens et garde celui qui fonctionne -
    voir _create_tenons_on_face)."""
    try:
        body = face.body
        p_plus  = adsk.core.Point3D.create(origin.x+normal.x*eps, origin.y+normal.y*eps, origin.z+normal.z*eps)
        p_minus = adsk.core.Point3D.create(origin.x-normal.x*eps, origin.y-normal.y*eps, origin.z-normal.z*eps)
        c_plus  = body.pointContainment(p_plus)
        c_minus = body.pointContainment(p_minus)
        inside = adsk.fusion.PointContainment.PointInsidePointContainment
        if c_plus != inside and c_minus == inside:
            return 1.0
        if c_minus != inside and c_plus == inside:
            return -1.0
    except Exception:
        pass
    return 1.0


def _compute_preview_boxes_for_face(face, edge_dist, count, tenon_len, tenon_h,
                                     centrer=False, repartition_mode='uniforme',
                                     repartition_cotes_pct=33.3, is_languette=False,
                                     languette_h=1.2):
    """Calcule la liste des volumes (tenons, ou la languette unique) a
    afficher pour UNE face, sous forme de listes de 8 coins (Point3D, MONDE) -
    [4 coins "au ras du chant", 4 coins "en bout du tenon/languette"].
    Reprend le MEME calcul de positionnement que _create_tenons_on_face/
    _create_languette_on_face (bbox u/v, axe long, mode centre/reparti...),
    mais sans jamais dessiner de sketch ni extruder - voir l'entete de
    section plus haut. Retourne une liste vide si la face n'est pas
    exploitable (silencieux : un apercu manquant sur une face n'empeche
    jamais la creation reelle, qui a sa propre gestion d'erreur complete)."""
    axes = _face_plane_axes_world(face)
    if axes is None:
        return []
    origin, normal, u, v = axes
    try:
        pts_uv = []
        for edge in face.edges:
            for vtx in (edge.startVertex, edge.endVertex):
                if vtx is None: continue
                p = vtx.geometry
                dx, dy, dz = p.x-origin.x, p.y-origin.y, p.z-origin.z
                du = dx*u.x+dy*u.y+dz*u.z
                dv = dx*v.x+dy*v.y+dz*v.z
                pts_uv.append((du, dv))
    except Exception:
        return []
    if len(pts_uv) < 2:
        return []
    xs=[p[0] for p in pts_uv]; ys=[p[1] for p in pts_uv]
    x_min,x_max=min(xs),max(xs); y_min,y_max=min(ys),max(ys)
    x_span=x_max-x_min; y_span=y_max-y_min
    if x_span>=y_span:
        long_min,long_max,face_len,long_axis=x_min,x_max,x_span,'X'
        larg_min,larg_max=y_min,y_max
    else:
        long_min,long_max,face_len,long_axis=y_min,y_max,y_span,'Y'
        larg_min,larg_max=x_min,x_max

    dn = _preview_outward_offset(face, origin, normal)

    def _rect_uv(du0, du1, dv0, dv1):
        return [(du0,dv0), (du1,dv0), (du1,dv1), (du0,dv1)]

    def _box_from_uv_rect(corners_uv, height):
        bottom = [_world_point(origin,u,v,du,dv) for (du,dv) in corners_uv]
        top    = [_world_point(origin,u,v,du,dv,normal,dn*height) for (du,dv) in corners_uv]
        return bottom, top

    boxes = []
    if is_languette:
        if face_len <= 2*edge_dist + 1e-6:
            return []
        nln = long_min+edge_dist; nlx = long_max-edge_dist
        if long_axis=='X':
            corners = _rect_uv(nln, nlx, larg_min, larg_max)
        else:
            corners = _rect_uv(larg_min, larg_max, nln, nlx)
        boxes.append(_box_from_uv_rect(corners, languette_h))
        return boxes

    half_l = tenon_len/2.0
    if centrer:
        if face_len <= count*tenon_len + 1e-6:
            return []
        total_leftover = max(0.0, face_len-count*tenon_len)
        if count<=1:
            margin=total_leftover/2.0; inter_gap=0.0
        elif repartition_mode=='personnalise':
            pct=repartition_cotes_pct
            try: pct=float(pct)
            except Exception: pct=33.3
            pct=max(0.0,min(100.0,pct))
            side_total=total_leftover*pct/100.0
            margin=side_total/2.0
            inter_gap=(total_leftover-side_total)/(count-1)
        else:
            gap=total_leftover/(count+1)
            margin=gap; inter_gap=gap
        long_start=long_min+margin+half_l
        spacing=tenon_len+inter_gap
        centers=[long_start+i*spacing for i in range(count)]
    else:
        if face_len <= 2.0*edge_dist+tenon_len+1e-6:
            return []
        long_start=long_min+edge_dist+half_l
        long_end_pos=long_max-edge_dist-half_l
        if long_start>=long_end_pos and count>1:
            return []
        spacing=(long_end_pos-long_start)/(count-1) if count>1 else 0.0
        centers=[long_start+i*spacing for i in range(count)]

    for t_c in centers:
        if long_axis=='X':
            corners = _rect_uv(t_c-half_l, t_c+half_l, larg_min, larg_max)
        else:
            corners = _rect_uv(larg_min, larg_max, t_c-half_l, t_c+half_l)
        boxes.append(_box_from_uv_rect(corners, tenon_h))
    return boxes


def _clear_preview_graphics():
    """Supprime le groupe de graphiques legers affiche (s'il existe) -
    appele avant de redessiner (nouvelles valeurs) et a la fermeture de la
    commande (Creer OU Fermer/Annuler), pour ne jamais laisser un apercu
    trainer apres coup."""
    global _preview_cg_group
    try:
        if _preview_cg_group is not None:
            _preview_cg_group.deleteMe()
    except Exception:
        pass
    _preview_cg_group = None


def _draw_tenon_preview_graphics(faces, edge_dist, count, tenon_len, tenon_h,
                                  centrer, repartition_mode, repartition_cotes_pct,
                                  is_languette, languette_bord, languette_h, design):
    """Dessine l'apercu "trait leger" (CustomGraphics) pour toutes les faces
    donnees en un seul groupe - voir la section plus haut. Remplace
    systematiquement le groupe precedent (_clear_preview_graphics). Ne
    souleve jamais d'exception vers l'appelant (une erreur de dessin ne doit
    jamais empecher l'utilisateur de continuer a regler ses parametres)."""
    global _preview_cg_group
    _clear_preview_graphics()
    try:
        all_boxes = []
        for face in faces:
            if is_languette:
                all_boxes.extend(_compute_preview_boxes_for_face(
                    face, languette_bord, 1, 0, 0,
                    is_languette=True, languette_h=languette_h))
            else:
                all_boxes.extend(_compute_preview_boxes_for_face(
                    face, edge_dist, count, tenon_len, tenon_h,
                    centrer=centrer, repartition_mode=repartition_mode,
                    repartition_cotes_pct=repartition_cotes_pct))
        if not all_boxes:
            return
        coords_flat = []
        strip_lengths = []
        for bottom, top in all_boxes:
            # Boucle du bas (5 pts = 4 aretes), boucle du haut (5 pts = 4
            # aretes), puis 4 "montants" verticaux (2 pts chacun = 1 arete) -
            # 6 strips par volume, regroupes dans UN SEUL appel addLines
            # pour toutes les faces/tenons de l'apercu (voir vecStripLength).
            loop_b = [bottom[0], bottom[1], bottom[2], bottom[3], bottom[0]]
            loop_t = [top[0], top[1], top[2], top[3], top[0]]
            for pt in loop_b: coords_flat += [pt.x, pt.y, pt.z]
            strip_lengths.append(len(loop_b))
            for pt in loop_t: coords_flat += [pt.x, pt.y, pt.z]
            strip_lengths.append(len(loop_t))
            for i in range(4):
                coords_flat += [bottom[i].x, bottom[i].y, bottom[i].z,
                                 top[i].x, top[i].y, top[i].z]
                strip_lengths.append(2)
        root = design.rootComponent
        cg_group = root.customGraphicsGroups.add()
        coords = adsk.fusion.CustomGraphicsCoordinates.create(coords_flat)
        lines = cg_group.addLines(coords, [], True, strip_lengths)
        try:
            # Orange vif (demande explicite de l'utilisateur, remplace le
            # bleu d'origine) + trait plus epais (4.0 au lieu de 2.0) pour
            # rester bien visible sur la matiere grise par defaut de
            # Fusion - l'intensite/epaisseur initiale etait jugee trop
            # faible.
            lines.color = adsk.fusion.CustomGraphicsSolidColorEffect.create(
                adsk.core.Color.create(255, 90, 0, 255))
            lines.weight = 2.0          # affine a 2.0 (demande du 2026-11-04 : traits trop gros)
        except Exception:
            pass
        _preview_cg_group = cg_group
    except Exception:
        _dbg('ERREUR _draw_tenon_preview_graphics: ' + traceback.format_exc())
        _clear_preview_graphics()


def _face_signature(face):
    p = face.geometry; n = p.normal; o = p.origin
    return (round(n.x,4),round(n.y,4),round(n.z,4),
            round(o.x,4),round(o.y,4),round(o.z,4))


def _find_face_by_signature(body, sig):
    for face in body.faces:
        try:
            if not hasattr(face.geometry,'normal'): continue
            if _face_signature(face) == sig: return face
        except: pass
    return None


# ===========================================================================
# CNC TOOLKIT - panneau integre (voir ToolkitCNC.py/palette.html) : au lieu
# d'ouvrir la boite de dialogue Fusion native de Tenons CNC, CNC Toolkit
# affiche directement dans sa palette HTML un panneau de creation avec un
# preview SVG live (demande explicite de l'utilisateur, inspire de l'add-in
# tiers "Tab & Slot"). Les 3 fonctions ci-dessous sont les points d'entree
# PURS (aucune dependance a une boite de dialogue/CommandInputs) que
# ToolkitCNC.py appelle via _find_module('TenonCNC') :
#   - compute_tenon_layout_1d : calcule les segments 1D (pour dessiner le
#     SVG cote JavaScript, TOUJOURS avec le meme calcul que la creation
#     reelle - jamais de formule dupliquee/divergente en JS).
#   - _face_len_for_preview : mesure la longueur d'un chant selectionne.
#   - create_tenons_core : cree reellement les tenons/languette, identique
#     dans son resultat a ce que fait _ExecuteHandler (boite de dialogue
#     native, toujours disponible telle quelle, ex. via la recherche de
#     commande Fusion) - duplique volontairement plutot que factorise pour
#     ne jamais risquer de casser la boite de dialogue existante, deja
#     testee en conditions reelles.
# ===========================================================================

def compute_tenon_layout_1d(face_len, mode, count, tenon_len, tenon_h,
                             languette_bord, languette_h, edge_dist,
                             centrer, repartition_mode, repartition_cotes_pct):
    """Calcule le placement 1D (le long d'un chant de longueur `face_len`,
    en cm) des tenons ou de la languette, SANS aucune geometrie Fusion -
    reprend EXACTEMENT le meme calcul que _compute_preview_boxes_for_face
    (voir plus haut) pour le positionnement, mais retourne de simples
    segments 1D. Utilise par CNC Toolkit pour dessiner le preview SVG dans
    la palette.

    Retourne {'ok': bool, 'reason': str|None, 'is_languette': bool,
              'segments': [{'start': float, 'width': float, 'height': float}, ...]}
    (start/width/height en cm, 'start' compte depuis le debut du chant)."""
    is_lang = (mode == 'languette')
    if is_lang:
        if face_len <= 2*languette_bord + 1e-6:
            return {'ok': False, 'reason': 'chant_trop_court', 'is_languette': True, 'segments': []}
        seg_start = languette_bord
        seg_width = face_len - 2*languette_bord
        return {'ok': True, 'reason': None, 'is_languette': True,
                'segments': [{'start': seg_start, 'width': seg_width, 'height': languette_h}]}

    half_l = tenon_len/2.0
    if centrer:
        if face_len <= count*tenon_len + 1e-6:
            return {'ok': False, 'reason': 'chant_trop_court', 'is_languette': False, 'segments': []}
        total_leftover = max(0.0, face_len-count*tenon_len)
        if count <= 1:
            margin = total_leftover/2.0; inter_gap = 0.0
        elif repartition_mode == 'personnalise':
            pct = repartition_cotes_pct
            try: pct = float(pct)
            except Exception: pct = 33.3
            pct = max(0.0, min(100.0, pct))
            side_total = total_leftover*pct/100.0
            margin = side_total/2.0
            inter_gap = (total_leftover-side_total)/(count-1)
        else:
            gap = total_leftover/(count+1)
            margin = gap; inter_gap = gap
        long_start = margin+half_l
        spacing = tenon_len+inter_gap
        centers = [long_start+i*spacing for i in range(count)]
    else:
        if face_len <= 2.0*edge_dist+tenon_len+1e-6:
            return {'ok': False, 'reason': 'chant_trop_court', 'is_languette': False, 'segments': []}
        long_start = edge_dist+half_l
        long_end_pos = face_len-edge_dist-half_l
        if long_start >= long_end_pos and count > 1:
            return {'ok': False, 'reason': 'chant_trop_court', 'is_languette': False, 'segments': []}
        spacing = (long_end_pos-long_start)/(count-1) if count > 1 else 0.0
        centers = [long_start+i*spacing for i in range(count)]

    segments = [{'start': c-half_l, 'width': tenon_len, 'height': tenon_h} for c in centers]
    return {'ok': True, 'reason': None, 'is_languette': False, 'segments': segments}


def _face_len_for_preview(face):
    """Longueur du chant (la plus grande des deux dimensions de la face
    dans son plan), en cm - reprend le meme calcul que
    _compute_preview_boxes_for_face (bbox u/v de la face). Retourne None
    si la face n'est pas exploitable."""
    axes = _face_plane_axes_world(face)
    if axes is None:
        return None
    origin, normal, u, v = axes
    try:
        pts_uv = []
        for edge in face.edges:
            for vtx in (edge.startVertex, edge.endVertex):
                if vtx is None: continue
                p = vtx.geometry
                dx, dy, dz = p.x-origin.x, p.y-origin.y, p.z-origin.z
                du = dx*u.x+dy*u.y+dz*u.z
                dv = dx*v.x+dy*v.y+dz*v.z
                pts_uv.append((du, dv))
    except Exception:
        return None
    if len(pts_uv) < 2:
        return None
    xs = [p[0] for p in pts_uv]; ys = [p[1] for p in pts_uv]
    return max(max(xs)-min(xs), max(ys)-min(ys))


# ---------------------------------------------------------------------------
# Regroupement PAR CORPS des tenons/languettes crees en un seul lot (demande
# explicite de l'utilisateur : "je veux absolument pouvoir faire CTRL Z une seule
# fois pour supprimer un tenon ou une entaille, sans devoir le faire 50 fois"
# - Tenons CNC creait jusqu'ici 1 esquisse + 1 extrusion PAR CHANT, donc
# jusqu'a 2 x (nombre de chants) etapes Ctrl+Z pour un seul lot). Principe
# (meme famille de technique que le regroupement deja fait pour EntailleCNC) :
#   1) _create_tenon_bump_isolated appelle _create_tenons_on_face /
#      _create_languette_on_face EXACTEMENT comme avant (calcul geometrique
#      totalement inchange - c'est lui qui est teste/fiabilise depuis
#      longtemps), puis isole la matiere ajoutee (difference booleenne
#      TEMPORAIRE) et supprime la feature+esquisse REELLES qui viennent
#      d'etre creees : le corps revient a son etat d'avant, le bossage
#      isole est garde en memoire.
#   2) _commit_tenon_bumps_for_body fusionne TOUS les bossages d'UN MEME
#      corps en une seule insertion groupee (_insert_real_bodies_grouped)
#      + une seule CombineFeature (Join) - 2 etapes Ctrl+Z par CORPS entier
#      au lieu de 2 par CHANT.
# La CombineFeature est nommee 'Tenon' (voir sa docstring) : c'est le nom
# exact que MortaiseCNC._tenon_feature_planes et
# MargeCNC._tenon_feature_face_tokens recherchent (boucle generique sur
# comp.features, confirmee en direct compatible avec N'IMPORTE QUEL type de
# feature) pour la detection automatique des mortaises/jeux - aucune
# modification necessaire dans ces deux autres add-ins.
# ---------------------------------------------------------------------------

def _create_tenon_bump_isolated(face, is_lang, create_kwargs, design):
    """Cree un tenon/languette sur `face` exactement comme avant (voir
    _create_tenons_on_face/_create_languette_on_face, calcul geometrique
    inchange), puis isole la matiere ajoutee et supprime la feature+esquisse
    REELLES qui viennent d'etre creees pour que l'appelant puisse les
    regrouper plus tard avec d'autres chants du MEME corps (voir
    _commit_tenon_bumps_for_body).

    Si l'isolement ou la suppression echoue pour une raison quelconque, on
    NE PREND AUCUN RISQUE : la feature/esquisse reelle est laissee en place
    telle quelle (comme avant cette fonctionnalite) plutot que de perdre le
    tenon ou de laisser le document dans un etat incoherent - l'appelant le
    detecte via mode='real' et enregistre feat_objs/sketch_objs normalement
    (ancien format - _delete_tenons_for_face_keys gere deja un melange de
    formats sans distinction, cle par cle).

    Retourne {'cnt': int, 'msg': str, 'mode': 'batched'|'real'|'none',
    'bump': BRepBody temporaire ou None, 'feat_objs': [...], 'sketch_objs': [...]}."""
    tbm = adsk.fusion.TemporaryBRepManager.get()
    body = face.body
    # Mode esquisse par defaut (decision l'utilisateur 2026-10-07) : l'esquisse +
    # extrusion reelle reste en place et suit le corps quand on le deplace.
    # Le bossage fige (plus rapide sur les gros lots) n'est utilise qu'avec
    # la case "Mode rapide (fige)".
    rapide = bool(create_kwargs.get('rapide', False))
    original_copy = None
    if rapide:
        try:
            original_copy = tbm.copy(body)
        except Exception:
            original_copy = None

    # NB : on utilise track_feat_objs/track_sketch_objs (les VRAIS objets
    # Feature/Sketch), pas track_feats/track_sketches (qui ne collectent
    # que leurs entityToken, des chaines) - il faut pouvoir appeler
    # .deleteMe() dessus juste apres (voir plus bas).
    ft = []; st = []
    # Contraintes/parametrage differes : inutiles tant que la feature reelle
    # va etre supprimee (mode batched), executes seulement en repli 'real'.
    deferred = []
    if is_lang:
        cnt, msg = _create_languette_on_face(
            face, create_kwargs['edge_dist'], create_kwargs['languette_h'], design,
            track_feat_objs=ft, track_sketch_objs=st,
            deferred_constraints=deferred)
    else:
        cnt, msg = _create_tenons_on_face(
            face, create_kwargs['edge_dist'], create_kwargs['count'],
            create_kwargs['tenon_len'], create_kwargs['tenon_h'], design,
            track_feat_objs=ft, track_sketch_objs=st,
            centrer=create_kwargs.get('centrer', False),
            repartition_mode=create_kwargs.get('repartition_mode', 'uniforme'),
            repartition_cotes_pct=create_kwargs.get('repartition_cotes_pct', 33.3),
            deferred_constraints=deferred)

    def _run_deferred():
        for fn in deferred:
            try: fn()
            except Exception: _dbg('deferred constraints EXCEPTION: ' + traceback.format_exc())

    if not cnt:
        return {'cnt': 0, 'msg': msg, 'mode': 'none', 'bump': None, 'feat_objs': [], 'sketch_objs': []}
    if original_copy is None:
        _run_deferred()
        return {'cnt': cnt, 'msg': msg, 'mode': 'real', 'bump': None, 'feat_objs': ft, 'sketch_objs': st}

    bump = None
    try:
        snapshot = tbm.copy(body)
        bump = tbm.copy(snapshot)
        if not tbm.booleanOperation(bump, tbm.copy(original_copy),
                                     adsk.fusion.BooleanTypes.DifferenceBooleanType):
            bump = None
        elif bump.faces.count == 0:
            bump = None
    except Exception:
        bump = None
    if bump is None:
        _run_deferred()
        return {'cnt': cnt, 'msg': msg, 'mode': 'real', 'bump': None, 'feat_objs': ft, 'sketch_objs': st}

    reverted = True
    # Ordre inverse de creation (extrusion avant esquisse) - une esquisse ne
    # peut pas etre supprimee tant qu'une feature en consomme un profil.
    for f in reversed(ft):
        try:
            f.deleteMe()
        except Exception:
            reverted = False
    for s in reversed(st):
        try:
            s.deleteMe()
        except Exception:
            reverted = False
    if not reverted:
        # Restes valides seulement : on ne parametre que si leurs objets existent encore.
        _run_deferred()
        return {'cnt': cnt, 'msg': msg, 'mode': 'real', 'bump': None, 'feat_objs': ft, 'sketch_objs': st}

    return {'cnt': cnt, 'msg': msg, 'mode': 'batched', 'bump': bump, 'feat_objs': [], 'sketch_objs': []}


def _insert_real_bodies_grouped(design, root, temp_bodies):
    """Insere PLUSIEURS corps transitoires (TemporaryBRepManager) dans UNE
    SEULE BaseFeature reelle (une seule entree d'historique pour tous), meme
    technique que EntailleCNC._insert_real_bodies (voir sa docstring pour le
    piege ALL_TOOL_BODY_REFERENCE_LOST deja rencontre - BaseFeature.
    startEdit/add/finishEdit, Design.computeAll + adsk.doEvents, puis
    relecture via BaseFeature.bodies, JAMAIS la reference retournee
    directement par bRepBodies.add()).

    Retourne (results, base_feat) : results a la MEME LONGUEUR que
    temp_bodies (None a la position d'un echec individuel), base_feat
    l'objet BaseFeature cree (ou None si meme la creation de la
    BaseFeature a echoue)."""
    n = len(temp_bodies)
    if n == 0:
        return [], None
    try:
        base_feat = root.features.baseFeatures.add()
        base_feat.startEdit()
    except Exception:
        return [None] * n, None
    added_flags = []
    try:
        for tb in temp_bodies:
            ok = False
            try:
                root.bRepBodies.add(tb, base_feat)
                ok = True
            except Exception:
                ok = False
            added_flags.append(ok)
    finally:
        try:
            base_feat.finishEdit()
        except Exception:
            pass
    try:
        design.computeAll()
    except Exception:
        pass
    try:
        adsk.doEvents()
    except Exception:
        pass
    try:
        count = base_feat.bodies.count
    except Exception:
        count = 0
    results = []
    idx = 0
    for ok in added_flags:
        if ok and idx < count:
            try:
                results.append(base_feat.bodies.item(idx))
            except Exception:
                results.append(None)
            idx += 1
        else:
            results.append(None)
    return results, base_feat


def _commit_tenon_bumps_for_body(design, root, body, bumps):
    """Insere TOUS les bossages (`bumps`, corps TemporaryBRepManager isoles
    par _create_tenon_bump_isolated) de CE corps en UNE SEULE insertion
    groupee (_insert_real_bodies_grouped) puis les fusionne dans `body` via
    UNE SEULE CombineFeature (Join, isKeepToolBodies=False) nommee 'Tenon'
    (voir le commentaire d'en-tete de cette section - nom exact attendu par
    MortaiseCNC/MargeCNC). Tague aussi la CombineFeature et la BaseFeature
    d'un attribut ('TenonCNC','batch_body_name') pour que 'Mettre a jour
    CNC' puisse les retrouver plus tard par ce corps (voir
    _delete_tenon_batch_for_body) sans dependre d'un token potentiellement
    invalide par d'autres etapes de mise a jour (mortaises/marges) entre-
    temps - meme precaution que _delete_old_tenon_geometry_by_plane pour
    l'ancien format.

    Retourne (combine_feat, base_feat), ou (None, None) en cas d'echec total
    (aucun bossage insere/combine - l'appelant doit alors traiter tous les
    chants de ce corps en repli, non groupe)."""
    if not bumps:
        return None, None
    inserted, base_feat = _insert_real_bodies_grouped(design, root, bumps)
    real_bumps = [b for b in inserted if b is not None]
    if not real_bumps:
        if base_feat is not None:
            try:
                base_feat.deleteMe()
            except Exception:
                pass
        return None, None
    combine_feat = None
    try:
        combines = root.features.combineFeatures
        col = adsk.core.ObjectCollection.create()
        for b in real_bumps:
            col.add(b)
        ci = combines.createInput(body, col)
        ci.operation = adsk.fusion.FeatureOperations.JoinFeatureOperation
        ci.isKeepToolBodies = False
        combine_feat = combines.add(ci)
        combine_feat.name = 'Tenon'
    except Exception:
        combine_feat = None
    if combine_feat is None:
        try:
            base_feat.deleteMe()
        except Exception:
            pass
        return None, None
    try:
        body_name = body.name
    except Exception:
        body_name = None
    if body_name:
        for feat_obj in (combine_feat, base_feat):
            try:
                feat_obj.attributes.add('TenonCNC', 'batch_body_name', body_name)
            except Exception:
                pass
    return combine_feat, base_feat


def _commit_tenon_bumps_globally(dsgn, root, pending_by_body):
    """Variante GLOBALE de _commit_tenon_bumps_for_body : insere TOUS les
    bossages de TOUS LES CORPS de `pending_by_body` en UNE SEULE insertion
    groupee (_insert_real_bodies_grouped), donc UN SEUL design.computeAll()
    pour le lot ENTIER, puis fait UNE CombineFeature (Join) par corps (ca,
    en revanche, ca ne peut pas etre regroupe davantage : chaque Join
    fusionne un jeu de bossages dans UN corps cible precis).

    Avant ce changement, _commit_tenon_bumps_for_body etait appelee UNE FOIS
    PAR CORPS, donc UN computeAll() PAR CORPS - mesure en direct (script de
    diagnostic, voir tenon_debug.log) a environ 1.2 a 1.4s PAR CORPS sur le
    document de test, independamment du temps de creation reelle du tenon
    (~0.3s, deja instrumente) - avec 20-30 corps distincts (un chant par
    montant, cas signale par l'utilisateur), ce cout se multiplie et
    provoque le ralentissement/risque de crash observe, exactement la meme
    classe de probleme que celui deja corrige dans EntailleCNC
    (create_entaille_core_multi / precomputed_real_bodies). En regroupant
    TOUS les corps dans UNE SEULE insertion, ce cout devient O(1) pour tout
    le lot au lieu de O(nombre de corps).

    `pending_by_body` : dict body_token -> {'body': BRepBody, 'items': [...]}
    (meme format que dans create_tenons_core / le gestionnaire de commande),
    seul `'body'` et la liste des bumps (4e element de chaque tuple 'items')
    sont utilises ici.

    Retourne dict body_token -> (combine_feat, base_feat) ; (None, None)
    pour un corps precis si SON Join a echoue (le bossage reste alors
    recuperable par l'appelant via le repli non groupe existant), meme si
    d'autres corps du meme lot ont reussi."""
    all_bumps = []
    body_slices = []  # (body_token, body, start, end)
    for _body_tok, _pending in pending_by_body.items():
        _bumps = [it[3] for it in _pending['items']]
        if not _bumps:
            continue
        start = len(all_bumps)
        all_bumps.extend(_bumps)
        body_slices.append((_body_tok, _pending['body'], start, len(all_bumps)))

    results_by_token = {}
    if not all_bumps:
        return results_by_token

    inserted, base_feat = _insert_real_bodies_grouped(dsgn, root, all_bumps)

    any_combined = False
    for _body_tok, _body, start, end in body_slices:
        real_bumps = [b for b in inserted[start:end] if b is not None]
        if not real_bumps:
            results_by_token[_body_tok] = (None, None)
            continue
        combine_feat = None
        try:
            combines = root.features.combineFeatures
            col = adsk.core.ObjectCollection.create()
            for b in real_bumps:
                col.add(b)
            ci = combines.createInput(_body, col)
            ci.operation = adsk.fusion.FeatureOperations.JoinFeatureOperation
            ci.isKeepToolBodies = False
            combine_feat = combines.add(ci)
            combine_feat.name = 'Tenon'
        except Exception:
            combine_feat = None
        if combine_feat is not None:
            any_combined = True
            try:
                body_name = _body.name
            except Exception:
                body_name = None
            if body_name:
                for feat_obj in (combine_feat, base_feat):
                    try:
                        feat_obj.attributes.add('TenonCNC', 'batch_body_name', body_name)
                    except Exception:
                        pass
        results_by_token[_body_tok] = (combine_feat, base_feat)

    # Si AUCUN corps n'a pu etre combine, la BaseFeature partagee est
    # inutile - on la supprime pour ne pas polluer l'historique (repli
    # complet vers la creation non groupee, gere par l'appelant).
    if not any_combined and base_feat is not None:
        try:
            base_feat.deleteMe()
        except Exception:
            pass

    return results_by_token


def create_tenons_core(dsgn, faces, mode, edge_dist, count, tenon_len, tenon_h,
                        languette_bord, languette_h, centrer, repartition_mode,
                        repartition_cotes_pct, mortaise_auto, marge_auto, rapide=None):
    """Coeur de la creation reelle des tenons/languette sur une liste de
    faces DEJA RESOLUES, avec des parametres DEJA LUS (pas de CommandInputs
    ici) - appele depuis CNC Toolkit (panneau HTML). Reproduit fidelement
    ce que fait _ExecuteHandler (boite de dialogue native) : creation sur
    chaque face, enregistrement dans tenon_face_map.json, groupement
    timeline 'Tenons CNC', puis MortaiseAuto/MargeAuto.

    Retourne {'n_faces_ok': int, 'n_faces_total': int,
              'mortaise_nb_ok': int|None, 'mortaise_nb_skip': int|None,
              'marge_n_faces': int|None, 'messages': [str, ...]}."""
    is_lang = (mode == 'languette')
    tl = dsgn.timeline
    start_index = tl.markerPosition
    messages = []
    _touched_male_tokens = set()
    n_ok = 0

    if faces:
        _touched_comps = {}
        _pending_by_body = {}  # body_token -> {'body': BRepBody, 'items': [(face, face_key, spec, bump), ...]}
        if is_lang:
            _kwargs = {'edge_dist': languette_bord, 'languette_h': languette_h}
        else:
            _kwargs = {'edge_dist': edge_dist, 'count': count, 'tenon_len': tenon_len,
                       'tenon_h': tenon_h, 'centrer': centrer,
                       'repartition_mode': repartition_mode,
                       'repartition_cotes_pct': repartition_cotes_pct}
        # Mode rapide (fige) retire du panneau le 2026-10-07 a la demande de
        # l'utilisateur : esquisse toujours, sauf appel explicite rapide=True.
        _kwargs['rapide'] = bool(rapide)
        cnc_progress.etape('Tenons : dessin sur les chants...', 0, len(faces))
        for _fi, face in enumerate(faces):
            cnc_progress.avance()
            try:
                _face_key = None
                _comp = None
                _spec = None
                _body_tok = None
                try:
                    _comp = face.body.parentComponent
                    _face_key = _face_map_key(_comp, face)
                    # Cle UNIQUE par creation (2026-10-06) : le plan seul se partageait
                    # entre chants coplanaires de corps differents (lattes alignees),
                    # l'un ecrasait l'autre et la mise a jour recreait au mauvais endroit.
                    _face_key += '|' + face.body.name + '|' + _uuid.uuid4().hex[:8]
                    _body_tok = face.body.entityToken
                except Exception as _e:
                    _dbg(f'[ToolkitCNC] face[{_fi}] erreur calcul cle AVANT creation: {_e}')
                try:
                    if _comp is not None:
                        _n = face.geometry.normal; _o = face.geometry.origin
                        _offset = _o.x*_n.x + _o.y*_n.y + _o.z*_n.z
                        if is_lang:
                            _params = {'edge_dist_mm': round(languette_bord*10, 4),
                                       'languette_h_mm': round(languette_h*10, 4)}
                            _mode = 'languette'
                        else:
                            _params = {'edge_dist_mm': round(edge_dist*10, 4),
                                       'tenon_count': count,
                                       'tenon_len_mm': round(tenon_len*10, 4),
                                       'tenon_h_mm': round(tenon_h*10, 4),
                                       'centrer': centrer,
                                       'repartition_mode': repartition_mode,
                                       'repartition_cotes_pct': repartition_cotes_pct}
                            _mode = 'tenon'
                        try:
                            _extreme = _classify_extreme(face.body, (_n.x, _n.y, _n.z), _offset)
                        except Exception:
                            _extreme = None
                        _spec = {
                            'mode': _mode,
                            'params': _params,
                            'body_token': face.body.entityToken,
                            'body_name': face.body.name,
                            'comp_token': _comp.entityToken,
                            'plane': [round(_n.x,6), round(_n.y,6), round(_n.z,6), round(_offset,6)],
                            'extreme': _extreme,
                            'tracked': True,
                        }
                except Exception as _e:
                    _dbg(f'[ToolkitCNC] face[{_fi}] erreur calcul spec AVANT creation: {_e}')
                if _comp is not None:
                    _touched_comps[_comp.entityToken] = _comp
                _tag_chant_face(face, _face_key)
                _res = _create_tenon_bump_isolated(face, is_lang, _kwargs, dsgn)
                _cnt = _res['cnt']; _msg = _res['msg']
                _dbg(f"[ToolkitCNC] face[{_fi}] -> cnt={_cnt} msg={_msg} mode={_res['mode']}")
                if _cnt and _res['mode'] == 'batched':
                    _pending = _pending_by_body.setdefault(_body_tok, {'body': face.body, 'items': []})
                    _pending['items'].append((face, _face_key, _spec, _res['bump']))
                    n_ok += 1
                elif _cnt:
                    # Repli (voir _create_tenon_bump_isolated) : feature/
                    # esquisse reelle laissee en place, ancien format.
                    _record_face_tenons_by_key(
                        _face_key,
                        [f.entityToken for f in _res['feat_objs']],
                        [s.entityToken for s in _res['sketch_objs']],
                        spec=_spec)
                    for _f in _res['feat_objs']:
                        _tag_feature_keys(_f, [_face_key])
                    n_ok += 1
                    if _body_tok:
                        _touched_male_tokens.add(_body_tok)
                elif _msg:
                    messages.append(f'Chant {_fi+1} : {_msg}')
            except Exception as _e:
                _dbg('[ToolkitCNC] face EXCEPTION: ' + traceback.format_exc())
                messages.append(f'Chant {_fi+1} : erreur ({_e})')

        # Commit GLOBAL (voir _commit_tenon_bumps_globally) : UNE SEULE
        # insertion groupee (donc un seul design.computeAll()) pour TOUS les
        # corps du lot, puis une CombineFeature par corps - au lieu d'une
        # insertion + computeAll() par corps (l'ancien comportement, mesure
        # a ~1.2-1.4s/corps, ce qui faisait exploser le temps total et
        # risquait de planter Fusion avec 20-30 corps distincts, cf. demande
        # l'utilisateur). C'est aussi ce qui reduit le nombre d'etapes Ctrl+Z.
        _root = dsgn.rootComponent
        cnc_progress.etape('Tenons : insertion dans le modele...')
        _commit_results = _commit_tenon_bumps_globally(dsgn, _root, _pending_by_body)
        for _body_tok, _pending in _pending_by_body.items():
            _body = _pending['body']
            _items = _pending['items']
            _combine_feat, _base_feat = _commit_results.get(_body_tok, (None, None))
            if _combine_feat is not None:
                _shared_tokens = [_combine_feat.entityToken, _base_feat.entityToken]
                for _face, _face_key, _spec, _bump in _items:
                    _record_face_tenons_by_key(_face_key, _shared_tokens, [], spec=_spec)
                _tag_feature_keys(_combine_feat, [_it[1] for _it in _items])
                try:
                    _fresh_tok = _body.entityToken
                except Exception:
                    _fresh_tok = _body_tok
                if _fresh_tok:
                    _touched_male_tokens.add(_fresh_tok)
            else:
                # Echec total du commit groupe (tres rare - voir
                # _commit_tenon_bumps_for_body) : on NE PERD AUCUN tenon, on
                # recree reellement (non groupe, ancien format) chaque chant
                # de ce corps - la geometrie du chant n'a pas change puisque
                # _create_tenon_bump_isolated a deja tout remis en l'etat.
                _dbg(f'[ToolkitCNC] commit groupe ECHEC pour corps {_body_tok} - '
                     f'repli non groupe sur {len(_items)} chant(s)')
                for _face, _face_key, _spec, _bump in _items:
                    _ft2 = []; _st2 = []
                    if is_lang:
                        _cnt2, _msg2 = _create_languette_on_face(
                            _face, _kwargs['edge_dist'], _kwargs['languette_h'], dsgn,
                            track_feats=_ft2, track_sketches=_st2)
                    else:
                        _cnt2, _msg2 = _create_tenons_on_face(
                            _face, _kwargs['edge_dist'], _kwargs['count'], _kwargs['tenon_len'],
                            _kwargs['tenon_h'], dsgn, track_feats=_ft2, track_sketches=_st2,
                            centrer=_kwargs.get('centrer', False),
                            repartition_mode=_kwargs.get('repartition_mode', 'uniforme'),
                            repartition_cotes_pct=_kwargs.get('repartition_cotes_pct', 33.3))
                    if _cnt2:
                        _record_face_tenons_by_key(
                            _face_key, [f.entityToken for f in _ft2], [s.entityToken for s in _st2], spec=_spec)
                        if _body_tok:
                            _touched_male_tokens.add(_body_tok)
                    else:
                        messages.append(f'Chant (repli apres echec de regroupement) : {_msg2}')

        try:
            _a  = adsk.core.Application.get()
            _tb = {}
            for _ci, _c in _touched_comps.items():
                _tb[_ci] = []
                for _k in range(_c.sketches.count):
                    _s = _c.sketches.item(_k)
                    if _s.name == 'Tenon' or _s.name.startswith('Tenon ('):
                        _tb[_ci].append(_s.entityToken)
            for _ci, _toks in _tb.items():
                if _toks:
                    _a.executeTextCommand('Sketch.MoveToNewSketchFolder ' + ' '.join(_toks))
        except: pass

    mortaise_nb_ok = mortaise_nb_skip = None
    marge_n_faces = None
    if mortaise_auto and _touched_male_tokens:
        cnc_progress.etape('Mortaises automatiques...')
        try:
            males = []
            for _tok in _touched_male_tokens:
                _found = dsgn.findEntityByToken(_tok)
                _mb = adsk.fusion.BRepBody.cast(_found[0]) if _found else None
                if _mb: males.append(_mb)
            MortaiseCNC = _find_module('MortaiseCNC')
            if MortaiseCNC is None:
                _dbg('[ToolkitCNC] MortaiseAuto: module MortaiseCNC introuvable (add-in inactif)')
                messages.append('MortaiseAuto : add-in "Mortaise CNC" inactif - aucune mortaise creee.')
            elif not males:
                _dbg('[ToolkitCNC] MortaiseAuto: aucun corps male resolu depuis les tokens, abandon')
            else:
                male_tokens = {m.entityToken for m in males}
                _root = dsgn.rootComponent
                _comps = [_root]
                _seen_comp = {_root.entityToken}
                for _occ in _root.allOccurrences:
                    _c = _occ.component
                    if _c.entityToken not in _seen_comp:
                        _seen_comp.add(_c.entityToken)
                        _comps.append(_c)
                femelles = []
                _seen_body = set()
                for _comp in _comps:
                    for _fb in _comp.bRepBodies:
                        try:
                            _tok = _fb.entityToken
                            if _tok in male_tokens or _tok in _seen_body:
                                continue
                            _seen_body.add(_tok)
                            femelles.append(_fb)
                        except Exception:
                            pass
                if not femelles:
                    _dbg('[ToolkitCNC] MortaiseAuto: aucun corps femelle candidat dans le design')
                else:
                    _nb_ok, _nb_skip, _merrs, _new_records = MortaiseCNC.creer_mortaises(
                        males, femelles, dsgn.rootComponent)
                    mortaise_nb_ok, mortaise_nb_skip = _nb_ok, _nb_skip
                    if _nb_ok == 0:
                        messages.append('MortaiseAuto : aucun corps femelle en contact detecte automatiquement.')
                    else:
                        messages.append(f'MortaiseAuto : {_nb_ok} mortaise(s) creee(s).')

                    if marge_auto and _new_records:
                        try:
                            MargeCNC = _find_module('MargeCNC')
                            if MargeCNC is None:
                                _dbg('[ToolkitCNC] MargeAuto: module MargeCNC introuvable (add-in inactif)')
                                messages.append('MargeAuto : add-in "Marge CNC" inactif - aucun jeu applique.')
                            else:
                                _jeu_cm, _jeu_actif, _exclure_fond = MargeCNC.load_settings()
                                if not _jeu_actif:
                                    messages.append('MargeAuto : "Appliquer le jeu" est desactive dans Marge CNC.')
                                else:
                                    _gfeat, _gn = MargeCNC.apply_jeu_to_tokens(
                                        dsgn, dsgn.rootComponent, _new_records,
                                        _jeu_cm, _exclure_fond)
                                    marge_n_faces = _gn
                                    if _gfeat:
                                        try:
                                            _gfeat.name = 'Marge CNC (auto)'
                                        except Exception:
                                            pass
                                    if _gfeat:
                                        messages.append(f'MargeAuto : jeu applique sur {_gn} face(s).')
                        except Exception:
                            _dbg('[ToolkitCNC] MargeAuto EXCEPTION: ' + traceback.format_exc())
                            messages.append('MargeAuto : erreur - voir marge_debug.log.')
        except Exception:
            _dbg('[ToolkitCNC] MortaiseAuto EXCEPTION: ' + traceback.format_exc())
            messages.append('MortaiseAuto : erreur - voir tenon_debug.log.')

    # Un SEUL groupe de timeline couvrant TOUTE cette execution (tenons +
    # MortaiseAuto + MargeAuto) - demande explicite de l'utilisateur : "tu
    # regroupe tout a chaque utilisation, comme ça je peux supprimer
    # directement le groupe dans l'historique". Remplace les 3 groupes
    # separes crees auparavant (Tenons CNC / Mortaise CNC (auto) / Marge
    # CNC (auto)) : avec 3 groupes distincts, supprimer seulement le
    # premier aurait laisse les mortaises/jeux orphelins (crees a partir du
    # tenon qui vient de disparaitre). TimelineGroup.deleteMe(True) (clic
    # droit > Supprimer sur le groupe dans l'arbre) supprime alors TOUT en
    # un seul geste - c'est ce mecanisme-la, et non Ctrl+Z, qui repond a la
    # demande initiale "un seul Ctrl+Z par tenon/entaille" (voir echanges
    # precedents : Ctrl+Z reste multi-etapes quel que soit le regroupement
    # en features, c'est une limite de Fusion).
    end_index = tl.markerPosition - 1
    if end_index > start_index:
        try:
            grp = tl.timelineGroups.add(start_index, end_index)
            if grp:
                grp.name = 'Tenon CNC'
                grp.isCollapsed = True
        except Exception:
            _dbg('[ToolkitCNC] groupement timeline Tenon CNC EXCEPTION: ' + traceback.format_exc())

    return {
        'n_faces_ok': n_ok,
        'n_faces_total': len(faces),
        'mortaise_nb_ok': mortaise_nb_ok,
        'mortaise_nb_skip': mortaise_nb_skip,
        'marge_n_faces': marge_n_faces,
        'messages': messages,
    }

class _CreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            cmd = args.command
            cmd.isRepeatable = True
            cmd.cancelButtonText = 'Fermer'
            cmd.okButtonText = 'Creer'
            onPrev = _ExecutePreviewHandler()
            cmd.executePreview.add(onPrev); _handlers.append(onPrev)
            onEx    = _ExecuteHandler()
            onChg   = _InputChangedHandler()
            onVal   = _ValidateHandler()
            onSel   = _SelectionHandler()
            onUnsel = _UnselectionHandler()
            onTerm  = _TerminateHandler()
            cmd.execute.add(onEx);          _handlers.append(onEx)
            cmd.inputChanged.add(onChg);    _handlers.append(onChg)
            cmd.validateInputs.add(onVal);  _handlers.append(onVal)
            cmd.select.add(onSel);          _handlers.append(onSel)
            cmd.unselect.add(onUnsel);      _handlers.append(onUnsel)
            cmd.destroy.add(onTerm);        _handlers.append(onTerm)
            inp = cmd.commandInputs
            sel = inp.addSelectionInput(
                'sel_faces', 'Chants',
                'Selectionnez un ou plusieurs chants (faces planes)')
            sel.addSelectionFilter('PlanarFaces')
            sel.setSelectionLimits(1, 0)
            _p = _load_prefs()
            _ed  = str(_p.get('edge_dist_mm',  10)) + ' mm'
            _tc  = int(_p.get('tenon_count',    2))
            _tl  = str(_p.get('tenon_len_mm',  20)) + ' mm'
            _th  = str(_p.get('tenon_h_mm',    12)) + ' mm'
            inp.addValueInput(
                'edge_dist', 'Distance du bord', 'mm',
                adsk.core.ValueInput.createByString(_ed))
            inp.addIntegerSpinnerCommandInput(
                'tenon_count', 'Nombre de tenons', 1, 200, 1, _tc)
            inp.addValueInput(
                'tenon_len', 'Longueur du tenon', 'mm',
                adsk.core.ValueInput.createByString(_tl))
            inp.addValueInput(
                'tenon_h', 'Hauteur du tenon (extrusion)', 'mm',
                adsk.core.ValueInput.createByString(_th))
            # "Centrer" : repartit les `tenon_count` tenons de longueur
            # `tenon_len` sur toute la longueur du chant, sans tenir compte
            # de "Distance du bord". "Mode de repartition" controle comment
            # l'espace restant (chant - tenons) est reparti : uniformement
            # partout, ou selon un pourcentage choisi pour les deux marges
            # de cote combinees (le reste va entre les tenons).
            _centrer_saved   = bool(_p.get('centrer', False))
            _rep_mode_saved  = _p.get('repartition_mode', 'uniforme')
            _rep_pct_saved   = _p.get('repartition_cotes_pct', 33.3)
            chk_centrer = inp.addBoolValueInput(
                'centrer', 'Centrer', True, '', _centrer_saved)
            dd_rep = inp.addDropDownCommandInput(
                'repartition_mode', 'Mode de repartition',
                adsk.core.DropDownStyles.TextListDropDownStyle)
            dd_rep.listItems.add('Uniforme', _rep_mode_saved != 'personnalise')
            dd_rep.listItems.add('Personnalise (% cotes)', _rep_mode_saved == 'personnalise')
            pct_rep = inp.addFloatSpinnerCommandInput(
                'repartition_cotes_pct', 'Part sur les cotes (%)', '', 0.0, 100.0, 1.0, _rep_pct_saved)
            # Etat initial coherent avec "Centrer" (l'utilisateur peut aussi
            # rouvrir la boite de dialogue avec Centrer deja coche via les
            # preferences sauvegardees) - voir aussi _InputChangedHandler
            # pour la mise a jour dynamique au clic.
            edge_dist_inp_ref = inp.itemById('edge_dist')
            if edge_dist_inp_ref:
                edge_dist_inp_ref.isEnabled = not _centrer_saved
            dd_rep.isVisible = _centrer_saved
            pct_rep.isVisible = _centrer_saved and _rep_mode_saved == 'personnalise'
            rb = inp.addRadioButtonGroupCommandInput('mode', 'Mode')
            rb.listItems.add('Tenons', True)
            rb.listItems.add('Languette', False)
            _lb = str(_p.get('languette_bord_mm', 5)) + ' mm'
            _lh2 = str(_p.get('languette_h_mm', 12)) + ' mm'
            inp.addValueInput(
                'languette_bord', 'Dist. bord (languette)', 'mm',
                adsk.core.ValueInput.createByString(_lb))
            inp.addValueInput(
                'languette_h', 'Hauteur languette', 'mm',
                adsk.core.ValueInput.createByString(_lh2))
            # MortaiseAuto : au clic sur "Creer", detecte automatiquement le(s)
            # corps femelle(s) en contact avec le(s) corps male(s) qui viennent
            # de recevoir un tenon/languette et decoupe la mortaise dans la
            # foulee (reutilise MortaiseCNC.creer_mortaises - voir
            # _ExecuteHandler). Ne joue aucun role pendant l'apercu (qui reste
            # un simple fil de fer, voir _ExecutePreviewHandler).
            _mortaise_auto_saved = bool(_p.get('mortaise_auto', False))
            chk_mortaise_auto = inp.addBoolValueInput(
                'mortaise_auto', 'MortaiseAuto', True, '', _mortaise_auto_saved)
            chk_mortaise_auto.tooltip = 'Mortaise automatique'
            chk_mortaise_auto.tooltipDescription = (
                "Detecte automatiquement le(s) corps femelle(s) en contact "
                "avec le(s) corps selectionne(s) et decoupe la mortaise "
                "correspondante des le clic sur Creer (en plus du tenon), "
                "sans avoir a relancer Mortaise CNC separement.<br><br>"
                "Necessite que l'add-in \"Mortaise CNC\" soit actif.")
            # MargeAuto : juste apres la creation automatique de la mortaise
            # (MortaiseAuto ci-dessus), applique aussitot le jeu de
            # fonctionnement configure dans Marge CNC (jeu + "exclure le
            # fond") sur les parois de CETTE mortaise precise (voir
            # MargeCNC.apply_jeu_to_tokens) - sans avoir a relancer Marge CNC
            # ni Mettre a jour CNC a la main. N'a d'effet que si MortaiseAuto
            # est egalement coche (une mortaise doit avoir ete creee).
            _marge_auto_saved = bool(_p.get('marge_auto', False))
            chk_marge_auto = inp.addBoolValueInput(
                'marge_auto', 'MargeAuto', True, '', _marge_auto_saved)
            chk_marge_auto.tooltip = 'Marge automatique'
            chk_marge_auto.tooltipDescription = (
                "Applique automatiquement le jeu de fonctionnement configure "
                "dans Marge CNC sur la mortaise qui vient d'etre creee par "
                "MortaiseAuto, des le clic sur Creer.<br><br>"
                "Necessite que MortaiseAuto soit egalement coche, et que "
                "l'add-in \"Marge CNC\" soit actif. Utilise le jeu, l'option "
                "\"Appliquer le jeu\" et \"Exclure le fond de mortaise\" tels "
                "que configures dans Marge CNC.")
            inp.addTextBoxCommandInput(
                'info', '', '<br><b>Tenons CNC</b>', 2, True)
            inp.addTextBoxCommandInput('result_text', 'Resultat', '', 3, True)
            inp.addBoolValueInput(
                'btn_preview', 'Apercu en direct', True, '', False)
            # "Purger tous les Tenons" et "Supprimer tenons des chants
            # selectionnes" sont maintenant des commandes independantes
            # (boutons a cote de "Isoler"/"Afficher tout"), et non plus
            # des boutons dans cette boite de dialogue : tant qu'elles
            # etaient ici, toute suppression etait annulee si l'utilisateur
            # cliquait ensuite sur "Fermer" (Fusion annule tout ce qui a
            # ete fait pendant qu'une commande reste ouverte, meme via un
            # evenement differe).
            global _sel_faces_cache, _hidden_bodies, _preview_geom_present
            global _preview_feat_tokens, _preview_sketch_tokens
            _sel_faces_cache = {}
            _hidden_bodies   = []
            _preview_geom_present = False
            _preview_feat_tokens = []
            _preview_sketch_tokens = []
        except:
            ui.messageBox(traceback.format_exc())



class _TerminateHandler(adsk.core.CommandEventHandler):
    """cmd.destroy : se declenche quand la boite de dialogue se ferme,
    quelle que soit la raison (clic sur "Creer" -> OK, clic sur
    "Fermer"/Echap -> Cancel, changement d'outil...). C'est le filet de
    securite qui garantit que l'apercu wireframe (CustomGraphics) ne
    reste jamais affiche a l'ecran apres la fermeture de la commande -
    _ExecuteHandler nettoie deja au clic sur "Creer", mais seul ce
    handler couvre aussi le cas "Fermer"."""
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            _clear_preview_graphics()
        except:
            pass


class _SelectionHandler(adsk.core.SelectionEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        global _sel_faces_cache
        try:
            face = adsk.fusion.BRepFace.cast(args.selection.entity)
            if not face: return
            sig  = _face_signature(face)
            body = face.body
            comp = face.body.parentComponent
            _sel_faces_cache[sig] = (body, comp)
            cmd = args.firingEvent.sender
            inp = cmd.commandInputs
            res_box = inp.itemById('result_text')
            if res_box:
                n = len(_sel_faces_cache)
                res_box.text = (f'<b>{n} chant(s) selectionne(s)</b><br>'
                                f'Cliquez OK pour creer les tenons.')
        except: pass


class _UnselectionHandler(adsk.core.SelectionEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        global _sel_faces_cache
        try:
            face = adsk.fusion.BRepFace.cast(args.selection.entity)
            if not face: return
            sig = _face_signature(face)
            if sig in _sel_faces_cache:
                del _sel_faces_cache[sig]
            cmd = args.firingEvent.sender
            inp = cmd.commandInputs
            res_box = inp.itemById('result_text')
            if res_box:
                n = len(_sel_faces_cache)
                res_box.text = (f'<b>{n} chant(s) selectionne(s)</b><br>'
                                f'Cliquez OK pour creer les tenons.'
                                if n > 0 else '')
        except: pass


class _ValidateHandler(adsk.core.ValidateInputsEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            i = args.inputs
            centrer_inp = i.itemById('centrer')
            centrer_on = bool(centrer_inp.value) if centrer_inp else False
            args.areInputsValid = (
                i.itemById('sel_faces').selectionCount >= 1 and
                (centrer_on or i.itemById('edge_dist').value > 0) and
                i.itemById('tenon_len').value > 0 and
                i.itemById('tenon_h').value > 0 and
                i.itemById('tenon_count').value >= 1)
        except:
            args.areInputsValid = False


class _InputChangedHandler(adsk.core.InputChangedEventHandler):
    """Gere l'affichage dynamique des options "Centrer" / "Mode de
    repartition" : quand "Centrer" est coche, "Distance du bord" est
    desactivee (elle n'est plus utilisee pour placer les tenons) et le
    choix du mode de repartition apparait ; le champ "Part sur les cotes
    (%)" n'apparait lui que si "Personnalise" est choisi. ("Purger tous
    les Tenons" et "Supprimer tenons des chants selectionnes" sont des
    commandes independantes - voir _PurgeCreatedHandler /
    _DeleteSelCreatedHandler - et n'ont pas besoin de ce handler.)"""
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            inp = args.inputs
            centrer_inp  = inp.itemById('centrer')
            edge_dist_inp = inp.itemById('edge_dist')
            rep_mode_inp = inp.itemById('repartition_mode')
            rep_pct_inp  = inp.itemById('repartition_cotes_pct')
            if centrer_inp is None:
                return
            is_centrer = bool(centrer_inp.value)
            if edge_dist_inp is not None:
                edge_dist_inp.isEnabled = not is_centrer
            if rep_mode_inp is not None:
                rep_mode_inp.isVisible = is_centrer
            is_perso = False
            if rep_mode_inp is not None and rep_mode_inp.selectedItem:
                is_perso = rep_mode_inp.selectedItem.name.startswith('Personnalise')
            if rep_pct_inp is not None:
                rep_pct_inp.isVisible = is_centrer and is_perso
        except:
            pass


class _ExecutePreviewHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        global _preview_geom_present
        try:
            inp        = args.command.commandInputs
            sel        = inp.itemById('sel_faces')
            prv        = inp.itemById('btn_preview')
            preview_on = bool(prv.value) if prv else True
            _dbg(f'--- ExecutePreview appele : preview_on={preview_on} sel.selectionCount={sel.selectionCount if sel else None} ---')
            edge_dist = inp.itemById('edge_dist').value
            count     = inp.itemById('tenon_count').value
            tenon_len = inp.itemById('tenon_len').value
            tenon_h   = inp.itemById('tenon_h').value
            lang_bord_inp = inp.itemById('languette_bord')
            lang_h_inp = inp.itemById('languette_h')
            lb_val = lang_bord_inp.value if lang_bord_inp else 0.5
            lh_val = lang_h_inp.value if lang_h_inp else 1.2
            centrer_inp  = inp.itemById('centrer')
            rep_mode_inp = inp.itemById('repartition_mode')
            rep_pct_inp  = inp.itemById('repartition_cotes_pct')
            centrer = bool(centrer_inp.value) if centrer_inp else False
            rep_mode = 'personnalise' if (rep_mode_inp and rep_mode_inp.selectedItem and
                                           rep_mode_inp.selectedItem.name.startswith('Personnalise')) else 'uniforme'
            rep_pct = rep_pct_inp.value if rep_pct_inp else 33.3
            mortaise_auto_inp = inp.itemById('mortaise_auto')
            mortaise_auto = bool(mortaise_auto_inp.value) if mortaise_auto_inp else False
            marge_auto_inp = inp.itemById('marge_auto')
            marge_auto = bool(marge_auto_inp.value) if marge_auto_inp else False
            _save_prefs({
                'edge_dist_mm': round(edge_dist*10,4),
                'tenon_count': count,
                'tenon_len_mm': round(tenon_len*10,4),
                'tenon_h_mm': round(tenon_h*10,4),
                'languette_bord_mm': round(lb_val*10,4),
                'languette_h_mm': round(lh_val*10,4),
                'centrer': centrer,
                'repartition_mode': rep_mode,
                'repartition_cotes_pct': rep_pct,
                'mortaise_auto': mortaise_auto,
                'marge_auto': marge_auto,
            })
            design = adsk.fusion.Design.cast(app.activeProduct)
            if not design: return
            res_box = inp.itemById('result_text')

            if not preview_on:
                # Preview desactive : on ne cree AUCUNE geometrie tant que
                # l'utilisateur n'a pas clique sur "Creer", et on efface
                # l'apercu en traits s'il y en avait un (option qui vient
                # d'etre decochee).
                _clear_preview_graphics()
                if _preview_geom_present:
                    # Filet de securite : geometrie "preview" reelle laissee
                    # par une VERSION PRECEDENTE de cet add-in (avant le
                    # passage a l'apercu en traits leger) encore presente en
                    # memoire au moment d'un rechargement a chaud - a purger
                    # une bonne fois pour ne pas la laisser trainer.
                    _purge_preview_tokens(design)
                    _preview_geom_present = False
                if res_box:
                    n = sel.selectionCount
                    res_box.text = (f'<b>{n} chant(s) selectionne(s)</b><br>'
                                    f'Apercu desactive - cliquez sur Creer pour generer les tenons.')
                # Aucune geometrie creee ici : on indique que ce n'est PAS un
                # resultat "valide" que Fusion pourrait reutiliser tel quel au
                # clic sur OK. Ca force Fusion a appeler pour de vrai
                # l'evenement execute (Creer), qui cree les tenons definitifs.
                args.isValidResult = False
                return

            faces = []
            for k in range(sel.selectionCount):
                try:
                    face = adsk.fusion.BRepFace.cast(sel.selection(k).entity)
                    if face: faces.append(face)
                except: pass
            if not faces:
                _clear_preview_graphics()
                args.isValidResult = False
                return

            # APERCU EN TRAITS LEGERS (CustomGraphics) - voir
            # _draw_tenon_preview_graphics : ne cree plus la moindre
            # geometrie Fusion reelle (ni sketch, ni extrusion), donc plus
            # besoin de purger quoi que ce soit entre deux apercus - le
            # groupe de graphiques precedent est simplement remplace.
            # Inspire par la fluidite du preview de l'add-in "Tab & Slot"
            # (dessin en traits plutot que modification du corps en direct -
            # demande explicite de l'utilisateur, capture d'ecran a l'appui).
            mode_inp = inp.itemById('mode')
            is_lang = mode_inp and mode_inp.selectedItem and mode_inp.selectedItem.name == 'Languette'
            lb = inp.itemById('languette_bord').value
            lh = inp.itemById('languette_h').value
            _draw_tenon_preview_graphics(
                faces, edge_dist, count, tenon_len, tenon_h,
                centrer, rep_mode, rep_pct, is_lang, lb, lh, design)
            if _preview_geom_present:
                # Meme filet de securite que ci-dessus (cas Preview actif).
                _purge_preview_tokens(design)
                _preview_geom_present = False
            # IMPORTANT : ne JAMAIS mettre isValidResult=True ici. D'apres la doc
            # Fusion, si l'apercu (executePreview) est marque comme resultat
            # valide, Fusion termine la commande au clic sur OK en gardant
            # directement la geometrie de l'apercu SANS jamais declencher
            # l'evenement execute (_ExecuteHandler) - confirme empiriquement
            # via tenon_debug.log (aucune ligne "Execute (Creer) declenche"
            # apres une sequence d'apercus avec preview_on=True). Or c'est
            # UNIQUEMENT dans _ExecuteHandler que sont faits : l'enregistrement
            # chant->tenons (tenon_face_map.json, utilise par la suppression
            # ciblee) et le groupement dans l'historique ("Tenons CNC"). D'ou
            # le bug rapporte : avec l'apercu en direct actif (option cochee
            # par defaut), les tenons crees n'etaient jamais groupes. On force
            # donc toujours False : Fusion rappelle alors reellement
            # _ExecuteHandler au clic sur OK (qui purge l'apercu et recree les
            # tenons definitifs - cf. _preview_geom_present plus haut), ce qui
            # est legerement plus lent mais garantit que l'enregistrement et le
            # groupement se produisent a chaque fois.
            args.isValidResult = False
        except:
            ui.messageBox(traceback.format_exc())



class _ExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        global _preview_geom_present
        _dbg('=== Execute (Creer) declenche ===')
        # Par securite/proprete : si un apercu CustomGraphics (wireframe)
        # etait encore affiche, on le retire avant de creer la geometrie
        # reelle, pour eviter tout doublon visuel (apercu + solide cree).
        # Le nettoyage normal se fait deja via CommandTerminatedHandler,
        # mais Execute peut se declencher sans passer par la ou le
        # terminate n'a pas encore ete traite.
        _clear_preview_graphics()
        try:
            inp=args.command.commandInputs
            lb_i=inp.itemById('languette_bord')
            lh_i=inp.itemById('languette_h')
            centrer_inp  = inp.itemById('centrer')
            rep_mode_inp = inp.itemById('repartition_mode')
            rep_pct_inp  = inp.itemById('repartition_cotes_pct')
            centrer = bool(centrer_inp.value) if centrer_inp else False
            rep_mode = 'personnalise' if (rep_mode_inp and rep_mode_inp.selectedItem and
                                           rep_mode_inp.selectedItem.name.startswith('Personnalise')) else 'uniforme'
            rep_pct = rep_pct_inp.value if rep_pct_inp else 33.3
            mortaise_auto_inp = inp.itemById('mortaise_auto')
            mortaise_auto = bool(mortaise_auto_inp.value) if mortaise_auto_inp else False
            marge_auto_inp = inp.itemById('marge_auto')
            marge_auto = bool(marge_auto_inp.value) if marge_auto_inp else False
            _save_prefs({
                'edge_dist_mm':round(inp.itemById('edge_dist').value*10,4),
                'tenon_count':inp.itemById('tenon_count').value,
                'tenon_len_mm':round(inp.itemById('tenon_len').value*10,4),
                'tenon_h_mm':round(inp.itemById('tenon_h').value*10,4),
                'languette_bord_mm':round(lb_i.value*10,4) if lb_i else 5,
                'languette_h_mm':round(lh_i.value*10,4) if lh_i else 12,
                'centrer': centrer,
                'repartition_mode': rep_mode,
                'repartition_cotes_pct': rep_pct,
                'mortaise_auto': mortaise_auto,
                'marge_auto': marge_auto,
            })
            dsgn=adsk.fusion.Design.cast(app.activeProduct)
            if not dsgn: return

            # On repart d'une base propre : si des tenons "live preview"
            # existaient deja (Preview etait actif), on les retire puis on
            # (re)cree les tenons definitifs avec les valeurs finales des
            # parametres. Si Preview etait desactive, rien n'existait encore
            # et on les cree ici, au clic sur "Creer".
            _dbg(f'_preview_geom_present={_preview_geom_present}')
            if _preview_geom_present:
                deleted, errs = _purge_preview_tokens(dsgn)
                _dbg(f'purge preview geom (scoped): deleted={deleted} errs={errs}')
                _preview_geom_present = False

            # Position de depart pour le groupement (voir plus bas) : capturee
            # ICI, APRES la purge de l'apercu mais AVANT toute creation reelle.
            # markerPosition (et non tl.count-1) est indispensable des que le
            # design est en rollback (barre d'historique pas a la toute fin) :
            # dans ce cas Fusion INSERE les nouvelles features/sketches a la
            # position du marqueur, pas a la fin absolue de la timeline - le
            # reste de l'historique (deja existant, plus recent) est alors
            # decale plus loin. Un ancien scan "en repartant de tl.count-1 et
            # en remontant tant que le nom commence par 'Tenon'" se trompait
            # totalement de plage des qu'il y avait de l'historique existant
            # APRES le marqueur (cas frequent ici) : il tombait immediatement
            # sur cet historique plus recent (qui ne s'appelle pas "Tenon") et
            # abandonnait aussitot, sans jamais grouper - c'est ce qui causait
            # le bug rapporte ("3 esquisses/extrusions separees, pas de
            # groupe"), meme quand execute() se declenchait bien.
            tl = dsgn.timeline
            start_index = tl.markerPosition

            sel = inp.itemById('sel_faces')
            faces = []
            for k in range(sel.selectionCount):
                try:
                    face = adsk.fusion.BRepFace.cast(sel.selection(k).entity)
                    if face: faces.append(face)
                except Exception as _e:
                    _dbg(f'erreur lecture selection[{k}]: {_e}')
            _dbg(f'sel.selectionCount={sel.selectionCount} faces_via_sel={len(faces)} cache_size={len(_sel_faces_cache)}')
            if not faces:
                # Filet de securite : au moment du clic sur "Creer", la
                # selection de l'input peut deja avoir ete videe par Fusion.
                # On retombe alors sur les chants memorises au fil des
                # selections/deselections dans la boite de dialogue.
                for sig, (body, _comp) in _sel_faces_cache.items():
                    try:
                        f = _find_face_by_signature(body, sig)
                        if f: faces.append(f)
                        else: _dbg(f'signature introuvable pour body={body.name if body else None}')
                    except Exception as _e:
                        _dbg(f'erreur fallback cache: {_e}')
                _dbg(f'faces_via_cache_fallback={len(faces)}')

            # MortaiseAuto (voir plus bas, apres le groupement "Tenons CNC") :
            # tokens des corps ayant reellement recu un tenon/languette
            # pendant CETTE execution - defini ici (et pas dans le "if
            # faces:" ci-dessous) pour rester toujours accessible plus bas,
            # meme si "faces" est vide (aucune mortaise a chercher alors).
            _touched_male_tokens = set()

            if faces:
                edge_dist = inp.itemById('edge_dist').value
                count     = inp.itemById('tenon_count').value
                tenon_len = inp.itemById('tenon_len').value
                tenon_h   = inp.itemById('tenon_h').value
                mode_inp  = inp.itemById('mode')
                is_lang = mode_inp and mode_inp.selectedItem and mode_inp.selectedItem.name == 'Languette'
                _dbg(f'creation reelle: {len(faces)} face(s), is_lang={is_lang}, edge_dist={edge_dist} count={count} tenon_len={tenon_len} tenon_h={tenon_h}')
                _touched_comps = {}
                _pending_by_body = {}  # body_token -> {'body': BRepBody, 'items': [(face, face_key, spec, bump), ...]}
                if is_lang:
                    _kwargs = {'edge_dist': inp.itemById('languette_bord').value,
                               'languette_h': inp.itemById('languette_h').value}
                else:
                    _kwargs = {'edge_dist': edge_dist, 'count': count, 'tenon_len': tenon_len,
                               'tenon_h': tenon_h, 'centrer': centrer,
                               'repartition_mode': rep_mode, 'repartition_cotes_pct': rep_pct}
                _kwargs['rapide'] = False
                for _fi, face in enumerate(faces):
                    try:
                        # Cle et composant calcules AVANT la creation : une
                        # fois l'extrusion faite, ce `face` peut deja etre
                        # invalide (chant decoupe), et le relire plantera
                        # silencieusement plus bas (voir _record_face_tenons).
                        _face_key = None
                        _comp = None
                        _spec = None
                        _body_tok = None
                        try:
                            _comp = face.body.parentComponent
                            _face_key = _face_map_key(_comp, face)
                            # Cle UNIQUE par creation (2026-10-06) : le plan seul se partageait
                            # entre chants coplanaires de corps differents (lattes alignees),
                            # l'un ecrasait l'autre et la mise a jour recreait au mauvais endroit.
                            _face_key += '|' + face.body.name + '|' + _uuid.uuid4().hex[:8]
                            _body_tok = face.body.entityToken
                        except Exception as _e:
                            _dbg(f'face[{_fi}] erreur calcul cle AVANT creation: {_e}')
                        try:
                            if _comp is not None:
                                _n = face.geometry.normal; _o = face.geometry.origin
                                _offset = _o.x*_n.x + _o.y*_n.y + _o.z*_n.z
                                if is_lang:
                                    _params = {'edge_dist_mm': round(inp.itemById('languette_bord').value*10, 4),
                                               'languette_h_mm': round(inp.itemById('languette_h').value*10, 4)}
                                    _mode = 'languette'
                                else:
                                    _params = {'edge_dist_mm': round(edge_dist*10, 4),
                                               'tenon_count': count,
                                               'tenon_len_mm': round(tenon_len*10, 4),
                                               'tenon_h_mm': round(tenon_h*10, 4),
                                               'centrer': centrer,
                                               'repartition_mode': rep_mode,
                                               'repartition_cotes_pct': rep_pct}
                                    _mode = 'tenon'
                                try:
                                    _extreme = _classify_extreme(face.body, (_n.x, _n.y, _n.z), _offset)
                                except Exception:
                                    _extreme = None
                                _spec = {
                                    'mode': _mode,
                                    'params': _params,
                                    'body_token': face.body.entityToken,
                                    'body_name': face.body.name,
                                    'comp_token': _comp.entityToken,
                                    'plane': [round(_n.x,6), round(_n.y,6), round(_n.z,6), round(_offset,6)],
                                    # 'extreme' ('min'/'max'/None) : permet de
                                    # retrouver ce chant apres un changement
                                    # de CONFIGURATION PARAMETRIQUE (panneau
                                    # redimensionne, ex. canape en plusieurs
                                    # longueurs) qui deplace l'offset bien
                                    # au-dela d'une simple derive - voir
                                    # _find_face_by_plane_resized.
                                    'extreme': _extreme,
                                    'tracked': True,
                                }
                        except Exception as _e:
                            _dbg(f'face[{_fi}] erreur calcul spec AVANT creation: {_e}')
                        if _comp is not None:
                            _touched_comps[_comp.entityToken] = _comp
                        _tag_chant_face(face, _face_key)
                        _res = _create_tenon_bump_isolated(face, is_lang, _kwargs, dsgn)
                        _cnt = _res['cnt']; _msg = _res['msg']
                        _dbg(f"face[{_fi}] -> cnt={_cnt} msg={_msg} mode={_res['mode']}")
                        if _cnt and _res['mode'] == 'batched':
                            _pending = _pending_by_body.setdefault(_body_tok, {'body': face.body, 'items': []})
                            _pending['items'].append((face, _face_key, _spec, _res['bump']))
                        elif _cnt:
                            # Repli (voir _create_tenon_bump_isolated) :
                            # feature/esquisse reelle laissee en place,
                            # ancien format.
                            _record_face_tenons_by_key(
                                _face_key,
                                [f.entityToken for f in _res['feat_objs']],
                                [s.entityToken for s in _res['sketch_objs']],
                                spec=_spec)
                            for _f in _res['feat_objs']:
                                _tag_feature_keys(_f, [_face_key])
                            if _body_tok:
                                _touched_male_tokens.add(_body_tok)
                    except Exception as _e:
                        _dbg(f'face[{_fi}] EXCEPTION: {traceback.format_exc()}')

                # Commit GLOBAL (voir _commit_tenon_bumps_globally /
                # create_tenons_core - meme mecanisme) : UNE SEULE insertion
                # groupee (un seul design.computeAll()) pour TOUS les corps
                # du lot, au lieu d'un computeAll() par corps.
                _root = dsgn.rootComponent
                _commit_results = _commit_tenon_bumps_globally(dsgn, _root, _pending_by_body)
                for _body_tok, _pending in _pending_by_body.items():
                    _body = _pending['body']
                    _items = _pending['items']
                    _combine_feat, _base_feat = _commit_results.get(_body_tok, (None, None))
                    if _combine_feat is not None:
                        _shared_tokens = [_combine_feat.entityToken, _base_feat.entityToken]
                        for _face, _face_key, _spec, _bump in _items:
                            _record_face_tenons_by_key(_face_key, _shared_tokens, [], spec=_spec)
                        _tag_feature_keys(_combine_feat, [_it[1] for _it in _items])
                        try:
                            _fresh_tok = _body.entityToken
                        except Exception:
                            _fresh_tok = _body_tok
                        if _fresh_tok:
                            _touched_male_tokens.add(_fresh_tok)
                    else:
                        _dbg(f'commit groupe ECHEC pour corps {_body_tok} - repli non groupe sur {len(_items)} chant(s)')
                        for _face, _face_key, _spec, _bump in _items:
                            _ft2 = []; _st2 = []
                            if is_lang:
                                _cnt2, _msg2 = _create_languette_on_face(
                                    _face, _kwargs['edge_dist'], _kwargs['languette_h'], dsgn,
                                    track_feats=_ft2, track_sketches=_st2)
                            else:
                                _cnt2, _msg2 = _create_tenons_on_face(
                                    _face, _kwargs['edge_dist'], _kwargs['count'], _kwargs['tenon_len'],
                                    _kwargs['tenon_h'], dsgn, track_feats=_ft2, track_sketches=_st2,
                                    centrer=_kwargs.get('centrer', False),
                                    repartition_mode=_kwargs.get('repartition_mode', 'uniforme'),
                                    repartition_cotes_pct=_kwargs.get('repartition_cotes_pct', 33.3))
                            if _cnt2:
                                _record_face_tenons_by_key(
                                    _face_key, [f.entityToken for f in _ft2], [s.entityToken for s in _st2], spec=_spec)
                                if _body_tok:
                                    _touched_male_tokens.add(_body_tok)

                try:
                    _a  = adsk.core.Application.get()
                    _tb = {}
                    for _ci, _c in _touched_comps.items():
                        _tb[_ci] = []
                        for _k in range(_c.sketches.count):
                            _s = _c.sketches.item(_k)
                            if _s.name == 'Tenon' or _s.name.startswith('Tenon ('):
                                _tb[_ci].append(_s.entityToken)
                    for _ci, _toks in _tb.items():
                        if _toks:
                            _a.executeTextCommand('Sketch.MoveToNewSketchFolder ' + ' '.join(_toks))
                except: pass

            # Pas de groupement ici : voir le groupe unique 'Tenon CNC' cree
            # a la toute fin de ce handler (apres MortaiseAuto/MargeAuto),
            # meme logique que create_tenons_core - demande l'utilisateur : un
            # seul groupe par execution, supprimable d'un coup dans
            # l'historique. Le nom exact "Tenon"/"Tenon (n)" de la feature
            # reste intact ici (non renomme) : c'est ce que
            # MortaiseCNC._tenon_feature_planes utilise pour retrouver les
            # faces du tenon male ; le groupe ne renomme pas la feature elle-
            # meme, seulement le groupe qui la contient.

            # -----------------------------------------------------------
            # MortaiseAuto : detecte automatiquement le(s) corps femelle(s)
            # en contact avec le(s) corps male(s) qui viennent de recevoir
            # un tenon/languette pendant CETTE execution, et decoupe la
            # mortaise dans la foulee - sans avoir a relancer Mortaise CNC
            # separement.
            #
            # Reutilise TEL QUEL MortaiseCNC.creer_mortaises (meme fonction
            # que l'add-in "Mortaise CNC" manuel et que "Mettre a jour CNC"),
            # retrouvee via _find_module - add-ins independants, TenonCNC ne
            # depend pas d'un import direct (MortaiseCNC peut etre inactif).
            # La detection du/des corps femelle(s) se limite a fournir TOUS
            # les autres corps du design comme candidats : c'est
            # creer_mortaises lui-meme qui ne decoupe que les paires dont les
            # bounding box se chevauchent REELLEMENT (voir _bbox_overlap),
            # exactement la meme logique que pour une selection manuelle.
            #
            # Les mortaises ainsi creees portent les memes attributs
            # (MortaiseCNC/male_token/female_token) que celles creees a la
            # main, donc "Mettre a jour CNC" les retrouve et les repositionne
            # normalement plus tard, sans aucune integration supplementaire.
            if mortaise_auto and _touched_male_tokens:
                try:
                    males = []
                    for _tok in _touched_male_tokens:
                        _found = dsgn.findEntityByToken(_tok)
                        _mb = adsk.fusion.BRepBody.cast(_found[0]) if _found else None
                        if _mb: males.append(_mb)
                    MortaiseCNC = _find_module('MortaiseCNC')
                    if MortaiseCNC is None:
                        _dbg('MortaiseAuto: module MortaiseCNC introuvable (add-in inactif)')
                        ui.messageBox(
                            'MortaiseAuto est coche mais l\'add-in "Mortaise CNC" '
                            "n'est pas actif : le tenon a bien ete cree, mais "
                            "aucune mortaise ne l'a ete.\n\n"
                            "Demarre \"Mortaise CNC\" (Outils > Scripts et "
                            "complements, Maj+S), puis relance Creer.",
                            'Tenons CNC - MortaiseAuto')
                    elif not males:
                        _dbg('MortaiseAuto: aucun corps male resolu depuis les tokens, abandon')
                    else:
                        male_tokens = {m.entityToken for m in males}
                        # Parcourt TOUS les corps du design (racine + tous les
                        # composants d'occurrence), pas seulement ceux places
                        # directement dans le composant racine - meme
                        # parcours que _purge_tenons, pour rester correct
                        # aussi sur un assemblage avec sous-composants (pas
                        # seulement ce fichier de test, ou tout est a plat).
                        _root = dsgn.rootComponent
                        _comps = [_root]
                        _seen_comp = {_root.entityToken}
                        for _occ in _root.allOccurrences:
                            _c = _occ.component
                            if _c.entityToken not in _seen_comp:
                                _seen_comp.add(_c.entityToken)
                                _comps.append(_c)
                        femelles = []
                        _seen_body = set()
                        for _comp in _comps:
                            for _fb in _comp.bRepBodies:
                                try:
                                    _tok = _fb.entityToken
                                    if _tok in male_tokens or _tok in _seen_body:
                                        continue
                                    _seen_body.add(_tok)
                                    femelles.append(_fb)
                                except Exception:
                                    pass
                        _dbg(f'MortaiseAuto: males={[m.name for m in males]} '
                             f'femelles_candidates={[f.name for f in femelles]}')
                        if not femelles:
                            _dbg('MortaiseAuto: aucun corps femelle candidat dans le design')
                        else:
                            _nb_ok, _nb_skip, _merrs, _new_records = MortaiseCNC.creer_mortaises(
                                males, femelles, dsgn.rootComponent)
                            # Pas de groupe separe ici non plus (voir groupe
                            # unique 'Tenon CNC' en fin de handler).
                            _dbg(f'MortaiseAuto: nb_ok={_nb_ok} nb_skipped={_nb_skip} errors={_merrs}')
                            if _nb_ok == 0:
                                ui.messageBox(
                                    "MortaiseAuto est coche : le tenon a bien ete "
                                    "cree, mais aucun corps femelle en contact "
                                    f"n'a ete detecte automatiquement (sur "
                                    f"{len(femelles)} autre(s) corps du design).\n\n"
                                    "Verifie que les corps se touchent bien, ou "
                                    "cree la mortaise manuellement avec l'add-in "
                                    "Mortaise CNC.",
                                    'Tenons CNC - MortaiseAuto')

                            # -------------------------------------------
                            # MargeAuto : applique aussitot le jeu de
                            # fonctionnement configure dans Marge CNC sur
                            # les parois des mortaises qui viennent d'etre
                            # creees par MortaiseAuto (_new_records
                            # ci-dessus - UNIQUEMENT cette/ces mortaise(s)
                            # precise(s), pas tout mortaise_face_map.json,
                            # pour ne jamais re-decaler une paroi deja
                            # margee par un tenon precedent sur le meme
                            # corps femelle - voir apply_jeu_to_tokens
                            # dans MargeCNC.py).
                            if marge_auto and _new_records:
                                try:
                                    MargeCNC = _find_module('MargeCNC')
                                    if MargeCNC is None:
                                        _dbg('MargeAuto: module MargeCNC introuvable (add-in inactif)')
                                        ui.messageBox(
                                            'MargeAuto est coche mais l\'add-in "Marge CNC" '
                                            "n'est pas actif : la mortaise a bien ete creee, "
                                            "mais aucun jeu ne lui a ete applique.\n\n"
                                            "Demarre \"Marge CNC\" (Outils > Scripts et "
                                            "complements, Maj+S), puis relance Creer.",
                                            'Tenons CNC - MargeAuto')
                                    else:
                                        _jeu_cm, _jeu_actif, _exclure_fond = MargeCNC.load_settings()
                                        if not _jeu_actif:
                                            _dbg('MargeAuto: "Appliquer le jeu" est desactive dans '
                                                 'Marge CNC, aucun jeu applique')
                                        else:
                                            _gfeat, _gn = MargeCNC.apply_jeu_to_tokens(
                                                dsgn, dsgn.rootComponent, _new_records,
                                                _jeu_cm, _exclure_fond)
                                            # Pas de groupe separe ici non
                                            # plus (voir groupe unique
                                            # 'Tenon CNC' en fin de handler) -
                                            # on renomme juste la feature
                                            # elle-meme, comme dans
                                            # create_tenons_core.
                                            if _gfeat:
                                                try:
                                                    _gfeat.name = 'Marge CNC (auto)'
                                                except Exception:
                                                    pass
                                            _dbg(f'MargeAuto: jeu={_jeu_cm} n_faces={_gn} feat={_gfeat}')
                                except Exception:
                                    _dbg('MargeAuto EXCEPTION: ' + traceback.format_exc())
                                    ui.messageBox('Erreur MargeAuto:\n' + traceback.format_exc())
                except Exception:
                    _dbg('MortaiseAuto EXCEPTION: ' + traceback.format_exc())
                    ui.messageBox('Erreur MortaiseAuto:\n' + traceback.format_exc())

            # Un SEUL groupe de timeline couvrant TOUTE cette execution
            # (tenons + MortaiseAuto + MargeAuto) - meme mecanisme et meme
            # demande l'utilisateur que dans create_tenons_core : "tu regroupe
            # tout a chaque utilisation, comme ça je peux supprimer
            # directement le groupe dans l'historique". Remplace les 3
            # groupes separes crees auparavant par ce handler (Tenons CNC /
            # Mortaise CNC (auto) / Marge CNC (auto)).
            end_index = tl.markerPosition - 1
            if end_index > start_index:
                try:
                    grp = tl.timelineGroups.add(start_index, end_index)
                    if grp:
                        grp.name = 'Tenon CNC'
                        grp.isCollapsed = True
                except Exception:
                    _dbg('groupement timeline Tenon CNC EXCEPTION: ' + traceback.format_exc())

            args.isValidResult = True
            _dbg('=== Execute termine sans exception ===')
        except:
            _dbg('EXCEPTION top-level Execute: ' + traceback.format_exc())
            ui.messageBox(traceback.format_exc())


# ---------------------------------------------------------------------------
# Entry points obligatoires pour un add-in Fusion
# ---------------------------------------------------------------------------

def _purge_tenons(design):
    root    = design.rootComponent
    deleted = 0
    errors  = []
    comps   = [root]
    seen    = {root.entityToken}
    for occ in root.allOccurrences:
        c = occ.component
        if c.entityToken not in seen:
            seen.add(c.entityToken)
            comps.append(c)
    for comp in comps:
        to_del = []
        for k in range(comp.features.count):
            try:
                feat = comp.features.item(k)
                n = feat.name
                if n == "Tenon" or n.startswith("Tenon ("):
                    to_del.append(feat)
            except: pass
        for feat in reversed(to_del):
            try: feat.deleteMe(); deleted += 1
            except Exception as ex: errors.append(str(ex))
        sk_del = []
        for k in range(comp.sketches.count):
            try:
                sk = comp.sketches.item(k)
                n  = sk.name
                if n == "Tenon" or n.startswith("Tenon ("):
                    sk_del.append(sk)
            except: pass
        for sk in reversed(sk_del):
            try: sk.deleteMe(); deleted += 1
            except Exception as ex: errors.append(str(ex))
    return deleted, errors


def _purge_preview_tokens(design):
    """Supprime UNIQUEMENT les sketches/features cree(e)s par la session de
    "live preview" en cours (identifiees par leur entityToken exact), sans
    jamais toucher a des tenons deja existants/valides crees precedemment
    (a une autre session, ou avec un autre chant). Contrairement a
    _purge_tenons (qui matche par NOM et efface TOUT ce qui s'appelle
    "Tenon" dans tout le design), celle-ci est sans risque a appeler
    automatiquement a chaque changement de parametre."""
    global _preview_feat_tokens, _preview_sketch_tokens
    deleted = 0
    errors  = []
    for tok in list(_preview_feat_tokens):
        try:
            found = design.findEntityByToken(tok)
            if found:
                found[0].deleteMe()
                deleted += 1
        except Exception as ex:
            errors.append(str(ex))
    for tok in list(_preview_sketch_tokens):
        try:
            found = design.findEntityByToken(tok)
            if found:
                found[0].deleteMe()
                deleted += 1
        except Exception as ex:
            errors.append(str(ex))
    _preview_feat_tokens = []
    _preview_sketch_tokens = []
    return deleted, errors





class _IsolateCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            cmd = args.command
            cmd.isRepeatable = False
            onEx = _IsolateExecuteHandler()
            onVal = _IsolateValidateHandler()
            cmd.execute.add(onEx); _handlers.append(onEx)
            cmd.validateInputs.add(onVal); _handlers.append(onVal)
            inp = cmd.commandInputs
            sel = inp.addSelectionInput(
                'iso_sel',
                'Corps a garder',
                'Selectionnez')
            sel.addSelectionFilter('SolidBodies')
            sel.setSelectionLimits(1, 0)
        except: ui.messageBox(traceback.format_exc())


class _IsolateValidateHandler(adsk.core.ValidateInputsEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            sid = 'iso_sel'
            args.areInputsValid = args.inputs.itemById(sid).selectionCount >= 1
        except: args.areInputsValid = False


class _IsolateExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        global _iso_hidden
        try:
            design = adsk.fusion.Design.cast(app.activeProduct)
            if not design:
                return

            root = design.rootComponent
            sid = 'iso_sel'
            sel = args.command.commandInputs.itemById(sid)
            if not sel:
                return

            # Build the exact occurrences corresponding to the selected bodies.
            # A selected BRepBody in an assembly is normally a proxy and exposes
            # its occurrence through assemblyContext. For native bodies, fall back
            # to the occurrence whose component owns the body.
            keep_occurrences = []
            keep_tokens = set()

            for k in range(sel.selectionCount):
                try:
                    ent = sel.selection(k).entity
                    occ = adsk.fusion.Occurrence.cast(ent)

                    if not occ:
                        body = adsk.fusion.BRepBody.cast(ent)
                        if body:
                            try:
                                occ = body.assemblyContext
                            except:
                                occ = None

                            if not occ:
                                parent_comp = body.parentComponent
                                for candidate in root.allOccurrences:
                                    if candidate.component.entityToken == parent_comp.entityToken:
                                        occ = candidate
                                        break

                    if occ and occ.isValid:
                        tok = occ.entityToken
                        if tok not in keep_tokens:
                            keep_tokens.add(tok)
                            keep_occurrences.append(occ)
                except:
                    pass

            if not keep_occurrences:
                ui.messageBox('Aucune occurrence valide n\'a pu etre determinee.')
                return

            # Fusion's native Isolate command is the reliable way to perform a
            # real isolation. Directly changing isLightBulbOn from a command
            # handler can be reverted by Fusion, especially in CAM/Manufacture.
            active_selections = ui.activeSelections
            active_selections.clear()
            for occ in keep_occurrences:
                try:
                    active_selections.add(occ)
                except:
                    pass

            # Mark the current isolation as native; we no longer need to store
            # visibility indices because UnisolateAllCmd restores the isolation
            # state without changing the user's individual bulb states.
            _iso_hidden = [occ.entityToken for occ in keep_occurrences]

            try:
                result = app.executeTextCommand('Commands.Start IsolateCmd')
            finally:
                active_selections.clear()

        except:
            ui.messageBox('Tenons CNC - Erreur lors de l\'isolation :\n' + traceback.format_exc())


class _RestoreCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            onEx = _RestoreExecuteHandler()
            args.command.execute.add(onEx)
            _handlers.append(onEx)
        except: ui.messageBox(traceback.format_exc())


class _RestoreExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        global _iso_hidden
        try:
            # Use Fusion's native command so the isolation state is removed
            # cleanly without relying on occurrence indices or bulb states.
            app.executeTextCommand('Commands.Start UnisolateAllCmd')
            _iso_hidden = []
        except:
            ui.messageBox('Tenons CNC - Erreur lors de la restauration :\n' + traceback.format_exc())



class _TenonCreateHandler(adsk.core.CustomEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        global _create_params
        p = _create_params
        if not p: return
        try:
            dsgn=adsk.fusion.Design.cast(app.activeProduct)
            faces=p[0]; ed=p[1]; cnt=p[2]; tlv=p[3]; th=p[4]
            isl=p[5]; lbv=p[6]; lhv=p[7]
            for face in faces:
                try:
                    if isl: _create_languette_on_face(face,lbv,lhv,dsgn)
                    else: _create_tenons_on_face(face,ed,cnt,tlv,th,dsgn)
                except: pass
        except: pass


class _PurgeCreatedHandler(adsk.core.CommandCreatedEventHandler):
    """Commande independante (pas nichee dans la boite de dialogue de
    'Tenons CNC'), exactement comme TenonIsolateCmd/TenonRestoreCmd :
    ainsi la suppression reste definitive meme si l'utilisateur ferme
    ensuite 'Tenons CNC' avec 'Fermer'."""
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            cmd = args.command
            cmd.isRepeatable = False
            onEx = _PurgeExecuteHandler()
            cmd.execute.add(onEx); _handlers.append(onEx)
        except: ui.messageBox(traceback.format_exc())


class _PurgeExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            design = adsk.fusion.Design.cast(app.activeProduct)
            if not design: return
            res = ui.messageBox('Purger tous les Tenons ?', 'Purger',
                adsk.core.MessageBoxButtonTypes.YesNoButtonType,
                adsk.core.MessageBoxIconTypes.WarningIconType)
            if res != adsk.core.DialogResults.DialogYes:
                return
            deleted, errors = _purge_tenons(design)
            try: app.activeViewport.fit()
            except: pass
            msg = f'{deleted} element(s) supprimes.'
            if errors: msg += ' - ' + ', '.join(errors)
            ui.messageBox(msg, 'Purger tous les Tenons')
        except:
            ui.messageBox('Tenons CNC - Erreur purge :\n' + traceback.format_exc())


class _DeleteSelCreatedHandler(adsk.core.CommandCreatedEventHandler):
    """'Annuler tenon CNC' (remplace l'ancienne 'Suppr. Tenons chants') :
    commande independante avec sa propre selection de CORPS (plus simple a
    l'usage qu'une selection de chant precis - un seul corps a
    selectionner meme s'il porte plusieurs tenons sur des chants
    differents) ; supprime aussi automatiquement la/les mortaise(s) et le
    jeu de fonctionnement lies, sur le(s) AUTRE(S) corps (voir
    annuler_tenon_cnc_pour_corps) - jamais ces autres corps eux-memes."""
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            cmd = args.command
            cmd.isRepeatable = False
            onEx  = _DeleteSelExecuteHandler()
            onVal = _DeleteSelValidateHandler()
            cmd.execute.add(onEx);         _handlers.append(onEx)
            cmd.validateInputs.add(onVal); _handlers.append(onVal)
            inp = cmd.commandInputs
            sel = inp.addSelectionInput(
                'del_sel_bodies', 'Corps',
                "Selectionnez le(s) corps portant le(s) tenon(s) a annuler")
            sel.addSelectionFilter('SolidBodies')
            sel.setSelectionLimits(1, 0)
        except: ui.messageBox(traceback.format_exc())


class _DeleteSelValidateHandler(adsk.core.ValidateInputsEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            args.areInputsValid = args.inputs.itemById('del_sel_bodies').selectionCount >= 1
        except: args.areInputsValid = False


class _DeleteSelExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            design = adsk.fusion.Design.cast(app.activeProduct)
            if not design: return
            sel = args.command.commandInputs.itemById('del_sel_bodies')
            bodies = []
            for k in range(sel.selectionCount):
                try:
                    body = adsk.fusion.BRepBody.cast(sel.selection(k).entity)
                    if body: bodies.append(body)
                except: pass
            if not bodies:
                ui.messageBox("Aucun corps selectionne.")
                return
            noms = ', '.join(b.name for b in bodies[:6])
            if len(bodies) > 6: noms += ', ...'
            res = ui.messageBox(
                f'Annuler le(s) tenon(s) du/des corps : {noms} ?\n\n'
                'Les mortaises correspondantes (creusees dans les autres '
                "corps) seront supprimees, et le jeu de fonctionnement sera "
                'reduit pour ne plus concerner que ces mortaises precises '
                "(le jeu des AUTRES mortaises, meme sur le meme corps "
                'femelle, est conserve) - les autres corps ne seront jamais '
                'supprimes, seulement leur decoupe de mortaise/jeu.\n\n'
                'Le tenon sera ensuite supprime sur le(s) corps '
                "selectionne(s), puis SEUL le composant/l'occurrence qui le "
                "contient sera RETIRE de l'assemblage (comme un clic droit "
                "> Retirer) - le corps lui-meme n'est jamais supprime "
                'directement, pour ne jamais risquer de supprimer une '
                "feature partagee par d'autres corps.",
                'Annuler tenon CNC', adsk.core.MessageBoxButtonTypes.YesNoButtonType,
                adsk.core.MessageBoxIconTypes.WarningIconType)
            if res != adsk.core.DialogResults.DialogYes:
                return
            tot = {'tenons_supprimes': 0, 'mortaises_supprimees': 0,
                   'jeux_supprimes': 0, 'jeux_reduits': 0}
            composants_retires = []
            errors = []
            for body in bodies:
                nom_body = body.name
                try:
                    r = annuler_tenon_cnc_pour_corps(design, body)
                except Exception:
                    errors.append(f'{nom_body}: ' + traceback.format_exc().strip().splitlines()[-1])
                    continue
                for k2 in ('tenons_supprimes', 'mortaises_supprimees', 'jeux_supprimes', 'jeux_reduits'):
                    tot[k2] += r.get(k2, 0)
                if r.get('composant_retire'):
                    composants_retires.append(r['composant_retire'])
                errors.extend(f'{nom_body}: {e}' for e in r.get('erreurs', []))
            try: app.activeViewport.fit()
            except: pass
            msg = (f"{tot['tenons_supprimes']} tenon(s)/languette(s) et "
                   f"{tot['mortaises_supprimees']} mortaise(s) supprimes. "
                   f"Jeu de fonctionnement : {tot['jeux_supprimes']} supprime(s) entierement, "
                   f"{tot['jeux_reduits']} reduit(s) (autres mortaises conservees).")
            if composants_retires:
                msg += '\n\nComposant(s) retire(s) : ' + ', '.join(composants_retires)
            if errors: msg += '\n\nErreurs :\n' + '\n'.join(errors[:10])
            ui.messageBox(msg, 'Annuler tenon CNC')
        except:
            ui.messageBox('Tenons CNC - Erreur annulation :\n' + traceback.format_exc())


class _RepairCreatedHandler(adsk.core.CommandCreatedEventHandler):
    """Commande independante (meme famille que Purger / Suppr. Tenons
    chants) : prepare les tenons/languettes crees AVANT le suivi des
    parametres pour qu'ils deviennent geres par 'Mettre a jour CNC' (voir
    backfill_all_tenon_specs - reconstruit mode/parametres/corps/plan a
    partir de leur geometrie existante). Verifie empiriquement : ancrer un
    tenon sur le contour de son esquisse par des contraintes ne suffit PAS a
    le rendre associatif au modele (ces courbes de contour ne sont pas des
    references vivantes) - la seule methode fiable est de le supprimer et
    de le recreer, ce que fait 'Mettre a jour CNC' une fois le spec connu."""
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            cmd = args.command
            cmd.isRepeatable = False
            onEx = _RepairExecuteHandler()
            cmd.execute.add(onEx); _handlers.append(onEx)
        except: ui.messageBox(traceback.format_exc())


class _RepairExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self): super().__init__()
    def notify(self, args):
        try:
            design = adsk.fusion.Design.cast(app.activeProduct)
            if not design:
                ui.messageBox("Aucun design actif.")
                return
            res = ui.messageBox(
                "Preparer les tenons/languettes crees avant cette mise a "
                "jour pour qu'ils soient desormais repositionnes par "
                "'Mettre a jour CNC' (comme les mortaises) ?\n\n"
                "Ceux qui le sont deja sont automatiquement ignores.",
                'Reparer anciens Tenons CNC',
                adsk.core.MessageBoxButtonTypes.YesNoButtonType,
                adsk.core.MessageBoxIconTypes.QuestionIconType)
            if res != adsk.core.DialogResults.DialogYes:
                return
            n_ok, n_total, n_purged, errors = backfill_all_tenon_specs(design)
            msg = f'{n_ok}/{n_total} tenon(s)/languette(s) pris en charge par "Mettre a jour CNC".'
            if n_purged:
                msg += f'\n{n_purged} entree(s) obsolete(s) nettoyee(s) (tenons deja supprimes depuis).'
            if errors:
                msg += '\n\nNon pris en charge :\n' + '\n'.join(errors[:10])
            msg += ('\n\nUtilisez ensuite "Mettre a jour CNC" apres chaque changement de '
                    'parametre pour les repositionner (ils sont supprimes puis '
                    'recrees a la position courante, comme les mortaises).')
            ui.messageBox(msg, 'Reparer anciens Tenons CNC')
        except:
            ui.messageBox('Tenons CNC - Erreur reparation :\n' + traceback.format_exc())


def run(context):
    global app, ui
    try:
        app = adsk.core.Application.get()
        ui  = app.userInterface

        old = ui.commandDefinitions.itemById(COMMAND_ID)
        if old:
            old.deleteMe()

        cmd_def = ui.commandDefinitions.addButtonDefinition(
            COMMAND_ID, COMMAND_NAME, COMMAND_DESC, "")

        on_created = _CreatedHandler()
        cmd_def.commandCreated.add(on_created)
        _handlers.append(on_created)

        # Bouton de ruban "Tenons CNC" (SolidCreatePanel/SolidModifyPanel)
        # RETIRE : devenu inutile depuis la creation de CNC Toolkit, qui
        # regroupe deja cet outil (avec tous les autres) dans sa palette -
        # la CommandDefinition ci-dessus reste enregistree (c'est elle que
        # CNC Toolkit retrouve et execute via ui.commandDefinitions.itemById),
        # seul l'ajout redondant d'un bouton natif est supprime. Les
        # panel_ids ci-dessous restent necessaires pour Purger/Annuler/
        # Reparer (voir plus bas), qui eux ne sont PAS dans la palette.
        panel_ids = ["SolidCreatePanel", "SolidModifyPanel",
                     "SketchCreatePanel", "ToolsPanel"]

        # "Isoler" / "Afficher tout" retires de la barre d'outils a la
        # demande de l'utilisateur. On continue neanmoins de supprimer les
        # anciennes commandes/boutons s'ils existent encore (installation
        # precedente), pour un nettoyage propre.
        old_iso = ui.commandDefinitions.itemById("TenonIsolateCmd")
        if old_iso: old_iso.deleteMe()
        old_rest = ui.commandDefinitions.itemById("TenonRestoreCmd")
        if old_rest: old_rest.deleteMe()
        for pid in panel_ids:
            panel = ui.allToolbarPanels.itemById(pid)
            if panel is None: continue
            for cid in ("TenonIsolateCmd", "TenonRestoreCmd"):
                ctrl = panel.controls.itemById(cid)
                if ctrl: ctrl.deleteMe()
        try:
            app.unregisterCustomEvent('TenonCreateEv')
        except: pass
        eo = app.registerCustomEvent('TenonCreateEv')
        eh = _TenonCreateHandler()
        eo.add(eh)
        _handlers.append(eh)

        old_purge = ui.commandDefinitions.itemById(PURGE_ID)
        if old_purge: old_purge.deleteMe()
        old_del = ui.commandDefinitions.itemById(DELETE_SEL_ID)
        if old_del: old_del.deleteMe()
        purge_def = ui.commandDefinitions.addButtonDefinition(
            PURGE_ID, 'Purger Tenons CNC', 'Supprimer tous les tenons crees par cet add-in')
        purge_cr = _PurgeCreatedHandler()
        purge_def.commandCreated.add(purge_cr)
        _handlers.append(purge_cr)
        del_def = ui.commandDefinitions.addButtonDefinition(
            DELETE_SEL_ID, 'Annuler tenon CNC',
            "Supprime le(s) tenon(s) d'un corps selectionne ainsi que "
            "les mortaises/jeu qui lui sont lies, sans supprimer les "
            "autres corps")
        del_cr = _DeleteSelCreatedHandler()
        del_def.commandCreated.add(del_cr)
        _handlers.append(del_cr)

        old_repair = ui.commandDefinitions.itemById(REPAIR_ID)
        if old_repair: old_repair.deleteMe()
        repair_def = ui.commandDefinitions.addButtonDefinition(
            REPAIR_ID, 'Reparer anciens Tenons',
            "Ancrer sur leur chant les tenons/languettes crees avant le "
            "correctif d'associativite")
        repair_cr = _RepairCreatedHandler()
        repair_def.commandCreated.add(repair_cr)
        _handlers.append(repair_cr)

        for pid in panel_ids:
            panel = ui.allToolbarPanels.itemById(pid)
            if panel is None: continue
            try:
                panel.controls.addCommand(purge_def)
                panel.controls.addCommand(del_def)
                panel.controls.addCommand(repair_def)
                break
            except: continue

        adsk.autoTerminate(False)

    except:
        if ui:
            ui.messageBox("Tenons CNC - Erreur au demarrage :\n" + traceback.format_exc())


def stop(context):
    try:
        panel_ids = ["SolidCreatePanel", "SolidModifyPanel",
                     "SketchCreatePanel", "ToolsPanel"]
        for pid in panel_ids:
            panel = ui.allToolbarPanels.itemById(pid)
            if panel is None:
                continue
            ctrl = panel.controls.itemById(COMMAND_ID)
            if ctrl:
                ctrl.isPromoted = False
                ctrl.deleteMe()
        cmd_def = ui.commandDefinitions.itemById(COMMAND_ID)
        if cmd_def: cmd_def.deleteMe()
        for cid in ("TenonIsolateCmd", "TenonRestoreCmd", PURGE_ID, DELETE_SEL_ID, REPAIR_ID):
            cd = ui.commandDefinitions.itemById(cid)
            if cd: cd.deleteMe()
        for pid in panel_ids:
            panel = ui.allToolbarPanels.itemById(pid)
            if panel is None: continue
            for cid in ("TenonIsolateCmd", "TenonRestoreCmd", PURGE_ID, DELETE_SEL_ID, REPAIR_ID):
                ctrl = panel.controls.itemById(cid)
                if ctrl: ctrl.deleteMe()
        try: app.unregisterCustomEvent('TenonCreateEv')
        except: pass
        _handlers.clear()
    except:
        if ui:
            ui.messageBox("Tenons CNC - Erreur a larret :\n" + traceback.format_exc())
