@echo off
setlocal
title Installation CNC Toolkit
echo ============================================
echo   Installation de CNC Toolkit pour Fusion
echo ============================================
echo.

set "SRC=%~dp0ToolkitCNC"
set "ADDINS=%APPDATA%\Autodesk\Autodesk Fusion 360\API\AddIns"
set "DEST=%ADDINS%\ToolkitCNC"

if not exist "%SRC%\ToolkitCNC.py" (
  echo ERREUR : le dossier ToolkitCNC est introuvable a cote de ce script.
  echo Decompressez d'abord tout le zip ^(clic droit ^> Extraire tout^),
  echo puis lancez INSTALLER.bat depuis le dossier extrait.
  echo.
  pause
  exit /b 1
)

tasklist /FI "IMAGENAME eq Fusion360.exe" 2>nul | find /I "Fusion360.exe" >nul
if not errorlevel 1 (
  echo Fusion 360 est ouvert. Fermez-le, puis appuyez sur une touche.
  pause >nul
)

for /f %%i in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss"') do set "STAMP=%%i"
if not exist "%ADDINS%" mkdir "%ADDINS%"

if exist "%DEST%" (
  echo Une ancienne version existe : elle est mise de cote dans
  echo   ToolkitCNC_ancien_%STAMP%
  move "%DEST%" "%ADDINS%\ToolkitCNC_ancien_%STAMP%" >nul
  if errorlevel 1 (
    echo ERREUR : impossible de deplacer l'ancienne version. Fusion est-il ferme ?
    pause
    exit /b 1
  )
)

echo Copie des fichiers...
robocopy "%SRC%" "%DEST%" /E /NFL /NDL /NJH /NJS /NP >nul
if errorlevel 8 (
  echo ERREUR pendant la copie.
  pause
  exit /b 1
)

echo.
echo Installation terminee dans :
echo   %DEST%
echo.
echo Ouvrez Fusion : CNC Toolkit demarre seul et active tous ses outils
echo ^(Tenons, Mortaise, Entaille, Gravure, Reseau...^). Rien a cocher dans Maj+S.
echo Si la fenetre CNC Toolkit n'apparait pas, voir LISEZMOI.txt.
echo.
pause
